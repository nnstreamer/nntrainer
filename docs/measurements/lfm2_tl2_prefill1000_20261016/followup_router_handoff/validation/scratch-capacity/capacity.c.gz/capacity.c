#include "/tmp/nntr-lfm2-router-handoff-20261016/worktree/nntrainer/tensor/htp_backend/hmx/hexkl_mm_u8i4_moe.c"
unsigned audit_need_M1024_E1(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=1, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E2(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=2, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E3(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=3, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E4(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=4, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E5(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=5, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E6(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=6, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E7(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=7, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E8(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=8, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E9(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=9, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E10(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=10, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E11(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=11, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E12(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=12, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E13(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=13, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E14(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=14, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E15(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=15, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E16(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=16, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E17(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=17, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E18(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=18, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E19(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=19, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E20(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=20, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E21(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=21, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E22(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=22, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E23(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=23, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E24(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=24, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E25(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=25, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E26(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=26, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E27(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=27, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E28(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=28, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E29(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=29, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E30(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=30, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E31(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=31, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E32(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=32, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E33(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=33, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E34(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=34, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E35(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=35, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E36(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=36, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E37(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=37, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E38(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=38, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E39(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=39, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E40(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=40, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E41(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=41, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E42(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=42, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E43(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=43, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E44(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=44, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E45(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=45, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E46(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=46, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E47(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=47, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E48(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=48, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E49(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=49, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E50(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=50, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E51(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=51, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E52(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=52, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E53(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=53, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E54(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=54, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E55(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=55, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E56(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=56, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E57(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=57, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E58(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=58, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E59(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=59, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E60(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=60, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E61(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=61, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E62(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=62, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E63(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=63, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M1024_E64(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=64, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E1(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=1, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E2(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=2, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E3(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=3, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E4(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=4, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E5(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=5, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E6(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=6, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E7(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=7, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E8(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=8, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E9(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=9, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E10(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=10, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E11(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=11, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E12(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=12, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E13(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=13, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E14(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=14, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E15(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=15, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E16(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=16, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E17(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=17, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E18(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=18, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E19(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=19, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E20(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=20, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E21(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=21, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E22(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=22, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E23(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=23, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E24(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=24, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E25(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=25, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E26(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=26, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E27(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=27, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E28(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=28, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E29(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=29, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E30(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=30, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E31(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=31, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E32(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=32, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E33(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=33, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E34(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=34, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E35(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=35, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E36(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=36, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E37(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=37, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E38(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=38, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E39(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=39, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E40(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=40, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E41(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=41, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E42(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=42, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E43(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=43, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E44(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=44, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E45(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=45, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E46(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=46, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E47(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=47, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E48(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=48, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E49(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=49, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E50(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=50, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E51(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=51, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E52(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=52, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E53(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=53, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E54(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=54, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E55(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=55, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E56(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=56, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E57(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=57, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E58(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=58, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E59(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=59, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E60(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=60, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E61(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=61, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E62(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=62, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E63(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=63, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_need_M2048_E64(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=8192, n_experts=64, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned char audit_hvx_bg_job_size[sizeof(hvx_bg_job)];
unsigned char audit_moe_tail_ctx_size[sizeof(moe_tail_ctx)];
unsigned audit_warmup_M1024_E64(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=1024, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=64, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}
unsigned audit_warmup_M2048_E64(void) {
  hexkl_moe_scratch st = {0}; hexkl_moe_scratch *scratch = &st;
  void *pool = 0; const unsigned M=2048, K=2048, inter=1536, N_out=2048, n_rows=4096, n_experts=64, BR=HEXKL_HMX_INT8_BLOCK_N_ROW, m_pad=ROUND_UP_U32(M,BR), inter_ntiles=(2u*inter/HEXKL_HMX_INT8_BLOCK_N_COL)/2u, dn_ntiles=N_out/HEXKL_HMX_INT8_BLOCK_N_COL, inter_ktiles=inter/HEXKL_HMX_INT8_BLOCK_N_INNER;
  const int use_m1=0;
  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;
  return (unsigned)need;
}

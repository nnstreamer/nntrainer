	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"capacity.c"
	.globl	hexkl_moe_scratch_free          // -- Begin function hexkl_moe_scratch_free
	.falign
	.type	hexkl_moe_scratch_free,@function
hexkl_moe_scratch_free:                 // @hexkl_moe_scratch_free
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#1)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB0_3
	}
// %bb.1:                               // %if.then
	{
		r17:16 = combine(#0,#0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r3:2 = add(r3:2,r5:4)
		r1 = memw(r0+#0)
		memw(r0+#48) = #0
	}
	{
		r0 = r1
		memd(r0+#24) = r3:2
		memd(r18+#40) = r17:16
	}
	{
		call free
		memd(r18+#56) = r17:16
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r18+#0) = r17:16
		memw(r18+#8) = #0
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB0_3:                                // %if.end
	{
		jumpr r31
	}
.Lfunc_end0:
	.size	hexkl_moe_scratch_free, .Lfunc_end0-hexkl_moe_scratch_free
                                        // -- End function
	.globl	hexkl_moe_scratch_reserve       // -- Begin function hexkl_moe_scratch_reserve
	.falign
	.type	hexkl_moe_scratch_reserve,@function
hexkl_moe_scratch_reserve:              // @hexkl_moe_scratch_reserve
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#0)
		r17:16 = combine(r1,r0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r6 = memw(r0+#8)
		memd(r0+#40) = r5:4
	}
	{
		r1:0 = combine(#0,#1)
		p0 = cmp.gtu(r17,r6)
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r3:2,r1:0)
		r18 = #0
		memd(r16+#56) = r5:4
		memw(r16+#48) = #0
	}
	{
		if (!p0) jump:nt .LBB1_5
		memd(r16+#24) = r1:0
	}
// %bb.1:                               // %hexkl_moe_scratch_free.exit
	{
		r1:0 = combine(#0,#2)
		memw(r16+#40) = #0
		memw(r16+#56) = #0
	}
	{
		r3:2 = add(r3:2,r1:0)
		r0 = memw(r16+#0)
	}
	{
		call free
		memd(r16+#24) = r3:2
	}
	.falign
// %bb.2:                               // %hexkl_moe_scratch_free.exit
	{
		call malloc
		r0 = add(r17,#128)
		memw(r16+#4) = #0
		memw(r16+#8) = #0
	}
	.falign
// %bb.3:                               // %hexkl_moe_scratch_free.exit
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB1_6
		memw(r16+#0) = r0
		if (!p1.new) memw(r16+#8) = r17
	}
// %bb.4:                               // %if.end3
	{
		r2 = add(r0,#127)
	}
	{
		r2 = and(r2,#-128)
		memw(r16+#4) = r2.new
	}
	.falign
.LBB1_5:                                // %return
	{
		r0 = r18
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB1_6:
	{
		r18 = ##-2147482622
		r0 = ##-2147482622
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	hexkl_moe_scratch_reserve, .Lfunc_end1-hexkl_moe_scratch_reserve
                                        // -- End function
	.globl	hexkl_moe_carve                 // -- Begin function hexkl_moe_carve
	.balign 32
	.type	hexkl_moe_carve,@function
hexkl_moe_carve:                        // @hexkl_moe_carve
// %bb.0:                               // %entry
	{
		r3 = add(r1,#127)
		r2 = memw(r0+#0)
	}
	{
		r3 = and(r3,#-128)
	}
	{
		r3 = add(r2,r3)
		jumpr r31
		r0 = r2
		memw(r0+#0) = r3.new
	}
.Lfunc_end2:
	.size	hexkl_moe_carve, .Lfunc_end2-hexkl_moe_carve
                                        // -- End function
	.globl	hexkl_moe_push_weight_chunk     // -- Begin function hexkl_moe_push_weight_chunk
	.falign
	.type	hexkl_moe_push_weight_chunk,@function
hexkl_moe_push_weight_chunk:            // @hexkl_moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		r6 = r5
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		memd(r29+#48) = r19:18
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r24 = memw(r29+#76)
		memd(r29+#32) = r23:22
	}
	{
		if (p0) jump:nt .LBB3_3
		r5 = memw(r29+#72)
		memd(r29+#16) = r27:26
	}
// %bb.1:                               // %if.then
	{
		r3:2 = combine(r18,#0)
		r4 = r6
		memw(r29+#0) = r24
		memw(r29+#4) = #0
	}
	{
		call moe_push_native_chunk
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB3_3:                                // %if.end
	{
		r27 = asl(r5,#9)
		r7 = r4
		r17 = r3
	}
	{
		r21:20 = vaslw(r7:6,#9)
	}
	{
		r19 = r20
	}
	{
		r19 += add(r0,r1)
		r2 = memw(r18+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB3_8
	}
// %bb.4:                               // %if.then3
	{
		r26 = r21
	}
	{
		call hexkl_dma_ring_next_idx
		r27:26 = vlsrw(r27:26,#1)
	}
	.falign
// %bb.5:                               // %if.then3
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
		memw(r29+#12) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_12
	}
// %bb.6:                               // %if.then12
	{
		r0 = lsr(r3,#10)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then12
	{
		r3 = lsr(r20,#1)
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		r2 = memw(r18+#4)
	}
	{
		if (!p1) jump:nt .LBB3_13
	}
	{
		jump .LBB3_15
	}
	.falign
.LBB3_8:                                // %if.end30
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.9:                               // %if.end30
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = r0
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_19
	}
// %bb.10:                              // %if.then44
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then44
	{
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		if (!p1.new) jump:t .LBB3_20
		r2 = memw(r18+#4)
	}
	{
		jump .LBB3_22
	}
	.falign
.LBB3_12:
	{
		r3 = lsr(r20,#1)
		p1 = cmp.eq(r24,#0)
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	{
		if (p1) jump:nt .LBB3_15
	}
	.falign
.LBB3_13:                               // %land.rhs.i
	{
		r16 = #1
		r4 = memw(r18+#36)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB3_15
	}
// %bb.14:                              // %lor.rhs.i
	{
		r4 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r4,#0)
	}
	.falign
.LBB3_15:                               // %moe_weight_src_bypass.exit
	{
		r1 = add(r2,r3)
		r0 = add(r19,r27)
		r3:2 = combine(r26,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.16:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_26
	}
// %bb.17:                              // %if.then24
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.18:                              // %if.then24
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
		memd(r2+#96) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_19:
	{
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB3_22
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	.falign
.LBB3_20:                               // %land.rhs.i105
	{
		r16 = #1
		r3 = memw(r18+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB3_22
	}
// %bb.21:                              // %lor.rhs.i109
	{
		r3 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r3,#0)
	}
	.falign
.LBB3_22:                               // %moe_weight_src_bypass.exit112
	{
		r1 = add(r2,r20)
		r0 = r19
		r3:2 = combine(r21,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.23:                              // %moe_weight_src_bypass.exit112
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_27
	}
// %bb.24:                              // %if.then56
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then56
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		r0 = r26
		jump .LBB3_28
		memd(r2+#96) = r1:0
	}
	.falign
.LBB3_26:
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_27:
	{
		r0 = r26
	}
	.falign
.LBB3_28:                               // %cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hexkl_moe_push_weight_chunk, .Lfunc_end3-hexkl_moe_push_weight_chunk
                                        // -- End function
	.falign
	.type	moe_push_native_chunk,@function // -- Begin function moe_push_native_chunk
moe_push_native_chunk:                  // @moe_push_native_chunk
// %bb.0:                               // %entry
	{
		r9:8 = combine(#0,#0)
		p1 = cmp.eq(r4,#0)
		memd(r29+#-16) = r17:16
		allocframe(#136)
	}                                       // 8-byte Folded Spill
	{
		r2 = add(r4,add(r5,#3))
		r17:16 = combine(r0,r3)
		r6 = memw(r29+#144)
		memw(r29+#36) = r2
	}
	{
		r27 = lsr(r2,#2)
		p0 = cmp.eq(r6,#0)
		r13 = #0
		memd(r29+#88) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r2 = #0
		memd(r29+#120) = r19:18
		memd(r29+#112) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#104) = r23:22
		memd(r29+#96) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) memd(r3+#64) = r9:8
		if (p1) memd(r3+#56) = r9:8
	}
	{
		if (p0) jump:nt .LBB4_3
		memw(r29+#28) = r2
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB4_3
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_3:                                // %moe_weight_src_bypass.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = lsr(r4,#2)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.gtu(r27,r26)
		if (!p0.new) jump:t .LBB4_95
		if (p0.new) r2 = memw(r29+#36)
		if (p0.new) r4 = memw(r16+#28)
	}                                       // 4-byte Folded Reload
// %bb.4:                               // %for.body.lr.ph
	{
		r5 = ##-1431655765
		r3 = add(r4,#23)
		r6 = memw(r29+#148)
	}
	{
		r3 = mpyu(r3,r5)
		p0 = cmp.eq(r2,#0)
		r2 = #640
	}
	{
		if (p0) r12 = ##2560
		memw(r29+#40) = r6
		if (!p0) memw(r29+#44) = r27
	}                                       // 4-byte Folded Spill
	{
		r3 = lsr(r3,#4)
	}
	{
		r14 = mpyi(r3,r2)
		if (p0) jump:nt .LBB4_39
		memw(r29+#24) = r14.new
	}                                       // 4-byte Folded Spill
// %bb.5:
	{
		p1 = cmp.eq(r6,#0)
		r9:8 = combine(#0,#1)
		r25:24 = combine(#0,#0)
	}
	{
		r2 = p1
		memw(r29+#48) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_6:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_10 Depth 2
	{
		r1:0 = asl(r9:8,r26)
		r18 = add(r26,#1)
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p0 = cmp.eq(r5:4,r25:24)
		if (!p0.new) r18 = add(r26,#1)
		if (p0.new) jump:t .LBB4_8
	}
// %bb.7:                               //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = cmp.gtu(r27,r18)
		r26 = r18
		if (p1.new) jump:t .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_8:                                // %if.end13
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		p1 = cmp.gtu(r27,r18)
		if (p1.new) r2 = sub(r27,r18)
	}
	{
		if (!p1) jump:nt .LBB4_13
		memd(r16+#64) = r1:0
	}
// %bb.9:                               //   in Loop: Header=BB4_6 Depth=1
	{
		loop0(.LBB4_10,r2)
	}
	.falign
.LBB4_10:                               // Block address taken
                                        // %land.rhs
                                        //   Parent Loop BB4_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3:2 = asl(r9:8,r18)
	}
	{
		r5:4 = and(r1:0,r3:2)
	}
	{
		r1:0 = or(r1:0,r3:2)
		p0 = cmp.eq(r5:4,r25:24)
		if (p0.new) r18 = add(r18,#1)
		if (!p0.new) jump:nt .LBB4_13
	}
// %bb.11:                              // %while.body
                                        //   in Loop: Header=BB4_10 Depth=2
	{
		nop
		memd(r16+#64) = r1:0
	} :endloop0
// %bb.12:                              //   in Loop: Header=BB4_6 Depth=1
	{
		r18 = r27
	}
	.falign
.LBB4_13:                               // %while.end
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = sub(r18,r26)
		r0 = #16256
	}
	{
		r17 = mpyi(r2,r14)
		r2 = #8064
	}
	{
		p1 = bitsclr(r17,r0)
		if (!p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB4_20
	}
// %bb.14:                              // %while.body.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		if (!p0.new) r2 = ##3968
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.15:                              // %while.body.1.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		if (!p1.new) r2 = #1920
		if (p1.new) jump:nt .LBB4_22
	}
// %bb.16:                              // %while.body.2.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #2048
		if (!p0.new) r2 = #896
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.17:                              // %while.body.3.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		r19 = #1024
		if (!p1.new) r2 = #384
		if (p1.new) jump:nt .LBB4_26
	}
// %bb.18:                              // %while.body.4.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #512
		if (!p0.new) r2 = #128
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.19:                              // %while.body.5.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = !tstbit(r17,#7)
	}
	{
		r19 = mux(p1,##256,r2)
		jump .LBB4_26
	}
	.falign
.LBB4_20:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #16384
		jump .LBB4_26
	}
	.falign
.LBB4_22:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #4096
	}
	.falign
.LBB4_26:                               // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r17)
		r27 = memw(r16+#44)
		memw(r29+#32) = r13
	}                                       // 4-byte Folded Spill
	.falign
// %bb.27:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r21 = r0
	}
	.falign
// %bb.28:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r20 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_31
	}
// %bb.29:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.30:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(r1,r0)
		jump .LBB4_32
	}
	.falign
.LBB4_31:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(#0,#0)
	}
	.falign
.LBB4_32:                               // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r5:4 = combine(r21,r19)
		r2 = memw(r29+#24)
		r7 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = #1
	}
	{
		r6 = mpyi(r26,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3:2 = combine(r19,r19)
		r1 = add(r27,r6)
		r0 = add(r7,r6)
	}
	.falign
// %bb.33:                              // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r26 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.34:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.35:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r26+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_38
	}
// %bb.36:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.37:                              // %if.then11.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r20
		r4 = memw(r2+#4)
		memw(r29+#0) = r19

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = r21
		memw(r29+#8) = r19
	}
	.falign
.LBB4_38:                               // %moe_native_push2d.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r9:8 = combine(#0,#1)
		r26 = r18
		r13 = memw(r29+#32)
		r27 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r17,r13)
		p1 = cmp.gtu(r27,r18)
		r14 = memw(r29+#24)
		memw(r16+#72) = r20
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_39:                               // %for.body.us.preheader
	{
		r5 = mpyu(r4,r5)
		p0 = cmp.gtu(r4,#95)
		r7:6 = combine(#0,#2)
		r21 = memw(r16+#32)
	}
	{
		r5 = mpyi(r26,r3)
		r15 = lsr(r5,#6)
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
	}
	{
		r7 = insert(r26,#21,#11)
		r8 = asl(r15,#2)
		memw(r29+#36) = r15
	}                                       // 4-byte Folded Spill
	{
		r9 = +mpyi(r15,#3)
		r21 = and(##-512,asl(r21,#4))
		p1 = cmp.eq(r3,r8)
	}
	{
		r20 = mpyi(r5,r2)
		r3 = p1
		r5 = sub(r3,r8)
		memw(r29+#52) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r17 += add(r1,r7)
		r7 = mpyi(r15,r12)
		p1 = cmp.gtu(r5,#2)
		memw(r29+#44) = r7.new
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r9,r21)
		r4 = p0
		r7 = add(r5,#-2)
		memw(r29+#32) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r12 = minu(r5,r6)
		r6 = minu(r7,r6)
		r4 = add(r9,#1)
		memw(r29+#72) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r4,r21)
		r7 = +mpyi(r21,#3)
		memw(r29+#76) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p1
		memw(r29+#48) = r7
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r12,r2)
		r2 = mpyi(r6,r2)
		memw(r29+#56) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#60) = r3
		memw(r29+#64) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_40:                               // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1:0 = asl(r11:10,r26)
		r25 = r13
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p1 = cmp.eq(r5:4,r19:18)
		if (!p1.new) jump:t .LBB4_94
		if (p1.new) r23 = memw(r16+#44)
	}
// %bb.41:                              // %if.end13.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		r24 = add(r23,r20)
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB4_54
		memd(r16+#64) = r1:0
	}
// %bb.42:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.43:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_46
	}
// %bb.44:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_47
	}
	.falign
.LBB4_46:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_47:                               // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = combine(r24,r17)
		r3 = #2560
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = #1280
		r2 = memw(r29+#48)
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.48:                              // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.49:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.50:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_53
	}
// %bb.51:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.52:                              // %if.then11.i176.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_53:                               // %moe_native_push2d.exit179.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r22
	}
	.falign
.LBB4_54:                               // %if.end55.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r2)
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_57
		if (p0.new) r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
// %bb.55:                              // %for.inc.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		p0 = r2
		if (p0.new) jump:t .LBB4_69
	}
	.falign
.LBB4_56:                               // %if.end55.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	{
		jump .LBB4_81
	}
	.falign
.LBB4_57:                               // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.58:                              // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_61
	}
// %bb.59:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.60:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_62
	}
	.falign
.LBB4_61:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_62:                               // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = r24
		r3 = #1280
		r5 = #1
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		r4 = memw(r29+#60)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	.falign
// %bb.63:                              // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.64:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.65:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_68
	}
// %bb.66:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.67:                              // %if.then11.i194.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_68:                               // %moe_native_push2d.exit197.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#32)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_56
	}
	.falign
.LBB4_69:                               // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.70:                              // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_73
	}
// %bb.71:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.72:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_74
	}
	.falign
.LBB4_73:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_74:                               // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = #1280
		r0 = add(r17,r21)
		r3 = #2560
		r4 = #1280
	}
	{
		r23 += add(r20,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r1 = r23
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.75:                              // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.76:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r23 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.77:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r23
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_80
	}
// %bb.78:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.79:                              // %if.then11.i176.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_80:                               // %moe_native_push2d.exit179.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	.falign
.LBB4_81:                               // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.82:                              // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r23 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_85
	}
// %bb.83:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.84:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_86
	}
	.falign
.LBB4_85:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_86:                               // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = add(r24,#1280)
		r3 = #1280
		r2 = memw(r29+#76)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r5 = #1
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		memw(r29+#4) = #1
	}
	.falign
// %bb.87:                              // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.88:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r22 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.89:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r22
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_92
	}
// %bb.90:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.91:                              // %if.then11.i194.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r23
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_92:                               // %moe_native_push2d.exit197.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r23
	}
	.falign
.LBB4_93:                               // %for.inc.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
		r14 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r25,r14)
	}
	.falign
.LBB4_94:                               // %cleanup77.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r20 = add(r20,r14)
		r17 = add(r17,#2048)
	}
	{
		r26 = add(r26,#1)
		if (!cmp.eq(r26.new,r27)) jump:t ##.LBB4_40
	}
	.falign
.LBB4_95:                               // %for.cond.cleanup
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_97
	}
// %bb.96:                              // %if.then81
	{
		r0 = lsr(r13,#10)
		r1 = #0
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB4_97:                               // %do.end
	{
		r0 = memw(r16+#72)
		r17:16 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#120)
		r21:20 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r23:22 = memd(r29+#104)
		r25:24 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r27:26 = memd(r29+#88)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end4:
	.size	moe_push_native_chunk, .Lfunc_end4-moe_push_native_chunk
                                        // -- End function
	.globl	hexkl_moe_expand_chunk          // -- Begin function hexkl_moe_expand_chunk
	.balign 32
	.type	hexkl_moe_expand_chunk,@function
hexkl_moe_expand_chunk:                 // @hexkl_moe_expand_chunk
// %bb.0:                               // %entry
	{
		r4 = r3
		r3 = r2
		r6 = r4
		allocframe(#16)
	}
	{
		r2 = memw(r29+#28)
		memw(r29+#8) = r2.new
	}
	{
		r2 = memw(r29+#24)
		memw(r29+#4) = r2.new
	}
	{
		call moe_expand_chunk
		r5 = r6
		r2 = #0
		memw(r29+#0) = r5
	}
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end5:
	.size	hexkl_moe_expand_chunk, .Lfunc_end5-hexkl_moe_expand_chunk
                                        // -- End function
	.falign
	.type	moe_expand_chunk,@function      // -- Begin function moe_expand_chunk
moe_expand_chunk:                       // @moe_expand_chunk
// %bb.0:                               // %entry
	{
		r6 = r3
		allocframe(r29,#256):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r7 = memw(r3+#44)
		deallocframe
	}
	{
		p1 = cmp.eq(r7,#0)
	}
	{
		r18 = memw(r30+#12)
		memd(r30+#-16) = r19:18
	}
	{
		r22 = r4
		r17 = r0
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r0 = add(r3,#88)
		if (!p1) r12 = add(r17,r1)
		r16 = memw(r30+#16)
		r4 = memw(r30+#8)
	}
	{
		if (p1) jump:nt .LBB6_10
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r5 = add(r4,add(r18,#3))
		r3 = lsr(r4,#2)
	}
	{
		r7 = lsr(r5,#2)
		r5:4 = combine(#0,#0)
	}
	{
		if (p0.new) r7 = sub(r7,r3)
		p0 = cmp.gtu(r7,r3); if (!p0.new) jump:t .LBB6_4
	}
// %bb.2:
	{
		loop0(.LBB6_3,r7)
		r9:8 = combine(#0,#1)
	}
	.falign
.LBB6_3:                                // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r9:8,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB6_4:                                // %for.cond.cleanup7.i
	{
		r15 = ##-1431655765
		r13 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r7 = #0
		r28 = add(r13,#23)
		r1 = add(r13,#95)
		r14 = add(r3,#127)
	}
	{
		r2 = mpyu(r28,r15)
		r15 = mpyu(r1,r15)
		r9:8 = memd(r6+#56)
		memw(r29+#156) = r2
	}
	{
		r14 = lsr(r14,#7)
		r28 = lsr(r2,#4)
		p1 = cmp.gtu(r14,#127)
		memw(r29+#168) = r13
	}
	{
		r2 = lsr(r15,#6)
		r13:12 = and(r5:4,~r9:8)
		memw(r29+#152) = r12
		memw(r29+#172) = r14
	}
	{
		r15 = +mpyi(r28,##640)
		memw(r29+#184) = r7
		memd(r29+#160) = r13:12
	}
	{
		if (!p1) jump:nt .LBB6_16
		memw(r29+#176) = r2
		memw(r29+#180) = r15
	}
// %bb.5:
	{
		r15 = lsr(r14,#1)
		r19:18 = combine(#0,#1)
		r11:10 = combine(#0,#0)
		r28 = and(r14,#1)
	}
	{
		p1 = cmp.gtu(r15,#0)
		if (!p1.new) jump:t .LBB6_14
	}
// %bb.6:
	{
		loop0(.LBB6_7,r15)
		r15:14 = combine(#0,#0)
	}
	.falign
.LBB6_7:                                // =>This Inner Loop Header: Depth=1
	{
		r21:20 = combine(r13,r12)
		r1 = add(r14,r2)
		r17 = add(r15,#1)
		r23:22 = combine(r13,r12)
	}
	{
		r21:20 &= asl(r19:18,r15)
		r23:22 &= asl(r19:18,r17)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r21:20,r11:10)
		if (!p0.new) r14 = add(r1,#0)
		if (!p0.new) r7 = add(r1,#0)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r1 = add(r14,r2)
	}
	{
		if (!p0) r14 = add(r1,#0)
		if (!p0) r7 = add(r1,#0)
	} :endloop0
// %bb.8:
	{
		p1 = cmp.gtu(r28,#0)
		if (!p1.new) jump:t .LBB6_15
	}
	.falign
.LBB6_9:                                // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r19:18,r15)
		r2 = add(r14,r2)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		if (!p1.new) r7 = add(r2,#0)
		jump .LBB6_15
	}
	.falign
.LBB6_10:                               // %if.end
	{
		r23 = r1
		r19 = add(r29,#0)
		r2 = memw(r6+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB6_39
	}
// %bb.11:                              // %if.end4
	{
		r21:20 = vaslw(r5:4,#9)
		r1 = r19
	}
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.12:                              // %if.end4
	{
		r20 += add(r17,r23)
		r18 = and(##2147483392,asl(r18,#8))
		r5:4 = combine(r16,r19)
	}
	{
		call hvx_expand_i2i4_rows
		r1:0 = combine(r21,r20)
		r3:2 = combine(r22,r18)
	}
	.falign
// %bb.13:                              // %if.end4
	{
		jump .LBB6_39
	}
	.falign
.LBB6_14:
	{
		r15:14 = combine(#0,#0)
		p1 = cmp.gtu(r28,#0)
		if (p1.new) jump:t .LBB6_9
	}
	.falign
.LBB6_15:                               // %for.cond.cleanup24.i.loopexit
	{
		memw(r29+#184) = r7
	}
	.falign
.LBB6_16:                               // %for.cond.cleanup24.i
	{
		r7 = #0
		r2 = memb(r0+#0)
	}
	{
		r2 = abs(r2)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB6_19
	}
// %bb.17:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#7); if (p1.new) jump:nt .LBB6_19
	}
// %bb.18:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_19:                               // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_24
	}
// %bb.20:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_22
	}
// %bb.21:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_22:                               // %lor.lhs.false.1.i.i
	{
		if (p0) jump:nt .LBB6_25
	}
// %bb.23:                              // %lor.lhs.false.1.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_25
	}
	.falign
.LBB6_24:
	{
		r12 = r2
	}
	.falign
.LBB6_25:                               // %for.inc.1.i.i
	{
		r2 = memb(r6+#90)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB6_30
	}
// %bb.26:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB6_28
	}
// %bb.27:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_28:                               // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,#0)
		if (p0.new) jump:nt .LBB6_31
	}
// %bb.29:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,r2)
		if (!p1.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_31
	}
	.falign
.LBB6_30:
	{
		r2 = r12
	}
	.falign
.LBB6_31:                               // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_36
	}
// %bb.32:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_34
	}
// %bb.33:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB6_38
	}
	.falign
.LBB6_34:                               // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB6_37
	}
// %bb.35:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_37
	}
	.falign
.LBB6_36:
	{
		r12 = r2
	}
	.falign
.LBB6_37:                               // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r7 = maxu(r12,r2)
	}
	.falign
.LBB6_38:                               // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r29+#12) = r3.new
	}
	{
		r1 = add(pc,##moe_expand_unit@PCREL)
		r2 = add(r29,#0)
		r0 = r16
	}
	{
		call hvx_worker_pool_run
		r3 = #8
		memw(r29+#188) = r7
		memd(r6+#56) = r5:4
	}
	.falign
.LBB6_39:                               // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	moe_expand_chunk, .Lfunc_end6-moe_expand_chunk
                                        // -- End function
	.globl	hexkl_moe_push_act_block        // -- Begin function hexkl_moe_push_act_block
	.falign
	.type	hexkl_moe_push_act_block,@function
hexkl_moe_push_act_block:               // @hexkl_moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17:16 = combine(r4,r2)
		memd(r29+#-16) = r17:16
		allocframe(#40)
	}                                       // 8-byte Folded Spill
	{
		r18 = r3
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r19:18
		memd(r29+#16) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) r19 = ##16384
		if (p0) jump:nt .LBB7_5
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = bitsclr(r5,#3)
		if (p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB7_5
	}
// %bb.2:                               // %while.body.1.i
	{
		p0 = tstbit(r5,#0)
		if (p0.new) r19 = ##2048
	}
	{
		if (!p0) r19 = ##4096
		jump .LBB7_5
	}
	.falign
.LBB7_5:                                // %moe_dma_row_size.exit
	{
		call hexkl_dma_ring_next_idx
		r22 = asl(r5,#11)
	}
	.falign
// %bb.6:                               // %moe_dma_row_size.exit
	{
		call __hexagon_udivsi3
		r23 = r0
		r1:0 = combine(r19,r22)
	}
	.falign
// %bb.7:                               // %moe_dma_row_size.exit
	{
		r16 += mpyi(r17,r18)
		r5:4 = combine(r0,r19)
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r16
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.8:                               // %moe_dma_row_size.exit
	{
		r0 = r23
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	hexkl_moe_push_act_block, .Lfunc_end7-hexkl_moe_push_act_block
                                        // -- End function
	.globl	hexkl_moe_pack_bg_worker        // -- Begin function hexkl_moe_pack_bg_worker
	.falign
	.type	hexkl_moe_pack_bg_worker,@function
hexkl_moe_pack_bg_worker:               // @hexkl_moe_pack_bg_worker
// %bb.0:                               // %entry
	{
		r3 = r1
		allocframe(#8)
	}
	{
		r4 = memw(r2+#28)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.1:                               // %land.lhs.true
	{
		r4 = memb(r4+r1<<#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.2:                               // %cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB8_3:                                // %if.end
	{
		r4 = asl(r3,#4)
		r5 = #16
		r0 = memw(r2+#4)
		if (cmp.eq(r0.new,#0)) jump:nt .LBB8_5
	}
// %bb.4:                               // %if.then4
	{
		r6 = r2
		r1 = memw(r2+#8)
	}
	{
		r3 = addasl(r5,r3,#4)
		r2 = r4
		r4 = memw(r6+#24)
		r5 = memw(r6+#20)
	}
	{
		jump hvx_gather_u8_ah_rows
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB8_5:                                // %if.end7
	{
		r6 = asl(r3,#4)
		r7 = #16
		r1 = memw(r2+#8)
		r8 = memw(r2+#16)
	}
	{
		r3 = addasl(r7,r3,#4)
		r0 = memw(r2+#0)
		r4 = memw(r2+#24)
	}
	{
		r5 = memw(r2+#12)
		r2 = memw(r2+#20)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r2 = r6
		memw(r29+#4) = r2
		memw(r29+#0) = r8
	}
	.falign
// %bb.6:                               // %if.end7
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	hexkl_moe_pack_bg_worker, .Lfunc_end8-hexkl_moe_pack_bg_worker
                                        // -- End function
	.globl	hexkl_moe_dma_copy              // -- Begin function hexkl_moe_dma_copy
	.falign
	.type	hexkl_moe_dma_copy,@function
hexkl_moe_dma_copy:                     // @hexkl_moe_dma_copy
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r2,#0)
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r19:18
		memd(r29+#32) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r24 = ##1048576
		memd(r29+#24) = r23:22
		memd(r29+#16) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r27 = ##4095
		if (p0) jump:nt .LBB9_33
		memd(r29+#8) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:
	{
		r17:16 = combine(r4,r2)
		r19:18 = combine(r1,r3)
		r23 = #0
		r20 = r0
	}
	{
		r25 = #16383
		r26 = #8191
	}
	.falign
.LBB9_2:                                // %while.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r16,r23)
	}
	{
		r21 = minu(r2,r24)
	}
	{
		p1 = bitsclr(r21,r25)
		if (!p1.new) r22 = ##8192
		if (p1.new) jump:nt .LBB9_16
	}
// %bb.3:                               // %while.body.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r26)
		if (!p0.new) r2 = #2047
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.4:                               // %while.body.1.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r27)
		if (!p1.new) r22 = ##2048
		if (p1.new) jump:nt .LBB9_18
	}
// %bb.5:                               // %while.body.2.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #1023
		if (!p0.new) r22 = #1024
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.6:                               // %while.body.3.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #511
		if (!p1.new) r22 = #512
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.7:                               // %while.body.4.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #255
		if (!p0.new) r22 = #256
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.8:                               // %while.body.5.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #127
		if (!p1.new) r22 = #128
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.9:                               // %while.body.6.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r22 = #64
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.10:                              // %while.body.7.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#63)
		if (!p1.new) r22 = #32
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.11:                              // %while.body.8.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#31)
		if (!p0.new) r22 = #16
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.12:                              // %while.body.9.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#15)
		if (!p1.new) r22 = #8
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.13:                              // %while.body.10.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#7)
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.14:                              // %while.body.11.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = tstbit(r21,#0)
		p1 = bitsclr(r21,#3)
		if (p1.new) r22 = #4
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.15:                              // %while.body.12.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = mux(p0,#1,#2)
		jump .LBB9_29
	}
	.falign
.LBB9_16:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #16384
		jump .LBB9_29
	}
	.falign
.LBB9_18:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #4096
	}
	.falign
.LBB9_29:                               // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r5:4 = combine(r0,r22)
		r0 = add(r20,r23)
		r1 = add(r19,r23)
		r3:2 = combine(r22,r22)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r18
		memw(r29+#4) = r17
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r23 = add(r21,r23)
		if (cmp.gtu(r16,r23.new)) jump:t .LBB9_2
	}
	.falign
.LBB9_33:                               // %moe_dma_copy.exit
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#16)
		r27:26 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end9:
	.size	hexkl_moe_dma_copy, .Lfunc_end9-hexkl_moe_dma_copy
                                        // -- End function
	.falign
	.type	moe_dma_copy,@function          // -- Begin function moe_dma_copy
moe_dma_copy:                           // @moe_dma_copy
// %bb.0:                               // %entry
	{
		r6 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17 = r2
		p0 = cmp.eq(r2,#0)
		memd(r29+#32) = r27:26
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gt(r5,#-1)
		r27 = #0
		memd(r29+#56) = r21:20
		memd(r29+#48) = r23:22
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r25:24
		memw(r29+#20) = r5
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r6+##hexkl_probe_on@GOT)
	}
	{
		if (p0) r25 = #0
		r2 = memw(r2+#0)
	}
	{
		p2 = cmp.eq(r2,#0)
	}
	{
		p1 = and(p1,!p2)
	}
	{
		r2 = p1
		if (p0) jump:nt .LBB10_38
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.1:
	{
		r19:18 = combine(r3,r4)
		r21:20 = combine(r0,r1)
		r16 = #16383
		r22 = #0
	}
	.falign
.LBB10_2:                               // %while.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r17,r27)
		r3 = ##1048576
	}
	{
		r23 = minu(r2,r3)
		r2 = #8191
	}
	{
		p0 = bitsclr(r23,r16)
		if (!p0.new) r24 = ##8192
		if (p0.new) jump:nt .LBB10_16
	}
// %bb.3:                               // %while.body.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		if (!p1.new) r2 = ##4095
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.4:                               // %while.body.1.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		if (!p2.new) r2 = #2047
		if (p2.new) jump:nt .LBB10_18
	}
// %bb.5:                               // %while.body.2.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #2048
		if (!p0.new) r2 = #1023
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.6:                               // %while.body.3.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #1024
		if (!p1.new) r2 = #511
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.7:                               // %while.body.4.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		r24 = #512
		if (!p2.new) r2 = #255
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.8:                               // %while.body.5.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #256
		if (!p0.new) r2 = #127
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.9:                               // %while.body.6.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #128
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.10:                              // %while.body.7.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,#63)
		r24 = #64
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.11:                              // %while.body.8.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#31)
		r24 = #32
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.12:                              // %while.body.9.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,#15)
		r24 = #16
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.13:                              // %while.body.10.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = tstbit(r23,#0)
		p2 = bitsclr(r23,#7)
		if (p2.new) r24 = #8
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.14:                              // %while.body.11.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#3)
		if (p0.new) r24 = #4
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.15:                              // %while.body.12.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = mux(p1,#1,#2)
		jump .LBB10_29
	}
	.falign
.LBB10_16:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #16384
		jump .LBB10_29
	}
	.falign
.LBB10_18:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #4096
	}
	.falign
.LBB10_29:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call __hexagon_udivsi3
		r25 = r0
		r1:0 = combine(r24,r23)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r26 = r0
		r0 = add(r21,r27)
		r1 = add(r20,r27)
		r3:2 = combine(r24,r24)
	}
	{
		call hexkl_dma_ring_push2d
		r5:4 = combine(r26,r24)
		memw(r29+#0) = r19
		memw(r29+#4) = r18
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB10_34
	}
// %bb.33:                              // %if.then
                                        //   in Loop: Header=BB10_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = combine(r22,#0)
		r3:2 = combine(#4,r25)
		memw(r29+#0) = r24
		memw(r29+#4) = r26
	}
	{
		call hexkl_dma_trace_push
		r22 = add(r22,#1)
		memw(r29+#8) = r24
	}
	.falign
.LBB10_34:                              // %if.end
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r27 = add(r23,r27)
		if (cmp.gtu(r17,r27.new)) jump:t .LBB10_2
	}
// %bb.35:                              // %while.end
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB10_39
	}
	.falign
.LBB10_36:                              // %if.then14
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r25
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.37:                              // %if.then14
	{
		call hexkl_dma_ring_drain
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_trace_wait_end
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB10_38:
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB10_36
	}
	.falign
.LBB10_39:                              // %if.end12
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end10:
	.size	moe_dma_copy, .Lfunc_end10-moe_dma_copy
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layout        // -- Begin function hexkl_mm_u8i4_moe_layout
	.falign
	.type	hexkl_mm_u8i4_moe_layout,@function
hexkl_mm_u8i4_moe_layout:               // @hexkl_mm_u8i4_moe_layout
// %bb.0:                               // %entry
	{
		r8 = r1
		r6 = ##-2147449855
		r7 = r2
	}
	{
		r7 |= or(r1,r0)
		r0 = add(r6,#-32755)
		r5 = r0
		allocframe(#40)
	}
	{
		r7 = and(r7,#31)
		memd(r29+#32) = r17:16
		memd(r29+#24) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r8 = or(r7,and(r8,#15))
		memd(r29+#16) = r21:20
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r8,#0)
		if (!p0.new) jump:nt .LBB11_11
		memd(r29+#0) = r25:24
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.3:                               // %entry
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.4:                               // %entry
	{
		r5 = extractu(r5,#23,#5)
		r7 = extractu(r1,#27,#4)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.5:                               // %if.end16
	{
		r8 = extractu(r5,#21,#0)
		r12 = extractu(r7,#23,#1)
		r0 = add(r6,#-32767)
	}
	{
		r5 = mpyi(r5,r7)
		r9 = lsr(r2,#5)
	}
	{
		r5 = asl(r5,#9)
		r17 = asl(r8,#11)
	}
	{
		r19 = add(r5,add(r17,##1536))
		r5 = mpyi(r12,r9)
	}
	{
		r19 = insert(r19,#9,#2)
		r5 = asl(r5,#9)
	}
	{
		r18 = add(r5,add(r19,##2047))
		r5 = extractu(r7,#20,#1)
	}
	{
		r18 += asl(r1,#8)
		r2 = add(##2047,asl(r2,#8))
		r20 = r18
	}
	{
		r20 = insert(r19,#11,#0)
		r18 += asl(r5,#12)
		r21 = r18
	}
	{
		r21 = insert(r20,#11,#0)
		r22 = r18
	}
	{
		r22 = insert(r21,#12,#0)
	}
	{
		r2 = insert(r22,#11,#0)
	}
	{
		r2 = add(r22,r2)
	}
	{
		r5 = sub(r3,r2)
		p1 = cmp.gtu(r3,r2)
	}
	{
		r2 = lsr(r5,#14)
	}
	{
		if (!p1) r2 = #0
	}
	{
		r2 = minu(r7,r2)
		if (!cmp.gtu(r2.new,#1)) jump:t .LBB11_11
	}
// %bb.6:                               // %cleanup.cont
	{
		r5 = #32
	}
	{
		r2 = minu(r2,r5)
	}
	{
		r23 = and(r2,#62)
	}
	{
		r18 += asl(r23,#14)
		r16 = asl(r23,#13)
	}
	{
		r18 = insert(r16,#11,#0)
		if (!cmp.gtu(r3,r18.new)) jump:t .LBB11_11
	}
// %bb.7:                               // %cond.end95
	{
		r2 = sub(r3,r18)
		r25:24 = combine(r4,r0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r2)
	}
	.falign
// %bb.8:                               // %cond.end95
	{
		r3:2 = combine(r25,r0)
		r4 = #4
		p0 = cmp.gtu(r0,#3); if (p0.new) jump:t .LBB11_10
	}
// %bb.9:
	{
		r0 = r24
		r4 = r2
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
	.falign
.LBB11_10:                              // %cleanup.cont113
	{
		r18 += mpyi(r4,r16)
		r0 = #0
		memw(r3+#28) = r18
		memw(r3+#0) = #0
	}
	{
		memw(r3+#4) = r17
		memw(r3+#8) = r19
	}
	{
		memw(r3+#12) = r20
		memw(r3+#16) = r21
	}
	{
		memw(r3+#20) = r22
		memw(r3+#24) = r23
	}
	{
		memw(r3+#32) = r4
		memw(r3+#36) = r18
	}
	.falign
.LBB11_11:                              // %return
	{
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#0)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end11:
	.size	hexkl_mm_u8i4_moe_layout, .Lfunc_end11-hexkl_mm_u8i4_moe_layout
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layer_run     // -- Begin function hexkl_mm_u8i4_moe_layer_run
	.falign
	.type	hexkl_mm_u8i4_moe_layer_run,@function
hexkl_mm_u8i4_moe_layer_run:            // @hexkl_mm_u8i4_moe_layer_run
// %bb.0:                               // %entry
	{
		allocframe(r29,##17152):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = memw(r30+#52)
		memd(r30+#-32) = r23:22
	}
	{
		r20 = r4
		p0 = cmp.eq(r22,#0)
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r4 = ##-2147449856
		r18 = memw(r30+#16)
		memd(r30+#-8) = r17:16
	}
	{
		if (p0) r15 = #0
		if (p0) jump:nt .LBB12_19
		memd(r30+#-40) = r25:24
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r9:8 = combine(#0,#1)
		r13:12 = combine(#0,#0)
		r7:6 = memd(r22+#24)
		memw(r22+#48) = #0
	}
	{
		r7:6 = add(r7:6,r9:8)
		p3 = cmp.eq(r18,#0)
		r15 = memw(r22+#56)
		memd(r22+#40) = r13:12
	}
	{
		r17 = add(r4,#-32754)
		memd(r22+#56) = r13:12
		memd(r22+#24) = r7:6
	}
	{
		if (p3) jump:nt .LBB12_20
	}
	.falign
.LBB12_2:                               // %if.end
	{
		r6 = r17
		p2 = cmp.eq(r20,#0)
		if (p2.new) jump:nt .LBB12_838
	}
// %bb.3:                               // %if.end
	{
		r6 = r17
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB12_838
	}
// %bb.4:                               // %if.end
	{
		r6 = r17
		p3 = cmp.eq(r1,#0)
		if (p3.new) jump:nt .LBB12_838
	}
// %bb.5:                               // %if.end
	{
		r6 = r17
		r10 = memw(r30+#20)
		if (cmp.eq(r10.new,#0)) jump:nt ##.LBB12_158
	}
// %bb.6:                               // %if.end
	{
		r6 = r17
		r11 = memw(r30+#24)
		if (cmp.eq(r11.new,#0)) jump:nt ##.LBB12_102
	}
// %bb.7:                               // %if.end
	{
		r6 = r17
		r8 = memw(r30+#28)
		if (cmp.eq(r8.new,#0)) jump:nt ##.LBB12_100
	}
// %bb.8:                               // %if.end
	{
		r6 = r17
		r19 = memw(r30+#32)
		if (cmp.eq(r19.new,#0)) jump:nt ##.LBB12_95
	}
// %bb.9:                               // %if.end
	{
		r6 = r17
		r9 = memw(r30+#36)
		if (cmp.eq(r9.new,#0)) jump:nt ##.LBB12_86
	}
// %bb.10:                              // %if.end
	{
		r6 = r17
		r14 = memw(r30+#40)
		if (cmp.eq(r14.new,#0)) jump:nt ##.LBB12_85
	}
// %bb.11:                              // %if.end
	{
		r6 = memw(r30+#44)
		if (cmp.eq(r6.new,#0)) jump:nt ##.LBB12_84
	}
// %bb.12:                              // %if.end
	{
		if (p0) r6 = add(r17,#0)
		if (p0) jump:nt .LBB12_838
		if (!p0) r13 = memw(r30+#56)
		if (!p0) r7 = memw(r30+#12)
	}
// %bb.13:                              // %if.end26
	{
		r12 = add(pc,##g_moe_src_bypass@PCREL)
		p0 = cmp.eq(r7,#0)
		if (p0.new) r6 = add(r17,#0)
	}
	{
		r4 = extractu(r13,#1,#18)
		if (p0) jump:nt .LBB12_838
		memw(r12+#0) = r4.new
	}
// %bb.14:                              // %if.end26
	{
		if (p1.new) r6 = add(r17,#0)
		if (!p1.new) r12 = add(r7,#0)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB12_838
	}
// %bb.15:                              // %if.end26
	{
		r28 = memw(r30+#8)
		if (cmp.eq(r28.new,#0)) jump:nt ##.LBB12_82
	}
// %bb.16:                              // %if.end26
	{
		r12 |= or(r28,r5)
		r4 = r28
	}
	{
		r12 = and(r12,#31)
	}
	{
		r4 = or(r12,and(r4,#15))
		if (!cmp.eq(r4.new,#0)) jump:nt .LBB12_21
	}
// %bb.17:                              // %if.end16.i
	{
		r13 = lsr(r28,#5)
		r12 = lsr(r7,#5)
		memw(r29+#236) = r13
		memw(r29+#252) = r14
	}                                       // 4-byte Folded Spill
	{
		r21 = extractu(r13,#23,#0)
		r14 = lsr(r5,#5)
		r16 = #1536
		memw(r29+#248) = r15
	}                                       // 4-byte Folded Spill
	{
		r4 = extractu(r14,#23,#0)
		r15 = extractu(r28,#27,#4)
	}
	{
		r21 = mpyi(r21,r12)
		r4 = asl(r4,#9)
	}
	{
		r24 = mpyi(r4,r15)
		r27 = asl(r21,#9)
		memw(r29+#244) = r24.new
	}                                       // 4-byte Folded Spill
	{
		r23 = r27
	}
	{
		r23 = insert(r4,#30,#2)
		r4 = extractu(r13,#20,#0)
		memw(r29+#1688) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r24 += add(r23,r16)
	}
	{
		r24 = insert(r24,#9,#2)
	}
	{
		r16 = add(r27,add(r24,##2047))
	}
	{
		r16 += asl(r28,#8)
		r26 = r16
	}
	{
		r26 = insert(r24,#11,#0)
		r16 += asl(r4,#12)
		r21 = r16
		r4 = r7
	}
	{
		r21 = insert(r26,#11,#0)
		r4 = add(##2047,asl(r4,#8))
		r25 = r16
	}
	{
		r25 = insert(r21,#12,#0)
		r26 = minu(r2,r3)
		memw(r29+#256) = r26
	}                                       // 4-byte Folded Spill
	{
		r4 = insert(r25,#11,#0)
		memw(r29+#240) = r25
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r25,r4)
		r25 = ##-2147449856
	}
	{
		r4 = sub(r26,r2)
		p0 = cmp.gtu(r26,r2)
		r25 = add(r25,#-32766)
	}
	{
		r2 = lsr(r4,#14)
	}
	{
		if (!p0) r2 = #0
	}
	{
		r2 = minu(r15,r2)
		if (cmp.gtu(r2.new,#1)) jump:t .LBB12_22
	}
// %bb.18:
	{
		r6 = r25
		jump .LBB12_838
	}
	.falign
.LBB12_19:
	{
		r4 = ##-2147449856
		p3 = cmp.eq(r18,#0)
	}
	{
		r17 = add(r4,#-32754)
		if (!p3) jump:nt .LBB12_2
	}
	.falign
.LBB12_20:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_21:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_22:                              // %cleanup.cont.i
	{
		r4 = #32
		memw(r29+#268) = r21
	}                                       // 4-byte Folded Spill
	{
		r4 = minu(r2,r4)
	}
	{
		r2 = and(r4,#62)
	}
	{
		r16 += asl(r2,#14)
		r21 = asl(r2,#13)
	}
	{
		r16 = insert(r21,#11,#0)
		if (!cmp.gtu(r26,r16.new)) jump:t ##.LBB12_80
	}
// %bb.23:                              // %cond.end95.i
	{
		r2 = sub(r26,r16)
		r16 = r0
		memw(r29+#304) = r2
		memw(r29+#292) = r16
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(r21,r2)
		r20 = r5
		memw(r29+#296) = r1
		memd(r29+#1696) = r21:20
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#312) = r4
		memw(r29+#324) = r24
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#336) = r23
		memw(r29+#340) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#280) = r19
		memw(r29+#284) = r11
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#288) = r10
		memw(r29+#272) = r28
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#328) = r15
		memw(r29+#320) = r14
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#316) = r13
		memw(r29+#308) = r12
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#344) = r9
		memw(r29+#300) = r8
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#276) = r7
		memw(r29+#332) = r6
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#260) = r16
		memw(r29+#264) = r20
	}                                       // 4-byte Folded Spill
	.falign
// %bb.24:                              // %cond.end95.i
	{
		r1 = r16
		p2 = cmp.gtu(r0,#3)
		r4 = #4
		r2 = r20
	}
	{
		if (!p2) r4 = add(r0,#0)
		if (!p2) r6 = add(r25,#0)
		if (p2) jump:nt .LBB12_26
	}
// %bb.25:
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_838
	}
	.falign
.LBB12_26:                              // %for.body.lr.ph
	{
		r7 = #8192
		r19 = #0
		r28 = memw(r29+#272)
		r8 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r8 += mpyi(r4,r21)
		r16 = asl(r28,#1)
		r3 = memw(r29+#236)
		r15 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r6 = maxu(r16,r28)
		r0 = extractu(r3,#1,#19)
		r3 = memw(r29+#288)
		memw(r29+#348) = r4
	}                                       // 4-byte Folded Reload
	{
		r6 = maxu(r6,r15)
		r5 = or(r16,r15)
		r4 = memw(r29+#284)
		r11:10 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r6,r7)
		r23 = #0
		r14 = memw(r30+#48)
		r7 = memw(r29+#280)
	}
	{
		r21:20 = combine(#0,#0)
		r5 = and(r5,#127)
		r25:24 = combine(#0,#0)
		r11 = #8192
	}
	{
		loop0(.LBB12_27,r18)
		memw(r29+#352) = r8
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_27:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
		r8 = r19
		r6 = memw(r7+#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB12_43
	}
// %bb.28:                              // %if.end46
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r9 = memw(r3+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt ##.LBB12_87
	}
// %bb.29:                              // %lor.lhs.false58
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r13 = #4095
	}
	{
		r13 = memw(r4+#0)
		if (cmp.gtu(r13.new,r13)) jump:nt ##.LBB12_88
	}
// %bb.30:                              // %if.end63
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r1+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_89
	}
// %bb.31:                              // %lor.lhs.false70
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r12 = +mpyi(r13,#96)
	}
	{
		r12 = memw(r1+r12<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_90
	}
// %bb.32:                              // %lor.lhs.false73
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r9 = add(r1,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r2)) jump:nt ##.LBB12_91
	}
// %bb.33:                              // %lor.lhs.false77
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r12 = memw(r9+#32)
		if (!cmp.eq(r12.new,r16)) jump:nt ##.LBB12_92
	}
// %bb.34:                              // %lor.lhs.false80
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r12 = r1
	}
	{
		r12 += mpyi(r13,#96)
	}
	{
		r13 = memw(r12+#28)
		if (!cmp.eq(r13.new,r28)) jump:nt ##.LBB12_93
	}
// %bb.35:                              // %lor.lhs.false84
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r13 = memw(r12+#32)
		if (!cmp.eq(r13.new,r15)) jump:nt ##.LBB12_94
	}
// %bb.36:                              // %if.end89
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r13 = memw(r9+#44)
	}
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_44
		r13 = memw(r12+#44)
	}
// %bb.37:                              // %lor.lhs.false97
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) r6 = add(r17,#0)
		if (p3.new) jump:nt .LBB12_838
	}
// %bb.38:                              // %lor.lhs.false100
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p3 = cmp.eq(r5,#0)
		r13 = memw(r9+#84)
		if (!cmp.eq(r13.new,#2)) jump:nt ##.LBB12_97
	}
// %bb.39:                              // %lor.lhs.false103
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p0 = cmp.gtu(r2,r11)
		r13 = memw(r12+#84)
	}
	{
		p1 = cmp.eq(r13,#2)
	}
	{
		p1 = not(p1)
	}
	{
		p3 = or(p1,!p3)
	}
	{
		p1 = or(p2,or(p0,p3))
		if (p1.new) r6 = add(r17,#0)
		if (p1.new) jump:nt .LBB12_838
	}
// %bb.40:                              // %if.end132
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p3 = and(p3,!p3)
		r13 = memw(r9+#48)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_42
	}
// %bb.41:                              // %land.rhs
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r13 = memw(r12+#48)
	}
	{
		p3 = cmp.eq(r13,#0)
	}
	{
		p3 = not(p3)
	}
	.falign
.LBB12_42:                              // %land.end
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r24 = add(r24,#1)
		if (p3) r25 = add(r25,#1)
		jump .LBB12_45
	}
	.falign
.LBB12_43:                              //   in Loop: Header=BB12_27 Depth=1
	{
		r19 = r8
		jump .LBB12_48
	}
	.falign
.LBB12_44:                              // %lor.lhs.false91
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (!p3.new) r6 = add(r17,#0)
		if (!p3.new) jump:nt .LBB12_838
	}
	.falign
.LBB12_45:                              // %if.end137
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		p3 = or(p3,!p3)
		r9 = memw(r9+#20)
		if (!cmp.eq(r9.new,#0)) jump:t .LBB12_47
	}
// %bb.46:                              // %lor.rhs
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r9 = memw(r12+#20)
	}
	{
		p0 = cmp.eq(r9,#0)
	}
	{
		p3 = not(p0)
	}
	.falign
.LBB12_47:                              // %cleanup
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r20 = maxu(r6,r20)
		r23 = add(r23,#1)
		if (p3) r21 = add(r21,#1)
		r19 = add(r6,r8)
	}
	.falign
.LBB12_48:                              // %for.inc
                                        //   in Loop: Header=BB12_27 Depth=1
	{
		r4 = add(r4,#4)
		r7 = add(r7,#4)
		r3 = add(r3,#4)
	} :endloop0
// %bb.49:                              // %for.cond150.preheader
	{
		r3 = add(r8,r6)
		p1 = cmp.eq(r19,#0); if (p1.new) jump:nt .LBB12_53
	}
// %bb.50:                              // %for.body154.preheader
	{
		r4 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_51:                              // %for.body154
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r4+#0)
		if (!cmp.gtu(r10,r5.new)) jump:nt ##.LBB12_99
	}
// %bb.52:                              // %for.cond150
                                        //   in Loop: Header=BB12_51 Depth=1
	{
		r4 = add(r4,#4)
		r3 = add(r3,#-1)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_51
	}
	.falign
.LBB12_53:                              // %for.end164
	{
		r3 = #2048
		p1 = cmp.eq(r24,#0)
		memw(r29+#1712) = r25
		memw(r29+#364) = r23
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		p0 = cmp.eq(r2,r3)
		memw(r29+#356) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p0
		memw(r29+#376) = r0
		memw(r29+#380) = r14
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB12_62
		memw(r29+#368) = r24
		memw(r29+#372) = r2
	}                                       // 4-byte Folded Spill
// %bb.54:                              // %for.end164
	{
		r2 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r3 = #1536
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB12_62
	}
// %bb.55:                              // %for.end164
	{
		r2 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r3 = #2048
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB12_62
	}
// %bb.56:                              // %for.end164
	{
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) r17 = add(r18,#0)
		if (p3.new) jump:nt .LBB12_62
	}
// %bb.57:
	{
		r23 = memw(r29+#284)
		r25 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_58:                              // %for.body181
                                        // =>This Inner Loop Header: Depth=1
	{
		r0 = r1
		r2 = memw(r24+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_61
	}
// %bb.59:                              // %if.end186
                                        //   in Loop: Header=BB12_58 Depth=1
	{
		r2 = memw(r25+#0)
		r3 = memw(r23+#0)
	}
	{
		r0 += mpyi(r2,#96)
		r1 += mpyi(r3,#96)
	}
	{
		call hexkl_weight_tl2_refresh_pair
	}
	.falign
// %bb.60:                              // %if.end186
                                        //   in Loop: Header=BB12_58 Depth=1
	{
		r6 = r0
		p3 = cmp.eq(r0,#0)
		if (!p3.new) jump:nt .LBB12_838
		r1 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_61:                              // %for.inc198
                                        //   in Loop: Header=BB12_58 Depth=1
	{
		r24 = add(r24,#4)
		r23 = add(r23,#4)
		r25 = add(r25,#4)
	}
	{
		r17 = add(r17,#-1)
		if (!cmp.eq(r17.new,#0)) jump:t .LBB12_58
	}
	.falign
.LBB12_62:                              // %if.end203
	{
		r17 = r1
		r0 = r1
		r23 = memw(r29+#284)
		r25 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r1 = r18
		r3:2 = combine(r23,r25)
		r24 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		call moe_all_4bit
		r4 = r24
	}
	.falign
// %bb.63:                              // %if.end203
	{
		r1:0 = combine(r18,r17)
		r3:2 = combine(r23,r25)
		r4 = r24
		memw(r29+#388) = r0
	}                                       // 4-byte Folded Spill
	{
		call moe_all_2bit
	}
	.falign
// %bb.64:                              // %if.end203
	{
		r3:2 = combine(#0,#0)
		r23 = r0
		r0 = memw(r29+#296)
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		memd(r29+#1808) = r3:2
		memd(r29+#1800) = r3:2
	}
	{
		memd(r29+#1792) = r3:2
		memd(r29+#1784) = r3:2
	}
	{
		memd(r29+#1776) = r3:2
		memd(r29+#1768) = r3:2
	}
	{
		call hexkl_acc_layout_get
		memd(r29+#1760) = r3:2
		memd(r29+#1752) = r3:2
	}
	.falign
// %bb.65:                              // %if.end203
	{
		r2 = memw(r0+#4)
	}
	{
		if (!p0.new) r17 = add(r0,#0)
		r2 = ##-2147449856
		p0 = cmp.eq(r2,#0)
	}
	{
		r6 = add(r2,#-32748)
		if (p0) jump:nt .LBB12_838
	}
// %bb.66:                              // %if.end214
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r29+#396) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p3 = and(p3,!p3)
		r5 = #0
		r4 = memw(r0+#12)
		r1:0 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r3 = p3
		r1 = #0
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		p2 = cmp.gtu(r0,#4)
		p3 = cmp.eq(r0,#1)
		memw(r29+#360) = r3
		memd(r29+#1704) = r1:0
	}                                       // 4-byte Folded Spill
	{
		r3 = p3
		r4 = memw(r29+#364)
		memd(r2+#136) = r5:4
	}                                       // 4-byte Folded Reload
	{
		if (p2) jump:nt .LBB12_166
		if (!p2) r2 = memw(r29+#236)
		memw(r29+#384) = r3
	}                                       // 4-byte Folded Reload
// %bb.67:                              // %if.end214
	{
		r3 = memw(r29+#260)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,#1)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_167
	}
// %bb.68:                              // %if.end214
	{
		p3 = cmp.gtu(r20,#4)
		if (p3.new) jump:nt .LBB12_72
		r24 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
// %bb.69:                              // %if.end214
	{
		r2 = add(r4,#-1)
		if (cmp.gtu(r2.new,#15)) jump:nt .LBB12_72
	}
// %bb.70:                              // %if.end214
	{
		r2 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = or(r2,r23)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_72
	}
// %bb.71:                              // %land.rhs238
	{
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
	}
	{
		p3 = or(p0,p2)
	}
	{
		r2 = p3
		memw(r29+#360) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_72:                              // %land.end245
	{
		r2 = memw(r29+#360)
		memw(r29+#388) = r23
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r20 = #0
		if (p0.new) jump:nt .LBB12_106
		memw(r29+#392) = r6
	}                                       // 4-byte Folded Spill
// %bb.73:                              // %land.end245
	{
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) r20 = #0
		if (!p3.new) r23 = add(r17,#0)
		if (p3.new) jump:nt .LBB12_106
	}
// %bb.74:                              // %if.then250
	{
		call hvx_tl2_weight_bytes
		r1 = r16
	}
	.falign
// %bb.75:                              // %if.then250
	{
		r17 = r0
		r20 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		call hvx_tl2_weight_bytes
		r1:0 = combine(r20,r24)
	}
	.falign
// %bb.76:                              // %if.then250
	{
		r4 = add(r0,r17)
		r5 = memw(r29+#352)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r26,r5)
	}
	{
		p3 = cmp.gtu(r17,r3)
		p2 = cmp.gtu(r4,r3)
		r4 = add(r2,r5)
		if (!p2.new) jump:t .LBB12_105
	}
// %bb.77:                              // %if.else
	{
		if (p3) r4 = #0
		r17 = r23
		r2 = memw(r29+#376)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r2 = #1536
		r6 = memw(r29+#392)
		r3 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r24,r2)
		if (!p1) r4 = #0
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = #2048
		if (!p2.new) r4 = #0
	}
	{
		p2 = cmp.eq(r20,r2)
		if (!p0) r4 = #0
	}
	{
		if (!p2) r4 = #0
	}
	{
		r20 = r4 ; jump .LBB12_106
		r4 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_80:
	{
		r6 = r25
		jump .LBB12_838
	}
	.falign
.LBB12_82:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_84:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_85:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_86:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_87:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_88:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_89:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_90:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_91:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_92:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_93:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_94:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_95:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_97:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_99:
	{
		r6 = r17 ; jump .LBB12_838
	}
	.falign
.LBB12_100:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_102:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_105:                             // %if.then257
	{
		r17 += add(r2,r5)
		r20 = r4
		r3 = memw(r29+#260)
		r6 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		r1 = r17
		r17 = r23
	}
	{
		r0 = memw(r29+#264)
		memd(r29+#1704) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_106:                             // %if.end281
	{
		p3 = cmp.eq(r21,#0)
		r21 = #0
		r24 = #8192
		r2 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
	}
	{
		p1 = and(p3,!p2)
		if (!p1.new) r23 = #0
		if (!p1.new) jump:nt .LBB12_206
	}
// %bb.107:                             // %if.end281
	{
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r23 = #0
		if (p0.new) jump:nt .LBB12_206
	}
// %bb.108:                             // %if.end281
	{
		r2 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		if (!p0.new) r23 = #0
		if (p0.new) r8 = #0
		p0 = cmp.eq(r2,r4); if (!p0.new) jump:nt .LBB12_206
	}
// %bb.109:
	{
		r5:4 = combine(#1,#0)
		r7 = memw(r29+#284)
		r15 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB12_110,r18)
		r9 = memw(r29+#280)
		r23 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_110:                             // Block address taken
                                        // %for.body296
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r9+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_156
	}
// %bb.111:                             // %if.end300
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = r3
		r12 = memw(r25+#0)
	}
	{
		r2 += mpyi(r12,#96)
	}
	{
		r12 = memb(r2+#88)
	}
	{
		r13 = abs(r12)
		r12 = #0
	}
	{
		p1 = cmp.eq(r13,#0)
		if (p1.new) jump:nt .LBB12_114
	}
// %bb.112:                             // %if.end300
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r13,#7)
		if (p3.new) jump:nt .LBB12_114
	}
// %bb.113:                             // %if.end300
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r13,#1)
		if (!p0.new) jump:t .LBB12_133
	}
	.falign
.LBB12_114:                             // %for.inc.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_119
	}
// %bb.115:                             // %for.inc.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r14,#7)
		if (p3.new) jump:nt .LBB12_117
	}
// %bb.116:                             // %for.inc.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r14,#1)
		if (!p0.new) jump:t .LBB12_133
	}
	.falign
.LBB12_117:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		if (p1) jump:nt .LBB12_120
	}
// %bb.118:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r13,r14)
		if (!p1.new) jump:t .LBB12_133
	}
	{
		jump .LBB12_120
	}
	.falign
.LBB12_119:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_120:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_125
	}
// %bb.121:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r13,#7)
		if (p3.new) jump:nt .LBB12_123
	}
// %bb.122:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r13,#1)
		if (!p0.new) jump:t .LBB12_133
	}
	.falign
.LBB12_123:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r14,#0)
		if (p1.new) jump:nt .LBB12_126
	}
// %bb.124:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p2 = cmp.eq(r14,r13)
		if (!p2.new) jump:t .LBB12_133
	}
	{
		jump .LBB12_126
	}
	.falign
.LBB12_125:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_126:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_131
	}
// %bb.127:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB12_129
	}
// %bb.128:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB12_133
	}
	.falign
.LBB12_129:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p2 = cmp.eq(r13,#0)
		if (p2.new) jump:nt .LBB12_132
	}
// %bb.130:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r13,r2)
		if (!p3.new) jump:t .LBB12_133
	}
	{
		jump .LBB12_132
	}
	.falign
.LBB12_131:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = r13
	}
	.falign
.LBB12_132:                             // %for.inc.3.i
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r12 = maxu(r2,r5)
	}
	.falign
.LBB12_133:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = r3
		r21 = #8
		r13 = memw(r7+#0)
	}
	{
		r2 += mpyi(r13,#96)
	}
	{
		r13 = memb(r2+#88)
	}
	{
		r13 = abs(r13)
	}
	{
		p2 = cmp.eq(r13,#0)
		if (p2.new) jump:nt .LBB12_136
	}
// %bb.134:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_136
	}
// %bb.135:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r13,#1)
		if (!p1.new) r2 = #8
		if (!p1.new) jump:nt .LBB12_172
	}
	.falign
.LBB12_136:                             // %for.inc.i5101
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_141
	}
// %bb.137:                             // %for.inc.i5101
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r14,#7)
		if (p0.new) jump:nt .LBB12_139
	}
// %bb.138:                             // %for.inc.i5101
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r14,#1)
		if (!p1.new) r2 = #8
		if (!p1.new) jump:nt .LBB12_172
	}
	.falign
.LBB12_139:                             // %lor.lhs.false.1.i5104
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		if (p2) jump:nt .LBB12_142
	}
// %bb.140:                             // %lor.lhs.false.1.i5104
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p2 = cmp.eq(r13,r14)
		if (p2.new) jump:t .LBB12_142
	}
	{
		jump .LBB12_163
	}
	.falign
.LBB12_141:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_142:                             // %for.inc.1.i5109
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_147
	}
// %bb.143:                             // %for.inc.1.i5109
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_145
	}
// %bb.144:                             // %for.inc.1.i5109
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r13,#1)
		if (!p1.new) r2 = #8
		if (!p1.new) jump:nt .LBB12_172
	}
	.falign
.LBB12_145:                             // %lor.lhs.false.2.i5112
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p2 = cmp.eq(r14,#0)
		if (p2.new) jump:nt .LBB12_148
	}
// %bb.146:                             // %lor.lhs.false.2.i5112
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r14,r13)
		if (p3.new) jump:t .LBB12_148
	}
	{
		jump .LBB12_164
	}
	.falign
.LBB12_147:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_148:                             // %for.inc.2.i5117
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r14 = abs(r2)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_153
	}
// %bb.149:                             // %for.inc.2.i5117
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p1 = cmp.eq(r14,#7)
		if (p1.new) jump:nt .LBB12_151
	}
// %bb.150:                             // %for.inc.2.i5117
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p2 = cmp.eq(r14,#1)
		if (!p2.new) r2 = #8
		if (!p2.new) jump:nt .LBB12_172
	}
	.falign
.LBB12_151:                             // %lor.lhs.false.3.i5120
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_154
	}
// %bb.152:                             // %lor.lhs.false.3.i5120
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		p0 = cmp.eq(r13,r14)
		if (p0.new) jump:t .LBB12_154
	}
	{
		jump .LBB12_165
	}
	.falign
.LBB12_153:                             //   in Loop: Header=BB12_110 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_154:                             // %htp_tl2_palette_magnitude.exit5129
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r4 = max(r12,r4)
		p1 = cmp.eq(r12,#0)
		r2 = #8
		if (p1.new) jump:nt .LBB12_172
	}
// %bb.155:                             // %if.end316
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r2 = maxu(r14,r5)
	}
	{
		r8 = max(r2,r8)
	}
	.falign
.LBB12_156:                             // %for.inc329
                                        //   in Loop: Header=BB12_110 Depth=1
	{
		r9 = add(r9,#4)
		r7 = add(r7,#4)
		r25 = add(r25,#4)
		r21 = r8
	}
	{
		r2 = r4
		nop
	} :endloop0
	{
		jump .LBB12_172
	}
	.falign
.LBB12_158:
	{
		jump .LBB12_838
	}
	.falign
.LBB12_163:
	{
		r2 = #8 ; jump .LBB12_172
	}
	.falign
.LBB12_164:
	{
		r2 = #8 ; jump .LBB12_172
	}
	.falign
.LBB12_165:
	{
		r2 = #8 ; jump .LBB12_172
	}
	.falign
.LBB12_166:
	{
		r0 = memw(r29+#264)
		r3 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_72
		r24 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_167:
	{
		jump .LBB12_72
		r24 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_172:                             // %cleanup331
	{
		r4 = #2048
		r1 = sub(#0,r2)
		r3 = r17
	}
	{
		p3 = cmp.eq(r15,r4)
	}
	{
		call hexkl_acc_i24_usable
		r4 = p3
		memw(r29+#404) = r4.new
	}                                       // 4-byte Folded Spill
	.falign
// %bb.173:                             // %cleanup331
	{
		r1 = sub(#0,r21)
		r3:2 = combine(r17,r21)
		r25 = memw(r29+#272)
		memw(r29+#400) = r0
	}                                       // 4-byte Folded Reload
	{
		call hexkl_acc_i24_usable
		r0 = r25
	}
	.falign
// %bb.174:                             // %cleanup331
	{
		p3 = cmp.eq(r0,#0)
		r24 = #8192
		r2 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r1 = p3
		p1 = cmp.eq(r2,#0)
		r0 = memw(r29+#404)
		memw(r29+#1720) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r2 = p1
		p1 = r0
		if (!p1.new) jump:nt .LBB12_189
		memw(r29+#400) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.175:                             // %cleanup331
	{
		r21 = #0
		r2 = #1536
		r4 = memw(r29+#348)
		if (!cmp.eq(r2.new,r25)) jump:nt .LBB12_190
	}                                       // 4-byte Folded Reload
// %bb.176:                             // %cleanup331
	{
		r2 = memw(r29+#372)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) r2 = #32
		if (!p3.new) jump:nt .LBB12_191
	}
// %bb.177:                             // %cleanup331
	{
		r2 = memw(r29+#304)
		if (!cmp.eq(r2.new,r2)) jump:nt .LBB12_191
	}                                       // 4-byte Folded Reload
// %bb.178:                             // %cleanup331
	{
		r2 = memw(r29+#376)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_191
	}                                       // 4-byte Folded Reload
// %bb.179:                             // %cleanup331
	{
		r3:2 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.gtu(r2,#1); if (!p1.new) jump:nt .LBB12_191
		if (p1.new) r3:2 = memd(r29+##1704)
	}                                       // 8-byte Folded Reload
// %bb.180:                             // %cleanup331
	{
		p2 = cmp.eq(r3,#0)
		if (!p2.new) jump:nt .LBB12_191
		if (p2.new) r2 = memw(r29+##400)
	}                                       // 4-byte Folded Reload
// %bb.181:                             // %cleanup331
	{
		p2 = r2
		if (p2.new) jump:nt .LBB12_191
		if (!p2.new) r2 = memw(r29+##1720)
	}                                       // 4-byte Folded Reload
// %bb.182:                             // %cleanup331
	{
		p1 = r2
		if (p1.new) jump:nt .LBB12_191
	}
// %bb.183:                             // %if.then360
	{
		call hvx_tl2_weight_bytes
		r0 = #2048
		r1 = #3072
	}
	.falign
// %bb.184:                             // %if.then360
	{
		call hvx_tl2_weight_bytes
		r21 = r0
		r0 = #1536
		r1 = #2048
	}
	.falign
// %bb.185:                             // %if.then360
	{
		r3 = add(r0,r21)
		r0 = r26
		r4 = add(r29,#8704)
		r5 = add(r29,#3872)
	}
	{
		call hexkl_acc_i24_banks
		r2 = #32
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.186:                             // %if.then360
	{
		r4 = #2
		r24 = #6144
		p3 = cmp.eq(r0,#0)
		if (p3.new) jump:nt .LBB12_188
	}
// %bb.187:                             // %if.then369
	{
		r23 = memw(r29+#3872)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r2,r23)
		r2 = memw(r29+##8704)
		memw(r29+#292) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r1 = add(r20,r21)
		r21 = #0
	}
	{
		jump .LBB12_191
		r0 = memw(r29+#264)
		memd(r29+#1704) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_188:
	{
		r1 = #0
		r24 = #8192
		r21 = #0
		r4 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_191
		r0 = memw(r29+#264)
		memd(r29+#1704) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_189:
	{
		r21 = #0 ; jump .LBB12_191
		r0 = memw(r29+#264)
		r4 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_190:
	{
		r21 = #0
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_191:                             // %if.end374
	{
		if (!p0.new) r1 = add(r16,#0)
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB12_194
		memw(r29+#348) = r4
	}                                       // 4-byte Folded Spill
// %bb.192:                             // %if.then377
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.193:                             // %if.then377
	{
		r23 = add(r0,r23)
	}
	.falign
.LBB12_194:                             // %if.end381
	{
		r1:0 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB12_197
		if (!p1.new) r0 = memw(r29+##272)
	}                                       // 4-byte Folded Reload
// %bb.195:                             // %if.then383
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.196:                             // %if.then383
	{
		r23 = add(r0,r23)
		r2 = memw(r29+#296)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_198
		r6 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_197:
	{
		r2 = memw(r29+#296)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_198:                             // %if.end386
	{
		r3 = add(r26,#-3072)
		p2 = cmp.gtu(r26,##3071)
		if (!p2.new) jump:nt .LBB12_204
	}
// %bb.199:                             // %if.end386
	{
		r3 = insert(r24,#11,#0)
		r21 = #0
		if (cmp.gtu(r23,r3.new)) jump:nt .LBB12_203
	}
// %bb.200:                             // %if.then390
	{
		r2 = add(r2,r3)
		r3 = memw(r29+#400)
		r4 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		p2 = r4
	}
	{
		r3 = mux(p0,#0,r2)
		r21 = mux(p2,#0,r2)
	}
	{
		r23 = r3
		r3 = or(r3,r21)
		if (cmp.eq(r3.new,#0)) jump:t .LBB12_205
	}
// %bb.201:                             // %if.then402
	{
		call hexkl_acc_i24_prepare
		r0 = r2
	}
	.falign
// %bb.202:                             // %if.then402
	{
		jump .LBB12_206
		r6 = memw(r29+#392)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_203:
	{
		r23 = #0 ; jump .LBB12_206
	}
	.falign
.LBB12_204:
	{
		r21 = #0 ; jump .LBB12_206
		r23 = #0
	}
	.falign
.LBB12_205:
	{
		r21 = #0
		r23 = #0
	}
	.falign
.LBB12_206:                             // %if.end405
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p1 = !tstbit(r2,#25)
		if (p1.new) jump:nt .LBB12_208
		if (!p1.new) r4 = memw(r29+##360)
	}                                       // 4-byte Folded Reload
// %bb.207:                             // %if.end405
	{
		p0 = r4
		r2 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p2 = and(p1,p0)
		if (!p2.new) jump:t .LBB12_838
	}
	.falign
.LBB12_208:                             // %if.end416
	{
		p2 = and(p2,!p2)
		r2 = memw(r29+#360)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		r2 = mux(p1,#1,#0)
		r4 = memw(r3+##hexkl_probe_us@GOT)
		r6 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r25 = add(r20,#0)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r5 = lsr(r3,r6)
		r6 = lsr(r27,r6)
		r3 = #0
		memw(r29+#404) = r6.new
	}                                       // 4-byte Folded Spill
	{
		if (!p1) jump:nt .LBB12_211
		memd(r4+#224) = r3:2
		memw(r29+#400) = r5
	}                                       // 4-byte Folded Spill
// %bb.209:                             // %land.lhs.true444
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,##131104)
	}
	{
		p3 = cmp.eq(r2,#32)
		if (p3.new) r25 = add(r20,#0)
		if (!p3.new) r27 = #0
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p3) r25 = add(r20,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r2 = p1
		if (!p3) jump:nt .LBB12_231
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.210:
	{
		r2 = p2
		jump .LBB12_212
		memw(r29+#352) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_211:
	{
		r2 = p2
		memw(r29+#352) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_212:                             // %land.end460
	{
		call hvx_tl2_table_bytes
	}
	.falign
// %bb.213:                             // %land.end460
	{
		r20 = memw(r29+#272)
		memd(r29+#1720) = r1:0
	}                                       // 4-byte Folded Reload
	{
		call hvx_tl2_table_bytes
		r0 = r20
	}
	.falign
// %bb.214:                             // %land.end460
	{
		r27 = r0
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_222
		if (!p2.new) r3 = memw(r29+##352)
	}                                       // 4-byte Folded Reload
// %bb.215:                             // %land.lhs.true471
	{
		r2 = ##-2147449856
	}
	{
		r6 = add(r2,#-32754)
		r3 = #8192
		if (cmp.gtu(r20,r3.new)) jump:nt ##.LBB12_838
	}
// %bb.216:                             // %land.lhs.true471
	{
		r0 = memw(r29+#264)
		if (cmp.gtu(r0.new,r3)) jump:nt ##.LBB12_838
	}                                       // 4-byte Folded Reload
// %bb.217:                             // %land.lhs.true471
	{
		r3 = #0
		r2 = memw(r29+#352)
		r7 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = memw(r29+#384)
		r9:8 = memd(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r2 = asl(r7,#1)
	}
	{
		p0 = and(p0,p1)
		if (p0.new) r9 = #0
		if (p0.new) r1 = add(r16,#0)
		if (!p0.new) jump:nt .LBB12_838
	}
// %bb.218:                             // %lor.lhs.false482
	{
		memw(r29+#384) = r27
	}                                       // 4-byte Folded Spill
	{
		r5:4 = add(r9:8,r3:2)
		r2 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r27,r2)
		r27 = #0
	}
	{
		r5:4 = add(r5:4,r3:2)
	}
	{
		p1 = cmp.gtu(r5:4,r27:26)
		if (!p1.new) r27:26 = combine(r7,r23)
		if (!p1.new) r23 = add(r6,#0)
		if (p1.new) jump:t .LBB12_838
	}
// %bb.219:                             // %lor.lhs.false493
	{
		call hvx_tl2_weight_bytes
		memd(r29+#1720) = r9:8
	}                                       // 8-byte Folded Spill
	.falign
// %bb.220:                             // %lor.lhs.false493
	{
		if (!p2.new) jump:t .LBB12_244
		r6 = r23 ; jump .LBB12_838
		p2 = cmp.gtu(r0,r27)
	}
// %bb.221:
	.falign
.LBB12_222:                             // %if.end503
	{
		r2 = #0
		memw(r29+#784) = r2.new
	}
	{
		p2 = r3
		r2 = #1
		r3 = memw(r29+#312)
		memw(r29+#408) = r25
	}                                       // 4-byte Folded Reload
	{
		if (!p2) jump:nt .LBB12_224
		memw(r29+#412) = r17
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_223:                             // %cond.true505
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r2,#2,#22)
	}
	{
		r2 = add(r2,#1)
	}
	.falign
.LBB12_224:                             // %cond.end508
	{
		r20 = lsr(r3,#1)
		r17 = lsr(r16,#6)
		r2 = #1
		memw(r29+#788) = r2
	}
	{
		r0 = add(r17,add(r20,#-1))
		r1 = r20
		r2 = #0
		memw(r29+#792) = r2
	}
	{
		call __hexagon_udivsi3
		memw(r29+#796) = r2
	}
	.falign
// %bb.225:                             // %cond.end508
	{
		r2 = ##-2147449856
		p0 = cmp.gtu(r0,#16)
	}
	{
		r6 = add(r2,#-32748)
		if (p0) jump:nt .LBB12_838
		if (!p0) r2 = memw(r29+##308)
	}                                       // 4-byte Folded Reload
// %bb.226:                             // %lor.lhs.false517
	{
		r1 = memw(r29+#304)
		memw(r29+#432) = r0
	}                                       // 4-byte Folded Reload
	{
		r20 = r6
		memw(r29+#424) = r20
		memw(r29+#384) = r27
	}                                       // 4-byte Folded Spill
	{
		r0 = add(r2,add(r1,#-1))
		call __hexagon_udivsi3
		memw(r29+#428) = r21
	}                                       // 4-byte Folded Spill
	.falign
// %bb.227:                             // %lor.lhs.false517
	{
		r6 = r20
		p1 = cmp.gtu(r0,#16); if (p1.new) jump:t .LBB12_838
		memw(r29+#440) = r0
	}                                       // 4-byte Folded Spill
// %bb.228:                             // %if.end526
	{
		r19 += mpyi(r18,#63)
		r4 = memw(r22+#12)
		memw(r29+#512) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r27:26 = vaslw(r19:18,#2)
		p3 = cmp.eq(r4,#0)
		r2 = memw(r22+#64)
		memw(r29+#312) = r17
	}                                       // 4-byte Folded Spill
	{
		r2 = p3
		p1 = cmp.eq(r2,#0)
		r4 = memw(r29+#264)
		memw(r29+#524) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p0 = not(p3)
		p2 = not(p1)
		r1:0 = memd(r29+#1696)
		r2 = memw(r29+#360)
	}                                       // 8-byte Folded Reload
	{
		p1 = r2
		r2 = p0
		r3 = add(r0,#63)
		memw(r29+#392) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p3 = and(p0,!p1)
		p0 = and(p2,!p1)
		r1 = and(r3,#-64)
		r2 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r25 = mpyi(r19,r4)
		r21:20 = vaslw(r1:0,#2)
		memw(r29+#544) = r3
		memd(r29+#1696) = r1:0
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r20,r2)
		r3 = mpyi(r20,r4)
		memw(r29+#520) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r5 = p0
		r2 = p3
		r17 = add(r2,#127)
		memw(r29+#556) = r3
	}                                       // 4-byte Folded Spill
	{
		if (!p3) r2 = #0
		if (!p3) jump:nt .LBB12_234
		memw(r29+#416) = r5
		memw(r29+#484) = r2
	}                                       // 4-byte Folded Spill
// %bb.229:                             // %cond.true579
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.230:                             // %cond.true579
	{
		r0 = add(#4,asl(r0,#2))
		r3 = #127
		r4 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r0,r4)
		jump .LBB12_235
	}
	.falign
.LBB12_231:                             // %land.lhs.true448
	{
		r3:2 = combine(#0,r5)
	}
	{
		r5:4 = asl(r3:2,#1)
	}
	{
		p0 = cmp.gtu(r5:4,r27:26)
		if (p0.new) r25 = add(r20,#0)
		if (!p0.new) jump:t .LBB12_233
	}
// %bb.232:
	{
		r2 = p2
		jump .LBB12_212
		memw(r29+#352) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_233:                             // %land.rhs454
	{
		r4 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(#0,r4)
	}
	{
		r5:4 = asl(r5:4,#1)
	}
	{
		p1 = cmp.gtu(r5:4,r3:2)
	}
	{
		p0 = not(p1)
	}
	{
		r2 = p0
		jump .LBB12_212
		memw(r29+#352) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_234:
	{
		r3 = add(r3,#127)
	}
	.falign
.LBB12_235:                             // %cond.end585
	{
		r20 = lsr(r19,#4)
		r9 = add(r25,#127)
		r7 = memw(r29+#272)
		r5 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(#127,asl(r7,#4))
		r15 = and(r9,#-128)
		r8 = memw(r29+#276)
		r1:0 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(#127,asl(r8,#4))
		r11 = asl(r0,#4)
		r13 = memw(r29+#316)
		r14 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r10 = extractu(r13,#21,#0)
		r13 = extractu(r13,#22,#0)
		r28 = add(r27,#127)
		r12 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r5,add(r14,#1))
		r4 = add(##383,mpyi(r4,r0))
		r5 = r20
	}
	{
		r14 = extractu(r14,#23,#0)
		r0 = asl(r13,#10)
		r13 = and(r8,#-128)
		memw(r29+#508) = r28
	}                                       // 4-byte Folded Spill
	{
		p0 = r12
		r12 = asl(r10,#11)
		r8 = r0
		memw(r29+#540) = r0
	}                                       // 4-byte Folded Spill
	{
		r9 = asl(r14,#9)
		r0 = and(r7,#-128)
		r7 = r13
		memw(r29+#444) = r9.new
	}                                       // 4-byte Folded Spill
	{
		r8 += add(r9,r12)
		r6 = add(##127,mpyi(r6,r18))
		memw(r29+#536) = r0
	}                                       // 4-byte Folded Spill
	{
		r7 += add(r8,r0)
		r10 = and(r28,#-128)
		r9:8 = combine(r18,#96)
		memw(r29+#436) = r13
	}                                       // 4-byte Folded Spill
	{
		r9 = add(#127,asl(r9,#6))
		r0 = add(r26,#127)
		r28 = and(r6,#-128)
		memw(r29+#464) = r12
	}                                       // 4-byte Folded Spill
	{
		r8 = add(##159,mpyi(r18,r8))
		r13 = and(r0,#-128)
		memw(r29+#516) = r0
	}                                       // 4-byte Folded Spill
	{
		r0 = addasl(r12,r1,#3)
		r9 = and(r9,#-128)
		r14 = and(r8,#-128)
		if (p0) r11 = #0
	}
	{
		r5 = add(##256,asl(r5,#1))
		r1 = r9
		memw(r29+#496) = r9
	}                                       // 4-byte Folded Spill
	{
		r1 += add(r0,r14)
		r12 = and(r4,#-128)
		r4 = r28
		r0 = add(r10,r13)
	}
	{
		r4 += add(r1,r13)
		r9 = mux(p0,#0,r12)
		r5 = and(r5,##1073741568)
	}
	{
		r6 = +mpyi(r0,#3)
		r1 = add(r11,#127)
		r0 = and(r3,#-128)
		memw(r29+#500) = r14
	}                                       // 4-byte Folded Spill
	{
		r5 += add(r4,r15)
		r4 = r9
		r9 = #8192
		memw(r29+#488) = r9
	}                                       // 4-byte Folded Spill
	{
		r9 += asl(r7,#4)
		r1 = and(r1,#-128)
		memw(r29+#1728) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r4 += add(r5,r6)
		if (!p0) r9 = #0
		r5 = and(r17,#-128)
		memw(r29+#504) = r28
	}                                       // 4-byte Folded Spill
	{
		r1 += add(r4,r9)
		r2 = add(r2,#127)
		r17 = r0
		r4 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		p3 = r4
		r0 = and(r2,#-128)
		r4 = memw(r29+#248)
		memw(r29+#1736) = r0
	}                                       // 4-byte Folded Reload
	{
		p1 = and(p1,!p1)
		if (p3) r5 = #0
		p3 = cmp.eq(r4,#0)
		r19 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r17 += add(r1,r5)
		r1 = #1536
		memw(r29+#480) = r10
		memw(r29+#1744) = r13
	}                                       // 4-byte Folded Spill
	{
		r17 += add(r0,r1)
		memw(r29+#468) = r5
		memw(r29+#476) = r15
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		memw(r29+#472) = r0
		memw(r29+#548) = r12
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#452) = r0
		memw(r29+#528) = r11
	}                                       // 4-byte Folded Spill
	{
		if (p3) jump:nt .LBB12_241
	}
// %bb.236:                             // %land.lhs.true730
	{
		r2 = memw(r22+#4)
		if (!cmp.eq(r2.new,r4)) jump:t .LBB12_241
	}
// %bb.237:                             // %land.lhs.true733
	{
		r4 = #1536
		r0 = memw(r29+#272)
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r0,r4)
		p1 = cmp.eq(r2,#0)
		r5 = memw(r29+#276)
		r1:0 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p1)
		r1 = add(r0,#-128)
		r0 = #2048
		r3 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		p2 = not(p2)
		p0 = cmp.eq(r5,r0)
		r0 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p3 = or(p1,!p3)
		p0 = not(p0)
		p1 = cmp.gtu(r1,##3968)
	}
	{
		p3 = or(p2,or(p3,p1))
		p1 = r0
		r1 = memw(r29+#416)
		r0 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		p2 = or(p1,or(p0,p3))
		p0 = r1
	}
	{
		p3 = r0
	}
	{
		p1 = or(p0,or(p2,p3))
		if (p1.new) jump:nt .LBB12_241
		if (p1.new) r19 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.238:                             // %land.lhs.true733
	{
		r2 = memw(r29+#364)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_644
	}                                       // 4-byte Folded Reload
// %bb.239:                             // %land.lhs.true733
	{
		r2 = memw(r29+#364)
		r4 = memw(r29+#1712)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r4,r2); if (!p0.new) jump:nt .LBB12_241
		if (p0.new) r2 = memw(r22+#8)
		r19 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
// %bb.240:                             // %land.rhs756
	{
		p2 = cmp.gtu(r17,r2)
	}
	{
		p2 = not(p2)
	}
	{
		r0 = p2
		memw(r29+#452) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_241:                             // %land.end759
	{
		r2 = memw(r19+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_247
	}
// %bb.242:                             // %if.then762
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.243:                             // %if.then762
	{
		r27:26 = combine(r1,r0)
		jump .LBB12_248
	}
	.falign
.LBB12_244:                             // %lor.lhs.false498
	{
		call hvx_tl2_weight_bytes
		r0 = memw(r29+#272)
		r1 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.245:                             // %lor.lhs.false498
	{
		r6 = r23
		r2 = memw(r29+#404)
		if (cmp.gtu(r0,r2.new)) jump:t ##.LBB12_838
	}                                       // 4-byte Folded Reload
// %bb.246:                             // %if.end503.thread
	{
		r2 = #0
		r23 = r26
		memw(r29+#408) = r25
		memw(r29+#412) = r17
	}                                       // 4-byte Folded Spill
	{
		r27 = memw(r29+#384)
		memw(r29+#784) = r2
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_223
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_247:
	{
		r27:26 = combine(#0,#0)
	}
	.falign
.LBB12_248:                             // %do.end
	{
		call hexkl_moe_scratch_reserve
		r1:0 = combine(r17,r22)
	}
	.falign
// %bb.249:                             // %do.end
	{
		r2 = memw(r19+##hexkl_probe_on@GOT)
		memw(r29+#392) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_252
	}
// %bb.250:                             // %if.then768
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.251:                             // %if.then768
	{
		r1:0 = sub(r1:0,r27:26)
		r2 = memw(r19+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#72)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#72) = r1:0
	}
	.falign
.LBB12_252:                             // %do.end774
	{
		r19 = #0
		r6 = memw(r29+#392)
		if (!cmp.eq(r6.new,#0)) jump:t ##.LBB12_838
	}                                       // 4-byte Folded Reload
// %bb.253:                             // %for.body845.preheader
	{
		r0 = memw(r29+#452)
		memw(r29+#532) = r24
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		r17:16 = combine(#0,#0)
		r3 = memw(r29+#1736)
		memw(r29+#576) = r16
	}                                       // 4-byte Folded Reload
	{
		r7 = mux(p0,r3,#0)
		r8 = mux(p0,#0,r3)
		r2 = memw(r29+#244)
		r4 = memw(r22+#4)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = mux(p0,#1,#0)
		r6 = memw(r29+#504)
		r1 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r4,r7)
		r5 = mux(p1,#1,#0)
		memw(r29+#588) = r7
	}                                       // 4-byte Folded Spill
	{
		p3 = r1
		r1 = add(r7,#1024)
		r2 = memw(r29+#332)
		memw(r22+#60) = r2
	}                                       // 4-byte Folded Reload
	{
		if (p3) r5 = add(r2,#0)
		r0 = memw(r29+#476)
		memw(r29+#620) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,r0)
		r1 = memw(r29+#480)
		memw(r29+#420) = r1
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r1)
		r14 = memw(r29+#1744)
		memw(r29+#552) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r1)
		memw(r29+#460) = r2
		memw(r29+#592) = r8
	}                                       // 4-byte Folded Spill
	{
		r9 = add(r2,r1)
		r0 = memw(r29+#468)
		memw(r29+#456) = r2
	}                                       // 4-byte Folded Reload
	{
		r12 = add(r9,r14)
		r1 = memw(r29+#472)
		memw(r29+#572) = r4
	}                                       // 4-byte Folded Reload
	{
		r25 = add(r12,r14)
		memw(r29+#560) = r23
		memw(r29+#612) = r7
	}                                       // 4-byte Folded Spill
	{
		r27 = add(r25,r14)
		r24 = memw(r29+#280)
		memw(r29+#448) = r9
	}                                       // 4-byte Folded Reload
	{
		r26 = add(r27,r21)
		memw(r29+#372) = r12
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r26,r21)
	}
	{
		r8 = add(r2,r8)
		r13 = mux(p0,r4,r2)
		memw(r29+#492) = r13.new
	}                                       // 4-byte Folded Spill
	{
		r15 = add(r8,r0)
		r0 = add(r20,#128)
		if (!p3) r5 = add(r8,#0)
		memw(r29+#648) = r8
	}                                       // 4-byte Folded Spill
	{
		r21:20 = combine(#0,r24)
		r11 = and(r0,##536870784)
		memw(r29+#624) = r0
	}                                       // 4-byte Folded Spill
	{
		r3 = add(r15,r1)
		r0 = memw(r29+#488)
		memw(r29+#600) = r15
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r3,r0)
		r0 = memw(r29+#1728)
		memw(r29+#628) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r11)
		r1 = memw(r29+#500)
		memw(r29+#632) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r11)
		memw(r29+#580) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r4 = add(r4,r0)
		memw(r29+#596) = r11
		memw(r29+#564) = r5
	}                                       // 4-byte Folded Spill
	{
		r6 += add(r4,r1)
		r1 = memw(r29+#496)
		memw(r29+#584) = r4
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#464)
		memw(r29+#652) = r6
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r6,r1)
		r6 = add(r3,#128)
		r1 = memw(r29+#236)
		memw(r29+#636) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,add(r0,##512))
		r0 = memw(r29+#360)
		memw(r29+#616) = r4.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r3 = add(r4,r14)
		r0 = add(r7,#512)
		memw(r29+#644) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = and(r1,##33554432)
		if (!p2) r3 = #0
		memw(r29+#608) = r0
	}                                       // 4-byte Folded Spill
	{
		r15 = mux(p2,#0,r6)
		memw(r29+#604) = r15.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#640) = r2
		memw(r29+#656) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_254:                             // %for.body845
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r20+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_263
	}
// %bb.255:                             // %if.then849
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		p3 = cmp.eq(r19,#0)
		if (p3.new) jump:nt .LBB12_261
		if (!p3.new) r3 = memw(r29+##360)
	}                                       // 4-byte Folded Reload
// %bb.256:                             // %cond.end855
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		p2 = r3
		if (!p2.new) r23 = add(r19,#-1)
		if (p2.new) jump:t .LBB12_261
	}
// %bb.257:                             // %land.lhs.true860
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		r3 = memw(r12+r23<<#2)
	}
	{
		r3 = memw(r24+r3<<#2)
		if (!cmp.eq(r3.new,r2)) jump:t .LBB12_261
	}
// %bb.258:                             // %land.end875
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		r2 = asl(r2,#2)
		r4 = memw(r29+#300)
		r3 = memw(r25+r23<<#2)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r16,#2)
		r0 = addasl(r4,r3,#2)
	}
	{
		call memcmp
	}
	.falign
// %bb.259:                             // %land.end875
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		p2 = cmp.eq(r0,#0)
		r12 = memw(r29+#372)
		r9 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		if (!p2) jump:nt .LBB12_262
		memw(r25+r19<<#2) = r16
	}
// %bb.260:                             // %cond.end883.thread5494
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		r2 = memw(r9+r23<<#2)
		memw(r9+r19<<#2) = r2.new
	}
	{
		r19 = add(r19,#1)
		jump .LBB12_264
		memw(r12+r19<<#2) = r21
		r2 = memw(r20+#0)

	} :mem_noshuf
	.falign
.LBB12_261:                             // %cond.end883.thread
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		memw(r25+r19<<#2) = r16
	}
	.falign
.LBB12_262:                             // %if.then889
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		r19 = add(r19,#1)
		memw(r9+r19<<#2) = r17
		memw(r12+r19<<#2) = r21
	}
	{
		r2 = memw(r20+#0)
	}
	{
		r3 = add(r2,#63)
	}
	{
		r3 = and(r3,#-64)
	}
	{
		r17 = add(r3,r17)
		jump .LBB12_264
	}
	.falign
.LBB12_263:                             //   in Loop: Header=BB12_254 Depth=1
	{
		r2 = #0
	}
	.falign
.LBB12_264:                             // %if.end896
                                        //   in Loop: Header=BB12_254 Depth=1
	{
		r16 = add(r2,r16)
		r20 = add(r20,#4)
		r21 = add(r21,#1)
		if (!cmp.eq(r21.new,r18)) jump:t .LBB12_254
	}
// %bb.265:                             // %for.cond.cleanup844
	{
		r2 = memw(r29+#396)
		memw(r29+#248) = r19
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#568) = r25
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_268
	}
// %bb.266:                             // %if.then905
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.267:                             // %if.then905
	{
		jump .LBB12_269
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_268:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_269:                             // %do.end909
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.270:                             // %do.end909
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_272
	}
// %bb.271:                             // %if.then911
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_reset
	}
	.falign
.LBB12_272:                             // %if.end913
	{
		r2 = memw(r29+#484)
		r0 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		p0 = r0
	}
	{
		p0 = or(p3,p0)
		if (p0.new) jump:t .LBB12_278
		if (!p0.new) r2 = memw(r29+##524)
	}                                       // 4-byte Folded Reload
// %bb.273:                             // %if.else919
	{
		p2 = r2
		if (p2.new) r3 = #0
		if (p2.new) jump:nt .LBB12_277
		if (p2.new) r1 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
// %bb.274:                             // %if.then921
	{
		r2 = memw(r22+#16)
		memw(r29+#0) = r2.new
	}
	{
		r3:2 = memd(r29+#1696)
		r1 = memw(r29+#492)
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#264)
		r0 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r4 = r3
		r5 = memw(r29+#512)
		r6 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_rmsnorm_rows_f32
		memw(r29+#4) = r6
	}
	.falign
// %bb.275:                             // %if.then921
	{
		p2 = cmp.eq(r0,#0)
		if (!p2.new) r2 = ##-2147449856
		if (p2.new) jump:nt .LBB12_278
	}
// %bb.276:
	{
		r17 = add(r2,#-32754)
		jump .LBB12_795
	}
	.falign
.LBB12_277:                             // %if.else927
	{
		r5:4 = combine(#3,#0)
		r0 = memw(r29+#492)
		r2 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
	}
	.falign
.LBB12_278:                             // %if.end932
	{
		r2 = memw(r29+#248)
		r1 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p3 = r1
		p0 = cmp.eq(r2,#0)
	}
	{
		p1 = or(p3,p0)
		r0 = p0
		if (!p1.new) jump:t .LBB12_281
		memw(r29+#452) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.279:                             // %if.then937
	{
		call memset
		r1 = #0
		r0 = memw(r29+#564)
		r2 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.280:                             // %if.then937
	{
		jump .LBB12_282
	}
	.falign
.LBB12_281:                             // %if.else940
	{
		call memset
		r1 = #0
		r0 = memw(r29+#580)
		r2 = memw(r29+#528)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_282:                             // %do.body942
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_285
	}
// %bb.283:                             // %if.then944
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.284:                             // %if.then944
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_285:                             // %do.end950
	{
		r2 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) r17 = #0
		if (p2.new) jump:nt .LBB12_294
	}
// %bb.286:                             // %if.end959
	{
		r2 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB12_297
		if (!p0.new) r2 = memw(r29+##372)
	}                                       // 4-byte Folded Reload
// %bb.287:                             // %if.else968
	{
		r2 = memw(r29+#788)
	}
	{
		p0 = cmp.gtu(r2,#1)
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p2 = and(p1,p0)
		if (!p2.new) r17 = #0
		if (!p2.new) jump:t .LBB12_603
	}
// %bb.288:                             // %if.then974
	{
		r0 = add(r29,#744)
		r2 = memw(r29+#372)
		r1 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r4+r3<<#2)
		r3 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r5,#96)
		call moe_m1_q_post
	}
	.falign
// %bb.289:                             // %if.then974
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.290:                             // %if.then974
	{
		r2 = add(r29,#744)
		r3 = memw(r29+#788)
		if (!cmp.gtu(r3.new,r0)) jump:t ##.LBB12_645
	}
// %bb.291:                             // %if.else986
	{
		r17 = #0
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_685
	}
// %bb.292:                             // %if.then989
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.293:                             // %if.then989
	{
		r19:18 = combine(r1,r0)
		jump .LBB12_686
		r3 = memw(r29+#788)
	}
	.falign
.LBB12_294:                             // %if.then953
	{
		r2 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r3 = #0
		if (p1.new) jump:t .LBB12_795
	}
// %bb.295:                             // %if.then955
	{
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#332)
		r1 = memw(r29+#648)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.296:                             // %if.then955
	{
		jump .LBB12_795
	}
	.falign
.LBB12_297:                             // %if.then961
	{
		r5 = add(r29,#1816)
		r3 = memw(r29+#260)
		r4 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#296)
		r1 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		r6 = memw(r4+r2<<#2)
		memw(r29+#12) = r5

	} :mem_noshuf
	{
		r5 = memw(r29+#328)
		memw(r29+#8) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r6,#96)
		r2 = memw(r29+#408)
		r4 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#424)
		memw(r29+#4) = r7.new
	}                                       // 4-byte Folded Reload
	{
		call moe_push_gate_up_chunks
		r6 = memw(r29+#312)
		memw(r29+#0) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.298:                             // %if.then961
	{
		r17 = #0
	}
	.falign
.LBB12_299:                             // %if.end1040
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_302
	}
// %bb.300:                             // %if.then1043
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.301:                             // %if.then1043
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_302:                             // %do.end1047
	{
		p2 = cmp.eq(r17,#0)
		r3 = memw(r29+#484)
		r0 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r4 = p2
		r2 = memw(r29+#492)
		r3 = memw(r29+#600)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r0 = add(r2,#0)
		r2 = memw(r22+#16)
		memw(r29+#12) = r3

	} :mem_noshuf
	{
		r3 = memw(r29+#380)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Reload
	{
		if (!p2) r3 = #0
		r2 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = memw(r29+#512)
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r26,r27)
		if (p1) r2 = #0
		r3 = memw(r29+#244)
		memw(r29+#452) = r4
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r2 = memw(r29+#420)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#604)
	}                                       // 4-byte Folded Reload
	{
		if (p0) r3 = add(r2,#0)
		r17:16 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r1 = r16
		r2 = r17
		r3 = memw(r29+#264)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_rows_u8_params_rm
	}
	.falign
// %bb.303:                             // %do.end1047
	{
		r4 = extractu(r17,#23,#6)
		r6 = #1
		r5 = memw(r29+#516)
		r2 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		r5 = lsr(r5,#7)
		r18 = #384
		r8 = memw(r29+#588)
		r7 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	{
		r5 += lsr(r7,#7)
		r2 = add(r8,r2)
		r3 = memw(r29+#468)
		r7 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		r3 += add(r2,r7)
		r2 = memw(r29+#248)
		r13 = memw(r29+#596)
	}                                       // 4-byte Folded Reload
	{
		r9 = maxu(r2,r6)
		r3 += asl(r4,#9)
		r4 = add(r8,#1024)
		r21 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		r8 = r21
		r2 = r21
		r6 = memw(r29+#472)
		r17 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r3,add(r6,##1024))
		r3 = mpyi(r5,r18)
		r5 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r5 = extractu(r5,#24,#7)
		r7 = add(r21,r5)
		r12 = memw(r29+#572)
		memw(r29+#252) = r9
	}                                       // 4-byte Folded Reload
	{
		r2 += add(r3,r13)
		r8 += asl(r5,#8)
		r4 = add(r12,r4)
		r19 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r12,r6)
		r6 = add(r4,r7)
		r7 = add(r4,r8)
		r8 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		loop1(.LBB12_304,r9)
		r3 = #0
		r20 = memw(r29+#568)
		r11 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r9 = #0
	}
	.falign
.LBB12_304:                             // Block address taken
                                        // %for.body1075
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_308 Depth 2
                                        //     Child Loop BB12_313 Depth 2
	{
		r28 = lsr(r3,#4)
		r12 = memw(r8+#0)
		if (!cmp.eq(r12.new,r3)) jump:t .LBB12_315
	}
// %bb.305:                             // %if.end1082
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r13 = memw(r11+r9<<#2)
		r15 = memw(r20+r9<<#2)
	}
	{
		r13 = addasl(r19,r13,#2)
		r12 = memw(r19+r13<<#2)
	}
	{
		r12 = add(r12,#63)
	}
	{
		r14 = and(r12,#-64)
	}
	{
		r12 = add(r14,r3)
	}
	{
		r0 = lsr(r12,#4)
		if (!cmp.gtu(r0.new,r28)) jump:t .LBB12_311
	}
// %bb.306:                             // %for.body1096.preheader
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r28 += add(r5,r2)
		r0 = sub(r28,r0)
	}
	{
		r10 = sub(#0,r0)
		r1:0 = combine(r3,r28)
	}
	{
		r11 = lsr(r10,#1)
		r10 = and(r10,#1)
	}
	{
		p1 = cmp.gtu(r11,#0)
		if (!p1.new) jump:t .LBB12_309
	}
// %bb.307:                             //   in Loop: Header=BB12_304 Depth=1
	{
		loop0(.LBB12_308,r11)
	}
	.falign
.LBB12_308:                             //   Parent Loop BB12_304 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r16 = add(r1,#16)
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p0 = cmp.gtu(r11,r1)
		r1 = add(r1,#32)
	}
	{
		r11 = mux(p0,#0,#1)
		memb(r0++#2) = r11.new
	}
	{
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p2 = cmp.gtu(r11,r16)
	}
	{
		r11 = mux(p2,#0,#1)
		r28 = r0
		memb(r28+#1) = r11.new
	} :endloop0
	.falign
.LBB12_309:                             //   in Loop: Header=BB12_304 Depth=1
	{
		p1 = cmp.gtu(r10,#0)
		if (!p1.new) jump:t .LBB12_311
		if (p1.new) r28 = memw(r13+#0)
		r11 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_310:                             // Block address taken
                                        // %for.body1096
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r28 = add(r28,r3)
	}
	{
		p3 = cmp.gtu(r28,r1)
	}
	{
		r28 = mux(p3,#0,#1)
		memb(r0++#1) = r28.new
	}
	.falign
.LBB12_311:                             // %for.cond1108.preheader
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r28 = addasl(r6,r3,#2)
		r15 = addasl(r17,r15,#2)
		p3 = cmp.eq(r14,#0)
		if (p3.new) jump:nt .LBB12_315
	}
// %bb.312:                             // %for.body1112.preheader
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r1 = add(r4,r21)
	}
	{
		r0 = addasl(r7,r3,#2)
		r3 = addasl(r1,r3,#2)
	}
	{
		loop0(.LBB12_313,r14)
		r14 = #0
	}
	.falign
.LBB12_313:                             // Block address taken
                                        // %for.body1112
                                        //   Parent Loop BB12_304 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r1 = memw(r13+#0)
	}
	{
		p0 = cmp.gtu(r1,r14)
		r1 = #0
		r14 = add(r14,#1)
	}
	{
		if (p0) r1 = memw(r15+#0)
	}
	{
		r15 = add(r15,#4)
		memw(r3++#4) = r1
	}
	{
		r10 = memw(r27+r1<<#2)
		memw(r28++#4) = r10.new
	}
	{
		r1 = memw(r26+r1<<#2)
		memw(r0++#4) = r1.new
	} :endloop0
// %bb.314:                             //   in Loop: Header=BB12_304 Depth=1
	{
		r3 = r12
	}
	.falign
.LBB12_315:                             // %cleanup1131
                                        //   in Loop: Header=BB12_304 Depth=1
	{
		r9 = add(r9,#1)
		r8 = add(r8,#4)
		nop
	} :endloop1
// %bb.316:                             // %for.cond.cleanup1074
	{
		r2 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r4 = add(r29,##712)
		if (!p2.new) jump:t .LBB12_322
	}
// %bb.317:                             // %if.then1139
	{
		r5 = add(r29,#8704)
		r16 = add(r29,#16896)
		r2 = memw(r29+#368)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#3)
		r2 = memw(r29+#296)
		memw(r29+#304) = r5
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#400)
		r4 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r3,#1)
		r3 = mux(p2,#1,#0)
		r6 = memw(r29+#620)
		memw(r16+#44) = r4
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		memw(r16+#48) = r6
	}
	{
		r2 = add(r5,#8252)
		memd(r16+#56) = r3:2
	}
	{
		call hvx_worker_pool_workers
		memw(r29+#240) = r2
	}                                       // 4-byte Folded Spill
	.falign
// %bb.318:                             // %if.then1139
	{
		call hvx_tl2_k_splits
		r2 = add(r0,#1)
		r0 = memw(r29+#264)
		r1 = memw(r29+#576)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.319:                             // %if.then1139
	{
		r2 = memw(r29+#244)
		memw(r29+#324) = r16
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_607
		memw(r16+#52) = r0
	}
// %bb.320:                             // %land.lhs.true1151
	{
		r2 = memw(r29+#576)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#24,#0)
		r2 = add(r2,#127)
	}
	{
		r3 = asl(r3,#8)
		r2 = and(r2,#-128)
	}
	{
		r2 = mpyi(r0,r2)
		if (!cmp.gtu(r2.new,r3)) jump:t ##.LBB12_647
	}
// %bb.321:
	{
		r2 = ##-2147449856
	}
	{
		r17 = add(r2,#-32754)
		jump .LBB12_795
	}
	.falign
.LBB12_322:                             // %if.end1749
	{
		r2 = memw(r29+#492)
		memw(r29+#712) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#636)
		memw(r29+#716) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#552)
		memw(r29+#720) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#460)
		memw(r29+#724) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#584)
		r16 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r19,r16)
		r2 = memw(r29+#456)
		memw(r29+#728) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#420)
		memw(r29+#732) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#264)
		memw(r29+#736) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#396)
		r2 = memw(r29+#632)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#740) = r2
	}
	{
		r2 = memw(r17+##hexkl_moe_pack_bg_worker@GOT)
		memw(r19+#0) = r2.new
	}
	{
		r2 = lsr(r3,#4)
		memw(r19+#8) = r2.new
	}
	{
		r2 = memw(r29+#628)
		memw(r19+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit_bg
		memw(r19+#12) = r2
	}
	.falign
// %bb.323:                             // %if.end1749
	{
		r4 = memw(r29+#544)
		r2 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#7)
		r1 = memw(r29+#516)
		r3 = memw(r29+#1736)
	}                                       // 4-byte Folded Reload
	{
		r4 = and(##-512,asl(r4,#3))
		r2 += lsr(r1,#7)
		r5 = memw(r29+#572)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r5,r3)
		r6 = memw(r29+#468)
		r0 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r3,r0)
		r3 = #1536
		r1 = memw(r29+#464)
		r0 = memw(r29+#624)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r6,r1)
		r0 = and(##1073741568,asl(r0,#1))
		r1 = memw(r29+#500)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r2,r18)
		r6 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r1 += add(r4,r0)
		r0 = memw(r29+#1728)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r1,r0)
		r0 = r21
		r1 = memw(r29+#504)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r1)
		r1 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#2)
		r1 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r1,r3)
		call memset
		r1 = #255
	}
	.falign
// %bb.324:                             // %if.end1749
	{
		r1:0 = combine(r19,r16)
		r2 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r2,#64)
	}
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.325:                             // %if.end1749
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_328
	}
// %bb.326:                             // %if.then1860
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.327:                             // %if.then1860
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_328:                             // %do.end1866
	{
		p1 = and(p1,!p1)
		r2 = memw(r29+#296)
		r3 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r0 = p1
		r2 = add(r2,r3)
		memw(r29+#600) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = extractu(r2,#11,#0)
		memw(r29+#252) = r0
	}                                       // 4-byte Folded Spill
	{
		p2 = cmp.eq(r2,#0)
		if (!p2.new) jump:t .LBB12_330
	}
// %bb.329:                             // %land.rhs1872
	{
		r2 = p2
		memw(r29+#252) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_330:                             // %land.end1877
	{
		r9 = #64
		r1 = memw(r29+#388)
		r0 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r1,#0)
		r1 = memw(r29+#372)
		r8 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		r6 = maxu(r0,r8)
		r18 = minu(r8,r0)
		r0 = memw(r29+#280)
		r21 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r6,#8)
		r6 = sub(r6,r8)
		r3 = memw(r1+#0)
		r2 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p2)
		r2 = add(r21,r2)
		r16 = memw(r29+#320)
		memw(r29+#544) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p0 = and(p1,!p0)
		r5 = r16
		r7 = memw(r0+r3<<#2)
		memw(r29+#384) = r3
	}                                       // 4-byte Folded Spill
	{
		r0 = memw(r29+#356)
		r2 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r1 = p0
		r0 = memw(r29+#448)
		memw(r29+#496) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r7,r9)
		p1 = and(p0,!p2)
		r4 = memw(r29+#264)
		memw(r29+#620) = r6
	}                                       // 4-byte Folded Reload
	{
		r1 = p1
		p1 = cmp.gtu(r7,#64)
		r17 = memw(r0+#0)
	}
	{
		r7 = #0
		r1:0 = combine(#0,r21)
		r3 = r17
		memw(r29+#604) = r1
	}                                       // 4-byte Folded Spill
	{
		r12 = mux(p1,#0,#1)
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	{
		memw(r29+#1720) = r6
		memw(r29+#356) = r12
	}                                       // 4-byte Folded Spill
	{
		call moe_push_act_block
		memd(r29+#1688) = r7:6
	}                                       // 8-byte Folded Spill
	.falign
// %bb.331:                             // %land.end1877
	{
		p0 = or(p0,!p0)
		r0 = #0
		r1 = memw(r29+#304)
		memw(r29+#516) = r0
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#584)
		memw(r29+#392) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,#96)
		r3 = memw(r29+#532)
		memw(r29+#640) = r2.new
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#364) = r0
		memw(r29+#472) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r3,r1)
		r1 = extractu(r16,#22,#0)
		r3 = memw(r29+#424)
		memw(r29+#500) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#10)
		r1 = memw(r29+#272)
		memw(r29+#668) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r1,#23,#4)
		r1 = mpyi(r18,r3)
		memw(r29+#644) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r2,#9)
		r1 = memw(r29+#560)
		memw(r29+#476) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = !cmp.eq(r1,#0)
		r1 = memw(r29+#324)
		memw(r29+#236) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r21,r1)
		r1 = memw(r29+#428)
		memw(r29+#624) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r3,#22,#0)
		memw(r29+#628) = r2
		memw(r29+#572) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r2,#10)
		r3 = !cmp.eq(r1,#0)
		r1 = memw(r29+#256)
		memw(r29+#492) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r21,r1)
		r1 = #-1
		memw(r29+#636) = r2
		memw(r29+#632) = r3
	}                                       // 4-byte Folded Spill
	{
		r0 = #0
		r1 = #1
		memw(r29+#536) = r1
		memw(r29+#524) = r0
	}                                       // 4-byte Folded Spill
	{
		r1 = p0
		memw(r29+#360) = r1
		memw(r29+#548) = r0
	}                                       // 4-byte Folded Spill
	{
		r3:2 = combine(#0,#0)
		memw(r29+#508) = r2
		memw(r29+#588) = r18
	}                                       // 4-byte Folded Spill
	{
		r0 = #0
		r1 = #1
		memw(r29+#480) = r0
		memw(r29+#504) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#388) = r1
		memw(r29+#352) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#512) = r0
		memw(r29+#528) = r4
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#1736) = r3:2
		memd(r29+#1728) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#1744) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_332:                             // %for.cond1921
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_367 Depth 2
                                        //       Child Loop BB12_395 Depth 3
                                        //       Child Loop BB12_440 Depth 3
                                        //         Child Loop BB12_450 Depth 4
                                        //         Child Loop BB12_445 Depth 4
                                        //       Child Loop BB12_418 Depth 3
                                        //     Child Loop BB12_503 Depth 2
                                        //       Child Loop BB12_571 Depth 3
                                        //         Child Loop BB12_580 Depth 4
                                        //         Child Loop BB12_576 Depth 4
                                        //     Child Loop BB12_499 Depth 2
	{
		r2 = memw(r29+#388)
		r0 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r1 = memw(r29+#384)
		memw(r29+#452) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#392)
		memw(r29+#368) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#1720)
		memw(r29+#468) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#360)
		memw(r29+#256) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#356)
		memw(r29+#404) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#284)
		memw(r29+#400) = r1
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#476)
		r1 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r3,#2)
		r0 = p0
		p1 = cmp.eq(r1,#0)
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#484) = r2.new
	}                                       // 4-byte Folded Spill
	{
		if (p0) jump:nt .LBB12_336
		memw(r29+#436) = r0
		if (p0) memw(r29+##488) = r17
	}                                       // 4-byte Folded Spill
// %bb.333:                             // %if.then1923
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		p1 = or(p1,!p1)
		r2 = memw(r29+#400)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_337
	}                                       // 4-byte Folded Reload
// %bb.334:                             // %if.end.i
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r3 = #0
		r4 = memw(r29+#452)
		memw(r29+#388) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,#1)
		r3 = memw(r29+#400)
		memw(r29+#356) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#404)
		memw(r29+#360) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#248)
		memw(r29+#488) = r17
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r3,r2)
		r3 = memw(r29+#256)
		memw(r29+#1720) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#468)
		memw(r29+#392) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#368)
		memw(r29+#384) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = p1
		memw(r29+#364) = r4
	}                                       // 4-byte Folded Spill
	{
		if (!p2) jump:nt .LBB12_339
		if (p2) r3 = memw(r29+##372)
		memw(r29+#592) = r3
	}                                       // 4-byte Folded Reload
// %bb.335:                             // %if.then3.i
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r0 = #64
		r6 = #0
		r1 = #1
	}
	{
		memw(r29+#392) = r6
		memw(r29+#360) = r1
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r3+r2<<#2)
		memw(r29+#384) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r2<<#2)
		memw(r29+#488) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r3 = minu(r3,r0)
		p1 = cmp.gtu(r3,#64)
		memw(r29+#1720) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p0 = not(p1)
		jump .LBB12_338
	}
	.falign
.LBB12_336:                             //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#400)
		memw(r29+#356) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#404)
		memw(r29+#360) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#256)
		memw(r29+#1720) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#468)
		memw(r29+#392) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#368)
		memw(r29+#384) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#452)
		memw(r29+#364) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		jump .LBB12_363
		memw(r29+#388) = r1
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_337:                             // %if.then.i
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#372)
		r5 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#468)
		r1 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r4,#64)
		r4 = add(r4,#128)
		r6 = memw(r2+r5<<#2)
		r2 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r0 = cmp.eq(r7,#0)
		memw(r29+#384) = r6
	}                                       // 4-byte Folded Spill
	{
		r2 = r5
		r3 = memw(r2+r5<<#2)
		memw(r29+#360) = r0
	}                                       // 4-byte Folded Spill
	{
		r3 = add(r3,r7)
		r5 = memw(r1+r6<<#2)
	}
	{
		p0 = cmp.gtu(r5,r4)
		r6 = sub(r5,r7)
		r3 = #64
		memw(r29+#488) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = minu(r6,r3)
		p0 = not(p0)
		memw(r29+#392) = r7
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#1720) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_338:                             // %return.sink.split.i
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		p2 = and(p2,!p2)
		r4 = #1
		r3 = memw(r29+#356)
		memw(r29+#388) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r0 = p2
		r3 = mux(p0,#1,#0)
		memw(r29+#364) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#592) = r0
		memw(r29+#356) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_339:                             // %moe_blk_next.exit
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r5:4 = combine(#0,#1)
		r2 = memw(r29+#288)
		r3 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+r3<<#2)
	}
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_343
	}
// %bb.340:                             // %do.end1949
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r18 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#128)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#128) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.341:                             // %do.end1949
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_343
	}
// %bb.342:                             // %if.then1951
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = memd(r29+#1688)
		r2 = memw(r29+#516)
	}                                       // 8-byte Folded Reload
	{
		call hexkl_dma_trace_wait_begin
		r3 = r5
	}
	.falign
.LBB12_343:                             // %if.end1953
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		call hexkl_dma_ring_wait
		r0 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.344:                             // %if.end1953
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_349
	}
// %bb.345:                             // %do.body1958
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.346:                             // %do.body1958
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_349
	}
// %bb.347:                             // %if.then1960
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.348:                             // %if.then1960
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#32)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#32) = r1:0
	}
	.falign
.LBB12_349:                             // %do.end1966
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r22 = memw(r29+#260)
		r0 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r22 += mpyi(r16,#96)
	}
	{
		r2 = memw(r22+#20)
	}
	{
		r2 = addasl(r0,r17,#2)
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_351
		memw(r29+#552) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.350:                             // %if.then1970
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r4 = add(r29,#2456)
		r0 = memw(r29+#296)
		r1 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_sums
		r2 = memw(r29+#264)
		r3 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_351:                             // %if.end1974
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = #63
	}
	{
		r2 = memw(r29+#576)
		if (cmp.gtu(r2.new,r2)) jump:t .LBB12_366
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_352:                             // %for.end2406
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:t .LBB12_363
		if (!p3.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.353:                             // %do.body2409
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_356
	}
// %bb.354:                             // %if.then2411
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.355:                             // %if.then2411
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_356:                             // %do.end2415
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#488)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#64)
		r1 = memw(r29+#584)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.357:                             // %do.end2415
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_360
	}
// %bb.358:                             // %if.then2421
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.359:                             // %if.then2421
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_360:                             // %do.end2427
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#392)
		r0 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#6)
		r5 = memw(r29+#320)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1688)
		memw(r29+#0) = r0
	}                                       // 8-byte Folded Reload
	{
		r1 = r3
		r0 = memw(r29+#296)
		r2 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#488)
		r4 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		call moe_push_act_block
	}
	.falign
// %bb.361:                             // %do.end2427
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#360)
		memw(r29+#516) = r0
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB12_363
		if (!p2.new) r2 = memw(r29+##288)
	}                                       // 4-byte Folded Reload
// %bb.362:                             // %if.then2435
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r0 = memw(r29+#364)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#336)
		r4 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r2+r3<<#2)
		memw(r29+#8) = r0

	} :mem_noshuf
	{
		r0 = memw(r29+#296)
		r3 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r5,#96)
		r2 = memw(r29+#424)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#312)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#1816)
		r5 = memw(r29+#328)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call moe_push_gate_up_chunks
		r2 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_363:                             // %if.end2452
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_465
		if (p0.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.364:                             // %if.else2479
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#548)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_475
	}                                       // 4-byte Folded Reload
// %bb.365:                             // %land.lhs.true2500
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#616)
		r3 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#652)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r3<<#2)
	}
	{
		r2 = addasl(r0,r2,#6)
		p2 = cmp.eq(r2,#-1)
	}
	{
		if (p2) r2 = #0
	}
	{
		jump .LBB12_476
		memw(r29+#484) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_366:                             // %for.body1979.lr.ph
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r18 = #0
		r24 = #0
		r2 = memw(r29+#524)
		r0 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r0,#0)
		p1 = cmp.eq(r2,#0)
		r1 = memw(r29+#484)
		r0 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r17,#2)
		p3 = r1
		r1 = memw(r29+#256)
		memw(r29+#656) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#2)
		p2 = not(p3)
		r1 = memw(r29+#496)
		r0 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		p3 = r1
		p1 = not(p1)
		memw(r29+#540) = r0
		memw(r29+#672) = r2
	}                                       // 4-byte Folded Spill
	{
		p2 = and(p1,and(p3,p2))
		p1 = and(p3,!p0)
	}
	{
		r0 = p2
		r1 = p0
		memw(r29+#660) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		memw(r29+#664) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#556) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_367:                             // %for.body1979
                                        //   Parent Loop BB12_332 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_395 Depth 3
                                        //       Child Loop BB12_440 Depth 3
                                        //         Child Loop BB12_450 Depth 4
                                        //         Child Loop BB12_445 Depth 4
                                        //       Child Loop BB12_418 Depth 3
	{
		r16 = add(r29,#1752)
		r2 = memw(r29+#312)
		r3 = memw(r29+#424)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r24)
		r0 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r27 = minu(r2,r3)
		p2 = r0
		if (!p2.new) jump:t .LBB12_377
		if (p2.new) r2 = memw(r16+r18<<#2)
	}
// %bb.368:                             // %land.lhs.true1997
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p2) jump:nt .LBB12_379
		r2 = memw(r3+#0)
	}
// %bb.369:                             // %do.body2001
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_372
	}
// %bb.370:                             // %if.then2003
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.371:                             // %if.then2003
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_372:                             // %do.end2007
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r18,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.373:                             // %do.end2007
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_376
	}
// %bb.374:                             // %if.then2011
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.375:                             // %if.then2011
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_376:                             // %do.end2017
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = addasl(r16,r18,#2)
	}
	{
		jump .LBB12_400
		memw(r2+#0) = #0
	}
	.falign
.LBB12_377:                             // %if.else2019
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#664)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB12_400
		if (!p1.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.378:                             // %if.else2019.do.body2023_crit_edge
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_379:                             // %do.body2023
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r0 = add(r29,#1816)
		p1 = cmp.eq(r2,#0)
	}
	{
		r16 = addasl(r0,r18,#2)
		if (p1) jump:nt .LBB12_383
	}
// %bb.380:                             // %do.end2029
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.381:                             // %do.end2029
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_383
	}
// %bb.382:                             // %if.then2031
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #1
		r2 = memw(r16+#0)
	}
	.falign
.LBB12_383:                             // %if.end2034
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r16+#0)
	}
	.falign
// %bb.384:                             // %if.end2034
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_389
	}
// %bb.385:                             // %do.body2040
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.386:                             // %do.body2040
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_389
	}
// %bb.387:                             // %if.then2042
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.388:                             // %if.then2042
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_389:                             // %do.end2048
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r19 = memw(r29+#380)
		memw(r29+#8) = r19.new
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#296)
		memw(r29+#4) = r27
	}                                       // 4-byte Folded Reload
	{
		r23 = memw(r29+#336)
		memw(r29+#0) = r24
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r23,r17)
		r25 = memw(r29+#408)
		r20 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r22,r25)
		r21 = memw(r29+#328)
		r6 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
		r5:4 = combine(r21,r20)
		r16 = or(r6,r18)
	}
	.falign
// %bb.390:                             // %do.end2048
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r1:0 = combine(r23,r17)
		r5:4 = combine(r21,r20)
		r2 = memw(r29+#312)
		memw(r29+#8) = r19
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r24,r2)
		memw(r29+#0) = r2.new
	}
	{
		call moe_expand_chunk
		r3:2 = combine(r22,r25)
		memw(r29+#4) = r27
	}
	.falign
// %bb.391:                             // %do.end2048
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		p1 = cmp.eq(r16,#0); if (!p1.new) jump:t .LBB12_400
		if (p1.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.392:                             // %if.then2057
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#104)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r22+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_396
	}
// %bb.393:                             // %if.then2063
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3:2 = combine(#0,#0)
		r1:0 = memd(r22+#56)
	}
	{
		p3 = cmp.eq(r1:0,r3:2)
		if (p3.new) jump:nt .LBB12_397
		if (!p3.new) r2 = memw(r22+#28)
	}
// %bb.394:                             // %for.body2067.lr.ph
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3 = ##-1431655765
		r2 = add(r2,#23)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r3 = lsr(r2,#4)
		r2 = #0
	}
	{
		r3 = +mpyi(r3,##640)
	}
	.balign 32
.LBB12_395:                             // %for.body2067
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_367 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r5:4 = combine(#-1,#-1)
		r2 = add(r2,r3)
	}
	{
		r5:4 = add(r1:0,r5:4)
	}
	{
		r1:0 = and(r5:4,r1:0)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.eq(r1:0,r5:4)
		if (!p0.new) jump:t .LBB12_395
	}
	{
		jump .LBB12_398
	}
	.falign
.LBB12_396:                             //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#668)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r27)
		jump .LBB12_398
	}
	.falign
.LBB12_397:                             //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = #0
	}
	.falign
.LBB12_398:                             // %do.body2079
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_403
	}
// %bb.399:                             // %if.then2081
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r6 = lsr(r2,#10)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_us@GOT)
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		r7 = r1
	}
	{
		r5 = r7
		r1:0 = memd(r3+#80)
	}
	{
		r1:0 = add(r1:0,r7:6)
		memd(r29+#1688) = r5:4
	}                                       // 8-byte Folded Spill
	{
		memd(r3+#80) = r1:0
	}
	.falign
.LBB12_400:                             // %do.body2091
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_403
	}
// %bb.401:                             // %if.then2093
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.402:                             // %if.then2093
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_403:                             // %do.end2097
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r17 = #0
		r16 = memw(r29+#240)
		r1 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r3 = and(r1,#1)
		r0 = memw(r29+#500)
		r2 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,r24)
		if (!p3.new) r2 = memw(r29+##424)
		memw(r29+#596) = r3
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r0,r3)
		if (!p3) jump:nt .LBB12_439
		if (!p3) r3 = memw(r29+##540)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_404:                             // %do.body2192
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_407
	}
// %bb.405:                             // %if.then2194
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.406:                             // %if.then2194
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_407:                             // %do.end2205
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#588)
		r1 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r18,r2)
		r0 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		p3 = cmp.gtu(r1,r17)
	}
	{
		p0 = and(p0,p3)
		if (!p0.new) jump:t .LBB12_417
		if (p0.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.408:                             // %if.then2214
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_411
	}
// %bb.409:                             // %if.then2227
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.410:                             // %if.then2227
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_411:                             // %do.end2231
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r17<<#2)
	}
	.falign
// %bb.412:                             // %do.end2231
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_415
	}
// %bb.413:                             // %if.then2236
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.414:                             // %if.then2236
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_415:                             // %do.end2242
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r3 = add(r29,#2712)
		r5 = add(r29,#2328)
		r0 = memw(r29+#328)
		memw(r29+#12) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r17,#5)
		r3 = addasl(r5,r17,#3)
		r0 = memw(r29+#408)
		memw(r29+#0) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#644)
		memw(r29+#4) = r22
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r24,r2)
		r2 = add(r29,#5632)
		r0 = memw(r29+#380)
		r6 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r17,#192)
		r7 = memw(r29+#312)
		memw(r29+#8) = r6
	}                                       // 4-byte Folded Reload
	{
		r6 = sub(r7,r4)
		r4 = add(r4,r7)
		memw(r29+#16) = r4
	}
	{
		r4 = memw(r29+#296)
		memw(r29+#20) = r4
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#424)
	}                                       // 4-byte Folded Reload
	{
		r5 = minu(r6,r7)
		memw(r29+#24) = r5.new
	}
	{
		call moe_expand_submit
		r5 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.416:                             // %do.end2242
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r17<<#2) = r3
	}
	.falign
.LBB12_417:                             // %if.end2254
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r21 = add(r18,#1)
		r5 = memw(r29+#620)
		r4 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r18,r5)
		r2 = add(r18,sub(#1,r5))
		p3 = cmp.gtu(r5,r18)
		p0 = cmp.eq(r21,r4)
	}
	{
		r17 = sub(r3,r5)
		if (p3) r2 = #0
		r3 = memw(r29+#440)
		r0 = memw(r29+#660)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		if (p0) r2 = add(r3,#0)
	}
	{
		r19 = minu(r2,r3)
	}
	{
		p1 = cmp.gtu(r19,r17)
	}
	{
		p2 = and(p3,p1)
		if (!p2.new) jump:t .LBB12_428
	}
	.falign
.LBB12_418:                             // %land.rhs2291
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_367 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r20 = add(r17,#8)
		r25 = add(r29,#1752)
	}
	{
		r2 = memw(r25+r20<<#2)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_428
	}
// %bb.419:                             // %for.body2299
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r2 = memw(r29+#244)
		r23 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r26 = memw(r2+#0)
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_422
	}
// %bb.420:                             // %if.then2318
                                        //   in Loop: Header=BB12_418 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.421:                             // %if.then2318
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_422:                             // %do.end2322
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r2 = add(r29,#2008)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r17<<#2)
	}
	.falign
// %bb.423:                             // %do.end2322
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_426
	}
// %bb.424:                             // %if.then2326
                                        //   in Loop: Header=BB12_418 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.425:                             // %if.then2326
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r2 = memw(r23+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_426:                             // %do.end2332
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r3 = add(r29,#2712)
		r5 = add(r29,#2328)
		r8 = memw(r29+#304)
		r2 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#5632)
		r7 = memw(r29+#308)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Reload
	{
		r4 = mpyi(r17,r8)
		r2 += mpyi(r20,#192)
		r1:0 = memd(r29+#1704)
		memw(r29+#16) = r4.new
	}                                       // 8-byte Folded Reload
	{
		r1 = addasl(r3,r20,#5)
		r4 = sub(r7,r4)
		r6 = memw(r29+#260)
		memw(r29+#0) = r1
	}                                       // 4-byte Folded Reload
	{
		r4 = minu(r4,r8)
		r3 = addasl(r5,r20,#3)
		r0 = memw(r29+#380)
		memw(r29+#24) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r6 += mpyi(r26,#96)
		r20 = addasl(r25,r20,#2)
		r4 = memw(r29+#296)
		r5 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#12) = r7
		memw(r29+#20) = #-1
	}
	{
		call moe_expand_submit
		memw(r29+#4) = r6
	}
	.falign
// %bb.427:                             // %do.end2332
                                        //   in Loop: Header=BB12_418 Depth=3
	{
		r17 = add(r17,#1)
		memw(r20+#0) = #1
	}
	{
		p3 = cmp.gtu(r19,r17)
		if (p3.new) jump:t .LBB12_418
	}
	.falign
.LBB12_428:                             // %for.cond.cleanup2298
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_431
	}
// %bb.429:                             // %if.then2349
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.430:                             // %if.then2349
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_431:                             // %do.end2353
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.432:                             // %do.end2353
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_435
	}
// %bb.433:                             // %if.then2356
                                        //   in Loop: Header=BB12_367 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.434:                             // %if.then2356
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		p1 = cmp.eq(r18,#0)
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r3 = mux(p1,#120,#16)
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+r3<<#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+r3<<#0) = r1:0
	}
	.falign
.LBB12_435:                             // %do.end2366
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r17 = add(r29,#3224)
		r3 = memw(r29+#596)
		r2 = memw(r22+#20)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		if (!p2.new) r1 = add(r29,##2456)
		r0 = memw(r29+#624)
	}                                       // 4-byte Folded Reload
	{
		r17 += mpyi(r3,##324)
	}
	{
		if (!p2) r0 = add(r17,#68)
		if (p2) jump:nt .LBB12_437
		memw(r17+#60) = r0
		memw(r17+#64) = r2
	}
// %bb.436:                             // %if.then2375
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		call memcpy
		r2 = memw(r29+#672)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_437:                             // %for.inc2400
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r4 = memw(r29+#412)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r16)
		r5 = memw(r29+#532)
		r1:0 = memd(r22+#8)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r4+#8)
		memw(r17+#4) = r5

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		memw(r17+#8) = r27
		memw(r17+#12) = r24
	}
	{
		r3 = memw(r29+#256)
		memw(r17+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r4+#12)
		memw(r17+#20) = r3

	} :mem_noshuf
	{
		r3 = memw(r29+#656)
		memw(r17+#36) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r22+#16)
		memw(r17+#24) = r3
	}
	{
		r3 = memw(r29+#552)
		memw(r17+#40) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_gu_worker@PCREL)
		r0 = memw(r29+#380)
		memw(r17+#32) = r1
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#272)
		memw(r17+#28) = r3
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r27,r17)
		r7 = memw(r29+#508)
		memw(r17+#16) = r2
	}                                       // 4-byte Folded Reload
	{
		memw(r17+#44) = r6
		memw(r17+#52) = r6
	}
	{
		r6 = memw(r29+#376)
		memw(r17+#48) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		memw(r17+#56) = r6
	}
	.falign
// %bb.438:                             // %for.inc2400
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r18 = r21
		r3 = memw(r29+#424)
		r2 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r3)
		r1 = memw(r29+#480)
		r0 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r2,r24)
		r2 = add(r1,#1)
		memw(r29+#480) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = sub(r0,r3)
		if (p3) jump:nt .LBB12_367
		memw(r29+#540) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_352
	}
	.falign
.LBB12_439:                             // %for.body2104.lr.ph
                                        //   in Loop: Header=BB12_367 Depth=2
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r2,#1)
		r3 = add(r24,r3)
	}
	{
		r20 = sub(r3,r27)
		r3 = #1
	}
	{
		r19 = maxu(r2,r3)
	}
	.falign
.LBB12_440:                             // %for.body2104
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_367 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_450 Depth 4
                                        //         Child Loop BB12_445 Depth 4
	{
		p1 = cmp.gtu(r27,r17)
	}
	{
		r2 = mux(p1,r24,r20)
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r23 = add(r17,r2)
	}
	.falign
// %bb.441:                             // %for.body2104
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = memw(r29+#264)
		r0 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		p1 = cmp.gtu(r2,#31)
		if (!p3.new) jump:t .LBB12_448
	}
// %bb.442:                             // %if.then2116
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		if (!p1) jump:nt .LBB12_453
		r3 = memw(r29+#296)
		if (p1) r4 = memw(r29+##320)
	}                                       // 4-byte Folded Reload
// %bb.443:                             // %for.body2127.preheader
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = memw(r29+#600)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r23,#9)
		r5 = lsr(r4,#1)
		r4 = and(r4,#1)
	}
	{
		p2 = cmp.gtu(r5,#0)
		if (!p2.new) jump:t .LBB12_446
	}
// %bb.444:                             //   in Loop: Header=BB12_440 Depth=3
	{
		loop0(.LBB12_445,r5)
	}
	.falign
.LBB12_445:                             //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_367 Depth=2
                                        //       Parent Loop BB12_440 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7 = #31
		r8 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r5 = add(r3,#2048)
		r6 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r6)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r3 = add(r3,#4096)
		r2 = add(r2,r6)
	} :endloop0
	.falign
.LBB12_446:                             //   in Loop: Header=BB12_440 Depth=3
	{
		r5 = #384
		p3 = cmp.gtu(r4,#0)
		if (p3.new) r4 = #31
		if (!p3.new) jump:t .LBB12_453
	}
	.falign
.LBB12_447:                             // Block address taken
                                        // %for.body2127
                                        //   in Loop: Header=BB12_440 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	{
		jump .LBB12_453
	}
	.falign
.LBB12_448:                             // %for.cond2137.preheader
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		if (p1) r26 = #0
		if (!p1) jump:nt .LBB12_453
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
// %bb.449:                             // %for.body2141.preheader
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r21 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r21 += asl(r23,#9)
		r23 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_450:                             // %for.body2141
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_367 Depth=2
                                        //       Parent Loop BB12_440 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r26
		r2 = r21
	}
	.falign
// %bb.451:                             // %for.body2141
                                        //   in Loop: Header=BB12_450 Depth=4
	{
		r26 = add(r26,#2048)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB12_602
		if (p1.new) r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.452:                             // %for.cond2137
                                        //   in Loop: Header=BB12_450 Depth=4
	{
		r21 = add(r21,r2)
		r23 = add(r23,#-1)
		r0 = memw(r29+#296)
		if (!cmp.eq(r23.new,#0)) jump:t .LBB12_450
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_453:                             // %do.body2161
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_456
	}
// %bb.454:                             // %if.then2163
                                        //   in Loop: Header=BB12_440 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.455:                             // %if.then2163
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_456:                             // %do.end2167
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r21 = #0
		r2 = r16
		r3 = memw(r29+#560)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r3,#0)
		r3 = memw(r29+#532)
		if (!p3.new) r6 = memw(r29+##560)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r17,r3)
		if (p3) jump:nt .LBB12_458
		if (!p3) r3 = memw(r29+##296)
	}                                       // 4-byte Folded Reload
// %bb.457:                             // %if.then.i5321
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = add(r3,r2)
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_460
		v0 = vmem(r2+#0)
	}
	.falign
.LBB12_458:                             // %if.end.i5324
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#296)
		r1 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.459:                             // %if.end.i5324
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r21 = r0
	}
	.falign
.LBB12_460:                             // %moe_acc_read.exit
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_463
	}
// %bb.461:                             // %if.then2173
                                        //   in Loop: Header=BB12_440 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.462:                             // %if.then2173
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_463:                             // %do.end2179
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r0 = r21
		p1 = cmp.eq(r21,#0); if (!p1.new) jump:nt .LBB12_602
	}
// %bb.464:                             // %for.cond2099
                                        //   in Loop: Header=BB12_440 Depth=3
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r19)) jump:t .LBB12_440
	}
	{
		jump .LBB12_404
	}
	.falign
.LBB12_465:                             // %do.body2456
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_468
	}
// %bb.466:                             // %if.then2458
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.467:                             // %if.then2458
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_468:                             // %do.end2462
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.469:                             // %do.end2462
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_472
	}
// %bb.470:                             // %if.then2465
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.471:                             // %if.then2465
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_472:                             // %do.end2471
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r17 = add(r29,#808)
		r3:2 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		call memset
		r1:0 = combine(r3,r17)
		r2 = #856
	}
	.falign
// %bb.473:                             // %do.end2471
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#256)
		memw(r29+#1668) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#508)
		memw(r29+#1664) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#4,r17)
		r6 = memw(r29+#612)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#608)
		memw(r29+#1676) = r6
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#272)
		memw(r29+#1672) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#544)
		memw(r29+#1680) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		memw(r29+#1684) = r6
	}
	.falign
// %bb.474:                             // %do.end2471
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		jump .LBB12_495
	}
	.falign
.LBB12_475:                             //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = #0
		memw(r29+#484) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_476:                             // %cond.end2510
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r1 = memw(r29+#568)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#472)
		r0 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r17 = memw(r2+#0)
		if (p3.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
	{
		if (!p3) jump:nt .LBB12_484
		r16 = memw(r1+r3<<#2)
	}
// %bb.477:                             // %do.body2514
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_480
	}
// %bb.478:                             // %if.then2516
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.479:                             // %if.then2516
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_480:                             // %do.end2520
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.481:                             // %do.end2520
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_484
	}
// %bb.482:                             // %if.then2523
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.483:                             // %if.then2523
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_484:                             // %if.end2530
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
	}
	{
		r2 = p2
		if (p2) jump:nt .LBB12_492
		memw(r29+#592) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.485:                             // %do.body2533
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_488
	}
// %bb.486:                             // %if.then2535
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.487:                             // %if.then2535
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_488:                             // %do.end2539
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r3 = memw(r29+#472)
		r2 = memw(r29+#616)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#640)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r2 = #-1
		r3 = memw(r2+r3<<#2)
	}
	{
		r1 += mpyi(r3,#96)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.489:                             // %do.end2539
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_492
	}
// %bb.490:                             // %if.then2548
                                        //   in Loop: Header=BB12_332 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.491:                             // %if.then2548
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_492:                             // %if.end2555
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r22 = memw(r29+#260)
		r0 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r22 += mpyi(r17,#96)
		r2 = memw(r29+#352)
		r3 = memw(r29+#544)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,#1)
		memw(r29+#556) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r17 = togglebit(r2,#0)
		r1 = memw(r22+#20)
	}
	{
		r3 += mpyi(r17,r0)
		p3 = cmp.eq(r1,#0)
		if (p3.new) jump:nt .LBB12_494
		memw(r29+#540) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.493:                             // %if.then2558
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r4 = add(r29,#2456)
		r3 = memw(r29+#608)
		r0 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r17,#8)
		call hexkl_wh_affine_sums
		r1 = memw(r29+#492)
		r2 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_494:                             // %if.end2567
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r27 = #0
		r2 = memw(r29+#276)
		if (cmp.gtu(r2.new,#31)) jump:t .LBB12_502
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_495:                             // %if.end3027
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r16 = add(r29,##2008)
		if (p1.new) jump:nt .LBB12_839
	}
// %bb.496:                             // %if.end3030
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r25 = memw(r29+#452)
		r2 = memw(r29+#536)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,r25)
		r21 = memw(r29+#308)
		r22 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB12_501
		r23 = memw(r29+#304)
		r24 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
// %bb.497:                             // %if.then3034
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r2 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#31)
		if (p2.new) r20 = #0
		if (!p2.new) jump:t .LBB12_501
	}
// %bb.498:                             //   in Loop: Header=BB12_332 Depth=1
	{
		r19:18 = combine(r21,#0)
		r2 = memw(r29+#284)
		r3 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r3<<#2)
	}
	{
		r17 += mpyi(r2,#96)
	}
	.falign
.LBB12_499:                             // %for.body3045
                                        //   Parent Loop BB12_332 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = minu(r19,r23)
		r1 = r24
		r0 = memw(r29+#296)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r21,r22)
		r3:2 = memd(r29+#1704)
		memw(r29+#16) = r20
	}                                       // 8-byte Folded Reload
	{
		r2 = r3
		r3 = r17
		memw(r29+#12) = r25
		memw(r29+#0) = r18
	}
	{
		call moe_push_weight_chunk
		memw(r29+#8) = #3
	}
	.falign
// %bb.500:                             // %for.body3045
                                        //   in Loop: Header=BB12_499 Depth=2
	{
		r16 = add(r16,#4)
		r20 = add(r20,#1)
		r18 = add(r18,r23)
		memw(r16+#0) = r0
	}
	{
		r19 = sub(r19,r23)
		p1 = cmp.gtu(r21,r18); if (p1.new) jump:t .LBB12_499
	}
	.falign
.LBB12_501:                             // %for.inc3072
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r0 = memw(r29+#504)
		memw(r29+#472) = r25
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r0 = memw(r29+#368)
		memw(r29+#476) = r0.new
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p2)
		r2 = memw(r29+#352)
		memw(r29+#536) = r25
	}                                       // 4-byte Folded Reload
	{
		r1 = p2
		r2 = add(r2,#1)
		r0 = memw(r29+#256)
		memw(r29+#504) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#468)
		memw(r29+#572) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#404)
		memw(r29+#492) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#400)
		memw(r29+#352) = r2
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#488)
		memw(r29+#524) = r1
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_332
		memw(r29+#548) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_502:                             // %for.body2573.lr.ph
                                        //   in Loop: Header=BB12_332 Depth=1
	{
		r18 = #0
		r9 = memw(r29+#492)
		r12 = memw(r29+#544)
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r9,#2)
		r0 = memw(r29+#524)
		r6 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r0,#0)
		r1 = memw(r29+#360)
		r7 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r1 = p3
		p1 = cmp.eq(r1,#0)
		p0 = cmp.eq(r7,#0)
		r7 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p0)
		p0 = r7
		r3 = memw(r29+#568)
		r8 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r2 = +mpyi(r6,#1)
		p1 = not(p1)
		r4 = memw(r29+#472)
		memw(r29+#688) = r1
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r4,#2)
		p1 = and(p1,and(p0,p2))
		r7 = memw(r29+#612)
		memw(r29+#692) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r4 = asl(r8,#8)
		r0 = p1
		r3 = add(r9,#3)
		memw(r29+#660) = r0.new
	}                                       // 4-byte Folded Spill
	{
		p0 = and(p0,!p3)
		r3 = lsr(r3,#2)
		r1 = add(r7,r4)
		memw(r29+#700) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r12 += mpyi(r8,r6)
		r0 = p0
		r15 = memw(r29+#608)
		memw(r29+#596) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r17,#8)
		r4 = add(r15,r4)
		r1:0 = memd(r29+#1688)
		memw(r29+#656) = r5
	}                                       // 8-byte Folded Reload
	{
		r0 = memw(r29+#504)
		memw(r29+#664) = r3
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		if (!p3.new) r2 = add(r1,#0)
		r0 = memw(r29+#300)
		memw(r29+#704) = r4
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r0,r16,#2)
		r1 = memw(r29+#344)
		memw(r29+#696) = r12
	}                                       // 4-byte Folded Reload
	{
		r4 = addasl(r1,r16,#2)
		r1 = #4
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r2)
		r0 = add(r7,r5)
		memw(r29+#552) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = maxu(r9,r1)
		r1 = add(r15,r5)
		r0 = memw(r29+#572)
		memw(r29+#672) = r0
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r0,#2)
		r2 = addasl(r4,r0,#2)
		memw(r29+#708) = r2
		memw(r29+#676) = r1
	}                                       // 4-byte Folded Spill
	{
		r1 = memw(r29+#324)
		r0 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#680) = r3
		memw(r29+#684) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#472) = r1
		memw(r29+#524) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_503:                             // %for.body2573
                                        //   Parent Loop BB12_332 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_571 Depth 3
                                        //         Child Loop BB12_580 Depth 4
                                        //         Child Loop BB12_576 Depth 4
	{
		r17 = memw(r29+#512)
		r16 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.504:                             // %for.body2573
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		p3 = cmp.gtu(r16,r17)
		r1 = add(r29,#2072)
		r21 = r0
		r2 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r0,#5)
		p2 = r2
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = or(p2,p3)
		if (p0.new) jump:t .LBB12_512
		if (!p0.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.505:                             // %do.body2592
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_508
	}
// %bb.506:                             // %if.then2594
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.507:                             // %if.then2594
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_508:                             // %do.end2598
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		call hvx_worker_pool_wait_bg
		r2 = #-1
		r0 = memw(r29+#380)
		r1 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.509:                             // %do.end2598
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_512
	}
// %bb.510:                             // %if.then2602
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.511:                             // %if.then2602
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_512:                             // %if.end2609
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#308)
		r3 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r27)
		r0 = memw(r29+#596)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r3)
		p3 = r0
		if (!p3.new) jump:t .LBB12_522
		memw(r29+#548) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.513:                             // %land.lhs.true2620
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r16 = add(r18,#8)
		r17 = add(r29,#1752)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r17+r16<<#2)
	}
	{
		p3 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p3) jump:nt .LBB12_524
		r2 = memw(r3+#0)
	}
// %bb.514:                             // %do.body2625
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB12_517
	}
// %bb.515:                             // %if.then2627
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.516:                             // %if.then2627
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_517:                             // %do.end2631
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r16,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.518:                             // %do.end2631
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_521
	}
// %bb.519:                             // %if.then2636
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.520:                             // %if.then2636
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_521:                             // %do.end2642
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = addasl(r17,r16,#2)
	}
	{
		jump .LBB12_535
		memw(r2+#0) = #0
	}
	.falign
.LBB12_522:                             // %if.else2645
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#688)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_535
		if (!p0.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.523:                             // %if.else2645.do.body2649_crit_edge
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_524:                             // %do.body2649
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r0 = add(r29,#2008)
		p1 = cmp.eq(r2,#0)
	}
	{
		r16 = addasl(r0,r18,#2)
		if (p1) jump:nt .LBB12_528
	}
// %bb.525:                             // %do.end2655
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.526:                             // %do.end2655
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_528
	}
// %bb.527:                             // %if.then2657
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #2
		r2 = memw(r16+#0)
	}
	.falign
.LBB12_528:                             // %if.end2660
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r16+#0)
	}
	.falign
// %bb.529:                             // %if.end2660
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_534
	}
// %bb.530:                             // %do.body2666
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.531:                             // %do.body2666
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_534
	}
// %bb.532:                             // %if.then2668
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.533:                             // %if.then2668
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_534:                             // %do.end2674
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r0 = memw(r29+#548)
		memw(r29+#4) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#380)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#296)
		memw(r29+#0) = r27
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1704)
		r1 = memw(r29+#324)
	}                                       // 8-byte Folded Reload
	{
		r2 = r3
		r3 = r22
		r4 = memw(r29+#316)
		r5 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
	}
	.falign
.LBB12_535:                             // %do.body2678
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_538
	}
// %bb.536:                             // %if.then2680
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.537:                             // %if.then2680
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_538:                             // %do.end2684
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r17 = #0
		r2 = memw(r29+#308)
		r20 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,r27)
		r0 = memw(r29+#500)
		if (!p3.new) r2 = memw(r29+##304)
	}                                       // 4-byte Folded Reload
	{
		r20 += mpyi(r0,r21)
		if (!p3) r0 = #1
		if (!p3) jump:nt .LBB12_570
	}
	.falign
.LBB12_539:                             // %do.body2774
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_542
	}
// %bb.540:                             // %if.then2776
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.541:                             // %if.then2776
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_542:                             // %do.end2787
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#588)
		r0 = memw(r29+#660)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		p0 = cmp.gtu(r2,r18)
	}
	{
		p2 = and(p2,p0)
		if (!p2.new) jump:t .LBB12_552
		if (p2.new) r3 = memw(r29+##384)
	}                                       // 4-byte Folded Reload
// %bb.543:                             // %if.then2797
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#288)
		r0 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+r3<<#2)
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_546
	}
// %bb.544:                             // %if.then2815
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.545:                             // %if.then2815
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_546:                             // %do.end2819
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r18<<#2)
	}
	.falign
// %bb.547:                             // %do.end2819
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_550
	}
// %bb.548:                             // %if.then2823
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.549:                             // %if.then2823
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_550:                             // %do.end2829
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = add(r29,#5632)
		r4 = add(r29,#2712)
		r9 = memw(r29+#424)
		r1 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r18,#192)
		r6 = add(r29,#2328)
		r5 = memw(r29+#328)
		memw(r29+#12) = r5.new
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r18,r9)
		r5 = memw(r29+#260)
		r8 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r5 += mpyi(r16,#96)
		r0 = add(r3,r8)
		r7 = memw(r29+#320)
		memw(r29+#8) = r7.new
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r18,#5)
		r7 = sub(r8,r3)
		memw(r29+#0) = r1
		memw(r29+#20) = r0
	}
	{
		r3 = addasl(r6,r18,#3)
		r6 = minu(r7,r9)
		memw(r29+#16) = r3
		memw(r29+#4) = r5
	}
	{
		r0 = memw(r29+#380)
		memw(r29+#24) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_submit
		r4 = memw(r29+#296)
		r5 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.551:                             // %do.end2829
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r18<<#2) = r3
	}
	.falign
.LBB12_552:                             // %if.end2837
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r25 = add(r29,#8704)
		r1 = #880
		p1 = cmp.eq(r18,#0)
		r0 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		r25 += mpyi(r21,r1)
		p2 = r0
	}
	{
		r2 = p1
		if (p2) jump:nt .LBB12_563
		memw(r29+#572) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.553:                             // %if.end2837
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#572)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:nt .LBB12_563
		if (p3.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.554:                             // %do.body2843
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_557
	}
// %bb.555:                             // %if.then2845
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.556:                             // %if.then2845
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_557:                             // %do.end2849
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.558:                             // %do.end2849
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_561
	}
// %bb.559:                             // %if.then2852
                                        //   in Loop: Header=BB12_503 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.560:                             // %if.then2852
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_561:                             // %do.end2858
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = add(r29,#3872)
		r6 = #880
		r3 = memw(r29+#604)
		r5 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		r4 = memw(r29+#508)
		r7 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r5,r4)
		r5 = memw(r29+#700)
		r4 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r7,r6)
		r6 = memw(r29+#696)
		r7 = memw(r29+#704)
	}                                       // 4-byte Folded Reload
	{
		r3 = mux(p2,r25,r2)
		r7:6 = combine(r6,r7)
	}
	{
		memd(r3+#856) = r1:0
		memd(r3+#864) = r5:4
	}
	{
		if (!p2) r3 = #4
		if (p2) jump:nt .LBB12_563
		memw(r3+#12) = #0
		memd(r3+#872) = r7:6
	}
// %bb.562:                             // %if.then2887
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
	}
	.falign
.LBB12_563:                             // %if.end2889
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r16 = add(r29,#8704)
		r3 = #880
		r2 = memw(r22+#20)
		r0 = memw(r29+#632)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r21,r3)
		r1:0 = combine(r2,r0)
		p1 = cmp.eq(r2,#0)
	}
	{
		if (!p1) r1 = add(r29,##2456)
		if (p1) jump:nt .LBB12_565
		memd(r16+#544) = r1:0
	}
// %bb.564:                             // %if.then2898
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		call memcpy
		r0 = add(r16,#552)
		r2 = memw(r29+#656)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_565:                             // %if.end2904
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r17 = add(r16,#32)
		r4 = memw(r29+#412)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r20)
		r5 = memw(r29+#548)
		r6 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r5,r27)
		r3 = memw(r4+#8)
		memw(r16+#4) = r6

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		memd(r16+#8) = r1:0
	}
	{
		memw(r25+#0) = r2
		r2 = memw(r4+#12)

	} :mem_noshuf
	{
		r0 = memw(r29+#492)
		r19 = memw(r29+#656)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r0,r2)
		r0 = r17
		r2 = r19
		r1 = memw(r29+#672)
	}                                       // 4-byte Folded Reload
	{
		call memcpy
		memd(r16+#16) = r5:4
	}
	.falign
// %bb.566:                             // %if.end2904
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r24 = add(r16,#288)
		r2 = r19
		r1 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		call memcpy
		r0 = r24
	}
	.falign
// %bb.567:                             // %if.end2904
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r1:0 = combine(r24,r17)
		r3:2 = memd(r22+#8)
	}
	{
		r3:2 = combine(r2,r3)
		r0 = r27
		r1 = memw(r29+#304)
		memd(r16+#24) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r22+#16)
		memd(r16+#808) = r3:2
	}
	{
		r2 = memw(r29+#564)
		memw(r16+#816) = r2
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		memw(r16+#820) = r2
	}
	.falign
// %bb.568:                             // %if.end2904
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r2 = memw(r29+#580)
		r3 = memw(r29+#680)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r2 += mpyi(r0,r4)
	}
	{
		r1:0 = combine(r3,r2)
		r2 = memw(r29+#276)
		r3 = memw(r29+#684)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		r0 = memw(r29+#592)
		memd(r16+#824) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		if (p1.new) jump:nt .LBB12_595
		memd(r16+#832) = r3:2
	}
// %bb.569:                             // %if.then2947
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r3 = memw(r29+#280)
		r2 = memw(r29+#692)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#476)
		r7 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		r5 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r2,#2)
		r4 = memw(r3+r4<<#2)
		r6 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r6,r2,#2)
		r3 = memw(r7+#28)
	}
	{
		r6 = sub(r4,r3)
		r4 = memw(r7+#24)
	}
	{
		r5 = addasl(r5,r6,#2)
		r6 = addasl(r2,r6,#2)
		jump .LBB12_596
	}
	.falign
.LBB12_570:                             //   in Loop: Header=BB12_503 Depth=2
	{
		r3 = memw(r29+#524)
		r19 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r3,r2)
	}
	{
		r16 = maxu(r2,r0)
	}
	.falign
.LBB12_571:                             // %for.body2690
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_503 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_580 Depth 4
                                        //         Child Loop BB12_576 Depth 4
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.572:                             // %for.body2690
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) r26 = add(r19,#0)
		if (p0.new) r4 = add(r17,r27)
		if (!p0.new) jump:t .LBB12_579
	}
// %bb.573:                             // %if.then2692
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#272)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_583
	}                                       // 4-byte Folded Reload
// %bb.574:                             // %for.body2709.preheader
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r3 = memw(r29+#316)
		r2 = memw(r29+#628)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r4,#9)
		r5 = lsr(r3,#1)
		r3 = and(r3,#1)
		r4 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r5,#0)
		if (!p3.new) jump:t .LBB12_577
	}
// %bb.575:                             //   in Loop: Header=BB12_571 Depth=3
	{
		loop0(.LBB12_576,r5)
	}
	.falign
.LBB12_576:                             //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_503 Depth=2
                                        //       Parent Loop BB12_571 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7 = #31
		r8 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r5 = add(r4,#2048)
		r6 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r6)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r4 = add(r4,#4096)
		r2 = add(r2,r6)
	} :endloop0
	.falign
.LBB12_577:                             //   in Loop: Header=BB12_571 Depth=3
	{
		r5 = #384
		if (p0.new) r3 = #31
		p0 = cmp.gtu(r3,#0); if (!p0.new) jump:t .LBB12_583
	}
	.falign
.LBB12_578:                             // Block address taken
                                        // %for.body2709
                                        //   in Loop: Header=BB12_571 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r3):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	{
		jump .LBB12_583
	}
	.falign
.LBB12_579:                             // %for.cond2719.preheader
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#272)
		r24 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#31)
		if (!p2.new) jump:t .LBB12_583
		r23 = memw(r29+#316)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_580:                             // %for.body2723
                                        //   Parent Loop BB12_332 Depth=1
                                        //     Parent Loop BB12_503 Depth=2
                                        //       Parent Loop BB12_571 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r24
		r2 = r26
	}
	.falign
// %bb.581:                             // %for.body2723
                                        //   in Loop: Header=BB12_580 Depth=4
	{
		r24 = add(r24,#2048)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB12_638
	}
// %bb.582:                             // %for.cond2719
                                        //   in Loop: Header=BB12_580 Depth=4
	{
		r2 = memw(r29+#444)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r26 = add(r26,r2)
		r23 = add(r23,#-1)
		if (!cmp.eq(r23.new,#0)) jump:t .LBB12_580
	}
	.falign
.LBB12_583:                             // %do.body2746
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_586
	}
// %bb.584:                             // %if.then2748
                                        //   in Loop: Header=BB12_571 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.585:                             // %if.then2748
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_586:                             // %do.end2752
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r23 = #0
		r2 = r20
		r3 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r3,#0)
		r3 = memw(r29+#532)
		if (!p0.new) r1:0 = memd(r29+##1688)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r17,r3)
		if (p0) jump:nt .LBB12_588
		if (!p0) r3 = memw(r29+##296)
	}                                       // 4-byte Folded Reload
// %bb.587:                             // %if.then.i5350
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = add(r3,r2)
		r6 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_590
		v1 = vmem(r2+#0)
	}
	.falign
.LBB12_588:                             // %if.end.i5358
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#296)
		r1 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.589:                             // %if.end.i5358
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r23 = r0
	}
	.falign
.LBB12_590:                             // %moe_acc_read.exit5360
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_593
	}
// %bb.591:                             // %if.then2758
                                        //   in Loop: Header=BB12_571 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.592:                             // %if.then2758
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_593:                             // %do.end2764
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r19 = add(r19,#512)
		r0 = r23
		p1 = cmp.eq(r23,#0); if (!p1.new) jump:nt .LBB12_638
	}
// %bb.594:                             // %for.cond2686
                                        //   in Loop: Header=BB12_571 Depth=3
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r16)) jump:t .LBB12_571
	}
	{
		jump .LBB12_539
	}
	.falign
.LBB12_595:                             //   in Loop: Header=BB12_503 Depth=2
	{
		r5:4 = combine(#0,#0)
		r3 = #0
		r6 = #0
	}
	.falign
.LBB12_596:                             // %if.end2967
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r1:0 = combine(r5,r4)
		r5:4 = combine(r3,r6)
		r3 = add(r29,#2072)
		r2 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r29,#2200)
		r7 = memw(r29+#572)
		memd(r16+#840) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_dn_unit@PCREL)
		r6 = addasl(r0,r21,#5)
		r8 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r21,#5)
		p2 = r7
		r0 = memw(r29+#604)
		r7 = memw(r29+#664)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		if (!p2) r2 = #0
		r1:0 = combine(r6,r7)
		memw(r8+#0) = r1
	}
	{
		r4 = setbit(r3,#2)
		if (!p3) r2 = #0
		r6 = memw(r29+#436)
		memd(r16+#848) = r5:4
	}                                       // 4-byte Folded Reload
	{
		p0 = r6
		if (p0.new) r2 = #0
		r3 = memw(r29+#496)
		memd(r3+#8) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) jump:t .LBB12_599
		memw(r16+#856) = r2
		memw(r4+#0) = r25
	}
// %bb.597:                             // %if.then2991
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r1 = add(pc,##moe_dn_fg_worker@PCREL)
		p2 = cmp.eq(r2,#0)
		r2 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#708)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r3 = mux(p2,r2,r4)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.598:                             // %if.then2991
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		jump .LBB12_601
	}
	.falign
.LBB12_599:                             // %if.else3003
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r16 = memw(r29+#244)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit_bg
		r1 = r16
	}
	.falign
// %bb.600:                             // %if.else3003
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		memw(r29+#528) = r16
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_601:                             // %for.inc3011
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r18 = add(r18,#1)
		r3 = memw(r29+#304)
		r1 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r27,r3)
		r2 = memw(r29+#308)
		r0 = memw(r29+#524)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r2,r27)
		r2 = add(r1,#1)
		r1 = memw(r29+#636)
		memw(r29+#512) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r0,r3)
		r0 = memw(r29+#472)
		memw(r29+#524) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		if (p3) jump:nt .LBB12_503
		memw(r29+#472) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_495
	}
	.falign
.LBB12_602:                             // %cleanup2446
	{
		r17 = r0 ; jump .LBB12_639
	}
	.falign
.LBB12_603:                             // %if.else1013
	{
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) r2 = #2
		if (!p3.new) jump:t .LBB12_299
		if (p3.new) r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.604:                             // %for.cond1017.preheader
	{
		r20 = #0
		r16 = add(r29,#1880)
		r18 = memw(r29+#372)
		r23 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r21 = minu(r3,r2)
		r24 = memw(r29+#328)
		r25 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_605:                             // %for.body1026
                                        // =>This Inner Loop Header: Depth=1
	{
		p0 = tstbit(r20,#0)
		r3 = r23
		r2 = memw(r18+#0)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p0,r19,#0)
		r5:4 = combine(#1,r24)
		r18 = add(r18,#4)
	}
	{
		r6 = memw(r25+r2<<#2)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#0) = r20
	}
	{
		r2 += mpyi(r6,#96)
		call moe_m1_push
	}
	.falign
// %bb.606:                             // %for.body1026
                                        //   in Loop: Header=BB12_605 Depth=1
	{
		r16 = add(r16,#4)
		r20 = add(r20,#1)
		r21 = add(r21,#-1)
		memw(r16+#0) = r0
	}
	{
		p1 = cmp.eq(r21,#0); if (!p1.new) jump:t .LBB12_605
	}
	{
		jump .LBB12_299
	}
	.falign
.LBB12_607:                             // %if.else1193.peel
	{
		r2 = memw(r29+#448)
		r0 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#264)
		r19 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+#0)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#552)
		r5 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r16,#2)
		r2 = #0
		r17 = memw(r2+#0)
		r3 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r16,#2)
		r19 += mpyi(r16,r4)
		r6 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r6,r16,#2)
		r3 = memw(r3+r17<<#2)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		call hvx_quant_pack_u8_ah_rows
		memw(r29+#4) = r19
	}
	.falign
.LBB12_608:                             // %if.end1203.peel
	{
		r2 = memw(r29+#304)
		memw(r29+##8704) = r19
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r2,#8236)
		r2 = memw(r29+#288)
		memw(r29+#256) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#284)
		r4 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r2 = r4
		r3 = memw(r2+r17<<#2)
		r6 = memw(r6+#0)
	}
	{
		p0 = cmp.eq(r6,#0)
		if (!p0.new) r19 = add(r29,##8704)
		r5 = memw(r5+r17<<#2)
	}
	{
		r2 += mpyi(r3,#96)
		memw(r29+##8708) = r2.new
	}
	{
		r4 += mpyi(r5,#96)
		if (p0) jump:nt .LBB12_612
		memw(r29+##8712) = r4.new
	}
// %bb.609:                             // %land.lhs.true1215.peel
	{
		r0 = add(r2,#88)
		r3 = memw(r2+#44)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_612
	}
// %bb.610:                             // %if.then1219.peel
	{
		call hvx_expand_i2i4_table
		r1 = add(r19,#128)
	}
	.falign
// %bb.611:                             // %if.then1219.peel
	{
		r1 = add(r19,#256)
		r2 = memw(r29+##8712)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
.LBB12_612:                             // %if.end1228.peel
	{
		r2 = memw(r29+##8708)
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r4 = r5
		r3 = memw(r29+#352)
		r12 = memw(r29+#644)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) r3 = memw(r29+##8712)
		r6 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r4 = memw(r2+#4)
		r7 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r5 = memw(r3+#4)
		memw(r29+##8732) = r12

	} :mem_noshuf
	{
		r4 = add(r29,#8760)
		r3 = memw(r29+#540)
		memw(r29+##8716) = r4
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r12,r3)
		r8 = memw(r29+#464)
		memw(r29+##8736) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r3,r7)
		r15:14 = memd(r29+#1720)
		memw(r29+##8720) = r5
	}                                       // 8-byte Folded Reload
	{
		r1 = memw(r6+r17<<#2)
		r6 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r16,#2)
		r3 = memw(r29+#456)
		memw(r29+##8724) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#536)
		memw(r29+##8740) = r7
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r7,r6)
		r7 = memw(r29+#240)
		memw(r29+##9092) = r1
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r6,r8)
		memw(r29+##8744) = r6
	}
	{
		r7 = memw(r7+#0)
		memw(r29+##8748) = r6
	}
	{
		r7 = add(r7,r14)
		memw(r29+##9088) = r7.new
	}
	{
		r3 = addasl(r3,r16,#2)
		r7 = add(r6,#256)
		memw(r29+##8728) = r3.new
	}
	{
		memw(r29+##8752) = r7
	}
	{
		r6 = add(r7,#256)
		memw(r29+##8756) = r6.new
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_614
	}
// %bb.613:                             // %if.then1274.peel
	{
		call hexkl_wh_affine_sums
		r0 = memw(r29+##8704)
		r2 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_614:                             // %if.end1279.peel
	{
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#1)
		r2 = memw(r29+#260)
		if (!p2.new) r28 = memw(r29+##536)
	}                                       // 4-byte Folded Reload
	{
		r3 = p2
		if (!p2) r27 = #1
		if (p2) jump:nt .LBB12_631
		memw(r29+#336) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.615:                             // %for.body1174.preheader
	{
		r4 = extractu(r28,#24,#7)
		r9 = add(r29,#8704)
		r3 = memw(r29+#308)
		r1:0 = memd(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#22,#0)
		r4 = asl(r4,#8)
		r14 = memw(r29+#464)
		r7 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	{
		r3 = asl(r3,#10)
		r5 = add(r14,r14)
		r6 = memw(r29+#384)
		r8 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		r7 = lsr(r7,#7)
		r17 = add(r6,r0)
		r22 = memw(r29+#656)
		r12 = memw(r29+#1688)
	}                                       // 4-byte Folded Reload
	{
		r21 += mpyi(r7,r18)
		r7 = add(r5,r3)
		r6 = r28
		r15 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		r12 = asl(r12,#12)
		r8 = add(r14,r8)
		r13 = add(r7,r28)
		r11 = add(r22,#512)
	}
	{
		r28 += add(r5,r15)
		r6 += add(r8,r15)
		r7 = add(r7,r4)
		r5 = memw(r29+#612)
	}                                       // 4-byte Folded Reload
	{
		r3 += add(r12,r14)
		r19 = add(r9,#900)
		r23 = add(r6,r11)
		r24 = add(r13,r11)
	}
	{
		r26 = add(r5,add(r21,##1028))
		r22 += add(r3,r4)
		r5 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r6,add(r5,##512))
		r16 = add(r7,r11)
		r6 = memw(r29+#1744)
	}                                       // 4-byte Folded Reload
	{
		r21 = add(r26,r6)
		r18 = add(r28,r11)
		memw(r29+#1688) = r5
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_616:                             // %for.body1174
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = memw(r26+#0)
		r3 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r3,r6,#2)
		r3 = memw(r29+#456)
		r20 = memw(r21+#0)
	}                                       // 4-byte Folded Reload
	{
		r8 = addasl(r3,r6,#2)
		r3 = memw(r29+#280)
		r25 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r9 = addasl(r3,r20,#2)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (p3.new) jump:t .LBB12_619
		if (!p3.new) r2 = memw(r29+##552)
	}                                       // 4-byte Folded Reload
// %bb.617:                             // %if.else1193
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r24 = r9
		r0 = memw(r29+#492)
		memw(r29+#268) = r24
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r2,r6,#2)
		r2 = #0
		r3 = memw(r9+#0)
		r4 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r21 = r18
		r18 = r16
		memw(r29+#1696) = r21
	}                                       // 4-byte Folded Spill
	{
		r23 = r26
		r26 = r17
		r25 = memw(r29+#420)
		memw(r29+#292) = r23
	}                                       // 4-byte Folded Reload
	{
		r25 += mpyi(r6,r4)
		memw(r29+#0) = r8
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r17:16 = combine(r8,r5)
		memw(r29+#4) = r25
	}
	.falign
// %bb.618:                             // %if.else1193
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r9:8 = combine(r24,r17)
		r17 = r26
		r26 = r23
		r23 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r5 = r16
		r16 = r18
		r18 = r21
		r21 = memw(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r29+#268)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_619:                             // %if.end1203
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r6 = r2
		r3 = memw(r29+#288)
		memw(r19+#-388) = r25
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r3+r20<<#2)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r3 = r2
		r7 = memw(r3+r20<<#2)
	}
	{
		r3 += mpyi(r4,#96)
		r4 = memw(r29+#256)
		memw(r19+#-384) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r6 += mpyi(r7,#96)
		memw(r19+#-380) = r6.new
	}
	{
		r4 = memw(r4+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_624
	}
// %bb.620:                             // %land.lhs.true1215
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r1 = add(r19,#-260)
		r0 = add(r3,#88)
		r4 = memw(r3+#44)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB12_624
	}
// %bb.621:                             // %if.then1219
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r25 = r9
		r20 = r5
		memw(r29+#268) = r8
	}                                       // 4-byte Folded Spill
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.622:                             // %if.then1219
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r1 = add(r19,#-132)
		r2 = memw(r19+#-380)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
// %bb.623:                             // %if.then1219
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r5 = r20
		r9 = r25
		r8 = memw(r29+#268)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_624:                             // %if.end1228
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r3 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (!p3.new) jump:t .LBB12_626
		if (!p3.new) r3 = memw(r19+##-384)
	}
// %bb.625:                             // %cond.true1238
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		p1 = tstbit(r27,#0)
		r3 = asl(r27,#30)
		r4 = memw(r29+#400)
		r7 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r6 = r4
		r12 = mux(p1,r4,#0)
		r4 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		if (!p1) r4 = #0
		r12 = add(r7,r12)
		r3 = memw(r19+#-384)
	}
	{
		r4 += add(r7,r6)
		jump .LBB12_627
	}
	.falign
.LBB12_626:                             // %cond.false1241
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r4 = memw(r19+#-380)
		r12 = memw(r3+#4)
	}
	{
		r4 = memw(r4+#4)
	}
	.falign
.LBB12_627:                             // %cond.end1244
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r7 = memw(r29+#436)
		memw(r19+#-376) = r12
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r23,r7)
		r6 = add(r18,r7)
		r12 = add(r22,r7)
		memw(r19+#-372) = r4
	}
	{
		r6 = add(r24,r7)
		r4 = add(r16,r7)
		memw(r19+#-356) = r6
		memw(r19+#-360) = r4
	}
	{
		r7 = add(r12,#512)
		memw(r19+#-352) = r6
		memw(r19+#-368) = r5
	}
	{
		r6 = add(r7,#256)
		memw(r19+#-340) = r6.new
	}
	{
		r7 = add(r7,#512)
		r6 = memw(r29+#240)
		memw(r19+#-344) = r7
	}                                       // 4-byte Folded Reload
	{
		memw(r19+#-364) = r8
		memw(r19+#-348) = r4
	}
	{
		memw(r19+#-336) = r7
		r4 = memw(r6+#0)

	} :mem_noshuf
	{
		r4 = add(r4,r17)
		r1 = memw(r9+#0)
		memw(r19+#0) = r1.new
	}
	{
		memw(r19+#-4) = r4
	}
	{
		r4 = add(r19,#-332)
		r3 = memw(r3+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_630
	}
// %bb.628:                             // %if.then1274
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		call hexkl_wh_affine_sums
		r3 = r8
		r0 = memw(r19+#-388)
		r2 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.629:                             // %if.then1274
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_630:                             // %if.end1279
                                        //   in Loop: Header=BB12_616 Depth=1
	{
		r27 = add(r27,#1)
		r26 = add(r26,#4)
		r21 = add(r21,#4)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r17,r3)
		r19 = add(r19,#512)
		r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r3,r27)
		r3 = memw(r29+#1688)
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r22,r3)
		r24 = add(r24,r3)
		r23 = add(r23,r3)
		r16 = add(r16,r3)
	}
	{
		r18 = add(r18,r3)
		if (!p3) jump:nt .LBB12_616
	}
	.falign
.LBB12_631:                             // %for.cond.cleanup1173
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_634
	}
// %bb.632:                             // %if.then1286
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.633:                             // %if.then1286
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_634:                             // %do.end1292
	{
		r2 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r16 = #0
		if (p1.new) jump:nt .LBB12_657
	}
// %bb.635:                             // %if.then1294
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_651
	}
// %bb.636:                             // %if.then1298
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.637:                             // %if.then1298
	{
		r21:20 = combine(r1,r0)
		jump .LBB12_652
	}
	.falign
.LBB12_638:                             // %cleanup3015
	{
		r17 = r0
	}
	.falign
.LBB12_639:                             // %out3170
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.640:                             // %out3170
	{
		r2 = memw(r29+#528)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_796
	}                                       // 4-byte Folded Reload
// %bb.641:                             // %if.then3172
	{
		call hvx_worker_pool_wait_bg
		r2 = #-1
		r0 = memw(r29+#380)
		r1 = memw(r29+#528)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.642:                             // %if.then3172
	{
		jump .LBB12_796
	}
	.falign
.LBB12_644:
	{
		jump .LBB12_241
		r19 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_645:                             // %if.then985
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r4 = #0
		memw(r29+#800) = r4.new
	}
	.falign
// %bb.646:                             // %if.then985
	{
		r17 = #1 ; jump .LBB12_299
	}
	.falign
.LBB12_647:                             // %if.then1182.peel
	{
		r3 = ##-1431655765
		r1 = memw(r29+#264)
		r4 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,#23)
		r19 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyu(r2,r3)
		r2 = #0
		r0 = r19
		r4 = memw(r4+#0)
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
// %bb.648:                             // %if.then1182.peel
	{
		r2 = memw(r29+#364)
		r3 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r3,r2)
		r2 = memw(r29+#372)
		if (!p3.new) r4 = memw(r29+##420)
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r2+#0)
		r2 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		if (p3) jump:nt .LBB12_608
		r16 = memw(r2+#0)
		if (!p3) r2 = memw(r29+##460)
	}                                       // 4-byte Folded Reload
// %bb.649:                             // %if.then1188.peel
	{
		r3 = memw(r29+#456)
		r0 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r16<<#2)
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		r3 = memw(r3+r16<<#2)
	}
	.falign
// %bb.650:                             // %if.then1188.peel
	{
		jump .LBB12_608
	}
	.falign
.LBB12_651:
	{
		r21:20 = combine(#0,#0)
	}
	.falign
.LBB12_652:                             // %do.end1302
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.653:                             // %do.end1302
	{
		r2 = memw(r29+#396)
		memw(r29+#784) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_657
	}
// %bb.654:                             // %do.body1312
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.655:                             // %do.body1312
	{
		r1:0 = sub(r1:0,r21:20)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_657
	}
// %bb.656:                             // %if.then1314
	{
		r1 = #0
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#80)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_657:                             // %if.end1321
	{
		r4 = memw(r29+#352)
		r5 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		p1 = r4
		r12 = memw(r29+#324)
		r7 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p3 = !tstbit(r7,#7)
		r2 = r7
		r0 = memw(r29+#316)
		r6 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r7,#1,#16)
		r1:0 = combine(r0,r6)
		r6 = memw(r29+#248)
		memw(r12+#72) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = and(##16320,lsr(r2,#2))
		r5 = memw(r29+#320)
		r8 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		p0 = !tstbit(r7,#6)
		r7:6 = combine(r5,r6)
		r4 = mux(p1,#1,#0)
		r5 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		if (p3) r2 = #192
		r9:8 = combine(r5,r8)
		r1 = #0
		memd(r12+#8) = r1:0
	}
	{
		r5 = memw(r29+#276)
		memd(r12+#0) = r7:6
	}                                       // 4-byte Folded Reload
	{
		if (p1) r2 = add(r1,#0)
		if (p0) r3 = #1
		r6 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r5,r6)
		r2 = memw(r29+#396)
		memd(r12+#32) = r3:2
	}                                       // 4-byte Folded Reload
	{
		memd(r12+#16) = r9:8
		memd(r12+#24) = r7:6
	}
	{
		memw(r12+#40) = r4
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_660
	}
// %bb.658:                             // %if.then1356
	{
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r2 = memw(r29+#396)
		if (p0.new) r0 = memw(r29+##792)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r0 = add(r1,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#232)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#232) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.659:                             // %if.then1356
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_660:                             // %do.end1360
	{
		r3 = add(r29,#8704)
		r0 = memw(r29+#352)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r19 = add(r3,#8260)
		r18 = add(r3,#8256)
		r4 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r25 = add(r2,r4)
		if (!p3) jump:nt .LBB12_680
		if (!p3) r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.661:                             // %if.else1365
	{
		r2 = memw(r29+#788)
		r3 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#8248)
		p1 = cmp.gtu(r2,#1); if (!p1.new) jump:t .LBB12_682
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.662:                             // %if.then1378.peel
	{
		r1 = r25
		r0 = add(r29,#744)
		r17 = add(r29,#8704)
		r3 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:t .LBB12_665
		if (!p0.new) r2 = memw(r29+##9220)
	}
// %bb.663:                             // %if.then1381.peel
	{
		call moe_m1_q_post
		r4 = memw(r29+#328)
		r3 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.664:                             // %if.then1381.peel
	{
		r2 = memw(r29+#788)
	}
	.falign
.LBB12_665:                             // %if.end1390.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r3 = memw(r29+#312)
		memw(r19+#0) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r2,r3)
		r4 = add(r29,#8704)
		r2 = add(r29,#744)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r16 = add(pc,##moe_m1_pair_worker@PCREL)
		memw(r18+#0) = #0
		memw(r29+#804) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r29+#800) = r16
	}
	.falign
// %bb.666:                             // %if.end1390.peel
	{
		r20 = #0
		r2 = memw(r29+##8708)
		memw(r29+#784) = r20.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_669
	}
// %bb.667:                             // %if.end1390.peel
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_669
	}
// %bb.668:                             // %if.then1404.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_669:                             // %for.inc1406.peel
	{
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB12_678
		if (!p1.new) r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.670:                             // %for.body1375.preheader
	{
		r24 = add(pc,##moe_m1_q_worker@PCREL)
		r21:20 = combine(#0,#0)
		r26 = add(r17,#516)
	}
	{
		r27 = add(r2,#-1)
		r1 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r17 = asl(r1,#1)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_671:                             // %for.body1375
                                        // =>This Inner Loop Header: Depth=1
	{
		r22 = add(r29,#744)
		r23 = add(r29,#8704)
		r2 = r21
		r4 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r1:0 = combine(r23,r22)
		r3 = memw(r29+#296)
		r5 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.672:                             // %for.body1375
                                        //   in Loop: Header=BB12_671 Depth=1
	{
		r2 = add(r17,r20)
		r1 = r24
		r4 = memw(r29+#312)
		memw(r19+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = r22
		r20 = add(r4,r20)
		r0 = memw(r29+#788)
		memw(r29+#804) = r23
	}
	{
		r3 = maxu(r0,r4)
		r0 = memw(r29+#380)
		memw(r18+#0) = r20
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#800) = r16
	}
	.falign
// %bb.673:                             // %for.body1375
                                        //   in Loop: Header=BB12_671 Depth=1
	{
		r0 = #0
		r2 = memw(r26+#0)
		memw(r29+#784) = r0.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_676
	}
// %bb.674:                             // %for.body1375
                                        //   in Loop: Header=BB12_671 Depth=1
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_676
	}
// %bb.675:                             // %if.then1404
                                        //   in Loop: Header=BB12_671 Depth=1
	{
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_676:                             // %for.inc1406
                                        //   in Loop: Header=BB12_671 Depth=1
	{
		r21 = add(r21,#1)
		r26 = add(r26,#512)
		r27 = add(r27,#-1)
		if (!cmp.eq(r27.new,#0)) jump:t .LBB12_671
	}
// %bb.677:                             // %for.cond.cleanup1374
	{
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r2,#-1)
	}
	{
		p3 = tstbit(r20,#0)
		if (p3.new) jump:t .LBB12_726
	}
	.falign
.LBB12_678:                             // %if.then1414
	{
		r0 = add(r29,#744)
		r1 = add(r29,#8704)
		r2 = r20
		r4 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r3 = memw(r29+#296)
		r5 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.679:                             // %if.then1414
	{
		jump .LBB12_726
	}
	.falign
.LBB12_680:                             // %if.then1362
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r2 = add(r29,#8704)
	}
	{
		r4 = memw(r29+#312)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r4)
		call hvx_worker_pool_run
		memw(r19+#0) = r3.new
	}
	.falign
// %bb.681:                             // %if.then1362
	{
		jump .LBB12_726
	}
	.falign
.LBB12_682:                             // %for.cond1419.preheader
	{
		r17 = #0
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_691
	}
// %bb.683:                             // %if.then1427.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.684:                             // %if.then1427.peel
	{
		r21:20 = combine(r1,r0)
		jump .LBB12_692
	}
	.falign
.LBB12_685:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB12_686:                             // %do.end993
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = add(r29,#744)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#800) = r17
		memw(r29+#804) = r17
	}
	.falign
// %bb.687:                             // %do.end993
	{
		r2 = memw(r29+#396)
		memw(r29+#784) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_302
	}
// %bb.688:                             // %do.body1004
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.689:                             // %do.body1004
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_302
	}
// %bb.690:                             // %if.then1006
	{
		r17 = #0
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r16 = lsr(r3,#10)
	}
	{
		r1:0 = memd(r2+#80)
	}
	{
		r1:0 = add(r1:0,r17:16)
	}
	{
		jump .LBB12_299
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_691:
	{
		r21:20 = combine(#0,#0)
	}
	.falign
.LBB12_692:                             // %do.end1431.peel
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r29+#1880)
	}
	.falign
// %bb.693:                             // %do.end1431.peel
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_697
	}
// %bb.694:                             // %do.body1445.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.695:                             // %do.body1445.peel
	{
		r1:0 = sub(r1:0,r21:20)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_697
	}
// %bb.696:                             // %if.then1447.peel
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r16 = lsr(r3,#10)
	}
	{
		r1:0 = memd(r2+#80)
	}
	{
		r1:0 = add(r1:0,r17:16)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_697:                             // %if.end1454.peel
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#312)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r19+#0) = r3
	}
	.falign
// %bb.698:                             // %if.end1454.peel
	{
		r2 = memw(r29+##8708)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_701
	}
// %bb.699:                             // %if.end1454.peel
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_701
	}
// %bb.700:                             // %if.then1468.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_701:                             // %if.end1469.peel
	{
		r1 = #0
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,#2)) jump:t .LBB12_704
	}                                       // 4-byte Folded Reload
// %bb.702:                             // %if.then1473.peel
	{
		r1 = #0
		r2 = memw(r29+##9732)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r5 = #1
		r3 = memw(r29+#320)
		memw(r29+#0) = #2
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.703:                             // %if.then1473.peel
	{
		jump .LBB12_708
		memw(r29+#1888) = r0
	}
	.falign
.LBB12_704:                             // %for.inc1505.peel
	{
		r5 = #3
		r2 = memw(r29+##8712)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#296)
		memw(r29+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.705:                             // %for.inc1505.peel
	{
		r5 = #3
		r2 = memw(r29+#336)
		memw(r29+#1944) = r0
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:t .LBB12_726
		if (!p3.new) r2 = memw(r29+##9224)
	}
// %bb.706:                             // %if.then1497.1.peel
	{
		r1 = memw(r29+#404)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#316)
		memw(r29+#0) = #1
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.707:                             // %if.then1497.1.peel
	{
		memw(r29+#1948) = r0
	}
	.falign
.LBB12_708:                             // %for.body1423.preheader
	{
		r23 = #1
		r2 = add(r29,#8704)
		r3 = add(r29,#1880)
		r4 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r21 = add(pc,##moe_m1_pair_worker@PCREL)
		r22 = asl(r4,#1)
		r16 = #0
	}
	{
		r24 = #2
		r26 = add(r2,#1540)
		r27 = add(r3,#12)
	}
	{
		r0 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_709:                             // %for.body1423
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_711
	}
// %bb.710:                             // %if.then1427
                                        //   in Loop: Header=BB12_709 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
.LBB12_711:                             // %do.end1431
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r27+#-8)
	}
	.falign
// %bb.712:                             // %do.end1431
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#8704)
		r4 = add(r22,r16)
		r17 = memw(r29+#380)
		memw(r19+#0) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r21,r17)
		r20 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = r20
		r16 = add(r20,r16)
		memw(r18+#0) = r16.new
	}
	.falign
// %bb.713:                             // %do.end1431
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = memw(r26+#-1024)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_716
	}
// %bb.714:                             // %do.end1431
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_716
	}
// %bb.715:                             // %if.then1468
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#8704)
		r0 = r17
		r3 = r20
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
	}
	.falign
.LBB12_716:                             // %if.end1469
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r3 = add(r23,#2)
	}
	{
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_719
	}                                       // 4-byte Folded Reload
// %bb.717:                             // %if.then1473
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		p0 = tstbit(r23,#0)
		r5 = #1
		r3 = memw(r29+#400)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p0,r3,#0)
		r0 = memw(r29+#296)
		r2 = memw(r26+#0)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r3 = memw(r29+#320)
		r4 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.718:                             // %if.then1473
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		jump .LBB12_725
		memw(r27+#0) = r0
	}
	.falign
.LBB12_719:                             // %if.else1484
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r17 = and(r24,#2)
	}
	{
		p1 = cmp.eq(r17,#0)
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,r17)) jump:t .LBB12_722
	}                                       // 4-byte Folded Reload
// %bb.720:                             // %if.then1497
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#8704)
		r5 = #3
		r4 = memw(r29+#308)
		memw(r29+#0) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r17,#9)
		r6 = memw(r29+#400)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r1 = mux(p1,#0,r6)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r2 = memw(r2+#0)
	}
	.falign
// %bb.721:                             // %if.then1497
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r17<<#2) = r0
	}
	.falign
.LBB12_722:                             // %for.inc1505
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r20 = setbit(r17,#0)
	}
	{
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,r20)) jump:t .LBB12_725
	}                                       // 4-byte Folded Reload
// %bb.723:                             // %if.then1497.1
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#8704)
		p2 = cmp.eq(r17,#0)
		r4 = memw(r29+#308)
		memw(r29+#0) = r20
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r20,#9)
		r5 = memw(r29+#400)
		r0 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r6 = mux(p2,#0,r5)
		r5 = #3
		r7 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r3 = memw(r29+#316)
		r2 = memw(r2+#0)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.724:                             // %if.then1497.1
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r20<<#2) = r0
	}
	.falign
.LBB12_725:                             // %if.end1509
                                        //   in Loop: Header=BB12_709 Depth=1
	{
		r23 = add(r23,#1)
		r24 = add(r24,#2)
		r26 = add(r26,#512)
		r27 = add(r27,#4)
	}
	{
		r2 = memw(r29+#248)
		if (!cmp.eq(r2.new,r23)) jump:t .LBB12_709
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_726:                             // %do.body1516
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_731
	}
// %bb.727:                             // %do.body1525
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.728:                             // %do.body1525
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_731
	}
// %bb.729:                             // %if.then1527
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.730:                             // %if.then1527
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_731:                             // %do.end1531
	{
		r2 = memw(r29+#784)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_734
	}
// %bb.732:                             // %if.then1535
	{
		r2 = add(pc,##moe_m1_requant_worker@PCREL)
		r0 = memw(r29+#380)
		r3 = memw(r29+#788)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r29,#8704)
		r2 = add(r29,#744)
		r5 = memw(r29+#248)
		memw(r29+#800) = r2
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r3 = maxu(r3,r5)
		memw(r29+#804) = r4
	}
	{
		call hvx_worker_pool_run
	}
	.falign
// %bb.733:                             // %if.then1535
	{
		r2 = #0 ; jump .LBB12_735
		memw(r29+#784) = r2.new
	}
	.falign
.LBB12_734:                             // %if.else1536
	{
		r1 = add(pc,##moe_m1_requant_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_735:                             // %do.body1538
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_740
	}
// %bb.736:                             // %do.body1547
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.737:                             // %do.body1547
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_740
	}
// %bb.738:                             // %if.then1549
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.739:                             // %if.then1549
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_740:                             // %do.end1553
	{
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_759
		if (!p2.new) r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.741:                             // %if.else1560
	{
		r2 = memw(r29+#788)
	}
	{
		p3 = cmp.gtu(r2,#1)
		r2 = add(r29,#8704)
		if (!p3.new) jump:t .LBB12_761
	}
// %bb.742:                             // %land.lhs.true1573.peel
	{
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		if (!p0.new) r1 = add(r25,#0)
		p0 = tstbit(r2,#0); if (p0.new) jump:nt .LBB12_745
	}
// %bb.743:                             // %land.lhs.true1573.peel
	{
		r0 = add(r29,#744)
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,#2)) jump:nt .LBB12_745
	}                                       // 4-byte Folded Reload
// %bb.744:                             // %if.then1581.peel
	{
		r2 = memw(r29+##9736)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_745:                             // %if.end1604.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = add(r29,#744)
		r3 = memw(r29+#788)
	}
	{
		r4 = add(r29,#8704)
		r0 = memw(r29+#380)
		r5 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(pc,##moe_m1_down_worker@PCREL)
		r3 = maxu(r3,r5)
		memw(r18+#0) = #0
	}
	{
		memw(r19+#0) = r5
		memw(r29+#804) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r29+#800) = r17
	}
	.falign
// %bb.746:                             // %if.end1604.peel
	{
		r2 = #0
		r0 = memw(r29+#336)
		memw(r29+#784) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		if (p2.new) jump:t .LBB12_768
		if (!p2.new) r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.747:                             // %land.lhs.true1573.peel5765
	{
		r2 = and(r2,#1)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_750
	}
// %bb.748:                             // %land.lhs.true1573.peel5765
	{
		r0 = add(r29,#744)
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,#3)) jump:nt .LBB12_750
	}                                       // 4-byte Folded Reload
// %bb.749:                             // %if.then1581.peel5769
	{
		r2 = memw(r29+#404)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r25,r2)
		r2 = memw(r29+##10248)
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
	}
	.falign
.LBB12_750:                             // %if.end1589.peel5773
	{
		r0 = add(r29,#744)
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,#4)) jump:t .LBB12_752
	}                                       // 4-byte Folded Reload
// %bb.751:                             // %if.then1596.peel5776
	{
		r2 = memw(r29+##10760)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r1 = memw(r29+#296)
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_752:                             // %if.end1604.peel5783
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = add(r29,#744)
		r3 = memw(r29+#788)
	}
	{
		r4 = add(r29,#8704)
		r0 = memw(r29+#380)
		r5 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r20 = asl(r5,#1)
		memw(r18+#0) = r5
		memw(r29+#804) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r19+#0) = r20
		memw(r29+#800) = r17
	}
	.falign
// %bb.753:                             // %if.end1604.peel5783
	{
		r21 = #0
		r2 = memw(r29+#248)
		memw(r29+#784) = r21.new
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#2)
		if (!p2.new) r24 = #5
		if (p2.new) jump:t .LBB12_768
		if (!p2.new) r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.754:                             // %for.body1570.preheader
	{
		r16 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = add(r29,#8704)
		r26 = #0
	}
	{
		r22 = add(r3,#-2)
		r27 = add(r2,#2568)
		r3 = memw(r29+#308)
		r25 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r23 = +mpyi(r3,#3)
	}
	.falign
.LBB12_755:                             // %for.body1570
                                        // =>This Inner Loop Header: Depth=1
	{
		r3 = asl(r24,#30)
		p2 = tstbit(r24,#0)
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,r24)) jump:t .LBB12_757
	}                                       // 4-byte Folded Reload
// %bb.756:                             // %if.then1596
                                        //   in Loop: Header=BB12_755 Depth=1
	{
		r0 = add(r29,#744)
		r6 = memw(r29+#400)
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		r4 = memw(r29+#404)
		r2 = memw(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p2,r4,#0)
		r3 = memw(r29+#316)
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r1 += add(r5,r6)
		call moe_m1_q_post
	}
	.falign
.LBB12_757:                             // %if.end1604
                                        //   in Loop: Header=BB12_755 Depth=1
	{
		r2 = add(r20,r26)
		r1 = r16
		r3 = memw(r29+#788)
		memw(r18+#0) = r2.new
	}
	{
		r3 = maxu(r3,r25)
		r2 = add(r23,r26)
		r0 = memw(r29+#380)
		memw(r19+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#744)
		r4 = add(r29,#8704)
		memw(r29+#804) = r4.new
	}
	{
		call hvx_worker_pool_run
		memw(r29+#800) = r17
	}
	.falign
// %bb.758:                             // %if.end1604
                                        //   in Loop: Header=BB12_755 Depth=1
	{
		r22 = add(r22,#-1)
		r26 = add(r26,r25)
		r24 = add(r24,#1)
		r27 = add(r27,#512)
	}
	{
		p3 = cmp.eq(r22,#0)
		if (!p3.new) jump:t .LBB12_755
		memw(r29+#784) = r21
	}
	{
		jump .LBB12_768
	}
	.falign
.LBB12_759:                             // %if.then1555
	{
		r1 = add(pc,##moe_m1_down_worker@PCREL)
		r2 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#380)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r2)
		call hvx_worker_pool_run
		r2 = add(r29,#8704)
		memw(r19+#0) = r3.new
	}
	.falign
// %bb.760:                             // %if.then1555
	{
		jump .LBB12_768
	}
	.falign
.LBB12_761:                             // %for.cond1616.preheader
	{
		r16 = add(pc,##moe_m1_down_worker@PCREL)
		r3 = add(r29,#1944)
		r17 = add(r2,#2056)
	}
	{
		r21:20 = combine(#0,#0)
		r22 = add(r3,#16)
	}
	.falign
.LBB12_762:                             // %for.body1620
                                        // =>This Inner Loop Header: Depth=1
	{
		call moe_m1_wait
		r1 = #2
		r0 = memw(r22+#-16)
	}
	.falign
// %bb.763:                             // %for.body1620
                                        //   in Loop: Header=BB12_762 Depth=1
	{
		r1 = r16
		r2 = add(r29,#8704)
		r0 = memw(r29+#380)
		r3 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r3,r20)
		memw(r18+#0) = r20
	}
	{
		call hvx_worker_pool_run
		memw(r19+#0) = r20
	}
	.falign
// %bb.764:                             // %for.body1620
                                        //   in Loop: Header=BB12_762 Depth=1
	{
		r3 = add(r21,#4)
	}
	{
		r2 = memw(r29+#248)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_767
	}                                       // 4-byte Folded Reload
// %bb.765:                             // %if.then1630
                                        //   in Loop: Header=BB12_762 Depth=1
	{
		p0 = tstbit(r21,#0)
		r4 = asl(r21,#30)
		r6 = memw(r29+#400)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r4,#31)
		r5 = #3
		r3 = memw(r29+#404)
		r2 = memw(r17+#0)
	}                                       // 4-byte Folded Reload
	{
		r7 = mux(p0,r3,#0)
		r0 = memw(r29+#296)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r4 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.766:                             // %if.then1630
                                        //   in Loop: Header=BB12_762 Depth=1
	{
		memw(r22+#0) = r0
	}
	.falign
.LBB12_767:                             // %for.inc1642
                                        //   in Loop: Header=BB12_762 Depth=1
	{
		r17 = add(r17,#512)
		r22 = add(r22,#4)
		r21 = add(r21,#1)
	}
	{
		r2 = memw(r29+#252)
		if (!cmp.eq(r2.new,r21)) jump:t .LBB12_762
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_768:                             // %do.body1648
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_773
	}
// %bb.769:                             // %do.body1657
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.770:                             // %do.body1657
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_773
	}
// %bb.771:                             // %if.then1659
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.772:                             // %if.then1659
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_773:                             // %do.end1663
	{
		r17 = #0
		r2 = memw(r29+#640)
		r24 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r16 = asl(r24,#2)
		p1 = cmp.eq(r2,#0)
		r25 = memw(r29+#344)
		r23 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		r2 = p1
		r26 = memw(r29+#564)
		memw(r29+#236) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#568)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_774:                             // %for.body1669
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_777 Depth 2
	{
		r18 = add(r29,#8704)
		r27 = r2
		r2 = memw(r2+#0)
		r3 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r19 = addasl(r25,r2,#2)
		r18 += asl(r17,#9)
		r21 = #0
		r22 = #0
	}
	{
		p0 = r3
		if (!p0.new) r2 = add(r16,#0)
		if (!p0.new) jump:t .LBB12_779
	}
// %bb.775:                             // %for.cond1687.preheader
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r3 = memw(r18+#388)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_781
	}
// %bb.776:                             // %for.body1692.lr.ph
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r3 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r20 = addasl(r3,r2,#2)
	}
	.falign
.LBB12_777:                             // %for.body1692
                                        //   Parent Loop BB12_774 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = memw(r20++#4)
		r4 = memw(r18+#52)
	}
	{
		r1 = add(r4,r21)
		r2 = memw(r19++#4)
	}
	{
		r5 = mpyi(r3,r24)
		r3 = r24
	}
	{
		r0 = addasl(r26,r5,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.778:                             // %for.body1692
                                        //   in Loop: Header=BB12_777 Depth=2
	{
		r22 = add(r22,#1)
		r21 = add(r21,r16)
	}
	{
		r2 = memw(r18+#388)
		if (cmp.gtu(r2.new,r22)) jump:t .LBB12_777
	}
	{
		jump .LBB12_781
	}
	.falign
.LBB12_779:                             // %if.then1678
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r3 = mpyi(r17,r24)
	}
	{
		r20 = addasl(r23,r3,#2)
	}
	{
		call memset
		r1:0 = combine(#0,r20)
	}
	.falign
// %bb.780:                             // %if.then1678
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r0 = r20
		r3 = r24
		r1 = memw(r18+#52)
		r2 = memw(r19+#0)
	}
	{
		call hvx_scale_add_rows_f32
	}
	.falign
.LBB12_781:                             // %cleanup1704
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r17 = add(r17,#1)
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r17,r2)
		r2 = add(r27,#4)
		if (!p3.new) jump:t .LBB12_774
	}
// %bb.782:                             // %for.cond.cleanup1668
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_785
	}
// %bb.783:                             // %if.then1715
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.784:                             // %if.then1715
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_785:                             // %do.end1721
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_794
		if (p3.new) r2 = memw(r29+##396)
	}                                       // 4-byte Folded Reload
// %bb.786:                             // %do.body1728
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_789
	}
// %bb.787:                             // %if.then1730
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.788:                             // %if.then1730
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_789:                             // %do.end1734
	{
		r3 = #0
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#332)
		r1 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.790:                             // %do.end1734
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_793
	}
// %bb.791:                             // %if.then1739
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.792:                             // %if.then1739
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_793:                             // %do.end1745
	{
		r2 = memw(r29+#796)
		r17 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (p3.new) r17 = #0
	}
	{
		if (!p3) r17 = add(r2,##-32767)
		jump .LBB12_795
	}
	.falign
.LBB12_794:                             // %if.then1723
	{
		r2 = memw(r29+#796)
		r17 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		r2 = ##-2147449856
		p0 = cmp.eq(r2,#0)
		if (p0.new) r17 = #0
	}
	{
		if (!p0) r17 = add(r2,##-32767)
	}
	.falign
.LBB12_795:                             // %out3170.thread
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_796:                             // %for.body3179
	{
		r2 = memw(r29+#1752)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_798
	}
// %bb.797:                             // %if.then3182
	{
		call hvx_worker_pool_wait_bg
		r1 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_798:                             // %for.inc3185
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1756)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_800
	}
// %bb.799:                             // %if.then3182.1
	{
		r2 = #-1
		r1 = add(r3,#32)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_800:                             // %for.inc3185.1
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1760)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_802
	}
// %bb.801:                             // %if.then3182.2
	{
		r2 = #-1
		r1 = add(r3,#64)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_802:                             // %for.inc3185.2
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1764)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_804
	}
// %bb.803:                             // %if.then3182.3
	{
		r2 = #-1
		r1 = add(r3,#96)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_804:                             // %for.inc3185.3
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1768)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_806
	}
// %bb.805:                             // %if.then3182.4
	{
		r2 = #-1
		r1 = add(r3,#128)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_806:                             // %for.inc3185.4
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1772)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_808
	}
// %bb.807:                             // %if.then3182.5
	{
		r2 = #-1
		r1 = add(r3,#160)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_808:                             // %for.inc3185.5
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1776)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_810
	}
// %bb.809:                             // %if.then3182.6
	{
		r2 = #-1
		r1 = add(r3,#192)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_810:                             // %for.inc3185.6
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1780)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_812
	}
// %bb.811:                             // %if.then3182.7
	{
		r2 = #-1
		r1 = add(r3,#224)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_812:                             // %for.inc3185.7
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1784)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_814
	}
// %bb.813:                             // %if.then3182.8
	{
		r2 = #-1
		r1 = add(r3,#256)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_814:                             // %for.inc3185.8
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1788)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_816
	}
// %bb.815:                             // %if.then3182.9
	{
		r2 = #-1
		r1 = add(r3,#288)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_816:                             // %for.inc3185.9
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1792)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_818
	}
// %bb.817:                             // %if.then3182.10
	{
		r2 = #-1
		r1 = add(r3,#320)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_818:                             // %for.inc3185.10
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1796)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_820
	}
// %bb.819:                             // %if.then3182.11
	{
		r2 = #-1
		r1 = add(r3,#352)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_820:                             // %for.inc3185.11
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1800)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_822
	}
// %bb.821:                             // %if.then3182.12
	{
		r2 = #-1
		r1 = add(r3,#384)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_822:                             // %for.inc3185.12
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1804)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_824
	}
// %bb.823:                             // %if.then3182.13
	{
		r2 = #-1
		r1 = add(r3,#416)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_824:                             // %for.inc3185.13
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1808)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_826
	}
// %bb.825:                             // %if.then3182.14
	{
		r2 = #-1
		r1 = add(r3,#448)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_826:                             // %for.inc3185.14
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1812)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_828
	}
// %bb.827:                             // %if.then3182.15
	{
		r2 = #-1
		r1 = add(r3,#480)
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_828:                             // %for.inc3185.15
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_837
	}
// %bb.829:                             // %if.then3190
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_finish
		r2 = add(r29,#2456)
	}
	.falign
// %bb.830:                             // %if.then3190
	{
		r19 = #0
		r2 = memw(r29+#396)
		r18 = memw(r29+#2456)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r18 = memw(r29+#2460)
		memd(r16+#144) = r19:18
	}
	{
		r18 = memw(r29+#2464)
		memd(r16+#152) = r19:18
	}
	{
		r18 = memw(r29+#2468)
		memd(r16+#160) = r19:18
	}
	{
		r18 = memw(r29+#2472)
		memd(r16+#200) = r19:18
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.831:                             // %if.then3190
	{
		r18 = memw(r29+#2476)
		memd(r16+#168) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.832:                             // %if.then3190
	{
		r18 = memw(r29+#2480)
		memd(r16+#176) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.833:                             // %if.then3190
	{
		r18 = memw(r29+#2484)
		memd(r16+#184) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.834:                             // %if.then3190
	{
		r18 = memw(r29+#2488)
		memd(r16+#192) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.835:                             // %if.then3190
	{
		r18 = memw(r29+#2492)
		memd(r16+#208) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.836:                             // %if.then3190
	{
		memd(r16+#216) = r1:0
	}
	.falign
.LBB12_837:                             // %cleanup3209
	{
		r6 = r17
	}
	.falign
.LBB12_838:                             // %cleanup3324
	{
		r0 = r6
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB12_839:                             // %do.body3077
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_842
	}
// %bb.840:                             // %if.then3079
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.841:                             // %if.then3079
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_842:                             // %do.end3083
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.843:                             // %do.end3083
	{
		r2 = memw(r29+#512)
		r0 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		p0 = cmp.eq(r2,#0)
	}
	{
		p2 = or(p3,p0)
		if (p2.new) jump:t .LBB12_846
		if (!p2.new) r2 = memw(r29+##512)
	}                                       // 4-byte Folded Reload
// %bb.844:                             // %if.then3088
	{
		r0 = add(r2,#-1)
		r1 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.845:                             // %if.then3088
	{
		r3 = add(r29,#2072)
		r2 = #-1
	}
	{
		r1 = addasl(r3,r0,#5)
		call hvx_worker_pool_wait_bg
		r0 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_846:                             // %if.end3093
	{
		r16 = #0
		r2 = memw(r29+#276)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_854
	}                                       // 4-byte Folded Reload
// %bb.847:                             // %for.body3120.lr.ph.preheader
	{
		r2 = memw(r29+#424)
		r3 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r2,#24,#0)
		r19 = asl(r3,#2)
	}
	{
		r20 = asl(r2,#8)
	}
	.falign
.LBB12_848:                             // %for.body3120.lr.ph
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_850 Depth 2
	{
		r17 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.849:                             // %for.body3120.lr.ph
                                        //   in Loop: Header=BB12_848 Depth=1
	{
		r21 = memw(r29+#580)
		r2 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r16)
		r5:4 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r2 = minu(r2,r17)
		r22 = r4
		r17 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		r21 += mpyi(r0,r4)
		r18 = asl(r2,#7)
	}
	.falign
.LBB12_850:                             // %for.body3120
                                        //   Parent Loop BB12_848 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = memb(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB12_852
	}
// %bb.851:                             // %if.then3123
                                        //   in Loop: Header=BB12_850 Depth=2
	{
		call memset
		r2 = r18
		r1:0 = combine(#0,r17)
	}
	.falign
.LBB12_852:                             // %for.inc3131
                                        //   in Loop: Header=BB12_850 Depth=2
	{
		r21 = add(r21,#1)
		r17 = add(r17,r19)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB12_850
	}
// %bb.853:                             // %for.cond.cleanup3119
                                        //   in Loop: Header=BB12_848 Depth=1
	{
		r2 = memw(r29+#304)
		r1 = memw(r29+#308)
	}                                       // 4-byte Folded Reload
	{
		r16 = add(r16,r2)
		r0 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r1,r16)
	}
	{
		r2 = add(r0,r20)
		if (p0) jump:nt .LBB12_848
		memw(r29+#564) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_854:                             // %for.cond.cleanup3098
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_859
	}
// %bb.855:                             // %do.body3149
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.856:                             // %do.body3149
	{
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_859
	}
// %bb.857:                             // %if.then3151
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.858:                             // %if.then3151
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_859:                             // %do.end3155
	{
		r2 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r3 = #0
		if (p2.new) jump:t .LBB12_861
	}
// %bb.860:                             // %if.then3157
	{
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#332)
		r1 = memw(r29+#648)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_861:                             // %do.body3161
	{
		r17 = #0
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_639
	}
// %bb.862:                             // %if.then3163
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.863:                             // %if.then3163
	{
		r2 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB12_639
		memd(r2+#8) = r1:0
	}
.Lfunc_end12:
	.size	hexkl_mm_u8i4_moe_layer_run, .Lfunc_end12-hexkl_mm_u8i4_moe_layer_run
                                        // -- End function
	.falign
	.type	moe_all_4bit,@function          // -- Begin function moe_all_4bit
moe_all_4bit:                           // @moe_all_4bit
// %bb.0:                               // %entry
	{
		loop0(.LBB13_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB13_8
	}
	.falign
.LBB13_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB13_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (p0.new) jump:nt .LBB13_7
		if (!p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (cmp.eq(r6.new,#2)) jump:nt .LBB13_7
	}
	.falign
.LBB13_5:                               // %for.inc
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB13_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB13_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end13:
	.size	moe_all_4bit, .Lfunc_end13-moe_all_4bit
                                        // -- End function
	.falign
	.type	moe_all_2bit,@function          // -- Begin function moe_all_2bit
moe_all_2bit:                           // @moe_all_2bit
// %bb.0:                               // %entry
	{
		loop0(.LBB14_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB14_8
	}
	.falign
.LBB14_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB14_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (!p0.new) jump:nt .LBB14_7
		if (p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (!cmp.eq(r6.new,#2)) jump:nt .LBB14_7
	}
	.falign
.LBB14_5:                               // %for.inc
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB14_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB14_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end14:
	.size	moe_all_2bit, .Lfunc_end14-moe_all_2bit
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_usable,@function  // -- Begin function hexkl_acc_i24_usable
hexkl_acc_i24_usable:                   // @hexkl_acc_i24_usable
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB15_3
		r0 = #0
		r4 = r0
	}
// %bb.1:                               // %land.lhs.true
	{
		r5 = memw(r3+#4)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB15_3
	}
// %bb.2:                               // %land.lhs.true2
	{
		r5 = memw(r3+#8)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB15_4
	}
	.falign
.LBB15_3:                               // %land.end
	{
		jumpr r31
	}
	.falign
.LBB15_4:                               // %land.lhs.true3
	{
		r3 = memw(r3+#12)
	}
	{
		p1 = cmp.eq(r3,#32)
		if (p1.new) r3 = add(r1,#-1)
		if (!p1.new) jump:t .LBB15_3
	}
// %bb.5:                               // %land.rhs
	{
		p0 = cmp.gtu(r2,#7)
		if (p0.new) jumpr:nt r31
	}
.LBB15_6:                               // %land.rhs
	{
		p1 = cmp.eq(r4,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB15_7:                               // %land.rhs
	{
		r5 = #-9
		if (cmp.gtu(r5.new,r3)) jump:nt .LBB15_3
	}
// %bb.8:                               // %if.end.i
	{
		r3 = #255
		r5 = sub(#0,r1)
		r6 = ##8388609
	}
	{
		r13:12 = mpyu(r4,r3)
		r7 = #0
		r8 = ##8388608
	}
	{
		r9 = #0
	}
	{
		r15:14 = mpyu(r12,r5)
		r11:10 = mpyu(r12,r2)
	}
	{
		r15 += mpyi(r5,r13)
		r11 += mpyi(r2,r13)
	}
	{
		p1 = cmp.gtu(r7:6,r15:14)
		p0 = cmp.gtu(r9:8,r11:10)
	}
	{
		p1 = and(p1,p0)
	}
	{
		r0 = mux(p1,#1,#0)
		jumpr r31
	}
.Lfunc_end15:
	.size	hexkl_acc_i24_usable, .Lfunc_end15-hexkl_acc_i24_usable
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_banks,@function   // -- Begin function hexkl_acc_i24_banks
hexkl_acc_i24_banks:                    // @hexkl_acc_i24_banks
// %bb.0:                               // %entry
	{
		r7 = #0
		if (!p0.new) r8 = add(r3,#0)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB16_8
	}
// %bb.1:                               // %entry
	{
		r9 = and(r2,#1)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB16_8
	}
// %bb.2:                               // %lor.lhs.false2
	{
		p0 = cmp.gtu(r2,#1); if (!p0.new) jump:nt .LBB16_8
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r15:14 = combine(#0,#0)
		r3 = r1
		r6 = r1
	}
	{
		r3 = or(r9,and(r3,##2047))
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB16_8
	}
// %bb.4:                               // %if.end
	{
		r3 = #24576
		r9 = #0
	}
	{
		r13:12 = mpyu(r2,r3)
	}
	{
		r13:12 = add(r13:12,r7:6)
	}
	{
		r9:8 = add(r13:12,r9:8)
	}
	{
		r11:10 = combine(#0,r9)
	}
	{
		p0 = cmp.eq(r11:10,r15:14)
		if (p0.new) r3 = add(r0,##-3072)
		if (!p0.new) jump:t .LBB16_8
	}
// %bb.5:                               // %lor.lhs.false15
	{
		p1 = cmp.gtu(r0,##3071)
		if (!p1.new) jump:nt .LBB16_8
	}
// %bb.6:                               // %lor.lhs.false15
	{
		r3 = insert(r14,#11,#0)
		if (cmp.gtu(r8,r3.new)) jump:nt .LBB16_8
	}
// %bb.7:                               // %if.end20
	{
		r6 += mpyi(r2,##12288)
		r7 = #1
		memw(r4+#0) = r6.new
	}
	{
		r0 = r7
		jumpr r31
		memw(r5+#0) = r12
	}
	.falign
.LBB16_8:                               // %return
	{
		r0 = r7
		jumpr r31
	}
.Lfunc_end16:
	.size	hexkl_acc_i24_banks, .Lfunc_end16-hexkl_acc_i24_banks
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_prepare,@function // -- Begin function hexkl_acc_i24_prepare
hexkl_acc_i24_prepare:                  // @hexkl_acc_i24_prepare
// %bb.0:                               // %entry
	{
		r3 = #16384
		r1 = add(r0,#1024)
		v0 = vxor(v0,v0)
		vmem(r0+#2) = v0.new
	}
	{
		v2 = vsplat(r3)
		r1 = add(r0,#1152)
		r2 = #24576
		vmem(r1+#0) = v2.new
	}
	{
		v1 = vsplat(r2)
		r1 = add(r0,#1280)
		r3 = add(r0,#1408)
		vmem(r1+#0) = v2
	}
	{
		r1 = add(r0,#1536)
		r2 = #8192
		vmem(r1+#0) = v0
	}
	{
		v3 = vsplat(r2)
		r1 = add(r0,#1792)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2304)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2560)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2048)
		vmem(r1+#0) = v0
	}
	{
		r3 = add(r0,#1664)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2176)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#1920)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2688)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#2432)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2816)
		vmem(r1+#0) = v0
	}
	{
		vmem(r0+#0) = v1
	}
	{
		vmem(r0+#3) = v0
	}
	{
		vmem(r0+#4) = v0
	}
	{
		vmem(r0+#1) = v1
	}
	{
		vmem(r0+#5) = v0
	}
	{
		vmem(r0+#6) = v0
	}
	{
		r0 = add(r0,#2944)
		vmem(r0+#7) = v0
	}
	{
		vmem(r3+#0) = v0
	}
	{
		vmem(r1+#0) = v0
	}
	{
		jumpr r31
		vmem(r0+#0) = v0
	}
.Lfunc_end17:
	.size	hexkl_acc_i24_prepare, .Lfunc_end17-hexkl_acc_i24_prepare
                                        // -- End function
	.falign
	.type	moe_push_gate_up_chunks,@function // -- Begin function moe_push_gate_up_chunks
moe_push_gate_up_chunks:                // @moe_push_gate_up_chunks
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#168)
	}                                       // 8-byte Folded Spill
	{
		r23 = memw(r29+#176)
		memd(r29+#136) = r23:22
	}
	{
		p1 = cmp.eq(r23,#0)
		memd(r29+#152) = r19:18
		memd(r29+#144) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#128) = r25:24
		memd(r29+#120) = r27:26
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#28) = r4
		memw(r29+#40) = r2
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB18_59
		if (!p1) r27 = memw(r29+#188)
		memw(r29+#36) = r1
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r3 = asl(r5,#9)
		r17:16 = combine(r3,#0)
		r25:24 = combine(#0,#0)
		r22 = memw(r29+#180)
	}
	{
		r3 = lsr(r3,#1)
		r21:20 = combine(#0,r23)
		r18 = r0
		memw(r29+#48) = r3
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#36)
		memw(r29+#68) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
		r1:0 = vaslw(r23:22,#9)
		r4 = add(r0,r2)
	}
	{
		r3 = #0
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r6 = memw(r29+#184)
		memd(r29+#96) = r3:2
	}
	{
		r2 = add(r2,r1)
		memw(r29+#44) = r4
		memw(r29+#24) = r6
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#88) = r1:0
		memw(r29+#72) = r2
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#56) = r18
		memw(r29+#20) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB18_2:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = minu(r22,r20)
		r5 = add(r23,r16)
		r3 = #0
		r2 = memw(r17+#44)
	}
	{
		r26 = minu(r5,r22)
		r3 = insert(r4,#23,#8)
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r3)
		if (!p0) r5:4 = combine(r26,r25)
		if (p0) jump:nt .LBB18_8
		memw(r29+#32) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.3:                               // %if.then.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = add(r29,#76)
		r0 = r18
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r6 = memw(r29+#24)
		memw(r29+#76) = #1
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		r2 = memw(r29+#40)
		memw(r29+#84) = r24
	}                                       // 4-byte Folded Reload
	.falign
.LBB18_4:                               // %moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r4 = add(r23,r25)
		r2 = memw(r17+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_13
	}
// %bb.5:                               // %if.then.i30
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = add(r29,#76)
		r5 = r26
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r0 = r18
		r6 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#76) = #2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#40)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		memw(r29+#84) = r24
	}
	.falign
// %bb.6:                               // %if.then.i30
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r26 = r0
	}
	.falign
.LBB18_7:                               // %moe_push_weight_chunk.exit41
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r25 = add(r25,r22)
		r24 = add(r24,#1)
		r1:0 = memd(r29+#88)
		memw(r27++#4) = r26
	}                                       // 8-byte Folded Reload
	{
		p0 = cmp.gtu(r23,r25)
		r21 = add(r21,r0)
		r20 = sub(r20,r22)
		r16 = sub(r16,r22)
	}
	{
		if (p0) jump:nt .LBB18_2
	}
	{
		jump .LBB18_59
	}
	.falign
.LBB18_8:                               // %if.end.i48
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p1 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p0 = cmp.eq(r3,#0)
	}
	{
		r3 = p0
		if (!p1) jump:nt .LBB18_18
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.9:                               // %if.then3.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.10:                              // %if.then3.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_26
	}
// %bb.11:                              // %if.then12.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then12.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB18_27
		r5 = memw(r17+#4)
	}
	{
		jump .LBB18_29
	}
	.falign
.LBB18_13:                              // %if.end.i58
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p0 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		r3 = p1
		if (!p0) jump:nt .LBB18_22
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:                              // %if.then3.i90
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.15:                              // %if.then3.i90
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r19

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_32
	}
// %bb.16:                              // %if.then12.i95
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.17:                              // %if.then12.i95
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB18_33
		r3 = memw(r17+#4)
	}
	{
		jump .LBB18_35
	}
	.falign
.LBB18_18:                              // %if.end30.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.19:                              // %if.end30.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_38
	}
// %bb.20:                              // %if.then44.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.21:                              // %if.then44.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB18_39
		r2 = memw(r17+#4)
	}
	{
		jump .LBB18_41
	}
	.falign
.LBB18_22:                              // %if.end30.i61
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.23:                              // %if.end30.i61
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_48
	}
// %bb.24:                              // %if.then44.i64
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then44.i64
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB18_49
		r5 = memw(r17+#4)
	}
	{
		jump .LBB18_51
	}
	.falign
.LBB18_26:                              //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB18_29
		r5 = memw(r17+#4)
	}
	.falign
.LBB18_27:                              // %land.rhs.i.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB18_29
	}
// %bb.28:                              // %lor.rhs.i.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB18_29:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r6 = lsr(r21,#1)
		r4 = r19
		r2 = memw(r29+#32)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r1 = add(r5,r6)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = memw(r29+#68)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.30:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB18_4
	}
// %bb.31:                              // %if.then24.i
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB18_44
	}
	.falign
.LBB18_32:                              //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB18_35
		r3 = memw(r17+#4)
	}
	.falign
.LBB18_33:                              // %land.rhs.i.i110
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB18_35
	}
// %bb.34:                              // %lor.rhs.i.i120
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB18_35:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r0 = r21
		r5:4 = memd(r29+#88)
		memw(r29+#0) = r18
	}                                       // 8-byte Folded Reload
	{
		r2 = add(r5,r21)
		r6 = memw(r29+#32)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r2,#1)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r3,r4)
		r3 = memw(r29+#68)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r5)
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.36:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB18_58
	}
// %bb.37:                              // %if.then24.i116
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB18_54
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB18_38:                              //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB18_41
		r2 = memw(r17+#4)
	}
	.falign
.LBB18_39:                              // %land.rhs.i105.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #1
		r3 = memw(r17+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB18_41
	}
// %bb.40:                              // %lor.rhs.i109.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r3,#0)
	}
	.falign
.LBB18_41:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r1 = add(r2,r21)
		r2 = memw(r29+#44)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = r2
		r4 = memw(r29+#52)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.42:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB18_4
	}
// %bb.43:                              // %if.then56.i
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB18_44:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB18_4
	}
// %bb.46:                              // %if.then6.i
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3 = #1
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r2 = memw(r29+#64)
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.47:                              // %if.then6.i
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		jump .LBB18_4
	}
	.falign
.LBB18_48:                              //   in Loop: Header=BB18_2 Depth=1
	{
		r1:0 = combine(#0,#0)
	}
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB18_51
		r5 = memw(r17+#4)
	}
	.falign
.LBB18_49:                              // %land.rhs.i105.i77
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB18_51
	}
// %bb.50:                              // %lor.rhs.i109.i87
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB18_51:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r1:0 = combine(r21,r21)
		r2 = memw(r29+#48)
		r7:6 = memd(r29+#88)
	}                                       // 8-byte Folded Reload
	{
		r1 += add(r5,r7)
		r3 = r2
		r5 = memw(r29+#28)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#56)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#72)
		r4 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r18,r6)
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.52:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB18_7
	}
// %bb.53:                              // %if.then56.i83
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB18_54:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.55:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB18_7
	}
// %bb.56:                              // %if.then6.i38
                                        //   in Loop: Header=BB18_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#2,r26)
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.57:                              // %if.then6.i38
                                        //   in Loop: Header=BB18_2 Depth=1
	{
		jump .LBB18_7
	}
	.falign
.LBB18_58:                              //   in Loop: Header=BB18_2 Depth=1
	{
		jump .LBB18_7
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB18_59:                              // %for.cond.cleanup
	{
		r17:16 = memd(r29+#160)
		r19:18 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#144)
		r23:22 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#128)
		r27:26 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end18:
	.size	moe_push_gate_up_chunks, .Lfunc_end18-moe_push_gate_up_chunks
                                        // -- End function
	.falign
	.type	moe_m1_q_post,@function         // -- Begin function moe_m1_q_post
moe_m1_q_post:                          // @moe_m1_q_post
// %bb.0:                               // %entry
	{
		r4 = asl(r4,#9)
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r5 = memw(r0+#40)
		r6 = memw(r16+#84)
	}
	{
		r6 = lsr(r4,#1)
		r7 = add(r5,#1)
		p1 = cmp.eq(r6,#2)
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		if (!p1) r6 = add(r4,#0)
		r7 = memw(r16+#44)
		r2 = memw(r2+#4)
	}
	{
		r17 = add(r0,r5)
		p0 = cmp.eq(r7,#0)
	}
	{
		memw(r17+#4) = r2
		memw(r17+#8) = r6
	}
	{
		if (p0) jump:nt .LBB19_3
		memw(r17+#12) = r3
		memw(r0+r5<<#0) = r1
	}
// %bb.1:                               // %if.then
	{
		r0 = memw(r16+#28)
		memw(r17+#8) = ##640
	}
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r16+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r3 = lsr(r2,#9)
		memw(r17+#12) = r3.new
	}
	.falign
.LBB19_3:                               // %if.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_6
	}
// %bb.4:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB19_7
	}
// %bb.5:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB19_7
	}
	.falign
.LBB19_6:
	{
		r2 = #0
	}
	.falign
.LBB19_7:                               // %moe_weight_src_bypass.exit
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r17+#16) = r2
	}
	{
		r2 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_9
	}
// %bb.8:                               // %if.then7
	{
		r1 = #0
		r2 = memw(r17+#8)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		r0 = lsr(r2,#10)
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB19_9:                               // %do.end
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end19:
	.size	moe_m1_q_post, .Lfunc_end19-moe_m1_q_post
                                        // -- End function
	.falign
	.type	moe_m1_push,@function           // -- Begin function moe_m1_push
moe_m1_push:                            // @moe_m1_push
// %bb.0:                               // %entry
	{
		r16 = r5
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		r2 = memw(r2+#44)
		memd(r29+#32) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r21:20
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p0) r17 = add(r3,#0)
		if (p0) jump:nt .LBB20_3
		if (p0) r0 = memw(r18+#84)
	}
// %bb.1:                               // %if.then
	{
		call hvx_tl2_weight_bytes
		r0 = memw(r18+#28)
		r1 = memw(r18+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
		r19 = #640
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r17 = lsr(r2,#9)
		jump .LBB20_4
	}
	.falign
.LBB20_3:                               // %cond.end3.thread
	{
		r2 = asl(r4,#9)
		p1 = cmp.eq(r0,#2)
	}
	{
		r19 = lsr(r2,#1)
	}
	{
		if (!p1) r19 = add(r2,#0)
	}
	.falign
.LBB20_4:                               // %if.end
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.5:                               // %if.end
	{
		r23 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r3 = mpyi(r17,r19)
		r22 = r0
	}
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_7
	}
// %bb.6:                               // %if.then10
	{
		r1 = #0
		r2 = memw(r23+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB20_7:                               // %do.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
		r1 = memw(r18+#4)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_10
	}
// %bb.8:                               // %land.rhs.i
	{
		r2 = memw(r18+#36)
	}
	{
		r2 = #1
		p0 = cmp.eq(r2,#0); if (!p0.new) jump:t .LBB20_11
	}
// %bb.9:                               // %lor.rhs.i
	{
		r2 = memw(r18+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB20_11
	}
	.falign
.LBB20_10:
	{
		r2 = #0
	}
	.falign
.LBB20_11:                              // %moe_weight_src_bypass.exit
	{
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
		r5:4 = combine(r17,r19)
		memw(r29+#0) = r2
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.12:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_14
	}
// %bb.13:                              // %if.then15
	{
		r4 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = combine(r16,r22)
		r5 = #0
		memw(r29+#0) = r19
		memw(r29+#4) = r17
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r19
	}
	.falign
.LBB20_14:                              // %if.end17
	{
		r0 = r22
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end20:
	.size	moe_m1_push, .Lfunc_end20-moe_m1_push
                                        // -- End function
	.falign
	.type	hexkl_wh_affine_sums,@function  // -- Begin function hexkl_wh_affine_sums
hexkl_wh_affine_sums:                   // @hexkl_wh_affine_sums
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r1,#0)
		allocframe(r29,#128):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		if (p1) jump:nt .LBB21_17
		r31:30 = deallocframe(r30):raw
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r8 = add(r1,#3)
		p0 = cmp.gtu(r2,#31); if (p0.new) jump:t .LBB21_7
		v0 = vxor(v0,v0)
	}
// %bb.2:                               // %for.body.lr.ph.split
	{
		r6 = add(r1,#3)
		v11 = valign(v0,v0,#4)
		r5 = #8
		r7 = #16
	}
	{
		r8 = lsr(r6,#2)
		r6 = #1
		v12.w = vadd(v0.w,v11.w)
	}
	{
		loop0(.LBB21_3,r8)
	}
	{
		r5 = #0
		v13 = vror(v12,r5)
	}
	{
		v14.w = vadd(v12.w,v13.w)
	}
	{
		v15 = vror(v14,r7)
	}
	{
		v1.w = vadd(v14.w,v15.w)
	}
	.falign
.LBB21_3:                               // Block address taken
                                        // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB21_4 Depth 2
	{
		r7 = addasl(r3,r5,#2)
		r8 = addasl(r4,r5,#2)
		r9 = add(r29,#0)
		r12 = #0
	}
	{
		vmem(r29+#0) = v1
	}
	.falign
.LBB21_4:                               // %for.body11
                                        //   Parent Loop BB21_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p0 = cmp.gtu(r12,#2)
		r13 = memw(r7++#4)
		r14 = memw(r9+#0)
	}
	{
		r14 -= mpyi(r13,r2)
		if (p0) jump:nt .LBB21_6
		memw(r8++#4) = r14.new
	}
// %bb.5:                               // %for.body11
                                        //   in Loop: Header=BB21_4 Depth=2
	{
		r13 = add(r6,r12)
		r9 = add(r9,#32)
		r12 = add(r12,#1)
	}
	{
		p1 = cmp.gtu(r1,r13)
		if (p1.new) jump:t .LBB21_4
	}
	.falign
.LBB21_6:                               // %for.cond.cleanup10
                                        //   in Loop: Header=BB21_3 Depth=1
	{
		nop
		r5 = add(r5,#4)
		r6 = add(r6,#4)
	} :endloop0
	{
		jump .LBB21_17
	}
	.falign
.LBB21_7:
	{
		r13 = lsr(r8,#2)
		r5 = lsr(r2,#5)
		r7:6 = combine(#1,#0)
		r9 = #8
	}
	{
		r8 = ##16843009
		r12 = #16
	}
	{
		loop1(.LBB21_8,r13)
	}
	.falign
.LBB21_8:                               // Block address taken
                                        // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB21_10 Depth 2
                                        //     Child Loop BB21_14 Depth 2
	{
		r13 = addasl(r0,r6,#5)
		p1 = cmp.gtu(r5,#1)
		if (p1.new) r14 = add(r5,#-2)
		v2 = v0
	}
	{
		r13 = add(r13,#2048)
		if (!p1) jump:nt .LBB21_13
		v3 = vmemu(r13+#0)
	}
// %bb.9:                               // %for.body4.us
                                        //   in Loop: Header=BB21_8 Depth=1
	{
		p0 = cmp.gtu(r5,#2)
		v4 = vmemu(r13+#0)
	}
	{
		loop0(.LBB21_10,r14)
		r13 = add(r13,#2048)
		if (!p0) jump:nt .LBB21_11
		v2 = v0
	}
	.balign 32
.LBB21_10:                              // %for.body4.us
                                        //   Parent Loop BB21_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
		v4 = vmemu(r13+#0)
	}
	{
		r13 = add(r13,#2048)
		nop
	} :endloop0
	.falign
.LBB21_11:                              //   in Loop: Header=BB21_8 Depth=1
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
	}
	.falign
.LBB21_13:                              //   in Loop: Header=BB21_8 Depth=1
	{
		r13 = addasl(r3,r6,#2)
		v2.uw += vrmpy(v3.ub,r8.ub)
		r15 = #0
		r28 = add(r29,#0)
	}
	{
		r14 = addasl(r4,r6,#2)
	}
	{
		v5 = valign(v2,v2,#4)
	}
	{
		v6.w = vadd(v2.w,v5.w)
	}
	{
		v7 = vror(v6,r9)
	}
	{
		v8.w = vadd(v6.w,v7.w)
	}
	{
		v9 = vror(v8,r12)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		vmem(r29+#0) = v10.new
	}
	.falign
.LBB21_14:                              // %for.body11.us
                                        //   Parent Loop BB21_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p1 = cmp.gtu(r15,#2)
		r10 = memw(r13++#4)
		r11 = memw(r28+#0)
	}
	{
		r11 -= mpyi(r10,r2)
		if (p1) jump:nt .LBB21_16
		memw(r14++#4) = r11.new
	}
// %bb.15:                              // %for.body11.us
                                        //   in Loop: Header=BB21_14 Depth=2
	{
		r10 = add(r7,r15)
		r28 = add(r28,#32)
		r15 = add(r15,#1)
	}
	{
		p0 = cmp.gtu(r1,r10)
		if (p0.new) jump:t .LBB21_14
	}
	.falign
.LBB21_16:                              // %for.cond.cleanup10.us
                                        //   in Loop: Header=BB21_8 Depth=1
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	.falign
.LBB21_17:                              // %for.cond.cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end21:
	.size	hexkl_wh_affine_sums, .Lfunc_end21-hexkl_wh_affine_sums
                                        // -- End function
	.falign
	.type	moe_m1_pair_worker,@function    // -- Begin function moe_m1_pair_worker
moe_m1_pair_worker:                     // @moe_m1_pair_worker
// %bb.0:                               // %entry
	{
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#176)
	}                                       // 8-byte Folded Spill
	{
		r19 = add(r2,#8208)
		r22 = r1
		memd(r29+#160) = r19:18
		memd(r29+#144) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r19+#48)
		memd(r29+#152) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r18 = memw(r19+#0)
		memd(r29+#136) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r29+#128) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r16
		r25 = add(r16,#8196)
		r17 = add(r16,#8200)
		r24 = add(r22,#1)
	}
	{
		r2 += asl(r0,#9)
	}
	{
		r2 = memw(r2+#4)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_13
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r2 = memw(r25+#64)
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		r0 = sub(r2,r23)
	}
	.falign
// %bb.3:                               // %if.then
	{
		r26 = r20
		r2 = memw(r17+#0)
		r3 = memw(r19+#36)
	}
	{
		r2 = add(#127,asl(r2,#1))
		r1 = r26
		r21 = memw(r25+#0)
	}
	{
		r17 = lsr(r2,#7)
	}
	{
		r18 = mpyi(r17,r3)
	}
	{
		r20 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r20,r22)
		call __hexagon_udivsi3
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r20,r24)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r26
	}
	.falign
// %bb.5:                               // %if.then
	{
		r21 = or(#16,asl(r21,#5))
		r25 = r0
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB22_92
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r26 = add(r16,#8252)
		r2 = ##-1431655765
		r20 = r16
	}
	{
		r3 = add(r16,#8244)
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyu(r21,r2)
	}
	{
		r27 = lsr(r2,#4)
	}
	.falign
.LBB22_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB22_7 Depth=1
	{
		r2 = r0
		r16 = r17
		r21 = r19
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r21 -= mpyi(r0,r18)
	}
	{
		r22 = memw(r3+#0)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
		r17 = add(r2,r3)
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB22_7 Depth=1
	{
		r21 -= mpyi(r0,r22)
		r23 = r0
		r1 = r22
	}
	{
		r0 = mpyi(r21,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.10:                              // %for.body.i
                                        //   in Loop: Header=BB22_7 Depth=1
	{
		r24 = r0
		r1 = r22
		r2 = add(r21,#1)
	}
	{
		r0 = mpyi(r2,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.11:                              // %for.body.i
                                        //   in Loop: Header=BB22_7 Depth=1
	{
		r3 = r20
		r4 = r24
		r5 = sub(r0,r24)
		r2 = memw(r26+#0)
	}
	{
		r3 += asl(r17,#9)
		r4 += mpyi(r23,r27)
		r17 = r16
	}
	{
		r23 += mpyi(r21,r16)
		r1 = +mpyi(r5,#24)
	}
	{
		r2 += asl(r24,#9)
		r0 = memw(r3+#12)
		r3 = memw(r3+#28)
	}
	{
		r0 += mpyi(r4,##640)
		r3 += asl(r23,#9)
	}
	{
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.12:                              // %for.body.i
                                        //   in Loop: Header=BB22_7 Depth=1
	{
		r19 = add(r19,#1)
		if (cmp.gtu(r25,r19.new)) jump:t .LBB22_7
	}
	{
		jump .LBB22_92
	}
	.falign
.LBB22_13:                              // %if.end
	{
		r4 = add(r16,#8232)
		r2 = memw(r19+#16)
		memw(r29+#52) = r16
	}                                       // 4-byte Folded Spill
	{
		if (!p0.new) r18 = add(r20,#0)
		p0 = cmp.eq(r2,#0)
		memw(r29+#68) = r17
	}                                       // 4-byte Folded Spill
	{
		r3 = p0
		if (p0) jump:nt .LBB22_15
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:
	{
		p0 = or(p0,!p0)
	}
	{
		r3 = p0
		jump .LBB22_16
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB22_15:                              // %lor.rhs
	{
		r18 = r20
		r3 = memw(r4+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB22_16:                              // %lor.end
	{
		r5 = #512
		r1:0 = combine(#0,r2)
		r3 = memw(r25+#0)
		r6 = memw(r19+#28)
	}
	{
		r2 = lsr(r5,r6)
		r1:0 = asl(r1:0,#10)
		r21 = #0
		memw(r29+#56) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r3,r2)
	}
	{
		r20 = asl(r2,#1)
	}
	{
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.17:                              // %lor.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r5:4 = combine(#0,#0)
		memw(r29+#100) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#104) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_20
	}
// %bb.18:                              // %if.then6
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r2,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.19:                              // %if.then6
	{
		r5:4 = combine(r1,r0)
		r23 = memw(r17+#0)
	}
	.falign
.LBB22_20:                              // %do.end
	{
		r20 = r18
		r2 = memw(r25+#64)
		memd(r29+#112) = r5:4
	}                                       // 8-byte Folded Spill
	{
		r16 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r16,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.21:                              // %do.end
	{
		r1:0 = mpyu(r16,r24)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.22:                              // %do.end
	{
		r2 = add(r23,r0)
		r22 = memw(r29+#52)
		memw(r29+#92) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r22,#8236)
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB22_88
		if (p1.new) r1:0 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
// %bb.23:                              // %cond.end
	{
		r3:2 = combine(#127,#1)
		r20 = memw(r19+#0)
	}
	{
		r2 = maxu(r0,r2)
		r1:0 = combine(r20,r17)
	}
	{
		r16 = minu(r2,r3)
		call __hexagon_udivsi3
	}
	.falign
// %bb.24:                              // %cond.end
	{
		r2 = add(r0,#1)
		r3 = add(r17,r16)
		r16 = memw(r29+#100)
		memw(r29+#96) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r3 = minu(r2,r3)
		memw(r29+#84) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:nt .LBB22_35
	}
// %bb.25:                              // %cond.end
	{
		if (p0.new) r3:2 = combine(r22,r17)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB22_35
		if (p0.new) r4 = memw(r27+#0)
	}
// %bb.26:                              // %if.then17
	{
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r20 = sub(r4,r17)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB22_29
		r3 = r20
		r0 = memw(r3+#4)
	}
// %bb.27:                              // %if.then.i
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.28:                              // %if.then.i
	{
		jump .LBB22_30
	}
	.falign
.LBB22_29:                              // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB22_30:                              // %moe_m1_pf_gu.exit
	{
		r21 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.31:                              // %moe_m1_pf_gu.exit
	{
		r3:2 = combine(r17,r22)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r21)
		p0 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r21)
		r3 = r20
		r5 = memw(r2+#4)
	}
	{
		if (p0) jump:nt .LBB22_34
		r0 = memw(r5+#4)
	}
// %bb.32:                              // %if.then.i329
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.33:                              // %if.then.i329
	{
		jump .LBB22_35
	}
	.falign
.LBB22_34:                              // %if.else.i330
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB22_35:                              // %for.body.lr.ph
	{
		r18 = add(r22,#8228)
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		r0 = add(r22,#8264)
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
		if (p1) r5 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
	}
	{
		if (!p1) r5 = add(r3,#0)
		memw(r29+#80) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#76) = r5
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB22_36:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB22_41 Depth 2
                                        //       Child Loop BB22_74 Depth 3
                                        //       Child Loop BB22_81 Depth 3
	{
		r17 = memw(r29+#84)
		memw(r29+#60) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r17)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB22_39
		memw(r29+#88) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.37:                              // %cond.true23
                                        //   in Loop: Header=BB22_36 Depth=1
	{
		r20 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.38:                              // %cond.true23
                                        //   in Loop: Header=BB22_36 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#96)
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r2 = minu(r2,r0)
		memw(r29+#84) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB22_39:                              // %cond.end27
                                        //   in Loop: Header=BB22_36 Depth=1
	{
		r2 = memw(r29+#60)
		if (!cmp.gtu(r17,r2.new)) jump:t ##.LBB22_87
	}                                       // 4-byte Folded Reload
// %bb.40:                              // %for.body33.lr.ph
                                        //   in Loop: Header=BB22_36 Depth=1
	{
		r21 = memw(r29+#60)
		r2 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,r17)
		r3 = sub(r2,r17)
		memw(r29+#64) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB22_41:                              // %for.body33
                                        //   Parent Loop BB22_36 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB22_74 Depth 3
                                        //       Child Loop BB22_81 Depth 3
	{
		r23 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r21)
	}
	.falign
// %bb.42:                              // %for.body33
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r24 = r0
		r16 = r22
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r16 += asl(r0,#9)
		p0 = r2
	}
	{
		if (p0) jump:nt .LBB22_50
		r20 = memw(r16+#28)
	}
// %bb.43:                              // %for.body33
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r29+#60)
		if (!cmp.eq(r2.new,r21)) jump:nt .LBB22_50
	}                                       // 4-byte Folded Reload
// %bb.44:                              // %for.body33
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r1:0 = combine(r23,r17)
		if (!p0.new) jump:nt .LBB22_50
	}
// %bb.45:                              // %if.then48
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.46:                              // %if.then48
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r3:2 = combine(r22,r17)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r23)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB22_49
		r0 = memw(r3+#4)
		if (!p1) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.47:                              // %if.then.i352
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.48:                              // %if.then.i352
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		jump .LBB22_50
	}
	.falign
.LBB22_49:                              // %if.else.i353
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
		r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	.falign
.LBB22_50:                              // %if.end49
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r22 = r21
	}
	{
		r22 -= mpyi(r24,r23)
	}
	{
		r0 = asl(r22,#10)
	}
	{
		r23 = add(r20,r0)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_54
	}
// %bb.51:                              // %land.lhs.true53
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r5 = add(r16,#128)
		r0 = memw(r16+#0)
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r16+#388)
		r3 = memw(r16+#12)
	}
	{
		r2 = memw(r2+#0)
		r4 = memw(r27+#-24)
	}
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB22_56
		r2 = memw(r25+#0)
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then57
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r6 = memw(r19+#0)
		r7 = memw(r18+#0)
	}
	{
		r5 = r22
		r7 = add(r23,#512)
		memw(r29+#8) = r5
		memw(r29+#4) = r7
	}
	{
		r6 = add(r6,r22)
		memw(r29+#12) = r23
		memw(r29+#16) = r7
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#0) = r6
	}
	.falign
// %bb.53:                              // %if.then57
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		jump .LBB22_57
	}
	.falign
.LBB22_54:                              // %if.else75
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r0 = memw(r16+#0)
		r5 = memw(r18+#0)
	}
	{
		r1 = memw(r16+#388)
		r2 = memw(r25+#0)
	}
	{
		r3 = memw(r16+#12)
		r4 = memw(r27+#-24)
	}
	{
		r5 = r22
		r6 = memw(r29+#76)
		memw(r29+#0) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r23
	}
	{
		callr r6
	}
	.falign
// %bb.55:                              // %if.else75
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		jump .LBB22_57
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
.LBB22_56:                              // %if.then64
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r6 = memw(r18+#0)
		memw(r29+#0) = r6.new
	}
	{
		r5 = r22
		r6 = memw(r29+#80)
		memw(r29+#4) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r23
	}
	{
		callr r6
	}
	.falign
.LBB22_57:                              // %if.end85
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r21 = add(r21,#1)
		r0 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r21,r17)
	}
	{
		r2 = p1
		p1 = r0
		if (p1.new) jump:nt .LBB22_63
		memw(r29+#44) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.58:                              // %if.end85
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB22_63
		if (p1.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.59:                              // %if.end85
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB22_63
		if (p0.new) r24 = memw(r19+#0)
	}
// %bb.60:                              // %if.then94
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r17)
	}
	.falign
// %bb.61:                              // %if.then94
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r3 = r17
		r2 = memw(r29+#52)
		r4 = memw(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r24)
		p0 = cmp.eq(r4,#0)
		r1 = memw(r27+#-24)
	}
	{
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r24)
		r5 = memw(r2+#4)
		if (!p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB22_67
		r0 = memw(r5+#4)
		if (p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %if.then.i367
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB22_63:                              // %if.end95
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_69
	}
	.falign
.LBB22_64:                              // %land.lhs.true99
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB22_70
	}
// %bb.65:                              // %if.then108
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = add(r16,#128)
		memw(r29+#8) = r6
	}
	{
		r6 = memw(r29+#80)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.66:                              // %if.then108
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		jump .LBB22_70
	}
	.falign
.LBB22_67:                              // %if.else.i368
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.68:                              // %if.else.i368
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB22_64
	}
	.falign
.LBB22_69:                              // %if.else122
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = memw(r29+#76)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
.LBB22_70:                              // %if.end135
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r2 = memw(r4+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_85
	}
// %bb.71:                              // %if.then138
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r3 = asl(r22,#5)
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB22_85
	}
// %bb.72:                              // %for.body.us.i
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r9 = lsr(r5,#1)
		r5 = r23
		r4 = and(r5,#1)
	}
	{
		r7 = addasl(r2,r3,#2)
		r2 = add(r16,#56)
		p1 = cmp.gtu(r9,#0)
		if (p1.new) r5 = add(r23,#0)
	}
	{
		if (p1) r8 = add(r2,#0)
		r6 = r2
	}
	{
		if (!p1) jump:nt .LBB22_75
		v0 = vmemu(r7+#0)
	}
// %bb.73:                              //   in Loop: Header=BB22_41 Depth=2
	{
		loop0(.LBB22_74,r9)
		r7:6 = combine(r23,r2)
	}
	.balign 32
.LBB22_74:                              //   Parent Loop BB22_36 Depth=1
                                        //     Parent Loop BB22_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r6++#8)
	}
	{
		v2 = vsplat(r9)
		v3 = vmemu(r7+#0)
	}
	{
		v5 = vmemu(r7+#1)
	}
	{
		v3.w += vmpyie(v2.w,v0.h)
	}
	{
		vmemu(r5++#2) = v3
	}
	{
		r8 = memw(r8+#4)
	}
	{
		v4 = vsplat(r8)
		r8 = r6
	}
	{
		v5.w += vmpyie(v4.w,v0.h)
	}
	{
		r7 = r5
		vmemu(r7+#1) = v5
	} :endloop0
	.falign
.LBB22_75:                              //   in Loop: Header=BB22_41 Depth=2
	{
		p0 = cmp.gtu(r4,#0); if (!p0.new) jump:t .LBB22_77
		if (p0.new) r4 = memw(r6+#0)
	}
	.falign
.LBB22_76:                              // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		v6 = vsplat(r4)
		v7 = vmemu(r5+#0)
	}
	{
		v7.w += vmpyie(v6.w,v0.h)
	}
	{
		vmemu(r5++#1) = v7
	}
	.falign
.LBB22_77:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r6 = memw(r4+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB22_85
	}
// %bb.78:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB22_85
	}
// %bb.79:                              // %for.body.us.i376
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r7 = lsr(r5,#1)
		r5 = and(r5,#1)
		r4 = memw(r20+#0)
	}
	{
		r4 = addasl(r6,r4,#2)
		r6 = add(r23,#512)
		p1 = cmp.gtu(r7,#0)
	}
	{
		r3 = addasl(r4,r3,#2)
		r4 = r2
	}
	{
		r3 = r6
		if (!p1) jump:nt .LBB22_82
		v1 = vmemu(r3+#0)
	}
// %bb.80:                              //   in Loop: Header=BB22_41 Depth=2
	{
		loop0(.LBB22_81,r7)
	}
	.balign 32
.LBB22_81:                              //   Parent Loop BB22_36 Depth=1
                                        //     Parent Loop BB22_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r4++#8)
	}
	{
		v8 = vsplat(r7)
		v9 = vmemu(r6+#0)
	}
	{
		v11 = vmemu(r6+#1)
	}
	{
		v9.w += vmpyie(v8.w,v1.h)
	}
	{
		vmemu(r3++#2) = v9
	}
	{
		r2 = memw(r2+#4)
	}
	{
		v10 = vsplat(r2)
		r2 = r4
	}
	{
		v11.w += vmpyie(v10.w,v1.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v11
	} :endloop0
	.falign
.LBB22_82:                              //   in Loop: Header=BB22_41 Depth=2
	{
		p0 = cmp.gtu(r5,#0); if (!p0.new) jump:t .LBB22_84
		if (p0.new) r2 = memw(r4+#0)
	}
	.falign
.LBB22_83:                              // Block address taken
                                        // %for.body3.us.i379
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		v12 = vsplat(r2)
		v13 = vmemu(r3+#0)
	}
	{
		v13.w += vmpyie(v12.w,v1.h)
	}
	{
		vmemu(r3++#1) = v13
	}
	.falign
.LBB22_84:                              // %if.end154.loopexit
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	.falign
.LBB22_85:                              // %if.end154
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r6 = memw(r29+#72)
		r5 = memw(r16+#388)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r4+#8)
		r2 = memw(r16+#20)
	}
	{
		r3 = memw(r16+#24)
		r4 = memw(r4+#16)
	}
	{
		r6 = memw(r6+#0)
		r7 = memw(r16+#36)
	}
	{
		r4 = #32
		r8 = memw(r20+#0)
		memw(r29+#16) = r4

	} :mem_noshuf
	{
		r0 = r23
		r1 = #512
		memw(r29+#12) = r0
		memw(r29+#8) = r1
	}
	{
		r3:2 = combine(r22,#1)
		memw(r29+#4) = r3
		memw(r29+#0) = r2
	}
	{
		memw(r29+#36) = #0
		memw(r29+#32) = r8
	}
	{
		memw(r29+#28) = r7
		memw(r29+#24) = r6
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#20) = r8
	}
	.falign
// %bb.86:                              // %if.end154
                                        //   in Loop: Header=BB22_41 Depth=2
	{
		r2 = memw(r29+#44)
		r22 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB22_41
	}
	.falign
.LBB22_87:                              // %for.cond.loopexit
                                        //   in Loop: Header=BB22_36 Depth=1
	{
		r2 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB22_36
	}
	.falign
.LBB22_88:                              // %for.cond.cleanup
	{
		r16 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB22_92
	}
// %bb.89:                              // %if.then.i332
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.90:                              // %if.then.i332
	{
		r3:2 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB22_91:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB22_91
	}
	.falign
.LBB22_92:                              // %cleanup
	{
		r17:16 = memd(r29+#168)
		r19:18 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#152)
		r23:22 = memd(r29+#144)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#136)
		r27:26 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end22:
	.size	moe_m1_pair_worker, .Lfunc_end22-moe_m1_pair_worker
                                        // -- End function
	.falign
	.type	moe_m1_q_post_after_a,@function // -- Begin function moe_m1_q_post_after_a
moe_m1_q_post_after_a:                  // @moe_m1_q_post_after_a
// %bb.0:                               // %entry
	{
		r6 = add(r2,#2)
		r14 = #640
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(r1,#8192)
		r16 = ##-858960692
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r7 = memw(r20+#0)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r7,r6)
		memd(r29+#32) = r23:22
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p1) r22 = add(r1,##8204)
		if (!p1) jump:nt .LBB23_7
		memd(r29+#16) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r1 += asl(r6,#9)
		p0 = tstbit(r2,#0)
		r5 = memw(r0+#40)
		r2 = memw(r20+#20)
	}
	{
		r6 = asl(r2,#9)
		r7 = add(r5,#1)
		if (!p0) r4 = #0
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		r3 = add(r3,r4)
		r19 = memw(r1+#4)
		r2 = memw(r20+#4)
	}
	{
		r4 = lsr(r6,#1)
		r18 = add(r0,r5)
	}
	{
		r3 = memw(r19+#84)
		memw(r0+r5<<#0) = r3
	}
	{
		p1 = cmp.eq(r3,#2)
		r0 = memw(r19+#44)
		r3 = memw(r19+#4)
	}
	{
		p0 = cmp.eq(r0,#0)
		if (!p1) r4 = add(r6,#0)
		memw(r18+#4) = r3
		memw(r18+#12) = r2
	}
	{
		if (p0) jump:nt .LBB23_4
		if (!p0) r0 = memw(r19+#28)
		memw(r18+#8) = r4
	}
// %bb.2:                               // %if.then.i
	{
		r1 = memw(r19+#32)
		memw(r18+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.3:                               // %if.then.i
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r18+#12) = r2.new
	}
	.falign
.LBB23_4:                               // %if.end.i
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB23_14
	}
// %bb.5:                               // %land.rhs.i.i
	{
		r3 = memw(r19+#36)
	}
	{
		r3 = #1
		p0 = cmp.eq(r3,#0); if (!p0.new) jump:t .LBB23_15
	}
// %bb.6:                               // %lor.rhs.i.i
	{
		r3 = memw(r19+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB23_15
	}
	.falign
.LBB23_7:                               // %if.end
	{
		r17 = add(pc,##g_moe_src_bypass@PCREL)
		r2 = and(#2,asl(r2,#1))
		r25 = add(r1,#8216)
	}
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p0 = cmp.gtu(r7,r2)
		p2 = cmp.eq(r2,#0)
	}
	{
		r7 = r1
		if (!p0) jump:nt .LBB23_20
		if (p0) r8 = memw(r0+#40)
		if (p0) r6 = memw(r25+#0)
	}
// %bb.8:                               // %if.then9
	{
		r7 += asl(r2,#9)
		r12 = asl(r6,#9)
		r9 = mux(p2,#0,r4)
		r6 = memw(r22+#0)
	}
	{
		r13 = +mpyi(r8,#20)
		r8 = add(r8,#1)
		r10 = add(r3,r9)
		memw(r0+#40) = r8.new
	}
	{
		r23 = add(r0,r13)
		r24 = memw(r7+#8)
	}
	{
		memw(r0+r13<<#0) = r10
		memw(r23+#12) = r6
	}
	{
		r7 = memw(r24+#84)
		r11 = memw(r24+#44)
	}
	{
		r7 = lsr(r12,#1)
		p0 = cmp.eq(r7,#2)
		p1 = cmp.eq(r11,#0)
		r13 = memw(r24+#4)
	}
	{
		if (!p0) r7 = add(r12,#0)
		memw(r23+#4) = r13
	}
	{
		if (p1) jump:nt .LBB23_11
		memw(r23+#8) = r7
	}
// %bb.9:                               // %if.then.i49
	{
		r27:26 = combine(r3,r1)
		r21 = r18
		r6 = memw(r24+#28)
		memw(r29+#4) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		r0 = r6
		r19:18 = combine(r2,r17)
		r6 = memw(r24+#32)
	}
	{
		r1 = r6
		r17:16 = combine(r4,r5)
		memw(r23+#8) = r14
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Spill
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.10:                              // %if.then.i49
	{
		r5:4 = combine(r16,r17)
		r16 = ##-858960692
		r2 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r7 = add(r16,#-32767)
		r6 = r0
		r0 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r6 = mpyu(r6,r7)
		r17 = r18
		r14 = #640
		r3:2 = combine(r27,r19)
	}
	{
		r6 = lsr(r6,#9)
		r18 = r21
		r1 = r26
		memw(r23+#12) = r6.new
	}
	.falign
.LBB23_11:                              // %if.end.i54
	{
		r7 = memw(r17+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB23_17
	}
// %bb.12:                              // %land.rhs.i.i56
	{
		r7 = memw(r24+#36)
	}
	{
		r7 = #1
		p1 = cmp.eq(r7,#0); if (!p1.new) jump:t .LBB23_18
	}
// %bb.13:                              // %lor.rhs.i.i68
	{
		r7 = memw(r24+#40)
	}
	{
		r7 = !cmp.eq(r7,#0)
		jump .LBB23_18
	}
	.falign
.LBB23_14:
	{
		r3 = #0
	}
	.falign
.LBB23_15:                              // %moe_weight_src_bypass.exit.i
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r18+#16) = r3
	}
	{
		r3 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB23_31
	}
// %bb.16:
	{
		r3 = add(r18,#8)
		jump .LBB23_30
	}
	.falign
.LBB23_17:
	{
		r7 = #0
	}
	.falign
.LBB23_18:                              // %moe_weight_src_bypass.exit.i59
	{
		memw(r23+#16) = r7
	}
	{
		r7 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r7 = memw(r7+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB23_20
	}
// %bb.19:                              // %if.then7.i63
	{
		r7 = memw(r23+#8)
		r8 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r6 = mpyi(r7,r6)
		r7 = #0
		r13:12 = memd(r8+#56)
	}
	{
		r6 = lsr(r6,#10)
	}
	{
		r7:6 = add(r13:12,r7:6)
	}
	{
		memd(r8+#56) = r7:6
	}
	.falign
.LBB23_20:                              // %for.inc
	{
		r2 = setbit(r2,#0)
	}
	{
		r1 += asl(r2,#9)
		r6 = memw(r20+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t .LBB23_31
	}
// %bb.21:                              // %if.then9.1
	{
		r7 = mux(p2,#0,r4)
		r6 = memw(r0+#40)
		r2 = memw(r25+#0)
	}
	{
		r8 = asl(r2,#9)
		r4 = add(r6,#1)
		memw(r0+#40) = r4.new
	}
	{
		r6 = +mpyi(r6,#20)
		r5 += add(r3,r7)
		r21 = memw(r1+#8)
		r2 = memw(r22+#0)
	}
	{
		r4 = lsr(r8,#1)
		r20 = add(r0,r6)
	}
	{
		r3 = memw(r21+#84)
		memw(r0+r6<<#0) = r5
	}
	{
		p0 = cmp.eq(r3,#2)
		r0 = memw(r21+#44)
		r3 = memw(r21+#4)
	}
	{
		p1 = cmp.eq(r0,#0)
		if (!p0) r4 = add(r8,#0)
		memw(r20+#4) = r3
		memw(r20+#12) = r2
	}
	{
		if (p1) jump:nt .LBB23_24
		if (!p1) r0 = memw(r21+#28)
		memw(r20+#8) = r4
	}
// %bb.22:                              // %if.then.i49.1
	{
		r1 = memw(r21+#32)
		memw(r20+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.23:                              // %if.then.i49.1
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r20+#12) = r2.new
	}
	.falign
.LBB23_24:                              // %if.end.i54.1
	{
		r3 = memw(r17+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB23_27
	}
// %bb.25:                              // %land.rhs.i.i56.1
	{
		r3 = memw(r21+#36)
	}
	{
		r3 = #1
		p1 = cmp.eq(r3,#0); if (!p1.new) jump:t .LBB23_28
	}
// %bb.26:                              // %lor.rhs.i.i68.1
	{
		r3 = memw(r21+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB23_28
	}
	.falign
.LBB23_27:
	{
		r3 = #0
	}
	.falign
.LBB23_28:                              // %moe_weight_src_bypass.exit.i59.1
	{
		memw(r20+#16) = r3
	}
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB23_31
	}
// %bb.29:
	{
		r3 = add(r20,#8)
	}
	.falign
.LBB23_30:                              // %for.end.sink.split
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r1 = #0
		r3 = memw(r3+#0)
	}
	{
		r2 = mpyi(r3,r2)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r2,#10)
	}
	{
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB23_31:                              // %for.end
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end23:
	.size	moe_m1_q_post_after_a, .Lfunc_end23-moe_m1_q_post_after_a
                                        // -- End function
	.falign
	.type	moe_tl2_gate_epilogue_worker,@function // -- Begin function moe_tl2_gate_epilogue_worker
moe_tl2_gate_epilogue_worker:           // @moe_tl2_gate_epilogue_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#640):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r19 = add(r2,#8200)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r2)
		r21:20 = memd(r19+#56)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r21 = sub(r21,r20)
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r0 = mpyi(r21,r1)
		call __hexagon_udivsi3
		r1 = r18
	}
	.falign
// %bb.1:                               // %entry
	{
		r17 = add(r0,r20)
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r21,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.2:                               // %entry
	{
		r21 = add(r16,#8208)
		r20 = add(r0,r20)
		if (!cmp.gtu(r20.new,r17)) jump:t ##.LBB24_71
	}
// %bb.3:                               // %for.body.lr.ph.i
	{
		r22 = add(r16,#8244)
		r23 = add(r16,#8264)
		r24 = #3
		r2 = memw(r19+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r25 = and(r2,#-128)
	}
	.falign
.LBB24_4:                               // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB24_8 Depth 2
                                        //     Child Loop BB24_12 Depth 2
                                        //     Child Loop BB24_40 Depth 2
                                        //     Child Loop BB24_44 Depth 2
	{
		r18 = memw(r21+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.5:                               // %for.body.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r3:2 = combine(r16,r17)
		r5 = #1
		r6 = memw(r22+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB24_14
		v0 = vmem(r4+#0)
	}
// %bb.6:                               // %for.body13.i.preheader
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = mpyi(r5,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB24_10
	}
// %bb.7:                               //   in Loop: Header=BB24_4 Depth=1
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB24_8,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r4,r13,#2)
		v3.w = vadd(v0.w,v23.w)
		v23.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB24_9
	}
	.falign
.LBB24_8:                               //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r25)
		v25.w = vadd(v3.w,v24.w)
		v24.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v26 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r5,#3)
		v27.w = vadd(v25.w,v26.w)
		v28 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r5 = add(r5,#4)
		v29.w = vadd(v27.w,v28.w)
		v30 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r4,r9,#2)
		v3.w = vadd(v29.w,v30.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB24_9:                               //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = addasl(r4,r12,#2)
		v0.w = vadd(v3.w,v31.w)
		v31.cur = vmem(r13+#0)
	}
	{
		v2.w = vadd(v0.w,v1.w)
		v1.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v2.w,v3.w)
		v3.cur = vmem(r12+#0)
	}
	.falign
.LBB24_10:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = mpyi(r5,r25)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB24_14
	}
// %bb.11:                              // %for.body13.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB24_12,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB24_13
	}
	.balign 32
.LBB24_12:                              // %for.body13.i
                                        //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r5,r25)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v4.w)
		v4.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB24_13:                              //   in Loop: Header=BB24_4 Depth=1
	{
		v0.w = vadd(v0.w,v5.w)
		v5.cur = vmem(r8+#0)
	}
	.falign
.LBB24_14:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r5 = memw(r3+#4)
		vmem(r29+#2) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r19+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB24_17
	}
// %bb.15:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB24_17
	}
// %bb.16:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_17:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB24_22
	}
// %bb.18:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB24_20
	}
// %bb.19:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_20:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		if (p1) jump:nt .LBB24_23
	}
// %bb.21:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_23
	}
	.falign
.LBB24_22:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB24_23:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB24_28
	}
// %bb.24:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB24_26
	}
// %bb.25:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_26:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB24_29
	}
// %bb.27:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_29
	}
	.falign
.LBB24_28:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r8 = r9
	}
	.falign
.LBB24_29:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB24_34
	}
// %bb.30:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB24_32
	}
// %bb.31:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB24_37
	}
	.falign
.LBB24_32:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB24_35
	}
// %bb.33:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_35
	}
	.falign
.LBB24_34:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB24_35:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB24_37
		v4.w = vasl(v0.w,r24)
	}
// %bb.36:                              // %if.end.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		v5.w = vsub(v4.w,v0.w)
		vmem(r29+#2) = v5.new
	}
	.falign
.LBB24_37:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB24_46
		v1 = vmem(r7+#0)
	}
// %bb.38:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = mpyi(r6,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB24_42
	}
// %bb.39:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB24_40,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r7,r13,#2)
		v2.w = vadd(v1.w,v6.w)
		v6.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB24_41
	}
	.falign
.LBB24_40:                              //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r25)
		v8.w = vadd(v2.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v9 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r6,#3)
		v10.w = vadd(v8.w,v9.w)
		v11 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r6 = add(r6,#4)
		v12.w = vadd(v10.w,v11.w)
		v13 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r7,r9,#2)
		v2.w = vadd(v12.w,v13.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB24_41:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = addasl(r7,r12,#2)
		v15.w = vadd(v2.w,v14.w)
		v14.cur = vmem(r13+#0)
	}
	{
		v17.w = vadd(v15.w,v16.w)
		v16.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v17.w,v18.w)
		v18.cur = vmem(r12+#0)
	}
	.falign
.LBB24_42:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = mpyi(r6,r25)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB24_46
	}
// %bb.43:                              // %for.body13.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB24_44,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB24_45
	}
	.balign 32
.LBB24_44:                              // %for.body13.1.i
                                        //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r6,r25)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v19.w)
		v19.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB24_45:                              //   in Loop: Header=BB24_4 Depth=1
	{
		v1.w = vadd(v1.w,v20.w)
		v20.cur = vmem(r8+#0)
	}
	.falign
.LBB24_46:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		vmem(r29+#3) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB24_49
	}
// %bb.47:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB24_49
	}
// %bb.48:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB24_69
	}
	.falign
.LBB24_49:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_54
	}
// %bb.50:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB24_52
	}
// %bb.51:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB24_69
	}
	.falign
.LBB24_52:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		if (p0) jump:nt .LBB24_55
	}
// %bb.53:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_55
	}
	.falign
.LBB24_54:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB24_55:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB24_60
	}
// %bb.56:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB24_58
	}
// %bb.57:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB24_69
	}
	.falign
.LBB24_58:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB24_61
	}
// %bb.59:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_61
	}
	.falign
.LBB24_60:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r6 = r7
	}
	.falign
.LBB24_61:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_66
	}
// %bb.62:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB24_64
	}
// %bb.63:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB24_69
	}
	.falign
.LBB24_64:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB24_67
	}
// %bb.65:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_67
	}
	.falign
.LBB24_66:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB24_67:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB24_69
		v21.w = vasl(v1.w,r24)
	}
// %bb.68:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		v22.w = vsub(v21.w,v1.w)
		vmem(r29+#3) = v22.new
	}
	.falign
.LBB24_69:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r23+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#256)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.70:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r20)) jump:t ##.LBB24_4
	}
	.falign
.LBB24_71:                              // %moe_tl2_gate_epilogue.exit
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end24:
	.size	moe_tl2_gate_epilogue_worker, .Lfunc_end24-moe_tl2_gate_epilogue_worker
                                        // -- End function
	.falign
	.type	moe_m1_wait,@function           // -- Begin function moe_m1_wait
moe_m1_wait:                            // @moe_m1_wait
// %bb.0:                               // %entry
	{
		r17 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r16 = r0
	}
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_2
	}
// %bb.1:                               // %if.then
	{
		r3 = r1
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r16
	}
	.falign
.LBB25_2:                               // %if.end
	{
		call hexkl_dma_ring_wait
		r0 = r16
	}
	.falign
// %bb.3:                               // %if.end
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_5
	}
// %bb.4:                               // %if.then2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump hexkl_dma_trace_wait_end
		r17:16 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB25_5:                               // %if.end4
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end25:
	.size	moe_m1_wait, .Lfunc_end25-moe_m1_wait
                                        // -- End function
	.falign
	.type	moe_m1_requant_worker,@function // -- Begin function moe_m1_requant_worker
moe_m1_requant_worker:                  // @moe_m1_requant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = add(r2,#8192)
		r17 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		r16 = memw(r22+#0)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r27 = r2
		r3:2 = combine(r21,r20)
		memd(r30+#-48) = r27:26
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r16,r1)
		call __hexagon_udivdi3
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r16,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r21:20 = combine(r1,r0)
	}
	{
		r21 = #16
		if (p0.new) r19 = #8
		p0 = cmp.gtu(r20,r18); if (!p0.new) jump:t .LBB26_103
	}
// %bb.3:                               // %for.body.lr.ph
	{
		r24 = add(r27,#8200)
		v20 = vxor(v20,v20)
		vmem(r29+#2) = v20.new
	}                                       // 128-byte Folded Spill
	{
		r25 = ##16843009
		memw(r29+#244) = r22
		memd(r29+#248) = r21:20
	}                                       // 4-byte Folded Spill
	{
		v7 = valign(v20,v20,#4)
	}
	{
		v8.w = vadd(v20.w,v7.w)
	}
	{
		v9 = vror(v8,r19)
	}
	{
		v10.w = vadd(v8.w,v9.w)
	}
	{
		v11 = vror(v10,r21)
	}
	{
		v22.w = vadd(v10.w,v11.w)
		vmem(r29+#3) = v22.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB26_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB26_8 Depth 2
                                        //       Child Loop BB26_12 Depth 3
                                        //       Child Loop BB26_16 Depth 3
                                        //       Child Loop BB26_44 Depth 3
                                        //       Child Loop BB26_48 Depth 3
                                        //     Child Loop BB26_94 Depth 2
                                        //       Child Loop BB26_96 Depth 3
                                        //       Child Loop BB26_100 Depth 3
                                        //     Child Loop BB26_89 Depth 2
                                        //       Child Loop BB26_90 Depth 3
	{
		r16 = r27
		r2 = r18
	}
	{
		r16 += asl(r18,#9)
		r18 = add(r18,#1)
	}
	{
		r3 = memw(r16+#4)
	}
	{
		r3 = memw(r3+#44)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB26_76
	}
// %bb.5:                               // %land.lhs.true
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r22+#56)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB26_76
	}
// %bb.6:                               // %if.then
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r22+#16)
	}
	{
		r17 = mpyi(r3,r2)
	}
	{
		r26 = mpyi(r3,r18)
		if (!cmp.gtu(r26.new,r17)) jump:t ##.LBB26_75
	}
// %bb.7:                               // %for.body.i.preheader
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r22 = add(r27,#8208)
		r20 = add(r27,#8244)
		r21 = add(r27,#8264)
		r2 = memw(r24+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r23 = and(r2,#-128)
	}
	.falign
.LBB26_8:                               // %for.body.i
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_12 Depth 3
                                        //       Child Loop BB26_16 Depth 3
                                        //       Child Loop BB26_44 Depth 3
                                        //       Child Loop BB26_48 Depth 3
	{
		r19 = memw(r22+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r17)
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r3:2 = combine(r27,r17)
		r5 = #1
		r6 = memw(r20+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r19)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB26_18
		v0 = vmem(r4+#0)
	}
// %bb.10:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = mpyi(r5,r23)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB26_14
	}
// %bb.11:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r23)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB26_12,r9)
		r14 = mpyi(r14,r23)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r23)
		r13 = addasl(r4,r13,#2)
		v5.w = vadd(v0.w,v31.w)
		v31.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB26_13
	}
	.falign
.LBB26_12:                              //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r23)
		v1.w = vadd(v5.w,v0.w)
		v0.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v2 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r23)
		r12 = add(r5,#3)
		v3.w = vadd(v1.w,v2.w)
		v4 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r23)
		r5 = add(r5,#4)
		v5.w = vadd(v3.w,v4.w)
		v6 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r23)
		r9 = addasl(r4,r9,#2)
		v5.w = vadd(v5.w,v6.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB26_13:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = addasl(r4,r12,#2)
		v8.w = vadd(v5.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		v9.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v10.w,v11.w)
		v11.cur = vmem(r12+#0)
	}
	.falign
.LBB26_14:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = mpyi(r5,r23)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB26_18
	}
// %bb.15:                              // %for.body13.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB26_16,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB26_17
	}
	.balign 32
.LBB26_16:                              // %for.body13.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r5,r23)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v12.w)
		v12.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB26_17:                              //   in Loop: Header=BB26_8 Depth=2
	{
		v0.w = vadd(v0.w,v13.w)
		v13.cur = vmem(r8+#0)
	}
	.falign
.LBB26_18:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r5 = memw(r3+#4)
		vmem(r29+#4) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r24+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB26_21
	}
// %bb.19:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB26_21
	}
// %bb.20:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_21:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB26_26
	}
// %bb.22:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB26_24
	}
// %bb.23:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_24:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		if (p1) jump:nt .LBB26_27
	}
// %bb.25:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_27
	}
	.falign
.LBB26_26:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB26_27:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB26_32
	}
// %bb.28:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB26_30
	}
// %bb.29:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_30:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB26_33
	}
// %bb.31:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_33
	}
	.falign
.LBB26_32:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = r9
	}
	.falign
.LBB26_33:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB26_38
	}
// %bb.34:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB26_36
	}
// %bb.35:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB26_41
	}
	.falign
.LBB26_36:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB26_39
	}
// %bb.37:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_39
	}
	.falign
.LBB26_38:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB26_39:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = #3
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB26_41
	}
// %bb.40:                              // %if.end.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		v12.w = vasl(v0.w,r8)
	}
	{
		v13.w = vsub(v12.w,v0.w)
		vmem(r29+#4) = v13.new
	}
	.falign
.LBB26_41:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB26_50
		v1 = vmem(r7+#0)
	}
// %bb.42:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = mpyi(r6,r23)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB26_46
	}
// %bb.43:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r23)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB26_44,r9)
		r14 = mpyi(r14,r23)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r23)
		r13 = addasl(r7,r13,#2)
		v4.w = vadd(v1.w,v14.w)
		v14.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB26_45
	}
	.falign
.LBB26_44:                              //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r23)
		v16.w = vadd(v4.w,v15.w)
		v15.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v17 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r23)
		r12 = add(r6,#3)
		v18.w = vadd(v16.w,v17.w)
		v19 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r23)
		r6 = add(r6,#4)
		v20.w = vadd(v18.w,v19.w)
		v21 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r23)
		r9 = addasl(r7,r9,#2)
		v4.w = vadd(v20.w,v21.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB26_45:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = addasl(r7,r12,#2)
		v23.w = vadd(v4.w,v22.w)
		v22.cur = vmem(r13+#0)
	}
	{
		v25.w = vadd(v23.w,v24.w)
		v24.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v25.w,v26.w)
		v26.cur = vmem(r12+#0)
	}
	.falign
.LBB26_46:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = mpyi(r6,r23)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB26_50
	}
// %bb.47:                              // %for.body13.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB26_48,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB26_49
	}
	.balign 32
.LBB26_48:                              // %for.body13.1.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r6,r23)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v27.w)
		v27.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB26_49:                              //   in Loop: Header=BB26_8 Depth=2
	{
		v1.w = vadd(v1.w,v28.w)
		v28.cur = vmem(r8+#0)
	}
	.falign
.LBB26_50:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		vmem(r29+#5) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB26_53
	}
// %bb.51:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB26_53
	}
// %bb.52:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB26_73
	}
	.falign
.LBB26_53:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB26_58
	}
// %bb.54:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB26_56
	}
// %bb.55:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB26_73
	}
	.falign
.LBB26_56:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		if (p0) jump:nt .LBB26_59
	}
// %bb.57:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_59
	}
	.falign
.LBB26_58:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB26_59:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB26_64
	}
// %bb.60:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB26_62
	}
// %bb.61:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB26_73
	}
	.falign
.LBB26_62:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB26_65
	}
// %bb.63:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_65
	}
	.falign
.LBB26_64:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = r7
	}
	.falign
.LBB26_65:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB26_70
	}
// %bb.66:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB26_68
	}
// %bb.67:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB26_73
	}
	.falign
.LBB26_68:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB26_71
	}
// %bb.69:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_71
	}
	.falign
.LBB26_70:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB26_71:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = #3
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB26_73
	}
// %bb.72:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		v29.w = vasl(v1.w,r6)
	}
	{
		v30.w = vsub(v29.w,v1.w)
		vmem(r29+#5) = v30.new
	}
	.falign
.LBB26_73:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#512)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.74:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r26)) jump:t ##.LBB26_8
	}
	.falign
.LBB26_75:                              // %moe_tl2_gate_epilogue.exit
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r19 = #8
		r21:20 = memd(r29+#248)
		r22 = memw(r29+#244)
	}                                       // 8-byte Folded Reload
	{
		r21 = #16
	}
	.falign
.LBB26_76:                              // %if.end
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_80
	}
// %bb.77:                              // %if.then6
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = #1
		r2 = #1
		r7:6 = memd(r16+#40)
		r0 = memw(r16+#36)
	}
	{
		r4 = r7
		r3 = memw(r24+#0)
		r5 = memw(r16+#48)
	}
	{
		memw(r29+#0) = r6
		memw(r29+#16) = #0
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_rows_u8_params_rm
		memw(r29+#4) = #0
	}
	.falign
// %bb.78:                              // %if.then6
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = ##-1431655765
		r1 = memw(r24+#0)
		r0 = memw(r16+#40)
	}
	{
		r2 = add(r1,#23)
		r4 = memw(r16+#384)
	}
	{
		r3 = mpyu(r2,r3)
		r2 = #0
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
.LBB26_79:                              // %cleanup
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		p2 = cmp.gtu(r20,r18)
		if (p2.new) jump:t .LBB26_4
	}
	{
		jump .LBB26_103
	}
	.falign
.LBB26_80:                              // %if.end11
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r24+#0)
	}
	{
		r2 = add(r1,#3)
	}
	{
		r17 = and(r2,#-4)
		if (!cmp.gtu(r17.new,r1)) jump:t .LBB26_83
	}
// %bb.81:                              // %if.then17
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r5 = mpyi(r3,r1)
		r2 = sub(r17,r1)
		r1 = #0
		r4 = memw(r16+#36)
	}
	{
		r2 = mpyi(r2,r3)
		r0 = addasl(r4,r5,#2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.82:                              // %if.then17
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r24+#0)
	}
	.falign
.LBB26_83:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = #64
		r0 = memw(r16+#36)
		r4 = memw(r16+#44)
	}
	{
		call hvx_quant_rows_u8_params
		r5 = memw(r16+#48)
		memw(r29+#0) = #0

	} :mem_noshuf
	.falign
// %bb.84:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = #0
		r7:6 = memd(r16+#40)
		r2 = memw(r16+#48)
	}
	{
		r5 = r7
		r0 = memw(r16+#36)
		r4 = memw(r24+#0)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r17,#0)
		memw(r29+#0) = r2
		memw(r29+#4) = r6
	}
	.falign
// %bb.85:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_79
	}
// %bb.86:                              // %if.then39
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r5 = add(r16,#72)
		r9:8 = combine(#1,#0)
		r2 = memw(r16+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_79
	}
// %bb.87:                              // %for.body.lr.ph.i93
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r24+#0)
		r4 = memw(r16+#48)
	}
	{
		p2 = cmp.gtu(r3,#31)
		if (p2.new) r7 = add(r2,#3)
		if (p2.new) jump:t .LBB26_93
		r6 = memw(r16+#40)
	}
// %bb.88:                              // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r6 = add(r2,#3)
	}
	{
		r8 = lsr(r6,#2)
		r7:6 = combine(#1,#0)
	}
	{
		loop1(.LBB26_89,r8)
	}
	.falign
.LBB26_89:                              // Block address taken
                                        // %for.body.i95
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_90 Depth 3
	{
		r8 = addasl(r4,r6,#2)
		r9 = addasl(r5,r6,#2)
		r12 = add(r29,#512)
		r13 = #0
	}
	{
		v21.cur = vmem(r29+#3)
		vmem(r29+#4) = v21
	}                                       // 128-byte Folded Reload
	.falign
.LBB26_90:                              // %for.body11.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_89 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r13,#2)
		r14 = memw(r8++#4)
		r15 = memw(r12+#0)
	}
	{
		r15 -= mpyi(r14,r3)
		if (p1) jump:nt .LBB26_92
		memw(r9++#4) = r15.new
	}
// %bb.91:                              // %for.body11.i
                                        //   in Loop: Header=BB26_90 Depth=3
	{
		r14 = add(r7,r13)
		r12 = add(r12,#32)
		r13 = add(r13,#1)
	}
	{
		p0 = cmp.gtu(r2,r14)
		if (p0.new) jump:t .LBB26_90
	}
	.falign
.LBB26_92:                              // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB26_89 Depth=2
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	{
		jump .LBB26_79
	}
	.falign
.LBB26_93:                              //   in Loop: Header=BB26_4 Depth=1
	{
		r12 = lsr(r7,#2)
		r7 = lsr(r3,#5)
	}
	{
		loop1(.LBB26_94,r12)
	}
	.falign
.LBB26_94:                              // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_96 Depth 3
                                        //       Child Loop BB26_100 Depth 3
	{
		r12 = addasl(r6,r8,#5)
		p1 = cmp.gtu(r7,#2)
		r13 = add(r7,#-2)
		p2 = cmp.gtu(r7,#1)
	}
	{
		r12 = add(r12,#2048)
		if (!p2) jump:nt .LBB26_98
		v3 = vmemu(r12+#0)
	}
// %bb.95:                              // %for.body4.us.i
                                        //   in Loop: Header=BB26_94 Depth=2
	{
		loop0(.LBB26_96,r13)
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		if (!p1) jump:nt .LBB26_97
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.balign 32
.LBB26_96:                              // %for.body4.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_94 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r25.ub)
		v3 = v6
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		nop
	} :endloop0
	.falign
.LBB26_97:                              //   in Loop: Header=BB26_94 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r25.ub)
		jump .LBB26_99
		v3 = v6
	}
	.falign
.LBB26_98:                              //   in Loop: Header=BB26_94 Depth=2
	{
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB26_99:                              //   in Loop: Header=BB26_94 Depth=2
	{
		r12 = addasl(r4,r8,#2)
		v2.uw += vrmpy(v3.ub,r25.ub)
		r14 = #0
		r15 = add(r29,#512)
	}
	{
		r13 = addasl(r5,r8,#2)
	}
	{
		v14 = valign(v2,v2,#4)
	}
	{
		v15.w = vadd(v2.w,v14.w)
	}
	{
		v16 = vror(v15,r19)
	}
	{
		v17.w = vadd(v15.w,v16.w)
	}
	{
		v18 = vror(v17,r21)
	}
	{
		v19.w = vadd(v17.w,v18.w)
		vmem(r29+#4) = v19.new
	}
	.falign
.LBB26_100:                             // %for.body11.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_94 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r14,#2)
		r28 = memw(r12++#4)
		r0 = memw(r15+#0)
	}
	{
		r0 -= mpyi(r28,r3)
		if (p1) jump:nt .LBB26_102
		memw(r13++#4) = r0.new
	}
// %bb.101:                             // %for.body11.us.i
                                        //   in Loop: Header=BB26_100 Depth=3
	{
		r28 = add(r9,r14)
		r15 = add(r15,#32)
		r14 = add(r14,#1)
	}
	{
		p0 = cmp.gtu(r2,r28)
		if (p0.new) jump:t .LBB26_100
	}
	.falign
.LBB26_102:                             // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB26_94 Depth=2
	{
		r8 = add(r8,#4)
		r9 = add(r9,#4)
		nop
	} :endloop1
	{
		jump .LBB26_79
	}
	.falign
.LBB26_103:                             // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end26:
	.size	moe_m1_requant_worker, .Lfunc_end26-moe_m1_requant_worker
                                        // -- End function
	.falign
	.type	moe_m1_down_worker,@function    // -- Begin function moe_m1_down_worker
moe_m1_down_worker:                     // @moe_m1_down_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r21 = add(r2,#8196)
		r22 = r1
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r21+#60)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r25 = r2
		r18 = memw(r21+#20)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r30+#-8) = r17:16
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r25
		r19 = add(r25,#8260)
		r16 = add(r22,#1)
		memw(r29+#212) = r25
	}                                       // 4-byte Folded Spill
	{
		r2 += asl(r0,#9)
		r24 = add(r19,#-40)
		memw(r29+#208) = r24.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+#8)
	}
	{
		r2 = memw(r2+#44)
	}
	{
		if (!p0.new) r17 = add(r0,#0)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB27_161
		if (!p0.new) r2 = memw(r19+#0)
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r0 = sub(r2,r23)
	}
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.3:                               // %if.then
	{
		r1 = r20
		r2 = memw(r24+#0)
	}
	{
		r2 = add(r2,#127)
	}
	{
		r18 = lsr(r2,#7)
	}
	{
		r23 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r23,r22)
		call __hexagon_udivsi3
		r22 = memw(r21+#4)
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r23,r16)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r20
	}
	.falign
// %bb.5:                               // %if.then
	{
		r20 = r0
		r2 = add(r22,#23)
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB27_222
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r3 = ##-1431655765
		r22 = add(r25,#8200)
		r23 = add(r25,#8240)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r2 = lsr(r2,#4)
	}
	{
		r26 = +mpyi(r2,##640)
	}
	.falign
.LBB27_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r27 = r25
		r2 = add(r0,r17)
		r16 = r19
		r1 = memw(r22+#0)
	}
	{
		r27 += asl(r2,#9)
		r16 -= mpyi(r0,r18)
		r3 = add(r29,#256)
	}
	{
		r0 = memw(r27+#16)
		r2 = memw(r27+#384)
	}
	{
		r0 += mpyi(r26,r16)
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = memw(r23+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_60
	}
// %bb.10:                              // %land.lhs.true.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = #64
	}
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB27_60
	}
// %bb.11:                              // %land.lhs.true19.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = #1536
	}
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB27_60
	}
// %bb.12:                              // %land.lhs.true22.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:t .LBB27_60
	}
// %bb.13:                              // %land.lhs.true25.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = memw(r27+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_60
	}
// %bb.14:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = memw(r27+#4)
	}
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB27_17
	}
// %bb.15:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB27_17
	}
// %bb.16:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB27_60
	}
	.falign
.LBB27_17:                              // %for.inc.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_22
	}
// %bb.18:                              // %for.inc.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_20
	}
// %bb.19:                              // %for.inc.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB27_60
	}
	.falign
.LBB27_20:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p1) jump:nt .LBB27_23
	}
// %bb.21:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_23
	}
	.falign
.LBB27_22:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB27_23:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB27_28
	}
// %bb.24:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB27_26
	}
// %bb.25:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB27_60
	}
	.falign
.LBB27_26:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB27_29
	}
// %bb.27:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_29
	}
	.falign
.LBB27_28:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB27_29:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_34
	}
// %bb.30:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB27_32
	}
// %bb.31:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB27_60
	}
	.falign
.LBB27_32:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB27_35
	}
// %bb.33:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,r2); if (!p1.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_35
	}
	.falign
.LBB27_34:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = r3
	}
	.falign
.LBB27_35:                              // %htp_tl2_palette_magnitude.exit.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.gtu(r2,#1); if (p0.new) jump:t .LBB27_60
		if (!p0.new) r2 = memw(r27+#8)
	}
// %bb.36:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB27_39
	}
// %bb.37:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB27_39
	}
// %bb.38:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB27_60
	}
	.falign
.LBB27_39:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_44
	}
// %bb.40:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB27_42
	}
// %bb.41:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_60
	}
	.falign
.LBB27_42:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p0) jump:nt .LBB27_45
	}
// %bb.43:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_45
	}
	.falign
.LBB27_44:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB27_45:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB27_50
	}
// %bb.46:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB27_48
	}
// %bb.47:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB27_60
	}
	.falign
.LBB27_48:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB27_51
	}
// %bb.49:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,r3); if (!p1.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_51
	}
	.falign
.LBB27_50:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB27_51:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r2+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_56
	}
// %bb.52:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB27_54
	}
// %bb.53:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB27_60
	}
	.falign
.LBB27_54:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB27_57
	}
// %bb.55:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_57
	}
	.falign
.LBB27_56:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB27_57:                              // %htp_tl2_palette_magnitude.exit168.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r9 = asl(r16,#9)
		r0 = add(r29,#256)
		p1 = cmp.gtu(r4,#1); if (p1.new) jump:t .LBB27_60
	}
// %bb.58:                              // %if.then.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r8 = memw(r27+#44)
		r7:6 = memd(r27+#48)
	}
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r3 = add(r5,r9)
		r5 = add(r2,r9)
		r4 = add(r4,r9)
		r2 = memw(r6+#0)
	}
	{
		call hvx_dequant_acc_4tiles_m1_f32
		r6 = add(r7,r9)
		r1 = memw(r8+#0)
		memw(r29+#0) = r6.new
	}
	.falign
// %bb.59:                              // %if.then.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		jump .LBB27_160
	}
	.falign
.LBB27_60:                              // %if.end.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r25 = asl(r16,#7)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r25)) jump:t ##.LBB27_160
	}
// %bb.61:                              // %for.body53.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r6 = memw(r27+#8)
	}
	{
		r3 = memb(r6+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB27_64
	}
// %bb.62:                              // %for.body53.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB27_64
	}
// %bb.63:                              // %for.body53.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB27_84
	}
	.falign
.LBB27_64:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r6+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_69
	}
// %bb.65:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_67
	}
// %bb.66:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB27_84
	}
	.falign
.LBB27_67:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p1) jump:nt .LBB27_70
	}
// %bb.68:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB27_84
	}
	{
		jump .LBB27_70
	}
	.falign
.LBB27_69:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB27_70:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = memb(r6+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB27_75
	}
// %bb.71:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB27_73
	}
// %bb.72:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB27_84
	}
	.falign
.LBB27_73:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB27_76
	}
// %bb.74:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB27_84
	}
	{
		jump .LBB27_76
	}
	.falign
.LBB27_75:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB27_76:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r6+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_81
	}
// %bb.77:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_79
	}
// %bb.78:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_84
	}
	.falign
.LBB27_79:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB27_82
	}
// %bb.80:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB27_84
	}
	{
		jump .LBB27_82
	}
	.falign
.LBB27_81:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB27_82:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r3 = #3
		p0 = cmp.eq(r4,#7); if (!p0.new) jump:t .LBB27_84
	}
// %bb.83:                              // %if.end.i.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		v2.w = vasl(v1.w,r3)
		v1.cur = vmem(r29+#2)
	}
	{
		v3.w = vsub(v2.w,v1.w)
		vmem(r29+#2) = v3.new
	}
	.falign
.LBB27_84:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r0 = add(r29,#256)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r6+#8)
	}
	{
		r3 = memw(r27+#44)
		r6 = memw(r6+#16)
	}
	{
		r2 = addasl(r5,r25,#2)
		r5 = addasl(r9,r25,#2)
		memw(r29+#12) = r2
		memw(r29+#16) = #0
	}
	{
		r2 = addasl(r6,r25,#2)
		memw(r29+#8) = r2
	}
	{
		r2 = addasl(r8,r25,#2)
		memw(r29+#4) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
		r2 = #1
		memw(r29+#0) = r2
	}
	.falign
// %bb.85:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = setbit(r25,#5)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB27_160
	}
// %bb.86:                              // %for.body53.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB27_89
	}
// %bb.87:                              // %for.body53.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB27_89
	}
// %bb.88:                              // %for.body53.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_109
	}
	.falign
.LBB27_89:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_94
	}
// %bb.90:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB27_92
	}
// %bb.91:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB27_109
	}
	.falign
.LBB27_92:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p0) jump:nt .LBB27_95
	}
// %bb.93:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB27_109
	}
	{
		jump .LBB27_95
	}
	.falign
.LBB27_94:                              //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_95:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_100
	}
// %bb.96:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_98
	}
// %bb.97:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_109
	}
	.falign
.LBB27_98:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB27_101
	}
// %bb.99:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB27_109
	}
	{
		jump .LBB27_101
	}
	.falign
.LBB27_100:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB27_101:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_106
	}
// %bb.102:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB27_104
	}
// %bb.103:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB27_109
	}
	.falign
.LBB27_104:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB27_107
	}
// %bb.105:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB27_109
	}
	{
		jump .LBB27_107
	}
	.falign
.LBB27_106:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_107:                             // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB27_109
	}
// %bb.108:                             // %if.end.i.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		v5.w = vasl(v4.w,r4)
		v4.cur = vmem(r29+#3)
	}
	{
		v6.w = vsub(v5.w,v4.w)
		vmem(r29+#3) = v6.new
	}
	.falign
.LBB27_109:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r0 = add(r3,#128)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.110:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r2 = setbit(r25,#6)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB27_160
	}
// %bb.111:                             // %for.body53.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB27_114
	}
// %bb.112:                             // %for.body53.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_114
	}
// %bb.113:                             // %for.body53.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB27_134
	}
	.falign
.LBB27_114:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_119
	}
// %bb.115:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB27_117
	}
// %bb.116:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB27_134
	}
	.falign
.LBB27_117:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p1) jump:nt .LBB27_120
	}
// %bb.118:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB27_134
	}
	{
		jump .LBB27_120
	}
	.falign
.LBB27_119:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_120:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_125
	}
// %bb.121:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB27_123
	}
// %bb.122:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB27_134
	}
	.falign
.LBB27_123:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB27_126
	}
// %bb.124:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,r4); if (!p0.new) jump:t .LBB27_134
	}
	{
		jump .LBB27_126
	}
	.falign
.LBB27_125:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB27_126:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_131
	}
// %bb.127:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB27_129
	}
// %bb.128:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB27_134
	}
	.falign
.LBB27_129:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB27_132
	}
// %bb.130:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB27_134
	}
	{
		jump .LBB27_132
	}
	.falign
.LBB27_131:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_132:                             // %for.inc.3.i.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = #3
		p0 = cmp.eq(r5,#7); if (!p0.new) jump:t .LBB27_134
	}
// %bb.133:                             // %if.end.i.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		v8.w = vasl(v7.w,r4)
		v7.cur = vmem(r29+#4)
	}
	{
		v9.w = vsub(v8.w,v7.w)
		vmem(r29+#4) = v9.new
	}
	.falign
.LBB27_134:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r0 = add(r3,#256)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.135:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r6 = or(r25,#96)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r6)) jump:t .LBB27_160
	}
// %bb.136:                             // %for.body53.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB27_139
	}
// %bb.137:                             // %for.body53.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB27_139
	}
// %bb.138:                             // %for.body53.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_159
	}
	.falign
.LBB27_139:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_144
	}
// %bb.140:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB27_142
	}
// %bb.141:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB27_159
	}
	.falign
.LBB27_142:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		if (p0) jump:nt .LBB27_145
	}
// %bb.143:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB27_159
	}
	{
		jump .LBB27_145
	}
	.falign
.LBB27_144:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_145:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB27_150
	}
// %bb.146:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB27_148
	}
// %bb.147:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB27_159
	}
	.falign
.LBB27_148:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB27_151
	}
// %bb.149:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB27_159
	}
	{
		jump .LBB27_151
	}
	.falign
.LBB27_150:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB27_151:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_156
	}
// %bb.152:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB27_154
	}
// %bb.153:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB27_159
	}
	.falign
.LBB27_154:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB27_157
	}
// %bb.155:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB27_159
	}
	{
		jump .LBB27_157
	}
	.falign
.LBB27_156:                             //   in Loop: Header=BB27_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB27_157:                             // %for.inc.3.i.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB27_159
	}
// %bb.158:                             // %if.end.i.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		v11.w = vasl(v10.w,r4)
		v10.cur = vmem(r29+#5)
	}
	{
		v12.w = vsub(v11.w,v10.w)
		vmem(r29+#5) = v12.new
	}
	.falign
.LBB27_159:                             // %moe_tl2_restore_magnitude.exit.3.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r0 = add(r3,#384)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r6,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#8) = r5
	}
	{
		r7 = addasl(r7,r6,#2)
		r6 = addasl(r8,r6,#2)
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
.LBB27_160:                             // %cleanup.i
                                        //   in Loop: Header=BB27_7 Depth=1
	{
		r19 = add(r19,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r20,r19.new)) jump:t ##.LBB27_7
	}                                       // 4-byte Folded Reload
	{
		jump .LBB27_222
	}
	.falign
.LBB27_161:                             // %if.end
	{
		r24 = add(r25,#8232)
		r2 = memw(r21+#28)
	}
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r3 = p1
		if (p1) jump:nt .LBB27_163
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.162:
	{
		p0 = or(p0,!p0)
		r26 = add(r25,#8204)
	}
	{
		r3 = p0
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB27_164
	}
	{
		jump .LBB27_165
	}
	.falign
.LBB27_163:                             // %lor.rhs
	{
		r26 = add(r25,#8204)
		r3 = memw(r24+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB27_165
	}
	.falign
.LBB27_164:                             // %land.lhs.true
	{
		r0 = #2
		r4 = memw(r24+#0)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r4,#0); if (!p1.new) jump:t .LBB27_167
	}
	.falign
.LBB27_165:                             // %cond.false
	{
		r4 = #512
		r1:0 = combine(#0,r2)
		r5 = memw(r26+#0)
	}
	{
		r2 = lsr(r4,r3)
		r1:0 = asl(r1:0,#10)
		r3 = #0
	}
	{
		r2 = mpyi(r5,r2)
		call __hexagon_udivdi3
	}
	.falign
// %bb.166:                             // %cond.false
	{
		r2 = #1
		r3 = #127
	}
	{
		r2 = maxu(r0,r2)
	}
	{
		r2 = minu(r2,r3)
		memw(r29+#240) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_167:                             // %cond.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r21 = #0
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_170
	}
// %bb.168:                             // %if.then12
	{
		r17 = add(r25,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.169:                             // %if.then12
	{
		jump .LBB27_171
		r23 = memw(r17+#0)
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB27_170:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB27_171:                             // %do.end
	{
		r2 = memw(r19+#0)
	}
	{
		r18 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r18,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.172:                             // %do.end
	{
		r1:0 = mpyu(r18,r16)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.173:                             // %do.end
	{
		r2 = add(r23,r0)
		r27 = add(r25,#8236)
		r18 = add(r25,#8216)
		memw(r29+#232) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB27_218
		if (p1.new) r20 = memw(r18+#0)
	}
// %bb.174:                             // %cond.end22
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.175:                             // %cond.end22
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r19 = minu(r2,r3)
		r3 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) r3 = sub(r19,r17)
		if (p1.new) jump:nt .LBB27_181
	}
// %bb.176:                             // %cond.end22
	{
		if (p0.new) r4 = add(r25,#0)
		if (p0.new) r2 = add(r17,#0)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB27_181
	}
// %bb.177:                             // %if.then28
	{
		r4 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		r1 = r20
	}
	{
		r6 = memw(r4+#8)
		r4 = memw(r26+#0)
	}
	{
		r0 = memw(r6+#4)
	}
	{
		r5 = memw(r27+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB27_180
	}
// %bb.178:                             // %if.then.i270
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.179:                             // %if.then.i270
	{
		jump .LBB27_181
	}
	.falign
.LBB27_180:                             // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB27_181:                             // %for.body.lr.ph
	{
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
	}
	{
		memw(r29+#220) = r4
	}                                       // 4-byte Folded Spill
	{
		r16 = add(r25,#8228)
		if (!p1) r2 = add(r3,#0)
		if (p1) r2 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		memw(r29+#216) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_182:                             // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB27_191 Depth 2
                                        //       Child Loop BB27_205 Depth 3
	{
		r20 = r17
		r17 = r19
		r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r19)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB27_185
		memw(r29+#228) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.183:                             // %cond.true34
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		r21 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r19)
	}
	.falign
// %bb.184:                             // %cond.true34
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r21)
		r3 = add(r19,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r19 = minu(r2,r0)
	}
	.falign
.LBB27_185:                             // %cond.end38
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB27_190
	}
// %bb.186:                             // %cond.end38
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		p0 = cmp.gtu(r19,r17); if (!p0.new) jump:nt .LBB27_190
		if (p0.new) r21 = memw(r18+#0)
	}
// %bb.187:                             // %if.then44
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.188:                             // %if.then44
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		r2 = r25
		r1 = r21
		r3 = memw(r27+#0)
		r4 = memw(r26+#0)
	}
	{
		r2 += asl(r0,#9)
		p1 = cmp.eq(r3,#0)
		r3 = sub(r19,r17)
	}
	{
		r2 = r17
		r5 = memw(r2+#8)
	}
	{
		r2 -= mpyi(r0,r21)
	}
	{
		if (p1) jump:nt .LBB27_216
		r0 = memw(r5+#4)
	}
// %bb.189:                             // %if.then.i291
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB27_190:                             // %if.end45
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB27_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_191:                             // %for.body50
                                        //   Parent Loop BB27_182 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_205 Depth 3
	{
		r23 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r20)
	}
	.falign
// %bb.192:                             // %for.body50
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r25 += asl(r0,#9)
		r22 = r20
		r19 = add(r20,#1)
	}
	{
		r22 -= mpyi(r0,r23)
	}
	{
		r21 = memw(r25+#32)
	}
	{
		r21 += asl(r22,#9)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_197
	}
// %bb.193:                             // %land.lhs.true61
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r4 = add(r25,#256)
		r2 = memw(r24+#0)
		r0 = memw(r25+#40)
	}
	{
		p0 = cmp.eq(r2,#0)
		if (!p0.new) r6 = add(r22,#1)
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		if (!p0) r7 = add(r21,##512)
		if (p0) jump:nt .LBB27_199
		r3 = memw(r25+#16)
	}
// %bb.194:                             // %land.lhs.true61
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		p1 = cmp.gtu(r17,r19); if (!p1.new) jump:nt .LBB27_199
	}
// %bb.195:                             // %if.then68
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#8) = r4

	} :mem_noshuf
	{
		r5:4 = combine(r22,r23)
		memw(r29+#4) = r5
		memw(r29+#12) = r21
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#16) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.196:                             // %if.then68
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB27_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_197:                             // %if.else87
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r4 = memw(r16+#0)
		r0 = memw(r25+#40)
	}
	{
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		r5:4 = combine(r22,r23)
		r3 = memw(r25+#16)
		memw(r29+#0) = r4

	} :mem_noshuf
	{
		r6 = memw(r29+#216)
		memw(r29+#4) = r21
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.198:                             // %if.else87
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		p0 = or(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB27_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_199:                             // %if.then76
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#0) = r5.new
	}
	{
		r5:4 = combine(r22,r23)
		r6 = memw(r29+#220)
		memw(r29+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r21
	}
	{
		callr r6
	}
	.falign
// %bb.200:                             // %if.then76
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB27_201:                             // %if.end97
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r22 = asl(r22,#5)
		r6 = memw(r25+#8)
		r23 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r6+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB27_210
	}
// %bb.202:                             // %if.then100
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r5 = add(r25,#72)
		r2 = memw(r25+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_210
	}
// %bb.203:                             // %for.body.us.i
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r6 = addasl(r3,r22,#2)
		r3 = lsr(r2,#1)
		r4 = and(r2,#1)
	}
	{
		p0 = cmp.gtu(r3,#0)
		if (!p0.new) r3 = add(r21,#0)
		r2 = r5
	}
	{
		if (!p0) jump:nt .LBB27_208
		v0 = vmemu(r6+#0)
	}
// %bb.204:                             //   in Loop: Header=BB27_191 Depth=2
	{
		loop0(.LBB27_205,r3)
		r6 = r21
		r3 = r21
	}
	.balign 32
.LBB27_205:                             //   Parent Loop BB27_182 Depth=1
                                        //     Parent Loop BB27_191 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r2++#8)
	}
	{
		v13 = vsplat(r7)
		v14 = vmemu(r6+#0)
	}
	{
		v16 = vmemu(r6+#1)
	}
	{
		v14.w += vmpyie(v13.w,v0.h)
	}
	{
		vmemu(r3++#2) = v14
	}
	{
		r5 = memw(r5+#4)
	}
	{
		v15 = vsplat(r5)
		r5 = r2
	}
	{
		v16.w += vmpyie(v15.w,v0.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v16
	} :endloop0
// %bb.206:                             //   in Loop: Header=BB27_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (!p1.new) jump:t .LBB27_209
	}
	.falign
.LBB27_207:                             // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r4 = memw(r2+#0)
	}
	{
		v17 = vsplat(r4)
		v18 = vmemu(r3+#0)
	}
	{
		v18.w += vmpyie(v17.w,v0.h)
	}
	{
		jump .LBB27_209
		vmemu(r3++#1) = v18
	}
	.falign
.LBB27_208:                             //   in Loop: Header=BB27_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (p1.new) jump:t .LBB27_207
	}
	.falign
.LBB27_209:                             // %if.end106.loopexit
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r6 = memw(r25+#8)
	}
	.falign
.LBB27_210:                             // %if.end106
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r5:4 = memd(r25+#48)
		r7 = memw(r6+#16)
	}
	{
		r0 = addasl(r7,r22,#2)
		r5 = addasl(r5,r22,#2)
		r9:8 = memd(r6+#8)
		r1 = memw(r23+#0)
	}
	{
		r6 = addasl(r9,r22,#2)
		r7 = addasl(r8,r22,#2)
		r2 = memw(r25+#388)
		r3 = memw(r25+#44)
	}
	{
		r5 = r6
		memw(r29+#8) = r5
		memw(r29+#12) = r1
	}
	{
		r1:0 = combine(#32,r21)
		memw(r29+#4) = r0
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r7
	}
	.falign
// %bb.211:                             // %if.end106
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r2 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB27_214
		if (!p0.new) r5:4 = memd(r25+#48)
		if (!p0.new) r6 = memw(r25+#8)
	}
// %bb.212:                             // %if.then116
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r22 = add(#128,asl(r22,#2))
		r1 = #32
		r0 = add(r21,#512)
		r2 = memw(r25+#388)
	}
	{
		r5 = add(r5,r22)
		r3 = memw(r25+#44)
		r9:8 = memd(r6+#8)
	}
	{
		r12 = memw(r6+#16)
	}
	{
		r6 = add(r9,r22)
		r7 = memw(r23+#0)
		memw(r29+#8) = r5

	} :mem_noshuf
	{
		r7 = add(r12,r22)
		r6 = add(r8,r22)
		r5 = r6
		memw(r29+#12) = r7
	}
	{
		memw(r29+#16) = #0
		memw(r29+#4) = r7
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.213:                             // %if.then116
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r20 = r19
	}
	.falign
.LBB27_214:                             // %if.end134
                                        //   in Loop: Header=BB27_191 Depth=2
	{
		r20 = add(r20,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r17,r20.new)) jump:t .LBB27_191
	}                                       // 4-byte Folded Reload
	.falign
.LBB27_215:                             // %for.cond.loopexit
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		r19 = memw(r29+#224)
		r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB27_182
	}
	{
		jump .LBB27_218
	}
	.falign
.LBB27_216:                             // %if.else.i293
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.217:                             // %if.else.i293
                                        //   in Loop: Header=BB27_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB27_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	{
		jump .LBB27_191
	}
	.falign
.LBB27_218:                             // %for.cond.cleanup
	{
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_222
	}
// %bb.219:                             // %if.then.i273
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.220:                             // %if.then.i273
	{
		r3:2 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB27_221:                             // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB27_221
	}
	.falign
.LBB27_222:                             // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end27:
	.size	moe_m1_down_worker, .Lfunc_end27-moe_m1_down_worker
                                        // -- End function
	.falign
	.type	moe_push_act_block,@function    // -- Begin function moe_push_act_block
moe_push_act_block:                     // @moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17 = asl(r5,#11)
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(r3,r4)
		r19 = r2
		memd(r29+#32) = r19:18
		memd(r29+#24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r23:22 = combine(r0,r1)
		if (p0) jump:nt .LBB28_2
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = tstbit(r5,#0)
		p0 = bitsclr(r5,#3)
		if (p1.new) r16 = ##2048
	}
	{
		if (!p1) r16 = ##4096
	}
	{
		if (p0) r16 = ##8192
		jump .LBB28_3
	}
	.falign
.LBB28_2:
	{
		r16 = #16384
	}
	.falign
.LBB28_3:                               // %hexkl_moe_push_act_block.exit
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.4:                               // %hexkl_moe_push_act_block.exit
	{
		call __hexagon_udivsi3
		r18 = r0
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.5:                               // %hexkl_moe_push_act_block.exit
	{
		r19 += mpyi(r20,r21)
		r5:4 = combine(r0,r16)
		r0 = add(r23,r22)
		r3:2 = combine(r16,r16)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r19
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.6:                               // %hexkl_moe_push_act_block.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_9
	}
// %bb.7:                               // %if.then
	{
		r19 = memw(r29+#60)
		r20 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r23:22 = c31:30
	}
	//# InlineAsm End
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.8:                               // %if.then
	{
		r5:4 = combine(r19,r20)
		r1:0 = combine(r23,r22)
		r3:2 = combine(#0,r18)
		memw(r29+#4) = r0
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#0) = r16
		memw(r29+#8) = r16
	}
	.falign
.LBB28_9:                               // %if.end
	{
		r0 = r18
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end28:
	.size	moe_push_act_block, .Lfunc_end28-moe_push_act_block
                                        // -- End function
	.falign
	.type	moe_expand_submit,@function     // -- Begin function moe_expand_submit
moe_expand_submit:                      // @moe_expand_submit
// %bb.0:                               // %entry
	{
		r17:16 = combine(r2,r3)
		r8 = add(r4,r5)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r18 = r1
		r3 = memw(r29+#48)
		memd(r29+#16) = r19:18
	}
	{
		r9 = memw(r29+#60)
		memd(r29+#8) = r21:20
	}
	{
		p1 = cmp.eq(r9,#-1)
		r6 = memw(r29+#44)
		r14 = memw(r29+#52)
	}
	{
		r12 = memw(r29+#64)
		memd(r29+#0) = r23:22
	}
	{
		r4 = r12
		r13 = memw(r29+#56)
		r7 = memw(r29+#40)
	}
	{
		r2 = asl(r14,#9)
		memw(r2+#152) = #0
		memw(r17+#8) = #1
	}
	{
		r4 = and(##2147483392,asl(r4,#8))
		r2 = r8
		memw(r17+#12) = r2
	}
	{
		r2 += asl(r13,#9)
		r5:4 = combine(r3,r4)
		if (!p1) r3 = add(r8,#0)
		if (!p1) memw(r17+#8) = #2
	}
	{
		r2 = add(r6,#88)
		if (p1) jump:nt .LBB29_8
		memw(r17+#0) = r2
		memd(r17+#16) = r5:4
	}
// %bb.1:                               // %if.end.thread
	{
		r3 += asl(r9,#9)
		memw(r17+#4) = r3.new
	}
	{
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB29_18
	}
// %bb.2:                               // %for.body.i
	{
		r12 = lsr(r13,#2)
		r15:14 = combine(#0,#1)
		r3 = add(r12,#3)
	}
	{
		r4 = add(r3,r13)
	}
	{
		r13 = lsr(r4,#2)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r13,r12)
		if (p0.new) r13 = sub(r13,r12)
		if (!p0.new) jump:t .LBB29_5
	}
// %bb.3:
	{
		loop0(.LBB29_4,r13)
	}
	.falign
.LBB29_4:                               // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r15:14,r12)
		r12 = add(r12,#1)
	} :endloop0
	.falign
.LBB29_5:                               // %for.cond.cleanup7.i
	{
		r3 = lsr(r9,#2)
		r12 = add(r3,r9)
	}
	{
		r9 = lsr(r12,#2)
	}
	{
		r13:12 = combine(#0,#1)
		p1 = cmp.gtu(r9,r3)
		if (p1.new) r9 = sub(r9,r3)
		if (!p1.new) jump:t .LBB29_12
	}
// %bb.6:
	{
		loop0(.LBB29_7,r9)
	}
	.falign
.LBB29_7:                               // Block address taken
                                        // %for.body8.i.1
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	{
		jump .LBB29_12
	}
	.falign
.LBB29_8:                               // %if.end
	{
		r4 = add(r12,add(r13,#3))
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB29_18
	}
// %bb.9:                               // %for.body.i.us
	{
		r3 = lsr(r13,#2)
	}
	{
		r9 = lsr(r4,#2)
		r13:12 = combine(#0,#1)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r9,r3)
		if (p0.new) r9 = sub(r9,r3)
		if (!p0.new) jump:t .LBB29_12
	}
// %bb.10:
	{
		loop0(.LBB29_11,r9)
	}
	.falign
.LBB29_11:                              // Block address taken
                                        // %for.body8.i.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB29_12:                              // %for.cond.cleanup.i
	{
		r11:10 = combine(r7,r8)
		r14 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r12 = ##-1431655765
		r7 = add(r14,#23)
		r13 = add(r3,#127)
	}
	{
		r7 = mpyu(r7,r12)
		p0 = cmp.gtu(r13,#127)
		r15 = add(r14,#95)
		r9:8 = memd(r6+#56)
	}
	{
		r28 = mpyu(r15,r12)
		r15 = lsr(r13,#7)
		memd(r17+#152) = r11:10
		memw(r17+#184) = #0
	}
	{
		r1 = lsr(r7,#4)
		r7 = lsr(r28,#6)
		r11:10 = combine(r15,r14)
	}
	{
		r14 = +mpyi(r1,##640)
		r13:12 = and(r5:4,~r9:8)
		memd(r17+#168) = r11:10
	}
	{
		r11:10 = combine(r14,r7)
		if (p0) r14 = #0
		memd(r17+#160) = r13:12
	}
	{
		if (!p0) jump:nt .LBB29_21
		memd(r17+#176) = r11:10
	}
// %bb.13:
	{
		r1 = lsr(r15,#1)
		r21:20 = combine(#0,#1)
		r11:10 = combine(#0,#0)
	}
	{
		r28 = and(r15,#1)
		if (!p1.new) r15 = #0
		p1 = cmp.gtu(r1,#0); if (!p1.new) jump:t .LBB29_20
	}
// %bb.14:
	{
		loop0(.LBB29_15,r1)
		r15 = #0
	}
	.falign
.LBB29_15:                              // =>This Inner Loop Header: Depth=1
	{
		r23:22 = combine(r13,r12)
		r1 = add(r14,r7)
		r19 = add(r15,#1)
	}
	{
		r23:22 &= asl(r21:20,r15)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r23:22 = combine(r13,r12)
	}
	{
		r23:22 &= asl(r21:20,r19)
		if (!p0) r14 = add(r1,#0)
		if (!p0) memw(r17+#184) = r1
	}
	{
		p1 = cmp.eq(r23:22,r11:10)
		r19 = add(r14,r7)
	}
	{
		if (!p1) r14 = add(r19,#0)
		if (!p1) memw(r17+#184) = r19
	} :endloop0
// %bb.16:
	{
		p0 = cmp.gtu(r28,#0)
		if (!p0.new) jump:t .LBB29_21
	}
	.falign
.LBB29_17:                              // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r21:20,r15)
		r7 = add(r14,r7)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		jump .LBB29_21
		if (!p1.new) memw(r17+#184) = r7
	}
	.falign
.LBB29_18:                              // %if.else
	{
		call hvx_expand_i2i4_table
		r1 = add(r17,#24)
		r19 = r0
		r0 = r2
	}
	.falign
// %bb.19:                              // %if.else
	{
		r0 = r19 ; jump .LBB29_44
	}
	.falign
.LBB29_20:
	{
		p0 = cmp.gtu(r28,#0)
		if (p0.new) jump:t .LBB29_17
	}
	.falign
.LBB29_21:                              // %for.cond.cleanup24.i
	{
		r2 = memb(r2+#0)
	}
	{
		r7 = abs(r2)
		r2 = #0
	}
	{
		p1 = cmp.eq(r7,#0); if (p1.new) jump:nt .LBB29_24
	}
// %bb.22:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#7); if (p0.new) jump:nt .LBB29_24
	}
// %bb.23:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB29_43
	}
	.falign
.LBB29_24:                              // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB29_29
	}
// %bb.25:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB29_27
	}
// %bb.26:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB29_43
	}
	.falign
.LBB29_27:                              // %lor.lhs.false.1.i.i
	{
		if (p1) jump:nt .LBB29_30
	}
// %bb.28:                              // %lor.lhs.false.1.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB29_43
	}
	{
		jump .LBB29_30
	}
	.falign
.LBB29_29:
	{
		r12 = r7
	}
	.falign
.LBB29_30:                              // %for.inc.1.i.i
	{
		r7 = memb(r6+#90)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB29_35
	}
// %bb.31:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r7,#7); if (p1.new) jump:nt .LBB29_33
	}
// %bb.32:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB29_43
	}
	.falign
.LBB29_33:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,#0)
		if (p1.new) jump:nt .LBB29_36
	}
// %bb.34:                              // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,r7)
		if (!p0.new) jump:t .LBB29_43
	}
	{
		jump .LBB29_36
	}
	.falign
.LBB29_35:
	{
		r7 = r12
	}
	.falign
.LBB29_36:                              // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB29_41
	}
// %bb.37:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB29_39
	}
// %bb.38:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB29_43
	}
	.falign
.LBB29_39:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r7,#0); if (p0.new) jump:nt .LBB29_42
	}
// %bb.40:                              // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB29_43
	}
	{
		jump .LBB29_42
	}
	.falign
.LBB29_41:
	{
		r12 = r7
	}
	.falign
.LBB29_42:                              // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r2 = maxu(r12,r2)
	}
	.falign
.LBB29_43:                              // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r17+#188) = r2
	}
	{
		memw(r17+#12) = r3
		memd(r6+#56) = r5:4
	}
	.falign
.LBB29_44:                              // %if.end13
	{
		r2 = add(pc,##moe_expand_unit@PCREL)
		r1 = r18
		memw(r18+#4) = r17
	}
	{
		memw(r18+#12) = r16
		memw(r18+#0) = r2
	}
	{
		r17:16 = memd(r29+#24)
		memw(r18+#8) = #8
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#16)
		r21:20 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hvx_worker_pool_submit_bg
		r23:22 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
.Lfunc_end29:
	.size	moe_expand_submit, .Lfunc_end29-moe_expand_submit
                                        // -- End function
	.falign
	.type	moe_gu_worker,@function         // -- Begin function moe_gu_worker
moe_gu_worker:                          // @moe_gu_worker
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB30_5
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r5:4 = c31:30
	}
	//# InlineAsm End
	{
		r20 = r0
		r1:0 = combine(r5,r4)
		r19 = r1
		r16 = r2
	}
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = r16
		r17:16 = combine(r1,r0)
		r1:0 = combine(r19,r20)
	}
	{
		r3 = memw(r2+#60)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB30_6
	}
	.falign
.LBB30_3:                               // %if.then2
	{
		call hvx_dq_swiglu_i24
	}
	.falign
// %bb.4:                               // %if.then2
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB30_11
	}
	{
		jump .LBB30_14
	}
	.falign
.LBB30_5:
	{
		r17:16 = combine(#0,#0)
		r3 = memw(r2+#60)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB30_3
	}
	.falign
.LBB30_6:                               // %if.else
	{
		r3 = memw(r2+#64)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB30_9
	}
// %bb.7:                               // %if.then4
	{
		call hvx_dq_swiglu_affine
		r4 = add(r2,#68)
	}
	.falign
// %bb.8:                               // %if.then4
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB30_11
	}
	{
		jump .LBB30_14
	}
	.falign
.LBB30_9:                               // %if.else7
	{
		call hvx_dq_swiglu_worker
	}
	.falign
// %bb.10:                              // %if.else7
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB30_14
	}
	.falign
.LBB30_11:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB30_13:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB30_13
	}
	.falign
.LBB30_14:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end30:
	.size	moe_gu_worker, .Lfunc_end30-moe_gu_worker
                                        // -- End function
	.falign
	.type	moe_dn_worker,@function         // -- Begin function moe_dn_worker
moe_dn_worker:                          // @moe_dn_worker
// %bb.0:                               // %entry
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r0)
		r20 = r2
		memd(r29+#56) = r21:20
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#48) = r23:22
		memd(r29+#40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#32) = r27:26
		memw(r29+#20) = r3
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB31_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB31_4
	}
	{
		jump .LBB31_13
	}
	.falign
.LBB31_3:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB31_13
	}
	.falign
.LBB31_4:                               // %if.then2
	{
		r19:18 = vaslw(r17:16,#6)
		r27:26 = vaslw(r17:16,#4)
		p0 = cmp.gtu(r17,#3); if (p0.new) jump:t .LBB31_13
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r25 = sub(#0,r27)
		r2 = memw(r20+#860)
	}
	{
		r2 = add(r2,#3)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r5 = and(r2,#-4)
		memw(r29+#16) = r5.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB31_6:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r5,r27)
		if (!p1.new) jump:nt .LBB31_13
		if (p1.new) r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
// %bb.7:                               // %if.end6
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r2 = add(r2,r25)
		r3 = memw(r20+#864)
		r4 = memw(r20+#860)
	}
	{
		r0 = mpyi(r3,r27)
		p0 = cmp.gtu(r2,#15)
		r2 = add(r25,r4)
		r1 = memw(r20+#856)
	}
	{
		r24 = addasl(r1,r0,#2)
		if (p0) r21 = add(r27,#16)
		if (!p0) r21 = add(r5,#0)
	}
	{
		r22 = add(r21,r25)
	}
	{
		r4 = maxu(r22,r2)
		r23 = minu(r2,r22)
		p1 = cmp.gtu(r22,r2); if (!p1.new) jump:t .LBB31_10
	}
// %bb.8:                               // %if.then24
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r5 = mpyi(r23,r3)
		r1 = #0
	}
	{
		r0 = addasl(r24,r5,#2)
		r2 = sub(r4,r2)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.9:                               // %if.then24
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r3 = memw(r20+#864)
	}
	.falign
.LBB31_10:                              // %for.inc
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r1:0 = combine(r23,r24)
		r5 = memw(r20+#872)
		r2 = memw(r20+#868)
	}
	{
		r4 = add(r2,r19)
		r5 = add(r5,r19)
		r2 = r22
		memw(r29+#0) = #0
	}
	{
		call hvx_quant_rows_u8_params
	}
	.falign
// %bb.11:                              // %for.inc
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r1 = #0
		r2 = memw(r20+#872)
		r4 = memw(r20+#864)
	}
	{
		r3 = memw(r20+#876)
		r0 = memw(r20+#856)
	}
	{
		r5 = memw(r20+#868)
		memw(r29+#4) = r3

	} :mem_noshuf
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r21,r27)
		memw(r29+#0) = r2
	}
	.falign
// %bb.12:                              // %for.inc
                                        //   in Loop: Header=BB31_6 Depth=1
	{
		r27 = add(r27,r26)
		r25 = sub(r25,r26)
		r19 = add(r19,r18)
		r5 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r17,r16)
		if (!cmp.gtu(r17.new,#3)) jump:t .LBB31_6
	}
	.falign
.LBB31_13:                              // %if.end44
	{
		r16 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB31_17
	}
// %bb.14:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.15:                              // %if.then.i
	{
		r3:2 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB31_16:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB31_16
	}
	.falign
.LBB31_17:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end31:
	.size	moe_dn_worker, .Lfunc_end31-moe_dn_worker
                                        // -- End function
	.falign
	.type	moe_dn_unit,@function           // -- Begin function moe_dn_unit
moe_dn_unit:                            // @moe_dn_unit
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#0) = r21:20
		memd(r29+#8) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r1,r2)
	}
	{
		r3 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB32_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = combine(r1,r0)
		jump .LBB32_4
	}
	.falign
.LBB32_3:
	{
		r17:16 = combine(#0,#0)
	}
	.falign
.LBB32_4:                               // %do.end
	{
		r1 = asl(r19,#2)
		r0 = r18
		r2 = #4
		r3 = memw(r18+#20)
	}
	{
		r2 = addasl(r2,r19,#2)
		r4 = sub(r3,r1)
	}
	{
		call moe_dn_rows
		p1 = cmp.gtu(r4,#3)
		if (!p1.new) r2 = add(r3,#0)
	}
	.falign
// %bb.5:                               // %do.end
	{
		r2 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB32_9
	}
// %bb.6:                               // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB32_8:                               // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r20+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB32_8
	}
	.falign
.LBB32_9:                               // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end32:
	.size	moe_dn_unit, .Lfunc_end32-moe_dn_unit
                                        // -- End function
	.falign
	.type	moe_dn_fg_worker,@function      // -- Begin function moe_dn_fg_worker
moe_dn_fg_worker:                       // @moe_dn_fg_worker
// %bb.0:                               // %entry
	{
		r17 = r0
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r20 = r1
		r16 = memw(r2+#4)
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#16) = r19:18
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r16+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB33_2
	}
// %bb.1:                               // %if.then
	{
		call moe_dn_worker
		r1:0 = combine(r20,r17)
		r2 = r16
	}
	.falign
.LBB33_2:                               // %if.end
	{
		r21 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB33_5
	}
// %bb.3:                               // %if.then3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.4:                               // %if.then3
	{
		r19:18 = combine(r1,r0)
		jump .LBB33_6
	}
	.falign
.LBB33_5:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB33_6:                               // %do.end
	{
		r1 = r17
		r22 = memw(r16+#20)
	}
	{
		r0 = mpyi(r22,r20)
		call __hexagon_udivsi3
	}
	.falign
// %bb.7:                               // %do.end
	{
		r20 = r0
		r1 = r17
		r2 = add(r20,#1)
	}
	{
		r0 = mpyi(r22,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %do.end
	{
		call moe_dn_rows
		r2 = r0
		r1:0 = combine(r20,r16)
	}
	.falign
// %bb.9:                               // %do.end
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB33_13
	}
// %bb.10:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r19:18)
	}
	.balign 32
.LBB33_12:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB33_12
	}
	.falign
.LBB33_13:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end33:
	.size	moe_dn_fg_worker, .Lfunc_end33-moe_dn_fg_worker
                                        // -- End function
	.falign
	.type	moe_push_weight_chunk,@function // -- Begin function moe_push_weight_chunk
moe_push_weight_chunk:                  // @moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r18 = r5
		r6 = memw(r3+#44)
		memd(r29+#40) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r6,#0)
		r5 = memw(r29+#64)
		memd(r29+#32) = r21:20
	}
	{
		if (p0) r2 = add(r3,#0)
		r21 = r4
		r17 = memw(r29+#76)
		r16 = memw(r29+#80)
	}
	{
		if (p0) jump:nt .LBB34_3
		r20 = memw(r29+#72)
		r19 = memw(r29+#68)
	}
// %bb.1:                               // %if.then
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
		r4 = add(r29,#20)
		memw(r29+#4) = r4.new
	}
	{
		r4 = r5
		r5 = r19
		memw(r29+#20) = r20
		memw(r29+#24) = r17
	}
	{
		r6 = memw(r6+#0)
		memw(r29+#28) = r16
	}
	{
		call moe_push_native_chunk
		memw(r29+#0) = r6
	}
	.falign
.LBB34_2:                               // %return
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB34_3:                               // %if.end
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r4 = r18
		r3 = r4
		memw(r29+#0) = r19
	}
	{
		call hexkl_moe_push_weight_chunk
		r6 = memw(r6+#0)
		memw(r29+#4) = r6.new
	}
	.falign
// %bb.4:                               // %if.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_2
	}
// %bb.5:                               // %if.then6
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r7:6 = vaslw(r19:18,#9)
		r18 = r0
		r1:0 = combine(r3,r2)
		r5:4 = combine(r16,r17)
	}
	{
		r3:2 = combine(r20,r18)
		memw(r29+#0) = r7
		memw(r29+#4) = r21
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
// %bb.6:                               // %if.then6
	{
		r0 = r18
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end34:
	.size	moe_push_weight_chunk, .Lfunc_end34-moe_push_weight_chunk
                                        // -- End function
	.globl	hexkl_mm_u8i4_fc_m1_run         // -- Begin function hexkl_mm_u8i4_fc_m1_run
	.falign
	.type	hexkl_mm_u8i4_fc_m1_run,@function
hexkl_mm_u8i4_fc_m1_run:                // @hexkl_mm_u8i4_fc_m1_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#656):raw
	}                                       // 8-byte Folded Spill
	{
		r23 = ##-2147449856
		memd(r29+#624) = r23:22
		memd(r29+#640) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19 = r0
		r0 = add(r23,#-32754)
		memd(r29+#632) = r21:20
		memd(r29+#616) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB35_34
		memd(r29+#608) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r26 = memw(r29+#664)
		if (cmp.eq(r26.new,#0)) jump:nt ##.LBB35_34
	}
// %bb.2:                               // %entry
	{
		r18 = memw(r29+#668)
		if (cmp.eq(r18.new,#0)) jump:nt ##.LBB35_34
	}
// %bb.3:                               // %entry
	{
		r24 = memw(r29+#672)
		if (cmp.eq(r24.new,#0)) jump:nt ##.LBB35_34
	}
// %bb.4:                               // %entry
	{
		r22 = memw(r29+#680)
		if (cmp.eq(r22.new,#0)) jump:nt .LBB35_34
	}
// %bb.5:                               // %if.end
	{
		r6 = add(r5,#-65)
		r0 = add(r23,#-32751)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB35_34
	}
// %bb.6:                               // %lor.lhs.false8
	{
		p1 = !bitsclr(r4,#31)
		if (p1.new) jump:nt .LBB35_34
	}
// %bb.7:                               // %lor.lhs.false8
	{
		r20 = add(r29,#32)
		r7 = #-64
		if (cmp.gtu(r7.new,r6)) jump:nt .LBB35_34
	}
// %bb.8:                               // %for.body.lr.ph
	{
		r2 = #568
		memw(r29+#12) = r1
		memw(r29+#20) = r2
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(#0,r20)
		r17:16 = combine(r4,r5)
		r3 = memw(r29+#676)
		memw(r29+#16) = r3
	}
	{
		call memset
		r25 = memw(r29+#684)
		memw(r29+#24) = r3
	}
	.falign
// %bb.9:                               // %for.body.lr.ph
	{
		r4 = lsr(r17,#5)
		r21 = add(r20,#12)
		r3:2 = combine(r17,r16)
		memw(r29+#564) = r4.new
	}
	{
		r0 = add(r23,#-32752)
		r5:4 = combine(r21,r16)
	}
	.falign
.LBB35_10:                              // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = #4095
	}
	{
		r6 = memw(r26+#0)
		if (cmp.gtu(r6.new,r6)) jump:nt .LBB35_34
	}
// %bb.11:                              // %cond.end
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		r6 = +mpyi(r6,#96)
	}
	{
		r7 = memw(r19+r6<<#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB35_34
	}
// %bb.12:                              // %lor.lhs.false23
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		r6 = add(r19,r6)
	}
	{
		r7 = memw(r6+#28)
		if (!cmp.eq(r7.new,r3)) jump:nt .LBB35_34
	}
// %bb.13:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		r7 = memw(r6+#32)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB35_34
	}
// %bb.14:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		r8 = and(r7,#31)
		if (!cmp.eq(r8.new,#0)) jump:nt .LBB35_34
	}
// %bb.15:                              // %lor.lhs.false32
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		r26 = add(r26,#4)
		r4 = add(r4,#-1)
		r8 = memw(r6+#84)
		if (cmp.eq(r8.new,#2)) jump:nt .LBB35_34
	}
// %bb.16:                              // %for.inc
                                        //   in Loop: Header=BB35_10 Depth=1
	{
		p1 = cmp.eq(r4,#0)
		r8 = memw(r5+#256)
	}
	{
		r8 += lsr(r7,#5)
		memw(r5+#260) = r8.new
	}
	{
		if (!p1) jump:nt .LBB35_10
		if (p1) r6 = memw(r29+##564)
		memw(r5++#4) = r6
	}
// %bb.17:                              // %for.end
	{
		r26 = asl(r6,#11)
		r7 = add(r29,#32)
		r1:0 = combine(#0,#1)
		memw(r29+#28) = r0
	}                                       // 4-byte Folded Spill
	{
		r7 = addasl(r7,r2,#2)
		r19 = setbit(r26,#9)
		r9:8 = combine(#0,#0)
		r5:4 = memd(r22+#24)
	}
	{
		r1:0 = add(r5:4,r1:0)
		memw(r29+#560) = r2
		memd(r22+#40) = r9:8
	}
	{
		r0 = memw(r22+#8)
		memd(r22+#24) = r1:0
	}
	{
		p0 = cmp.gtu(r19,r0)
		r2 = memw(r7+#268)
		memd(r22+#56) = r9:8
	}
	{
		if (!p0) jump:nt .LBB35_22
		memw(r22+#48) = #0
		memw(r29+#568) = r2
	}
// %bb.18:                              // %hexkl_moe_scratch_free.exit.i
	{
		r3:2 = combine(#0,#2)
		r0 = memw(r22+#0)
		memw(r22+#56) = #0
	}
	{
		r3:2 = add(r5:4,r3:2)
	}
	{
		call free
		memd(r22+#24) = r3:2
	}
	.falign
// %bb.19:                              // %hexkl_moe_scratch_free.exit.i
	{
		r0 = or(r26,##640)
		memw(r22+#4) = #0
		memw(r22+#8) = #0
	}
	{
		call malloc
	}
	.falign
// %bb.20:                              // %hexkl_moe_scratch_free.exit.i
	{
		if (!p1.new) r2 = add(r0,#127)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB35_35
		memw(r22+#0) = r0
	}
// %bb.21:                              // %if.end3.i
	{
		r3 = r17
		memw(r22+#8) = r19
	}
	{
		r19 = and(r2,#-128)
		jump .LBB35_23
		memw(r22+#4) = r19.new
	}
	.falign
.LBB35_22:                              // %for.end.if.end56_crit_edge
	{
		r19 = memw(r22+#4)
	}
	.falign
.LBB35_23:                              // %for.body78.lr.ph
	{
		r20 = add(r19,r26)
		r1:0 = combine(#1,r18)
		r2 = #64
		memw(r29+#0) = #0
	}
	{
		r27 = add(r20,#256)
		r22 = r3
	}
	{
		call hvx_quant_rows_u8_params
		r5:4 = combine(r27,r20)
	}
	.falign
// %bb.24:                              // %for.body78.lr.ph
	{
		r1:0 = combine(r22,r18)
		r4 = r19
		r2 = memw(r19+r26<<#0)
		r3 = memw(r20+#256)
	}
	{
		memw(r20+#4) = r2
		memw(r20+#260) = r3
	}
	{
		memw(r20+#8) = r2
		memw(r20+#264) = r3
	}
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		memw(r20+#12) = r2
		memw(r20+#268) = r3
	}
	.falign
// %bb.25:                              // %for.body78.lr.ph
	{
		r2 = memw(r29+#16)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
.LBB35_26:                              // %for.body78
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r21+#0)
	}
	{
		r21 = add(r21,#4)
		r5 = memw(r5+#20)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB35_28
	}
// %bb.27:                              // %for.cond75
                                        //   in Loop: Header=BB35_26 Depth=1
	{
		r16 = add(r16,#-1)
		if (!cmp.eq(r16.new,#0)) jump:t .LBB35_26
	}
	{
		jump .LBB35_30
	}
	.falign
.LBB35_28:                              // %if.then82
	{
		r4 = add(r29,#32)
		r1:0 = combine(#1,r19)
		r3:2 = combine(r27,r17)
	}
	{
		call hexkl_wh_affine_sums
		r4 = add(r4,#540)
	}
	.falign
// %bb.29:                              // %if.then82
	{
		r3 = memw(r29+#20)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	.falign
.LBB35_30:                              // %cleanup86
	{
		r7 = extractu(r25,#1,#16)
		p1 = !tstbit(r25,#6)
		r5 = and(r25,##131104)
	}
	{
		r6 = extractu(r25,#1,#18)
		p0 = cmp.eq(r5,#32)
		if (p1) r7 = #1
		memw(r29+#32) = r19
	}
	{
		r2 = minu(r3,r2)
		r5 = mux(p0,#0,r4)
		memw(r29+#36) = r20
		memw(r29+#40) = r27
	}
	{
		p0 = cmp.eq(r5,#0)
		memw(r29+#576) = r24
		memw(r29+#588) = r7
	}
	{
		memw(r29+#592) = r6
		memw(r29+#584) = r2
	}
	{
		if (p0) jump:nt .LBB35_32
		memw(r29+#580) = r5
	}
// %bb.31:                              // %if.then109
	{
		call hexkl_dma_ring_drain
	}
	.falign
.LBB35_32:                              // %if.end110
	{
		r1 = add(pc,##fc_m1_worker@PCREL)
		r3 = #8
		r2 = memw(r29+#568)
	}
	{
		r3 = minu(r2,r3)
		call hvx_worker_pool_run
		r2 = add(r29,#32)
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.33:                              // %if.end110
	{
		r2 = memw(r29+#596)
		r0 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		if (p1.new) r0 = #0
		if (!p1.new) r0 = add(r23,##-32767)
	}
	.falign
.LBB35_34:                              // %cleanup128
	{
		r17:16 = memd(r29+#648)
		r19:18 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#632)
		r23:22 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#616)
		r27:26 = memd(r29+#608)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB35_35:
	{
		r0 = add(r23,#-32766)
		jump .LBB35_34
	}
.Lfunc_end35:
	.size	hexkl_mm_u8i4_fc_m1_run, .Lfunc_end35-hexkl_mm_u8i4_fc_m1_run
                                        // -- End function
	.falign
	.type	fc_m1_worker,@function          // -- Begin function fc_m1_worker
fc_m1_worker:                           // @fc_m1_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = r0
		r24 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r1 = r22
		r16 = r2
		r0 = memw(r2+#552)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-24) = r21:20
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r20 = memw(r2+#532)
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r26 = asl(r20,#10)
		r17 = and(r0,#-128)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r26,r17)
	}
	.falign
// %bb.2:                               // %entry
	{
		r23 = #0
		r25 = r0
		r5:4 = combine(#0,#0)
		r27 = memw(r16+#536)
	}
	{
		r3:2 = combine(r23,r22)
		r21 = memw(r16+#548)
		memd(r29+#240) = r5:4
	}
	{
		r1:0 = mpyu(r27,r24)
		call __hexagon_udivdi3
	}
	.falign
// %bb.3:                               // %entry
	{
		r2 = add(r24,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r27,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r23,r22)
	}
	.falign
// %bb.4:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r18)
	}
	{
		if (!p0) jump:nt .LBB36_71
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.5:                               // %if.end
	{
		p1 = cmp.gtu(r26,r17)
		r4 = #1
		p0 = cmp.eq(r21,#0)
	}
	{
		p1 = not(p1)
	}
	{
		p1 = and(p1,!p0)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB36_10
		if (p1) r1:0 = memd(r29+#248)
		memw(r29+#216) = r2.new
	}                                       // 8-byte Folded Reload
// %bb.6:                               // %if.then5
	{
		r2 = add(r0,sub(#3,r18))
	}
	{
		r4 = lsr(r2,#2)
		r2 = asl(r20,#9)
	}
	{
		r4 = minu(r4,r25)
		r3 = memw(r16+#556)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB36_9
	}
// %bb.7:                               // %if.then5
	{
		r3 = add(r4,#3)
		p1 = cmp.gtu(r25,#3)
		if (!p1.new) jump:nt .LBB36_9
	}
// %bb.8:                               // %if.then11
	{
		r4 = and(r4,##1073741820)
		r3 = and(r3,##2147483644)
	}
	{
		p0 = cmp.gtu(r3,r25)
		if (!p0.new) r4 = add(r3,#0)
	}
	.falign
.LBB36_9:                               // %if.end20
	{
		r21 += mpyi(r17,r24)
		memw(r29+#240) = r21.new
	}
	{
		r21 += mpyi(r2,r4)
		r23 = r21
		memw(r29+#244) = r21.new
	}
	.falign
.LBB36_10:                              // %if.end28
	{
		r25 = add(r16,#272)
	}
	{
		r3 = r25
	}
	.balign 32
.LBB36_11:                              // %while.cond.i.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p1 = cmp.gtu(r3,r18); if (!p1.new) jump:t .LBB36_11
	}
// %bb.12:                              // %fc_m1_block_end.exit
	{
		r3 = add(r4,r18)
		r2 = memw(r2+#0)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r5 = add(pc,##g_fc_m1_desc@PCREL)
		r2 = minu(r3,r2)
		memw(r29+#236) = r4
	}                                       // 4-byte Folded Spill
	{
		r5 += asl(r24,#8)
		r3 = r25
	}
	{
		r26 = minu(r2,r0)
		r0 = memw(r29+#216)
		memw(r29+#232) = r5
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (!p0.new) jump:t .LBB36_20
	}
	.balign 32
.LBB36_14:                              // %while.cond.i.i318
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p0 = cmp.gtu(r3,r18); if (!p0.new) jump:t .LBB36_14
	}
// %bb.15:                              // %fc_m1_part.exit.i
	{
		r4 = memw(r2+#-260)
		r3 = memw(r16+#560)
	}
	{
		p1 = cmp.eq(r3,#0)
		r6 = memw(r4+#36)
		r2 = memw(r2+#-4)
	}
	{
		if (p1) r6 = #0
		if (p1) jump:nt .LBB36_19
		r3 = memw(r4+#4)
		r5 = memw(r4+#32)
	}
// %bb.16:                              // %land.rhs.i.i
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB36_19
		if (p0.new) r4 = memw(r4+#40)
	}
// %bb.17:                              // %lor.rhs.i.i
	{
		r6 = !cmp.eq(r4,#0)
	}
	.falign
.LBB36_19:                              // %fc_m1_push.exit
	{
		r5 = and(##-512,asl(r5,#4))
		r7 = sub(r18,r2)
		r4 = sub(r26,r18)
	}
	{
		r4 = asl(r4,#9)
		r1 = #0
		r2 = r23
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r7,#9)
		memw(r29+#8) = r6
		memw(r29+#4) = r20
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	.falign
.LBB36_20:                              // %while.body.lr.ph
	{
		r23 = #0
		r17 = r26
	}
	.falign
.LBB36_21:                              // %while.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB36_22 Depth 2
                                        //     Child Loop BB36_29 Depth 2
                                        //     Child Loop BB36_36 Depth 2
                                        //     Child Loop BB36_39 Depth 2
                                        //       Child Loop BB36_54 Depth 3
                                        //       Child Loop BB36_58 Depth 3
	{
		r3 = r25
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.gtu(r0,r26)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB36_24
		memw(r29+#220) = r2.new
	}                                       // 4-byte Folded Spill
	.balign 32
.LBB36_22:                              // %while.cond.i.i328
                                        //   Parent Loop BB36_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.gtu(r3,r26)
		r3 = add(r2,#4)
		if (!p1.new) jump:t .LBB36_22
	}
// %bb.23:                              // %fc_m1_block_end.exit340
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r3 = memw(r29+#236)
		r2 = memw(r2+#0)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r26,r3)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r2 = minu(r3,r2)
	}
	{
		r17 = minu(r2,r0)
	}
	.falign
.LBB36_24:                              // %cond.end39
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r19 = togglebit(r23,#0)
		r2 = r25
		r3 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB36_36
		if (p0.new) r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
// %bb.25:                              // %if.then42
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r0 = addasl(r2,r23,#7)
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.26:                              // %if.then42
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r2 = r25
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB36_70
	}
// %bb.27:                              // %if.end47
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r5 = r25
		p1 = cmp.gtu(r17,r26)
		if (!p1.new) jump:t .LBB36_36
	}
// %bb.28:                              // %if.then49
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r4 = togglebit(r23,#0)
		r2 = add(r29,#240)
	}
	{
		r2 = memw(r2+r4<<#2)
	}
	.balign 32
.LBB36_29:                              // %while.cond.i.i342
                                        //   Parent Loop BB36_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = r5
		r5 = memw(r5+#0)
	}
	{
		p0 = cmp.gtu(r5,r26)
		r5 = add(r3,#4)
		if (!p0.new) jump:t .LBB36_29
	}
// %bb.30:                              // %fc_m1_part.exit.i348
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r5 = memw(r16+#560)
	}
	{
		if (p1.new) r6 = #0
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB36_34
		r5 = memw(r3+#-260)
	}
// %bb.31:                              // %land.rhs.i.i358
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r6 = memw(r5+#36)
	}
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB36_34
	}
// %bb.32:                              // %lor.rhs.i.i368
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r6 = memw(r5+#40)
	}
	{
		r6 = !cmp.eq(r6,#0)
	}
	.falign
.LBB36_34:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r8 = sub(r17,r26)
		r1 = #0
		r7 = memw(r3+#-4)
		r3 = memw(r5+#4)
	}
	{
		r5 = memw(r5+#32)
		r9 = memw(r16+#532)
	}
	{
		r6 = sub(r26,r7)
		r12 = memw(r29+#232)
		memw(r29+#8) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = and(##-512,asl(r5,#4))
		r0 = addasl(r12,r4,#7)
		memw(r29+#12) = #1
	}
	{
		r3 += asl(r6,#9)
		r4 = asl(r8,#9)
		memw(r29+#4) = r9
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#0) = r4
	}
	.falign
// %bb.35:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r2 = r25
	}
	.balign 32
.LBB36_36:                              // %while.cond.i
                                        //   Parent Loop BB36_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r22 = r2
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r22,#4)
		p1 = cmp.gtu(r2,r18); if (!p1.new) jump:t .LBB36_36
	}
// %bb.37:                              // %fc_m1_part.exit
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		p0 = cmp.gtu(r26,r18)
		if (!p0.new) jump:t .LBB36_69
		memw(r29+#228) = r19
		memw(r29+#224) = r17
	}                                       // 4-byte Folded Spill
// %bb.38:                              // %for.body.lr.ph
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r19 = sub(r26,r18)
		r20 = r18
		r17 = memw(r22+#-260)
	}
	.falign
.LBB36_39:                              // %for.body
                                        //   Parent Loop BB36_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB36_54 Depth 3
                                        //       Child Loop BB36_58 Depth 3
	{
		r6 = add(r29,#256)
		r1 = #1
		r24 = memw(r22+#-4)
		r2 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r21 = sub(r20,r24)
		if (!p1.new) jump:t .LBB36_44
		if (!p1.new) r4 = memw(r17+#32)
	}
// %bb.40:                              // %land.lhs.true62
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r4 = add(r29,#256)
		r5 = sub(r20,r18)
		r3 = add(r29,#240)
		r0 = memw(r16+#0)
	}
	{
		r3 = addasl(r3,r23,#2)
		r1 = #1
		r2 = memw(r16+#556)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB36_46
	}
// %bb.41:                              // %if.then65
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r4 = r19
		r2 = sub(r26,r20)
		if (!cmp.gtu(r2.new,#3)) jump:t .LBB36_48
	}
// %bb.42:                              // %if.then68
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r3 = add(r29,#256)
		r2 = memw(r3+#0)
		r0 = memw(r16+#0)
	}
	{
		call hvx_gemv_u8i4_wh_4col_nopf
		r3 = #512
		r1 = memw(r16+#532)
		memw(r29+#0) = r3

	} :mem_noshuf
	.falign
// %bb.43:                              // %if.then68
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #4
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB36_53
	}
	{
		jump .LBB36_61
	}
	.falign
.LBB36_44:                              // %if.else102
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r27 = #1
		r5 = memw(r16+#556)
		r0 = memw(r16+#0)
	}
	{
		r4 = lsr(r4,#5)
		r2 = memw(r16+#532)
	}
	{
		r5 = r21
		r3 = memw(r17+#4)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		call hvx_gemm_u8i4_wh_col
		memw(r29+#4) = r6
	}
	.falign
// %bb.45:                              // %if.else102
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB36_53
	}
	{
		jump .LBB36_61
	}
	.falign
.LBB36_46:                              // %if.then94
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r27 = #1
		r2 = memw(r16+#532)
	}
	{
		r4 = r19
		r3 = memw(r3+#0)
		memw(r29+#4) = r4
	}
	{
		call hvx_gemm_u8i4_wh_col_nopf
		memw(r29+#0) = #0
	}
	.falign
// %bb.47:                              // %if.then94
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB36_53
	}
	{
		jump .LBB36_61
	}
	.falign
.LBB36_48:                              // %if.else
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = add(r29,#256)
		p1 = cmp.eq(r2,#3)
		r0 = memw(r16+#0)
		r1 = memw(r16+#532)
	}
	{
		if (!p1) r3 = add(r19,#0)
		if (!p1) jump:nt .LBB36_51
		r4 = r5
		r2 = memw(r3+#0)
	}
// %bb.49:                              // %if.then76
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r3 = add(r29,#256)
		r4 = r19
		memw(r29+#0) = r3.new
	}
	{
		call hvx_gemv_u8i4_wh_3col_nopf
		r3 = #512
	}
	.falign
// %bb.50:                              // %if.then76
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #3
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB36_53
	}
	{
		jump .LBB36_61
	}
	.falign
.LBB36_51:                              // %if.else83
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		call hvx_gemv_u8i4_wh_col_aligned_nopf
		r5 = r6
	}
	.falign
// %bb.52:                              // %if.else83
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #1
		r4 = memw(r17+#20)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB36_61
	}
	.falign
.LBB36_53:                              // %if.then112
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r8 = addasl(r4,r6,#2)
		r7 = asl(r20,#7)
		r5 = add(r29,#256)
		r2 = memw(r16+#540)
	}
	{
		r7 -= asl(r24,#7)
		v0 = vsplat(r2)
		r14 = #0
		r13 = add(r5,#128)
	}
	{
		r12 = add(r4,add(r7,##128))
		r3 = asl(r27,#5)
	}
	.balign 32
.LBB36_54:                              // %for.body.us.i
                                        //   Parent Loop BB36_21 Depth=1
                                        //     Parent Loop BB36_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r14,#64)
		r9 = r14
		v2 = vmemu(r8+#0)
	}
	{
		r4 = r13
		p1 = cmp.gtu(r7,r3)
		r7 = r12
		v1 = vmem(r5+#0)
	}
	{
		v1.w += vmpyie(v0.w,v2.h)
		r8 = add(r8,#128)
		r14 = add(r14,#32)
		vmem(r5+#0) = v1.new
	}
	{
		r13 = add(r13,#128)
		r12 = add(r12,#128)
		r5 = add(r5,#128)
		if (!p1) jump:nt .LBB36_54
	}
// %bb.55:                              // %for.cond10.preheader.i
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r8 = add(r3,sub(#-32,r9))
		r5 = r7
		p0 = cmp.gtu(r3,r14)
		if (!p0.new) jump:t .LBB36_61
	}
// %bb.56:                              // %for.body17.us.i.preheader
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r9 = lsr(r8,#1)
		r3 = r4
		r8 = and(r8,#1)
	}
	{
		loop0(.LBB36_58,r9)
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB36_59
	}
	.falign
.LBB36_58:                              //   Parent Loop BB36_21 Depth=1
                                        //     Parent Loop BB36_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r5++#8)
		r12 = memw(r4+#0)
	}
	{
		r1 = memw(r4+#4)
	}
	{
		r12 += mpyi(r9,r2)
		memw(r3++#8) = r12.new
	}
	{
		r7 = r5
		r9 = memw(r7+#4)
	}
	{
		r1 += mpyi(r9,r2)
		r4 = r3
		memw(r4+#4) = r1.new
	} :endloop0
	.falign
.LBB36_59:                              //   in Loop: Header=BB36_39 Depth=2
	{
		p0 = cmp.gtu(r8,#0)
		if (!p0.new) jump:t .LBB36_61
		if (p0.new) r0 = memw(r3+#0)
		if (p0.new) r4 = memw(r5+#0)
	}
	.falign
.LBB36_60:                              // Block address taken
                                        // %for.body17.us.i
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r0 += mpyi(r4,r2)
		memw(r3++#4) = r0.new
	}
	.falign
.LBB36_61:                              // %if.end118
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r0 = add(r29,#256)
		p1 = cmp.eq(r27,#3)
		r2 = memw(r16+#544)
		r3 = memw(r16+#4)
	}
	{
		r7 = addasl(r2,r20,#7)
		if (p1) jump:nt .LBB36_65
		if (p1) r5:4 = memd(r17+#8)
		if (p1) r2 = memw(r16+#8)
	}
// %bb.62:                              // %if.end118
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r0 = add(r29,#256)
		p0 = cmp.eq(r27,#4)
		if (!p0.new) jump:nt .LBB36_67
		if (p0.new) r2 = memw(r16+#8)
	}
// %bb.63:                              // %if.then123
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r5:4 = memd(r17+#8)
		r8 = memw(r17+#16)
	}
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_4tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.64:                              // %if.then123
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t .LBB36_39
	}
	{
		jump .LBB36_69
	}
	.falign
.LBB36_65:                              // %if.then132
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r8 = memw(r17+#16)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_3tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.66:                              // %if.then132
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB36_39
	}
	{
		jump .LBB36_69
	}
	.falign
.LBB36_67:                              // %if.else144
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r0 = add(r29,#256)
		r1 = #32
		r5 = memw(r17+#16)
		r2 = memw(r16+#536)
	}
	{
		r5 = addasl(r5,r6,#2)
		r2 = asl(r2,#5)
		r9:8 = memd(r17+#8)
		r4 = memw(r16+#8)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#4) = r5
	}
	{
		r6 = addasl(r8,r6,#2)
		memw(r29+#8) = r7
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.68:                              // %if.else144
                                        //   in Loop: Header=BB36_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB36_39
	}
	.falign
.LBB36_69:                              // %cleanup
                                        //   in Loop: Header=BB36_21 Depth=1
	{
		r18 = r26
		r23 = memw(r29+#228)
		r2 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r17 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r26 = r17
		if (p0) jump:nt .LBB36_21
	}
	{
		jump .LBB36_71
	}
	.falign
.LBB36_70:                              // %cleanup.thread
	{
		r2 = #1
		memw(r16+#564) = r2.new
	}
	.falign
.LBB36_71:                              // %cleanup163
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end36:
	.size	fc_m1_worker, .Lfunc_end36-fc_m1_worker
                                        // -- End function
	.globl	audit_need_M1024_E1             // -- Begin function audit_need_M1024_E1
	.balign 32
	.type	audit_need_M1024_E1,@function
audit_need_M1024_E1:                    // @audit_need_M1024_E1
// %bb.0:                               // %entry
	{
		r0 = ##27568256
		jumpr r31
	}
.Lfunc_end37:
	.size	audit_need_M1024_E1, .Lfunc_end37-audit_need_M1024_E1
                                        // -- End function
	.globl	audit_need_M1024_E2             // -- Begin function audit_need_M1024_E2
	.balign 32
	.type	audit_need_M1024_E2,@function
audit_need_M1024_E2:                    // @audit_need_M1024_E2
// %bb.0:                               // %entry
	{
		r0 = ##27698304
		jumpr r31
	}
.Lfunc_end38:
	.size	audit_need_M1024_E2, .Lfunc_end38-audit_need_M1024_E2
                                        // -- End function
	.globl	audit_need_M1024_E3             // -- Begin function audit_need_M1024_E3
	.balign 32
	.type	audit_need_M1024_E3,@function
audit_need_M1024_E3:                    // @audit_need_M1024_E3
// %bb.0:                               // %entry
	{
		r0 = ##27828480
		jumpr r31
	}
.Lfunc_end39:
	.size	audit_need_M1024_E3, .Lfunc_end39-audit_need_M1024_E3
                                        // -- End function
	.globl	audit_need_M1024_E4             // -- Begin function audit_need_M1024_E4
	.balign 32
	.type	audit_need_M1024_E4,@function
audit_need_M1024_E4:                    // @audit_need_M1024_E4
// %bb.0:                               // %entry
	{
		r0 = ##27958528
		jumpr r31
	}
.Lfunc_end40:
	.size	audit_need_M1024_E4, .Lfunc_end40-audit_need_M1024_E4
                                        // -- End function
	.globl	audit_need_M1024_E5             // -- Begin function audit_need_M1024_E5
	.balign 32
	.type	audit_need_M1024_E5,@function
audit_need_M1024_E5:                    // @audit_need_M1024_E5
// %bb.0:                               // %entry
	{
		r0 = ##28088576
		jumpr r31
	}
.Lfunc_end41:
	.size	audit_need_M1024_E5, .Lfunc_end41-audit_need_M1024_E5
                                        // -- End function
	.globl	audit_need_M1024_E6             // -- Begin function audit_need_M1024_E6
	.balign 32
	.type	audit_need_M1024_E6,@function
audit_need_M1024_E6:                    // @audit_need_M1024_E6
// %bb.0:                               // %entry
	{
		r0 = ##28218624
		jumpr r31
	}
.Lfunc_end42:
	.size	audit_need_M1024_E6, .Lfunc_end42-audit_need_M1024_E6
                                        // -- End function
	.globl	audit_need_M1024_E7             // -- Begin function audit_need_M1024_E7
	.balign 32
	.type	audit_need_M1024_E7,@function
audit_need_M1024_E7:                    // @audit_need_M1024_E7
// %bb.0:                               // %entry
	{
		r0 = ##28348800
		jumpr r31
	}
.Lfunc_end43:
	.size	audit_need_M1024_E7, .Lfunc_end43-audit_need_M1024_E7
                                        // -- End function
	.globl	audit_need_M1024_E8             // -- Begin function audit_need_M1024_E8
	.balign 32
	.type	audit_need_M1024_E8,@function
audit_need_M1024_E8:                    // @audit_need_M1024_E8
// %bb.0:                               // %entry
	{
		r0 = ##28478848
		jumpr r31
	}
.Lfunc_end44:
	.size	audit_need_M1024_E8, .Lfunc_end44-audit_need_M1024_E8
                                        // -- End function
	.globl	audit_need_M1024_E9             // -- Begin function audit_need_M1024_E9
	.balign 32
	.type	audit_need_M1024_E9,@function
audit_need_M1024_E9:                    // @audit_need_M1024_E9
// %bb.0:                               // %entry
	{
		r0 = ##28608768
		jumpr r31
	}
.Lfunc_end45:
	.size	audit_need_M1024_E9, .Lfunc_end45-audit_need_M1024_E9
                                        // -- End function
	.globl	audit_need_M1024_E10            // -- Begin function audit_need_M1024_E10
	.balign 32
	.type	audit_need_M1024_E10,@function
audit_need_M1024_E10:                   // @audit_need_M1024_E10
// %bb.0:                               // %entry
	{
		r0 = ##28738816
		jumpr r31
	}
.Lfunc_end46:
	.size	audit_need_M1024_E10, .Lfunc_end46-audit_need_M1024_E10
                                        // -- End function
	.globl	audit_need_M1024_E11            // -- Begin function audit_need_M1024_E11
	.balign 32
	.type	audit_need_M1024_E11,@function
audit_need_M1024_E11:                   // @audit_need_M1024_E11
// %bb.0:                               // %entry
	{
		r0 = ##28868992
		jumpr r31
	}
.Lfunc_end47:
	.size	audit_need_M1024_E11, .Lfunc_end47-audit_need_M1024_E11
                                        // -- End function
	.globl	audit_need_M1024_E12            // -- Begin function audit_need_M1024_E12
	.balign 32
	.type	audit_need_M1024_E12,@function
audit_need_M1024_E12:                   // @audit_need_M1024_E12
// %bb.0:                               // %entry
	{
		r0 = ##28999040
		jumpr r31
	}
.Lfunc_end48:
	.size	audit_need_M1024_E12, .Lfunc_end48-audit_need_M1024_E12
                                        // -- End function
	.globl	audit_need_M1024_E13            // -- Begin function audit_need_M1024_E13
	.balign 32
	.type	audit_need_M1024_E13,@function
audit_need_M1024_E13:                   // @audit_need_M1024_E13
// %bb.0:                               // %entry
	{
		r0 = ##29129088
		jumpr r31
	}
.Lfunc_end49:
	.size	audit_need_M1024_E13, .Lfunc_end49-audit_need_M1024_E13
                                        // -- End function
	.globl	audit_need_M1024_E14            // -- Begin function audit_need_M1024_E14
	.balign 32
	.type	audit_need_M1024_E14,@function
audit_need_M1024_E14:                   // @audit_need_M1024_E14
// %bb.0:                               // %entry
	{
		r0 = ##29259136
		jumpr r31
	}
.Lfunc_end50:
	.size	audit_need_M1024_E14, .Lfunc_end50-audit_need_M1024_E14
                                        // -- End function
	.globl	audit_need_M1024_E15            // -- Begin function audit_need_M1024_E15
	.balign 32
	.type	audit_need_M1024_E15,@function
audit_need_M1024_E15:                   // @audit_need_M1024_E15
// %bb.0:                               // %entry
	{
		r0 = ##29389312
		jumpr r31
	}
.Lfunc_end51:
	.size	audit_need_M1024_E15, .Lfunc_end51-audit_need_M1024_E15
                                        // -- End function
	.globl	audit_need_M1024_E16            // -- Begin function audit_need_M1024_E16
	.balign 32
	.type	audit_need_M1024_E16,@function
audit_need_M1024_E16:                   // @audit_need_M1024_E16
// %bb.0:                               // %entry
	{
		r0 = ##29519360
		jumpr r31
	}
.Lfunc_end52:
	.size	audit_need_M1024_E16, .Lfunc_end52-audit_need_M1024_E16
                                        // -- End function
	.globl	audit_need_M1024_E17            // -- Begin function audit_need_M1024_E17
	.balign 32
	.type	audit_need_M1024_E17,@function
audit_need_M1024_E17:                   // @audit_need_M1024_E17
// %bb.0:                               // %entry
	{
		r0 = ##29649408
		jumpr r31
	}
.Lfunc_end53:
	.size	audit_need_M1024_E17, .Lfunc_end53-audit_need_M1024_E17
                                        // -- End function
	.globl	audit_need_M1024_E18            // -- Begin function audit_need_M1024_E18
	.balign 32
	.type	audit_need_M1024_E18,@function
audit_need_M1024_E18:                   // @audit_need_M1024_E18
// %bb.0:                               // %entry
	{
		r0 = ##29779328
		jumpr r31
	}
.Lfunc_end54:
	.size	audit_need_M1024_E18, .Lfunc_end54-audit_need_M1024_E18
                                        // -- End function
	.globl	audit_need_M1024_E19            // -- Begin function audit_need_M1024_E19
	.balign 32
	.type	audit_need_M1024_E19,@function
audit_need_M1024_E19:                   // @audit_need_M1024_E19
// %bb.0:                               // %entry
	{
		r0 = ##29909504
		jumpr r31
	}
.Lfunc_end55:
	.size	audit_need_M1024_E19, .Lfunc_end55-audit_need_M1024_E19
                                        // -- End function
	.globl	audit_need_M1024_E20            // -- Begin function audit_need_M1024_E20
	.balign 32
	.type	audit_need_M1024_E20,@function
audit_need_M1024_E20:                   // @audit_need_M1024_E20
// %bb.0:                               // %entry
	{
		r0 = ##30039552
		jumpr r31
	}
.Lfunc_end56:
	.size	audit_need_M1024_E20, .Lfunc_end56-audit_need_M1024_E20
                                        // -- End function
	.globl	audit_need_M1024_E21            // -- Begin function audit_need_M1024_E21
	.balign 32
	.type	audit_need_M1024_E21,@function
audit_need_M1024_E21:                   // @audit_need_M1024_E21
// %bb.0:                               // %entry
	{
		r0 = ##30169600
		jumpr r31
	}
.Lfunc_end57:
	.size	audit_need_M1024_E21, .Lfunc_end57-audit_need_M1024_E21
                                        // -- End function
	.globl	audit_need_M1024_E22            // -- Begin function audit_need_M1024_E22
	.balign 32
	.type	audit_need_M1024_E22,@function
audit_need_M1024_E22:                   // @audit_need_M1024_E22
// %bb.0:                               // %entry
	{
		r0 = ##30299648
		jumpr r31
	}
.Lfunc_end58:
	.size	audit_need_M1024_E22, .Lfunc_end58-audit_need_M1024_E22
                                        // -- End function
	.globl	audit_need_M1024_E23            // -- Begin function audit_need_M1024_E23
	.balign 32
	.type	audit_need_M1024_E23,@function
audit_need_M1024_E23:                   // @audit_need_M1024_E23
// %bb.0:                               // %entry
	{
		r0 = ##30429824
		jumpr r31
	}
.Lfunc_end59:
	.size	audit_need_M1024_E23, .Lfunc_end59-audit_need_M1024_E23
                                        // -- End function
	.globl	audit_need_M1024_E24            // -- Begin function audit_need_M1024_E24
	.balign 32
	.type	audit_need_M1024_E24,@function
audit_need_M1024_E24:                   // @audit_need_M1024_E24
// %bb.0:                               // %entry
	{
		r0 = ##30559872
		jumpr r31
	}
.Lfunc_end60:
	.size	audit_need_M1024_E24, .Lfunc_end60-audit_need_M1024_E24
                                        // -- End function
	.globl	audit_need_M1024_E25            // -- Begin function audit_need_M1024_E25
	.balign 32
	.type	audit_need_M1024_E25,@function
audit_need_M1024_E25:                   // @audit_need_M1024_E25
// %bb.0:                               // %entry
	{
		r0 = ##30689920
		jumpr r31
	}
.Lfunc_end61:
	.size	audit_need_M1024_E25, .Lfunc_end61-audit_need_M1024_E25
                                        // -- End function
	.globl	audit_need_M1024_E26            // -- Begin function audit_need_M1024_E26
	.balign 32
	.type	audit_need_M1024_E26,@function
audit_need_M1024_E26:                   // @audit_need_M1024_E26
// %bb.0:                               // %entry
	{
		r0 = ##30819840
		jumpr r31
	}
.Lfunc_end62:
	.size	audit_need_M1024_E26, .Lfunc_end62-audit_need_M1024_E26
                                        // -- End function
	.globl	audit_need_M1024_E27            // -- Begin function audit_need_M1024_E27
	.balign 32
	.type	audit_need_M1024_E27,@function
audit_need_M1024_E27:                   // @audit_need_M1024_E27
// %bb.0:                               // %entry
	{
		r0 = ##30950016
		jumpr r31
	}
.Lfunc_end63:
	.size	audit_need_M1024_E27, .Lfunc_end63-audit_need_M1024_E27
                                        // -- End function
	.globl	audit_need_M1024_E28            // -- Begin function audit_need_M1024_E28
	.balign 32
	.type	audit_need_M1024_E28,@function
audit_need_M1024_E28:                   // @audit_need_M1024_E28
// %bb.0:                               // %entry
	{
		r0 = ##31080064
		jumpr r31
	}
.Lfunc_end64:
	.size	audit_need_M1024_E28, .Lfunc_end64-audit_need_M1024_E28
                                        // -- End function
	.globl	audit_need_M1024_E29            // -- Begin function audit_need_M1024_E29
	.balign 32
	.type	audit_need_M1024_E29,@function
audit_need_M1024_E29:                   // @audit_need_M1024_E29
// %bb.0:                               // %entry
	{
		r0 = ##31210112
		jumpr r31
	}
.Lfunc_end65:
	.size	audit_need_M1024_E29, .Lfunc_end65-audit_need_M1024_E29
                                        // -- End function
	.globl	audit_need_M1024_E30            // -- Begin function audit_need_M1024_E30
	.balign 32
	.type	audit_need_M1024_E30,@function
audit_need_M1024_E30:                   // @audit_need_M1024_E30
// %bb.0:                               // %entry
	{
		r0 = ##31340160
		jumpr r31
	}
.Lfunc_end66:
	.size	audit_need_M1024_E30, .Lfunc_end66-audit_need_M1024_E30
                                        // -- End function
	.globl	audit_need_M1024_E31            // -- Begin function audit_need_M1024_E31
	.balign 32
	.type	audit_need_M1024_E31,@function
audit_need_M1024_E31:                   // @audit_need_M1024_E31
// %bb.0:                               // %entry
	{
		r0 = ##31470336
		jumpr r31
	}
.Lfunc_end67:
	.size	audit_need_M1024_E31, .Lfunc_end67-audit_need_M1024_E31
                                        // -- End function
	.globl	audit_need_M1024_E32            // -- Begin function audit_need_M1024_E32
	.balign 32
	.type	audit_need_M1024_E32,@function
audit_need_M1024_E32:                   // @audit_need_M1024_E32
// %bb.0:                               // %entry
	{
		r0 = ##31600000
		jumpr r31
	}
.Lfunc_end68:
	.size	audit_need_M1024_E32, .Lfunc_end68-audit_need_M1024_E32
                                        // -- End function
	.globl	audit_need_M1024_E33            // -- Begin function audit_need_M1024_E33
	.balign 32
	.type	audit_need_M1024_E33,@function
audit_need_M1024_E33:                   // @audit_need_M1024_E33
// %bb.0:                               // %entry
	{
		r0 = ##31730816
		jumpr r31
	}
.Lfunc_end69:
	.size	audit_need_M1024_E33, .Lfunc_end69-audit_need_M1024_E33
                                        // -- End function
	.globl	audit_need_M1024_E34            // -- Begin function audit_need_M1024_E34
	.balign 32
	.type	audit_need_M1024_E34,@function
audit_need_M1024_E34:                   // @audit_need_M1024_E34
// %bb.0:                               // %entry
	{
		r0 = ##31860864
		jumpr r31
	}
.Lfunc_end70:
	.size	audit_need_M1024_E34, .Lfunc_end70-audit_need_M1024_E34
                                        // -- End function
	.globl	audit_need_M1024_E35            // -- Begin function audit_need_M1024_E35
	.balign 32
	.type	audit_need_M1024_E35,@function
audit_need_M1024_E35:                   // @audit_need_M1024_E35
// %bb.0:                               // %entry
	{
		r0 = ##31990912
		jumpr r31
	}
.Lfunc_end71:
	.size	audit_need_M1024_E35, .Lfunc_end71-audit_need_M1024_E35
                                        // -- End function
	.globl	audit_need_M1024_E36            // -- Begin function audit_need_M1024_E36
	.balign 32
	.type	audit_need_M1024_E36,@function
audit_need_M1024_E36:                   // @audit_need_M1024_E36
// %bb.0:                               // %entry
	{
		r0 = ##32120960
		jumpr r31
	}
.Lfunc_end72:
	.size	audit_need_M1024_E36, .Lfunc_end72-audit_need_M1024_E36
                                        // -- End function
	.globl	audit_need_M1024_E37            // -- Begin function audit_need_M1024_E37
	.balign 32
	.type	audit_need_M1024_E37,@function
audit_need_M1024_E37:                   // @audit_need_M1024_E37
// %bb.0:                               // %entry
	{
		r0 = ##32251008
		jumpr r31
	}
.Lfunc_end73:
	.size	audit_need_M1024_E37, .Lfunc_end73-audit_need_M1024_E37
                                        // -- End function
	.globl	audit_need_M1024_E38            // -- Begin function audit_need_M1024_E38
	.balign 32
	.type	audit_need_M1024_E38,@function
audit_need_M1024_E38:                   // @audit_need_M1024_E38
// %bb.0:                               // %entry
	{
		r0 = ##32381056
		jumpr r31
	}
.Lfunc_end74:
	.size	audit_need_M1024_E38, .Lfunc_end74-audit_need_M1024_E38
                                        // -- End function
	.globl	audit_need_M1024_E39            // -- Begin function audit_need_M1024_E39
	.balign 32
	.type	audit_need_M1024_E39,@function
audit_need_M1024_E39:                   // @audit_need_M1024_E39
// %bb.0:                               // %entry
	{
		r0 = ##32511232
		jumpr r31
	}
.Lfunc_end75:
	.size	audit_need_M1024_E39, .Lfunc_end75-audit_need_M1024_E39
                                        // -- End function
	.globl	audit_need_M1024_E40            // -- Begin function audit_need_M1024_E40
	.balign 32
	.type	audit_need_M1024_E40,@function
audit_need_M1024_E40:                   // @audit_need_M1024_E40
// %bb.0:                               // %entry
	{
		r0 = ##32641280
		jumpr r31
	}
.Lfunc_end76:
	.size	audit_need_M1024_E40, .Lfunc_end76-audit_need_M1024_E40
                                        // -- End function
	.globl	audit_need_M1024_E41            // -- Begin function audit_need_M1024_E41
	.balign 32
	.type	audit_need_M1024_E41,@function
audit_need_M1024_E41:                   // @audit_need_M1024_E41
// %bb.0:                               // %entry
	{
		r0 = ##32771328
		jumpr r31
	}
.Lfunc_end77:
	.size	audit_need_M1024_E41, .Lfunc_end77-audit_need_M1024_E41
                                        // -- End function
	.globl	audit_need_M1024_E42            // -- Begin function audit_need_M1024_E42
	.balign 32
	.type	audit_need_M1024_E42,@function
audit_need_M1024_E42:                   // @audit_need_M1024_E42
// %bb.0:                               // %entry
	{
		r0 = ##32901376
		jumpr r31
	}
.Lfunc_end78:
	.size	audit_need_M1024_E42, .Lfunc_end78-audit_need_M1024_E42
                                        // -- End function
	.globl	audit_need_M1024_E43            // -- Begin function audit_need_M1024_E43
	.balign 32
	.type	audit_need_M1024_E43,@function
audit_need_M1024_E43:                   // @audit_need_M1024_E43
// %bb.0:                               // %entry
	{
		r0 = ##33031424
		jumpr r31
	}
.Lfunc_end79:
	.size	audit_need_M1024_E43, .Lfunc_end79-audit_need_M1024_E43
                                        // -- End function
	.globl	audit_need_M1024_E44            // -- Begin function audit_need_M1024_E44
	.balign 32
	.type	audit_need_M1024_E44,@function
audit_need_M1024_E44:                   // @audit_need_M1024_E44
// %bb.0:                               // %entry
	{
		r0 = ##33161472
		jumpr r31
	}
.Lfunc_end80:
	.size	audit_need_M1024_E44, .Lfunc_end80-audit_need_M1024_E44
                                        // -- End function
	.globl	audit_need_M1024_E45            // -- Begin function audit_need_M1024_E45
	.balign 32
	.type	audit_need_M1024_E45,@function
audit_need_M1024_E45:                   // @audit_need_M1024_E45
// %bb.0:                               // %entry
	{
		r0 = ##33291520
		jumpr r31
	}
.Lfunc_end81:
	.size	audit_need_M1024_E45, .Lfunc_end81-audit_need_M1024_E45
                                        // -- End function
	.globl	audit_need_M1024_E46            // -- Begin function audit_need_M1024_E46
	.balign 32
	.type	audit_need_M1024_E46,@function
audit_need_M1024_E46:                   // @audit_need_M1024_E46
// %bb.0:                               // %entry
	{
		r0 = ##33421568
		jumpr r31
	}
.Lfunc_end82:
	.size	audit_need_M1024_E46, .Lfunc_end82-audit_need_M1024_E46
                                        // -- End function
	.globl	audit_need_M1024_E47            // -- Begin function audit_need_M1024_E47
	.balign 32
	.type	audit_need_M1024_E47,@function
audit_need_M1024_E47:                   // @audit_need_M1024_E47
// %bb.0:                               // %entry
	{
		r0 = ##33551744
		jumpr r31
	}
.Lfunc_end83:
	.size	audit_need_M1024_E47, .Lfunc_end83-audit_need_M1024_E47
                                        // -- End function
	.globl	audit_need_M1024_E48            // -- Begin function audit_need_M1024_E48
	.balign 32
	.type	audit_need_M1024_E48,@function
audit_need_M1024_E48:                   // @audit_need_M1024_E48
// %bb.0:                               // %entry
	{
		r0 = ##33681792
		jumpr r31
	}
.Lfunc_end84:
	.size	audit_need_M1024_E48, .Lfunc_end84-audit_need_M1024_E48
                                        // -- End function
	.globl	audit_need_M1024_E49            // -- Begin function audit_need_M1024_E49
	.balign 32
	.type	audit_need_M1024_E49,@function
audit_need_M1024_E49:                   // @audit_need_M1024_E49
// %bb.0:                               // %entry
	{
		r0 = ##33811840
		jumpr r31
	}
.Lfunc_end85:
	.size	audit_need_M1024_E49, .Lfunc_end85-audit_need_M1024_E49
                                        // -- End function
	.globl	audit_need_M1024_E50            // -- Begin function audit_need_M1024_E50
	.balign 32
	.type	audit_need_M1024_E50,@function
audit_need_M1024_E50:                   // @audit_need_M1024_E50
// %bb.0:                               // %entry
	{
		r0 = ##33941888
		jumpr r31
	}
.Lfunc_end86:
	.size	audit_need_M1024_E50, .Lfunc_end86-audit_need_M1024_E50
                                        // -- End function
	.globl	audit_need_M1024_E51            // -- Begin function audit_need_M1024_E51
	.balign 32
	.type	audit_need_M1024_E51,@function
audit_need_M1024_E51:                   // @audit_need_M1024_E51
// %bb.0:                               // %entry
	{
		r0 = ##34072064
		jumpr r31
	}
.Lfunc_end87:
	.size	audit_need_M1024_E51, .Lfunc_end87-audit_need_M1024_E51
                                        // -- End function
	.globl	audit_need_M1024_E52            // -- Begin function audit_need_M1024_E52
	.balign 32
	.type	audit_need_M1024_E52,@function
audit_need_M1024_E52:                   // @audit_need_M1024_E52
// %bb.0:                               // %entry
	{
		r0 = ##34201984
		jumpr r31
	}
.Lfunc_end88:
	.size	audit_need_M1024_E52, .Lfunc_end88-audit_need_M1024_E52
                                        // -- End function
	.globl	audit_need_M1024_E53            // -- Begin function audit_need_M1024_E53
	.balign 32
	.type	audit_need_M1024_E53,@function
audit_need_M1024_E53:                   // @audit_need_M1024_E53
// %bb.0:                               // %entry
	{
		r0 = ##34332032
		jumpr r31
	}
.Lfunc_end89:
	.size	audit_need_M1024_E53, .Lfunc_end89-audit_need_M1024_E53
                                        // -- End function
	.globl	audit_need_M1024_E54            // -- Begin function audit_need_M1024_E54
	.balign 32
	.type	audit_need_M1024_E54,@function
audit_need_M1024_E54:                   // @audit_need_M1024_E54
// %bb.0:                               // %entry
	{
		r0 = ##34462080
		jumpr r31
	}
.Lfunc_end90:
	.size	audit_need_M1024_E54, .Lfunc_end90-audit_need_M1024_E54
                                        // -- End function
	.globl	audit_need_M1024_E55            // -- Begin function audit_need_M1024_E55
	.balign 32
	.type	audit_need_M1024_E55,@function
audit_need_M1024_E55:                   // @audit_need_M1024_E55
// %bb.0:                               // %entry
	{
		r0 = ##34592256
		jumpr r31
	}
.Lfunc_end91:
	.size	audit_need_M1024_E55, .Lfunc_end91-audit_need_M1024_E55
                                        // -- End function
	.globl	audit_need_M1024_E56            // -- Begin function audit_need_M1024_E56
	.balign 32
	.type	audit_need_M1024_E56,@function
audit_need_M1024_E56:                   // @audit_need_M1024_E56
// %bb.0:                               // %entry
	{
		r0 = ##34722304
		jumpr r31
	}
.Lfunc_end92:
	.size	audit_need_M1024_E56, .Lfunc_end92-audit_need_M1024_E56
                                        // -- End function
	.globl	audit_need_M1024_E57            // -- Begin function audit_need_M1024_E57
	.balign 32
	.type	audit_need_M1024_E57,@function
audit_need_M1024_E57:                   // @audit_need_M1024_E57
// %bb.0:                               // %entry
	{
		r0 = ##34852352
		jumpr r31
	}
.Lfunc_end93:
	.size	audit_need_M1024_E57, .Lfunc_end93-audit_need_M1024_E57
                                        // -- End function
	.globl	audit_need_M1024_E58            // -- Begin function audit_need_M1024_E58
	.balign 32
	.type	audit_need_M1024_E58,@function
audit_need_M1024_E58:                   // @audit_need_M1024_E58
// %bb.0:                               // %entry
	{
		r0 = ##34982400
		jumpr r31
	}
.Lfunc_end94:
	.size	audit_need_M1024_E58, .Lfunc_end94-audit_need_M1024_E58
                                        // -- End function
	.globl	audit_need_M1024_E59            // -- Begin function audit_need_M1024_E59
	.balign 32
	.type	audit_need_M1024_E59,@function
audit_need_M1024_E59:                   // @audit_need_M1024_E59
// %bb.0:                               // %entry
	{
		r0 = ##35112576
		jumpr r31
	}
.Lfunc_end95:
	.size	audit_need_M1024_E59, .Lfunc_end95-audit_need_M1024_E59
                                        // -- End function
	.globl	audit_need_M1024_E60            // -- Begin function audit_need_M1024_E60
	.balign 32
	.type	audit_need_M1024_E60,@function
audit_need_M1024_E60:                   // @audit_need_M1024_E60
// %bb.0:                               // %entry
	{
		r0 = ##35242496
		jumpr r31
	}
.Lfunc_end96:
	.size	audit_need_M1024_E60, .Lfunc_end96-audit_need_M1024_E60
                                        // -- End function
	.globl	audit_need_M1024_E61            // -- Begin function audit_need_M1024_E61
	.balign 32
	.type	audit_need_M1024_E61,@function
audit_need_M1024_E61:                   // @audit_need_M1024_E61
// %bb.0:                               // %entry
	{
		r0 = ##35372544
		jumpr r31
	}
.Lfunc_end97:
	.size	audit_need_M1024_E61, .Lfunc_end97-audit_need_M1024_E61
                                        // -- End function
	.globl	audit_need_M1024_E62            // -- Begin function audit_need_M1024_E62
	.balign 32
	.type	audit_need_M1024_E62,@function
audit_need_M1024_E62:                   // @audit_need_M1024_E62
// %bb.0:                               // %entry
	{
		r0 = ##35502592
		jumpr r31
	}
.Lfunc_end98:
	.size	audit_need_M1024_E62, .Lfunc_end98-audit_need_M1024_E62
                                        // -- End function
	.globl	audit_need_M1024_E63            // -- Begin function audit_need_M1024_E63
	.balign 32
	.type	audit_need_M1024_E63,@function
audit_need_M1024_E63:                   // @audit_need_M1024_E63
// %bb.0:                               // %entry
	{
		r0 = ##35632768
		jumpr r31
	}
.Lfunc_end99:
	.size	audit_need_M1024_E63, .Lfunc_end99-audit_need_M1024_E63
                                        // -- End function
	.globl	audit_need_M1024_E64            // -- Begin function audit_need_M1024_E64
	.balign 32
	.type	audit_need_M1024_E64,@function
audit_need_M1024_E64:                   // @audit_need_M1024_E64
// %bb.0:                               // %entry
	{
		r0 = ##35762432
		jumpr r31
	}
.Lfunc_end100:
	.size	audit_need_M1024_E64, .Lfunc_end100-audit_need_M1024_E64
                                        // -- End function
	.globl	audit_need_M2048_E1             // -- Begin function audit_need_M2048_E1
	.balign 32
	.type	audit_need_M2048_E1,@function
audit_need_M2048_E1:                    // @audit_need_M2048_E1
// %bb.0:                               // %entry
	{
		r0 = ##54905472
		jumpr r31
	}
.Lfunc_end101:
	.size	audit_need_M2048_E1, .Lfunc_end101-audit_need_M2048_E1
                                        // -- End function
	.globl	audit_need_M2048_E2             // -- Begin function audit_need_M2048_E2
	.balign 32
	.type	audit_need_M2048_E2,@function
audit_need_M2048_E2:                    // @audit_need_M2048_E2
// %bb.0:                               // %entry
	{
		r0 = ##55035520
		jumpr r31
	}
.Lfunc_end102:
	.size	audit_need_M2048_E2, .Lfunc_end102-audit_need_M2048_E2
                                        // -- End function
	.globl	audit_need_M2048_E3             // -- Begin function audit_need_M2048_E3
	.balign 32
	.type	audit_need_M2048_E3,@function
audit_need_M2048_E3:                    // @audit_need_M2048_E3
// %bb.0:                               // %entry
	{
		r0 = ##55165696
		jumpr r31
	}
.Lfunc_end103:
	.size	audit_need_M2048_E3, .Lfunc_end103-audit_need_M2048_E3
                                        // -- End function
	.globl	audit_need_M2048_E4             // -- Begin function audit_need_M2048_E4
	.balign 32
	.type	audit_need_M2048_E4,@function
audit_need_M2048_E4:                    // @audit_need_M2048_E4
// %bb.0:                               // %entry
	{
		r0 = ##55295744
		jumpr r31
	}
.Lfunc_end104:
	.size	audit_need_M2048_E4, .Lfunc_end104-audit_need_M2048_E4
                                        // -- End function
	.globl	audit_need_M2048_E5             // -- Begin function audit_need_M2048_E5
	.balign 32
	.type	audit_need_M2048_E5,@function
audit_need_M2048_E5:                    // @audit_need_M2048_E5
// %bb.0:                               // %entry
	{
		r0 = ##55425792
		jumpr r31
	}
.Lfunc_end105:
	.size	audit_need_M2048_E5, .Lfunc_end105-audit_need_M2048_E5
                                        // -- End function
	.globl	audit_need_M2048_E6             // -- Begin function audit_need_M2048_E6
	.balign 32
	.type	audit_need_M2048_E6,@function
audit_need_M2048_E6:                    // @audit_need_M2048_E6
// %bb.0:                               // %entry
	{
		r0 = ##55555840
		jumpr r31
	}
.Lfunc_end106:
	.size	audit_need_M2048_E6, .Lfunc_end106-audit_need_M2048_E6
                                        // -- End function
	.globl	audit_need_M2048_E7             // -- Begin function audit_need_M2048_E7
	.balign 32
	.type	audit_need_M2048_E7,@function
audit_need_M2048_E7:                    // @audit_need_M2048_E7
// %bb.0:                               // %entry
	{
		r0 = ##55686016
		jumpr r31
	}
.Lfunc_end107:
	.size	audit_need_M2048_E7, .Lfunc_end107-audit_need_M2048_E7
                                        // -- End function
	.globl	audit_need_M2048_E8             // -- Begin function audit_need_M2048_E8
	.balign 32
	.type	audit_need_M2048_E8,@function
audit_need_M2048_E8:                    // @audit_need_M2048_E8
// %bb.0:                               // %entry
	{
		r0 = ##55816064
		jumpr r31
	}
.Lfunc_end108:
	.size	audit_need_M2048_E8, .Lfunc_end108-audit_need_M2048_E8
                                        // -- End function
	.globl	audit_need_M2048_E9             // -- Begin function audit_need_M2048_E9
	.balign 32
	.type	audit_need_M2048_E9,@function
audit_need_M2048_E9:                    // @audit_need_M2048_E9
// %bb.0:                               // %entry
	{
		r0 = ##55945984
		jumpr r31
	}
.Lfunc_end109:
	.size	audit_need_M2048_E9, .Lfunc_end109-audit_need_M2048_E9
                                        // -- End function
	.globl	audit_need_M2048_E10            // -- Begin function audit_need_M2048_E10
	.balign 32
	.type	audit_need_M2048_E10,@function
audit_need_M2048_E10:                   // @audit_need_M2048_E10
// %bb.0:                               // %entry
	{
		r0 = ##56076032
		jumpr r31
	}
.Lfunc_end110:
	.size	audit_need_M2048_E10, .Lfunc_end110-audit_need_M2048_E10
                                        // -- End function
	.globl	audit_need_M2048_E11            // -- Begin function audit_need_M2048_E11
	.balign 32
	.type	audit_need_M2048_E11,@function
audit_need_M2048_E11:                   // @audit_need_M2048_E11
// %bb.0:                               // %entry
	{
		r0 = ##56206208
		jumpr r31
	}
.Lfunc_end111:
	.size	audit_need_M2048_E11, .Lfunc_end111-audit_need_M2048_E11
                                        // -- End function
	.globl	audit_need_M2048_E12            // -- Begin function audit_need_M2048_E12
	.balign 32
	.type	audit_need_M2048_E12,@function
audit_need_M2048_E12:                   // @audit_need_M2048_E12
// %bb.0:                               // %entry
	{
		r0 = ##56336256
		jumpr r31
	}
.Lfunc_end112:
	.size	audit_need_M2048_E12, .Lfunc_end112-audit_need_M2048_E12
                                        // -- End function
	.globl	audit_need_M2048_E13            // -- Begin function audit_need_M2048_E13
	.balign 32
	.type	audit_need_M2048_E13,@function
audit_need_M2048_E13:                   // @audit_need_M2048_E13
// %bb.0:                               // %entry
	{
		r0 = ##56466304
		jumpr r31
	}
.Lfunc_end113:
	.size	audit_need_M2048_E13, .Lfunc_end113-audit_need_M2048_E13
                                        // -- End function
	.globl	audit_need_M2048_E14            // -- Begin function audit_need_M2048_E14
	.balign 32
	.type	audit_need_M2048_E14,@function
audit_need_M2048_E14:                   // @audit_need_M2048_E14
// %bb.0:                               // %entry
	{
		r0 = ##56596352
		jumpr r31
	}
.Lfunc_end114:
	.size	audit_need_M2048_E14, .Lfunc_end114-audit_need_M2048_E14
                                        // -- End function
	.globl	audit_need_M2048_E15            // -- Begin function audit_need_M2048_E15
	.balign 32
	.type	audit_need_M2048_E15,@function
audit_need_M2048_E15:                   // @audit_need_M2048_E15
// %bb.0:                               // %entry
	{
		r0 = ##56726528
		jumpr r31
	}
.Lfunc_end115:
	.size	audit_need_M2048_E15, .Lfunc_end115-audit_need_M2048_E15
                                        // -- End function
	.globl	audit_need_M2048_E16            // -- Begin function audit_need_M2048_E16
	.balign 32
	.type	audit_need_M2048_E16,@function
audit_need_M2048_E16:                   // @audit_need_M2048_E16
// %bb.0:                               // %entry
	{
		r0 = ##56856576
		jumpr r31
	}
.Lfunc_end116:
	.size	audit_need_M2048_E16, .Lfunc_end116-audit_need_M2048_E16
                                        // -- End function
	.globl	audit_need_M2048_E17            // -- Begin function audit_need_M2048_E17
	.balign 32
	.type	audit_need_M2048_E17,@function
audit_need_M2048_E17:                   // @audit_need_M2048_E17
// %bb.0:                               // %entry
	{
		r0 = ##56986624
		jumpr r31
	}
.Lfunc_end117:
	.size	audit_need_M2048_E17, .Lfunc_end117-audit_need_M2048_E17
                                        // -- End function
	.globl	audit_need_M2048_E18            // -- Begin function audit_need_M2048_E18
	.balign 32
	.type	audit_need_M2048_E18,@function
audit_need_M2048_E18:                   // @audit_need_M2048_E18
// %bb.0:                               // %entry
	{
		r0 = ##57116544
		jumpr r31
	}
.Lfunc_end118:
	.size	audit_need_M2048_E18, .Lfunc_end118-audit_need_M2048_E18
                                        // -- End function
	.globl	audit_need_M2048_E19            // -- Begin function audit_need_M2048_E19
	.balign 32
	.type	audit_need_M2048_E19,@function
audit_need_M2048_E19:                   // @audit_need_M2048_E19
// %bb.0:                               // %entry
	{
		r0 = ##57246720
		jumpr r31
	}
.Lfunc_end119:
	.size	audit_need_M2048_E19, .Lfunc_end119-audit_need_M2048_E19
                                        // -- End function
	.globl	audit_need_M2048_E20            // -- Begin function audit_need_M2048_E20
	.balign 32
	.type	audit_need_M2048_E20,@function
audit_need_M2048_E20:                   // @audit_need_M2048_E20
// %bb.0:                               // %entry
	{
		r0 = ##57376768
		jumpr r31
	}
.Lfunc_end120:
	.size	audit_need_M2048_E20, .Lfunc_end120-audit_need_M2048_E20
                                        // -- End function
	.globl	audit_need_M2048_E21            // -- Begin function audit_need_M2048_E21
	.balign 32
	.type	audit_need_M2048_E21,@function
audit_need_M2048_E21:                   // @audit_need_M2048_E21
// %bb.0:                               // %entry
	{
		r0 = ##57506816
		jumpr r31
	}
.Lfunc_end121:
	.size	audit_need_M2048_E21, .Lfunc_end121-audit_need_M2048_E21
                                        // -- End function
	.globl	audit_need_M2048_E22            // -- Begin function audit_need_M2048_E22
	.balign 32
	.type	audit_need_M2048_E22,@function
audit_need_M2048_E22:                   // @audit_need_M2048_E22
// %bb.0:                               // %entry
	{
		r0 = ##57636864
		jumpr r31
	}
.Lfunc_end122:
	.size	audit_need_M2048_E22, .Lfunc_end122-audit_need_M2048_E22
                                        // -- End function
	.globl	audit_need_M2048_E23            // -- Begin function audit_need_M2048_E23
	.balign 32
	.type	audit_need_M2048_E23,@function
audit_need_M2048_E23:                   // @audit_need_M2048_E23
// %bb.0:                               // %entry
	{
		r0 = ##57767040
		jumpr r31
	}
.Lfunc_end123:
	.size	audit_need_M2048_E23, .Lfunc_end123-audit_need_M2048_E23
                                        // -- End function
	.globl	audit_need_M2048_E24            // -- Begin function audit_need_M2048_E24
	.balign 32
	.type	audit_need_M2048_E24,@function
audit_need_M2048_E24:                   // @audit_need_M2048_E24
// %bb.0:                               // %entry
	{
		r0 = ##57897088
		jumpr r31
	}
.Lfunc_end124:
	.size	audit_need_M2048_E24, .Lfunc_end124-audit_need_M2048_E24
                                        // -- End function
	.globl	audit_need_M2048_E25            // -- Begin function audit_need_M2048_E25
	.balign 32
	.type	audit_need_M2048_E25,@function
audit_need_M2048_E25:                   // @audit_need_M2048_E25
// %bb.0:                               // %entry
	{
		r0 = ##58027136
		jumpr r31
	}
.Lfunc_end125:
	.size	audit_need_M2048_E25, .Lfunc_end125-audit_need_M2048_E25
                                        // -- End function
	.globl	audit_need_M2048_E26            // -- Begin function audit_need_M2048_E26
	.balign 32
	.type	audit_need_M2048_E26,@function
audit_need_M2048_E26:                   // @audit_need_M2048_E26
// %bb.0:                               // %entry
	{
		r0 = ##58157056
		jumpr r31
	}
.Lfunc_end126:
	.size	audit_need_M2048_E26, .Lfunc_end126-audit_need_M2048_E26
                                        // -- End function
	.globl	audit_need_M2048_E27            // -- Begin function audit_need_M2048_E27
	.balign 32
	.type	audit_need_M2048_E27,@function
audit_need_M2048_E27:                   // @audit_need_M2048_E27
// %bb.0:                               // %entry
	{
		r0 = ##58287232
		jumpr r31
	}
.Lfunc_end127:
	.size	audit_need_M2048_E27, .Lfunc_end127-audit_need_M2048_E27
                                        // -- End function
	.globl	audit_need_M2048_E28            // -- Begin function audit_need_M2048_E28
	.balign 32
	.type	audit_need_M2048_E28,@function
audit_need_M2048_E28:                   // @audit_need_M2048_E28
// %bb.0:                               // %entry
	{
		r0 = ##58417280
		jumpr r31
	}
.Lfunc_end128:
	.size	audit_need_M2048_E28, .Lfunc_end128-audit_need_M2048_E28
                                        // -- End function
	.globl	audit_need_M2048_E29            // -- Begin function audit_need_M2048_E29
	.balign 32
	.type	audit_need_M2048_E29,@function
audit_need_M2048_E29:                   // @audit_need_M2048_E29
// %bb.0:                               // %entry
	{
		r0 = ##58547328
		jumpr r31
	}
.Lfunc_end129:
	.size	audit_need_M2048_E29, .Lfunc_end129-audit_need_M2048_E29
                                        // -- End function
	.globl	audit_need_M2048_E30            // -- Begin function audit_need_M2048_E30
	.balign 32
	.type	audit_need_M2048_E30,@function
audit_need_M2048_E30:                   // @audit_need_M2048_E30
// %bb.0:                               // %entry
	{
		r0 = ##58677376
		jumpr r31
	}
.Lfunc_end130:
	.size	audit_need_M2048_E30, .Lfunc_end130-audit_need_M2048_E30
                                        // -- End function
	.globl	audit_need_M2048_E31            // -- Begin function audit_need_M2048_E31
	.balign 32
	.type	audit_need_M2048_E31,@function
audit_need_M2048_E31:                   // @audit_need_M2048_E31
// %bb.0:                               // %entry
	{
		r0 = ##58807552
		jumpr r31
	}
.Lfunc_end131:
	.size	audit_need_M2048_E31, .Lfunc_end131-audit_need_M2048_E31
                                        // -- End function
	.globl	audit_need_M2048_E32            // -- Begin function audit_need_M2048_E32
	.balign 32
	.type	audit_need_M2048_E32,@function
audit_need_M2048_E32:                   // @audit_need_M2048_E32
// %bb.0:                               // %entry
	{
		r0 = ##58937216
		jumpr r31
	}
.Lfunc_end132:
	.size	audit_need_M2048_E32, .Lfunc_end132-audit_need_M2048_E32
                                        // -- End function
	.globl	audit_need_M2048_E33            // -- Begin function audit_need_M2048_E33
	.balign 32
	.type	audit_need_M2048_E33,@function
audit_need_M2048_E33:                   // @audit_need_M2048_E33
// %bb.0:                               // %entry
	{
		r0 = ##59068032
		jumpr r31
	}
.Lfunc_end133:
	.size	audit_need_M2048_E33, .Lfunc_end133-audit_need_M2048_E33
                                        // -- End function
	.globl	audit_need_M2048_E34            // -- Begin function audit_need_M2048_E34
	.balign 32
	.type	audit_need_M2048_E34,@function
audit_need_M2048_E34:                   // @audit_need_M2048_E34
// %bb.0:                               // %entry
	{
		r0 = ##59198080
		jumpr r31
	}
.Lfunc_end134:
	.size	audit_need_M2048_E34, .Lfunc_end134-audit_need_M2048_E34
                                        // -- End function
	.globl	audit_need_M2048_E35            // -- Begin function audit_need_M2048_E35
	.balign 32
	.type	audit_need_M2048_E35,@function
audit_need_M2048_E35:                   // @audit_need_M2048_E35
// %bb.0:                               // %entry
	{
		r0 = ##59328128
		jumpr r31
	}
.Lfunc_end135:
	.size	audit_need_M2048_E35, .Lfunc_end135-audit_need_M2048_E35
                                        // -- End function
	.globl	audit_need_M2048_E36            // -- Begin function audit_need_M2048_E36
	.balign 32
	.type	audit_need_M2048_E36,@function
audit_need_M2048_E36:                   // @audit_need_M2048_E36
// %bb.0:                               // %entry
	{
		r0 = ##59458176
		jumpr r31
	}
.Lfunc_end136:
	.size	audit_need_M2048_E36, .Lfunc_end136-audit_need_M2048_E36
                                        // -- End function
	.globl	audit_need_M2048_E37            // -- Begin function audit_need_M2048_E37
	.balign 32
	.type	audit_need_M2048_E37,@function
audit_need_M2048_E37:                   // @audit_need_M2048_E37
// %bb.0:                               // %entry
	{
		r0 = ##59588224
		jumpr r31
	}
.Lfunc_end137:
	.size	audit_need_M2048_E37, .Lfunc_end137-audit_need_M2048_E37
                                        // -- End function
	.globl	audit_need_M2048_E38            // -- Begin function audit_need_M2048_E38
	.balign 32
	.type	audit_need_M2048_E38,@function
audit_need_M2048_E38:                   // @audit_need_M2048_E38
// %bb.0:                               // %entry
	{
		r0 = ##59718272
		jumpr r31
	}
.Lfunc_end138:
	.size	audit_need_M2048_E38, .Lfunc_end138-audit_need_M2048_E38
                                        // -- End function
	.globl	audit_need_M2048_E39            // -- Begin function audit_need_M2048_E39
	.balign 32
	.type	audit_need_M2048_E39,@function
audit_need_M2048_E39:                   // @audit_need_M2048_E39
// %bb.0:                               // %entry
	{
		r0 = ##59848448
		jumpr r31
	}
.Lfunc_end139:
	.size	audit_need_M2048_E39, .Lfunc_end139-audit_need_M2048_E39
                                        // -- End function
	.globl	audit_need_M2048_E40            // -- Begin function audit_need_M2048_E40
	.balign 32
	.type	audit_need_M2048_E40,@function
audit_need_M2048_E40:                   // @audit_need_M2048_E40
// %bb.0:                               // %entry
	{
		r0 = ##59978496
		jumpr r31
	}
.Lfunc_end140:
	.size	audit_need_M2048_E40, .Lfunc_end140-audit_need_M2048_E40
                                        // -- End function
	.globl	audit_need_M2048_E41            // -- Begin function audit_need_M2048_E41
	.balign 32
	.type	audit_need_M2048_E41,@function
audit_need_M2048_E41:                   // @audit_need_M2048_E41
// %bb.0:                               // %entry
	{
		r0 = ##60108544
		jumpr r31
	}
.Lfunc_end141:
	.size	audit_need_M2048_E41, .Lfunc_end141-audit_need_M2048_E41
                                        // -- End function
	.globl	audit_need_M2048_E42            // -- Begin function audit_need_M2048_E42
	.balign 32
	.type	audit_need_M2048_E42,@function
audit_need_M2048_E42:                   // @audit_need_M2048_E42
// %bb.0:                               // %entry
	{
		r0 = ##60238592
		jumpr r31
	}
.Lfunc_end142:
	.size	audit_need_M2048_E42, .Lfunc_end142-audit_need_M2048_E42
                                        // -- End function
	.globl	audit_need_M2048_E43            // -- Begin function audit_need_M2048_E43
	.balign 32
	.type	audit_need_M2048_E43,@function
audit_need_M2048_E43:                   // @audit_need_M2048_E43
// %bb.0:                               // %entry
	{
		r0 = ##60368640
		jumpr r31
	}
.Lfunc_end143:
	.size	audit_need_M2048_E43, .Lfunc_end143-audit_need_M2048_E43
                                        // -- End function
	.globl	audit_need_M2048_E44            // -- Begin function audit_need_M2048_E44
	.balign 32
	.type	audit_need_M2048_E44,@function
audit_need_M2048_E44:                   // @audit_need_M2048_E44
// %bb.0:                               // %entry
	{
		r0 = ##60498688
		jumpr r31
	}
.Lfunc_end144:
	.size	audit_need_M2048_E44, .Lfunc_end144-audit_need_M2048_E44
                                        // -- End function
	.globl	audit_need_M2048_E45            // -- Begin function audit_need_M2048_E45
	.balign 32
	.type	audit_need_M2048_E45,@function
audit_need_M2048_E45:                   // @audit_need_M2048_E45
// %bb.0:                               // %entry
	{
		r0 = ##60628736
		jumpr r31
	}
.Lfunc_end145:
	.size	audit_need_M2048_E45, .Lfunc_end145-audit_need_M2048_E45
                                        // -- End function
	.globl	audit_need_M2048_E46            // -- Begin function audit_need_M2048_E46
	.balign 32
	.type	audit_need_M2048_E46,@function
audit_need_M2048_E46:                   // @audit_need_M2048_E46
// %bb.0:                               // %entry
	{
		r0 = ##60758784
		jumpr r31
	}
.Lfunc_end146:
	.size	audit_need_M2048_E46, .Lfunc_end146-audit_need_M2048_E46
                                        // -- End function
	.globl	audit_need_M2048_E47            // -- Begin function audit_need_M2048_E47
	.balign 32
	.type	audit_need_M2048_E47,@function
audit_need_M2048_E47:                   // @audit_need_M2048_E47
// %bb.0:                               // %entry
	{
		r0 = ##60888960
		jumpr r31
	}
.Lfunc_end147:
	.size	audit_need_M2048_E47, .Lfunc_end147-audit_need_M2048_E47
                                        // -- End function
	.globl	audit_need_M2048_E48            // -- Begin function audit_need_M2048_E48
	.balign 32
	.type	audit_need_M2048_E48,@function
audit_need_M2048_E48:                   // @audit_need_M2048_E48
// %bb.0:                               // %entry
	{
		r0 = ##61019008
		jumpr r31
	}
.Lfunc_end148:
	.size	audit_need_M2048_E48, .Lfunc_end148-audit_need_M2048_E48
                                        // -- End function
	.globl	audit_need_M2048_E49            // -- Begin function audit_need_M2048_E49
	.balign 32
	.type	audit_need_M2048_E49,@function
audit_need_M2048_E49:                   // @audit_need_M2048_E49
// %bb.0:                               // %entry
	{
		r0 = ##61149056
		jumpr r31
	}
.Lfunc_end149:
	.size	audit_need_M2048_E49, .Lfunc_end149-audit_need_M2048_E49
                                        // -- End function
	.globl	audit_need_M2048_E50            // -- Begin function audit_need_M2048_E50
	.balign 32
	.type	audit_need_M2048_E50,@function
audit_need_M2048_E50:                   // @audit_need_M2048_E50
// %bb.0:                               // %entry
	{
		r0 = ##61279104
		jumpr r31
	}
.Lfunc_end150:
	.size	audit_need_M2048_E50, .Lfunc_end150-audit_need_M2048_E50
                                        // -- End function
	.globl	audit_need_M2048_E51            // -- Begin function audit_need_M2048_E51
	.balign 32
	.type	audit_need_M2048_E51,@function
audit_need_M2048_E51:                   // @audit_need_M2048_E51
// %bb.0:                               // %entry
	{
		r0 = ##61409280
		jumpr r31
	}
.Lfunc_end151:
	.size	audit_need_M2048_E51, .Lfunc_end151-audit_need_M2048_E51
                                        // -- End function
	.globl	audit_need_M2048_E52            // -- Begin function audit_need_M2048_E52
	.balign 32
	.type	audit_need_M2048_E52,@function
audit_need_M2048_E52:                   // @audit_need_M2048_E52
// %bb.0:                               // %entry
	{
		r0 = ##61539200
		jumpr r31
	}
.Lfunc_end152:
	.size	audit_need_M2048_E52, .Lfunc_end152-audit_need_M2048_E52
                                        // -- End function
	.globl	audit_need_M2048_E53            // -- Begin function audit_need_M2048_E53
	.balign 32
	.type	audit_need_M2048_E53,@function
audit_need_M2048_E53:                   // @audit_need_M2048_E53
// %bb.0:                               // %entry
	{
		r0 = ##61669248
		jumpr r31
	}
.Lfunc_end153:
	.size	audit_need_M2048_E53, .Lfunc_end153-audit_need_M2048_E53
                                        // -- End function
	.globl	audit_need_M2048_E54            // -- Begin function audit_need_M2048_E54
	.balign 32
	.type	audit_need_M2048_E54,@function
audit_need_M2048_E54:                   // @audit_need_M2048_E54
// %bb.0:                               // %entry
	{
		r0 = ##61799296
		jumpr r31
	}
.Lfunc_end154:
	.size	audit_need_M2048_E54, .Lfunc_end154-audit_need_M2048_E54
                                        // -- End function
	.globl	audit_need_M2048_E55            // -- Begin function audit_need_M2048_E55
	.balign 32
	.type	audit_need_M2048_E55,@function
audit_need_M2048_E55:                   // @audit_need_M2048_E55
// %bb.0:                               // %entry
	{
		r0 = ##61929472
		jumpr r31
	}
.Lfunc_end155:
	.size	audit_need_M2048_E55, .Lfunc_end155-audit_need_M2048_E55
                                        // -- End function
	.globl	audit_need_M2048_E56            // -- Begin function audit_need_M2048_E56
	.balign 32
	.type	audit_need_M2048_E56,@function
audit_need_M2048_E56:                   // @audit_need_M2048_E56
// %bb.0:                               // %entry
	{
		r0 = ##62059520
		jumpr r31
	}
.Lfunc_end156:
	.size	audit_need_M2048_E56, .Lfunc_end156-audit_need_M2048_E56
                                        // -- End function
	.globl	audit_need_M2048_E57            // -- Begin function audit_need_M2048_E57
	.balign 32
	.type	audit_need_M2048_E57,@function
audit_need_M2048_E57:                   // @audit_need_M2048_E57
// %bb.0:                               // %entry
	{
		r0 = ##62189568
		jumpr r31
	}
.Lfunc_end157:
	.size	audit_need_M2048_E57, .Lfunc_end157-audit_need_M2048_E57
                                        // -- End function
	.globl	audit_need_M2048_E58            // -- Begin function audit_need_M2048_E58
	.balign 32
	.type	audit_need_M2048_E58,@function
audit_need_M2048_E58:                   // @audit_need_M2048_E58
// %bb.0:                               // %entry
	{
		r0 = ##62319616
		jumpr r31
	}
.Lfunc_end158:
	.size	audit_need_M2048_E58, .Lfunc_end158-audit_need_M2048_E58
                                        // -- End function
	.globl	audit_need_M2048_E59            // -- Begin function audit_need_M2048_E59
	.balign 32
	.type	audit_need_M2048_E59,@function
audit_need_M2048_E59:                   // @audit_need_M2048_E59
// %bb.0:                               // %entry
	{
		r0 = ##62449792
		jumpr r31
	}
.Lfunc_end159:
	.size	audit_need_M2048_E59, .Lfunc_end159-audit_need_M2048_E59
                                        // -- End function
	.globl	audit_need_M2048_E60            // -- Begin function audit_need_M2048_E60
	.balign 32
	.type	audit_need_M2048_E60,@function
audit_need_M2048_E60:                   // @audit_need_M2048_E60
// %bb.0:                               // %entry
	{
		r0 = ##62579712
		jumpr r31
	}
.Lfunc_end160:
	.size	audit_need_M2048_E60, .Lfunc_end160-audit_need_M2048_E60
                                        // -- End function
	.globl	audit_need_M2048_E61            // -- Begin function audit_need_M2048_E61
	.balign 32
	.type	audit_need_M2048_E61,@function
audit_need_M2048_E61:                   // @audit_need_M2048_E61
// %bb.0:                               // %entry
	{
		r0 = ##62709760
		jumpr r31
	}
.Lfunc_end161:
	.size	audit_need_M2048_E61, .Lfunc_end161-audit_need_M2048_E61
                                        // -- End function
	.globl	audit_need_M2048_E62            // -- Begin function audit_need_M2048_E62
	.balign 32
	.type	audit_need_M2048_E62,@function
audit_need_M2048_E62:                   // @audit_need_M2048_E62
// %bb.0:                               // %entry
	{
		r0 = ##62839808
		jumpr r31
	}
.Lfunc_end162:
	.size	audit_need_M2048_E62, .Lfunc_end162-audit_need_M2048_E62
                                        // -- End function
	.globl	audit_need_M2048_E63            // -- Begin function audit_need_M2048_E63
	.balign 32
	.type	audit_need_M2048_E63,@function
audit_need_M2048_E63:                   // @audit_need_M2048_E63
// %bb.0:                               // %entry
	{
		r0 = ##62969984
		jumpr r31
	}
.Lfunc_end163:
	.size	audit_need_M2048_E63, .Lfunc_end163-audit_need_M2048_E63
                                        // -- End function
	.globl	audit_need_M2048_E64            // -- Begin function audit_need_M2048_E64
	.balign 32
	.type	audit_need_M2048_E64,@function
audit_need_M2048_E64:                   // @audit_need_M2048_E64
// %bb.0:                               // %entry
	{
		r0 = ##63099648
		jumpr r31
	}
.Lfunc_end164:
	.size	audit_need_M2048_E64, .Lfunc_end164-audit_need_M2048_E64
                                        // -- End function
	.globl	audit_warmup_M1024_E64          // -- Begin function audit_warmup_M1024_E64
	.balign 32
	.type	audit_warmup_M1024_E64,@function
audit_warmup_M1024_E64:                 // @audit_warmup_M1024_E64
// %bb.0:                               // %entry
	{
		r0 = ##35762432
		jumpr r31
	}
.Lfunc_end165:
	.size	audit_warmup_M1024_E64, .Lfunc_end165-audit_warmup_M1024_E64
                                        // -- End function
	.globl	audit_warmup_M2048_E64          // -- Begin function audit_warmup_M2048_E64
	.balign 32
	.type	audit_warmup_M2048_E64,@function
audit_warmup_M2048_E64:                 // @audit_warmup_M2048_E64
// %bb.0:                               // %entry
	{
		r0 = ##54661376
		jumpr r31
	}
.Lfunc_end166:
	.size	audit_warmup_M2048_E64, .Lfunc_end166-audit_warmup_M2048_E64
                                        // -- End function
	.falign
	.type	moe_expand_unit,@function       // -- Begin function moe_expand_unit
moe_expand_unit:                        // @moe_expand_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2816):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r1 = memw(r2+#152)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r1,#0)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r1 = add(r18,#0)
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB167_25
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r20 = memw(r16+#184)
		r19 = memw(r16+#176)
	}
	{
		r0 = mpyi(r20,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r20,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.3:                               // %if.then
	{
		p1 = cmp.eq(r17,r0); if (p1.new) jump:t .LBB167_32
		r3 = #0
		r18 = r0
	}
// %bb.4:                               // %if.end
	{
		r2 = memw(r16+#172)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB167_32
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r26 = #0
		r25:24 = combine(#2,#96)
	}
	.falign
.LBB167_6:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB167_11 Depth 2
                                        //       Child Loop BB167_17 Depth 3
                                        //       Child Loop BB167_21 Depth 3
	{
		r1:0 = memd(r16+#160)
	}
	{
		r1:0 &= asl(r7:6,r26)
	}
	{
		p1 = cmp.eq(r1:0,r9:8)
		if (!p1.new) r27 = add(r3,r19)
		if (p1.new) jump:nt .LBB167_22
	}
// %bb.7:                               // %if.end8
                                        //   in Loop: Header=BB167_6 Depth=1
	{
		p0 = cmp.gtu(r18,r3); if (!p0.new) jump:nt .LBB167_24
	}
// %bb.8:                               // %if.end8
                                        //   in Loop: Header=BB167_6 Depth=1
	{
		r4 = maxu(r17,r3)
		p1 = cmp.gtu(r27,r17)
		if (!p1.new) jump:nt .LBB167_24
	}
// %bb.9:                               // %if.end13
                                        //   in Loop: Header=BB167_6 Depth=1
	{
		r22 = asl(r26,#11)
		p0 = cmp.gtu(r27,r18)
		if (p0.new) r20 = sub(r18,r3)
		if (!p0.new) r20 = add(r19,#0)
	}
	{
		r21 = sub(r4,r3)
		if (!cmp.gtu(r20,r21.new)) jump:t .LBB167_24
	}
	.falign
.LBB167_11:                             // %for.body24
                                        //   Parent Loop BB167_6 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB167_17 Depth 3
                                        //       Child Loop BB167_21 Depth 3
	{
		r5 = r22
		r3 = memw(r16+#12)
		r7:6 = memd(r16+#152)
	}
	{
		p0 = cmp.eq(r7,#0)
		r2 = memw(r16+#168)
	}
	{
		r4 = mpyi(r21,r3)
		r2 -= mpyi(r21,#96)
	}
	{
		r1 = minu(r2,r24)
		r4 = +mpyi(r4,#3)
		if (!p0) r2 = memw(r16+#180)
	}
	{
		r5 += add(r6,r4)
		if (p0) jump:nt .LBB167_15
	}
// %bb.12:                              // %if.then33
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		r7 += mpyi(r2,r26)
	}
	{
		r7 += mpyi(r21,##2560)
	}
	.falign
.LBB167_13:                             // %if.end77
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		call hvx_tl2_expand_wh96
		r0 = r7
		r2 = #128
		r4 = memw(r16+#188)
	}
	.falign
// %bb.14:                              // %if.end77
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB167_11
	}
	{
		jump .LBB167_23
	}
	.falign
.LBB167_15:                             // %if.else
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB167_13
		r7 = add(r29,#128)
		r6 = r5
	}
// %bb.16:                              //   in Loop: Header=BB167_11 Depth=2
	{
		r4 = add(##989,mpyi(r1,#43))
	}
	{
		r4 = lsr(r4,#10)
	}
	{
		r8 = minu(r4,r25)
	}
	{
		r8 = +mpyi(r8,#5)
	}
	{
		loop0(.LBB167_17,r8)
	}
	.falign
.LBB167_17:                             // Block address taken
                                        // %for.body55
                                        //   Parent Loop BB167_6 Depth=1
                                        //     Parent Loop BB167_11 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0.cur = vmem(r6++#1)
		vmem(r7++#1) = v0
	} :endloop0
// %bb.18:                              // %for.cond.cleanup54
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		p0 = cmp.gtu(r2,#48)
		r7 = add(r29,#128)
		if (!p0.new) jump:t .LBB167_13
	}
// %bb.19:                              // %for.cond61.preheader
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		r4 = add(##-10,mpyi(r4,#5))
	}
	{
		if (!p1.new) r2 = add(r5,r3)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB167_13
	}
// %bb.20:                              // %for.body66.lr.ph
                                        //   in Loop: Header=BB167_11 Depth=2
	{
		loop0(.LBB167_21,r4)
		r6 = add(r29,#128)
	}
	{
		r4 = add(r6,#1280)
	}
	.falign
.LBB167_21:                             // Block address taken
                                        // %for.body66
                                        //   Parent Loop BB167_6 Depth=1
                                        //     Parent Loop BB167_11 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r29,#128)
		v1.cur = vmem(r2++#1)
		vmem(r4++#1) = v1
	} :endloop0
	{
		jump .LBB167_13
	}
	.falign
.LBB167_22:                             //   in Loop: Header=BB167_6 Depth=1
	{
		r27 = r3
		jump .LBB167_24
	}
	.falign
.LBB167_23:                             // %for.inc87.loopexit
                                        //   in Loop: Header=BB167_6 Depth=1
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r2 = memw(r16+#172)
	}
	.falign
.LBB167_24:                             // %for.inc87
                                        //   in Loop: Header=BB167_6 Depth=1
	{
		r3 = r27
		r26 = add(r26,#1)
		if (cmp.gtu(r2,r26.new)) jump:t .LBB167_6
	}
	{
		jump .LBB167_32
	}
	.falign
.LBB167_25:                             // %if.end96
	{
		r1 = r18
		r2 = memw(r16+#8)
		r3 = memw(r16+#20)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		r0 = mpyi(r19,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.26:                              // %if.end96
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r19,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.27:                              // %if.end96
	{
		r19 = add(r16,#24)
		r18 = r0
		p0 = cmp.gtu(r0,r17); if (!p0.new) jump:t .LBB167_32
	}
	.falign
.LBB167_29:                             // %for.body105
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.30:                              // %for.body105
                                        //   in Loop: Header=BB167_29 Depth=1
	{
		r2 = r17
		r4 = memw(r16+#12)
		r3 = memw(r16+r0<<#2)
	}
	{
		r2 -= mpyi(r0,r20)
		r1 = memw(r16+#16)
	}
	{
		r3 += mpyi(r4,r2)
		r2 = r19
	}
	{
		call hvx_expand_i2i4
		r0 = add(r3,r1)
	}
	.falign
// %bb.31:                              // %for.body105
                                        //   in Loop: Header=BB167_29 Depth=1
	{
		r17 = add(r17,#1)
		if (cmp.gtu(r18,r17.new)) jump:t .LBB167_29
	}
	.falign
.LBB167_32:                             // %cleanup120
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end167:
	.size	moe_expand_unit, .Lfunc_end167-moe_expand_unit
                                        // -- End function
	.falign
	.type	moe_m1_q_worker,@function       // -- Begin function moe_m1_q_worker
moe_m1_q_worker:                        // @moe_m1_q_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#72)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#56) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r18 = minu(r2,r0)
		r20 = #0
		memd(r29+#48) = r21:20
		memd(r29+#40) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r18,r1); if (!p1.new) jump:t .LBB168_10
		memd(r29+#32) = r25:24
		memd(r29+#24) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %for.cond.preheader
	{
		r24 = memw(r16+#40)
		memw(r29+#20) = r0
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r24,#0)
		if (p0.new) jump:nt .LBB168_9
		if (!p0.new) r19 = #0
		memw(r29+#16) = r16
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %for.body.lr.ph
	{
		r21 = add(pc,##g_m1q_desc@PCREL)
		r25 = add(r17,#1)
		r27:26 = combine(#0,r16)
	}
	{
		r21 += asl(r17,#8)
	}
	.falign
.LBB168_3:                              // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r3:2 = combine(r19,r18)
		r16 = memw(r26+#12)
	}
	{
		r1:0 = mpyu(r16,r17)
		call __hexagon_udivdi3
	}
	.falign
// %bb.4:                               // %for.body
                                        //   in Loop: Header=BB168_3 Depth=1
	{
		r1:0 = mpyu(r16,r25)
		call __hexagon_udivdi3
		r23:22 = combine(r1,r0)
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB168_3 Depth=1
	{
		if (p0.new) r0 = sub(r0,r22)
		p0 = cmp.gtu(r0,r22); if (!p0.new) jump:t .LBB168_8
		if (p0.new) r4 = memw(r26+#8)
	}
// %bb.6:                               // %if.then6
                                        //   in Loop: Header=BB168_3 Depth=1
	{
		r5 = r4
		r2 = memw(r26+#0)
		r6 = memw(r26+#16)
	}
	{
		r3 = memw(r26+#4)
	}
	{
		r6 = mpyi(r4,r22)
		r1:0 = combine(r20,r21)
		memw(r29+#8) = r6
		memw(r29+#4) = r0
	}
	{
		r2 = add(r2,r6)
		r3 = add(r3,r6)
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	{
		call hexkl_dma_lane_push2d
	}
	.falign
// %bb.7:                               // %if.then6
                                        //   in Loop: Header=BB168_3 Depth=1
	{
		r20 = r21
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r2+#40)
	}
	.falign
.LBB168_8:                              // %if.end
                                        //   in Loop: Header=BB168_3 Depth=1
	{
		r26 = add(r26,#20)
		r21 = add(r21,#128)
		r27 = add(r27,#1)
		if (cmp.gtu(r24,r27.new)) jump:t .LBB168_3
	}
	.falign
.LBB168_9:                              // %for.cond.cleanup
	{
		p1 = cmp.eq(r17,#0)
		if (p1.new) r16 = memw(r29+#16)
		if (p1.new) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r16 = memw(r29+#16)
		if (p1) memw(r16+#48) = r18
	}                                       // 4-byte Folded Reload
	.falign
.LBB168_10:                             // %if.end18
	{
		r3 = memw(r16+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB168_12
	}
// %bb.11:                              // %if.then20
	{
		callr r3
		r1 = r17
		r2 = memw(r16+#60)
	}
	.falign
.LBB168_12:                             // %if.end22
	{
		if (!p0.new) r0 = add(r20,#0)
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB168_15
	}
// %bb.13:                              // %land.lhs.true
	{
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.14:                              // %land.lhs.true
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) memw(r16+#52) = #1
	}
	.falign
.LBB168_15:                             // %if.end26
	{
		r17:16 = memd(r29+#64)
		r19:18 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#48)
		r23:22 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#32)
		r27:26 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end168:
	.size	moe_m1_q_worker, .Lfunc_end168-moe_m1_q_worker
                                        // -- End function
	.falign
	.type	moe_dn_rows,@function           // -- Begin function moe_dn_rows
moe_dn_rows:                            // @moe_dn_rows
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r0)
		r6 = r2
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r0+#544)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r3,#0)
		r4 = memw(r0+#8)
		if (!p1.new) r0 = memw(r16+#0)
	}
	{
		r18 = asl(r4,#5)
		if (p1) jump:nt .LBB169_3
		if (!p1) r5 = memw(r16+#24)
		if (!p1) r2 = memw(r16+#12)
	}
// %bb.1:                               // %if.then
	{
		r4 = memw(r16+#808)
		r8 = memw(r16+#816)
	}
	{
		r4 = addasl(r4,r18,#2)
		r8 = addasl(r8,r18,#2)
		r1 = memw(r16+#4)
		r3 = memw(r16+#28)
	}
	{
		r12 = memw(r16+#836)
		r13 = memw(r16+#828)
	}
	{
		r7 = memw(r16+#812)
		r9 = memw(r16+#820)
	}
	{
		r7 = addasl(r7,r18,#2)
		r9 = addasl(r9,r18,#2)
		r14 = memw(r16+#832)
	}
	{
		r4 = r6
		r15 = memw(r16+#824)
		memw(r29+#4) = r4

	} :mem_noshuf
	{
		r3 = r17
		memw(r29+#0) = r3
		memw(r29+#32) = r15
	}
	{
		memw(r29+#28) = r14
		memw(r29+#24) = r13
	}
	{
		memw(r29+#20) = r12
		memw(r29+#16) = r9
	}
	{
		call hvx_dequant_i24_tiles_scatter_rows_f32
		memw(r29+#12) = r8
		memw(r29+#8) = r7
	}
	.falign
// %bb.2:                               // %if.then
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB169_15
	}
	{
		jump .LBB169_8
	}
	.falign
.LBB169_3:                              // %if.else
	{
		r5 = memw(r16+#548)
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r5,#0)
		r0 = memw(r16+#0)
		r3 = memw(r16+#16)
	}
	{
		r4 = memw(r16+#24)
		r8 = memw(r16+#808)
	}
	{
		r8 = addasl(r8,r18,#2)
		r14 = memw(r16+#816)
		r1 = memw(r16+#4)
	}
	{
		r14 = addasl(r14,r18,#2)
		r7 = memw(r16+#28)
		r12 = memw(r16+#812)
	}
	{
		r12 = addasl(r12,r18,#2)
		r15 = memw(r16+#820)
		r9 = memw(r16+#836)
	}
	{
		r15 = addasl(r15,r18,#2)
		r13 = memw(r16+#828)
		r28 = memw(r16+#832)
	}
	{
		if (p0) jump:nt .LBB169_6
		r10 = memw(r16+#824)
	}
// %bb.4:                               // %if.then5
	{
		r7 = add(r16,#552)
		memw(r29+#4) = r7
		memw(r29+#36) = r10
	}
	{
		r7 = addasl(r5,r18,#2)
		r5:4 = combine(r6,r17)
		memw(r29+#44) = r7
		memw(r29+#0) = r4
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		memw(r29+#8) = r8
		memw(r29+#40) = r7
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_affine_f32
	}
	.falign
// %bb.5:                               // %if.then5
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB169_15
	}
	{
		jump .LBB169_8
	}
	.falign
.LBB169_6:                              // %if.else25
	{
		r5:4 = combine(r6,r17)
		memw(r29+#0) = r4
		memw(r29+#36) = r10
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_f32
		memw(r29+#8) = r8
		memw(r29+#4) = r7
	}
	.falign
// %bb.7:                               // %if.else25
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB169_15
	}
	.falign
.LBB169_8:                              // %land.rhs.lr.ph
	{
		r19 = #0
		r17 = #0
		r2 = memw(r16+#852)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB169_15
	}
	.falign
.LBB169_10:                             // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1 = #0
		r2 = memw(r16+#844)
		r3 = memw(r16+#824)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r4 = memb(r3+r2<<#0)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB169_13
	}
// %bb.11:                              // %if.then49.us
                                        //   in Loop: Header=BB169_10 Depth=1
	{
		r2 = add(r3,r2)
	}
	{
		memb(r2+#0) = #1
		r2 = memw(r16+#844)

	} :mem_noshuf
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#820)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r2 = mpyi(r3,r2)
		r3 = memw(r16+#12)
	}
	{
		r4 = addasl(r4,r2,#2)
		r2 = asl(r3,#7)
	}
	{
		r0 = addasl(r4,r18,#2)
		call memset
	}
	.falign
// %bb.12:                              // %if.then49.us
                                        //   in Loop: Header=BB169_10 Depth=1
	{
		r2 = memw(r16+#844)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	.falign
.LBB169_13:                             // %if.end64.us
                                        //   in Loop: Header=BB169_10 Depth=1
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#848)
	}
	{
		r6 = memw(r16+#12)
		r5 = memw(r16+#820)
	}
	{
		r7 = mpyi(r3,r2)
		r9 = mpyi(r3,r19)
		r8 = memw(r16+#840)
		r2 = memw(r4+r17<<#0)
	}
	{
		r7 = addasl(r5,r7,#2)
		r3 = asl(r6,#5)
	}
	{
		r6 = addasl(r8,r9,#2)
		r0 = addasl(r7,r18,#2)
	}
	{
		r1 = addasl(r6,r18,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.14:                              // %if.end64.us
                                        //   in Loop: Header=BB169_10 Depth=1
	{
		r17 = add(r17,#4)
		r19 = add(r19,#1)
	}
	{
		r2 = memw(r16+#852)
		if (cmp.gtu(r2.new,r19)) jump:t .LBB169_10
	}
	.falign
.LBB169_15:                             // %for.cond.cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end169:
	.size	moe_dn_rows, .Lfunc_end169-moe_dn_rows
                                        // -- End function
	.type	g_moe_src_bypass,@object        // @g_moe_src_bypass
	.lcomm	g_moe_src_bypass,4,4
	.type	audit_hvx_bg_job_size,@object   // @audit_hvx_bg_job_size
	.comm	audit_hvx_bg_job_size,32,8
	.type	audit_moe_tail_ctx_size,@object // @audit_moe_tail_ctx_size
	.comm	audit_moe_tail_ctx_size,64,8
	.type	g_m1q_desc,@object              // @g_m1q_desc
	.lcomm	g_m1q_desc,1024,128
	.type	g_fc_m1_desc,@object            // @g_fc_m1_desc
	.lcomm	g_fc_m1_desc,2048,128
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym hexkl_moe_pack_bg_worker
	.addrsig_sym moe_m1_pair_worker
	.addrsig_sym moe_tl2_gate_epilogue_worker
	.addrsig_sym moe_m1_requant_worker
	.addrsig_sym moe_m1_down_worker
	.addrsig_sym moe_gu_worker
	.addrsig_sym moe_dn_worker
	.addrsig_sym moe_dn_unit
	.addrsig_sym moe_dn_fg_worker
	.addrsig_sym fc_m1_worker
	.addrsig_sym moe_expand_unit
	.addrsig_sym moe_m1_q_worker
	.addrsig_sym hexkl_probe_us
	.addrsig_sym g_m1q_desc
	.addrsig_sym g_fc_m1_desc
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#hexkl_moe_pack_bg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_pair_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_tl2_gate_epilogue_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_requant_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_down_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_gu_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_fg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#fc_m1_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_expand_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_q_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"

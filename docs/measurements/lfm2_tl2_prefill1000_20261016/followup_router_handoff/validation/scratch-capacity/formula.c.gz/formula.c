  const size_t n_slots_cap = (size_t)n_rows + (size_t)n_experts * (BR - 1u);
  /* mid's row params, one set per mid buffer. */
  const size_t sz_scale = sizeof(float) * 2u * BR;
  const size_t sz_zp = sizeof(int32_t) * 2u * BR;
  const size_t sz_act_ah = n_slots_cap * K;
  const size_t sz_slot_u32 = sizeof(uint32_t) * n_slots_cap;
  const size_t sz_expert_u32 = sizeof(uint32_t) * n_experts;
  const size_t sz_mpad_u32 = sizeof(uint32_t) * m_pad;
  /** ...unless the caller says otherwise (hexkl_moe_scratch): a row the
     scan norms is read once, where it is, and a heap out_f32 needs no
     copy to scatter into. */
  const float *pre_gamma = scratch->pre_gamma;
#ifdef HEXKL_MOE_NO_DIRECT /* diagnosis: the copied paths for every call */
  const int act_direct = 0;
  const int out_direct = 0;
#else
  const int act_direct = pre_gamma != NULL && !use_m1;
  const int out_direct = scratch->out_heap && !use_m1;
#endif
  const size_t sz_act_c = act_direct ? 0u : sizeof(float) * (size_t)M * K;
  const size_t sz_out_c = out_direct ? 0u : sizeof(float) * (size_t)M * N_out;
  const size_t sz_pre =
    act_direct
      ? sizeof(float) * ((size_t)hvx_worker_pool_workers(pool) + 1u) * K
      : 0u;
  /** The rows quantized once, row-major, for the pack to gather from (the
     HMX path; MOE_U8_GUARD readable bytes either side, the gather's
     contract). */
  const size_t sz_act_u8 = use_m1 ? 0u : (size_t)M * K + 2u * MOE_U8_GUARD;
  /* One done byte per slot block for the background pack. */
  const size_t sz_pack_done = n_slots_cap / HEXKL_MOE_PACK_UNIT_ROWS + 1u;
  /** the down batches' out rows written so far, [MOE_MAX_CHUNKS][M] */
  const size_t sz_seen = use_m1 ? 0u : (size_t)MOE_MAX_CHUNKS * M;
  /** The tail path (moe_tail_*): jobs, done bytes and contexts for as many
     tails as there are experts -- a bound, like n_slots_cap, so the block
     never regrows -- one shared staging set, and each tail's own result. */
  const size_t sz_jobs = sizeof(hvx_bg_job) * (1u + 3u * (size_t)n_experts);
  const size_t sz_tail_done =
    (size_t)n_experts * (inter_ntiles + 1u + dn_ntiles);
  const size_t sz_tail_ctx = sizeof(moe_tail_ctx) * (size_t)n_experts;
  const size_t sz_tail_acc_gu = (size_t)inter_ntiles * 2u * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_acc_dn = (size_t)dn_ntiles * MOE_TAIL_TILE_BYTES;
  const size_t sz_tail_gate = sizeof(float) * MOE_TAIL_MAX_ROWS * inter;
  const size_t sz_tail_mid =
    (size_t)inter_ktiles * HEXKL_HMX_ACTIVATION_ALIGNMENT;
  const size_t sz_tail_rq = sizeof(float) * HEXKL_HMX_INT8_BLOCK_N_ROW;
  const size_t sz_tail_res =
    sizeof(float) * MOE_TAIL_MAX_ROWS * (size_t)N_out * n_experts;
  /** The M=1 path's per-expert staging, reserved for MOE_M1_MAX_EXPERTS
     whenever the path is taken (the bound, so no later routing regrows). */
  const size_t sz_m1_expert =
    ROUND_UP_SZ((size_t)inter_ntiles * 2u * MOE_M1_TILE_BYTES,
                MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ((size_t)dn_ntiles * MOE_M1_TILE_BYTES, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * inter, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
    2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
    ROUND_UP_SZ(sizeof(float) * MOE_M1_MAX_ROWS * N_out, MOE_SCRATCH_ALIGN);
  const size_t sz_m1 = use_m1 ? MOE_M1_MAX_EXPERTS * sz_m1_expert : 0u;
  const size_t need = ROUND_UP_SZ(sz_scale, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_zp, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_ah, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_slot_u32, MOE_SCRATCH_ALIGN) +
                      3u * ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_mpad_u32, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_out_c, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_act_u8, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_pre, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_pack_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_seen, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_jobs, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_done, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_ctx, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_gu, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_acc_dn, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_gate, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_mid, MOE_SCRATCH_ALIGN) +
                      2u * ROUND_UP_SZ(sz_tail_rq, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_tail_res, MOE_SCRATCH_ALIGN) +
                      ROUND_UP_SZ(sz_expert_u32, MOE_SCRATCH_ALIGN) + sz_m1;

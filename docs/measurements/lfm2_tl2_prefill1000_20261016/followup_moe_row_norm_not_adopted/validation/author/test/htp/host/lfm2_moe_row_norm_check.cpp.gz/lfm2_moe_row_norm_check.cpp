// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <stdexcept>
#include <thread>
#include <tuple>
#include <vector>
#define SIMDE_ENABLE_NATIVE_ALIASES
#include <simde/arm/neon.h>
// Only the extracted application guards use the target architecture macro.
#define __aarch64__ 1
#define ENABLE_HEXKL 1
#define VFMAQ_F32 vfmaq_f32

static void check(bool ok, const char *why) {
  if (!ok)
    throw std::runtime_error(why);
}
static unsigned cases;
static bool enabled() {
  const char *s = std::getenv("NNTR_LFM2_MOE_ROW_NORM");
  return s && std::strcmp(s, "1") == 0;
}
struct Throw {
  template <typename T> Throw &operator<<(const T &) { return *this; }
  ~Throw() noexcept(false) { throw std::invalid_argument("norm type"); }
};
#define NNTR_THROW_IF(c, t)                                                    \
  if (c)                                                                       \
  Throw()
namespace math {
#include "math.inc"
}
namespace nntrainer {
enum class Tdatatype { FP32, FP16, TL2CX_WH, QS4CX_WH };
enum class Tformat { NCHW, NHWC };
struct ContextData {};
struct ComputeOps {
  bool supported = true;
  std::atomic<size_t> calls{0};
  bool supports_gemm_qs4cx_moe_layer_fp32() const { return supported; }
  void ele_mul_fp32(unsigned n, const float *x, const float *y, float *z,
                    float alpha, float beta, unsigned is, unsigned os) {
    check(n == 2048 && is == 1 && os == 1, "gamma call geometry changed");
    check(alpha == 1.0f && beta == 0.0f, "gamma call coefficients changed");
    calls.fetch_add(1, std::memory_order_relaxed);
    math::ele_mul(n, x, y, z, alpha, beta);
  }
};
static ComputeOps htp, other;
static ComputeOps *get_htp_ops() { return &htp; }
struct Tensor {
  std::array<unsigned, 4> dim{1, 1, 1, 2048};
  Tdatatype type = Tdatatype::FP32;
  Tformat format = Tformat::NCHW;
  bool contiguous = true;
  float *data = nullptr;
  ComputeOps *ops = &htp;
  std::shared_ptr<ContextData> context;
  unsigned batch() const { return dim[0]; }
  unsigned channel() const { return dim[1]; }
  unsigned height() const { return dim[2]; }
  unsigned width() const { return dim[3]; }
  size_t size() const { return size_t(dim[0]) * dim[1] * dim[2] * dim[3]; }
  auto getDim() const { return std::make_tuple(dim, type, format); }
  Tdatatype getDataType() const { return type; }
  Tformat getFormat() const { return format; }
  bool getContiguous() const { return contiguous; }
  ComputeOps *getOps() const { return ops; }
  const std::shared_ptr<ContextData> &getContextData() const { return context; }
  template <typename T> T *getData() const {
    return reinterpret_cast<T *>(data);
  }
  void multiply_i(const Tensor &gamma) {
    // The fixed NCHW [1,1,M,2048] x [1,1,1,2048] broadcast calls
    // FloatTensor::multiply's exact ele_mul arguments once per row.
    for (size_t r = 0; r < size() / width(); ++r)
      ops->ele_mul_fp32(width(), data + r * width(), gamma.data,
                        data + r * width(), 1.0f, 0.0f, 1, 1);
  }
};
struct RunLayerContext {
  std::vector<Tensor> weights;
  Tensor &getWeight(unsigned i) { return weights.at(i); }
};
namespace props {
struct Unit {
  unsigned value;
  unsigned get() const { return value; }
};
} // namespace props
static void rms_norm_wrt_width_fp32_intrinsic(const float *x, float *y,
                                              size_t h, size_t w, float eps) {
  math::rms_norm_wrt_width_fp32_intrinsic(x, y, h, w, eps);
}
struct ThreadManager {
  inline static unsigned lanes = 1, order = 0, dispatches = 0;
  inline static size_t last_jobs = 0;
  static ThreadManager &Global() {
    static ThreadManager tm;
    return tm;
  }
  template <typename F> void parallel_for(size_t begin, size_t end, F fn) {
    ++dispatches;
    last_jobs = end - begin;
    std::vector<size_t> jobs(end - begin);
    std::iota(jobs.begin(), jobs.end(), begin);
    if (order == 1)
      std::reverse(jobs.begin(), jobs.end());
    if (order == 2)
      std::shuffle(jobs.begin(), jobs.end(), std::mt19937(789));
    std::atomic<size_t> next{0};
    std::exception_ptr error;
    std::mutex lock;
    auto work = [&] {
      try {
        size_t i;
        while ((i = next.fetch_add(1)) < jobs.size()) {
          if ((jobs[i] & 1) == 0)
            std::this_thread::yield();
          fn(jobs[i]);
        }
      } catch (...) {
        std::lock_guard<std::mutex> guard(lock);
        error = std::current_exception();
      }
    };
    std::vector<std::thread> workers;
    for (unsigned i = 1; i < lanes; ++i)
      workers.emplace_back(work);
    work();
    for (auto &w : workers)
      w.join();
    if (error)
      std::rethrow_exception(error);
  }
};
} // namespace nntrainer
namespace ml {
namespace train {
struct TensorDim {
  using DataType = nntrainer::Tdatatype;
};
} // namespace train
} // namespace ml
namespace causallm {
#include "baseline.inc"
#include "helper.inc"
static void route(const nntrainer::Tensor &raw, nntrainer::Tensor &input,
                  nntrainer::RunLayerContext &context,
                  const std::vector<unsigned> &expert_gate_up_proj_indices,
                  const std::vector<unsigned> &expert_down_proj_indices,
                  bool in_norm, bool norm_on_accel, bool out_add,
                  bool router_norm, bool gelu_act, bool softmax_router,
                  unsigned num_experts, unsigned inter, float norm_eps) {
  const unsigned in_gamma_idx = 128;
  const auto moe_props = std::make_tuple(nntrainer::props::Unit{inter});
#include "caller.inc"
}
} // namespace causallm

static void fill(float *p, size_t n, uint32_t seed, unsigned mode) {
  const uint32_t edge[] = {0,          0x80000000, 1,          0x80000001,
                           0x00800000, 0x80800000, 0x3f800000, 0xbf800000,
                           0x7f800000, 0xff800000, 0x7fc00021, 0xffc00042,
                           0x7f800021, 0xff800042};
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    uint32_t v = (seed & 0x807fffff) | ((120u + unsigned(i % 12)) << 23);
    if (mode == 1 && i % 257 == 0)
      v = edge[(i + seed) % 14];
    if (mode == 2)
      v = edge[i % 8];
    std::memcpy(p + i, &v, 4);
  }
}
struct Data {
  std::vector<float> x, y, ref, gamma;
  nntrainer::Tensor src, dst, expected, scale;
  nntrainer::RunLayerContext context;
  std::vector<unsigned> gu, dn;
  explicit Data(unsigned rows) :
    x(size_t(rows) * 2048 + 32), y(x.size()), ref(x.size()), gamma(2048 + 32) {
    src.dim = dst.dim = expected.dim = {1, 1, rows, 2048};
    src.data = x.data() + 16;
    dst.data = y.data() + 16;
    expected.data = ref.data() + 16;
    scale.data = gamma.data() + 16;
    src.context = dst.context = scale.context =
      std::make_shared<nntrainer::ContextData>();
    context.weights.resize(129);
    for (unsigned i = 0; i < 64; ++i) {
      gu.push_back(i);
      dn.push_back(i + 64);
      context.weights[i].type = context.weights[i + 64].type =
        nntrainer::Tdatatype::TL2CX_WH;
    }
    context.weights[128] = scale;
  }
  bool helper() {
    return causallm::lfmPrefillRowNorm(src, dst, scale, 1e-5f, context, gu, dn);
  }
  void reset(unsigned mode) {
    fill(src.data, src.size(), 7781, mode);
    fill(scale.data, scale.size(), 17791, mode);
    std::fill(y.begin(), y.end(), -1234.5f);
    std::fill(ref.begin(), ref.end(), -1234.5f);
    nntrainer::ThreadManager::dispatches = 0;
    nntrainer::htp.calls.store(0);
  }
};

int main() {
  try {
    for (unsigned rows : {1024u, 2048u}) {
      Data d(rows);
      for (unsigned lanes : {1u, 8u})
        for (unsigned order : {0u, 1u, 2u})
          for (unsigned mode : {0u, 1u, 2u}) {
            nntrainer::ThreadManager::lanes = lanes;
            nntrainer::ThreadManager::order = order;
            d.reset(mode);
            causallm::normRows(d.src, d.expected, d.scale, 1e-5f);
            const auto original_x = d.x, original_gamma = d.gamma;
            nntrainer::htp.calls.store(0);
            const bool ok = d.helper();
            check(ok == enabled(),
                  "enabled helper rejected or disabled helper used");
            if (!ok)
              causallm::normRows(d.src, d.dst, d.scale, 1e-5f);
            check(std::memcmp(d.y.data(), d.ref.data(), d.y.size() * 4) == 0,
                  "row norm numeric/canary mismatch");
            check(std::memcmp(d.x.data(), original_x.data(), d.x.size() * 4) ==
                    0,
                  "source modified");
            check(std::memcmp(d.gamma.data(), original_gamma.data(),
                              d.gamma.size() * 4) == 0,
                  "gamma modified");
            check(nntrainer::htp.calls.load() == rows, "gamma row coverage");
            check(nntrainer::ThreadManager::dispatches == unsigned(enabled()),
                  "dispatch count");
            if (enabled())
              check(nntrainer::ThreadManager::last_jobs == rows / 64,
                    "job count");
            ++cases;
          }
      // The actual incremental caller block keeps unsupported policy paths
      // serial.
      for (unsigned policy = 0; policy < 9; ++policy) {
        d.reset(1);
        causallm::normRows(d.src, d.expected, d.scale, 1e-5f);
        causallm::route(d.src, d.dst, d.context, d.gu, d.dn, policy != 7,
                        policy == 8, policy == 1, policy == 2, policy == 3,
                        policy == 4, policy == 5 ? 32 : 64,
                        policy == 6 ? 704 : 1536, 1e-5f);
        check(nntrainer::ThreadManager::dispatches ==
                unsigned(policy == 0 && enabled()),
              "caller policy dispatch");
        if (policy < 7)
          check(std::memcmp(d.y.data(), d.ref.data(), d.y.size() * 4) == 0,
                "caller fallback changed");
        else
          check(std::all_of(d.y.begin(), d.y.end(),
                            [](float v) { return v == -1234.5f; }),
                "disabled norm changed output");
        ++cases;
      }
    }
    // No rejected helper may write a byte or submit work. Every alias direction
    // has real storage behind it; guard failures are not fabricated pointer
    // math.
    for (unsigned bad = 0; bad < 35; ++bad) {
      Data d(1024);
      d.reset(0);
      using nntrainer::Tdatatype;
      using nntrainer::Tformat;
      switch (bad) {
      case 0:
        d.src.dim[2] = d.dst.dim[2] = 1;
        break;
      case 1:
        d.src.dim[2] = d.dst.dim[2] = 512;
        break;
      case 2:
        d.src.dim[2] = d.dst.dim[2] = 2047;
        break;
      case 3:
        d.src.dim[0] = d.dst.dim[0] = 2;
        break;
      case 4:
        d.src.dim[1] = d.dst.dim[1] = 2;
        break;
      case 5:
        d.src.dim[3] = d.dst.dim[3] = 2816;
        break;
      case 6:
        d.src.format = d.dst.format = Tformat::NHWC;
        break;
      case 7:
        d.src.type = d.dst.type = Tdatatype::FP16;
        break;
      case 8:
        d.dst.dim[2] = 1023;
        break;
      case 9:
        d.scale.dim[0] = 2;
        break;
      case 10:
        d.scale.dim[1] = 2;
        break;
      case 11:
        d.scale.dim[2] = 2;
        break;
      case 12:
        d.scale.dim[3] = 2047;
        break;
      case 13:
        d.scale.type = Tdatatype::FP16;
        break;
      case 14:
        d.scale.format = Tformat::NHWC;
        break;
      case 15:
        d.src.contiguous = false;
        break;
      case 16:
        d.dst.contiguous = false;
        break;
      case 17:
        d.scale.contiguous = false;
        break;
      case 18:
        d.gu.pop_back();
        break;
      case 19:
        d.dn.push_back(1);
        break;
      case 20:
        d.dst.ops = nullptr;
        break;
      case 21:
        d.src.ops = &nntrainer::other;
        break;
      case 22:
        d.src.ops = d.dst.ops = &nntrainer::other;
        break;
      case 23:
        nntrainer::htp.supported = false;
        break;
      case 24:
        d.src.context = std::make_shared<nntrainer::ContextData>();
        break;
      case 25:
        d.scale.context = std::make_shared<nntrainer::ContextData>();
        break;
      case 26:
        d.context.weights[63].type = Tdatatype::QS4CX_WH;
        break;
      case 27:
        d.context.weights[127].type = Tdatatype::QS4CX_WH;
        break;
      case 28:
        d.src.data = nullptr;
        break;
      case 29:
        d.dst.data = nullptr;
        break;
      case 30:
        d.scale.data = nullptr;
        break;
      case 31:
        d.dst.data = d.src.data;
        break;
      case 32:
        d.dst.data = d.src.data + 1;
        break;
      case 33:
        d.dst.data = d.src.data - 1;
        break;
      case 34:
        d.scale.data = d.dst.data + 3;
        break;
      }
      const auto x = d.x, y = d.y, g = d.gamma;
      check(!d.helper(), "invalid helper accepted");
      check(nntrainer::ThreadManager::dispatches == 0,
            "rejected helper dispatched");
      check(std::memcmp(x.data(), d.x.data(), x.size() * 4) == 0 &&
              std::memcmp(y.data(), d.y.data(), y.size() * 4) == 0 &&
              std::memcmp(g.data(), d.gamma.data(), g.size() * 4) == 0,
            "rejected helper wrote memory");
      nntrainer::htp.supported = true;
      ++cases;
    }
    std::printf("ROW_NORM %u cases env=%s PASS\n", cases,
                enabled() ? "1" : "off");
  } catch (const std::exception &e) {
    std::fprintf(stderr, "ROW_NORM FAIL: %s\n", e.what());
    return 1;
  }
}

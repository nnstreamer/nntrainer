// SPDX-License-Identifier: Apache-2.0
// The helpers are extracted from the app. Tensor, RunLayerContext, RMS,
// ele_mul and ThreadManager are the real deployed libnntrainer implementations.
#include <algorithm>
#include <compute_ops.h>
#include <cpu_backend.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <layer_context.h>
#include <memory>
#include <nntrainer_error.h>
#include <stdexcept>
#include <tensor.h>
#include <thread_manager.h>
#include <tuple>
#include <vector>
#include <weight.h>

static void check(bool ok, const char *why) {
  if (!ok)
    throw std::runtime_error(why);
}
namespace causallm {
#include "baseline.inc"
#include "helper.inc"
static void route(const nntrainer::Tensor &raw, nntrainer::Tensor &input,
                  nntrainer::RunLayerContext &context,
                  const std::vector<unsigned> &expert_gate_up_proj_indices,
                  const std::vector<unsigned> &expert_down_proj_indices,
                  bool in_norm, bool norm_on_accel, bool out_add,
                  bool router_norm, bool gelu_act, bool softmax_router,
                  unsigned num_experts, unsigned inter, float norm_eps) {
  const unsigned in_gamma_idx = 128;
  std::tuple<nntrainer::props::Unit> moe_props;
  std::get<nntrainer::props::Unit>(moe_props).set(inter);
#include "caller.inc"
}
} // namespace causallm
static void fill(float *p, size_t n, uint32_t seed, unsigned mode) {
  const uint32_t edge[] = {0,          0x80000000, 1,          0x80000001,
                           0x00800000, 0x80800000, 0x3f800000, 0xbf800000,
                           0x7f800000, 0xff800000, 0x7fc00021, 0xffc00042,
                           0x7f800021, 0xff800042};
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    uint32_t v = (seed & 0x807fffff) | ((120u + unsigned(i % 12)) << 23);
    if (mode == 1 && i % 257 == 0)
      v = edge[(i + seed) % 14];
    if (mode == 2)
      v = edge[i % 8];
    std::memcpy(p + i, &v, 4);
  }
}
int main(int argc, char **argv) {
  try {
    const char *v = std::getenv("NNTR_LFM2_MOE_ROW_NORM");
    const bool enabled = v && std::strcmp(v, "1") == 0;
    nntrainer::ThreadManagerConfig config;
    config.compute_threads = argc == 2 ? std::stoul(argv[1]) : 8;
    nntrainer::ThreadManager::setConfig(config);
    auto *ops = nntrainer::get_htp_ops();
    auto ct = std::make_shared<nntrainer::ContextData>();
    ct->setComputeOps(ops);
    unsigned cases = 0;
    for (unsigned rows : {1024u, 2048u}) {
      nntrainer::Tensor src(1, 1, rows, 2048), dst(1, 1, rows, 2048);
      nntrainer::Tensor ref(1, 1, rows, 2048), gamma(1, 1, 1, 2048), empty;
      src.setContextData(ct);
      dst.setContextData(ct);
      ref.setContextData(ct);
      gamma.setContextData(ct);
      std::vector<std::unique_ptr<nntrainer::Weight>> storage;
      std::vector<nntrainer::Weight *> weights;
      std::vector<unsigned> gu, dn;
      for (unsigned i = 0; i < 128; ++i) {
        nntrainer::TensorDim dim(1, 1, i < 64 ? 2048 : 1536,
                                 i < 64 ? 3072 : 2048, nntrainer::Tformat::NCHW,
                                 nntrainer::Tdatatype::TL2CX_WH);
        storage.emplace_back(new nntrainer::Weight(
          dim, nntrainer::Initializer::NONE, nntrainer::WeightRegularizer::NONE,
          0, 0, 0, false, false, "metadata" + std::to_string(i)));
        weights.push_back(storage.back().get());
      }
      storage.emplace_back(new nntrainer::Weight(gamma, empty, empty, "gamma"));
      weights.push_back(storage.back().get());
      for (unsigned i = 0; i < 64; ++i) {
        gu.push_back(i);
        dn.push_back(i + 64);
      }
      nntrainer::Var_Grad input(src, empty, "input"),
        output(dst, empty, "output");
      nntrainer::RunLayerContext context("row_norm", false, 0, false, 1, ct,
                                         false, weights, {&input}, {&output},
                                         {});
      auto run = [&] {
        return causallm::lfmPrefillRowNorm(src, dst, gamma, 1e-5f, context, gu,
                                           dn);
      };
      for (unsigned mode : {0u, 1u, 2u}) {
        fill(src.getData<float>(), src.size(), 7781, mode);
        fill(gamma.getData<float>(), gamma.size(), 17791, mode);
        causallm::normRows(src, ref, gamma, 1e-5f);
        std::vector<float> x(src.getData<float>(),
                             src.getData<float>() + src.size());
        std::vector<float> g(gamma.getData<float>(),
                             gamma.getData<float>() + gamma.size());
        bool used = run();
        check(used == enabled, "native eligible route/option mismatch");
        if (!used)
          causallm::normRows(src, dst, gamma, 1e-5f);
        check(std::memcmp(dst.getData<float>(), ref.getData<float>(),
                          src.size() * 4) == 0,
              "native output bits");
        check(std::memcmp(src.getData<float>(), x.data(), src.size() * 4) == 0,
              "native source bits");
        check(std::memcmp(gamma.getData<float>(), g.data(), gamma.size() * 4) ==
                0,
              "native gamma bits");
        std::printf("EXACT M=%u mode=%u used=%d PASS\n", rows, mode, used);
        ++cases;
      }
      // Actual caller fallback remains a full original norm, including Gemma
      // policies even when the synthetic activations use the LFM dimensions.
      for (unsigned p = 0; p < 7; ++p) {
        causallm::route(src, dst, context, gu, dn, true, false, p == 1, p == 2,
                        p == 3, p == 4, p == 5 ? 32 : 64, p == 6 ? 704 : 1536,
                        1e-5f);
        check(std::memcmp(dst.getData<float>(), ref.getData<float>(),
                          src.size() * 4) == 0,
              "native caller fallback bits");
        ++cases;
      }
      {
        auto save = dst;
        dst = src;
        check(!run(), "native exact alias accepted");
        dst = save;
        ++cases;
      }
      {
        auto save = gamma;
        gamma = dst.getSharedDataTensor(gamma.getDim(), 1, true);
        check(!run(), "native gamma alias accepted");
        gamma = save;
        ++cases;
      }
      {
        auto save = gu.back();
        gu.pop_back();
        check(!run(), "native short expert list accepted");
        gu.push_back(save);
        ++cases;
      }
      {
        auto save = gamma.getContextData();
        auto different = std::make_shared<nntrainer::ContextData>();
        different->setComputeOps(ops);
        gamma.setContextData(different);
        check(!run(), "native incompatible context accepted");
        gamma.setContextData(save);
        ++cases;
      }
      {
        auto &weight = context.getWeight(127);
        auto save = weight;
        weight = nntrainer::Tensor(
          nntrainer::TensorDim(1, 1, 32, 32, nntrainer::Tformat::NCHW,
                               nntrainer::Tdatatype::QS4CX_WH),
          false);
        check(!run(), "native last expert not TL2 accepted");
        weight = save;
        ++cases;
      }
    }
    std::printf("ROW_NORM_NATIVE %u cases threads=%u env=%d PASS\n", cases,
                nntrainer::ThreadManager::Global().getComputeThreadCount(),
                enabled);
  } catch (const std::exception &e) {
    std::fprintf(stderr, "ROW_NORM_NATIVE FAIL: %s\n", e.what());
    return 1;
  }
}

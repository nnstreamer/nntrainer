// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>
#include <compute_ops.h>
#include <cpu_backend.h>
#include <nntrainer_error.h>
#include <tensor.h>
#include <thread_manager.h>

#include "baseline.inc"

static void chunkNorm(const nntrainer::Tensor &src, nntrainer::Tensor &dst,
                      const nntrainer::Tensor &gamma, float eps) {
  constexpr size_t rows_per_task = 64;
  const size_t rows = src.height(), width = src.width();
  const float *input = src.getData<float>(), *scale = gamma.getData<float>();
  float *output = dst.getData<float>();
  auto *ops = dst.getOps();
  nntrainer::ThreadManager::Global().parallel_for(
    0, (rows + rows_per_task - 1) / rows_per_task, [&](size_t task) {
      const size_t first = task * rows_per_task;
      const size_t count = std::min(rows_per_task, rows - first);
      nntrainer::rms_norm_wrt_width_fp32_intrinsic(
        input + first * width, output + first * width, count, width, eps);
      for (size_t r = first; r < first + count; ++r) {
        float *out = output + r * width;
        ops->ele_mul_fp32(width, out, scale, out, 1.0f, 0.0f, 1, 1);
      }
    });
}

static void fill(float *data, size_t n, uint32_t seed, bool special) {
  const uint32_t edge[] = {0u, 0x80000000u, 1u, 0x80000001u, 0x00800000u,
    0x80800000u, 0x3f800000u, 0xbf800000u, 0x7f800000u, 0xff800000u,
    0x7fc00021u, 0xffc00042u, 0x7f800021u, 0xff800042u, 0x3f800001u,
    0xbf800001u};
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
    uint32_t bits = (seed & 0x807fffffu) | ((120u + unsigned(i % 12)) << 23);
    if (special && i % 257 == 0) bits = edge[(i + seed) % 16];
    std::memcpy(data + i, &bits, sizeof bits);
  }
}

int main() {
  try {
    nntrainer::ThreadManagerConfig config;
    config.compute_threads = 8;
    nntrainer::ThreadManager::setConfig(config);
    std::printf("THREADS %u\n", nntrainer::ThreadManager::Global().getComputeThreadCount());
    for (unsigned rows : {128u, 1024u, 2048u}) {
      nntrainer::Tensor input(1, 1, rows, 2048), gamma(1, 1, 1, 2048);
      nntrainer::Tensor baseline(1, 1, rows, 2048), candidate(1, 1, rows, 2048);
      for (bool special : {false, true}) {
        fill(input.getData<float>(), input.size(), 0x124512u, special);
        fill(gamma.getData<float>(), gamma.size(), 0x39418u, special);
        normRows(input, baseline, gamma, 1e-5f);
        chunkNorm(input, candidate, gamma, 1e-5f);
        if (std::memcmp(baseline.getData<float>(), candidate.getData<float>(), input.size() * sizeof(float)))
          throw std::runtime_error("output mismatch");
        std::printf("EXACT rows=%u special=%d PASS\n", rows, special);
      }
      fill(input.getData<float>(), input.size(), 0x124512u, false);
      fill(gamma.getData<float>(), gamma.size(), 0x39418u, false);
      // Both paths write the same output; exclude allocation and initialization.
      auto run = [&](bool parallel) {
        if (parallel) chunkNorm(input, candidate, gamma, 1e-5f);
        else normRows(input, candidate, gamma, 1e-5f);
      };
      for (unsigned i=0; i<3; ++i) { run(false); run(true); }
      std::vector<double> times[2];
      for (unsigned i=0; i<31; ++i) {
        for (unsigned j=0; j<2; ++j) {
          unsigned p = (i+j)%2;
          auto start=std::chrono::steady_clock::now();
          run(p);
          double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count();
          times[p].push_back(us);
          std::printf("SAMPLE rows=%u rep=%u parallel=%u us=%.3f\n",rows,i,p,us);
        }
      }
      for(unsigned p=0;p<2;++p) {
        std::sort(times[p].begin(),times[p].end());
        std::printf("MEDIAN rows=%u parallel=%u us=%.3f\n",rows,p,times[p][15]);
      }
    }
    std::puts("PASS");
  } catch (const std::exception &e) {
    std::fprintf(stderr,"FAIL %s\n",e.what());return 1;
  }
}

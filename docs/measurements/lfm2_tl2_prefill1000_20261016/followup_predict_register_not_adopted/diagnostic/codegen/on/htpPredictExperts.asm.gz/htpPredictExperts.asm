0000000000000000 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>:
       0:      	sub	sp, sp, #0xc0
       4:      	str	d10, [sp, #0x40]
       8:      	stp	d9, d8, [sp, #0x50]
       c:      	stp	x29, x30, [sp, #0x60]
      10:      	stp	x28, x27, [sp, #0x70]
      14:      	stp	x26, x25, [sp, #0x80]
      18:      	stp	x24, x23, [sp, #0x90]
      1c:      	stp	x22, x21, [sp, #0xa0]
      20:      	stp	x20, x19, [sp, #0xb0]
      24:      	add	x29, sp, #0x60
      28:      	mrs	x9, TPIDR_EL0
      2c:      	ldr	x10, [x9, #0x28]
      30:      	stur	x10, [x29, #-0x28]
      34:      	cbz	x0, 0x1dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1dc>
      38:      	mov	x26, x1
      3c:      	cbz	x1, 0x1dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1dc>
      40:      	mov	w28, w2
      44:      	cbz	w2, 0x1dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1dc>
      48:      	mov	w21, w3
      4c:      	cbz	w3, 0x1dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1dc>
      50:      	cbz	w4, 0x1dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1dc>
      54:      	str	w4, [sp, #0x4]
      58:      	mov	w27, w6
      5c:      	mov	x22, x5
      60:      	stp	x9, x8, [sp, #0x8]
      64:      	adrp	x9, 0x0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>
      68:      	mov	w8, #0x1                // =1
      6c:      	ldr	x9, [x9]
      70:      	mov	x25, x0
      74:      	cmp	w28, #0x800
      78:      	ldadd	x8, x8, [x9]
      7c:      	b.ne	0x98 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x98>
      80:      	cmp	w21, #0x40
      84:      	b.ne	0x98 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x98>
      88:      	cbz	x22, 0x98 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x98>
      8c:      	add	x8, x9, #0x8
      90:      	mov	w9, #0x1                // =1
      94:      	ldadd	x9, x8, [x8]
      98:      	ubfiz	x23, x21, #2, #32
      9c:      	mov	w20, w21
      a0:      	mov	x0, x23
      a4:      	bl	0xa4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0xa4>
      a8:      	add	x19, x0, x23
      ac:      	mov	w1, wzr
      b0:      	mov	x2, x23
      b4:      	mov	x24, x0
      b8:      	str	x0, [sp, #0x18]
      bc:      	str	x19, [sp, #0x28]
      c0:      	bl	0xc0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0xc0>
      c4:      	str	x19, [sp, #0x20]
      c8:      	cbz	x22, 0x1f8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1f8>
      cc:      	cmp	w21, #0x40
      d0:      	b.ne	0x1f8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1f8>
      d4:      	cmp	w28, #0x800
      d8:      	b.ne	0x1f8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1f8>
      dc:      	tbz	w27, #0x0, 0x1f8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1f8>
      e0:      	adrp	x9, 0x0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>
      e4:      	movi	v0.2d, #0000000000000000
      e8:      	movi	v2.2d, #0000000000000000
      ec:      	ldr	x9, [x9]
      f0:      	movi	v3.2d, #0000000000000000
      f4:      	movi	v4.2d, #0000000000000000
      f8:      	movi	v5.2d, #0000000000000000
      fc:      	movi	v6.2d, #0000000000000000
     100:      	mov	w10, #0x1               // =1
     104:      	movi	v7.2d, #0000000000000000
     108:      	movi	v16.2d, #0000000000000000
     10c:      	add	x9, x9, #0x10
     110:      	movi	v17.2d, #0000000000000000
     114:      	movi	v18.2d, #0000000000000000
     118:      	ldadd	x10, x9, [x9]
     11c:      	movi	v19.2d, #0000000000000000
     120:      	movi	v20.2d, #0000000000000000
     124:      	mov	x8, xzr
     128:      	movi	v21.2d, #0000000000000000
     12c:      	movi	v22.2d, #0000000000000000
     130:      	add	x9, x26, #0x80
     134:      	movi	v23.2d, #0000000000000000
     138:      	movi	v1.2d, #0000000000000000
     13c:      	ldp	q25, q26, [x9, #-0x80]
     140:      	ldr	s24, [x25, x8]
     144:      	ldp	q27, q28, [x9, #-0x60]
     148:      	add	x8, x8, #0x4
     14c:      	cmp	x8, #0x2, lsl #12       // =0x2000
     150:      	fmla	v0.4s, v25.4s, v24.s[0]
     154:      	fmla	v2.4s, v26.4s, v24.s[0]
     158:      	ldp	q25, q26, [x9, #-0x40]
     15c:      	fmla	v3.4s, v27.4s, v24.s[0]
     160:      	fmla	v4.4s, v28.4s, v24.s[0]
     164:      	fmla	v5.4s, v25.4s, v24.s[0]
     168:      	ldp	q25, q27, [x9, #-0x20]
     16c:      	fmla	v6.4s, v26.4s, v24.s[0]
     170:      	ldp	q26, q28, [x9]
     174:      	fmla	v7.4s, v25.4s, v24.s[0]
     178:      	fmla	v16.4s, v27.4s, v24.s[0]
     17c:      	fmla	v17.4s, v26.4s, v24.s[0]
     180:      	ldp	q25, q26, [x9, #0x20]
     184:      	fmla	v18.4s, v28.4s, v24.s[0]
     188:      	fmla	v19.4s, v25.4s, v24.s[0]
     18c:      	ldp	q25, q27, [x9, #0x40]
     190:      	fmla	v20.4s, v26.4s, v24.s[0]
     194:      	ldp	q26, q28, [x9, #0x60]
     198:      	add	x9, x9, #0x100
     19c:      	fmla	v21.4s, v25.4s, v24.s[0]
     1a0:      	fmla	v22.4s, v27.4s, v24.s[0]
     1a4:      	fmla	v23.4s, v26.4s, v24.s[0]
     1a8:      	fmla	v1.4s, v28.4s, v24.s[0]
     1ac:      	b.ne	0x13c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x13c>
     1b0:      	stp	q0, q2, [x24]
     1b4:      	mov	x8, x23
     1b8:      	mov	x9, x24
     1bc:      	stp	q3, q4, [x24, #0x20]
     1c0:      	stp	q5, q6, [x24, #0x40]
     1c4:      	stp	q7, q16, [x24, #0x60]
     1c8:      	stp	q17, q18, [x24, #0x80]
     1cc:      	stp	q19, q20, [x24, #0xa0]
     1d0:      	stp	q21, q22, [x24, #0xc0]
     1d4:      	stp	q23, q1, [x24, #0xe0]
     1d8:      	b	0x2a8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2a8>
     1dc:      	ldr	x10, [x9, #0x28]
     1e0:      	ldur	x9, [x29, #-0x28]
     1e4:      	cmp	x10, x9
     1e8:      	b.ne	0x4b4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x4b4>
     1ec:      	stp	xzr, xzr, [x8]
     1f0:      	str	xzr, [x8, #0x10]
     1f4:      	b	0x438 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x438>
     1f8:      	mov	x8, xzr
     1fc:      	mov	w9, w28
     200:      	and	x10, x20, #0xfffffff8
     204:      	add	x11, x24, #0x10
     208:      	add	x12, x26, #0x10
     20c:      	b	0x224 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x224>
     210:      	add	x8, x8, #0x1
     214:      	add	x12, x12, x23
     218:      	add	x26, x26, x23
     21c:      	cmp	x8, x9
     220:      	b.eq	0x2a0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2a0>
     224:      	ldr	s0, [x25, x8, lsl #2]
     228:      	cmp	w21, #0x8
     22c:      	b.hs	0x238 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x238>
     230:      	mov	x15, xzr
     234:      	b	0x274 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x274>
     238:      	mov	x13, x12
     23c:      	mov	x14, x11
     240:      	mov	x15, x10
     244:      	ldp	q1, q4, [x14, #-0x10]
     248:      	subs	x15, x15, #0x8
     24c:      	ldp	q2, q3, [x13, #-0x10]
     250:      	add	x13, x13, #0x20
     254:      	fmla	v1.4s, v2.4s, v0.s[0]
     258:      	fmla	v4.4s, v3.4s, v0.s[0]
     25c:      	stp	q1, q4, [x14, #-0x10]
     260:      	add	x14, x14, #0x20
     264:      	b.ne	0x244 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x244>
     268:      	cmp	x10, x20
     26c:      	mov	x15, x10
     270:      	b.eq	0x210 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x210>
     274:      	lsl	x14, x15, #2
     278:      	sub	x15, x20, x15
     27c:      	add	x13, x26, x14
     280:      	add	x14, x24, x14
     284:      	ldr	s1, [x13], #0x4
     288:      	ldr	s2, [x14]
     28c:      	subs	x15, x15, #0x1
     290:      	fmadd	s1, s0, s1, s2
     294:      	str	s1, [x14], #0x4
     298:      	b.ne	0x284 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x284>
     29c:      	b	0x210 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x210>
     2a0:      	mov	x8, x23
     2a4:      	mov	x9, x24
     2a8:      	ldr	w10, [x9]
     2ac:      	mov	w11, #0x7f800000        // =2139095040
     2b0:      	and	w10, w10, #0x7fffffff
     2b4:      	cmp	w10, w11
     2b8:      	b.ge	0x400 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x400>
     2bc:      	subs	x8, x8, #0x4
     2c0:      	add	x9, x9, #0x4
     2c4:      	b.ne	0x2a8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2a8>
     2c8:      	cbz	x22, 0x324 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x324>
     2cc:      	fmov	s8, #1.00000000
     2d0:      	cmp	w21, #0x1
     2d4:      	mov	w25, #0x7f800000        // =2139095040
     2d8:      	csinc	w19, w21, wzr, hi
     2dc:      	ldr	s9, [x22]
     2e0:      	fmov	w8, s9
     2e4:      	and	w8, w8, #0x7fffffff
     2e8:      	cmp	w8, w25
     2ec:      	b.ge	0x400 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x400>
     2f0:      	ldr	s10, [x24]
     2f4:      	fabs	s0, s10
     2f8:      	fneg	s0, s0
     2fc:      	bl	0x2fc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2fc>
     300:      	fcmp	s10, #0.0
     304:      	fadd	s1, s0, s8
     308:      	add	x22, x22, #0x4
     30c:      	fcsel	s0, s0, s8, lt
     310:      	subs	x19, x19, #0x1
     314:      	fdiv	s0, s0, s1
     318:      	fadd	s0, s9, s0
     31c:      	str	s0, [x24], #0x4
     320:      	b.ne	0x2dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2dc>
     324:      	ldr	x24, [sp, #0x10]
     328:      	stp	xzr, xzr, [x24]
     32c:      	str	xzr, [x24, #0x10]
     330:      	mov	x0, x23
     334:      	bl	0x334 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x334>
     338:      	add	x8, x0, x20, lsl #2
     33c:      	mov	w1, wzr
     340:      	mov	x2, x23
     344:      	mov	x22, x0
     348:      	str	x0, [x24]
     34c:      	str	x8, [x24, #0x10]
     350:      	bl	0x350 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x350>
     354:      	sub	x10, x23, #0x4
     358:      	ldr	w20, [sp, #0x4]
     35c:      	mov	w8, wzr
     360:      	add	x2, x22, x23
     364:      	cmp	x10, #0x1c
     368:      	mov	x9, x22
     36c:      	str	x2, [x24, #0x8]
     370:      	b.lo	0x3bc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3bc>
     374:      	lsr	x8, x10, #2
     378:      	movi	v0.4s, #0x4
     37c:      	movi	v1.4s, #0x8
     380:      	adrp	x11, 0x0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>
     384:      	add	x10, x8, #0x1
     388:      	ldr	q2, [x11]
     38c:      	add	x11, x22, #0x10
     390:      	and	x8, x10, #0x7ffffffffffffff8
     394:      	add	x9, x22, x8, lsl #2
     398:      	mov	x12, x8
     39c:      	add	v3.4s, v2.4s, v0.4s
     3a0:      	subs	x12, x12, #0x8
     3a4:      	stp	q2, q3, [x11, #-0x10]
     3a8:      	add	v2.4s, v2.4s, v1.4s
     3ac:      	add	x11, x11, #0x20
     3b0:      	b.ne	0x39c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x39c>
     3b4:      	cmp	x10, x8
     3b8:      	b.eq	0x3cc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3cc>
     3bc:      	str	w8, [x9], #0x4
     3c0:      	cmp	x9, x2
     3c4:      	add	w8, w8, #0x1
     3c8:      	b.ne	0x3bc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3bc>
     3cc:      	cmp	w21, w20
     3d0:      	add	x8, sp, #0x18
     3d4:      	csel	w19, w21, w20, lo
     3d8:      	str	x8, [sp, #0x30]
     3dc:      	add	x1, x22, w19, uxtw #2
     3e0:      	add	x3, sp, #0x30
     3e4:      	mov	x0, x22
     3e8:      	bl	0x3e8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3e8>
     3ec:      	cmp	w20, w21
     3f0:      	b.hs	0x40c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x40c>
     3f4:      	add	x8, x22, x19, lsl #2
     3f8:      	str	x8, [x24, #0x8]
     3fc:      	b	0x40c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x40c>
     400:      	ldr	x8, [sp, #0x10]
     404:      	stp	xzr, xzr, [x8]
     408:      	str	xzr, [x8, #0x10]
     40c:      	ldr	x0, [sp, #0x18]
     410:      	cbz	x0, 0x424 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x424>
     414:      	ldr	x8, [sp, #0x28]
     418:      	str	x0, [sp, #0x20]
     41c:      	sub	x1, x8, x0
     420:      	bl	0x420 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x420>
     424:      	ldr	x8, [sp, #0x8]
     428:      	ldr	x8, [x8, #0x28]
     42c:      	ldur	x9, [x29, #-0x28]
     430:      	cmp	x8, x9
     434:      	b.ne	0x4b4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x4b4>
     438:      	ldp	x20, x19, [sp, #0xb0]
     43c:      	ldr	d10, [sp, #0x40]
     440:      	ldp	x22, x21, [sp, #0xa0]
     444:      	ldp	x24, x23, [sp, #0x90]
     448:      	ldp	x26, x25, [sp, #0x80]
     44c:      	ldp	x28, x27, [sp, #0x70]
     450:      	ldp	x29, x30, [sp, #0x60]
     454:      	ldp	d9, d8, [sp, #0x50]
     458:      	add	sp, sp, #0xc0
     45c:      	ret
     460:      	ldr	x8, [x24, #0x10]
     464:      	mov	x21, x0
     468:      	mov	x0, x22
     46c:      	str	x22, [x24, #0x8]
     470:      	sub	x1, x8, x22
     474:      	bl	0x474 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x474>
     478:      	b	0x480 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x480>
     47c:      	mov	x21, x0
     480:      	ldr	x0, [sp, #0x18]
     484:      	cbz	x0, 0x498 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x498>
     488:      	ldr	x8, [sp, #0x28]
     48c:      	str	x0, [sp, #0x20]
     490:      	sub	x1, x8, x0
     494:      	bl	0x494 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x494>
     498:      	ldr	x8, [sp, #0x8]
     49c:      	ldr	x8, [x8, #0x28]
     4a0:      	ldur	x9, [x29, #-0x28]
     4a4:      	cmp	x8, x9
     4a8:      	b.ne	0x4b4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x4b4>
     4ac:      	mov	x0, x21
     4b0:      	bl	0x4b0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x4b0>
     4b4:      	bl	0x4b4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x4b4>

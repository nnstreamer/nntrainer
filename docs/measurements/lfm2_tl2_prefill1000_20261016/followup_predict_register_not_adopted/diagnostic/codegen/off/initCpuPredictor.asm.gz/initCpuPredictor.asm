0000000000000000 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>:
       0:      	sub	sp, sp, #0x120
       4:      	str	d8, [sp, #0xb0]
       8:      	stp	x29, x30, [sp, #0xc0]
       c:      	stp	x28, x27, [sp, #0xd0]
      10:      	stp	x26, x25, [sp, #0xe0]
      14:      	stp	x24, x23, [sp, #0xf0]
      18:      	stp	x22, x21, [sp, #0x100]
      1c:      	stp	x20, x19, [sp, #0x110]
      20:      	add	x29, sp, #0xc0
      24:      	mrs	x8, TPIDR_EL0
      28:      	mov	x10, #-0x3333333333333334 // =-3689348814741910324
      2c:      	mov	x19, x0
      30:      	stp	x1, x8, [sp]
      34:      	movk	x10, #0xcccd
      38:      	mov	w28, #0x4a78            // =19064
      3c:      	ldr	x8, [x8, #0x28]
      40:      	stur	x8, [x29, #-0x20]
      44:      	ldr	x9, [x0, #0x4a80]
      48:      	ldr	x8, [x0, #0x4a78]
      4c:      	ldr	x23, [x0, #0x47f0]
      50:      	ldr	x24, [x0, #0x47e8]
      54:      	sub	x9, x9, x8
      58:      	asr	x9, x9, #3
      5c:      	mul	x10, x9, x10
      60:      	sub	x9, x23, x24
      64:      	asr	x9, x9, #2
      68:      	subs	x1, x9, x10
      6c:      	b.ls	0x84 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x84>
      70:      	add	x0, x19, x28
      74:      	bl	0x74 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x74>
      78:      	ldr	x23, [x19, #0x47f0]
      7c:      	ldr	x24, [x19, #0x47e8]
      80:      	b	0x94 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x94>
      84:      	b.hs	0x94 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x94>
      88:      	mov	w10, #0x28              // =40
      8c:      	madd	x8, x9, x10, x8
      90:      	str	x8, [x19, #0x4a80]
      94:      	cmp	x23, x24
      98:      	b.eq	0x21c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x21c>
      9c:      	mov	x25, xzr
      a0:      	adrp	x21, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
      a4:      	add	x21, x21, #0x0
      a8:      	b	0x104 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x104>
      ac:      	mov	x1, xzr
      b0:      	mov	w2, #0xa                // =10
      b4:      	bl	0xb4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xb4>
      b8:      	ldr	x23, [x19, #0x47f0]
      bc:      	cmp	w0, #0x10
      c0:      	ldr	x24, [x19, #0x47e8]
      c4:      	mov	w8, #0x10               // =16
      c8:      	csel	w8, w0, w8, lo
      cc:      	ldr	w9, [x20, #0x1c]
      d0:      	add	x25, x25, #0x1
      d4:      	cmp	w8, w9
      d8:      	csel	w8, w8, w9, lo
      dc:      	cmp	w26, #0x0
      e0:      	str	w8, [x28, #0x8]
      e4:      	sub	x8, x23, x24
      e8:      	csel	x9, xzr, x22, ne
      ec:      	csel	x10, x22, xzr, ne
      f0:      	stp	x27, x9, [x28, #0x10]
      f4:      	cmp	x25, x8, asr #2
      f8:      	str	x10, [x28, #0x20]
      fc:      	mov	w28, #0x4a78            // =19064
     100:      	b.hs	0x21c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x21c>
     104:      	ldr	w8, [x24, x25, lsl #2]
     108:      	ldr	x9, [x19, #0x47d0]
     10c:      	mov	w10, #0x90              // =144
     110:      	mul	w10, w8, w10
     114:      	ldr	w11, [x9, #0x8]
     118:      	add	w10, w10, w11, lsl #1
     11c:      	sub	w10, w10, #0x89
     120:      	add	x20, x9, w10, uxtw #2
     124:      	ldr	w9, [x20, #0x3c]
     128:      	cbnz	w9, 0x168 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x168>
     12c:      	ldr	w10, [x20, #0xc]
     130:      	cmp	w10, #0x800
     134:      	b.ne	0x168 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x168>
     138:      	ldr	w10, [x20, #0x18]
     13c:      	cmp	w10, #0x40
     140:      	b.ne	0x168 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x168>
     144:      	ldr	w10, [x20, #0x1c]
     148:      	cmp	w10, #0x4
     14c:      	cset	w26, eq
     150:      	ldr	w10, [x20]
     154:      	cmp	w9, #0x0
     158:      	cset	w9, ne
     15c:      	cmp	w10, #0x7
     160:      	b.eq	0x180 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x180>
     164:      	b	0x768 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x768>
     168:      	mov	w26, wzr
     16c:      	ldr	w10, [x20]
     170:      	cmp	w9, #0x0
     174:      	cset	w9, ne
     178:      	cmp	w10, #0x7
     17c:      	b.ne	0x768 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x768>
     180:      	orr	w9, w9, w26
     184:      	tbz	w9, #0x0, 0x768 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x768>
     188:      	ldr	w9, [x20, #0xc]
     18c:      	cmp	w9, #0x2, lsl #12       // =0x2000
     190:      	b.hi	0x768 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x768>
     194:      	ldr	x10, [x19, #0x4ce0]
     198:      	ldr	x11, [x19, #0x4ce8]
     19c:      	cmp	x10, x11
     1a0:      	b.eq	0x784 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x784>
     1a4:      	mov	x27, xzr
     1a8:      	mov	x22, xzr
     1ac:      	sub	w8, w8, #0x1
     1b0:      	b	0x1c0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x1c0>
     1b4:      	add	x10, x10, #0x18
     1b8:      	cmp	x10, x11
     1bc:      	b.eq	0x1e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x1e8>
     1c0:      	ldr	w12, [x10]
     1c4:      	cmp	w12, w8
     1c8:      	b.ne	0x1b4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x1b4>
     1cc:      	ldr	w12, [x10, #0x4]
     1d0:      	ldr	x13, [x10, #0x8]
     1d4:      	cmp	w12, #0x4
     1d8:      	csel	x27, x13, x27, eq
     1dc:      	cmp	w12, #0x5
     1e0:      	csel	x22, x13, x22, eq
     1e4:      	b	0x1b4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x1b4>
     1e8:      	cbz	x27, 0x784 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x784>
     1ec:      	cbz	x22, 0x784 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x784>
     1f0:      	mov	w10, #0x28              // =40
     1f4:      	ldr	x8, [x19, x28]
     1f8:      	mov	x0, x21
     1fc:      	madd	x28, x25, x10, x8
     200:      	str	w9, [x28]
     204:      	ldr	w8, [x20, #0x18]
     208:      	str	w8, [x28, #0x4]
     20c:      	bl	0x20c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x20c>
     210:      	cbnz	x0, 0xac <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xac>
     214:      	mov	w8, #0x8                // =8
     218:      	b	0xcc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xcc>
     21c:      	add	x8, sp, #0x38
     220:      	stp	xzr, xzr, [sp, #0x38]
     224:      	str	xzr, [sp, #0x48]
     228:      	str	x8, [sp, #0x58]
     22c:      	strb	wzr, [sp, #0x60]
     230:      	mov	w0, #0x60               // =96
     234:      	bl	0x234 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x234>
     238:      	movi	v0.2d, #0000000000000000
     23c:      	add	x8, x0, #0x60
     240:      	ldr	x9, [x19, x28]
     244:      	stp	x8, x8, [sp, #0x40]
     248:      	mov	x21, x0
     24c:      	str	x0, [sp, #0x38]
     250:      	stp	q0, q0, [x0]
     254:      	stp	q0, q0, [x0, #0x20]
     258:      	stp	q0, q0, [x0, #0x40]
     25c:      	ldr	w1, [x9]
     260:      	cbz	w1, 0x294 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x294>
     264:      	mov	x0, x21
     268:      	bl	0x268 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x268>
     26c:      	ldr	x8, [x19, x28]
     270:      	ldp	x9, x10, [x21, #0x30]
     274:      	ldr	w8, [x8]
     278:      	sub	x10, x10, x9
     27c:      	asr	x10, x10, #2
     280:      	subs	x1, x8, x10
     284:      	b.ls	0x2ac <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x2ac>
     288:      	add	x0, x21, #0x30
     28c:      	bl	0x28c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x28c>
     290:      	b	0x2b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x2b8>
     294:      	mov	x8, xzr
     298:      	mov	x9, xzr
     29c:      	neg	x10, xzr
     2a0:      	asr	x10, x10, #2
     2a4:      	negs	x1, x10
     2a8:      	b.hi	0x288 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x288>
     2ac:      	b.hs	0x2b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x2b8>
     2b0:      	add	x8, x9, x8, lsl #2
     2b4:      	str	x8, [x21, #0x38]
     2b8:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     2bc:      	add	x0, x0, #0x0
     2c0:      	bl	0x2c0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x2c0>
     2c4:      	cbz	x0, 0x374 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x374>
     2c8:      	mov	x1, xzr
     2cc:      	bl	0x2cc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x2cc>
     2d0:      	fmov	s8, s0
     2d4:      	mov	w8, #0x7fffff           // =8388607
     2d8:      	fmov	w9, s8
     2dc:      	and	w10, w9, #0x7fffffff
     2e0:      	sub	w11, w10, #0x800, lsl #12 // =0x800000
     2e4:      	sub	w12, w10, #0x1
     2e8:      	lsr	w11, w11, #24
     2ec:      	cmp	w12, w8
     2f0:      	cset	w8, lo
     2f4:      	cmp	w11, #0x7f
     2f8:      	cset	w11, lo
     2fc:      	cmp	w9, #0x0
     300:      	mov	w9, #0x7f800000         // =2139095040
     304:      	csel	w11, wzr, w11, ge
     308:      	csel	w8, wzr, w8, ge
     30c:      	cmp	w10, w9
     310:      	csinc	w8, w8, wzr, ne
     314:      	csinc	w8, w8, wzr, le
     318:      	orr	w8, w8, w11
     31c:      	tbnz	w8, #0x0, 0x820 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x820>
     320:      	fmov	s0, #1.00000000
     324:      	fcmp	s8, s0
     328:      	b.gt	0x820 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x820>
     32c:      	fcmp	s8, #0.0
     330:      	b.le	0x374 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x374>
     334:      	mov	w0, #0x20               // =32
     338:      	bl	0x338 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x338>
     33c:      	ldr	x8, [x19, #0x4a80]
     340:      	ldr	x9, [x19, #0x4a78]
     344:      	mov	x21, x0
     348:      	sub	x8, x8, x9
     34c:      	mov	x9, #-0x3333333333333334 // =-3689348814741910324
     350:      	asr	x8, x8, #3
     354:      	movk	x9, #0xcccd
     358:      	mul	x1, x8, x9
     35c:      	bl	0x35c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x35c>
     360:      	mov	w8, #0x4a90             // =19088
     364:      	mov	x1, x21
     368:      	str	s8, [x21, #0x18]
     36c:      	add	x0, x19, x8
     370:      	bl	0x370 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x370>
     374:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     378:      	add	x0, x0, #0x0
     37c:      	bl	0x37c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x37c>
     380:      	cbz	x0, 0x394 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x394>
     384:      	mov	x1, xzr
     388:      	bl	0x388 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x388>
     38c:      	fmov	s8, s0
     390:      	b	0x398 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x398>
     394:      	fmov	s8, #0.50000000
     398:      	fmov	w8, s8
     39c:      	mov	w12, #0x7fffff          // =8388607
     3a0:      	and	w9, w8, #0x7fffffff
     3a4:      	sub	w10, w9, #0x800, lsl #12 // =0x800000
     3a8:      	sub	w11, w9, #0x1
     3ac:      	lsr	w10, w10, #24
     3b0:      	cmp	w11, w12
     3b4:      	cset	w11, lo
     3b8:      	cmp	w10, #0x7f
     3bc:      	cset	w10, lo
     3c0:      	cmp	w8, #0x0
     3c4:      	mov	w8, #0x7f800000         // =2139095040
     3c8:      	csel	w10, wzr, w10, ge
     3cc:      	csel	w11, wzr, w11, ge
     3d0:      	cmp	w9, w8
     3d4:      	csinc	w8, w11, wzr, ne
     3d8:      	csinc	w8, w8, wzr, le
     3dc:      	orr	w8, w8, w10
     3e0:      	tbnz	w8, #0x0, 0x7c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x7c8>
     3e4:      	fmov	s0, #1.00000000
     3e8:      	fcmp	s8, s0
     3ec:      	b.gt	0x7c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x7c8>
     3f0:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     3f4:      	add	x0, x0, #0x0
     3f8:      	stp	xzr, xzr, [sp, #0x28]
     3fc:      	bl	0x3fc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x3fc>
     400:      	cbz	x0, 0x44c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x44c>
     404:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     408:      	add	x1, x1, #0x0
     40c:      	bl	0x40c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x40c>
     410:      	cbz	x0, 0x878 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x878>
     414:      	mov	x21, x0
     418:      	mov	w0, #0x28               // =40
     41c:      	bl	0x41c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x41c>
     420:      	adrp	x8, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     424:      	adrp	x9, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     428:      	mov	x22, x0
     42c:      	ldr	x8, [x8]
     430:      	stp	xzr, x21, [x0, #0x10]
     434:      	ldr	x9, [x9]
     438:      	stp	x21, x0, [sp, #0x28]
     43c:      	add	x8, x8, #0x10
     440:      	stp	x8, xzr, [x0]
     444:      	str	x9, [x0, #0x20]
     448:      	b	0x454 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x454>
     44c:      	mov	x22, xzr
     450:      	mov	x21, xzr
     454:      	ldr	x24, [x19, #0x4a80]
     458:      	ldr	x20, [x19, #0x4a78]
     45c:      	mov	w0, #0x60               // =96
     460:      	bl	0x460 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x460>
     464:      	sub	x8, x24, x20
     468:      	adrp	x9, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     46c:      	mov	w10, #0xcccd            // =52429
     470:      	ldr	x9, [x9]
     474:      	lsr	x8, x8, #3
     478:      	movk	w10, #0xcccc, lsl #16
     47c:      	stp	xzr, xzr, [x0, #0x8]
     480:      	mov	x23, x0
     484:      	add	x24, x0, #0x18
     488:      	add	x9, x9, #0x10
     48c:      	mul	w1, w8, w10
     490:      	str	x9, [x0]
     494:      	ldr	w2, [x20]
     498:      	mov	x0, x24
     49c:      	bl	0x49c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x49c>
     4a0:      	ldr	x8, [x19, #0x4848]
     4a4:      	stp	x24, x23, [sp, #0x18]
     4a8:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     4ac:      	add	x0, x0, #0x0
     4b0:      	ldr	x20, [x8]
     4b4:      	bl	0x4b4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4b4>
     4b8:      	cbz	x0, 0x4d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d0>
     4bc:      	ldrb	w8, [x0]
     4c0:      	cmp	w8, #0x31
     4c4:      	b.ne	0x4d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d0>
     4c8:      	ldrb	w8, [x0, #0x1]
     4cc:      	cbz	w8, 0x730 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x730>
     4d0:      	ldr	x9, [sp]
     4d4:      	mov	w26, wzr
     4d8:      	mov	w8, #0x1                // =1
     4dc:      	stp	x19, xzr, [sp, #0x58]
     4e0:      	str	w8, [sp, #0x14]
     4e4:      	ldp	x25, x8, [x9]
     4e8:      	stp	xzr, xzr, [sp, #0x68]
     4ec:      	subs	x20, x8, x25
     4f0:      	b.eq	0x51c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x51c>
     4f4:      	tbnz	x20, #0x3f, 0x8bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8bc>
     4f8:      	mov	x0, x20
     4fc:      	bl	0x4fc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4fc>
     500:      	add	x27, x0, x20
     504:      	mov	x1, x25
     508:      	mov	x2, x20
     50c:      	stp	x0, x0, [sp, #0x60]
     510:      	str	x27, [sp, #0x70]
     514:      	bl	0x514 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x514>
     518:      	str	x27, [sp, #0x68]
     51c:      	str	s8, [sp, #0x78]
     520:      	add	x8, x23, #0x8
     524:      	mov	w9, #0x1                // =1
     528:      	strb	w26, [sp, #0x7c]
     52c:      	stp	x24, x23, [sp, #0x80]
     530:      	add	x23, sp, #0x58
     534:      	ldadd	x9, x8, [x8]
     538:      	str	x21, [sp, #0x90]
     53c:      	str	x22, [x23, #0x40]
     540:      	cbz	x22, 0x550 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x550>
     544:      	add	x8, x22, #0x8
     548:      	mov	w9, #0x1                // =1
     54c:      	ldadd	x9, x8, [x8]
     550:      	mov	w0, #0x1a0              // =416
     554:      	bl	0x554 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x554>
     558:      	adrp	x8, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     55c:      	mov	x20, x0
     560:      	add	x21, x0, #0x20
     564:      	ldr	x8, [x8]
     568:      	stp	xzr, xzr, [x0, #0x8]
     56c:      	add	x8, x8, #0x10
     570:      	str	x8, [x0]
     574:      	add	x0, sp, #0x57
     578:      	add	x2, sp, #0x38
     57c:      	add	x3, sp, #0x14
     580:      	add	x4, sp, #0x58
     584:      	mov	x1, x21
     588:      	bl	0x588 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x588>
     58c:      	ldr	x22, [x19, #0x4a70]
     590:      	str	x21, [x19, #0x4a68]
     594:      	str	x20, [x19, #0x4a70]
     598:      	cbz	x22, 0x5c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5c4>
     59c:      	add	x8, x22, #0x8
     5a0:      	mov	x9, #-0x1               // =-1
     5a4:      	ldaddal	x9, x8, [x8]
     5a8:      	cbnz	x8, 0x5c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5c4>
     5ac:      	ldr	x8, [x22]
     5b0:      	mov	x0, x22
     5b4:      	ldr	x8, [x8, #0x10]
     5b8:      	blr	x8
     5bc:      	mov	x0, x22
     5c0:      	bl	0x5c0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5c0>
     5c4:      	ldr	x19, [x23, #0x40]
     5c8:      	cbz	x19, 0x5f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5f4>
     5cc:      	add	x8, x19, #0x8
     5d0:      	mov	x9, #-0x1               // =-1
     5d4:      	ldaddal	x9, x8, [x8]
     5d8:      	cbnz	x8, 0x5f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5f4>
     5dc:      	ldr	x8, [x19]
     5e0:      	mov	x0, x19
     5e4:      	ldr	x8, [x8, #0x10]
     5e8:      	blr	x8
     5ec:      	mov	x0, x19
     5f0:      	bl	0x5f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x5f0>
     5f4:      	ldr	x19, [sp, #0x88]
     5f8:      	cbz	x19, 0x624 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x624>
     5fc:      	add	x8, x19, #0x8
     600:      	mov	x9, #-0x1               // =-1
     604:      	ldaddal	x9, x8, [x8]
     608:      	cbnz	x8, 0x624 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x624>
     60c:      	ldr	x8, [x19]
     610:      	mov	x0, x19
     614:      	ldr	x8, [x8, #0x10]
     618:      	blr	x8
     61c:      	mov	x0, x19
     620:      	bl	0x620 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x620>
     624:      	ldr	x0, [sp, #0x60]
     628:      	cbz	x0, 0x63c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x63c>
     62c:      	ldr	x8, [sp, #0x70]
     630:      	str	x0, [sp, #0x68]
     634:      	sub	x1, x8, x0
     638:      	bl	0x638 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x638>
     63c:      	ldr	x19, [sp, #0x20]
     640:      	cbz	x19, 0x66c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x66c>
     644:      	add	x8, x19, #0x8
     648:      	mov	x9, #-0x1               // =-1
     64c:      	ldaddal	x9, x8, [x8]
     650:      	cbnz	x8, 0x66c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x66c>
     654:      	ldr	x8, [x19]
     658:      	mov	x0, x19
     65c:      	ldr	x8, [x8, #0x10]
     660:      	blr	x8
     664:      	mov	x0, x19
     668:      	bl	0x668 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x668>
     66c:      	ldr	x19, [sp, #0x30]
     670:      	cbz	x19, 0x69c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x69c>
     674:      	add	x8, x19, #0x8
     678:      	mov	x9, #-0x1               // =-1
     67c:      	ldaddal	x9, x8, [x8]
     680:      	cbnz	x8, 0x69c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x69c>
     684:      	ldr	x8, [x19]
     688:      	mov	x0, x19
     68c:      	ldr	x8, [x8, #0x10]
     690:      	blr	x8
     694:      	mov	x0, x19
     698:      	bl	0x698 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x698>
     69c:      	ldr	x19, [sp, #0x38]
     6a0:      	cbz	x19, 0x6f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6f8>
     6a4:      	ldr	x8, [sp, #0x40]
     6a8:      	mov	x0, x19
     6ac:      	cmp	x19, x8
     6b0:      	b.eq	0x6e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6e8>
     6b4:      	mov	x20, x8
     6b8:      	b	0x6c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6c8>
     6bc:      	cmp	x20, x19
     6c0:      	mov	x8, x20
     6c4:      	b.eq	0x6e4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6e4>
     6c8:      	ldr	x0, [x20, #-0x30]!
     6cc:      	cbz	x0, 0x6bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6bc>
     6d0:      	ldur	x9, [x8, #-0x20]
     6d4:      	stur	x0, [x8, #-0x28]
     6d8:      	sub	x1, x9, x0
     6dc:      	bl	0x6dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6dc>
     6e0:      	b	0x6bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6bc>
     6e4:      	ldr	x0, [sp, #0x38]
     6e8:      	ldr	x8, [sp, #0x48]
     6ec:      	str	x19, [sp, #0x40]
     6f0:      	sub	x1, x8, x0
     6f4:      	bl	0x6f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x6f4>
     6f8:      	ldr	x8, [sp, #0x8]
     6fc:      	ldr	x8, [x8, #0x28]
     700:      	ldur	x9, [x29, #-0x20]
     704:      	cmp	x8, x9
     708:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     70c:      	ldp	x20, x19, [sp, #0x110]
     710:      	ldr	d8, [sp, #0xb0]
     714:      	ldp	x22, x21, [sp, #0x100]
     718:      	ldp	x24, x23, [sp, #0xf0]
     71c:      	ldp	x26, x25, [sp, #0xe0]
     720:      	ldp	x28, x27, [sp, #0xd0]
     724:      	ldp	x29, x30, [sp, #0xc0]
     728:      	add	sp, sp, #0x120
     72c:      	ret
     730:      	ldr	w8, [x20, #0x34]
     734:      	ldr	x9, [sp]
     738:      	cmp	w8, #0x102
     73c:      	b.ne	0x4d4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d4>
     740:      	ldr	w8, [x20, #0x28]
     744:      	cmp	w8, #0x800
     748:      	b.ne	0x4d4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d4>
     74c:      	ldr	w8, [x20, #0x2c]
     750:      	cmp	w8, #0x600
     754:      	b.ne	0x4d4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d4>
     758:      	ldr	w8, [x20, #0x30]
     75c:      	cmp	w8, #0x800
     760:      	cset	w26, eq
     764:      	b	0x4d8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x4d8>
     768:      	mov	w0, #0x10               // =16
     76c:      	bl	0x76c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x76c>
     770:      	mov	x20, x0
     774:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     778:      	add	x1, x1, #0x0
     77c:      	bl	0x77c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x77c>
     780:      	b	0x79c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x79c>
     784:      	mov	w0, #0x10               // =16
     788:      	bl	0x788 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x788>
     78c:      	mov	x20, x0
     790:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     794:      	add	x1, x1, #0x0
     798:      	bl	0x798 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x798>
     79c:      	ldr	x8, [sp, #0x8]
     7a0:      	ldr	x8, [x8, #0x28]
     7a4:      	ldur	x9, [x29, #-0x20]
     7a8:      	cmp	x8, x9
     7ac:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     7b0:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     7b4:      	adrp	x2, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     7b8:      	mov	x0, x20
     7bc:      	ldr	x1, [x1]
     7c0:      	ldr	x2, [x2]
     7c4:      	bl	0x7c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x7c4>
     7c8:      	mov	w0, #0x10               // =16
     7cc:      	bl	0x7cc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x7cc>
     7d0:      	mov	x20, x0
     7d4:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     7d8:      	add	x1, x1, #0x0
     7dc:      	bl	0x7dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x7dc>
     7e0:      	adrp	x8, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     7e4:      	ldr	x8, [x8]
     7e8:      	add	x8, x8, #0x10
     7ec:      	str	x8, [x20]
     7f0:      	ldr	x8, [sp, #0x8]
     7f4:      	ldr	x8, [x8, #0x28]
     7f8:      	ldur	x9, [x29, #-0x20]
     7fc:      	cmp	x8, x9
     800:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     804:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     808:      	adrp	x2, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     80c:      	mov	x0, x20
     810:      	ldr	x1, [x1]
     814:      	ldr	x2, [x2]
     818:      	bl	0x818 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x818>
     81c:      	b	0x8bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8bc>
     820:      	mov	w0, #0x10               // =16
     824:      	bl	0x824 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x824>
     828:      	mov	x20, x0
     82c:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     830:      	add	x1, x1, #0x0
     834:      	bl	0x834 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x834>
     838:      	adrp	x8, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     83c:      	ldr	x8, [x8]
     840:      	add	x8, x8, #0x10
     844:      	str	x8, [x20]
     848:      	ldr	x8, [sp, #0x8]
     84c:      	ldr	x8, [x8, #0x28]
     850:      	ldur	x9, [x29, #-0x20]
     854:      	cmp	x8, x9
     858:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     85c:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     860:      	adrp	x2, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     864:      	mov	x0, x20
     868:      	ldr	x1, [x1]
     86c:      	ldr	x2, [x2]
     870:      	bl	0x870 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x870>
     874:      	b	0x8bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8bc>
     878:      	mov	w0, #0x10               // =16
     87c:      	bl	0x87c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x87c>
     880:      	mov	x20, x0
     884:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     888:      	add	x1, x1, #0x0
     88c:      	bl	0x88c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x88c>
     890:      	ldr	x8, [sp, #0x8]
     894:      	ldr	x8, [x8, #0x28]
     898:      	ldur	x9, [x29, #-0x20]
     89c:      	cmp	x8, x9
     8a0:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     8a4:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     8a8:      	adrp	x2, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)>
     8ac:      	mov	x0, x20
     8b0:      	ldr	x1, [x1]
     8b4:      	ldr	x2, [x2]
     8b8:      	bl	0x8b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8b8>
     8bc:      	ldr	x8, [sp, #0x8]
     8c0:      	ldr	x8, [x8, #0x28]
     8c4:      	ldur	x9, [x29, #-0x20]
     8c8:      	cmp	x8, x9
     8cc:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     8d0:      	bl	0x8d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8d0>
     8d4:      	mov	x19, x0
     8d8:      	b	0x9e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e8>
     8dc:      	mov	x19, x0
     8e0:      	mov	x0, x20
     8e4:      	bl	0x8e4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8e4>
     8e8:      	b	0x9e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e8>
     8ec:      	mov	x19, x0
     8f0:      	mov	x0, x21
     8f4:      	mov	w1, #0x20               // =32
     8f8:      	bl	0x8f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x8f8>
     8fc:      	b	0x9f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f0>
     900:      	b	0x90c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x90c>
     904:      	mov	x19, x0
     908:      	b	0x9f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f0>
     90c:      	mov	x19, x0
     910:      	mov	x0, x20
     914:      	bl	0x914 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x914>
     918:      	b	0x9f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f0>
     91c:      	bl	0x91c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x91c>
     920:      	mov	x0, x21
     924:      	bl	0x924 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x924>
     928:      	ldr	x8, [sp, #0x8]
     92c:      	ldr	x8, [x8, #0x28]
     930:      	ldur	x9, [x29, #-0x20]
     934:      	cmp	x8, x9
     938:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     93c:      	bl	0x93c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x93c>
     940:      	mov	x19, x0
     944:      	bl	0x944 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x944>
     948:      	b	0x9e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e8>
     94c:      	bl	0x94c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x94c>
     950:      	mov	x19, x0
     954:      	b	0x9f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f0>
     958:      	mov	x19, x0
     95c:      	mov	x0, x20
     960:      	bl	0x960 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x960>
     964:      	mov	x0, x20
     968:      	mov	w1, #0x1a0              // =416
     96c:      	bl	0x96c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x96c>
     970:      	b	0x978 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x978>
     974:      	mov	x19, x0
     978:      	add	x0, sp, #0x58
     97c:      	bl	0x97c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x97c>
     980:      	b	0x9e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e0>
     984:      	mov	x19, x0
     988:      	mov	x0, x23
     98c:      	bl	0x98c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x98c>
     990:      	mov	x0, x23
     994:      	mov	w1, #0x60               // =96
     998:      	bl	0x998 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x998>
     99c:      	b	0x9e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e8>
     9a0:      	mov	x19, x0
     9a4:      	b	0x9e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e8>
     9a8:      	mov	x19, x0
     9ac:      	add	x0, sp, #0x58
     9b0:      	bl	0x9b0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9b0>
     9b4:      	b	0xa0c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa0c>
     9b8:      	mov	x19, x0
     9bc:      	b	0x9f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f0>
     9c0:      	ldr	x8, [sp, #0x60]
     9c4:      	mov	x19, x0
     9c8:      	cbz	x8, 0x9e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e0>
     9cc:      	ldr	x9, [sp, #0x70]
     9d0:      	mov	x0, x8
     9d4:      	str	x8, [sp, #0x68]
     9d8:      	sub	x1, x9, x8
     9dc:      	bl	0x9dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9dc>
     9e0:      	add	x0, sp, #0x18
     9e4:      	bl	0x9e4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9e4>
     9e8:      	add	x0, sp, #0x28
     9ec:      	bl	0x9ec <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9ec>
     9f0:      	add	x0, sp, #0x38
     9f4:      	bl	0x9f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0x9f4>
     9f8:      	b	0xa0c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa0c>
     9fc:      	b	0xa00 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa00>
     a00:      	mov	x19, x0
     a04:      	mov	x0, x20
     a08:      	bl	0xa08 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa08>
     a0c:      	ldr	x8, [sp, #0x8]
     a10:      	ldr	x8, [x8, #0x28]
     a14:      	ldur	x9, [x29, #-0x20]
     a18:      	cmp	x8, x9
     a1c:      	b.ne	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>
     a20:      	mov	x0, x19
     a24:      	bl	0xa24 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa24>
     a28:      	bl	0xa28 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)+0xa28>

0000000000000000 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()>:
       0:      	stp	x29, x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	x29, sp
       c:      	ldr	x20, [x0, #0x40]
      10:      	mov	x19, x0
      14:      	cbz	x20, 0x40 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x40>
      18:      	add	x8, x20, #0x8
      1c:      	mov	x9, #-0x1               // =-1
      20:      	ldaddal	x9, x8, [x8]
      24:      	cbnz	x8, 0x40 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x40>
      28:      	ldr	x8, [x20]
      2c:      	mov	x0, x20
      30:      	ldr	x8, [x8, #0x10]
      34:      	blr	x8
      38:      	mov	x0, x20
      3c:      	bl	0x3c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x3c>
      40:      	ldr	x20, [x19, #0x30]
      44:      	cbz	x20, 0x58 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x58>
      48:      	add	x8, x20, #0x8
      4c:      	mov	x9, #-0x1               // =-1
      50:      	ldaddal	x9, x8, [x8]
      54:      	cbz	x8, 0x78 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x78>
      58:      	ldr	x0, [x19, #0x8]
      5c:      	cbz	x0, 0x98 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x98>
      60:      	ldr	x8, [x19, #0x18]
      64:      	sub	x1, x8, x0
      68:      	str	x0, [x19, #0x10]
      6c:      	ldp	x20, x19, [sp, #0x10]
      70:      	ldp	x29, x30, [sp], #0x20
      74:      	b	0x74 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x74>
      78:      	ldr	x8, [x20]
      7c:      	mov	x0, x20
      80:      	ldr	x8, [x8, #0x10]
      84:      	blr	x8
      88:      	mov	x0, x20
      8c:      	bl	0x8c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x8c>
      90:      	ldr	x0, [x19, #0x8]
      94:      	cbnz	x0, 0x60 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::~()+0x60>
      98:      	ldp	x20, x19, [sp, #0x10]
      9c:      	ldp	x29, x30, [sp], #0x20
      a0:      	ret

0000000000000000 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)>:
       0:      	stp	x29, x30, [sp, #-0x40]!
       4:      	stp	x24, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	mov	x29, sp
      14:      	mov	x20, x0
      18:      	str	xzr, [x0, #0x20]
      1c:      	mov	w0, #0x50               // =80
      20:      	mov	x21, x1
      24:      	bl	0x24 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x24>
      28:      	adrp	x8, 0x0 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)>
      2c:      	mov	x19, x0
      30:      	mov	x24, x0
      34:      	ldr	x8, [x8]
      38:      	ldp	x9, x22, [x21]
      3c:      	ldr	x10, [x21, #0x10]
      40:      	str	xzr, [x24, #0x10]!
      44:      	add	x8, x8, #0x10
      48:      	stp	xzr, xzr, [x0, #0x18]
      4c:      	subs	x23, x10, x22
      50:      	stp	x8, x9, [x0]
      54:      	b.eq	0x80 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x80>
      58:      	tbnz	x23, #0x3f, 0xbc <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xbc>
      5c:      	mov	x0, x23
      60:      	bl	0x60 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x60>
      64:      	add	x24, x0, x23
      68:      	mov	x1, x22
      6c:      	mov	x2, x23
      70:      	str	x0, [x19, #0x10]
      74:      	str	x24, [x19, #0x20]
      78:      	bl	0x78 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x78>
      7c:      	str	x24, [x19, #0x18]
      80:      	ldr	w8, [x21, #0x20]
      84:      	ldrb	w9, [x21, #0x24]
      88:      	ldur	q0, [x21, #0x28]
      8c:      	ldur	q1, [x21, #0x38]
      90:      	stp	xzr, xzr, [x21, #0x28]
      94:      	str	w8, [x19, #0x28]
      98:      	strb	w9, [x19, #0x2c]
      9c:      	stp	q0, q1, [x19, #0x30]
      a0:      	stp	xzr, xzr, [x21, #0x38]
      a4:      	str	x19, [x20, #0x20]
      a8:      	ldp	x20, x19, [sp, #0x30]
      ac:      	ldp	x22, x21, [sp, #0x20]
      b0:      	ldp	x24, x23, [sp, #0x10]
      b4:      	ldp	x29, x30, [sp], #0x40
      b8:      	ret
      bc:      	bl	0xbc <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xbc>
      c0:      	ldr	x8, [x24]
      c4:      	mov	x20, x0
      c8:      	cbz	x8, 0xe0 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xe0>
      cc:      	ldr	x9, [x19, #0x20]
      d0:      	mov	x0, x8
      d4:      	str	x8, [x19, #0x18]
      d8:      	sub	x1, x9, x8
      dc:      	bl	0xdc <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xdc>
      e0:      	mov	x0, x19
      e4:      	mov	w1, #0x50               // =80
      e8:      	bl	0xe8 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xe8>
      ec:      	mov	x0, x20
      f0:      	bl	0xf0 <std::__ndk1::__function::__value_func<bool (nntrainer::HtpComputeOps::PredictionJob&)>::__value_func[abi:ne210000]<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>>(nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)&&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xf0>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()>:
       0:      	stp	x29, x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	x29, sp
       c:      	adrp	x8, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()>
      10:      	mov	x19, x0
      14:      	ldr	x8, [x8]
      18:      	ldr	x20, [x0, #0x48]
      1c:      	add	x8, x8, #0x10
      20:      	str	x8, [x0]
      24:      	cbz	x20, 0x50 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x50>
      28:      	add	x8, x20, #0x8
      2c:      	mov	x9, #-0x1               // =-1
      30:      	ldaddal	x9, x8, [x8]
      34:      	cbnz	x8, 0x50 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x50>
      38:      	ldr	x8, [x20]
      3c:      	mov	x0, x20
      40:      	ldr	x8, [x8, #0x10]
      44:      	blr	x8
      48:      	mov	x0, x20
      4c:      	bl	0x4c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x4c>
      50:      	ldr	x20, [x19, #0x38]
      54:      	cbz	x20, 0x68 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x68>
      58:      	add	x8, x20, #0x8
      5c:      	mov	x9, #-0x1               // =-1
      60:      	ldaddal	x9, x8, [x8]
      64:      	cbz	x8, 0x88 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x88>
      68:      	ldr	x0, [x19, #0x10]
      6c:      	cbz	x0, 0xa8 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0xa8>
      70:      	ldr	x8, [x19, #0x20]
      74:      	sub	x1, x8, x0
      78:      	str	x0, [x19, #0x18]
      7c:      	ldp	x20, x19, [sp, #0x10]
      80:      	ldp	x29, x30, [sp], #0x20
      84:      	b	0x84 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x84>
      88:      	ldr	x8, [x20]
      8c:      	mov	x0, x20
      90:      	ldr	x8, [x8, #0x10]
      94:      	blr	x8
      98:      	mov	x0, x20
      9c:      	bl	0x9c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x9c>
      a0:      	ldr	x0, [x19, #0x10]
      a4:      	cbnz	x0, 0x70 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x70>
      a8:      	ldp	x20, x19, [sp, #0x10]
      ac:      	ldp	x29, x30, [sp], #0x20
      b0:      	ret

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()>:
       0:      	stp	x29, x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	x29, sp
       c:      	adrp	x8, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()>
      10:      	mov	x19, x0
      14:      	ldr	x8, [x8]
      18:      	ldr	x20, [x0, #0x48]
      1c:      	add	x8, x8, #0x10
      20:      	str	x8, [x0]
      24:      	cbz	x20, 0x50 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x50>
      28:      	add	x8, x20, #0x8
      2c:      	mov	x9, #-0x1               // =-1
      30:      	ldaddal	x9, x8, [x8]
      34:      	cbnz	x8, 0x50 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x50>
      38:      	ldr	x8, [x20]
      3c:      	mov	x0, x20
      40:      	ldr	x8, [x8, #0x10]
      44:      	blr	x8
      48:      	mov	x0, x20
      4c:      	bl	0x4c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x4c>
      50:      	ldr	x20, [x19, #0x38]
      54:      	cbz	x20, 0x80 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x80>
      58:      	add	x8, x20, #0x8
      5c:      	mov	x9, #-0x1               // =-1
      60:      	ldaddal	x9, x8, [x8]
      64:      	cbnz	x8, 0x80 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x80>
      68:      	ldr	x8, [x20]
      6c:      	mov	x0, x20
      70:      	ldr	x8, [x8, #0x10]
      74:      	blr	x8
      78:      	mov	x0, x20
      7c:      	bl	0x7c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x7c>
      80:      	ldr	x0, [x19, #0x10]
      84:      	cbz	x0, 0x98 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x98>
      88:      	ldr	x8, [x19, #0x20]
      8c:      	str	x0, [x19, #0x18]
      90:      	sub	x1, x8, x0
      94:      	bl	0x94 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0x94>
      98:      	mov	x0, x19
      9c:      	mov	w1, #0x50               // =80
      a0:      	ldp	x20, x19, [sp, #0x10]
      a4:      	ldp	x29, x30, [sp], #0x20
      a8:      	b	0xa8 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::~__func()+0xa8>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const>:
       0:      	sub	sp, sp, #0x40
       4:      	stp	x29, x30, [sp, #0x10]
       8:      	str	x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	add	x29, sp, #0x10
      14:      	mrs	x21, TPIDR_EL0
      18:      	mov	x20, x0
      1c:      	mov	w0, #0x50               // =80
      20:      	ldr	x8, [x21, #0x28]
      24:      	str	x8, [sp, #0x8]
      28:      	bl	0x28 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x28>
      2c:      	adrp	x8, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const>
      30:      	mov	x19, x0
      34:      	ldr	x8, [x8]
      38:      	add	x8, x8, #0x10
      3c:      	str	x8, [x0], #0x8
      40:      	add	x1, x20, #0x8
      44:      	add	x2, sp, #0x7
      48:      	bl	0x48 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x48>
      4c:      	ldr	x8, [x21, #0x28]
      50:      	ldr	x9, [sp, #0x8]
      54:      	cmp	x8, x9
      58:      	b.ne	0x9c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x9c>
      5c:      	mov	x0, x19
      60:      	ldp	x20, x19, [sp, #0x30]
      64:      	ldr	x21, [sp, #0x20]
      68:      	ldp	x29, x30, [sp, #0x10]
      6c:      	add	sp, sp, #0x40
      70:      	ret
      74:      	mov	x20, x0
      78:      	mov	x0, x19
      7c:      	mov	w1, #0x50               // =80
      80:      	bl	0x80 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x80>
      84:      	ldr	x8, [x21, #0x28]
      88:      	ldr	x9, [sp, #0x8]
      8c:      	cmp	x8, x9
      90:      	b.ne	0x9c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x9c>
      94:      	mov	x0, x20
      98:      	bl	0x98 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x98>
      9c:      	bl	0x9c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone() const+0x9c>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone(std::__ndk1::__function::__base<bool (nntrainer::HtpComputeOps::PredictionJob&)>*) const>:
       0:      	adrp	x9, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone(std::__ndk1::__function::__base<bool (nntrainer::HtpComputeOps::PredictionJob&)>*) const>
       4:      	mov	x8, x1
       8:      	add	x1, x0, #0x8
       c:      	ldr	x9, [x9]
      10:      	add	x2, x0, #0x8
      14:      	add	x9, x9, #0x10
      18:      	str	x9, [x8], #0x8
      1c:      	mov	x0, x8
      20:      	b	0x20 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__clone(std::__ndk1::__function::__base<bool (nntrainer::HtpComputeOps::PredictionJob&)>*) const+0x20>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()>:
       0:      	stp	x29, x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	x29, sp
       c:      	ldr	x20, [x0, #0x48]
      10:      	mov	x19, x0
      14:      	cbz	x20, 0x40 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x40>
      18:      	add	x8, x20, #0x8
      1c:      	mov	x9, #-0x1               // =-1
      20:      	ldaddal	x9, x8, [x8]
      24:      	cbnz	x8, 0x40 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x40>
      28:      	ldr	x8, [x20]
      2c:      	mov	x0, x20
      30:      	ldr	x8, [x8, #0x10]
      34:      	blr	x8
      38:      	mov	x0, x20
      3c:      	bl	0x3c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x3c>
      40:      	ldr	x20, [x19, #0x38]
      44:      	cbz	x20, 0x58 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x58>
      48:      	add	x8, x20, #0x8
      4c:      	mov	x9, #-0x1               // =-1
      50:      	ldaddal	x9, x8, [x8]
      54:      	cbz	x8, 0x78 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x78>
      58:      	ldr	x0, [x19, #0x10]
      5c:      	cbz	x0, 0x98 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x98>
      60:      	ldr	x8, [x19, #0x20]
      64:      	sub	x1, x8, x0
      68:      	str	x0, [x19, #0x18]
      6c:      	ldp	x20, x19, [sp, #0x10]
      70:      	ldp	x29, x30, [sp], #0x20
      74:      	b	0x74 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x74>
      78:      	ldr	x8, [x20]
      7c:      	mov	x0, x20
      80:      	ldr	x8, [x8, #0x10]
      84:      	blr	x8
      88:      	mov	x0, x20
      8c:      	bl	0x8c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x8c>
      90:      	ldr	x0, [x19, #0x10]
      94:      	cbnz	x0, 0x60 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy()+0x60>
      98:      	ldp	x20, x19, [sp, #0x10]
      9c:      	ldp	x29, x30, [sp], #0x20
      a0:      	ret

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()>:
       0:      	stp	x29, x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	x29, sp
       c:      	ldr	x20, [x0, #0x48]
      10:      	mov	x19, x0
      14:      	cbz	x20, 0x40 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x40>
      18:      	add	x8, x20, #0x8
      1c:      	mov	x9, #-0x1               // =-1
      20:      	ldaddal	x9, x8, [x8]
      24:      	cbnz	x8, 0x40 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x40>
      28:      	ldr	x8, [x20]
      2c:      	mov	x0, x20
      30:      	ldr	x8, [x8, #0x10]
      34:      	blr	x8
      38:      	mov	x0, x20
      3c:      	bl	0x3c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x3c>
      40:      	ldr	x20, [x19, #0x38]
      44:      	cbz	x20, 0x70 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x70>
      48:      	add	x8, x20, #0x8
      4c:      	mov	x9, #-0x1               // =-1
      50:      	ldaddal	x9, x8, [x8]
      54:      	cbnz	x8, 0x70 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x70>
      58:      	ldr	x8, [x20]
      5c:      	mov	x0, x20
      60:      	ldr	x8, [x8, #0x10]
      64:      	blr	x8
      68:      	mov	x0, x20
      6c:      	bl	0x6c <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x6c>
      70:      	ldr	x0, [x19, #0x10]
      74:      	cbz	x0, 0x88 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x88>
      78:      	ldr	x8, [x19, #0x20]
      7c:      	str	x0, [x19, #0x18]
      80:      	sub	x1, x8, x0
      84:      	bl	0x84 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x84>
      88:      	mov	x0, x19
      8c:      	mov	w1, #0x50               // =80
      90:      	ldp	x20, x19, [sp, #0x10]
      94:      	ldp	x29, x30, [sp], #0x20
      98:      	b	0x98 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::destroy_deallocate()+0x98>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::operator()(nntrainer::HtpComputeOps::PredictionJob&)>:
       0:      	add	x0, x0, #0x8
       4:      	b	0x4 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::operator()(nntrainer::HtpComputeOps::PredictionJob&)+0x4>

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::target(std::type_info const&) const>:
       0:      	adrp	x9, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::target(std::type_info const&) const>
       4:      	ldr	x8, [x1, #0x8]
       8:      	add	x10, x0, #0x8
       c:      	ldr	x9, [x9]
      10:      	cmp	x8, x9
      14:      	csel	x0, x10, xzr, eq
      18:      	ret

0000000000000000 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::target_type() const>:
       0:      	adrp	x0, 0x0 <std::__ndk1::__function::__func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::target_type() const>
       4:      	ldr	x0, [x0]
       8:      	ret

0000000000000000 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)>:
       0:      	stp	x29, x30, [sp, #-0x40]!
       4:      	str	x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	mov	x29, sp
      14:      	mov	x23, x0
      18:      	ldr	x8, [x1]
      1c:      	stp	xzr, xzr, [x0, #0x10]
      20:      	str	xzr, [x23, #0x8]!
      24:      	mov	x20, x1
      28:      	ldp	x21, x9, [x1, #0x8]
      2c:      	mov	x19, x0
      30:      	str	x8, [x0]
      34:      	subs	x22, x9, x21
      38:      	b.eq	0x64 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0x64>
      3c:      	tbnz	x22, #0x3f, 0xc0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xc0>
      40:      	mov	x0, x22
      44:      	bl	0x44 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0x44>
      48:      	add	x23, x0, x22
      4c:      	mov	x1, x21
      50:      	mov	x2, x22
      54:      	stp	x0, x0, [x19, #0x8]
      58:      	str	x23, [x19, #0x18]
      5c:      	bl	0x5c <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0x5c>
      60:      	str	x23, [x19, #0x10]
      64:      	ldrb	w8, [x20, #0x24]
      68:      	ldr	w9, [x20, #0x20]
      6c:      	strb	w8, [x19, #0x24]
      70:      	str	w9, [x19, #0x20]
      74:      	ldr	x8, [x20, #0x30]
      78:      	ldur	q0, [x20, #0x28]
      7c:      	stur	q0, [x19, #0x28]
      80:      	cbz	x8, 0x90 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0x90>
      84:      	add	x8, x8, #0x8
      88:      	mov	w9, #0x1                // =1
      8c:      	ldadd	x9, x8, [x8]
      90:      	ldr	x8, [x20, #0x40]
      94:      	ldur	q0, [x20, #0x38]
      98:      	stur	q0, [x19, #0x38]
      9c:      	cbz	x8, 0xac <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xac>
      a0:      	add	x8, x8, #0x8
      a4:      	mov	w9, #0x1                // =1
      a8:      	ldadd	x9, x8, [x8]
      ac:      	ldp	x20, x19, [sp, #0x30]
      b0:      	ldr	x23, [sp, #0x10]
      b4:      	ldp	x22, x21, [sp, #0x20]
      b8:      	ldp	x29, x30, [sp], #0x40
      bc:      	ret
      c0:      	bl	0xc0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xc0>
      c4:      	ldr	x8, [x23]
      c8:      	mov	x20, x0
      cc:      	cbz	x8, 0xe4 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xe4>
      d0:      	ldr	x9, [x19, #0x18]
      d4:      	mov	x0, x8
      d8:      	str	x8, [x19, #0x10]
      dc:      	sub	x1, x9, x8
      e0:      	bl	0xe0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xe0>
      e4:      	mov	x0, x20
      e8:      	bl	0xe8 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>&&)+0xe8>

0000000000000000 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)>:
       0:      	stp	x29, x30, [sp, #-0x40]!
       4:      	str	x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	mov	x29, sp
      14:      	mov	x23, x0
      18:      	ldr	x8, [x1]
      1c:      	stp	xzr, xzr, [x0, #0x10]
      20:      	str	xzr, [x23, #0x8]!
      24:      	mov	x20, x1
      28:      	ldp	x21, x9, [x1, #0x8]
      2c:      	mov	x19, x0
      30:      	str	x8, [x0]
      34:      	subs	x22, x9, x21
      38:      	b.eq	0x64 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x64>
      3c:      	tbnz	x22, #0x3f, 0xc0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xc0>
      40:      	mov	x0, x22
      44:      	bl	0x44 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x44>
      48:      	add	x23, x0, x22
      4c:      	mov	x1, x21
      50:      	mov	x2, x22
      54:      	stp	x0, x0, [x19, #0x8]
      58:      	str	x23, [x19, #0x18]
      5c:      	bl	0x5c <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x5c>
      60:      	str	x23, [x19, #0x10]
      64:      	ldrb	w8, [x20, #0x24]
      68:      	ldr	w9, [x20, #0x20]
      6c:      	strb	w8, [x19, #0x24]
      70:      	str	w9, [x19, #0x20]
      74:      	ldr	x8, [x20, #0x30]
      78:      	ldur	q0, [x20, #0x28]
      7c:      	stur	q0, [x19, #0x28]
      80:      	cbz	x8, 0x90 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0x90>
      84:      	add	x8, x8, #0x8
      88:      	mov	w9, #0x1                // =1
      8c:      	ldadd	x9, x8, [x8]
      90:      	ldr	x8, [x20, #0x40]
      94:      	ldur	q0, [x20, #0x38]
      98:      	stur	q0, [x19, #0x38]
      9c:      	cbz	x8, 0xac <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xac>
      a0:      	add	x8, x8, #0x8
      a4:      	mov	w9, #0x1                // =1
      a8:      	ldadd	x9, x8, [x8]
      ac:      	ldp	x20, x19, [sp, #0x30]
      b0:      	ldr	x23, [sp, #0x10]
      b4:      	ldp	x22, x21, [sp, #0x20]
      b8:      	ldp	x29, x30, [sp], #0x40
      bc:      	ret
      c0:      	bl	0xc0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xc0>
      c4:      	ldr	x8, [x23]
      c8:      	mov	x20, x0
      cc:      	cbz	x8, 0xe4 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xe4>
      d0:      	ldr	x9, [x19, #0x18]
      d4:      	mov	x0, x8
      d8:      	str	x8, [x19, #0x10]
      dc:      	sub	x1, x9, x8
      e0:      	bl	0xe0 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xe0>
      e4:      	mov	x0, x20
      e8:      	bl	0xe8 <std::__ndk1::__function::__alloc_func<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&), std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)>, bool (nntrainer::HtpComputeOps::PredictionJob&)>::__alloc_func[abi:ne210000](nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&) const&, std::__ndk1::allocator<nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)> const&)+0xe8>

0000000000000000 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>:
       0:      	sub	sp, sp, #0x150
       4:      	str	d8, [sp, #0xe0]
       8:      	stp	x29, x30, [sp, #0xf0]
       c:      	stp	x28, x27, [sp, #0x100]
      10:      	stp	x26, x25, [sp, #0x110]
      14:      	stp	x24, x23, [sp, #0x120]
      18:      	stp	x22, x21, [sp, #0x130]
      1c:      	stp	x20, x19, [sp, #0x140]
      20:      	add	x29, sp, #0xf0
      24:      	mrs	x22, TPIDR_EL0
      28:      	mov	x21, x0
      2c:      	mov	x20, x1
      30:      	ldr	x8, [x22, #0x28]
      34:      	stur	x8, [x29, #-0x20]
      38:      	ldr	x27, [x0]
      3c:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
      40:      	ldr	x1, [x0]
      44:      	add	x0, x0, #0x0
      48:      	blr	x1
      4c:      	ldrb	w8, [x22, x0]
      50:      	tbnz	w8, #0x0, 0xd4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd4>
      54:      	ldp	x8, x9, [x21, #0x8]
      58:      	cmp	x8, x9
      5c:      	b.eq	0xcc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xcc>
      60:      	movi	v0.2d, #0000000000000000
      64:      	mov	x19, x0
      68:      	mov	w10, #0x1               // =1
      6c:      	add	x11, sp, #0x50
      70:      	stp	q0, q0, [sp, #0x50]
      74:      	stp	q0, q0, [sp, #0x70]
      78:      	stp	q0, q0, [sp, #0x90]
      7c:      	stp	q0, q0, [sp, #0xb0]
      80:      	b	0x90 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x90>
      84:      	add	x8, x8, #0x4
      88:      	cmp	x8, x9
      8c:      	b.eq	0xb8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xb8>
      90:      	ldr	w12, [x8]
      94:      	cmp	w12, #0x3ff
      98:      	b.hi	0x84 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x84>
      9c:      	lsr	x13, x12, #3
      a0:      	lsl	x12, x10, x12
      a4:      	and	x13, x13, #0x1ffffff8
      a8:      	ldr	x14, [x11, x13]
      ac:      	orr	x12, x14, x12
      b0:      	str	x12, [x11, x13]
      b4:      	b	0x84 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x84>
      b8:      	add	x2, sp, #0x50
      bc:      	mov	w0, wzr
      c0:      	mov	w1, #0x80               // =128
      c4:      	bl	0xc4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc4>
      c8:      	mov	x0, x19
      cc:      	mov	w8, #0x1                // =1
      d0:      	strb	w8, [x22, x0]
      d4:      	ldp	x23, x10, [x20, #0x18]
      d8:      	mov	w8, #0x28               // =40
      dc:      	ldr	x9, [x27, #0x4a78]
      e0:      	str	x22, [sp, #0x10]
      e4:      	nop
      e8:      	madd	x28, x23, x8, x9
      ec:      	lsr	x25, x10, #32
      f0:      	ldr	w8, [x28]
      f4:      	cbz	w8, 0x138 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x138>
      f8:      	lsl	x24, x8, #2
      fc:      	mov	x0, x24
     100:      	bl	0x100 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x100>
     104:      	add	x8, x0, x24
     108:      	mov	w1, wzr
     10c:      	mov	x2, x24
     110:      	mov	x19, x0
     114:      	str	x8, [sp, #0x8]
     118:      	bl	0x118 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x118>
     11c:      	ldr	x22, [x21, #0x28]
     120:      	ldr	x1, [x20]
     124:      	sub	w24, w23, #0x1
     128:      	ldrb	w8, [x22, #0x40]
     12c:      	cmp	w8, #0x1
     130:      	b.eq	0x158 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x158>
     134:      	b	0x200 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x200>
     138:      	str	xzr, [sp, #0x8]
     13c:      	mov	x19, xzr
     140:      	ldr	x22, [x21, #0x28]
     144:      	ldr	x1, [x20]
     148:      	sub	w24, w23, #0x1
     14c:      	ldrb	w8, [x22, #0x40]
     150:      	cmp	w8, #0x1
     154:      	b.ne	0x200 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x200>
     158:      	ldr	x8, [x22, #0x38]
     15c:      	cmp	x25, x8
     160:      	b.ne	0x200 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x200>
     164:      	ldr	w8, [x22, #0x30]
     168:      	add	w8, w8, #0x2
     16c:      	cmp	w8, w23
     170:      	b.ne	0x200 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x200>
     174:      	ldp	x8, x9, [x22]
     178:      	mov	x10, #-0x3333333333333334 // =-3689348814741910324
     17c:      	movk	x10, #0xcccd
     180:      	sub	x9, x9, x8
     184:      	asr	x9, x9, #3
     188:      	mul	x9, x9, x10
     18c:      	cmp	x9, x24
     190:      	b.ls	0x200 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x200>
     194:      	mov	w10, #0x28              // =40
     198:      	ldp	x9, x11, [x22, #0x18]
     19c:      	nop
     1a0:      	umaddl	x8, w24, w10, x8
     1a4:      	subs	x10, x11, x9
     1a8:      	b.eq	0x1f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1f4>
     1ac:      	asr	x13, x10, #2
     1b0:      	ldr	x10, [x8]
     1b4:      	cmp	x13, #0x1
     1b8:      	csinc	x11, x13, xzr, hi
     1bc:      	cmp	x13, #0x8
     1c0:      	b.hs	0xbe8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xbe8>
     1c4:      	mov	x12, xzr
     1c8:      	lsl	x13, x12, #2
     1cc:      	sub	x11, x11, x12
     1d0:      	add	x10, x10, x13
     1d4:      	add	x9, x9, x13
     1d8:      	add	x12, x1, x13
     1dc:      	ldr	s0, [x12], #0x4
     1e0:      	subs	x11, x11, #0x1
     1e4:      	ldr	s1, [x9], #0x4
     1e8:      	fsub	s0, s0, s1
     1ec:      	str	s0, [x10], #0x4
     1f0:      	b.ne	0x1dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1dc>
     1f4:      	mov	w9, #0x1                // =1
     1f8:      	str	x25, [x8, #0x18]
     1fc:      	strb	w9, [x8, #0x20]
     200:      	ldp	x0, x8, [x22, #0x18]
     204:      	subs	x2, x8, x0
     208:      	b.eq	0x214 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x214>
     20c:      	bl	0x20c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x20c>
     210:      	ldr	x23, [x20, #0x18]
     214:      	mov	w8, #0x1                // =1
     218:      	str	w24, [x22, #0x30]
     21c:      	str	x25, [x22, #0x38]
     220:      	strb	w8, [x22, #0x40]
     224:      	ldr	x0, [x21, #0x38]
     228:      	cbz	x0, 0x578 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x578>
     22c:      	adrp	x1, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
     230:      	add	x1, x1, #0x0
     234:      	mov	x2, x25
     238:      	mov	x3, x23
     23c:      	bl	0x23c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x23c>
     240:      	movi	d8, #0000000000000000
     244:      	movi	v2.2d, #0000000000000000
     248:      	adrp	x8, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
     24c:      	ldr	d0, [x8]
     250:      	sub	x9, x25, #0x1
     254:      	mov	x26, xzr
     258:      	mov	w8, #0x3f800000         // =1065353216
     25c:      	stp	x9, x25, [sp, #0x18]
     260:      	add	x9, x19, #0x10
     264:      	adrp	x23, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
     268:      	add	x23, x23, #0x0
     26c:      	adrp	x24, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
     270:      	add	x24, x24, #0x0
     274:      	str	d0, [sp, #0x38]
     278:      	str	x9, [sp, #0x28]
     27c:      	str	w8, [sp, #0x40]
     280:      	b	0x294 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x294>
     284:      	movi	v2.2d, #0000000000000000
     288:      	add	x26, x26, #0x4
     28c:      	cmp	x26, #0xc
     290:      	b.eq	0x564 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x564>
     294:      	ldr	x8, [x21, #0x28]
     298:      	mov	x11, #-0x3333333333333334 // =-3689348814741910324
     29c:      	movk	x11, #0xcccd
     2a0:      	ldp	x9, x10, [x8]
     2a4:      	sub	x10, x10, x9
     2a8:      	asr	x10, x10, #3
     2ac:      	mul	x11, x10, x11
     2b0:      	ldr	w10, [x20, #0x18]
     2b4:      	cmp	x11, x10
     2b8:      	b.ls	0x2f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x2f0>
     2bc:      	cbz	x9, 0x2f0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x2f0>
     2c0:      	mov	w11, #0x28              // =40
     2c4:      	umaddl	x10, w10, w11, x9
     2c8:      	ldr	x9, [sp, #0x20]
     2cc:      	mov	w11, wzr
     2d0:      	cbz	x9, 0x2f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x2f8>
     2d4:      	ldrb	w9, [x10, #0x20]
     2d8:      	tbz	w9, #0x0, 0x2f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x2f8>
     2dc:      	ldr	x9, [x10, #0x18]
     2e0:      	ldr	x11, [sp, #0x18]
     2e4:      	cmp	x9, x11
     2e8:      	cset	w11, eq
     2ec:      	b	0x2f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x2f8>
     2f0:      	mov	x10, xzr
     2f4:      	mov	w11, wzr
     2f8:      	ldp	x8, x9, [x8, #0x18]
     2fc:      	subs	x9, x9, x8
     300:      	b.eq	0x3e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3e0>
     304:      	ldr	x8, [x20]
     308:      	asr	x9, x9, #2
     30c:      	tbz	w11, #0x0, 0x364 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x364>
     310:      	add	x11, sp, #0x38
     314:      	cmp	x9, #0x1
     318:      	ldr	x10, [x10]
     31c:      	ldr	s0, [x11, x26]
     320:      	csinc	x11, x9, xzr, hi
     324:      	cmp	x9, #0x8
     328:      	b.hs	0x4b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x4b8>
     32c:      	mov	x12, xzr
     330:      	lsl	x13, x12, #2
     334:      	sub	x9, x11, x12
     338:      	add	x11, x19, x13
     33c:      	add	x10, x10, x13
     340:      	add	x8, x8, x13
     344:      	ldr	s1, [x10], #0x4
     348:      	subs	x9, x9, #0x1
     34c:      	ldr	s2, [x8], #0x4
     350:      	fmul	s1, s0, s1
     354:      	fadd	s1, s2, s1
     358:      	str	s1, [x11], #0x4
     35c:      	b.ne	0x344 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x344>
     360:      	b	0x3e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3e0>
     364:      	cmp	x9, #0x1
     368:      	mov	x11, xzr
     36c:      	csinc	x10, x9, xzr, hi
     370:      	cmp	x9, #0x8
     374:      	b.lo	0x3bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3bc>
     378:      	sub	x12, x19, x8
     37c:      	cmp	x12, #0x20
     380:      	b.lo	0x3bc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3bc>
     384:      	and	x11, x10, #0xfffffffffffffff8
     388:      	ldr	x13, [sp, #0x28]
     38c:      	add	x12, x8, #0x10
     390:      	mov	x14, x11
     394:      	ldp	q0, q1, [x12, #-0x10]
     398:      	subs	x14, x14, #0x8
     39c:      	add	x12, x12, #0x20
     3a0:      	fadd	v0.4s, v0.4s, v2.4s
     3a4:      	fadd	v1.4s, v1.4s, v2.4s
     3a8:      	stp	q0, q1, [x13, #-0x10]
     3ac:      	add	x13, x13, #0x20
     3b0:      	b.ne	0x394 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x394>
     3b4:      	cmp	x9, x11
     3b8:      	b.eq	0x3e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3e0>
     3bc:      	lsl	x12, x11, #2
     3c0:      	sub	x9, x10, x11
     3c4:      	add	x10, x19, x12
     3c8:      	add	x8, x8, x12
     3cc:      	ldr	s0, [x8], #0x4
     3d0:      	subs	x9, x9, #0x1
     3d4:      	fadd	s0, s0, s8
     3d8:      	str	s0, [x10], #0x4
     3dc:      	b.ne	0x3cc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3cc>
     3e0:      	ldr	x8, [x28, #0x18]
     3e4:      	ldr	w2, [x28]
     3e8:      	cbz	x8, 0x440 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x440>
     3ec:      	cbz	w2, 0x440 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x440>
     3f0:      	cmp	w2, #0x8
     3f4:      	b.lo	0x414 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x414>
     3f8:      	lsl	x9, x2, #2
     3fc:      	add	x10, x8, x9
     400:      	cmp	x19, x10
     404:      	b.hs	0x524 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x524>
     408:      	add	x9, x19, x9
     40c:      	cmp	x8, x9
     410:      	b.hs	0x524 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x524>
     414:      	mov	x9, xzr
     418:      	lsl	x10, x9, #2
     41c:      	sub	x9, x2, x9
     420:      	add	x8, x8, x10
     424:      	add	x10, x19, x10
     428:      	ldr	s0, [x8], #0x4
     42c:      	ldr	s1, [x10]
     430:      	subs	x9, x9, #0x1
     434:      	fmul	s0, s0, s1
     438:      	str	s0, [x10], #0x4
     43c:      	b.ne	0x428 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x428>
     440:      	ldr	x1, [x28, #0x10]
     444:      	ldr	w3, [x28, #0x4]
     448:      	ldr	x5, [x28, #0x20]
     44c:      	ldrb	w6, [x21, #0x24]
     450:      	add	x8, sp, #0x50
     454:      	mov	x0, x19
     458:      	mov	w4, #0x8                // =8
     45c:      	bl	0x45c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x45c>
     460:      	ldr	x3, [x21, #0x38]
     464:      	mov	x0, x23
     468:      	mov	w1, #0x2                // =2
     46c:      	mov	w2, #0x1                // =1
     470:      	bl	0x470 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x470>
     474:      	ldp	x25, x22, [sp, #0x50]
     478:      	cmp	x25, x22
     47c:      	b.eq	0x49c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x49c>
     480:      	ldr	w2, [x25], #0x4
     484:      	ldr	x0, [x21, #0x38]
     488:      	mov	x1, x24
     48c:      	bl	0x48c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x48c>
     490:      	cmp	x25, x22
     494:      	b.ne	0x480 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x480>
     498:      	ldr	x25, [sp, #0x50]
     49c:      	cbz	x25, 0x284 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x284>
     4a0:      	ldr	x8, [sp, #0x60]
     4a4:      	mov	x0, x25
     4a8:      	str	x25, [sp, #0x58]
     4ac:      	sub	x1, x8, x25
     4b0:      	bl	0x4b0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x4b0>
     4b4:      	b	0x284 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x284>
     4b8:      	sub	x12, x19, x8
     4bc:      	cmp	x12, #0x20
     4c0:      	mov	x12, xzr
     4c4:      	b.lo	0x330 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x330>
     4c8:      	sub	x13, x19, x10
     4cc:      	cmp	x13, #0x20
     4d0:      	b.lo	0x330 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x330>
     4d4:      	and	x12, x11, #0xfffffffffffffff8
     4d8:      	ldr	x15, [sp, #0x28]
     4dc:      	add	x13, x10, #0x10
     4e0:      	add	x14, x8, #0x10
     4e4:      	mov	x16, x12
     4e8:      	ldp	q1, q2, [x13, #-0x10]
     4ec:      	subs	x16, x16, #0x8
     4f0:      	ldp	q3, q4, [x14, #-0x10]
     4f4:      	add	x13, x13, #0x20
     4f8:      	add	x14, x14, #0x20
     4fc:      	fmul	v1.4s, v1.4s, v0.s[0]
     500:      	fmul	v2.4s, v2.4s, v0.s[0]
     504:      	fadd	v1.4s, v3.4s, v1.4s
     508:      	fadd	v2.4s, v4.4s, v2.4s
     50c:      	stp	q1, q2, [x15, #-0x10]
     510:      	add	x15, x15, #0x20
     514:      	b.ne	0x4e8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x4e8>
     518:      	cmp	x9, x12
     51c:      	b.ne	0x330 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x330>
     520:      	b	0x3e0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x3e0>
     524:      	and	x9, x2, #0xfffffff8
     528:      	ldr	x11, [sp, #0x28]
     52c:      	add	x10, x8, #0x10
     530:      	mov	x12, x9
     534:      	ldp	q0, q3, [x11, #-0x10]
     538:      	subs	x12, x12, #0x8
     53c:      	ldp	q1, q2, [x10, #-0x10]
     540:      	add	x10, x10, #0x20
     544:      	fmul	v0.4s, v1.4s, v0.4s
     548:      	fmul	v1.4s, v2.4s, v3.4s
     54c:      	stp	q0, q1, [x11, #-0x10]
     550:      	add	x11, x11, #0x20
     554:      	b.ne	0x534 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x534>
     558:      	cmp	x9, x2
     55c:      	b.eq	0x440 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x440>
     560:      	b	0x418 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x418>
     564:      	ldr	x1, [x21, #0x38]
     568:      	mov	w0, #0xa                // =10
     56c:      	bl	0x56c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x56c>
     570:      	ldr	w23, [x20, #0x18]
     574:      	ldr	x25, [sp, #0x20]
     578:      	ldr	x8, [x21, #0x28]
     57c:      	mov	x11, #-0x3333333333333334 // =-3689348814741910324
     580:      	movk	x11, #0xcccd
     584:      	ldp	x9, x10, [x8]
     588:      	sub	x10, x10, x9
     58c:      	asr	x10, x10, #3
     590:      	mul	x11, x10, x11
     594:      	mov	w10, w23
     598:      	cmp	x11, x10
     59c:      	b.ls	0x5d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x5d0>
     5a0:      	cbz	x9, 0x5d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x5d0>
     5a4:      	mov	w11, #0x28              // =40
     5a8:      	umaddl	x10, w10, w11, x9
     5ac:      	mov	w11, wzr
     5b0:      	cbz	x25, 0x5d8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x5d8>
     5b4:      	ldrb	w9, [x10, #0x20]
     5b8:      	tbz	w9, #0x0, 0x5d8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x5d8>
     5bc:      	ldr	x9, [x10, #0x18]
     5c0:      	sub	x11, x25, #0x1
     5c4:      	cmp	x9, x11
     5c8:      	cset	w11, eq
     5cc:      	b	0x5d8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x5d8>
     5d0:      	mov	x10, xzr
     5d4:      	mov	w11, wzr
     5d8:      	ldp	x8, x9, [x8, #0x18]
     5dc:      	subs	x9, x9, x8
     5e0:      	b.eq	0x6c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6c4>
     5e4:      	ldr	x8, [x20]
     5e8:      	asr	x9, x9, #2
     5ec:      	tbz	w11, #0x0, 0x640 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x640>
     5f0:      	ldr	s0, [x21, #0x20]
     5f4:      	cmp	x9, #0x1
     5f8:      	ldr	x10, [x10]
     5fc:      	csinc	x11, x9, xzr, hi
     600:      	cmp	x9, #0x8
     604:      	b.hs	0xb3c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xb3c>
     608:      	mov	x12, xzr
     60c:      	lsl	x13, x12, #2
     610:      	sub	x9, x11, x12
     614:      	add	x11, x19, x13
     618:      	add	x10, x10, x13
     61c:      	add	x8, x8, x13
     620:      	ldr	s1, [x10], #0x4
     624:      	subs	x9, x9, #0x1
     628:      	ldr	s2, [x8], #0x4
     62c:      	fmul	s1, s0, s1
     630:      	fadd	s1, s2, s1
     634:      	str	s1, [x11], #0x4
     638:      	b.ne	0x620 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x620>
     63c:      	b	0x6c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6c4>
     640:      	cmp	x9, #0x1
     644:      	mov	x11, xzr
     648:      	csinc	x10, x9, xzr, hi
     64c:      	cmp	x9, #0x8
     650:      	b.lo	0x69c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x69c>
     654:      	sub	x12, x19, x8
     658:      	cmp	x12, #0x20
     65c:      	b.lo	0x69c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x69c>
     660:      	movi	v0.2d, #0000000000000000
     664:      	and	x11, x10, #0xfffffffffffffff8
     668:      	add	x12, x19, #0x10
     66c:      	add	x13, x8, #0x10
     670:      	mov	x14, x11
     674:      	ldp	q1, q2, [x13, #-0x10]
     678:      	subs	x14, x14, #0x8
     67c:      	add	x13, x13, #0x20
     680:      	fadd	v1.4s, v1.4s, v0.4s
     684:      	fadd	v2.4s, v2.4s, v0.4s
     688:      	stp	q1, q2, [x12, #-0x10]
     68c:      	add	x12, x12, #0x20
     690:      	b.ne	0x674 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x674>
     694:      	cmp	x9, x11
     698:      	b.eq	0x6c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6c4>
     69c:      	movi	d0, #0000000000000000
     6a0:      	lsl	x12, x11, #2
     6a4:      	sub	x9, x10, x11
     6a8:      	add	x10, x19, x12
     6ac:      	add	x8, x8, x12
     6b0:      	ldr	s1, [x8], #0x4
     6b4:      	subs	x9, x9, #0x1
     6b8:      	fadd	s1, s1, s0
     6bc:      	str	s1, [x10], #0x4
     6c0:      	b.ne	0x6b0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6b0>
     6c4:      	ldr	x8, [x28, #0x18]
     6c8:      	ldr	w2, [x28]
     6cc:      	cbz	x8, 0x724 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x724>
     6d0:      	cbz	w2, 0x724 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x724>
     6d4:      	cmp	w2, #0x8
     6d8:      	b.lo	0x6f8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6f8>
     6dc:      	lsl	x9, x2, #2
     6e0:      	add	x10, x8, x9
     6e4:      	cmp	x19, x10
     6e8:      	b.hs	0xba8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xba8>
     6ec:      	add	x9, x19, x9
     6f0:      	cmp	x8, x9
     6f4:      	b.hs	0xba8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xba8>
     6f8:      	mov	x9, xzr
     6fc:      	lsl	x10, x9, #2
     700:      	sub	x9, x2, x9
     704:      	add	x8, x8, x10
     708:      	add	x10, x19, x10
     70c:      	ldr	s0, [x8], #0x4
     710:      	ldr	s1, [x10]
     714:      	subs	x9, x9, #0x1
     718:      	fmul	s0, s0, s1
     71c:      	str	s0, [x10], #0x4
     720:      	b.ne	0x70c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x70c>
     724:      	ldr	x1, [x28, #0x10]
     728:      	ldr	x5, [x28, #0x20]
     72c:      	ldrb	w6, [x21, #0x24]
     730:      	ldp	w3, w4, [x28, #0x4]
     734:      	add	x8, sp, #0x50
     738:      	mov	x0, x19
     73c:      	bl	0x73c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x73c>
     740:      	mov	w24, #0x4458            // =17496
     744:      	add	x0, x27, x24
     748:      	bl	0x748 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x748>
     74c:      	ldp	x1, x2, [sp, #0x50]
     750:      	stp	xzr, xzr, [sp, #0x38]
     754:      	str	xzr, [sp, #0x48]
     758:      	cmp	x2, x1
     75c:      	b.eq	0x9cc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x9cc>
     760:      	mov	x23, xzr
     764:      	mov	w24, #0x18              // =24
     768:      	mov	w25, #0x38              // =56
     76c:      	mov	x26, #0x3ffffffffffffffe // =4611686018427387902
     770:      	mov	w28, #0x1               // =1
     774:      	b	0x7b0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x7b0>
     778:      	ldrb	w8, [x20, #0x28]
     77c:      	ldr	x0, [x27, #0x4a50]
     780:      	ldr	x2, [x20, #0x20]
     784:      	strb	w8, [sp, #0x30]
     788:      	ldr	x1, [x21]
     78c:      	add	x4, sp, #0x30
     790:      	mov	x3, x21
     794:      	bl	0x794 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x794>
     798:      	ldp	x1, x2, [sp, #0x50]
     79c:      	add	x23, x23, #0x1
     7a0:      	sub	x8, x2, x1
     7a4:      	asr	x3, x8, #2
     7a8:      	cmp	x23, x3
     7ac:      	b.hs	0x9b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x9b8>
     7b0:      	ldr	x8, [x20, #0x18]
     7b4:      	ldr	x9, [x27, #0x4848]
     7b8:      	add	x0, sp, #0x30
     7bc:      	ldr	w10, [x1, x23, lsl #2]
     7c0:      	mov	w1, #0x8                // =8
     7c4:      	mul	x8, x8, x24
     7c8:      	ldr	x8, [x9, x8]
     7cc:      	nop
     7d0:      	umaddl	x21, w10, w25, x8
     7d4:      	ldr	x22, [x21]
     7d8:      	str	x22, [sp, #0x30]
     7dc:      	bl	0x7dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x7dc>
     7e0:      	ldr	x9, [x27, #0x45d8]
     7e4:      	cbz	x9, 0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     7e8:      	sub	x11, x9, #0x1
     7ec:      	tst	x9, x11
     7f0:      	b.eq	0x818 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x818>
     7f4:      	cmp	x0, x9
     7f8:      	mov	x8, x0
     7fc:      	b.lo	0x808 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x808>
     800:      	udiv	x8, x0, x9
     804:      	msub	x8, x8, x9, x0
     808:      	ldr	x10, [x27, #0x45d0]
     80c:      	ldr	x10, [x10, x8, lsl #3]
     810:      	cbnz	x10, 0x828 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x828>
     814:      	b	0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     818:      	and	x8, x11, x0
     81c:      	ldr	x10, [x27, #0x45d0]
     820:      	ldr	x10, [x10, x8, lsl #3]
     824:      	cbz	x10, 0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     828:      	ldr	x10, [x10]
     82c:      	cbz	x10, 0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     830:      	tst	x9, x11
     834:      	b.ne	0x84c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x84c>
     838:      	b	0x890 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x890>
     83c:      	cmp	x11, x8
     840:      	b.ne	0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     844:      	ldr	x10, [x10]
     848:      	cbz	x10, 0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     84c:      	ldr	x11, [x10, #0x8]
     850:      	cmp	x0, x11
     854:      	b.ne	0x868 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x868>
     858:      	ldr	x11, [x10, #0x10]
     85c:      	cmp	x11, x22
     860:      	b.ne	0x844 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x844>
     864:      	b	0x8a8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8a8>
     868:      	cmp	x11, x9
     86c:      	b.lo	0x83c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x83c>
     870:      	udiv	x12, x11, x9
     874:      	msub	x11, x12, x9, x11
     878:      	b	0x83c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x83c>
     87c:      	and	x9, x9, x11
     880:      	cmp	x9, x8
     884:      	b.ne	0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     888:      	ldr	x10, [x10]
     88c:      	cbz	x10, 0x8dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8dc>
     890:      	ldr	x9, [x10, #0x8]
     894:      	cmp	x0, x9
     898:      	b.ne	0x87c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x87c>
     89c:      	ldr	x9, [x10, #0x10]
     8a0:      	cmp	x9, x22
     8a4:      	b.ne	0x888 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x888>
     8a8:      	mov	w22, wzr
     8ac:      	ldp	x8, x9, [sp, #0x40]
     8b0:      	cmp	x8, x9, lsl #6
     8b4:      	b.eq	0x8ec <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8ec>
     8b8:      	add	x11, x8, #0x1
     8bc:      	ldr	x9, [sp, #0x38]
     8c0:      	lsr	x10, x8, #6
     8c4:      	lsl	x8, x28, x8
     8c8:      	str	x11, [sp, #0x40]
     8cc:      	cbz	w22, 0x938 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x938>
     8d0:      	ldr	x11, [x9, x10, lsl #3]
     8d4:      	orr	x8, x11, x8
     8d8:      	b	0x940 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x940>
     8dc:      	mov	w22, #0x1               // =1
     8e0:      	ldp	x8, x9, [sp, #0x40]
     8e4:      	cmp	x8, x9, lsl #6
     8e8:      	b.ne	0x8b8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8b8>
     8ec:      	cmn	x8, #0x1
     8f0:      	b.mi	0xc4c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc4c>
     8f4:      	cmp	x8, x26
     8f8:      	b.hi	0x914 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x914>
     8fc:      	lsl	x9, x9, #7
     900:      	and	x8, x8, #0x3fffffffffffffc0
     904:      	add	x8, x8, #0x40
     908:      	cmp	x9, x8
     90c:      	csel	x1, x9, x8, hi
     910:      	b	0x918 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x918>
     914:      	mov	x1, #0x7fffffffffffffff // =9223372036854775807
     918:      	add	x0, sp, #0x38
     91c:      	bl	0x91c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x91c>
     920:      	ldp	x9, x8, [sp, #0x38]
     924:      	add	x11, x8, #0x1
     928:      	lsr	x10, x8, #6
     92c:      	lsl	x8, x28, x8
     930:      	str	x11, [sp, #0x40]
     934:      	cbnz	w22, 0x8d0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x8d0>
     938:      	ldr	x11, [x9, x10, lsl #3]
     93c:      	bic	x8, x11, x8
     940:      	str	x8, [x9, x10, lsl #3]
     944:      	ldr	x8, [sp, #0x40]
     948:      	sub	x8, x8, #0x1
     94c:      	lsr	x10, x8, #6
     950:      	ldr	x9, [x9, x10, lsl #3]
     954:      	lsr	x8, x9, x8
     958:      	tbz	w8, #0x0, 0x798 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x798>
     95c:      	ldr	x8, [x27, #0x4a90]
     960:      	cbz	x8, 0x778 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x778>
     964:      	ldp	x9, x10, [x8]
     968:      	mov	x11, #-0x5555555555555556 // =-6148914691236517206
     96c:      	movk	x11, #0xaaab
     970:      	sub	x10, x10, x9
     974:      	asr	x10, x10, #6
     978:      	mul	x11, x10, x11
     97c:      	ldr	x10, [x20, #0x18]
     980:      	cmp	x10, x11
     984:      	b.hs	0xc64 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc64>
     988:      	cmp	x23, #0x10
     98c:      	b.hs	0xc7c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc7c>
     990:      	mov	w11, #0xc0              // =192
     994:      	ldr	s0, [x8, #0x18]
     998:      	nop
     99c:      	madd	x9, x10, x11, x9
     9a0:      	add	x9, x9, x23, lsl #3
     9a4:      	ldp	s1, s2, [x9]
     9a8:      	fmul	s0, s0, s2
     9ac:      	fcmp	s1, s0
     9b0:      	b.ge	0x778 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x778>
     9b4:      	b	0x798 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x798>
     9b8:      	mov	w24, #0x4458            // =17496
     9bc:      	ldr	x8, [x27, #0x4a90]
     9c0:      	ldr	x23, [sp, #0x10]
     9c4:      	cbnz	x8, 0x9dc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x9dc>
     9c8:      	b	0xabc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xabc>
     9cc:      	mov	x3, xzr
     9d0:      	ldr	x8, [x27, #0x4a90]
     9d4:      	ldr	x23, [sp, #0x10]
     9d8:      	cbz	x8, 0xabc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xabc>
     9dc:      	ldp	x8, x9, [x8]
     9e0:      	mov	x10, #-0x5555555555555556 // =-6148914691236517206
     9e4:      	movk	x10, #0xaaab
     9e8:      	sub	x9, x9, x8
     9ec:      	asr	x9, x9, #6
     9f0:      	mul	x10, x9, x10
     9f4:      	ldr	x9, [x20, #0x18]
     9f8:      	cmp	x9, x10
     9fc:      	b.hs	0xc9c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc9c>
     a00:      	mov	w10, #0xc0              // =192
     a04:      	ldr	x20, [x20, #0x20]
     a08:      	nop
     a0c:      	madd	x21, x9, x10, x8
     a10:      	add	x8, sp, #0x50
     a14:      	add	x0, x21, #0x80
     a18:      	cmp	x0, x8
     a1c:      	b.eq	0xa24 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa24>
     a20:      	bl	0xa20 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa20>
     a24:      	add	x22, x21, #0x98
     a28:      	add	x8, sp, #0x38
     a2c:      	cmp	x22, x8
     a30:      	b.eq	0xab0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xab0>
     a34:      	ldr	x8, [sp, #0x40]
     a38:      	cbz	x8, 0xaac <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xaac>
     a3c:      	ldr	x9, [x21, #0xa8]
     a40:      	ldr	x0, [x21, #0x98]
     a44:      	cmp	x8, x9, lsl #6
     a48:      	b.ls	0xa90 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa90>
     a4c:      	cbz	x0, 0xa64 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa64>
     a50:      	lsl	x1, x9, #3
     a54:      	bl	0xa54 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa54>
     a58:      	stp	xzr, xzr, [x22]
     a5c:      	str	xzr, [x22, #0x10]
     a60:      	ldr	x8, [sp, #0x40]
     a64:      	tbnz	x8, #0x3f, 0xcb0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xcb0>
     a68:      	sub	x9, x8, #0x1
     a6c:      	cmp	x8, #0x0
     a70:      	lsr	x9, x9, #6
     a74:      	csinc	x22, xzr, x9, eq
     a78:      	lsl	x0, x22, #3
     a7c:      	bl	0xa7c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xa7c>
     a80:      	stp	x0, xzr, [x21, #0x98]
     a84:      	str	x22, [x21, #0xa8]
     a88:      	ldr	x8, [sp, #0x40]
     a8c:      	cbz	x8, 0xaac <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xaac>
     a90:      	sub	x8, x8, #0x1
     a94:      	ldr	x1, [sp, #0x38]
     a98:      	lsr	x8, x8, #3
     a9c:      	and	x8, x8, #0x1ffffffffffffff8
     aa0:      	add	x2, x8, #0x8
     aa4:      	bl	0xaa4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xaa4>
     aa8:      	ldr	x8, [sp, #0x40]
     aac:      	str	x8, [x21, #0xa0]
     ab0:      	mov	w8, #0x1                // =1
     ab4:      	str	x20, [x21, #0xb0]
     ab8:      	strb	w8, [x21, #0xb8]
     abc:      	ldr	x0, [sp, #0x38]
     ac0:      	cbz	x0, 0xad0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xad0>
     ac4:      	ldr	x8, [sp, #0x48]
     ac8:      	lsl	x1, x8, #3
     acc:      	bl	0xacc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xacc>
     ad0:      	add	x0, x27, x24
     ad4:      	bl	0xad4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xad4>
     ad8:      	ldr	x0, [sp, #0x50]
     adc:      	cbz	x0, 0xaf0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xaf0>
     ae0:      	ldr	x8, [sp, #0x60]
     ae4:      	str	x0, [sp, #0x58]
     ae8:      	sub	x1, x8, x0
     aec:      	bl	0xaec <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xaec>
     af0:      	cbz	x19, 0xb04 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xb04>
     af4:      	ldr	x8, [sp, #0x8]
     af8:      	mov	x0, x19
     afc:      	sub	x1, x8, x19
     b00:      	bl	0xb00 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xb00>
     b04:      	ldr	x8, [x23, #0x28]
     b08:      	ldur	x9, [x29, #-0x20]
     b0c:      	cmp	x8, x9
     b10:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     b14:      	mov	w0, #0x1                // =1
     b18:      	ldp	x20, x19, [sp, #0x140]
     b1c:      	ldr	d8, [sp, #0xe0]
     b20:      	ldp	x22, x21, [sp, #0x130]
     b24:      	ldp	x24, x23, [sp, #0x120]
     b28:      	ldp	x26, x25, [sp, #0x110]
     b2c:      	ldp	x28, x27, [sp, #0x100]
     b30:      	ldp	x29, x30, [sp, #0xf0]
     b34:      	add	sp, sp, #0x150
     b38:      	ret
     b3c:      	sub	x12, x19, x8
     b40:      	cmp	x12, #0x20
     b44:      	mov	x12, xzr
     b48:      	b.lo	0x60c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x60c>
     b4c:      	sub	x13, x19, x10
     b50:      	cmp	x13, #0x20
     b54:      	b.lo	0x60c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x60c>
     b58:      	and	x12, x11, #0xfffffffffffffff8
     b5c:      	add	x13, x19, #0x10
     b60:      	add	x14, x10, #0x10
     b64:      	add	x15, x8, #0x10
     b68:      	mov	x16, x12
     b6c:      	ldp	q1, q2, [x14, #-0x10]
     b70:      	subs	x16, x16, #0x8
     b74:      	ldp	q3, q4, [x15, #-0x10]
     b78:      	add	x14, x14, #0x20
     b7c:      	add	x15, x15, #0x20
     b80:      	fmul	v1.4s, v1.4s, v0.s[0]
     b84:      	fmul	v2.4s, v2.4s, v0.s[0]
     b88:      	fadd	v1.4s, v3.4s, v1.4s
     b8c:      	fadd	v2.4s, v4.4s, v2.4s
     b90:      	stp	q1, q2, [x13, #-0x10]
     b94:      	add	x13, x13, #0x20
     b98:      	b.ne	0xb6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xb6c>
     b9c:      	cmp	x9, x12
     ba0:      	b.ne	0x60c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x60c>
     ba4:      	b	0x6c4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6c4>
     ba8:      	and	x9, x2, #0xfffffff8
     bac:      	add	x10, x19, #0x10
     bb0:      	add	x11, x8, #0x10
     bb4:      	mov	x12, x9
     bb8:      	ldp	q0, q3, [x10, #-0x10]
     bbc:      	subs	x12, x12, #0x8
     bc0:      	ldp	q1, q2, [x11, #-0x10]
     bc4:      	add	x11, x11, #0x20
     bc8:      	fmul	v0.4s, v1.4s, v0.4s
     bcc:      	fmul	v1.4s, v2.4s, v3.4s
     bd0:      	stp	q0, q1, [x10, #-0x10]
     bd4:      	add	x10, x10, #0x20
     bd8:      	b.ne	0xbb8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xbb8>
     bdc:      	cmp	x9, x2
     be0:      	b.eq	0x724 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x724>
     be4:      	b	0x6fc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x6fc>
     be8:      	sub	x12, x10, x1
     bec:      	cmp	x12, #0x20
     bf0:      	mov	x12, xzr
     bf4:      	b.lo	0x1c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1c8>
     bf8:      	sub	x14, x10, x9
     bfc:      	cmp	x14, #0x20
     c00:      	b.lo	0x1c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1c8>
     c04:      	and	x12, x11, #0xfffffffffffffff8
     c08:      	add	x14, x10, #0x10
     c0c:      	add	x15, x9, #0x10
     c10:      	add	x16, x1, #0x10
     c14:      	mov	x17, x12
     c18:      	ldp	q0, q3, [x15, #-0x10]
     c1c:      	subs	x17, x17, #0x8
     c20:      	ldp	q1, q2, [x16, #-0x10]
     c24:      	add	x15, x15, #0x20
     c28:      	add	x16, x16, #0x20
     c2c:      	fsub	v0.4s, v1.4s, v0.4s
     c30:      	fsub	v1.4s, v2.4s, v3.4s
     c34:      	stp	q0, q1, [x14, #-0x10]
     c38:      	add	x14, x14, #0x20
     c3c:      	b.ne	0xc18 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc18>
     c40:      	cmp	x13, x12
     c44:      	b.ne	0x1c8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1c8>
     c48:      	b	0x1f4 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0x1f4>
     c4c:      	ldr	x8, [sp, #0x10]
     c50:      	ldr	x8, [x8, #0x28]
     c54:      	ldur	x9, [x29, #-0x20]
     c58:      	cmp	x8, x9
     c5c:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     c60:      	bl	0xc60 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc60>
     c64:      	ldr	x8, [sp, #0x10]
     c68:      	ldr	x8, [x8, #0x28]
     c6c:      	ldur	x9, [x29, #-0x20]
     c70:      	cmp	x8, x9
     c74:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     c78:      	bl	0xc78 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc78>
     c7c:      	ldr	x8, [sp, #0x10]
     c80:      	ldr	x8, [x8, #0x28]
     c84:      	ldur	x9, [x29, #-0x20]
     c88:      	cmp	x8, x9
     c8c:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     c90:      	adrp	x0, 0x0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const>
     c94:      	add	x0, x0, #0x0
     c98:      	bl	0xc98 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xc98>
     c9c:      	ldr	x8, [x23, #0x28]
     ca0:      	ldur	x9, [x29, #-0x20]
     ca4:      	cmp	x8, x9
     ca8:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     cac:      	bl	0xcac <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xcac>
     cb0:      	ldr	x8, [x23, #0x28]
     cb4:      	ldur	x9, [x29, #-0x20]
     cb8:      	cmp	x8, x9
     cbc:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     cc0:      	bl	0xcc0 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xcc0>
     cc4:      	mov	x20, x0
     cc8:      	b	0xd0c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd0c>
     ccc:      	mov	x20, x0
     cd0:      	cbz	x19, 0xd18 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd18>
     cd4:      	b	0xd48 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd48>
     cd8:      	b	0xce8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xce8>
     cdc:      	b	0xce8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xce8>
     ce0:      	b	0xce8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xce8>
     ce4:      	b	0xce8 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xce8>
     ce8:      	mov	x20, x0
     cec:      	ldr	x0, [sp, #0x38]
     cf0:      	cbz	x0, 0xd00 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd00>
     cf4:      	ldr	x8, [sp, #0x48]
     cf8:      	lsl	x1, x8, #3
     cfc:      	bl	0xcfc <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xcfc>
     d00:      	mov	w8, #0x4458             // =17496
     d04:      	add	x0, x27, x8
     d08:      	bl	0xd08 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd08>
     d0c:      	ldr	x0, [sp, #0x50]
     d10:      	cbnz	x0, 0xd34 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd34>
     d14:      	cbnz	x19, 0xd48 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd48>
     d18:      	ldr	x8, [sp, #0x10]
     d1c:      	ldr	x8, [x8, #0x28]
     d20:      	ldur	x9, [x29, #-0x20]
     d24:      	cmp	x8, x9
     d28:      	b.ne	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     d2c:      	mov	x0, x20
     d30:      	bl	0xd30 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd30>
     d34:      	ldr	x8, [sp, #0x60]
     d38:      	str	x0, [sp, #0x58]
     d3c:      	sub	x1, x8, x0
     d40:      	bl	0xd40 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd40>
     d44:      	cbz	x19, 0xd18 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd18>
     d48:      	ldr	x8, [sp, #0x8]
     d4c:      	mov	x0, x19
     d50:      	sub	x1, x8, x19
     d54:      	bl	0xd54 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd54>
     d58:      	ldr	x8, [sp, #0x10]
     d5c:      	ldr	x8, [x8, #0x28]
     d60:      	ldur	x9, [x29, #-0x20]
     d64:      	cmp	x8, x9
     d68:      	b.eq	0xd2c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd2c>
     d6c:      	bl	0xd6c <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd6c>
     d70:      	mov	x20, x0
     d74:      	cbz	x19, 0xd18 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd18>
     d78:      	b	0xd48 <nntrainer::HtpComputeOps::initCpuPredictor(std::__ndk1::vector<int, std::__ndk1::allocator<int>> const&)::'lambda'(nntrainer::HtpComputeOps::PredictionJob&)::operator()(nntrainer::HtpComputeOps::PredictionJob&) const+0xd48>

0000000000000000 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>:
       0:      	sub	sp, sp, #0xc0
       4:      	str	d10, [sp, #0x40]
       8:      	stp	d9, d8, [sp, #0x50]
       c:      	stp	x29, x30, [sp, #0x60]
      10:      	stp	x28, x27, [sp, #0x70]
      14:      	stp	x26, x25, [sp, #0x80]
      18:      	stp	x24, x23, [sp, #0x90]
      1c:      	stp	x22, x21, [sp, #0xa0]
      20:      	stp	x20, x19, [sp, #0xb0]
      24:      	add	x29, sp, #0x60
      28:      	mrs	x9, TPIDR_EL0
      2c:      	ldr	x10, [x9, #0x28]
      30:      	stur	x10, [x29, #-0x28]
      34:      	cbz	x0, 0x19c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x19c>
      38:      	mov	x26, x1
      3c:      	cbz	x1, 0x19c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x19c>
      40:      	mov	w28, w2
      44:      	cbz	w2, 0x19c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x19c>
      48:      	mov	w21, w3
      4c:      	cbz	w3, 0x19c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x19c>
      50:      	cbz	w4, 0x19c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x19c>
      54:      	ubfiz	x22, x21, #2, #32
      58:      	mov	x25, x0
      5c:      	mov	w27, w6
      60:      	mov	x23, x5
      64:      	str	w4, [sp, #0x4]
      68:      	mov	w20, w21
      6c:      	mov	x0, x22
      70:      	stp	x9, x8, [sp, #0x8]
      74:      	bl	0x74 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x74>
      78:      	add	x19, x0, x22
      7c:      	mov	w1, wzr
      80:      	mov	x2, x22
      84:      	mov	x24, x0
      88:      	str	x0, [sp, #0x18]
      8c:      	str	x19, [sp, #0x28]
      90:      	bl	0x90 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x90>
      94:      	str	x19, [sp, #0x20]
      98:      	cbz	x23, 0x1b8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1b8>
      9c:      	cmp	w21, #0x40
      a0:      	b.ne	0x1b8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1b8>
      a4:      	cmp	w28, #0x800
      a8:      	b.ne	0x1b8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1b8>
      ac:      	tbz	w27, #0x0, 0x1b8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1b8>
      b0:      	movi	v0.2d, #0000000000000000
      b4:      	movi	v2.2d, #0000000000000000
      b8:      	mov	x8, xzr
      bc:      	movi	v3.2d, #0000000000000000
      c0:      	movi	v4.2d, #0000000000000000
      c4:      	add	x9, x26, #0x80
      c8:      	movi	v5.2d, #0000000000000000
      cc:      	movi	v6.2d, #0000000000000000
      d0:      	movi	v7.2d, #0000000000000000
      d4:      	movi	v16.2d, #0000000000000000
      d8:      	movi	v17.2d, #0000000000000000
      dc:      	movi	v18.2d, #0000000000000000
      e0:      	movi	v19.2d, #0000000000000000
      e4:      	movi	v20.2d, #0000000000000000
      e8:      	movi	v21.2d, #0000000000000000
      ec:      	movi	v22.2d, #0000000000000000
      f0:      	movi	v23.2d, #0000000000000000
      f4:      	movi	v1.2d, #0000000000000000
      f8:      	ldp	q25, q26, [x9, #-0x80]
      fc:      	ldr	s24, [x25, x8]
     100:      	ldp	q27, q28, [x9, #-0x60]
     104:      	add	x8, x8, #0x4
     108:      	cmp	x8, #0x2, lsl #12       // =0x2000
     10c:      	fmla	v0.4s, v25.4s, v24.s[0]
     110:      	fmla	v2.4s, v26.4s, v24.s[0]
     114:      	ldp	q25, q26, [x9, #-0x40]
     118:      	fmla	v3.4s, v27.4s, v24.s[0]
     11c:      	fmla	v4.4s, v28.4s, v24.s[0]
     120:      	fmla	v5.4s, v25.4s, v24.s[0]
     124:      	ldp	q25, q27, [x9, #-0x20]
     128:      	fmla	v6.4s, v26.4s, v24.s[0]
     12c:      	ldp	q26, q28, [x9]
     130:      	fmla	v7.4s, v25.4s, v24.s[0]
     134:      	fmla	v16.4s, v27.4s, v24.s[0]
     138:      	fmla	v17.4s, v26.4s, v24.s[0]
     13c:      	ldp	q25, q26, [x9, #0x20]
     140:      	fmla	v18.4s, v28.4s, v24.s[0]
     144:      	fmla	v19.4s, v25.4s, v24.s[0]
     148:      	ldp	q25, q27, [x9, #0x40]
     14c:      	fmla	v20.4s, v26.4s, v24.s[0]
     150:      	ldp	q26, q28, [x9, #0x60]
     154:      	add	x9, x9, #0x100
     158:      	fmla	v21.4s, v25.4s, v24.s[0]
     15c:      	fmla	v22.4s, v27.4s, v24.s[0]
     160:      	fmla	v23.4s, v26.4s, v24.s[0]
     164:      	fmla	v1.4s, v28.4s, v24.s[0]
     168:      	b.ne	0xf8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0xf8>
     16c:      	ldr	x19, [sp, #0x10]
     170:      	stp	q0, q2, [x24]
     174:      	mov	x8, x22
     178:      	stp	q3, q4, [x24, #0x20]
     17c:      	mov	x9, x24
     180:      	stp	q5, q6, [x24, #0x40]
     184:      	stp	q7, q16, [x24, #0x60]
     188:      	stp	q17, q18, [x24, #0x80]
     18c:      	stp	q19, q20, [x24, #0xa0]
     190:      	stp	q21, q22, [x24, #0xc0]
     194:      	stp	q23, q1, [x24, #0xe0]
     198:      	b	0x26c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x26c>
     19c:      	ldr	x10, [x9, #0x28]
     1a0:      	ldur	x9, [x29, #-0x28]
     1a4:      	cmp	x10, x9
     1a8:      	b.ne	0x470 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x470>
     1ac:      	stp	xzr, xzr, [x8]
     1b0:      	str	xzr, [x8, #0x10]
     1b4:      	b	0x3f4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3f4>
     1b8:      	ldr	x19, [sp, #0x10]
     1bc:      	mov	x8, xzr
     1c0:      	mov	w9, w28
     1c4:      	and	x10, x20, #0xfffffff8
     1c8:      	add	x11, x24, #0x10
     1cc:      	add	x12, x26, #0x10
     1d0:      	b	0x1e8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1e8>
     1d4:      	add	x8, x8, #0x1
     1d8:      	add	x12, x12, x22
     1dc:      	add	x26, x26, x22
     1e0:      	cmp	x8, x9
     1e4:      	b.eq	0x264 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x264>
     1e8:      	ldr	s0, [x25, x8, lsl #2]
     1ec:      	cmp	w21, #0x8
     1f0:      	b.hs	0x1fc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1fc>
     1f4:      	mov	x15, xzr
     1f8:      	b	0x238 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x238>
     1fc:      	mov	x13, x12
     200:      	mov	x14, x11
     204:      	mov	x15, x10
     208:      	ldp	q1, q4, [x14, #-0x10]
     20c:      	subs	x15, x15, #0x8
     210:      	ldp	q2, q3, [x13, #-0x10]
     214:      	add	x13, x13, #0x20
     218:      	fmla	v1.4s, v2.4s, v0.s[0]
     21c:      	fmla	v4.4s, v3.4s, v0.s[0]
     220:      	stp	q1, q4, [x14, #-0x10]
     224:      	add	x14, x14, #0x20
     228:      	b.ne	0x208 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x208>
     22c:      	cmp	x10, x20
     230:      	mov	x15, x10
     234:      	b.eq	0x1d4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1d4>
     238:      	lsl	x14, x15, #2
     23c:      	sub	x15, x20, x15
     240:      	add	x13, x26, x14
     244:      	add	x14, x24, x14
     248:      	ldr	s1, [x13], #0x4
     24c:      	ldr	s2, [x14]
     250:      	subs	x15, x15, #0x1
     254:      	fmadd	s1, s0, s1, s2
     258:      	str	s1, [x14], #0x4
     25c:      	b.ne	0x248 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x248>
     260:      	b	0x1d4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x1d4>
     264:      	mov	x8, x22
     268:      	mov	x9, x24
     26c:      	ldr	w10, [x9]
     270:      	mov	w11, #0x7f800000        // =2139095040
     274:      	and	w10, w10, #0x7fffffff
     278:      	cmp	w10, w11
     27c:      	b.ge	0x3c0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3c0>
     280:      	subs	x8, x8, #0x4
     284:      	add	x9, x9, #0x4
     288:      	b.ne	0x26c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x26c>
     28c:      	cbz	x23, 0x2e8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2e8>
     290:      	fmov	s8, #1.00000000
     294:      	cmp	w21, #0x1
     298:      	mov	w26, #0x7f800000        // =2139095040
     29c:      	csinc	w25, w21, wzr, hi
     2a0:      	ldr	s9, [x23]
     2a4:      	fmov	w8, s9
     2a8:      	and	w8, w8, #0x7fffffff
     2ac:      	cmp	w8, w26
     2b0:      	b.ge	0x3c0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3c0>
     2b4:      	ldr	s10, [x24]
     2b8:      	fabs	s0, s10
     2bc:      	fneg	s0, s0
     2c0:      	bl	0x2c0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2c0>
     2c4:      	fcmp	s10, #0.0
     2c8:      	fadd	s1, s0, s8
     2cc:      	add	x23, x23, #0x4
     2d0:      	fcsel	s0, s0, s8, lt
     2d4:      	subs	x25, x25, #0x1
     2d8:      	fdiv	s0, s0, s1
     2dc:      	fadd	s0, s9, s0
     2e0:      	str	s0, [x24], #0x4
     2e4:      	b.ne	0x2a0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2a0>
     2e8:      	stp	xzr, xzr, [x19]
     2ec:      	str	xzr, [x19, #0x10]
     2f0:      	mov	x0, x22
     2f4:      	bl	0x2f4 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x2f4>
     2f8:      	add	x8, x0, x20, lsl #2
     2fc:      	mov	w1, wzr
     300:      	mov	x2, x22
     304:      	mov	x23, x0
     308:      	str	x0, [x19]
     30c:      	str	x8, [x19, #0x10]
     310:      	bl	0x310 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x310>
     314:      	sub	x10, x22, #0x4
     318:      	add	x2, x23, x22
     31c:      	ldr	w22, [sp, #0x4]
     320:      	mov	w8, wzr
     324:      	cmp	x10, #0x1c
     328:      	mov	x9, x23
     32c:      	str	x2, [x19, #0x8]
     330:      	b.lo	0x37c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x37c>
     334:      	lsr	x8, x10, #2
     338:      	movi	v0.4s, #0x4
     33c:      	movi	v1.4s, #0x8
     340:      	adrp	x11, 0x0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)>
     344:      	add	x10, x8, #0x1
     348:      	ldr	q2, [x11]
     34c:      	add	x11, x23, #0x10
     350:      	and	x8, x10, #0x7ffffffffffffff8
     354:      	add	x9, x23, x8, lsl #2
     358:      	mov	x12, x8
     35c:      	add	v3.4s, v2.4s, v0.4s
     360:      	subs	x12, x12, #0x8
     364:      	stp	q2, q3, [x11, #-0x10]
     368:      	add	v2.4s, v2.4s, v1.4s
     36c:      	add	x11, x11, #0x20
     370:      	b.ne	0x35c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x35c>
     374:      	cmp	x10, x8
     378:      	b.eq	0x38c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x38c>
     37c:      	str	w8, [x9], #0x4
     380:      	cmp	x9, x2
     384:      	add	w8, w8, #0x1
     388:      	b.ne	0x37c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x37c>
     38c:      	cmp	w21, w22
     390:      	add	x8, sp, #0x18
     394:      	csel	w20, w21, w22, lo
     398:      	str	x8, [sp, #0x30]
     39c:      	add	x1, x23, w20, uxtw #2
     3a0:      	add	x3, sp, #0x30
     3a4:      	mov	x0, x23
     3a8:      	bl	0x3a8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3a8>
     3ac:      	cmp	w22, w21
     3b0:      	b.hs	0x3c8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3c8>
     3b4:      	add	x8, x23, x20, lsl #2
     3b8:      	str	x8, [x19, #0x8]
     3bc:      	b	0x3c8 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3c8>
     3c0:      	stp	xzr, xzr, [x19]
     3c4:      	str	xzr, [x19, #0x10]
     3c8:      	ldr	x0, [sp, #0x18]
     3cc:      	cbz	x0, 0x3e0 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3e0>
     3d0:      	ldr	x8, [sp, #0x28]
     3d4:      	str	x0, [sp, #0x20]
     3d8:      	sub	x1, x8, x0
     3dc:      	bl	0x3dc <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x3dc>
     3e0:      	ldr	x8, [sp, #0x8]
     3e4:      	ldr	x8, [x8, #0x28]
     3e8:      	ldur	x9, [x29, #-0x28]
     3ec:      	cmp	x8, x9
     3f0:      	b.ne	0x470 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x470>
     3f4:      	ldp	x20, x19, [sp, #0xb0]
     3f8:      	ldr	d10, [sp, #0x40]
     3fc:      	ldp	x22, x21, [sp, #0xa0]
     400:      	ldp	x24, x23, [sp, #0x90]
     404:      	ldp	x26, x25, [sp, #0x80]
     408:      	ldp	x28, x27, [sp, #0x70]
     40c:      	ldp	x29, x30, [sp, #0x60]
     410:      	ldp	d9, d8, [sp, #0x50]
     414:      	add	sp, sp, #0xc0
     418:      	ret
     41c:      	ldr	x8, [x19, #0x10]
     420:      	mov	x21, x0
     424:      	mov	x0, x23
     428:      	str	x23, [x19, #0x8]
     42c:      	sub	x1, x8, x23
     430:      	bl	0x430 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x430>
     434:      	b	0x43c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x43c>
     438:      	mov	x21, x0
     43c:      	ldr	x0, [sp, #0x18]
     440:      	cbz	x0, 0x454 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x454>
     444:      	ldr	x8, [sp, #0x28]
     448:      	str	x0, [sp, #0x20]
     44c:      	sub	x1, x8, x0
     450:      	bl	0x450 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x450>
     454:      	ldr	x8, [sp, #0x8]
     458:      	ldr	x8, [x8, #0x28]
     45c:      	ldur	x9, [x29, #-0x28]
     460:      	cmp	x8, x9
     464:      	b.ne	0x470 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x470>
     468:      	mov	x0, x21
     46c:      	bl	0x46c <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x46c>
     470:      	bl	0x470 <nntrainer::htpPredictExperts(float const*, float const*, unsigned int, unsigned int, unsigned int, float const*, bool)+0x470>

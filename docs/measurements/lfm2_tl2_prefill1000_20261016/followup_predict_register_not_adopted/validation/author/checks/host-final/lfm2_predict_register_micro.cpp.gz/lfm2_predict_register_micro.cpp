// SPDX-License-Identifier: Apache-2.0
// Native CPU predictor micro only. No inference, DSP or file I/O timing claim.
#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <string>
#include <vector>
#if defined(__linux__)
#include <sched.h>
#endif
#ifdef PREDICT_SIMDE
#define SIMDE_ENABLE_NATIVE_ALIASES
#include <simde/arm/neon.h>
#define __aarch64__ 1
#endif
#include "baseline.h"
#include "candidate.h"
static volatile uint64_t sink = 0;
struct Layer {
  std::vector<float> x, w, b;
  Layer() : x(2048), w(2048 * 64), b(64) {}
};
static uint32_t rng = 739391u;
static float next() {
  rng ^= rng << 13;
  rng ^= rng >> 17;
  rng ^= rng << 5;
  return float(int(rng & 65535u) - 32768) / 32768.0f;
}
__attribute__((noinline)) static std::vector<unsigned> predict(const Layer &l,
                                                               bool enabled) {
  return after::htpPredictExperts(l.x.data(), l.w.data(), 2048, 64, 4,
                                  l.b.data(), enabled);
}
__attribute__((noinline)) static double
measure(const std::vector<Layer> &layers, unsigned count, unsigned repeat,
        bool enabled) {
  uint64_t digest = 0;
  const auto start = std::chrono::steady_clock::now();
  for (unsigned r = 0; r < repeat; ++r)
    for (unsigned i = 0; i < count; ++i) {
      auto ids = predict(layers[i], enabled);
      for (unsigned id : ids)
        digest += id;
    }
  const auto end = std::chrono::steady_clock::now();
  sink = digest;
  return std::chrono::duration<double, std::micro>(end - start).count() /
         (count * repeat);
}
int main(int argc, char **argv) {
#if defined(__linux__)
  if (argc == 3 && std::strcmp(argv[1], "--cpu") == 0) {
    const int cpu = std::atoi(argv[2]);
    assert(cpu >= 0 && cpu < CPU_SETSIZE);
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    if (sched_setaffinity(0, sizeof(set), &set) != 0) {
      std::perror("sched_setaffinity");
      return 2;
    }
  } else if (argc != 1) {
    std::fputs("usage: micro [--cpu N]\n", stderr);
    return 2;
  }
#else
  (void)argc;
  (void)argv;
#endif
  std::vector<Layer> layers(37);
  for (auto &l : layers) {
    for (auto &v : l.x)
      v = next();
    for (auto &v : l.w)
      v = next();
    for (auto &v : l.b)
      v = next();
    const auto reference = before::htpPredictExperts(l.x.data(), l.w.data(),
                                                     2048, 64, 4, l.b.data());
    assert(reference == predict(l, false));
    assert(reference == predict(l, true));
  }
  std::puts(
    "PREDICT_MICRO parity=37 exact; scope=CPU hint "
    "dot+finite+sigmoid+topk+existing allocations; no DSP/I/O/inference");
  for (unsigned count : {1u, 37u}) {
    const unsigned repeats = count == 1 ? 128u : 4u;
    std::vector<double> off, on, ratio;
    measure(layers, count, repeats, false);
    measure(layers, count, repeats, true);
    for (unsigned p = 0; p < 31; ++p) {
      double a, b;
      if (p & 1) {
        b = measure(layers, count, repeats, true);
        a = measure(layers, count, repeats, false);
      } else {
        a = measure(layers, count, repeats, false);
        b = measure(layers, count, repeats, true);
      }
      off.push_back(a);
      on.push_back(b);
      ratio.push_back(b / a);
      std::printf("PREDICT_MICRO mode=%s pair=%u order=%s off_us=%.6f "
                  "on_us=%.6f ratio=%.6f\n",
                  count == 1 ? "warm" : "37layers", p, p & 1 ? "BA" : "AB", a,
                  b, b / a);
    }
    std::sort(off.begin(), off.end());
    std::sort(on.begin(), on.end());
    std::sort(ratio.begin(), ratio.end());
    std::printf("PREDICT_MICRO summary mode=%s pairs=31 off_us=%.6f on_us=%.6f "
                "paired_ratio=%.6f sink=%llu\n",
                count == 1 ? "warm" : "37layers", off[15], on[15], ratio[15],
                static_cast<unsigned long long>(sink));
  }
}

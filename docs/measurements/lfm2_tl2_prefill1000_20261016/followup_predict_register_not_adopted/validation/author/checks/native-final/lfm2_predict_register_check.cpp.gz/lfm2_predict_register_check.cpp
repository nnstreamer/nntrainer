// SPDX-License-Identifier: Apache-2.0
// Linux/Android host fixture. No DSP, disk reads, or timing proof.
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <mutex>
#include <numeric>
#include <set>
#include <string>
#include <tuple>
#include <type_traits>
#include <vector>
#ifdef PREDICT_SIMDE
#define SIMDE_ENABLE_NATIVE_ALIASES
#include <simde/arm/neon.h>
#define __aarch64__ 1
#endif
#include "baseline-checked.h"
#include "candidate-checked.h"

namespace before {
__attribute__((noinline)) std::vector<float>
raw(const float *input, const float *weights, unsigned hidden, unsigned experts,
    unsigned top, const float *sigmoid_bias, bool lfm2_register_accum) {
  (void)sigmoid_bias;
#include "baseline-raw.inc"
}
} // namespace before
namespace after {
__attribute__((noinline)) std::vector<float>
raw(const float *input, const float *weights, unsigned hidden, unsigned experts,
    unsigned top, const float *sigmoid_bias, bool lfm2_register_accum) {
  (void)sigmoid_bias;
#include "candidate-raw.inc"
}
} // namespace after

static unsigned cases, score_cases, job_cases, guard_cases;
static uint32_t rng = 739391u;
static uint32_t bits(float f) {
  uint32_t n;
  std::memcpy(&n, &f, 4);
  return n;
}
static float fromBits(uint32_t n) {
  float f;
  std::memcpy(&f, &n, 4);
  return f;
}
static float randomFloat() {
  rng ^= rng << 13;
  rng ^= rng >> 17;
  rng ^= rng << 5;
  return float(int(rng & 65535u) - 32768) / 32768.0f;
}
static void fill(std::vector<float> &v) {
  for (auto &f : v)
    f = randomFloat();
}
static void eqScores(const std::vector<float> &a, const std::vector<float> &b) {
  assert(a.size() == b.size());
  for (size_t i = 0; i < a.size(); ++i) {
    // NaN payload selection is native-instruction-specific. Both rankers must
    // reject every nonfinite raw score; finite/signed-zero scores are exact.
    if (std::isnan(a[i]) && std::isnan(b[i]))
      continue;
    if (bits(a[i]) != bits(b[i])) {
      std::fprintf(stderr, "score mismatch case=%u e=%zu %08x != %08x\n", cases,
                   i, bits(a[i]), bits(b[i]));
      std::abort();
    }
  }
}
static void check(const float *x, const float *w, unsigned h, unsigned e,
                  unsigned top, const float *bias, bool enabled) {
  const unsigned start = after::dot_calls;
  const auto b = before::htpPredictExperts(x, w, h, e, top, bias);
  const auto a = after::htpPredictExperts(x, w, h, e, top, bias, enabled);
  assert(a == b);
#if defined(__aarch64__)
  const bool selected =
    x && w && h == 2048 && e == 64 && top && bias && enabled;
#else
  const bool selected = false;
#endif
  assert(after::dot_calls - start == unsigned(selected));
  const auto br = before::raw(x, w, h, e, top, bias, false);
  const auto ar = after::raw(x, w, h, e, top, bias, enabled);
  eqScores(br, ar);
  for (float s : ar)
    if (!std::isfinite(s))
      assert(a.empty());
  ++cases;
  score_cases += !ar.empty();
}
struct Shape {
  unsigned w_bits = 0x102u, K = 2048, inter = 1536, N_out = 2048;
};
static constexpr unsigned HTP_TL2_WEIGHT_BITS = 0x102u;
static bool enabled(const Shape &shape) {
#include "guard.inc"
}

struct PredictionJob {
  std::vector<float> input;
  size_t layer = 0;
  uint64_t epoch = 0;
  bool native = false;
};
struct PredictionRouter {
  unsigned hidden = 0, experts = 0, top = 0;
  const float *weights = nullptr, *gamma = nullptr, *sigmoid_bias = nullptr;
};
struct Desc {
  const void *key_gu = nullptr;
};
template <bool Candidate> struct Predictor {
  using Residual =
    typename std::conditional<Candidate, after::HtpRouterResidual,
                              before::HtpRouterResidual>::type;
  using Confidence =
    typename std::conditional<Candidate, after::HtpPrefetchConfidence,
                              before::HtpPrefetchConfidence>::type;
  std::vector<PredictionRouter> prediction_routers_;
  std::vector<std::vector<Desc>> pool_descs_;
  std::set<const void *> experts_;
  std::vector<std::tuple<const void *, uint64_t, bool>> submitted;
  std::unique_ptr<Confidence> prediction_confidence_;
  std::mutex handle_mutex_;
  std::shared_ptr<Residual> residual;
  std::shared_ptr<FILE> trace;
  std::vector<int> cpus{0};
  float blend = 0.5f;
  bool register_accum = false;
  Predictor(unsigned h, unsigned e, const float *w, const float *b,
            const float *gamma, bool conf, bool trace_on) {
    prediction_routers_.assign(3, {h, e, 4, w, gamma, b});
    pool_descs_.resize(3);
    for (size_t l = 0; l < 3; ++l) {
      pool_descs_[l].resize(e);
      for (unsigned i = 0; i < e; ++i) {
        const auto key =
          reinterpret_cast<const void *>(uintptr_t(4096 + l * 1024 + i));
        pool_descs_[l][i].key_gu = key;
        if (i % 7 == 0)
          experts_.insert(key);
      }
    }
    residual = std::make_shared<Residual>(3, h);
    if (conf)
      prediction_confidence_.reset(new Confidence(3, 0.6f));
    if (trace_on) {
      FILE *f = std::tmpfile();
      assert(f);
      trace.reset(f, std::fclose);
    }
  }
  void pinToCpus(const std::vector<int> &v) { assert(v == cpus); }
  bool queueDirectPrefetch(const Desc &d, uint64_t epoch, bool native) {
    submitted.emplace_back(d.key_gu, epoch, native);
    return true;
  }
  __attribute__((noinline)) bool run(PredictionJob &job) {
    if constexpr (Candidate) {
      using after::htpPredictExperts;
#include "candidate-callback.inc"
    } else {
      using before::htpPredictExperts;
#include "baseline-callback.inc"
    }
  }
  std::string traceText() {
    if (!trace)
      return {};
    std::fflush(trace.get());
    std::rewind(trace.get());
    std::string s;
    char buf[512];
    while (std::fgets(buf, sizeof(buf), trace.get()))
      s += buf;
    return s;
  }
};

int main() {
  std::vector<float> x(2048), w(2048 * 64), b(64);
  for (unsigned seed = 0; seed < 12; ++seed) {
    fill(x);
    fill(w);
    fill(b);
    for (unsigned top : {1u, 4u, 8u, 64u, 80u})
      check(x.data(), w.data(), 2048, 64, top, b.data(), true);
    check(x.data(), w.data(), 2048, 64, 4, b.data(), false);
  }
  // Equal logits, bias-only ties and sigmoid saturation ranking.
  std::fill(x.begin(), x.end(), 0.0f);
  fill(w);
  std::fill(b.begin(), b.end(), 0.0f);
  check(x.data(), w.data(), 2048, 64, 64, b.data(), true);
  auto ids =
    after::htpPredictExperts(x.data(), w.data(), 2048, 64, 64, b.data(), true);
  for (unsigned e = 0; e < 64; ++e)
    assert(ids[e] == e);
  for (unsigned e = 0; e < 64; ++e)
    b[e] = float(e % 5) * 0.25f;
  check(x.data(), w.data(), 2048, 64, 8, b.data(), true);
  std::fill(w.begin(), w.end(), 0.0f);
  x[0] = 1.0f;
  for (unsigned e = 0; e < 64; ++e)
    w[e] = e & 1 ? 1000.0f : -1000.0f;
  check(x.data(), w.data(), 2048, 64, 8, b.data(), true);
  // Cancellation and one-ULP inputs exercise h-order and fused rounding.
  fill(x);
  fill(w);
  fill(b);
  for (unsigned h = 0; h < 2048; ++h) {
    x[h] = (h % 3 == 0) ? fromBits(0x3f800001u) : ((h % 3 == 1) ? 1.0f : -1.0f);
    for (unsigned e = 0; e < 64; ++e)
      w[h * 64 + e] = (h % 3 == 0)
                        ? fromBits(0x3f7fffffu)
                        : (h % 3 == 1 ? -1.0f : std::ldexp(float(e + 1), -24));
  }
  check(x.data(), w.data(), 2048, 64, 64, b.data(), true);
  // Signed zeros, subnormals, largest finite, overflow, Inf, qNaN, sNaN.
  const uint32_t special[] = {
    0u,          0x80000000u, 1u,          0x80000001u, 0x007fffffu,
    0x00800000u, 0x3f800001u, 0x7f7fffffu, 0xff7fffffu, 0x7f800000u,
    0xff800000u, 0x7fc12345u, 0x7f812345u};
  for (uint32_t z : special) {
    std::fill(x.begin(), x.end(), 1.0f);
    std::fill(w.begin(), w.end(), 0.25f);
    std::fill(b.begin(), b.end(), 0.0f);
    x[1023] = fromBits(z);
    check(x.data(), w.data(), 2048, 64, 8, b.data(), true);
    x[1023] = 1;
    w[1023 * 64 + 17] = fromBits(z);
    check(x.data(), w.data(), 2048, 64, 8, b.data(), true);
    w[1023 * 64 + 17] = 0.25f;
    b[17] = fromBits(z);
    check(x.data(), w.data(), 2048, 64, 8, b.data(), true);
  }
  std::fill(x.begin(), x.end(), 2.0f);
  std::fill(w.begin(), w.end(), std::numeric_limits<float>::max());
  std::fill(b.begin(), b.end(), 0.0f);
  check(x.data(), w.data(), 2048, 64, 4, b.data(), true);
  // Guard failures have exact-size allocations: an incorrect fixed-shape load
  // is detected by ASan rather than masked by a padded reference allocation.
  for (auto shape : {std::pair<unsigned, unsigned>{2047, 64},
                     {2049, 64},
                     {2048, 63},
                     {2048, 65},
                     {2816, 128},
                     {3, 4},
                     {1, 1}}) {
    std::vector<float> gx(shape.first), gw(size_t(shape.first) * shape.second),
      gb(shape.second);
    fill(gx);
    fill(gw);
    fill(gb);
    check(gx.data(), gw.data(), shape.first, shape.second, 4, gb.data(), true);
  }
  fill(x);
  fill(w);
  fill(b);
  check(x.data(), w.data(), 2048, 64, 4, nullptr, true);
  check(nullptr, w.data(), 2048, 64, 4, b.data(), true);
  check(x.data(), nullptr, 2048, 64, 4, b.data(), true);
  check(x.data(), w.data(), 0, 64, 4, b.data(), true);
  check(x.data(), w.data(), 2048, 0, 4, b.data(), true);
  check(x.data(), w.data(), 2048, 64, 0, b.data(), true);
  // Legal 4-byte alignment, but deliberately not SIMD aligned.
  std::vector<float> ux(2049), uw(2048 * 64 + 1);
  fill(ux);
  fill(uw);
  check(ux.data() + 1, uw.data() + 1, 2048, 64, 4, b.data(), true);
  for (const char *value : {"0", "1", "true", "01", "", "2", "1x"}) {
    assert(setenv("NNTR_LFM2_PREDICT_REGISTER_ACCUM", value, 1) == 0);
    Shape s;
    assert(enabled(s) == (std::strcmp(value, "1") == 0));
    ++guard_cases;
  }
  unsetenv("NNTR_LFM2_PREDICT_REGISTER_ACCUM");
  assert(!enabled(Shape{}));
  ++guard_cases;
  setenv("NNTR_LFM2_PREDICT_REGISTER_ACCUM", "1", 1);
  for (unsigned field = 0; field < 4; ++field) {
    Shape s;
    if (field == 0)
      s.w_bits = 2;
    if (field == 1)
      s.K = 2049;
    if (field == 2)
      s.inter = 1535;
    if (field == 3)
      s.N_out = 2816;
    assert(!enabled(s));
    ++guard_cases;
  }
  // Actual prediction callback, including residual history, gamma fallback,
  // trace rankings, resident filtering and confidence feedback. Queue is a log.
  for (bool gemma : {false, true})
    for (bool conf : {false, true})
      for (bool trace : {false, true})
        for (float blend : {0.0f, 0.5f, 1.0f}) {
          const unsigned h = gemma ? 2816 : 2048, e = gemma ? 128 : 64;
          std::vector<float> jw(size_t(h) * e), jb(e), gamma(h);
          fill(jw);
          fill(jb);
          fill(gamma);
          Predictor<false> old(h, e, jw.data(), gemma ? nullptr : jb.data(),
                               gemma ? gamma.data() : nullptr, conf, trace);
          Predictor<true> now(h, e, jw.data(), gemma ? nullptr : jb.data(),
                              gemma ? gamma.data() : nullptr, conf, trace);
          old.blend = now.blend = blend;
          now.register_accum = !gemma;
          PredictionJob job;
          job.input.resize(h);
          job.native = true;
          for (uint64_t token = 1; token <= 3; ++token)
            for (size_t layer = 1; layer <= 2; ++layer) {
              fill(job.input);
              job.layer = layer;
              job.epoch = (token << 32) + layer;
              assert(old.run(job));
              assert(now.run(job));
              assert(old.submitted == now.submitted);
              if (conf) {
                const uint32_t actual[] = {0, 1, 2, 3};
                old.prediction_confidence_->observe(layer, job.epoch, actual,
                                                    4);
                now.prediction_confidence_->observe(layer, job.epoch, actual,
                                                    4);
              }
              ++job_cases;
            }
          assert(old.traceText() == now.traceText());
        }
  std::printf("PREDICT_REGISTER PASS cases=%u raw_scores=%u callback_jobs=%u "
              "env_shape_guards=%u\n",
              cases, score_cases, job_cases, guard_cases);
}

	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hexkl_mm_u8i4_moe.c"
	.globl	hexkl_moe_scratch_free          // -- Begin function hexkl_moe_scratch_free
	.falign
	.type	hexkl_moe_scratch_free,@function
hexkl_moe_scratch_free:                 // @hexkl_moe_scratch_free
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#1)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB0_3
	}
// %bb.1:                               // %if.then
	{
		r17:16 = combine(#0,#0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r3:2 = add(r3:2,r5:4)
		r1 = memw(r0+#0)
		memw(r0+#48) = #0
	}
	{
		r0 = r1
		memd(r0+#24) = r3:2
		memd(r18+#40) = r17:16
	}
	{
		call free
		memd(r18+#56) = r17:16
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r18+#0) = r17:16
		memw(r18+#8) = #0
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB0_3:                                // %if.end
	{
		jumpr r31
	}
.Lfunc_end0:
	.size	hexkl_moe_scratch_free, .Lfunc_end0-hexkl_moe_scratch_free
                                        // -- End function
	.globl	hexkl_moe_scratch_reserve       // -- Begin function hexkl_moe_scratch_reserve
	.falign
	.type	hexkl_moe_scratch_reserve,@function
hexkl_moe_scratch_reserve:              // @hexkl_moe_scratch_reserve
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#0)
		r17:16 = combine(r1,r0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r6 = memw(r0+#8)
		memd(r0+#40) = r5:4
	}
	{
		r1:0 = combine(#0,#1)
		p0 = cmp.gtu(r17,r6)
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r3:2,r1:0)
		r18 = #0
		memd(r16+#56) = r5:4
		memw(r16+#48) = #0
	}
	{
		if (!p0) jump:nt .LBB1_5
		memd(r16+#24) = r1:0
	}
// %bb.1:                               // %hexkl_moe_scratch_free.exit
	{
		r1:0 = combine(#0,#2)
		memw(r16+#40) = #0
		memw(r16+#56) = #0
	}
	{
		r3:2 = add(r3:2,r1:0)
		r0 = memw(r16+#0)
	}
	{
		call free
		memd(r16+#24) = r3:2
	}
	.falign
// %bb.2:                               // %hexkl_moe_scratch_free.exit
	{
		call malloc
		r0 = add(r17,#128)
		memw(r16+#4) = #0
		memw(r16+#8) = #0
	}
	.falign
// %bb.3:                               // %hexkl_moe_scratch_free.exit
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB1_6
		memw(r16+#0) = r0
		if (!p1.new) memw(r16+#8) = r17
	}
// %bb.4:                               // %if.end3
	{
		r2 = add(r0,#127)
	}
	{
		r2 = and(r2,#-128)
		memw(r16+#4) = r2.new
	}
	.falign
.LBB1_5:                                // %return
	{
		r0 = r18
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB1_6:
	{
		r18 = ##-2147482622
		r0 = ##-2147482622
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	hexkl_moe_scratch_reserve, .Lfunc_end1-hexkl_moe_scratch_reserve
                                        // -- End function
	.globl	hexkl_moe_carve                 // -- Begin function hexkl_moe_carve
	.balign 32
	.type	hexkl_moe_carve,@function
hexkl_moe_carve:                        // @hexkl_moe_carve
// %bb.0:                               // %entry
	{
		r3 = add(r1,#127)
		r2 = memw(r0+#0)
	}
	{
		r3 = and(r3,#-128)
	}
	{
		r3 = add(r2,r3)
		jumpr r31
		r0 = r2
		memw(r0+#0) = r3.new
	}
.Lfunc_end2:
	.size	hexkl_moe_carve, .Lfunc_end2-hexkl_moe_carve
                                        // -- End function
	.globl	hexkl_moe_push_weight_chunk     // -- Begin function hexkl_moe_push_weight_chunk
	.falign
	.type	hexkl_moe_push_weight_chunk,@function
hexkl_moe_push_weight_chunk:            // @hexkl_moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		r6 = r5
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		memd(r29+#48) = r19:18
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r24 = memw(r29+#76)
		memd(r29+#32) = r23:22
	}
	{
		if (p0) jump:nt .LBB3_3
		r5 = memw(r29+#72)
		memd(r29+#16) = r27:26
	}
// %bb.1:                               // %if.then
	{
		r3:2 = combine(r18,#0)
		r4 = r6
		memw(r29+#0) = r24
		memw(r29+#4) = #0
	}
	{
		call moe_push_native_chunk
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB3_3:                                // %if.end
	{
		r27 = asl(r5,#9)
		r7 = r4
		r17 = r3
	}
	{
		r21:20 = vaslw(r7:6,#9)
	}
	{
		r19 = r20
	}
	{
		r19 += add(r0,r1)
		r2 = memw(r18+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB3_8
	}
// %bb.4:                               // %if.then3
	{
		r26 = r21
	}
	{
		call hexkl_dma_ring_next_idx
		r27:26 = vlsrw(r27:26,#1)
	}
	.falign
// %bb.5:                               // %if.then3
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
		memw(r29+#12) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_12
	}
// %bb.6:                               // %if.then12
	{
		r0 = lsr(r3,#10)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then12
	{
		r3 = lsr(r20,#1)
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		r2 = memw(r18+#4)
	}
	{
		if (!p1) jump:nt .LBB3_13
	}
	{
		jump .LBB3_15
	}
	.falign
.LBB3_8:                                // %if.end30
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.9:                               // %if.end30
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = r0
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_19
	}
// %bb.10:                              // %if.then44
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then44
	{
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		if (!p1.new) jump:t .LBB3_20
		r2 = memw(r18+#4)
	}
	{
		jump .LBB3_22
	}
	.falign
.LBB3_12:
	{
		r3 = lsr(r20,#1)
		p1 = cmp.eq(r24,#0)
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	{
		if (p1) jump:nt .LBB3_15
	}
	.falign
.LBB3_13:                               // %land.rhs.i
	{
		r16 = #1
		r4 = memw(r18+#36)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB3_15
	}
// %bb.14:                              // %lor.rhs.i
	{
		r4 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r4,#0)
	}
	.falign
.LBB3_15:                               // %moe_weight_src_bypass.exit
	{
		r1 = add(r2,r3)
		r0 = add(r19,r27)
		r3:2 = combine(r26,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.16:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_26
	}
// %bb.17:                              // %if.then24
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.18:                              // %if.then24
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
		memd(r2+#96) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_19:
	{
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB3_22
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	.falign
.LBB3_20:                               // %land.rhs.i105
	{
		r16 = #1
		r3 = memw(r18+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB3_22
	}
// %bb.21:                              // %lor.rhs.i109
	{
		r3 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r3,#0)
	}
	.falign
.LBB3_22:                               // %moe_weight_src_bypass.exit112
	{
		r1 = add(r2,r20)
		r0 = r19
		r3:2 = combine(r21,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.23:                              // %moe_weight_src_bypass.exit112
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_27
	}
// %bb.24:                              // %if.then56
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then56
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		r0 = r26
		jump .LBB3_28
		memd(r2+#96) = r1:0
	}
	.falign
.LBB3_26:
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_27:
	{
		r0 = r26
	}
	.falign
.LBB3_28:                               // %cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hexkl_moe_push_weight_chunk, .Lfunc_end3-hexkl_moe_push_weight_chunk
                                        // -- End function
	.falign
	.type	moe_push_native_chunk,@function // -- Begin function moe_push_native_chunk
moe_push_native_chunk:                  // @moe_push_native_chunk
// %bb.0:                               // %entry
	{
		r9:8 = combine(#0,#0)
		p1 = cmp.eq(r4,#0)
		memd(r29+#-16) = r17:16
		allocframe(#136)
	}                                       // 8-byte Folded Spill
	{
		r2 = add(r4,add(r5,#3))
		r17:16 = combine(r0,r3)
		r6 = memw(r29+#144)
		memw(r29+#36) = r2
	}
	{
		r27 = lsr(r2,#2)
		p0 = cmp.eq(r6,#0)
		r13 = #0
		memd(r29+#88) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r2 = #0
		memd(r29+#120) = r19:18
		memd(r29+#112) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#104) = r23:22
		memd(r29+#96) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) memd(r3+#64) = r9:8
		if (p1) memd(r3+#56) = r9:8
	}
	{
		if (p0) jump:nt .LBB4_3
		memw(r29+#28) = r2
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB4_3
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_3:                                // %moe_weight_src_bypass.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = lsr(r4,#2)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.gtu(r27,r26)
		if (!p0.new) jump:t .LBB4_95
		if (p0.new) r2 = memw(r29+#36)
		if (p0.new) r4 = memw(r16+#28)
	}                                       // 4-byte Folded Reload
// %bb.4:                               // %for.body.lr.ph
	{
		r5 = ##-1431655765
		r3 = add(r4,#23)
		r6 = memw(r29+#148)
	}
	{
		r3 = mpyu(r3,r5)
		p0 = cmp.eq(r2,#0)
		r2 = #640
	}
	{
		if (p0) r12 = ##2560
		memw(r29+#40) = r6
		if (!p0) memw(r29+#44) = r27
	}                                       // 4-byte Folded Spill
	{
		r3 = lsr(r3,#4)
	}
	{
		r14 = mpyi(r3,r2)
		if (p0) jump:nt .LBB4_39
		memw(r29+#24) = r14.new
	}                                       // 4-byte Folded Spill
// %bb.5:
	{
		p1 = cmp.eq(r6,#0)
		r9:8 = combine(#0,#1)
		r25:24 = combine(#0,#0)
	}
	{
		r2 = p1
		memw(r29+#48) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_6:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_10 Depth 2
	{
		r1:0 = asl(r9:8,r26)
		r18 = add(r26,#1)
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p0 = cmp.eq(r5:4,r25:24)
		if (!p0.new) r18 = add(r26,#1)
		if (p0.new) jump:t .LBB4_8
	}
// %bb.7:                               //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = cmp.gtu(r27,r18)
		r26 = r18
		if (p1.new) jump:t .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_8:                                // %if.end13
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		p1 = cmp.gtu(r27,r18)
		if (p1.new) r2 = sub(r27,r18)
	}
	{
		if (!p1) jump:nt .LBB4_13
		memd(r16+#64) = r1:0
	}
// %bb.9:                               //   in Loop: Header=BB4_6 Depth=1
	{
		loop0(.LBB4_10,r2)
	}
	.falign
.LBB4_10:                               // Block address taken
                                        // %land.rhs
                                        //   Parent Loop BB4_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3:2 = asl(r9:8,r18)
	}
	{
		r5:4 = and(r1:0,r3:2)
	}
	{
		r1:0 = or(r1:0,r3:2)
		p0 = cmp.eq(r5:4,r25:24)
		if (p0.new) r18 = add(r18,#1)
		if (!p0.new) jump:nt .LBB4_13
	}
// %bb.11:                              // %while.body
                                        //   in Loop: Header=BB4_10 Depth=2
	{
		nop
		memd(r16+#64) = r1:0
	} :endloop0
// %bb.12:                              //   in Loop: Header=BB4_6 Depth=1
	{
		r18 = r27
	}
	.falign
.LBB4_13:                               // %while.end
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = sub(r18,r26)
		r0 = #16256
	}
	{
		r17 = mpyi(r2,r14)
		r2 = #8064
	}
	{
		p1 = bitsclr(r17,r0)
		if (!p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB4_20
	}
// %bb.14:                              // %while.body.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		if (!p0.new) r2 = ##3968
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.15:                              // %while.body.1.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		if (!p1.new) r2 = #1920
		if (p1.new) jump:nt .LBB4_22
	}
// %bb.16:                              // %while.body.2.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #2048
		if (!p0.new) r2 = #896
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.17:                              // %while.body.3.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		r19 = #1024
		if (!p1.new) r2 = #384
		if (p1.new) jump:nt .LBB4_26
	}
// %bb.18:                              // %while.body.4.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #512
		if (!p0.new) r2 = #128
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.19:                              // %while.body.5.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = !tstbit(r17,#7)
	}
	{
		r19 = mux(p1,##256,r2)
		jump .LBB4_26
	}
	.falign
.LBB4_20:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #16384
		jump .LBB4_26
	}
	.falign
.LBB4_22:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #4096
	}
	.falign
.LBB4_26:                               // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r17)
		r27 = memw(r16+#44)
		memw(r29+#32) = r13
	}                                       // 4-byte Folded Spill
	.falign
// %bb.27:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r21 = r0
	}
	.falign
// %bb.28:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r20 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_31
	}
// %bb.29:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.30:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(r1,r0)
		jump .LBB4_32
	}
	.falign
.LBB4_31:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(#0,#0)
	}
	.falign
.LBB4_32:                               // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r5:4 = combine(r21,r19)
		r2 = memw(r29+#24)
		r7 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = #1
	}
	{
		r6 = mpyi(r26,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3:2 = combine(r19,r19)
		r1 = add(r27,r6)
		r0 = add(r7,r6)
	}
	.falign
// %bb.33:                              // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r26 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.34:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.35:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r26+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_38
	}
// %bb.36:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.37:                              // %if.then11.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r20
		r4 = memw(r2+#4)
		memw(r29+#0) = r19

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = r21
		memw(r29+#8) = r19
	}
	.falign
.LBB4_38:                               // %moe_native_push2d.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r9:8 = combine(#0,#1)
		r26 = r18
		r13 = memw(r29+#32)
		r27 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r17,r13)
		p1 = cmp.gtu(r27,r18)
		r14 = memw(r29+#24)
		memw(r16+#72) = r20
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_39:                               // %for.body.us.preheader
	{
		r5 = mpyu(r4,r5)
		p0 = cmp.gtu(r4,#95)
		r7:6 = combine(#0,#2)
		r21 = memw(r16+#32)
	}
	{
		r5 = mpyi(r26,r3)
		r15 = lsr(r5,#6)
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
	}
	{
		r7 = insert(r26,#21,#11)
		r8 = asl(r15,#2)
		memw(r29+#36) = r15
	}                                       // 4-byte Folded Spill
	{
		r9 = +mpyi(r15,#3)
		r21 = and(##-512,asl(r21,#4))
		p1 = cmp.eq(r3,r8)
	}
	{
		r20 = mpyi(r5,r2)
		r3 = p1
		r5 = sub(r3,r8)
		memw(r29+#52) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r17 += add(r1,r7)
		r7 = mpyi(r15,r12)
		p1 = cmp.gtu(r5,#2)
		memw(r29+#44) = r7.new
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r9,r21)
		r4 = p0
		r7 = add(r5,#-2)
		memw(r29+#32) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r12 = minu(r5,r6)
		r6 = minu(r7,r6)
		r4 = add(r9,#1)
		memw(r29+#72) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r4,r21)
		r7 = +mpyi(r21,#3)
		memw(r29+#76) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p1
		memw(r29+#48) = r7
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r12,r2)
		r2 = mpyi(r6,r2)
		memw(r29+#56) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#60) = r3
		memw(r29+#64) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_40:                               // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1:0 = asl(r11:10,r26)
		r25 = r13
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p1 = cmp.eq(r5:4,r19:18)
		if (!p1.new) jump:t .LBB4_94
		if (p1.new) r23 = memw(r16+#44)
	}
// %bb.41:                              // %if.end13.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		r24 = add(r23,r20)
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB4_54
		memd(r16+#64) = r1:0
	}
// %bb.42:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.43:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_46
	}
// %bb.44:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_47
	}
	.falign
.LBB4_46:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_47:                               // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = combine(r24,r17)
		r3 = #2560
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = #1280
		r2 = memw(r29+#48)
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.48:                              // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.49:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.50:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_53
	}
// %bb.51:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.52:                              // %if.then11.i176.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_53:                               // %moe_native_push2d.exit179.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r22
	}
	.falign
.LBB4_54:                               // %if.end55.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r2)
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_57
		if (p0.new) r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
// %bb.55:                              // %for.inc.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		p0 = r2
		if (p0.new) jump:t .LBB4_69
	}
	.falign
.LBB4_56:                               // %if.end55.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	{
		jump .LBB4_81
	}
	.falign
.LBB4_57:                               // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.58:                              // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_61
	}
// %bb.59:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.60:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_62
	}
	.falign
.LBB4_61:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_62:                               // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = r24
		r3 = #1280
		r5 = #1
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		r4 = memw(r29+#60)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	.falign
// %bb.63:                              // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.64:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.65:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_68
	}
// %bb.66:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.67:                              // %if.then11.i194.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_68:                               // %moe_native_push2d.exit197.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#32)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_56
	}
	.falign
.LBB4_69:                               // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.70:                              // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_73
	}
// %bb.71:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.72:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_74
	}
	.falign
.LBB4_73:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_74:                               // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = #1280
		r0 = add(r17,r21)
		r3 = #2560
		r4 = #1280
	}
	{
		r23 += add(r20,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r1 = r23
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.75:                              // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.76:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r23 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.77:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r23
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_80
	}
// %bb.78:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.79:                              // %if.then11.i176.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_80:                               // %moe_native_push2d.exit179.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	.falign
.LBB4_81:                               // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.82:                              // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r23 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_85
	}
// %bb.83:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.84:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_86
	}
	.falign
.LBB4_85:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_86:                               // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = add(r24,#1280)
		r3 = #1280
		r2 = memw(r29+#76)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r5 = #1
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		memw(r29+#4) = #1
	}
	.falign
// %bb.87:                              // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.88:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r22 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.89:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r22
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_92
	}
// %bb.90:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.91:                              // %if.then11.i194.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r23
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_92:                               // %moe_native_push2d.exit197.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r23
	}
	.falign
.LBB4_93:                               // %for.inc.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
		r14 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r25,r14)
	}
	.falign
.LBB4_94:                               // %cleanup77.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r20 = add(r20,r14)
		r17 = add(r17,#2048)
	}
	{
		r26 = add(r26,#1)
		if (!cmp.eq(r26.new,r27)) jump:t ##.LBB4_40
	}
	.falign
.LBB4_95:                               // %for.cond.cleanup
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_97
	}
// %bb.96:                              // %if.then81
	{
		r0 = lsr(r13,#10)
		r1 = #0
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB4_97:                               // %do.end
	{
		r0 = memw(r16+#72)
		r17:16 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#120)
		r21:20 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r23:22 = memd(r29+#104)
		r25:24 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r27:26 = memd(r29+#88)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end4:
	.size	moe_push_native_chunk, .Lfunc_end4-moe_push_native_chunk
                                        // -- End function
	.globl	hexkl_moe_expand_chunk          // -- Begin function hexkl_moe_expand_chunk
	.balign 32
	.type	hexkl_moe_expand_chunk,@function
hexkl_moe_expand_chunk:                 // @hexkl_moe_expand_chunk
// %bb.0:                               // %entry
	{
		r4 = r3
		r3 = r2
		r6 = r4
		allocframe(#16)
	}
	{
		r2 = memw(r29+#28)
		memw(r29+#8) = r2.new
	}
	{
		r2 = memw(r29+#24)
		memw(r29+#4) = r2.new
	}
	{
		call moe_expand_chunk
		r5 = r6
		r2 = #0
		memw(r29+#0) = r5
	}
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end5:
	.size	hexkl_moe_expand_chunk, .Lfunc_end5-hexkl_moe_expand_chunk
                                        // -- End function
	.falign
	.type	moe_expand_chunk,@function      // -- Begin function moe_expand_chunk
moe_expand_chunk:                       // @moe_expand_chunk
// %bb.0:                               // %entry
	{
		r6 = r3
		allocframe(r29,#256):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r7 = memw(r3+#44)
		deallocframe
	}
	{
		p1 = cmp.eq(r7,#0)
	}
	{
		r18 = memw(r30+#12)
		memd(r30+#-16) = r19:18
	}
	{
		r22 = r4
		r17 = r0
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r0 = add(r3,#88)
		if (!p1) r12 = add(r17,r1)
		r16 = memw(r30+#16)
		r4 = memw(r30+#8)
	}
	{
		if (p1) jump:nt .LBB6_10
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r5 = add(r4,add(r18,#3))
		r3 = lsr(r4,#2)
	}
	{
		r7 = lsr(r5,#2)
		r5:4 = combine(#0,#0)
	}
	{
		if (p0.new) r7 = sub(r7,r3)
		p0 = cmp.gtu(r7,r3); if (!p0.new) jump:t .LBB6_4
	}
// %bb.2:
	{
		loop0(.LBB6_3,r7)
		r9:8 = combine(#0,#1)
	}
	.falign
.LBB6_3:                                // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r9:8,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB6_4:                                // %for.cond.cleanup7.i
	{
		r15 = ##-1431655765
		r13 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r7 = #0
		r28 = add(r13,#23)
		r1 = add(r13,#95)
		r14 = add(r3,#127)
	}
	{
		r2 = mpyu(r28,r15)
		r15 = mpyu(r1,r15)
		r9:8 = memd(r6+#56)
		memw(r29+#156) = r2
	}
	{
		r14 = lsr(r14,#7)
		r28 = lsr(r2,#4)
		p1 = cmp.gtu(r14,#127)
		memw(r29+#168) = r13
	}
	{
		r2 = lsr(r15,#6)
		r13:12 = and(r5:4,~r9:8)
		memw(r29+#152) = r12
		memw(r29+#172) = r14
	}
	{
		r15 = +mpyi(r28,##640)
		memw(r29+#184) = r7
		memd(r29+#160) = r13:12
	}
	{
		if (!p1) jump:nt .LBB6_16
		memw(r29+#176) = r2
		memw(r29+#180) = r15
	}
// %bb.5:
	{
		r15 = lsr(r14,#1)
		r19:18 = combine(#0,#1)
		r11:10 = combine(#0,#0)
		r28 = and(r14,#1)
	}
	{
		p1 = cmp.gtu(r15,#0)
		if (!p1.new) jump:t .LBB6_14
	}
// %bb.6:
	{
		loop0(.LBB6_7,r15)
		r15:14 = combine(#0,#0)
	}
	.falign
.LBB6_7:                                // =>This Inner Loop Header: Depth=1
	{
		r21:20 = combine(r13,r12)
		r1 = add(r14,r2)
		r17 = add(r15,#1)
		r23:22 = combine(r13,r12)
	}
	{
		r21:20 &= asl(r19:18,r15)
		r23:22 &= asl(r19:18,r17)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r21:20,r11:10)
		if (!p0.new) r14 = add(r1,#0)
		if (!p0.new) r7 = add(r1,#0)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r1 = add(r14,r2)
	}
	{
		if (!p0) r14 = add(r1,#0)
		if (!p0) r7 = add(r1,#0)
	} :endloop0
// %bb.8:
	{
		p1 = cmp.gtu(r28,#0)
		if (!p1.new) jump:t .LBB6_15
	}
	.falign
.LBB6_9:                                // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r19:18,r15)
		r2 = add(r14,r2)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		if (!p1.new) r7 = add(r2,#0)
		jump .LBB6_15
	}
	.falign
.LBB6_10:                               // %if.end
	{
		r23 = r1
		r19 = add(r29,#0)
		r2 = memw(r6+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB6_39
	}
// %bb.11:                              // %if.end4
	{
		r21:20 = vaslw(r5:4,#9)
		r1 = r19
	}
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.12:                              // %if.end4
	{
		r20 += add(r17,r23)
		r18 = and(##2147483392,asl(r18,#8))
		r5:4 = combine(r16,r19)
	}
	{
		call hvx_expand_i2i4_rows
		r1:0 = combine(r21,r20)
		r3:2 = combine(r22,r18)
	}
	.falign
// %bb.13:                              // %if.end4
	{
		jump .LBB6_39
	}
	.falign
.LBB6_14:
	{
		r15:14 = combine(#0,#0)
		p1 = cmp.gtu(r28,#0)
		if (p1.new) jump:t .LBB6_9
	}
	.falign
.LBB6_15:                               // %for.cond.cleanup24.i.loopexit
	{
		memw(r29+#184) = r7
	}
	.falign
.LBB6_16:                               // %for.cond.cleanup24.i
	{
		r7 = #0
		r2 = memb(r0+#0)
	}
	{
		r2 = abs(r2)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB6_19
	}
// %bb.17:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#7); if (p1.new) jump:nt .LBB6_19
	}
// %bb.18:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_19:                               // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_24
	}
// %bb.20:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_22
	}
// %bb.21:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_22:                               // %lor.lhs.false.1.i.i
	{
		if (p0) jump:nt .LBB6_25
	}
// %bb.23:                              // %lor.lhs.false.1.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_25
	}
	.falign
.LBB6_24:
	{
		r12 = r2
	}
	.falign
.LBB6_25:                               // %for.inc.1.i.i
	{
		r2 = memb(r6+#90)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB6_30
	}
// %bb.26:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB6_28
	}
// %bb.27:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_28:                               // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,#0)
		if (p0.new) jump:nt .LBB6_31
	}
// %bb.29:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,r2)
		if (!p1.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_31
	}
	.falign
.LBB6_30:
	{
		r2 = r12
	}
	.falign
.LBB6_31:                               // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_36
	}
// %bb.32:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_34
	}
// %bb.33:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB6_38
	}
	.falign
.LBB6_34:                               // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB6_37
	}
// %bb.35:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_37
	}
	.falign
.LBB6_36:
	{
		r12 = r2
	}
	.falign
.LBB6_37:                               // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r7 = maxu(r12,r2)
	}
	.falign
.LBB6_38:                               // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r29+#12) = r3.new
	}
	{
		r1 = add(pc,##moe_expand_unit@PCREL)
		r2 = add(r29,#0)
		r0 = r16
	}
	{
		call hvx_worker_pool_run
		r3 = #8
		memw(r29+#188) = r7
		memd(r6+#56) = r5:4
	}
	.falign
.LBB6_39:                               // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	moe_expand_chunk, .Lfunc_end6-moe_expand_chunk
                                        // -- End function
	.globl	hexkl_moe_push_act_block        // -- Begin function hexkl_moe_push_act_block
	.falign
	.type	hexkl_moe_push_act_block,@function
hexkl_moe_push_act_block:               // @hexkl_moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17:16 = combine(r4,r2)
		memd(r29+#-16) = r17:16
		allocframe(#40)
	}                                       // 8-byte Folded Spill
	{
		r18 = r3
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r19:18
		memd(r29+#16) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) r19 = ##16384
		if (p0) jump:nt .LBB7_5
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = bitsclr(r5,#3)
		if (p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB7_5
	}
// %bb.2:                               // %while.body.1.i
	{
		p0 = tstbit(r5,#0)
		if (p0.new) r19 = ##2048
	}
	{
		if (!p0) r19 = ##4096
		jump .LBB7_5
	}
	.falign
.LBB7_5:                                // %moe_dma_row_size.exit
	{
		call hexkl_dma_ring_next_idx
		r22 = asl(r5,#11)
	}
	.falign
// %bb.6:                               // %moe_dma_row_size.exit
	{
		call __hexagon_udivsi3
		r23 = r0
		r1:0 = combine(r19,r22)
	}
	.falign
// %bb.7:                               // %moe_dma_row_size.exit
	{
		r16 += mpyi(r17,r18)
		r5:4 = combine(r0,r19)
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r16
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.8:                               // %moe_dma_row_size.exit
	{
		r0 = r23
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	hexkl_moe_push_act_block, .Lfunc_end7-hexkl_moe_push_act_block
                                        // -- End function
	.globl	hexkl_moe_pack_bg_worker        // -- Begin function hexkl_moe_pack_bg_worker
	.falign
	.type	hexkl_moe_pack_bg_worker,@function
hexkl_moe_pack_bg_worker:               // @hexkl_moe_pack_bg_worker
// %bb.0:                               // %entry
	{
		r3 = r1
		allocframe(#8)
	}
	{
		r4 = memw(r2+#28)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.1:                               // %land.lhs.true
	{
		r4 = memb(r4+r1<<#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.2:                               // %cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB8_3:                                // %if.end
	{
		r4 = asl(r3,#4)
		r5 = #16
		r0 = memw(r2+#4)
		if (cmp.eq(r0.new,#0)) jump:nt .LBB8_5
	}
// %bb.4:                               // %if.then4
	{
		r6 = r2
		r1 = memw(r2+#8)
	}
	{
		r3 = addasl(r5,r3,#4)
		r2 = r4
		r4 = memw(r6+#24)
		r5 = memw(r6+#20)
	}
	{
		jump hvx_gather_u8_ah_rows
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB8_5:                                // %if.end7
	{
		r6 = asl(r3,#4)
		r7 = #16
		r1 = memw(r2+#8)
		r8 = memw(r2+#16)
	}
	{
		r3 = addasl(r7,r3,#4)
		r0 = memw(r2+#0)
		r4 = memw(r2+#24)
	}
	{
		r5 = memw(r2+#12)
		r2 = memw(r2+#20)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r2 = r6
		memw(r29+#4) = r2
		memw(r29+#0) = r8
	}
	.falign
// %bb.6:                               // %if.end7
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	hexkl_moe_pack_bg_worker, .Lfunc_end8-hexkl_moe_pack_bg_worker
                                        // -- End function
	.globl	hexkl_moe_dma_copy              // -- Begin function hexkl_moe_dma_copy
	.falign
	.type	hexkl_moe_dma_copy,@function
hexkl_moe_dma_copy:                     // @hexkl_moe_dma_copy
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r2,#0)
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r19:18
		memd(r29+#32) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r24 = ##1048576
		memd(r29+#24) = r23:22
		memd(r29+#16) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r27 = ##4095
		if (p0) jump:nt .LBB9_33
		memd(r29+#8) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:
	{
		r17:16 = combine(r4,r2)
		r19:18 = combine(r1,r3)
		r23 = #0
		r20 = r0
	}
	{
		r25 = #16383
		r26 = #8191
	}
	.falign
.LBB9_2:                                // %while.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r16,r23)
	}
	{
		r21 = minu(r2,r24)
	}
	{
		p1 = bitsclr(r21,r25)
		if (!p1.new) r22 = ##8192
		if (p1.new) jump:nt .LBB9_16
	}
// %bb.3:                               // %while.body.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r26)
		if (!p0.new) r2 = #2047
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.4:                               // %while.body.1.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r27)
		if (!p1.new) r22 = ##2048
		if (p1.new) jump:nt .LBB9_18
	}
// %bb.5:                               // %while.body.2.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #1023
		if (!p0.new) r22 = #1024
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.6:                               // %while.body.3.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #511
		if (!p1.new) r22 = #512
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.7:                               // %while.body.4.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #255
		if (!p0.new) r22 = #256
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.8:                               // %while.body.5.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #127
		if (!p1.new) r22 = #128
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.9:                               // %while.body.6.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r22 = #64
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.10:                              // %while.body.7.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#63)
		if (!p1.new) r22 = #32
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.11:                              // %while.body.8.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#31)
		if (!p0.new) r22 = #16
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.12:                              // %while.body.9.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#15)
		if (!p1.new) r22 = #8
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.13:                              // %while.body.10.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#7)
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.14:                              // %while.body.11.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = tstbit(r21,#0)
		p1 = bitsclr(r21,#3)
		if (p1.new) r22 = #4
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.15:                              // %while.body.12.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = mux(p0,#1,#2)
		jump .LBB9_29
	}
	.falign
.LBB9_16:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #16384
		jump .LBB9_29
	}
	.falign
.LBB9_18:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #4096
	}
	.falign
.LBB9_29:                               // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r5:4 = combine(r0,r22)
		r0 = add(r20,r23)
		r1 = add(r19,r23)
		r3:2 = combine(r22,r22)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r18
		memw(r29+#4) = r17
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r23 = add(r21,r23)
		if (cmp.gtu(r16,r23.new)) jump:t .LBB9_2
	}
	.falign
.LBB9_33:                               // %moe_dma_copy.exit
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#16)
		r27:26 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end9:
	.size	hexkl_moe_dma_copy, .Lfunc_end9-hexkl_moe_dma_copy
                                        // -- End function
	.falign
	.type	moe_dma_copy,@function          // -- Begin function moe_dma_copy
moe_dma_copy:                           // @moe_dma_copy
// %bb.0:                               // %entry
	{
		r6 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17 = r2
		p0 = cmp.eq(r2,#0)
		memd(r29+#32) = r27:26
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gt(r5,#-1)
		r27 = #0
		memd(r29+#56) = r21:20
		memd(r29+#48) = r23:22
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r25:24
		memw(r29+#20) = r5
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r6+##hexkl_probe_on@GOT)
	}
	{
		if (p0) r25 = #0
		r2 = memw(r2+#0)
	}
	{
		p2 = cmp.eq(r2,#0)
	}
	{
		p1 = and(p1,!p2)
	}
	{
		r2 = p1
		if (p0) jump:nt .LBB10_38
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.1:
	{
		r19:18 = combine(r3,r4)
		r21:20 = combine(r0,r1)
		r16 = #16383
		r22 = #0
	}
	.falign
.LBB10_2:                               // %while.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r17,r27)
		r3 = ##1048576
	}
	{
		r23 = minu(r2,r3)
		r2 = #8191
	}
	{
		p0 = bitsclr(r23,r16)
		if (!p0.new) r24 = ##8192
		if (p0.new) jump:nt .LBB10_16
	}
// %bb.3:                               // %while.body.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		if (!p1.new) r2 = ##4095
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.4:                               // %while.body.1.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		if (!p2.new) r2 = #2047
		if (p2.new) jump:nt .LBB10_18
	}
// %bb.5:                               // %while.body.2.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #2048
		if (!p0.new) r2 = #1023
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.6:                               // %while.body.3.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #1024
		if (!p1.new) r2 = #511
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.7:                               // %while.body.4.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		r24 = #512
		if (!p2.new) r2 = #255
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.8:                               // %while.body.5.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #256
		if (!p0.new) r2 = #127
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.9:                               // %while.body.6.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #128
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.10:                              // %while.body.7.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,#63)
		r24 = #64
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.11:                              // %while.body.8.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#31)
		r24 = #32
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.12:                              // %while.body.9.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,#15)
		r24 = #16
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.13:                              // %while.body.10.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = tstbit(r23,#0)
		p2 = bitsclr(r23,#7)
		if (p2.new) r24 = #8
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.14:                              // %while.body.11.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#3)
		if (p0.new) r24 = #4
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.15:                              // %while.body.12.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = mux(p1,#1,#2)
		jump .LBB10_29
	}
	.falign
.LBB10_16:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #16384
		jump .LBB10_29
	}
	.falign
.LBB10_18:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #4096
	}
	.falign
.LBB10_29:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call __hexagon_udivsi3
		r25 = r0
		r1:0 = combine(r24,r23)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r26 = r0
		r0 = add(r21,r27)
		r1 = add(r20,r27)
		r3:2 = combine(r24,r24)
	}
	{
		call hexkl_dma_ring_push2d
		r5:4 = combine(r26,r24)
		memw(r29+#0) = r19
		memw(r29+#4) = r18
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB10_34
	}
// %bb.33:                              // %if.then
                                        //   in Loop: Header=BB10_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = combine(r22,#0)
		r3:2 = combine(#4,r25)
		memw(r29+#0) = r24
		memw(r29+#4) = r26
	}
	{
		call hexkl_dma_trace_push
		r22 = add(r22,#1)
		memw(r29+#8) = r24
	}
	.falign
.LBB10_34:                              // %if.end
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r27 = add(r23,r27)
		if (cmp.gtu(r17,r27.new)) jump:t .LBB10_2
	}
// %bb.35:                              // %while.end
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB10_39
	}
	.falign
.LBB10_36:                              // %if.then14
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r25
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.37:                              // %if.then14
	{
		call hexkl_dma_ring_drain
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_trace_wait_end
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB10_38:
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB10_36
	}
	.falign
.LBB10_39:                              // %if.end12
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end10:
	.size	moe_dma_copy, .Lfunc_end10-moe_dma_copy
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layout        // -- Begin function hexkl_mm_u8i4_moe_layout
	.falign
	.type	hexkl_mm_u8i4_moe_layout,@function
hexkl_mm_u8i4_moe_layout:               // @hexkl_mm_u8i4_moe_layout
// %bb.0:                               // %entry
	{
		r8 = r1
		r6 = ##-2147449855
		r7 = r2
	}
	{
		r7 |= or(r1,r0)
		r0 = add(r6,#-32755)
		r5 = r0
		allocframe(#40)
	}
	{
		r7 = and(r7,#31)
		memd(r29+#32) = r17:16
		memd(r29+#24) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r8 = or(r7,and(r8,#15))
		memd(r29+#16) = r21:20
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r8,#0)
		if (!p0.new) jump:nt .LBB11_11
		memd(r29+#0) = r25:24
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.3:                               // %entry
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.4:                               // %entry
	{
		r5 = extractu(r5,#23,#5)
		r7 = extractu(r1,#27,#4)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.5:                               // %if.end16
	{
		r8 = extractu(r5,#21,#0)
		r12 = extractu(r7,#23,#1)
		r0 = add(r6,#-32767)
	}
	{
		r5 = mpyi(r5,r7)
		r9 = lsr(r2,#5)
	}
	{
		r5 = asl(r5,#9)
		r17 = asl(r8,#11)
	}
	{
		r19 = add(r5,add(r17,##1536))
		r5 = mpyi(r12,r9)
	}
	{
		r19 = insert(r19,#9,#2)
		r5 = asl(r5,#9)
	}
	{
		r18 = add(r5,add(r19,##2047))
		r5 = extractu(r7,#20,#1)
	}
	{
		r18 += asl(r1,#8)
		r2 = add(##2047,asl(r2,#8))
		r20 = r18
	}
	{
		r20 = insert(r19,#11,#0)
		r18 += asl(r5,#12)
		r21 = r18
	}
	{
		r21 = insert(r20,#11,#0)
		r22 = r18
	}
	{
		r22 = insert(r21,#12,#0)
	}
	{
		r2 = insert(r22,#11,#0)
	}
	{
		r2 = add(r22,r2)
	}
	{
		r5 = sub(r3,r2)
		p1 = cmp.gtu(r3,r2)
	}
	{
		r2 = lsr(r5,#14)
	}
	{
		if (!p1) r2 = #0
	}
	{
		r2 = minu(r7,r2)
		if (!cmp.gtu(r2.new,#1)) jump:t .LBB11_11
	}
// %bb.6:                               // %cleanup.cont
	{
		r5 = #32
	}
	{
		r2 = minu(r2,r5)
	}
	{
		r23 = and(r2,#62)
	}
	{
		r18 += asl(r23,#14)
		r16 = asl(r23,#13)
	}
	{
		r18 = insert(r16,#11,#0)
		if (!cmp.gtu(r3,r18.new)) jump:t .LBB11_11
	}
// %bb.7:                               // %cond.end95
	{
		r2 = sub(r3,r18)
		r25:24 = combine(r4,r0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r2)
	}
	.falign
// %bb.8:                               // %cond.end95
	{
		r3:2 = combine(r25,r0)
		r4 = #4
		p0 = cmp.gtu(r0,#3); if (p0.new) jump:t .LBB11_10
	}
// %bb.9:
	{
		r0 = r24
		r4 = r2
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
	.falign
.LBB11_10:                              // %cleanup.cont113
	{
		r18 += mpyi(r4,r16)
		r0 = #0
		memw(r3+#28) = r18
		memw(r3+#0) = #0
	}
	{
		memw(r3+#4) = r17
		memw(r3+#8) = r19
	}
	{
		memw(r3+#12) = r20
		memw(r3+#16) = r21
	}
	{
		memw(r3+#20) = r22
		memw(r3+#24) = r23
	}
	{
		memw(r3+#32) = r4
		memw(r3+#36) = r18
	}
	.falign
.LBB11_11:                              // %return
	{
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#0)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end11:
	.size	hexkl_mm_u8i4_moe_layout, .Lfunc_end11-hexkl_mm_u8i4_moe_layout
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layer_run     // -- Begin function hexkl_mm_u8i4_moe_layer_run
	.falign
	.type	hexkl_mm_u8i4_moe_layer_run,@function
hexkl_mm_u8i4_moe_layer_run:            // @hexkl_mm_u8i4_moe_layer_run
// %bb.0:                               // %entry
	{
		allocframe(r29,##17152):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17 = add(pc,##tl2_gu_trace@PCREL)
		memd(r30+#-8) = r17:16
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r26 = r4
		memd(r30+#-48) = r27:26
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r14 = memw(r17+#0)
		r24 = memw(r30+#52)
	}
	{
		p0 = cmp.eq(r24,#0)
		r15 = memw(r17+#4)
		r28 = memw(r17+#8)
	}
	{
		if (p0) jump:nt .LBB12_74
		r16 = memw(r30+#16)
		r10 = memw(r17+#12)
	}
// %bb.1:                               // %if.then
	{
		r9:8 = combine(#0,#1)
		r13:12 = combine(#0,#0)
		r7:6 = memd(r24+#24)
		memw(r24+#48) = #0
	}
	{
		r7:6 = add(r7:6,r9:8)
		p2 = cmp.eq(r16,#0)
		r22 = memw(r24+#56)
		memd(r24+#40) = r13:12
	}
	{
		r4 = ##-2147449856
		memd(r24+#56) = r13:12
		memd(r24+#24) = r7:6
	}
	{
		r18 = add(r4,#-32754)
		if (p2) jump:nt .LBB12_75
	}
	.falign
.LBB12_2:                               // %if.end
	{
		r4 = r18
		p3 = cmp.eq(r26,#0)
		if (p3.new) jump:nt .LBB12_864
	}
// %bb.3:                               // %if.end
	{
		if (p1.new) r4 = add(r18,#0)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB12_864
	}
// %bb.4:                               // %if.end
	{
		p2 = cmp.eq(r1,#0)
		if (p2.new) r4 = add(r18,#0)
		if (p2.new) jump:nt .LBB12_864
	}
// %bb.5:                               // %if.end
	{
		r25 = memw(r30+#20)
		if (cmp.eq(r25.new,#0)) jump:nt ##.LBB12_156
	}
// %bb.6:                               // %if.end
	{
		r21 = memw(r30+#24)
		if (cmp.eq(r21.new,#0)) jump:nt ##.LBB12_100
	}
// %bb.7:                               // %if.end
	{
		r12 = memw(r30+#28)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_98
	}
// %bb.8:                               // %if.end
	{
		r6 = memw(r30+#32)
		if (cmp.eq(r6.new,#0)) jump:nt ##.LBB12_93
	}
// %bb.9:                               // %if.end
	{
		r13 = memw(r30+#36)
		if (cmp.eq(r13.new,#0)) jump:nt ##.LBB12_84
	}
// %bb.10:                              // %if.end
	{
		r20 = memw(r30+#40)
		if (cmp.eq(r20.new,#0)) jump:nt ##.LBB12_83
	}
// %bb.11:                              // %if.end
	{
		r8 = memw(r30+#44)
		if (cmp.eq(r8.new,#0)) jump:nt ##.LBB12_82
	}
// %bb.12:                              // %if.end
	{
		if (p0) r4 = add(r18,#0)
		if (p0) jump:nt .LBB12_864
		if (!p0) r19 = memw(r30+#56)
		if (!p0) r9 = memw(r30+#12)
	}
// %bb.13:                              // %if.end26
	{
		r7 = add(pc,##g_moe_src_bypass@PCREL)
		p0 = cmp.eq(r9,#0)
	}
	{
		r4 = extractu(r19,#1,#18)
		if (p0) jump:nt .LBB12_78
		memw(r7+#0) = r4.new
	}
// %bb.14:                              // %if.end26
	{
		r4 = r18
		if (!p1.new) r11 = add(r9,#0)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB12_864
	}
// %bb.15:                              // %if.end26
	{
		r7 = memw(r30+#8)
		if (cmp.eq(r7.new,#0)) jump:nt ##.LBB12_80
	}
// %bb.16:                              // %if.end26
	{
		r11 |= or(r7,r5)
		r4 = r7
	}
	{
		r11 = and(r11,#31)
	}
	{
		r4 = or(r11,and(r4,#15))
		if (!cmp.eq(r4.new,#0)) jump:nt ##.LBB12_76
	}
// %bb.17:                              // %if.end16.i
	{
		r17 = lsr(r7,#5)
		r11 = lsr(r9,#5)
		memw(r29+#228) = r17
		memd(r29+#1672) = r27:26
	}                                       // 4-byte Folded Spill
	{
		r26 = extractu(r17,#23,#0)
		r22 = r3
		memw(r29+#212) = r22
		memw(r29+#192) = r19
	}                                       // 4-byte Folded Spill
	{
		r23 = extractu(r7,#27,#4)
		r19 = lsr(r5,#5)
		memw(r29+#220) = r20
		memw(r29+#188) = r6
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r26,r11)
		r4 = extractu(r19,#23,#0)
		r6 = #1536
		memw(r29+#224) = r22
	}                                       // 4-byte Folded Spill
	{
		r20 = asl(r3,#9)
		r4 = asl(r4,#9)
		memw(r29+#204) = r20.new
	}                                       // 4-byte Folded Spill
	{
		r26 = mpyi(r4,r23)
		r3 = r20
		memw(r29+#1680) = r26.new
	}                                       // 4-byte Folded Spill
	{
		r3 = insert(r4,#30,#2)
		memw(r29+#216) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r26 += add(r3,r6)
		r3 = extractu(r17,#20,#0)
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r26 = insert(r26,#9,#2)
		memw(r29+#208) = r26.new
	}                                       // 4-byte Folded Spill
	{
		r27 = add(r20,add(r26,##2047))
	}
	{
		r27 += asl(r7,#8)
		r20 = r27
	}
	{
		r20 = insert(r26,#11,#0)
		r27 += asl(r3,#12)
		r6 = r27
		r3 = r9
	}
	{
		r6 = insert(r20,#11,#0)
		r3 = add(##2047,asl(r3,#8))
		r4 = r27
	}
	{
		r4 = insert(r6,#12,#0)
		r26 = minu(r2,r22)
		memw(r29+#232) = r20
	}                                       // 4-byte Folded Spill
	{
		r3 = insert(r4,#11,#0)
		r22 = ##-2147449856
		memw(r29+#200) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r4,r3)
		r4 = add(r22,#-32766)
	}
	{
		r3 = sub(r26,r2)
		p0 = cmp.gtu(r26,r2)
	}
	{
		r2 = lsr(r3,#14)
	}
	{
		if (!p0) r2 = #0
	}
	{
		r2 = minu(r23,r2)
		if (!cmp.gtu(r2.new,#1)) jump:t ##.LBB12_864
	}
// %bb.18:                              // %cleanup.cont.i
	{
		r3 = #32
		memw(r29+#240) = r21
	}                                       // 4-byte Folded Spill
	{
		r2 = minu(r2,r3)
	}
	{
		r22 = and(r2,#62)
	}
	{
		r27 += asl(r22,#14)
		r21 = asl(r22,#13)
	}
	{
		r27 = insert(r21,#11,#0)
		if (!cmp.gtu(r26,r27.new)) jump:t ##.LBB12_864
	}
// %bb.19:                              // %cond.end95.i
	{
		r2 = sub(r26,r27)
		r20 = r0
		memw(r29+#280) = r2
		memw(r29+#268) = r1
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(r21,r2)
		r23 = r5
		memw(r29+#296) = r23
		memw(r29+#292) = r19
	}                                       // 4-byte Folded Spill
	{
		r19 = #1536
		r17 = r4
		memw(r29+#284) = r17
		memw(r29+#320) = r6
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#256) = r25
		memw(r29+#276) = r11
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#288) = r13
		memw(r29+#272) = r12
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#264) = r9
		memw(r29+#300) = r8
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#252) = r7
		memw(r29+#316) = r10
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#312) = r28
		memw(r29+#308) = r15
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#304) = r14
		memw(r29+#260) = r27
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#244) = r20
		memw(r29+#248) = r23
	}                                       // 4-byte Folded Spill
	.falign
// %bb.20:                              // %cond.end95.i
	{
		p3 = cmp.gtu(r0,#3)
		r11 = #4
		r2 = r23
		r1 = r20
	}
	{
		if (!p3) r11 = add(r0,#0)
		if (!p3) r4 = add(r17,#0)
		if (p3) jump:nt .LBB12_22
	}
// %bb.21:
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_864
	}
	.falign
.LBB12_22:                              // %for.body.lr.ph
	{
		r7 = #0
		r25 = #8192
		r3 = memw(r29+#192)
		r14 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r10 = extractu(r3,#1,#19)
		r20 = asl(r14,#1)
		r4 = memw(r29+#260)
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r6 = maxu(r20,r14)
		r4 += mpyi(r11,r21)
		r5 = or(r20,r0)
		memw(r29+#324) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r6 = maxu(r6,r0)
		r17 = #0
		r28 = memw(r30+#48)
		memw(r29+#196) = r7
	}
	{
		r27 = #0
		r5 = and(r5,#127)
		r3 = memw(r29+#256)
		r4 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r15 = #0
		r21 = #0
		r23 = #0
		r7 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB12_23,r16)
		p2 = cmp.gtu(r6,r25)
	}
	.falign
.LBB12_23:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
		r8 = r17
		r6 = memw(r7+#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB12_39
	}
// %bb.24:                              // %if.end46
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r9 = memw(r3+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt ##.LBB12_85
	}
// %bb.25:                              // %lor.lhs.false58
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r13 = #4095
	}
	{
		r13 = memw(r4+#0)
		if (cmp.gtu(r13.new,r13)) jump:nt ##.LBB12_86
	}
// %bb.26:                              // %if.end63
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r1+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_87
	}
// %bb.27:                              // %lor.lhs.false70
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r12 = +mpyi(r13,#96)
	}
	{
		r12 = memw(r1+r12<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_88
	}
// %bb.28:                              // %lor.lhs.false73
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r9 = add(r1,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r2)) jump:nt ##.LBB12_89
	}
// %bb.29:                              // %lor.lhs.false77
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r12 = memw(r9+#32)
		if (!cmp.eq(r12.new,r20)) jump:nt ##.LBB12_90
	}
// %bb.30:                              // %lor.lhs.false80
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r12 = r1
	}
	{
		r12 += mpyi(r13,#96)
	}
	{
		r13 = memw(r12+#28)
		if (!cmp.eq(r13.new,r14)) jump:nt ##.LBB12_91
	}
// %bb.31:                              // %lor.lhs.false84
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r13 = memw(r12+#32)
		if (!cmp.eq(r13.new,r0)) jump:nt ##.LBB12_92
	}
// %bb.32:                              // %if.end89
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r13 = memw(r9+#44)
	}
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_40
		r13 = memw(r12+#44)
	}
// %bb.33:                              // %lor.lhs.false97
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) r4 = add(r18,#0)
		if (p3.new) jump:nt .LBB12_864
	}
// %bb.34:                              // %lor.lhs.false100
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p3 = cmp.eq(r5,#0)
		r13 = memw(r9+#84)
		if (!cmp.eq(r13.new,#2)) jump:nt ##.LBB12_95
	}
// %bb.35:                              // %lor.lhs.false103
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p0 = cmp.gtu(r2,r25)
		r13 = memw(r12+#84)
	}
	{
		p1 = cmp.eq(r13,#2)
	}
	{
		p1 = not(p1)
	}
	{
		p3 = or(p1,!p3)
	}
	{
		p1 = or(p2,or(p0,p3))
		if (p1.new) r4 = add(r18,#0)
		if (p1.new) jump:nt .LBB12_864
	}
// %bb.36:                              // %if.end132
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p3 = and(p3,!p3)
		r13 = memw(r9+#48)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_38
	}
// %bb.37:                              // %land.rhs
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r13 = memw(r12+#48)
	}
	{
		p3 = cmp.eq(r13,#0)
	}
	{
		p3 = not(p3)
	}
	.falign
.LBB12_38:                              // %land.end
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r15 = add(r15,#1)
		if (p3) r23 = add(r23,#1)
		jump .LBB12_41
	}
	.falign
.LBB12_39:                              //   in Loop: Header=BB12_23 Depth=1
	{
		r17 = r8
		jump .LBB12_44
	}
	.falign
.LBB12_40:                              // %lor.lhs.false91
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (!p3.new) r4 = add(r18,#0)
		if (!p3.new) jump:nt .LBB12_864
	}
	.falign
.LBB12_41:                              // %if.end137
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		p3 = or(p3,!p3)
		r9 = memw(r9+#20)
		if (!cmp.eq(r9.new,#0)) jump:t .LBB12_43
	}
// %bb.42:                              // %lor.rhs
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r9 = memw(r12+#20)
	}
	{
		p0 = cmp.eq(r9,#0)
	}
	{
		p3 = not(p0)
	}
	.falign
.LBB12_43:                              // %cleanup
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r27 = add(r27,#1)
		if (p3) r21 = add(r21,#1)
		r17 = add(r6,r8)
		r9 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r9 = maxu(r6,r9)
		memw(r29+#196) = r9.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_44:                              // %for.inc
                                        //   in Loop: Header=BB12_23 Depth=1
	{
		r4 = add(r4,#4)
		r7 = add(r7,#4)
		r3 = add(r3,#4)
	} :endloop0
// %bb.45:                              // %for.cond150.preheader
	{
		r3 = add(r8,r6)
		p1 = cmp.eq(r17,#0); if (p1.new) jump:nt .LBB12_49
	}
// %bb.46:                              // %for.body154.preheader
	{
		r4 = memw(r29+#272)
		r7:6 = memd(r29+#1672)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_47:                              // %for.body154
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r4+#0)
		if (!cmp.gtu(r6,r5.new)) jump:nt ##.LBB12_97
	}
// %bb.48:                              // %for.cond150
                                        //   in Loop: Header=BB12_47 Depth=1
	{
		r4 = add(r4,#4)
		r3 = add(r3,#-1)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_47
	}
	.falign
.LBB12_49:                              // %for.end164
	{
		r3 = #2048
		p2 = cmp.eq(r15,#0)
		memw(r29+#380) = r23
		memw(r29+#348) = r20
	}                                       // 4-byte Folded Spill
	{
		r4 = p2
		p3 = cmp.eq(r0,r3)
		p2 = cmp.eq(r2,r3)
		memw(r29+#356) = r10
	}                                       // 4-byte Folded Spill
	{
		r2 = p3
		memw(r29+#336) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#368) = r28
		memw(r29+#352) = r15
	}                                       // 4-byte Folded Spill
	{
		if (!p2) jump:nt .LBB12_58
		memw(r29+#328) = r4
		memw(r29+#344) = r2
	}                                       // 4-byte Folded Spill
// %bb.50:                              // %for.end164
	{
		r2 = memw(r29+#252)
		if (!cmp.eq(r2.new,r19)) jump:nt .LBB12_58
	}                                       // 4-byte Folded Reload
// %bb.51:                              // %for.end164
	{
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB12_58
		if (p1.new) r2 = memw(r29+##328)
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %for.end164
	{
		p3 = r2
		if (!p3.new) r18 = add(r16,#0)
		if (p3.new) jump:nt .LBB12_58
		if (!p3.new) r25 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.53:
	{
		r19 = memw(r29+#256)
		r23 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_54:                              // %for.body181
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = r11
		r0 = r1
		r2 = memw(r23+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_57
	}
// %bb.55:                              // %if.end186
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r2 = memw(r19+#0)
		r3 = memw(r25+#0)
	}
	{
		r0 += mpyi(r2,#96)
		r1 += mpyi(r3,#96)
	}
	{
		call hexkl_weight_tl2_refresh_pair
	}
	.falign
// %bb.56:                              // %if.end186
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r11 = r20
		r4 = r0
		p2 = cmp.eq(r0,#0)
		r1 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		if (!p2) jump:nt .LBB12_864
	}
	.falign
.LBB12_57:                              // %for.inc198
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r25 = add(r25,#4)
		r23 = add(r23,#4)
		r19 = add(r19,#4)
	}
	{
		r18 = add(r18,#-1)
		if (!cmp.eq(r18.new,#0)) jump:t .LBB12_54
	}
	.falign
.LBB12_58:                              // %if.end203
	{
		r18 = r1
		r0 = r1
		r25 = memw(r29+#188)
		r19 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r1 = r16
		r4 = r25
		r23 = memw(r29+#240)
		memw(r29+#360) = r11
	}                                       // 4-byte Folded Reload
	{
		call moe_all_4bit
		r3:2 = combine(r23,r19)
	}
	.falign
// %bb.59:                              // %if.end203
	{
		r1:0 = combine(r16,r18)
		r3:2 = combine(r23,r19)
		r4 = r25
		memw(r29+#372) = r0
	}                                       // 4-byte Folded Spill
	{
		call moe_all_2bit
	}
	.falign
// %bb.60:                              // %if.end203
	{
		r18 = r0
		r3:2 = combine(#0,#0)
		r0 = memw(r29+#268)
		r1 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		memd(r29+#1808) = r3:2
		memd(r29+#1800) = r3:2
	}
	{
		memd(r29+#1792) = r3:2
		memd(r29+#1784) = r3:2
	}
	{
		memd(r29+#1776) = r3:2
		memd(r29+#1768) = r3:2
	}
	{
		call hexkl_acc_layout_get
		memd(r29+#1760) = r3:2
		memd(r29+#1752) = r3:2
	}
	.falign
// %bb.61:                              // %if.end203
	{
		r2 = memw(r0+#4)
	}
	{
		p1 = cmp.eq(r2,#0)
		r2 = ##-2147449856
	}
	{
		r4 = add(r2,#-32748)
		if (p1) jump:nt .LBB12_864
	}
// %bb.62:                              // %if.end215
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r29+#340) = r4
	}                                       // 4-byte Folded Spill
	{
		p0 = and(p0,!p0)
		r20 = r0
		r4 = memw(r0+#12)
		memw(r29+#376) = r2
	}                                       // 4-byte Folded Spill
	{
		r5 = #0
		r1:0 = memd(r29+#1672)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}                                       // 8-byte Folded Reload
	{
		r3 = p0
		p1 = cmp.gtu(r0,#4)
		r1 = #0
		p0 = cmp.eq(r0,#1)
	}
	{
		r3 = p0
		memw(r29+#332) = r3
		memd(r29+#1688) = r1:0
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB12_164
		memw(r29+#364) = r3
		memd(r2+#136) = r5:4
	}                                       // 4-byte Folded Spill
// %bb.63:                              // %if.end215
	{
		r2 = memw(r29+#192)
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,#1)
		r3 = memw(r29+#244)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_165
	}                                       // 4-byte Folded Reload
// %bb.64:                              // %if.end215
	{
		r2 = memw(r29+#196)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#4)
		if (p2.new) jump:nt .LBB12_68
	}
// %bb.65:                              // %if.end215
	{
		r2 = add(r27,#-1)
		if (cmp.gtu(r2.new,#15)) jump:nt .LBB12_68
	}
// %bb.66:                              // %if.end215
	{
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r2 = or(r2,r18)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_68
	}
// %bb.67:                              // %land.rhs239
	{
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
	}
	{
		p2 = or(p0,p2)
	}
	{
		r2 = p2
		memw(r29+#332) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_68:                              // %land.end246
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r19 = #0
		if (p0.new) jump:nt .LBB12_104
	}
// %bb.69:                              // %land.end246
	{
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r19 = #0
		if (p0.new) jump:nt .LBB12_104
	}
// %bb.70:                              // %if.then251
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.71:                              // %if.then251
	{
		r23 = r0
		r25 = memw(r29+#252)
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		call hvx_tl2_weight_bytes
		r0 = r25
	}
	.falign
// %bb.72:                              // %if.then251
	{
		r4 = add(r0,r23)
		r5 = memw(r29+#324)
		r2 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r26,r5)
		r19 = add(r2,r5)
	}
	{
		p0 = cmp.gtu(r4,r3); if (!p0.new) jump:t .LBB12_103
		if (!p0.new) r3 = memw(r29+#244)
		if (p0.new) r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.73:                              // %if.else
	{
		p2 = cmp.gtu(r23,r3)
		r2 = memw(r29+#356)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = #1536
		if (p2) r19 = #0
	}
	{
		p1 = cmp.eq(r25,r2)
		if (!p3) r19 = #0
		r2 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r19 = #0
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p1) r19 = #0
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r19 = #0
		jump .LBB12_104
	}
	.falign
.LBB12_74:
	{
		p2 = cmp.eq(r16,#0)
		r4 = ##-2147449856
		r22 = #0
	}
	{
		r18 = add(r4,#-32754)
		if (!p2) jump:nt .LBB12_2
	}
	.falign
.LBB12_75:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_76:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_78:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_80:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_82:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_83:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_84:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_85:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_86:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_87:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_88:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_89:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_90:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_91:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_92:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_93:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_95:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_97:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_98:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_100:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_103:                             // %if.then258
	{
		r23 += add(r2,r5)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		r1 = r23
	}
	{
		r0 = memw(r29+#248)
		memd(r29+#1688) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_104:                             // %if.end282
	{
		p2 = cmp.eq(r21,#0)
		r5 = #0
		r6 = #8192
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = p2
		memw(r29+#372) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = or(p1,!p2)
		if (p0.new) r25 = add(r18,#0)
		if (p0.new) jump:nt .LBB12_157
		if (!p0.new) r7 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.105:                             // %if.end282
	{
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) r25 = add(r18,#0)
		if (p1.new) r18 = #0
		if (p1.new) jump:nt .LBB12_204
	}
// %bb.106:                             // %if.end282
	{
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,r27)
		if (p2.new) r8 = #0
		if (!p2.new) jump:nt .LBB12_155
		if (p2.new) r9 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
// %bb.107:
	{
		loop0(.LBB12_108,r16)
		r5:4 = combine(#1,#0)
		r6 = memw(r29+#256)
		r21 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_108:                             // Block address taken
                                        // %for.body297
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r9+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_154
	}
// %bb.109:                             // %if.end301
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = r3
		r12 = memw(r6+#0)
	}
	{
		r2 += mpyi(r12,#96)
	}
	{
		r12 = memb(r2+#88)
	}
	{
		r13 = abs(r12)
		r12 = #0
	}
	{
		p1 = cmp.eq(r13,#0)
		if (p1.new) jump:nt .LBB12_112
	}
// %bb.110:                             // %if.end301
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_112
	}
// %bb.111:                             // %if.end301
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r13,#1)
		if (!p2.new) jump:t .LBB12_131
	}
	.falign
.LBB12_112:                             // %for.inc.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_117
	}
// %bb.113:                             // %for.inc.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r14,#7)
		if (p0.new) jump:nt .LBB12_115
	}
// %bb.114:                             // %for.inc.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r14,#1)
		if (!p2.new) jump:t .LBB12_131
	}
	.falign
.LBB12_115:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		if (p1) jump:nt .LBB12_118
	}
// %bb.116:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r13,r14)
		if (!p1.new) jump:t .LBB12_131
	}
	{
		jump .LBB12_118
	}
	.falign
.LBB12_117:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_118:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_123
	}
// %bb.119:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_121
	}
// %bb.120:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r13,#1)
		if (!p2.new) jump:t .LBB12_131
	}
	.falign
.LBB12_121:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r14,#0)
		if (p1.new) jump:nt .LBB12_124
	}
// %bb.122:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r14,r13)
		if (!p3.new) jump:t .LBB12_131
	}
	{
		jump .LBB12_124
	}
	.falign
.LBB12_123:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_124:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_129
	}
// %bb.125:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r2,#7)
		if (p2.new) jump:nt .LBB12_127
	}
// %bb.126:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB12_131
	}
	.falign
.LBB12_127:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_130
	}
// %bb.128:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r13,r2)
		if (!p0.new) jump:t .LBB12_131
	}
	{
		jump .LBB12_130
	}
	.falign
.LBB12_129:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = r13
	}
	.falign
.LBB12_130:                             // %for.inc.3.i
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r12 = maxu(r2,r5)
	}
	.falign
.LBB12_131:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = r3
		r23 = #8
		r13 = memw(r7+#0)
	}
	{
		r2 += mpyi(r13,#96)
	}
	{
		r13 = memb(r2+#88)
	}
	{
		r13 = abs(r13)
	}
	{
		p2 = cmp.eq(r13,#0)
		if (p2.new) jump:nt .LBB12_134
	}
// %bb.132:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r13,#7)
		if (p1.new) jump:nt .LBB12_134
	}
// %bb.133:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r13,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_170
	}
	.falign
.LBB12_134:                             // %for.inc.i5275
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_139
	}
// %bb.135:                             // %for.inc.i5275
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r14,#7)
		if (p1.new) jump:nt .LBB12_137
	}
// %bb.136:                             // %for.inc.i5275
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r14,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_170
	}
	.falign
.LBB12_137:                             // %lor.lhs.false.1.i5278
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		if (p2) jump:nt .LBB12_140
	}
// %bb.138:                             // %lor.lhs.false.1.i5278
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r13,r14)
		if (p2.new) jump:t .LBB12_140
	}
	{
		jump .LBB12_161
	}
	.falign
.LBB12_139:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_140:                             // %for.inc.1.i5283
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_145
	}
// %bb.141:                             // %for.inc.1.i5283
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r13,#7)
		if (p1.new) jump:nt .LBB12_143
	}
// %bb.142:                             // %for.inc.1.i5283
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r13,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_170
	}
	.falign
.LBB12_143:                             // %lor.lhs.false.2.i5286
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r14,#0)
		if (p2.new) jump:nt .LBB12_146
	}
// %bb.144:                             // %lor.lhs.false.2.i5286
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r14,r13)
		if (p0.new) jump:t .LBB12_146
	}
	{
		jump .LBB12_162
	}
	.falign
.LBB12_145:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_146:                             // %for.inc.2.i5291
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r14 = abs(r2)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_151
	}
// %bb.147:                             // %for.inc.2.i5291
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p3 = cmp.eq(r14,#7)
		if (p3.new) jump:nt .LBB12_149
	}
// %bb.148:                             // %for.inc.2.i5291
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p2 = cmp.eq(r14,#1)
		if (!p2.new) r2 = #8
		if (!p2.new) jump:nt .LBB12_170
	}
	.falign
.LBB12_149:                             // %lor.lhs.false.3.i5294
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p0 = cmp.eq(r13,#0)
		if (p0.new) jump:nt .LBB12_152
	}
// %bb.150:                             // %lor.lhs.false.3.i5294
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		p1 = cmp.eq(r13,r14)
		if (p1.new) jump:t .LBB12_152
	}
	{
		jump .LBB12_163
	}
	.falign
.LBB12_151:                             //   in Loop: Header=BB12_108 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_152:                             // %htp_tl2_palette_magnitude.exit5303
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r4 = max(r12,r4)
		p3 = cmp.eq(r12,#0)
		r2 = #8
		if (p3.new) jump:nt .LBB12_170
	}
// %bb.153:                             // %if.end317
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r2 = maxu(r14,r5)
	}
	{
		r8 = max(r2,r8)
	}
	.falign
.LBB12_154:                             // %for.inc330
                                        //   in Loop: Header=BB12_108 Depth=1
	{
		r9 = add(r9,#4)
		r23 = r8
		r7 = add(r7,#4)
		r6 = add(r6,#4)
	}
	{
		r2 = r4
		nop
	} :endloop0
	{
		jump .LBB12_170
	}
	.falign
.LBB12_155:
	{
		r18 = #0 ; jump .LBB12_204
		r25 = r18
	}
	.falign
.LBB12_156:
	{
		r4 = r18 ; jump .LBB12_864
	}
	.falign
.LBB12_157:
	{
		r18 = #0 ; jump .LBB12_204
	}
	.falign
.LBB12_161:
	{
		r2 = #8 ; jump .LBB12_170
	}
	.falign
.LBB12_162:
	{
		r2 = #8 ; jump .LBB12_170
	}
	.falign
.LBB12_163:
	{
		r2 = #8 ; jump .LBB12_170
	}
	.falign
.LBB12_164:
	{
		r3 = memw(r29+#244)
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_68
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_165:
	{
		jump .LBB12_68
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_170:                             // %cleanup332
	{
		call hexkl_acc_i24_usable
		r1 = sub(#0,r2)
		r3 = r20
		r25 = r18
	}
	.falign
// %bb.171:                             // %cleanup332
	{
		r1 = sub(#0,r23)
		r0 = r21
		r3:2 = combine(r20,r23)
		memw(r29+#1696) = r0
	}                                       // 4-byte Folded Spill
	{
		call hexkl_acc_i24_usable
	}
	.falign
// %bb.172:                             // %cleanup332
	{
		r18 = #8192
		r2 = memw(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		p1 = cmp.eq(r0,#0)
		r0 = memw(r29+#336)
		memw(r29+#1696) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r1 = p1
		if (!p3.new) jump:nt .LBB12_187
		memw(r29+#384) = r1.new
	}                                       // 4-byte Folded Spill
// %bb.173:                             // %cleanup332
	{
		r4 = memw(r29+#260)
		r5 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		r2 = #1536
		if (!cmp.eq(r2.new,r21)) jump:nt .LBB12_188
	}
// %bb.174:                             // %cleanup332
	{
		r0 = memw(r29+#248)
		r2 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB12_189
	}
// %bb.175:                             // %cleanup332
	{
		p0 = cmp.eq(r22,#32)
		if (!p0.new) jump:nt .LBB12_189
	}
// %bb.176:                             // %cleanup332
	{
		r2 = memw(r29+#356)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_189
	}                                       // 4-byte Folded Reload
// %bb.177:                             // %cleanup332
	{
		r3:2 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		p3 = cmp.gtu(r2,#1)
		if (!p3.new) jump:nt .LBB12_189
		if (p3.new) r3:2 = memd(r29+##1688)
	}                                       // 8-byte Folded Reload
// %bb.178:                             // %cleanup332
	{
		p2 = cmp.eq(r3,#0)
		if (!p2.new) jump:nt .LBB12_189
		if (p2.new) r2 = memw(r29+##1696)
	}                                       // 4-byte Folded Reload
// %bb.179:                             // %cleanup332
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_189
		if (!p0.new) r2 = memw(r29+##384)
	}                                       // 4-byte Folded Reload
// %bb.180:                             // %cleanup332
	{
		p3 = r2
		if (p3.new) jump:nt .LBB12_189
	}
// %bb.181:                             // %if.then361
	{
		call hvx_tl2_weight_bytes
		r0 = #2048
		r1 = #3072
	}
	.falign
// %bb.182:                             // %if.then361
	{
		call hvx_tl2_weight_bytes
		r23 = r0
		r0 = #1536
		r1 = #2048
	}
	.falign
// %bb.183:                             // %if.then361
	{
		r3 = add(r0,r23)
		r0 = r26
		r4 = add(r29,#8704)
		r5 = add(r29,#3872)
	}
	{
		call hexkl_acc_i24_banks
		r2 = #32
		r1 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.184:                             // %if.then361
	{
		r5 = #2
		r18 = #6144
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_186
	}
// %bb.185:                             // %if.then370
	{
		r3 = memw(r29+#3872)
		r2 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r19 = add(r2,r3)
		r4 = memw(r29+##8704)
		memw(r29+#324) = r3
	}                                       // 4-byte Folded Spill
	{
		r1 = add(r19,r23)
	}
	{
		jump .LBB12_189
		r0 = memw(r29+#248)
		memd(r29+#1688) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_186:
	{
		r1 = #0
		r18 = #8192
		r4 = memw(r29+#260)
		r5 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_189
		r0 = memw(r29+#248)
		memd(r29+#1688) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_187:
	{
		r0 = memw(r29+#248)
		r4 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_189
		r5 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_188:
	{
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_189:                             // %if.end375
	{
		p1 = cmp.eq(r19,#0); if (p1.new) jump:nt .LBB12_192
		memw(r29+#360) = r5
		memw(r29+#260) = r4
	}                                       // 4-byte Folded Spill
// %bb.190:                             // %if.then378
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.191:                             // %if.then378
	{
		r2 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r2)
		memw(r29+#324) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_192:                             // %if.end382
	{
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		p3 = cmp.eq(r1,#0)
		if (p3.new) r6 = add(r18,#0)
		if (p3.new) jump:nt .LBB12_195
		if (p3.new) r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.193:                             // %if.then384
	{
		call hvx_tl2_weight_bytes
		r0 = r21
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.194:                             // %if.then384
	{
		r6 = r18
		r5 = memw(r29+#324)
		r2 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r0,r5)
		jump .LBB12_196
		r0 = memw(r29+#248)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_195:
	{
		r2 = memw(r29+#268)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_196:                             // %if.end387
	{
		r3 = add(r26,#-3072)
		p2 = cmp.gtu(r26,##3071)
		if (!p2.new) jump:nt .LBB12_202
	}
// %bb.197:                             // %if.end387
	{
		r3 = insert(r6,#11,#0)
		if (cmp.gtu(r5,r3.new)) jump:nt .LBB12_201
	}
// %bb.198:                             // %if.then391
	{
		r2 = add(r2,r3)
		r5 = #0
		r3 = memw(r29+#1696)
		r7 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		p0 = r7
		r23 = r20
	}
	{
		r3 = mux(p2,#0,r2)
		r5 = mux(p0,#0,r2)
	}
	{
		r21 = r3
		r3 = or(r3,r5)
		if (cmp.eq(r3.new,#0)) jump:t .LBB12_203
	}
// %bb.199:                             // %if.then403
	{
		call hexkl_acc_i24_prepare
		r0 = r2
		r20 = r5
	}
	.falign
// %bb.200:                             // %if.then403
	{
		r5 = r20
		r6 = r18
		r4 = memw(r29+#340)
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r20 = r23 ; jump .LBB12_204
		r18 = r21
	}
	.falign
.LBB12_201:
	{
		r5 = #0 ; jump .LBB12_204
		r18 = #0
	}
	.falign
.LBB12_202:
	{
		r5 = #0 ; jump .LBB12_204
		r18 = #0
	}
	.falign
.LBB12_203:
	{
		r5 = #0
		r18 = #0
	}
	.falign
.LBB12_204:                             // %if.end406
	{
		r2 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		p3 = and(p2,p3)
		r21 = and(r2,##33554432)
		if (p3.new) jump:nt .LBB12_206
	}
// %bb.205:                             // %if.end406
	{
		p2 = cmp.eq(r21,#0)
		if (!p2.new) jump:t .LBB12_864
	}
	.falign
.LBB12_206:                             // %if.end417
	{
		p3 = and(p3,!p3)
		r3 = memw(r29+#376)
		memw(r29+#392) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r4 = memw(r3+##hexkl_probe_us@GOT)
		r5 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		r5 = lsr(r5,r25)
		r2 = mux(p1,#1,#0)
		r3 = memw(r29+#1680)
		memw(r29+#384) = r5.new
	}                                       // 4-byte Folded Reload
	{
		r5 = p3
		r23 = lsr(r3,r25)
		r3 = #0
		memw(r29+#396) = r25
	}                                       // 4-byte Folded Spill
	{
		r5 = p3
		memw(r29+#204) = r5
	}                                       // 4-byte Folded Spill
	{
		r5 = p3
		memw(r29+#324) = r5
	}                                       // 4-byte Folded Spill
	{
		if (!p1) jump:nt .LBB12_212
		memw(r29+#1680) = r5
		memd(r4+#224) = r3:2
	}                                       // 4-byte Folded Spill
// %bb.207:                             // %land.lhs.true445
	{
		r2 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,##131104)
	}
	{
		p0 = cmp.eq(r2,#32)
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
	}
	{
		p3 = not(p3)
	}
	{
		r2 = p3
		if (!p0) jump:nt .LBB12_209
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.208:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB12_212
		memw(r29+#1680) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_209:                             // %land.lhs.true449
	{
		p3 = and(p3,!p3)
		r3:2 = combine(#0,r23)
		r7 = r27
		r27 = #0
	}
	{
		r5:4 = asl(r3:2,#1)
	}
	{
		p1 = cmp.gtu(r5:4,r27:26)
		if (!p1.new) r27 = add(r7,#0)
		if (!p1.new) jump:t .LBB12_211
	}
// %bb.210:
	{
		r27 = r7
	}
	{
		r2 = p3
		jump .LBB12_212
		memw(r29+#1680) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_211:                             // %land.rhs455
	{
		r4 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(#0,r4)
	}
	{
		r5:4 = asl(r5:4,#1)
	}
	{
		p3 = cmp.gtu(r5:4,r3:2)
	}
	{
		p1 = not(p3)
	}
	{
		r2 = p1
		memw(r29+#1680) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_212:                             // %land.end461
	{
		call hvx_tl2_table_bytes
		memw(r29+#388) = r6
	}                                       // 4-byte Folded Spill
	.falign
// %bb.213:                             // %land.end461
	{
		r25 = memw(r29+#252)
		memd(r29+#1696) = r1:0
	}                                       // 4-byte Folded Reload
	{
		call hvx_tl2_table_bytes
		r0 = r25
	}
	.falign
// %bb.214:                             // %land.end461
	{
		r7 = r0
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:nt .LBB12_222
		if (!p2.new) r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
// %bb.215:                             // %land.end461
	{
		r2 = #1536
		if (!cmp.eq(r2.new,r25)) jump:nt ##.LBB12_249
	}
// %bb.216:                             // %land.end461
	{
		r0 = memw(r29+#248)
		r2 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:nt .LBB12_222
	}
// %bb.217:                             // %land.end461
	{
		p0 = cmp.eq(r16,#64)
		if (!p0.new) jump:nt .LBB12_222
		if (p0.new) r2 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
// %bb.218:                             // %land.end461
	{
		p3 = r2
		if (!p3.new) jump:nt .LBB12_222
	}
// %bb.219:                             // %land.end461
	{
		p1 = cmp.gtu(r27,#4)
		if (p1.new) jump:nt .LBB12_222
	}
// %bb.220:                             // %land.end461
	{
		r2 = memw(r29+#196)
		if (!cmp.eq(r2.new,#1)) jump:nt .LBB12_222
	}                                       // 4-byte Folded Reload
// %bb.221:                             // %land.lhs.true490
	{
		r2 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,r27)
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p0 = and(p0,and(p2,p1))
	}
	{
		r2 = p0
		memw(r29+#324) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_222:                             // %land.end498
	{
		r4 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p0 = r4
		if (!p0.new) r25 = add(r7,#0)
		if (!p0.new) r2 = #0
		if (!p0.new) jump:t .LBB12_228
	}
// %bb.223:                             // %land.lhs.true501
	{
		r3 = #8192
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,r3)
		r2 = ##-2147449856
	}
	{
		r4 = add(r2,#-32754)
		if (p1) jump:nt .LBB12_864
	}
// %bb.224:                             // %land.lhs.true501
	{
		p3 = cmp.gtu(r0,r3)
		if (p3.new) jump:nt .LBB12_864
		if (!p3.new) r5 = memw(r29+##364)
	}                                       // 4-byte Folded Reload
// %bb.225:                             // %land.lhs.true501
	{
		r3 = #0
		memw(r29+#196) = r23
	}                                       // 4-byte Folded Spill
	{
		p3 = r5
		r5 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p1 = r5
	}
	{
		p2 = and(p3,p1)
		if (!p2.new) jump:nt .LBB12_864
		if (p2.new) r23 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
// %bb.226:                             // %lor.lhs.false512
	{
		r2 = asl(r23,#1)
		memw(r29+#340) = r4
		memw(r29+#372) = r27
	}                                       // 4-byte Folded Spill
	{
		r5:4 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r5 = #0
		r6 = r4
	}
	{
		r2 = mpyi(r7,r27)
		r5:4 = add(r5:4,r3:2)
		r27 = #0
		memd(r29+#1696) = r7:6
	}                                       // 8-byte Folded Spill
	{
		r5:4 = add(r5:4,r3:2)
	}
	{
		p0 = cmp.gtu(r5:4,r27:26)
		if (!p0.new) r25 = add(r7,#0)
		if (!p0.new) jump:t .LBB12_237
	}
// %bb.227:
	{
		jump .LBB12_864
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_228:                             // %if.end533
	{
		r3 = memw(r29+#1680)
		memw(r29+#400) = r19
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		r19 = r22
		r2 = #1
		memw(r29+#768) = r2
	}
	{
		if (!p2) jump:nt .LBB12_230
		memw(r29+#372) = r27
		memw(r29+#196) = r23
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_229:                             // %cond.true535
	{
		r2 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r2,#2,#22)
	}
	{
		r2 = add(r2,#1)
	}
	.falign
.LBB12_230:                             // %cond.end538
	{
		r2 = #1
		r3 = memw(r29+#280)
		memw(r29+#772) = r2
	}                                       // 4-byte Folded Reload
	{
		r23 = lsr(r3,#1)
		r2 = #0
		r3 = memw(r29+#348)
		memw(r29+#776) = r2
	}                                       // 4-byte Folded Reload
	{
		r22 = lsr(r3,#6)
		r1 = r23
		memw(r29+#780) = r2
	}
	{
		r0 = add(r22,add(r23,#-1))
		call __hexagon_udivsi3
	}
	.falign
// %bb.231:                             // %cond.end538
	{
		r2 = ##-2147449856
		p2 = cmp.gtu(r0,#16)
		r27:26 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		r1 = r19
		r4 = add(r2,#-32748)
		if (p2) jump:nt .LBB12_864
	}
// %bb.232:                             // %lor.lhs.false547
	{
		r2 = memw(r29+#276)
		memw(r29+#432) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,add(r19,#-1))
		r19 = r4
		memw(r29+#280) = r19
		memw(r29+#436) = r21
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#424) = r18
	}                                       // 4-byte Folded Spill
	.falign
// %bb.233:                             // %lor.lhs.false547
	{
		r4 = r19
		p0 = cmp.gtu(r0,#16); if (p0.new) jump:t .LBB12_864
		memw(r29+#444) = r0
	}                                       // 4-byte Folded Spill
// %bb.234:                             // %if.end556
	{
		r17 += mpyi(r16,#63)
		r3 = add(r26,#63)
		r4 = memw(r24+#12)
		r2 = memw(r24+#64)
	}
	{
		p3 = cmp.eq(r4,#0)
		p1 = cmp.eq(r2,#0)
		r27 = and(r3,#-64)
		memw(r29+#500) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = p3
		p2 = not(p3)
		r1:0 = combine(r27,r26)
		memw(r29+#508) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r1:0 = vaslw(r1:0,#2)
		p1 = not(p1)
		r2 = memw(r29+#332)
		memd(r29+#1672) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = p2
		r4 = memw(r29+#248)
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r27:26 = vaslw(r17:16,#2)
		p2 = and(p2,!p3)
		r2 = memw(r29+#264)
		memw(r29+#532) = r3
	}                                       // 4-byte Folded Reload
	{
		r19 = mpyi(r17,r4)
		p0 = and(p1,!p3)
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = mpyi(r0,r2)
		r21 = mpyi(r0,r4)
		memw(r29+#512) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p0
		r2 = p2
		r18 = add(r2,#127)
		memw(r29+#412) = r3.new
	}                                       // 4-byte Folded Spill
	{
		if (!p2) r3 = add(r21,#127)
		if (!p2) r2 = #0
		if (!p2) jump:nt .LBB12_241
		memw(r29+#468) = r2
	}                                       // 4-byte Folded Spill
// %bb.235:                             // %cond.true609
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.236:                             // %cond.true609
	{
		r0 = add(#4,asl(r0,#2))
		r3 = #127
		r4 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r0,r4)
		jump .LBB12_241
	}
	.falign
.LBB12_237:                             // %lor.lhs.false523
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.238:                             // %lor.lhs.false523
	{
		p1 = cmp.gtu(r0,r23); if (!p1.new) jump:t .LBB12_244
		if (!p1.new) r0 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
// %bb.239:
	{
		jump .LBB12_864
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_241:                             // %cond.end615
	{
		r9 = add(r19,#127)
		r28 = add(r27,#127)
		r7 = memw(r29+#252)
		r1:0 = memd(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(#127,asl(r7,#4))
		r15 = and(r9,#-128)
		r13 = memw(r29+#284)
		r8 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r11 = extractu(r13,#21,#0)
		r13 = extractu(r13,#22,#0)
		r14 = memw(r29+#276)
		r12 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r22,add(r14,#1))
		r10 = asl(r13,#10)
		memw(r29+#528) = r10.new
	}                                       // 4-byte Folded Spill
	{
		r14 = extractu(r14,#23,#0)
		r8 = add(#127,asl(r8,#4))
		r2 = add(r2,#127)
		memw(r29+#1744) = r28
	}                                       // 4-byte Folded Spill
	{
		r9 = asl(r14,#9)
		p2 = r12
		r13 = and(r8,#-128)
		memw(r29+#420) = r15
	}                                       // 4-byte Folded Spill
	{
		r12 = asl(r11,#11)
		r8 = r10
		r10 = and(r7,#-128)
		r7 = r13
	}
	{
		r8 += add(r9,r12)
		r14 = add(r26,#127)
		r11 = and(r28,#-128)
		memw(r29+#448) = r9
	}                                       // 4-byte Folded Spill
	{
		r6 = add(##127,mpyi(r6,r16))
		r7 += add(r8,r10)
		r9:8 = combine(r16,#96)
	}
	{
		r9 = add(#127,asl(r9,#6))
		r5 = lsr(r17,#4)
		r28 = and(r6,#-128)
		memw(r29+#440) = r13
	}                                       // 4-byte Folded Spill
	{
		r8 = add(##159,mpyi(r16,r8))
		r13 = and(r14,#-128)
		r9 = and(r9,#-128)
	}
	{
		r6 = addasl(r12,r1,#3)
		r14 = and(r8,#-128)
		memw(r29+#524) = r10
		memw(r29+#504) = r14
	}                                       // 4-byte Folded Spill
	{
		r4 = add(##383,mpyi(r4,r0))
		r10 = r9
		memw(r29+#484) = r9
	}                                       // 4-byte Folded Spill
	{
		r5 = add(##256,asl(r5,#1))
		r17 = asl(r0,#4)
		r19 = r5
	}
	{
		r10 += add(r6,r14)
		r12 = and(r4,#-128)
		r6 = add(r11,r13)
		memw(r29+#452) = r12
	}                                       // 4-byte Folded Spill
	{
		r6 = +mpyi(r6,#3)
		r4 = r28
		if (p2) r17 = #0
		r9 = mux(p2,#0,r12)
	}
	{
		r4 += add(r10,r13)
		r5 = and(r5,##1073741568)
		memw(r29+#492) = r28
	}                                       // 4-byte Folded Spill
	{
		r5 += add(r4,r15)
		r14 = add(r17,#127)
		memw(r29+#488) = r14
		memw(r29+#464) = r11
	}                                       // 4-byte Folded Spill
	{
		r4 = r9
		r9 = #8192
		memw(r29+#472) = r9
		memw(r29+#1736) = r13
	}                                       // 4-byte Folded Spill
	{
		r9 += asl(r7,#4)
		r4 += add(r5,r6)
		r7 = and(r14,#-128)
		r6 = and(r3,#-128)
	}
	{
		r3 = r7
		if (!p2) r9 = #0
		r7 = memw(r29+#412)
		memw(r29+#496) = r7
	}                                       // 4-byte Folded Reload
	{
		r3 += add(r4,r9)
		p2 = r7
		r5 = and(r18,#-128)
		r18 = r6
	}
	{
		if (p2) r5 = #0
		r6 = and(r2,#-128)
		r2 = #1536
		memw(r29+#1728) = r6
	}                                       // 4-byte Folded Spill
	{
		r18 += add(r3,r5)
		p2 = and(p2,!p2)
		r3 = memw(r29+#212)
		memw(r29+#456) = r5
	}                                       // 4-byte Folded Reload
	{
		r18 += add(r6,r2)
		r2 = p2
		p3 = cmp.eq(r3,#0)
		memw(r29+#460) = r6
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#1720) = r2
		memw(r29+#520) = r20
	}                                       // 4-byte Folded Spill
	{
		if (p3) r22 = add(r21,#0)
		memw(r29+#416) = r22
		memw(r29+#536) = r12
	}                                       // 4-byte Folded Spill
	{
		if (p3) jump:nt .LBB12_254
		if (p3) r17 = memw(r29+##376)
		memw(r29+#516) = r17
	}                                       // 4-byte Folded Reload
// %bb.242:                             // %land.lhs.true760
	{
		r1 = #1536
		r22 = r21
		r2 = memw(r24+#4)
		if (cmp.eq(r2.new,r3)) jump:nt .LBB12_250
	}
// %bb.243:
	{
		jump .LBB12_254
		r17 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_244:                             // %lor.lhs.false528
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.245:                             // %lor.lhs.false528
	{
		r2 = memw(r29+#384)
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r0,r2)
		if (!p3.new) r2 = #0
		if (p3.new) jump:t .LBB12_864
	}
// %bb.246:                             // %if.end533.thread
	{
		r19 = r22
		memw(r29+#400) = r19
		memw(r29+#768) = r2
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_229
	}
	.falign
.LBB12_249:
	{
		jump .LBB12_222
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_250:                             // %land.lhs.true763
	{
		r2 = memw(r29+#356)
		r3 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		p3 = cmp.eq(r3,r1)
		r2 = add(r0,#-128)
		r1 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p0)
		p0 = not(p3)
		r0 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p3 = r1
		p1 = r0
		r0 = memw(r29+#332)
		r1 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		p3 = or(p2,!p3)
		p1 = not(p1)
		p2 = cmp.gtu(r2,##3968)
	}
	{
		p0 = or(p0,or(p3,p2))
		p3 = r0
		r0 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p1 = or(p3,or(p1,p0))
		p0 = r1
	}
	{
		p3 = r0
	}
	{
		p3 = or(p0,or(p1,p3))
		if (p3.new) jump:nt .LBB12_254
		if (p3.new) r17 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.251:                             // %land.lhs.true763
	{
		r2 = memw(r29+#372)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_659
	}                                       // 4-byte Folded Reload
// %bb.252:                             // %land.lhs.true763
	{
		r3 = memw(r29+#380)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r3,r2); if (!p0.new) jump:nt .LBB12_254
		if (p0.new) r2 = memw(r24+#8)
		r17 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
// %bb.253:                             // %land.rhs786
	{
		p1 = cmp.gtu(r18,r2)
	}
	{
		p0 = not(p1)
	}
	{
		r0 = p0
		memw(r29+#1720) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_254:                             // %land.end789
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_257
	}
// %bb.255:                             // %if.then792
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.256:                             // %if.then792
	{
		r27:26 = combine(r1,r0)
		jump .LBB12_258
	}
	.falign
.LBB12_257:
	{
		r27:26 = combine(#0,#0)
	}
	.falign
.LBB12_258:                             // %do.end
	{
		call hexkl_moe_scratch_reserve
		r1:0 = combine(r18,r24)
	}
	.falign
// %bb.259:                             // %do.end
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
		memw(r29+#340) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_262
	}
// %bb.260:                             // %if.then798
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.261:                             // %if.then798
	{
		r1:0 = sub(r1:0,r27:26)
		r2 = memw(r17+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#72)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#72) = r1:0
	}
	.falign
.LBB12_262:                             // %do.end804
	{
		r18 = #0
		r4 = memw(r29+#340)
		if (!cmp.eq(r4.new,#0)) jump:t ##.LBB12_864
	}                                       // 4-byte Folded Reload
// %bb.263:                             // %for.body875.preheader
	{
		r21 = #0
		r1 = memw(r29+#1720)
		memw(r29+#476) = r25
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		r23 = #0
		r3 = memw(r29+#1728)
		memw(r29+#544) = r23
	}                                       // 4-byte Folded Reload
	{
		r6 = mux(p1,r3,#0)
		r9 = mux(p1,#0,r3)
		r2 = memw(r29+#204)
		r4 = memw(r24+#4)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r8 = add(r4,r6)
		r2 = mux(p1,#1,#0)
		r7 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r5 = mux(p2,#1,#0)
		r0 = memw(r29+#412)
		memw(r24+#60) = r2
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r0 = add(r8,#1024)
		r2 = memw(r29+#300)
		r1 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r5 = add(r2,#0)
		r2 = add(r0,r1)
		memw(r29+#600) = r5
		memw(r29+#428) = r0
	}                                       // 4-byte Folded Spill
	{
		r0 = memw(r29+#464)
		memw(r29+#540) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r0)
		r14 = memw(r29+#1736)
		memw(r29+#408) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r0)
		r17 = #0
		memw(r29+#568) = r6
	}                                       // 4-byte Folded Spill
	{
		r25 = add(r2,r0)
		r1:0 = memd(r29+#1704)
		memw(r29+#404) = r2
	}                                       // 8-byte Folded Reload
	{
		r12 = add(r25,r14)
		memw(r29+#572) = r9
		memw(r29+#556) = r4
	}                                       // 4-byte Folded Spill
	{
		r6 = add(r12,r14)
		r20 = memw(r29+#188)
		memw(r29+#592) = r8
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r6,r14)
		memw(r29+#1704) = r6
		memw(r29+#380) = r12
	}                                       // 4-byte Folded Spill
	{
		r26 = add(r27,r1)
		r0 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r26,r1)
		r1 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r9 = add(r2,r9)
		r13 = mux(p1,r4,r2)
		memw(r29+#480) = r13.new
	}                                       // 4-byte Folded Spill
	{
		r15 = add(r9,r1)
		r1 = add(r19,#128)
		if (!p2) r5 = add(r9,#0)
		memw(r29+#604) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r11 = and(r1,##536870784)
		r3 = add(r15,r0)
		r1 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r3,r1)
		r0 = memw(r29+#496)
		memw(r29+#580) = r15
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r11)
		r1 = memw(r29+#488)
		memw(r29+#608) = r4
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r11)
		memw(r29+#612) = r4
		memw(r29+#576) = r11
	}                                       // 4-byte Folded Spill
	{
		r4 = add(r4,r0)
		r0 = memw(r29+#484)
		memw(r29+#560) = r4
	}                                       // 4-byte Folded Reload
	{
		r7 += add(r4,r1)
		r1 = memw(r29+#332)
		memw(r29+#564) = r4
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		r4 = add(r7,r0)
		r7 = memw(r29+#452)
		memw(r29+#628) = r7
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r8,#512)
		memw(r29+#624) = r9
		memw(r29+#552) = r5
	}                                       // 4-byte Folded Spill
	{
		r4 = add(r4,add(r7,##512))
		memw(r29+#596) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r4,r14)
		r4 = add(r3,#128)
		memw(r29+#588) = r0
	}                                       // 4-byte Folded Spill
	{
		r7 = mux(p1,#0,r4)
		r3 = mux(p1,r2,#0)
		memw(r29+#620) = r2
		memw(r29+#616) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#584) = r7
		memw(r29+#632) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_264:                             // %for.body875
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r20+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_273
	}
// %bb.265:                             // %if.then879
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		p2 = cmp.eq(r23,#0)
		if (p2.new) jump:nt .LBB12_271
		if (!p2.new) r3 = memw(r29+##332)
	}                                       // 4-byte Folded Reload
// %bb.266:                             // %cond.end885
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		p0 = r3
		if (!p0.new) r19 = add(r23,#-1)
		if (p0.new) jump:t .LBB12_271
		if (!p0.new) r4 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
// %bb.267:                             // %land.lhs.true890
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		r3 = memw(r12+r19<<#2)
	}
	{
		r3 = memw(r4+r3<<#2)
		if (!cmp.eq(r3.new,r2)) jump:t .LBB12_271
	}
// %bb.268:                             // %land.end905
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		r2 = asl(r2,#2)
		r4 = memw(r29+#272)
		r3 = memw(r6+r19<<#2)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r18,#2)
		r0 = addasl(r4,r3,#2)
	}
	{
		call memcmp
	}
	.falign
// %bb.269:                             // %land.end905
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		p1 = cmp.eq(r0,#0)
		r6 = memw(r29+#1704)
		r12 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) jump:nt .LBB12_272
		memw(r6+r23<<#2) = r18
	}
// %bb.270:                             // %cond.end913.thread5679
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		r2 = memw(r25+r19<<#2)
		memw(r25+r23<<#2) = r2.new
	}
	{
		r23 = add(r23,#1)
		jump .LBB12_274
		memw(r12+r23<<#2) = r17
		r2 = memw(r20+#0)

	} :mem_noshuf
	.falign
.LBB12_271:                             // %cond.end913.thread
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		memw(r6+r23<<#2) = r18
	}
	.falign
.LBB12_272:                             // %if.then919
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		r23 = add(r23,#1)
		memw(r25+r23<<#2) = r21
		memw(r12+r23<<#2) = r17
	}
	{
		r2 = memw(r20+#0)
	}
	{
		r3 = add(r2,#63)
	}
	{
		r3 = and(r3,#-64)
	}
	{
		r21 = add(r3,r21)
		jump .LBB12_274
	}
	.falign
.LBB12_273:                             //   in Loop: Header=BB12_264 Depth=1
	{
		r2 = #0
	}
	.falign
.LBB12_274:                             // %if.end926
                                        //   in Loop: Header=BB12_264 Depth=1
	{
		r18 = add(r2,r18)
		r20 = add(r20,#4)
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r16)) jump:t .LBB12_264
	}
// %bb.275:                             // %for.cond.cleanup874
	{
		r2 = memw(r29+#376)
		memw(r29+#548) = r25
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#212) = r23
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_278
	}
// %bb.276:                             // %if.then935
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.277:                             // %if.then935
	{
		jump .LBB12_279
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_278:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_279:                             // %do.end939
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.280:                             // %do.end939
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_282
	}
// %bb.281:                             // %if.then941
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_reset
	}
	.falign
.LBB12_282:                             // %if.end943
	{
		r2 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p0 = or(p3,p1)
		if (p0.new) jump:t .LBB12_288
		if (!p0.new) r2 = memw(r29+##508)
	}                                       // 4-byte Folded Reload
// %bb.283:                             // %if.else949
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_287
		if (p0.new) r1 = memw(r29+#220)
		if (!p0.new) r0 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
// %bb.284:                             // %if.then951
	{
		r2 = memw(r24+#16)
		memw(r29+#0) = r2.new
	}
	{
		r3:2 = memd(r29+#1672)
		r5 = memw(r29+#500)
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#248)
		r1 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r4 = r3
		r6 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_rmsnorm_rows_f32
		memw(r29+#4) = r6
	}
	.falign
// %bb.285:                             // %if.then951
	{
		if (!p1.new) r2 = ##-2147449856
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB12_288
	}
// %bb.286:
	{
		r22 = add(r2,#-32754)
		jump .LBB12_811
	}
	.falign
.LBB12_287:                             // %if.else957
	{
		call moe_dma_copy
		r3:2 = combine(#0,r22)
		r5:4 = combine(#3,#0)
		r0 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_288:                             // %if.end962
	{
		r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = p3
		memw(r29+#1720) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p3 = or(p2,p3)
		if (!p3.new) jump:t .LBB12_292
		if (!p3.new) r0 = memw(r29+##560)
	}                                       // 4-byte Folded Reload
// %bb.289:                             // %if.then967
	{
		r2 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		r2 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p0 = and(p1,!p2)
		if (p0.new) jump:t .LBB12_293
		if (!p0.new) r0 = memw(r29+##552)
	}                                       // 4-byte Folded Reload
// %bb.290:                             // %if.then971
	{
		call memset
		r1 = #0
		r2 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.291:                             // %if.then971
	{
		jump .LBB12_293
	}
	.falign
.LBB12_292:                             // %if.else975
	{
		call memset
		r1 = #0
		r2 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_293:                             // %do.body977
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_296
	}
// %bb.294:                             // %if.then979
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.295:                             // %if.then979
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_296:                             // %do.end985
	{
		r2 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r22 = #0
		if (p0.new) jump:nt .LBB12_305
	}
// %bb.297:                             // %if.end994
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB12_308
		if (!p1.new) r2 = memw(r29+##380)
	}                                       // 4-byte Folded Reload
// %bb.298:                             // %if.else1003
	{
		r2 = memw(r29+#772)
	}
	{
		p3 = cmp.gtu(r2,#1)
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
	}
	{
		p2 = and(p0,p3)
		if (!p2.new) r1 = #0
		if (!p2.new) jump:t .LBB12_618
	}
// %bb.299:                             // %if.then1009
	{
		r0 = add(r29,#728)
		r2 = memw(r29+#380)
		r4 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r4+r3<<#2)
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r5,#96)
		call moe_m1_q_post
	}
	.falign
// %bb.300:                             // %if.then1009
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.301:                             // %if.then1009
	{
		r2 = add(r29,#728)
		r3 = memw(r29+#772)
		if (!cmp.gtu(r3.new,r0)) jump:t ##.LBB12_660
	}
// %bb.302:                             // %if.else1021
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_700
	}
// %bb.303:                             // %if.then1024
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.304:                             // %if.then1024
	{
		r19:18 = combine(r1,r0)
		jump .LBB12_701
		r3 = memw(r29+#772)
	}
	.falign
.LBB12_305:                             // %if.then988
	{
		r2 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r3 = #0
		if (p1.new) jump:t .LBB12_811
	}
// %bb.306:                             // %if.then990
	{
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#300)
		r1 = memw(r29+#624)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.307:                             // %if.then990
	{
		jump .LBB12_811
	}
	.falign
.LBB12_308:                             // %if.then996
	{
		r5 = add(r29,#1816)
		r4 = memw(r29+#256)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#268)
		r1 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		r7 = memw(r29+#544)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r4+r2<<#2)
		memw(r29+#12) = r5

	} :mem_noshuf
	{
		r4 = memw(r29+#292)
		memw(r29+#8) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r6,#96)
		r2 = memw(r29+#400)
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r7
	}
	{
		call moe_push_gate_up_chunks
		r6 = memw(r29+#416)
		memw(r29+#0) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.309:                             // %if.then996
	{
		r1 = #0
	}
	{
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_310:                             // %if.end1075
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_313
	}
// %bb.311:                             // %if.then1078
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.312:                             // %if.then1078
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_313:                             // %do.end1082
	{
		r0 = memw(r29+#220)
		r3 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r5:4 = memd(r29+#1720)
		r3 = memw(r24+#16)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.eq(r5,#0)
		r17:16 = memd(r29+#1672)
		memw(r29+#8) = r3
	}                                       // 8-byte Folded Reload
	{
		r4 = memw(r29+#368)
		r2 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r0 = add(r2,#0)
		if (!p1) r4 = #0
		r3 = memw(r29+#332)
		r2 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		p0 = r2
		r3 = memw(r29+#500)
		r1 = memw(r29+#580)
	}                                       // 4-byte Folded Reload
	{
		r1 = p1
		if (p2) r3 = #0
		r2 = mux(p0,#1,r17)
		memw(r29+#12) = r1
	}
	{
		r3 = memw(r29+#428)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#204)
		memw(r29+#468) = r1
	}                                       // 4-byte Folded Reload
	{
		p0 = r1
		r1 = r16
		r4 = memw(r29+#584)
		memw(r29+#16) = r4
	}                                       // 4-byte Folded Reload
	{
		if (p0) r4 = add(r3,#0)
		r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_rows_u8_params_rm
		r5:4 = combine(r26,r27)
		memw(r29+#0) = r4
	}
	.falign
// %bb.314:                             // %do.end1082
	{
		r2 = #1
		r3 = memw(r29+#504)
		r4 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r8 = maxu(r4,r2)
		r3 = lsr(r3,#7)
		r6 = memw(r29+#568)
		r5 = memw(r29+#1744)
	}                                       // 4-byte Folded Reload
	{
		r3 += lsr(r5,#7)
		r2 = memw(r29+#572)
		r4 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		loop1(.LBB12_315,r8)
		r2 = add(r6,r2)
		r5 = memw(r29+#472)
		r7 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r2,r5)
		r2 = extractu(r17,#23,#6)
		r17 = #384
		r5 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r4 += asl(r2,#9)
		r3 = mpyi(r3,r17)
		r2 = r7
		r11 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r4,add(r5,##1024))
		r4 = add(r6,#1024)
		r6 = memw(r29+#576)
	}                                       // 4-byte Folded Reload
	{
		r2 += add(r3,r6)
		r3 = memw(r29+#464)
		memw(r29+#1720) = r8
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#24,#7)
		r6 = add(r7,r3)
		r9 = memw(r29+#556)
		r8 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		r7 += asl(r3,#8)
		r4 = add(r9,r4)
		r5 = add(r9,r5)
		r15 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r3 = #0
		r6 = add(r4,r6)
		r7 = add(r4,r7)
		r9 = #0
	}
	.falign
.LBB12_315:                             // Block address taken
                                        // %for.body1115
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_321 Depth 2
                                        //     Child Loop BB12_327 Depth 2
	{
		r0 = lsr(r3,#4)
		r12 = memw(r8+#0)
		if (!cmp.eq(r12.new,r3)) jump:t .LBB12_330
	}
// %bb.316:                             // %if.end1122
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r13 = memw(r15+r9<<#2)
		r16 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		p2 = r16
		if (!p2.new) r1 = add(r3,#0)
		r12 = memw(r11+r13<<#2)
		if (p2.new) r13 = memw(r27+#0)
	}
	{
		r12 = add(r12,#63)
		if (!p2) r15 = memw(r29+##1704)
	}                                       // 4-byte Folded Reload
	{
		r14 = and(r12,#-64)
	}
	{
		r12 = add(r14,r3)
		if (!p2) jump:nt .LBB12_318
		if (p2) r14 = memw(r29+##408)
	}                                       // 4-byte Folded Reload
// %bb.317:                             // %if.then1130
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r14 = memw(r29+#404)
		memw(r14+r3<<#2) = r13
	}                                       // 4-byte Folded Reload
	{
		r3 = r12
		jump .LBB12_330
		r13 = memw(r26+#0)
		memw(r14+r3<<#2) = r13.new
	}
	.falign
.LBB12_318:                             // %if.end1136
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r13 = addasl(r11,r13,#2)
	}
	{
		r28 = lsr(r12,#4)
		r15 = memw(r15+r9<<#2)
		if (!cmp.gtu(r28.new,r0)) jump:t .LBB12_325
	}
// %bb.319:                             // %for.body1144.preheader
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r0 += add(r5,r2)
		r28 = sub(r0,r28)
	}
	{
		r10 = sub(#0,r28)
		r28 = r0
	}
	{
		r11 = lsr(r10,#1)
		r10 = and(r10,#1)
	}
	{
		p0 = cmp.gtu(r11,#0)
		if (!p0.new) jump:t .LBB12_322
	}
// %bb.320:                             //   in Loop: Header=BB12_315 Depth=1
	{
		loop0(.LBB12_321,r11)
	}
	.falign
.LBB12_321:                             //   Parent Loop BB12_315 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r16 = add(r1,#16)
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p3 = cmp.gtu(r11,r1)
		r1 = add(r1,#32)
	}
	{
		r11 = mux(p3,#0,#1)
		memb(r28++#2) = r11.new
	}
	{
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p2 = cmp.gtu(r11,r16)
	}
	{
		r11 = mux(p2,#0,#1)
		r0 = r28
		memb(r0+#1) = r11.new
	} :endloop0
	.falign
.LBB12_322:                             //   in Loop: Header=BB12_315 Depth=1
	{
		p0 = cmp.gtu(r10,#0)
		if (!p0.new) jump:t .LBB12_324
		if (p0.new) r0 = memw(r13+#0)
	}
	.falign
.LBB12_323:                             // Block address taken
                                        // %for.body1144
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r0 = add(r0,r3)
	}
	{
		p1 = cmp.gtu(r0,r1)
	}
	{
		r0 = mux(p1,#0,#1)
		memb(r28++#1) = r0.new
	}
	.falign
.LBB12_324:                             //   in Loop: Header=BB12_315 Depth=1
	{
		r11 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_325:                             // %for.cond1156.preheader
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r0 = addasl(r7,r3,#2)
		p1 = cmp.eq(r14,#0)
		if (p1.new) jump:nt .LBB12_329
	}
// %bb.326:                             // %for.body1160.preheader
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		loop0(.LBB12_327,r14)
		r14 = #0
		r28 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r4,r28)
		r28 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r15 = addasl(r28,r15,#2)
		r28 = addasl(r6,r3,#2)
	}
	{
		r3 = addasl(r1,r3,#2)
	}
	.falign
.LBB12_327:                             // Block address taken
                                        // %for.body1160
                                        //   Parent Loop BB12_315 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r1 = memw(r13+#0)
	}
	{
		p3 = cmp.gtu(r1,r14)
		r1 = #0
		r14 = add(r14,#1)
	}
	{
		if (p3) r1 = memw(r15+#0)
	}
	{
		r15 = add(r15,#4)
		memw(r3++#4) = r1
	}
	{
		r10 = memw(r27+r1<<#2)
		memw(r28++#4) = r10.new
	}
	{
		r1 = memw(r26+r1<<#2)
		memw(r0++#4) = r1.new
	} :endloop0
// %bb.328:                             //   in Loop: Header=BB12_315 Depth=1
	{
		r3 = r12
		jump .LBB12_330
		r15 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_329:                             //   in Loop: Header=BB12_315 Depth=1
	{
		r15 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_330:                             // %cleanup1181
                                        //   in Loop: Header=BB12_315 Depth=1
	{
		r9 = add(r9,#1)
		r8 = add(r8,#4)
		nop
	} :endloop1
// %bb.331:                             // %for.cond.cleanup1114
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_337
		if (!p3.new) r16 = memw(r29+##368)
	}                                       // 4-byte Folded Reload
// %bb.332:                             // %if.then1189
	{
		r5 = add(r29,#8704)
		r16 = add(r29,#16896)
		r2 = memw(r29+#352)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#3)
		r2 = memw(r29+#268)
		memw(r29+#232) = r5
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#196)
		r4 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r3,#1)
		r3 = mux(p2,#1,#0)
		r6 = memw(r29+#600)
		memw(r16+#44) = r4
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		memw(r16+#48) = r6
	}
	{
		r2 = add(r5,#8252)
		memd(r16+#56) = r3:2
	}
	{
		call hvx_worker_pool_workers
		memw(r29+#1672) = r2
	}                                       // 4-byte Folded Spill
	.falign
// %bb.333:                             // %if.then1189
	{
		call hvx_tl2_k_splits
		r2 = add(r0,#1)
		r0 = memw(r29+#248)
		r1 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.334:                             // %if.then1189
	{
		r2 = memw(r29+#204)
		memw(r29+#260) = r16
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_622
		memw(r16+#52) = r0
	}
// %bb.335:                             // %land.lhs.true1201
	{
		r2 = memw(r29+#348)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#24,#0)
		r2 = add(r2,#127)
	}
	{
		r2 = and(r2,#-128)
	}
	{
		r3 = asl(r3,#8)
	}
	{
		r2 = mpyi(r0,r2)
		if (!cmp.gtu(r2.new,r3)) jump:t ##.LBB12_662
	}
// %bb.336:
	{
		r2 = ##-2147449856
	}
	{
		r22 = add(r2,#-32754)
		jump .LBB12_811
	}
	.falign
.LBB12_337:                             // %if.end1799
	{
		r4 = add(r29,#696)
		r2 = memw(r29+#480)
		r19 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#376)
		memw(r29+#696) = r2
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#616)
		memw(r29+#700) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#540)
		memw(r29+#704) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#404)
		memw(r29+#712) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#408)
		memw(r29+#708) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r19,r16)
		r2 = memw(r29+#428)
		memw(r29+#716) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#248)
		memw(r29+#720) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#612)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#724) = r2
	}
	{
		r2 = memw(r18+##hexkl_moe_pack_bg_worker@GOT)
		memw(r19+#0) = r2.new
	}
	{
		r2 = lsr(r3,#4)
		memw(r19+#8) = r2.new
	}
	{
		r2 = memw(r29+#608)
		memw(r19+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit_bg
		memw(r19+#12) = r2
	}
	.falign
// %bb.338:                             // %if.end1799
	{
		r4 = memw(r29+#532)
		r5 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r4 = and(##-512,asl(r4,#3))
		r2 = memw(r29+#1744)
		r3 = memw(r29+#1728)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#7)
		r3 = add(r5,r3)
		r1 = memw(r29+#504)
		r0 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r2 += lsr(r1,#7)
		r6 = memw(r29+#536)
		r1 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r3,r6)
		r3 = #1536
		r6 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r0,r1)
		r0 = memw(r29+#604)
		r1 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		r0 = and(##1073741568,asl(r0,#1))
		r4 += mpyi(r2,r17)
	}
	{
		r1 += add(r4,r0)
		r0 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r1,r0)
		r0 = memw(r29+#420)
		r1 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r1)
		r1 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#2)
		r1 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r1,r3)
		call memset
		r1 = #255
	}
	.falign
// %bb.339:                             // %if.end1799
	{
		r1:0 = combine(r19,r16)
		r2 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r2,#64)
	}
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.340:                             // %if.end1799
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	{
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_343
	}
// %bb.341:                             // %if.then1910
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.342:                             // %if.then1910
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_343:                             // %do.end1916
	{
		p3 = and(p3,!p3)
		r2 = memw(r29+#268)
		r3 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r0 = p3
		r2 = add(r2,r3)
		memw(r29+#584) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = extractu(r2,#11,#0)
		memw(r29+#204) = r0
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0); if (!p0.new) jump:t .LBB12_345
	}
// %bb.344:                             // %land.rhs1922
	{
		r2 = p0
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_345:                             // %land.end1927
	{
		r9 = #64
		r21 = memw(r29+#268)
		r0 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r8 = memw(r29+#444)
		r1 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r6 = maxu(r0,r8)
		r17 = minu(r8,r0)
		p2 = cmp.eq(r1,#0)
		r1 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r6,#8)
		r6 = sub(r6,r8)
		r0 = memw(r29+#188)
		r2 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p0)
		r2 = add(r21,r2)
		r3 = memw(r1+#0)
		r1 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p3 = and(p1,!p2)
		p1 = r1
		memw(r29+#536) = r2
		memw(r29+#1696) = r3
	}                                       // 4-byte Folded Spill
	{
		r0 = p3
		p3 = and(p3,!p1)
		r7 = memw(r0+r3<<#2)
		memw(r29+#488) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r1 = p3
		p1 = cmp.gtu(r7,#64)
		r0 = memw(r29+#548)
		memw(r29+#604) = r6
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r7,r9)
		r7 = #0
		r16 = memw(r29+#292)
		r2 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(#0,r21)
		r5 = r16
		r18 = memw(r0+#0)
		memw(r29+#600) = r1
	}                                       // 4-byte Folded Spill
	{
		r3 = r18
		r12 = mux(p1,#0,#1)
		r4 = memw(r29+#248)
		memw(r29+#4) = #0
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#0) = #0
		memw(r29+#436) = r6
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#236) = r12
		memd(r29+#1680) = r7:6
	}                                       // 4-byte Folded Spill
	{
		call moe_push_act_block
	}
	.falign
// %bb.346:                             // %land.end1927
	{
		p1 = or(p1,!p1)
		r0 = #0
		r4 = memw(r29+#564)
		memw(r29+#508) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,#96)
		r1 = memw(r29+#280)
		r3 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#632) = r2
		memw(r29+#396) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r3,r1)
		r1 = extractu(r16,#22,#0)
		r3 = memw(r29+#544)
		memw(r29+#492) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#10)
		r1 = memw(r29+#252)
		memw(r29+#652) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r1,#23,#4)
		r1 = mpyi(r17,r3)
		memw(r29+#636) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r2,#9)
		r1 = memw(r29+#424)
		memw(r29+#340) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = !cmp.eq(r1,#0)
		r1 = memw(r29+#208)
		memw(r29+#192) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r21,r1)
		r1 = memw(r29+#392)
		memw(r29+#608) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r3,#22,#0)
		memw(r29+#612) = r2
		memw(r29+#464) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r2,#10)
		r3 = !cmp.eq(r1,#0)
		r1 = memw(r29+#232)
		memw(r29+#468) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r21,r1)
		r1 = #-1
		memw(r29+#620) = r2
		memw(r29+#572) = r0
	}                                       // 4-byte Folded Spill
	{
		r1 = #1
		memw(r29+#528) = r1
		memw(r29+#616) = r3
	}                                       // 4-byte Folded Spill
	{
		r0 = #0
		memw(r29+#484) = r0
		memw(r29+#516) = r0
	}                                       // 4-byte Folded Spill
	{
		r1 = p1
		memw(r29+#324) = r1
		memw(r29+#540) = r0
	}                                       // 4-byte Folded Spill
	{
		r3:2 = combine(#0,#0)
		memw(r29+#500) = r2
		memw(r29+#576) = r17
	}                                       // 4-byte Folded Spill
	{
		r0 = #0
		r1 = #1
		memw(r29+#472) = r0
		memw(r29+#496) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#384) = r1
		memw(r29+#232) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#504) = r0
		memw(r29+#524) = r4
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#1736) = r3:2
		memd(r29+#1728) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#1744) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_347:                             // %for.cond1971
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_382 Depth 2
                                        //       Child Loop BB12_410 Depth 3
                                        //       Child Loop BB12_455 Depth 3
                                        //         Child Loop BB12_465 Depth 4
                                        //         Child Loop BB12_460 Depth 4
                                        //       Child Loop BB12_433 Depth 3
                                        //     Child Loop BB12_518 Depth 2
                                        //       Child Loop BB12_586 Depth 3
                                        //         Child Loop BB12_595 Depth 4
                                        //         Child Loop BB12_591 Depth 4
                                        //     Child Loop BB12_514 Depth 2
	{
		r2 = memw(r29+#384)
		r0 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r1 = memw(r29+#1696)
		memw(r29+#456) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#396)
		memw(r29+#372) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#436)
		memw(r29+#460) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#324)
		memw(r29+#220) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#236)
		memw(r29+#440) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#240)
		memw(r29+#420) = r1
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#468)
		r1 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r3,#2)
		r0 = p1
		p0 = cmp.eq(r1,#0)
		memw(r29+#196) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p0
		memw(r29+#476) = r2.new
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB12_351
		memw(r29+#1720) = r0
		if (p1) memw(r29+##480) = r18
	}                                       // 4-byte Folded Spill
// %bb.348:                             // %if.then1973
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		p3 = or(p3,!p3)
		r2 = memw(r29+#420)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_352
	}                                       // 4-byte Folded Reload
// %bb.349:                             // %if.end.i
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r3 = #0
		r4 = memw(r29+#456)
		memw(r29+#384) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,#1)
		r3 = memw(r29+#420)
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#440)
		memw(r29+#324) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#212)
		memw(r29+#480) = r18
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r3,r2)
		r3 = memw(r29+#220)
		memw(r29+#436) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#460)
		memw(r29+#396) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#372)
		memw(r29+#1696) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = p3
		memw(r29+#340) = r4
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB12_354
		if (p0) r3 = memw(r29+##380)
		memw(r29+#580) = r3
	}                                       // 4-byte Folded Reload
// %bb.350:                             // %if.then3.i
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r0 = #64
		r6 = #0
		r1 = #1
	}
	{
		memw(r29+#396) = r6
		memw(r29+#324) = r1
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r3+r2<<#2)
		memw(r29+#1696) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r2<<#2)
		memw(r29+#480) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r3 = minu(r3,r0)
		p1 = cmp.gtu(r3,#64)
		memw(r29+#436) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p2 = not(p1)
		jump .LBB12_353
	}
	.falign
.LBB12_351:                             //   in Loop: Header=BB12_347 Depth=1
	{
		r0 = memw(r29+#440)
		memw(r29+#324) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#220)
		memw(r29+#436) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#460)
		memw(r29+#396) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#372)
		memw(r29+#1696) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#456)
		memw(r29+#340) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#1680)
	}                                       // 8-byte Folded Reload
	{
		r2 = memw(r29+#420)
		memw(r29+#236) = r2.new
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_378
		memw(r29+#384) = r1
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_352:                             // %if.then.i
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#380)
		r5 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#460)
		r1 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r4,#64)
		r4 = add(r4,#128)
		r6 = memw(r2+r5<<#2)
		r2 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		r0 = cmp.eq(r7,#0)
		memw(r29+#1696) = r6
	}                                       // 4-byte Folded Spill
	{
		r2 = r5
		r3 = memw(r2+r5<<#2)
		memw(r29+#324) = r0
	}                                       // 4-byte Folded Spill
	{
		r3 = add(r3,r7)
		r5 = memw(r1+r6<<#2)
	}
	{
		p3 = cmp.gtu(r5,r4)
		r6 = sub(r5,r7)
		r3 = #64
		memw(r29+#480) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = minu(r6,r3)
		p2 = not(p3)
		memw(r29+#396) = r7
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#436) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_353:                             // %return.sink.split.i
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		p0 = and(p0,!p0)
		r4 = #1
		r3 = memw(r29+#236)
		memw(r29+#384) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r0 = p0
		r3 = mux(p2,#1,#0)
		memw(r29+#340) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#580) = r0
		memw(r29+#236) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_354:                             // %moe_blk_next.exit
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r5:4 = combine(#0,#1)
		r2 = memw(r29+#256)
		r3 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+r3<<#2)
	}
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_358
	}
// %bb.355:                             // %do.end1999
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r17 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r17+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#128)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#128) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.356:                             // %do.end1999
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_358
	}
// %bb.357:                             // %if.then2001
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = memd(r29+#1680)
		r2 = memw(r29+#508)
	}                                       // 8-byte Folded Reload
	{
		call hexkl_dma_trace_wait_begin
		r3 = r5
	}
	.falign
.LBB12_358:                             // %if.end2003
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		call hexkl_dma_ring_wait
		r0 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.359:                             // %if.end2003
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_364
	}
// %bb.360:                             // %do.body2008
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.361:                             // %do.body2008
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_364
	}
// %bb.362:                             // %if.then2010
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.363:                             // %if.then2010
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#32)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#32) = r1:0
	}
	.falign
.LBB12_364:                             // %do.end2016
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r23 = memw(r29+#244)
		r0 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		r23 += mpyi(r16,#96)
	}
	{
		r2 = memw(r23+#20)
	}
	{
		r2 = addasl(r0,r18,#2)
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB12_366
		memw(r29+#556) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.365:                             // %if.then2020
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r4 = add(r29,#2456)
		r0 = memw(r29+#268)
		r1 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_sums
		r2 = memw(r29+#248)
		r3 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_366:                             // %if.end2024
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = #63
	}
	{
		r2 = memw(r29+#348)
		if (cmp.gtu(r2.new,r2)) jump:t .LBB12_381
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_367:                             // %for.end2456
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#580)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:t .LBB12_378
		if (!p3.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.368:                             // %do.body2459
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_371
	}
// %bb.369:                             // %if.then2461
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.370:                             // %if.then2461
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_371:                             // %do.end2465
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#480)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#64)
		r1 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.372:                             // %do.end2465
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_375
	}
// %bb.373:                             // %if.then2471
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.374:                             // %if.then2471
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_375:                             // %do.end2477
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#396)
		r0 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#6)
		r4 = memw(r29+#248)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1680)
		memw(r29+#0) = r0
	}                                       // 8-byte Folded Reload
	{
		r1 = r3
		r0 = memw(r29+#268)
		r3 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#428)
		r5 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		call moe_push_act_block
	}
	.falign
// %bb.376:                             // %do.end2477
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#324)
		memw(r29+#508) = r0
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB12_378
		if (!p1.new) r1 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
// %bb.377:                             // %if.then2485
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#256)
		r3 = memw(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r2+r3<<#2)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#544)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r5,#96)
		r2 = memw(r29+#416)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#1816)
		r0 = memw(r29+#340)
		memw(r29+#8) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#268)
		memw(r29+#12) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#400)
		r4 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		call moe_push_gate_up_chunks
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_378:                             // %if.end2502
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) r22 = #0
		if (p3.new) jump:nt .LBB12_480
	}
// %bb.379:                             // %if.else2529
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#540)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_491
	}                                       // 4-byte Folded Reload
// %bb.380:                             // %land.lhs.true2550
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#596)
		r3 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#628)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r3<<#2)
	}
	{
		r22 = addasl(r0,r2,#6)
		p1 = cmp.eq(r2,#-1)
	}
	{
		if (p1) r22 = #0
		jump .LBB12_491
	}
	.falign
.LBB12_381:                             // %for.body2029.lr.ph
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r20 = #0
		r24 = #0
		r0 = memw(r29+#440)
		r2 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r0,#0)
		p0 = cmp.eq(r2,#0)
		r1 = memw(r29+#476)
		r0 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		p0 = not(p0)
		r1 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r18,#2)
		p2 = not(p1)
		memw(r29+#640) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r1,#2)
		r1 = memw(r29+#488)
		memw(r29+#656) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		r1 = p3
		r0 = memw(r29+#416)
		memw(r29+#532) = r0.new
	}                                       // 4-byte Folded Reload
	{
		p2 = and(p0,and(p1,p2))
		p1 = and(p1,!p3)
		memw(r29+#648) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p2
		memw(r29+#644) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		memw(r29+#568) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_382:                             // %for.body2029
                                        //   Parent Loop BB12_347 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_410 Depth 3
                                        //       Child Loop BB12_455 Depth 3
                                        //         Child Loop BB12_465 Depth 4
                                        //         Child Loop BB12_460 Depth 4
                                        //       Child Loop BB12_433 Depth 3
	{
		r16 = add(r29,#1752)
		r2 = memw(r29+#416)
		r0 = memw(r29+#568)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r2 = sub(r2,r24)
		r3 = memw(r29+#544)
	}                                       // 4-byte Folded Reload
	{
		r22 = minu(r2,r3)
		if (!p2) jump:nt .LBB12_392
		if (!p2) r2 = memw(r29+##648)
	}                                       // 4-byte Folded Reload
// %bb.383:                             // %land.lhs.true2047
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3 = memw(r29+#376)
		r2 = memw(r16+r20<<#2)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p1) jump:nt .LBB12_394
		r2 = memw(r3+#0)
	}
// %bb.384:                             // %do.body2051
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB12_387
	}
// %bb.385:                             // %if.then2053
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.386:                             // %if.then2053
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_387:                             // %do.end2057
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r20,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.388:                             // %do.end2057
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_391
	}
// %bb.389:                             // %if.then2061
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.390:                             // %if.then2061
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_391:                             // %do.end2067
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = addasl(r16,r20,#2)
	}
	{
		jump .LBB12_415
		memw(r2+#0) = #0
	}
	.falign
.LBB12_392:                             // %if.else2069
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		p1 = r2
		if (p1.new) jump:nt .LBB12_415
		if (!p1.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.393:                             // %if.else2069.do.body2073_crit_edge
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_394:                             // %do.body2073
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r0 = add(r29,#1816)
		p0 = cmp.eq(r2,#0)
	}
	{
		r16 = addasl(r0,r20,#2)
		if (p0) jump:nt .LBB12_398
	}
// %bb.395:                             // %do.end2079
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.396:                             // %do.end2079
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_398
	}
// %bb.397:                             // %if.then2081
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #1
		r2 = memw(r16+#0)
	}
	.falign
.LBB12_398:                             // %if.end2084
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r16+#0)
	}
	.falign
// %bb.399:                             // %if.end2084
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_404
	}
// %bb.400:                             // %do.body2090
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.401:                             // %do.body2090
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_404
	}
// %bb.402:                             // %if.then2092
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.403:                             // %if.then2092
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_404:                             // %do.end2098
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r17 = memw(r29+#368)
		memw(r29+#8) = r17.new
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#268)
		memw(r29+#4) = r22
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#216)
		memw(r29+#0) = r24
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r25,r18)
		r26 = memw(r29+#400)
		r21 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r23,r26)
		r19 = memw(r29+#292)
		r6 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
		r5:4 = combine(r21,r19)
		r16 = or(r6,r20)
	}
	.falign
// %bb.405:                             // %do.end2098
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r1:0 = combine(r25,r18)
		r5:4 = combine(r21,r19)
		r2 = memw(r29+#416)
		memw(r29+#8) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r24,r2)
		memw(r29+#0) = r2.new
	}
	{
		call moe_expand_chunk
		r3:2 = combine(r23,r26)
		memw(r29+#4) = r22
	}
	.falign
// %bb.406:                             // %do.end2098
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		p0 = cmp.eq(r16,#0); if (!p0.new) jump:t .LBB12_415
		if (p0.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.407:                             // %if.then2107
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#104)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r23+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_411
	}
// %bb.408:                             // %if.then2113
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3:2 = combine(#0,#0)
		r1:0 = memd(r23+#56)
	}
	{
		p2 = cmp.eq(r1:0,r3:2)
		if (p2.new) jump:nt .LBB12_412
		if (!p2.new) r2 = memw(r23+#28)
	}
// %bb.409:                             // %for.body2117.lr.ph
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3 = ##-1431655765
		r2 = add(r2,#23)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r3 = lsr(r2,#4)
		r2 = #0
	}
	{
		r3 = +mpyi(r3,##640)
	}
	.balign 32
.LBB12_410:                             // %for.body2117
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_382 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r5:4 = combine(#-1,#-1)
		r2 = add(r2,r3)
	}
	{
		r5:4 = add(r1:0,r5:4)
	}
	{
		r1:0 = and(r5:4,r1:0)
		r5:4 = combine(#0,#0)
	}
	{
		p3 = cmp.eq(r1:0,r5:4)
		if (!p3.new) jump:t .LBB12_410
	}
	{
		jump .LBB12_413
	}
	.falign
.LBB12_411:                             //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#652)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r22)
		jump .LBB12_413
	}
	.falign
.LBB12_412:                             //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = #0
	}
	.falign
.LBB12_413:                             // %do.body2129
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_418
	}
// %bb.414:                             // %if.then2131
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r6 = lsr(r2,#10)
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_us@GOT)
		r1:0 = memd(r29+#1680)
	}                                       // 8-byte Folded Reload
	{
		r7 = r1
	}
	{
		r5 = r7
		r1:0 = memd(r3+#80)
	}
	{
		r1:0 = add(r1:0,r7:6)
		memd(r29+#1680) = r5:4
	}                                       // 8-byte Folded Spill
	{
		memd(r3+#80) = r1:0
	}
	.falign
.LBB12_415:                             // %do.body2141
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_418
	}
// %bb.416:                             // %if.then2143
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.417:                             // %if.then2143
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_418:                             // %do.end2147
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r18 = #0
		r16 = memw(r29+#200)
		r1 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r25 = and(r1,#1)
		r0 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r0,r25)
		r2 = memw(r29+#416)
		if (!cmp.eq(r2.new,r24)) jump:t ##.LBB12_454
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_419:                             // %do.body2242
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_422
	}
// %bb.420:                             // %if.then2244
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.421:                             // %if.then2244
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_422:                             // %do.end2255
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#576)
		r0 = memw(r29+#568)
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		r17 = add(r20,r2)
		r1 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r1,r17)
	}
	{
		p3 = and(p0,p2)
		if (!p3.new) jump:t .LBB12_432
		if (p3.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.423:                             // %if.then2264
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_426
	}
// %bb.424:                             // %if.then2277
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.425:                             // %if.then2277
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_426:                             // %do.end2281
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r17<<#2)
	}
	.falign
// %bb.427:                             // %do.end2281
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_430
	}
// %bb.428:                             // %if.then2286
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.429:                             // %if.then2286
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_430:                             // %do.end2292
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r3 = add(r29,#2712)
		r5 = add(r29,#2328)
		r6 = memw(r29+#292)
		r2 = memw(r29+#636)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r24,r2)
		r2 = add(r29,#5632)
		r7 = memw(r29+#416)
		memw(r29+#8) = r6
	}                                       // 4-byte Folded Reload
	{
		r6 = sub(r7,r4)
		r4 = add(r4,r7)
		r0 = memw(r29+#296)
		memw(r29+#16) = r4
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r17,#5)
		r3 = addasl(r5,r17,#3)
		r7 = memw(r29+#544)
		memw(r29+#12) = r0
	}                                       // 4-byte Folded Reload
	{
		r5 = minu(r6,r7)
		r2 += mpyi(r17,#192)
		r0 = memw(r29+#400)
		memw(r29+#0) = r0.new
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#20) = r4
		memw(r29+#24) = r5
	}
	{
		r0 = memw(r29+#368)
		memw(r29+#4) = r23
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_submit
		r4 = memw(r29+#268)
		r5 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.431:                             // %do.end2292
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r17<<#2) = r3
	}
	.falign
.LBB12_432:                             // %if.end2304
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r19 = add(r20,#1)
		r5 = memw(r29+#604)
		r4 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r20,r5)
		r2 = add(r20,sub(#1,r5))
		p2 = cmp.gtu(r5,r20)
		p3 = cmp.eq(r19,r4)
	}
	{
		r17 = sub(r3,r5)
		if (p2) r2 = #0
		r3 = memw(r29+#444)
		r0 = memw(r29+#644)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		if (p3) r2 = add(r3,#0)
	}
	{
		r18 = minu(r2,r3)
	}
	{
		p0 = cmp.gtu(r18,r17)
	}
	{
		p1 = and(p3,p0)
		if (!p1.new) jump:t .LBB12_443
	}
	.falign
.LBB12_433:                             // %land.rhs2341
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_382 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r21 = add(r17,#8)
		r26 = add(r29,#1752)
	}
	{
		r2 = memw(r26+r21<<#2)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_443
	}
// %bb.434:                             // %for.body2349
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r2 = memw(r29+#196)
		r0 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r27 = memw(r2+#0)
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_437
	}
// %bb.435:                             // %if.then2368
                                        //   in Loop: Header=BB12_433 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.436:                             // %if.then2368
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_437:                             // %do.end2372
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r2 = add(r29,#2008)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r17<<#2)
	}
	.falign
// %bb.438:                             // %do.end2372
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_441
	}
// %bb.439:                             // %if.then2376
                                        //   in Loop: Header=BB12_433 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.440:                             // %if.then2376
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_441:                             // %do.end2382
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r3 = add(r29,#2712)
		r5 = add(r29,#2328)
		r8 = memw(r29+#280)
		r7 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#284)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = mpyi(r17,r8)
		r2 = add(r29,#5632)
		r6 = memw(r29+#244)
		memw(r29+#16) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r21,#192)
		r6 += mpyi(r27,#96)
		r4 = sub(r7,r4)
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		r4 = minu(r4,r8)
		r1 = addasl(r3,r21,#5)
		r0 = memw(r29+#368)
		memw(r29+#0) = r1
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r5,r21,#3)
		r21 = addasl(r26,r21,#2)
		r4 = memw(r29+#268)
		memw(r29+#24) = r4
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#208)
		memw(r29+#12) = r7
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_submit
		memw(r29+#20) = #-1
		memw(r29+#4) = r6
	}
	.falign
// %bb.442:                             // %do.end2382
                                        //   in Loop: Header=BB12_433 Depth=3
	{
		r17 = add(r17,#1)
		memw(r21+#0) = #1
	}
	{
		p2 = cmp.gtu(r18,r17)
		if (p2.new) jump:t .LBB12_433
	}
	.falign
.LBB12_443:                             // %for.cond.cleanup2348
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_446
	}
// %bb.444:                             // %if.then2399
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.445:                             // %if.then2399
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_446:                             // %do.end2403
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.447:                             // %do.end2403
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_450
	}
// %bb.448:                             // %if.then2406
                                        //   in Loop: Header=BB12_382 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.449:                             // %if.then2406
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		p0 = cmp.eq(r20,#0)
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r3 = mux(p0,#120,#16)
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+r3<<#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+r3<<#0) = r1:0
	}
	.falign
.LBB12_450:                             // %do.end2416
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r18 = add(r29,#3224)
		r2 = memw(r23+#20)
		r3 = memw(r29+#608)
	}                                       // 4-byte Folded Reload
	{
		r18 += mpyi(r25,##324)
		p1 = cmp.eq(r2,#0)
	}
	{
		if (!p1) r0 = add(r18,#68)
		if (p1) jump:nt .LBB12_452
		memw(r18+#60) = r3
		memw(r18+#64) = r2
	}
// %bb.451:                             // %if.then2425
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		call memcpy
		r1 = add(r29,#2456)
		r2 = memw(r29+#656)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_452:                             // %for.inc2450
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r4 = memw(r29+#520)
		r5 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#268)
		r1:0 = memd(r23+#8)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r16)
		r3 = memw(r4+#8)
		memw(r18+#4) = r5

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		r3 = memw(r29+#220)
		memw(r18+#8) = r22
	}                                       // 4-byte Folded Reload
	{
		memw(r18+#12) = r24
		memw(r18+#0) = r2
	}
	{
		r2 = memw(r4+#12)
		memw(r18+#20) = r3

	} :mem_noshuf
	{
		r3 = memw(r29+#640)
		memw(r18+#24) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#556)
		memw(r18+#36) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_gu_worker@PCREL)
		r0 = memw(r23+#16)
		memw(r18+#32) = r1
	}
	{
		r6 = memw(r29+#252)
		memw(r18+#40) = r0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#368)
		memw(r18+#28) = r3
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r22,r18)
		r7 = memw(r29+#500)
		memw(r18+#16) = r2
	}                                       // 4-byte Folded Reload
	{
		memw(r18+#44) = r6
		memw(r18+#52) = r6
	}
	{
		r6 = memw(r29+#356)
		memw(r18+#48) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		memw(r18+#56) = r6
	}
	.falign
// %bb.453:                             // %for.inc2450
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r20 = r19
		r2 = memw(r29+#544)
		r1 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r2)
		r3 = memw(r29+#416)
		r0 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r3,r24)
		r3 = add(r1,#1)
		memw(r29+#472) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = sub(r0,r2)
		if (p2) jump:nt .LBB12_382
		memw(r29+#532) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_367
	}
	.falign
.LBB12_454:                             // %for.body2154.lr.ph
                                        //   in Loop: Header=BB12_382 Depth=2
	{
		r2 = memw(r29+#544)
		r3 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r2,#1)
		r3 = add(r24,r3)
	}
	{
		r17 = sub(r3,r22)
		r3 = #1
	}
	{
		r27 = maxu(r2,r3)
	}
	.falign
.LBB12_455:                             // %for.body2154
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_382 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_465 Depth 4
                                        //         Child Loop BB12_460 Depth 4
	{
		p0 = cmp.gtu(r22,r18)
	}
	{
		r2 = mux(p0,r24,r17)
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r19 = add(r18,r2)
	}
	.falign
// %bb.456:                             // %for.body2154
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = memw(r29+#248)
		r0 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		p1 = cmp.gtu(r2,#31)
		if (!p2.new) jump:t .LBB12_463
	}
// %bb.457:                             // %if.then2166
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		if (!p1) jump:nt .LBB12_468
		r3 = memw(r29+#268)
		if (p1) r4 = memw(r29+##292)
	}                                       // 4-byte Folded Reload
// %bb.458:                             // %for.body2177.preheader
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = memw(r29+#584)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r19,#9)
		r5 = lsr(r4,#1)
		r4 = and(r4,#1)
	}
	{
		p1 = cmp.gtu(r5,#0); if (!p1.new) jump:t .LBB12_461
	}
// %bb.459:                             //   in Loop: Header=BB12_455 Depth=3
	{
		loop0(.LBB12_460,r5)
	}
	.falign
.LBB12_460:                             //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_382 Depth=2
                                        //       Parent Loop BB12_455 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7 = #31
		r8 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r5 = add(r3,#2048)
		r6 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r6)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r3 = add(r3,#4096)
		r2 = add(r2,r6)
	} :endloop0
	.falign
.LBB12_461:                             //   in Loop: Header=BB12_455 Depth=3
	{
		r5 = #384
		p2 = cmp.gtu(r4,#0)
		if (p2.new) r4 = #31
		if (!p2.new) jump:t .LBB12_468
	}
	.falign
.LBB12_462:                             // Block address taken
                                        // %for.body2177
                                        //   in Loop: Header=BB12_455 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	{
		jump .LBB12_468
	}
	.falign
.LBB12_463:                             // %for.cond2187.preheader
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		if (p1) r26 = #0
		if (!p1) jump:nt .LBB12_468
		if (p1) r21 = memw(r29+#216)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
// %bb.464:                             // %for.body2191.preheader
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r21 += asl(r19,#9)
		r19 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_465:                             // %for.body2191
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_382 Depth=2
                                        //       Parent Loop BB12_455 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r26
		r2 = r21
	}
	.falign
// %bb.466:                             // %for.body2191
                                        //   in Loop: Header=BB12_465 Depth=4
	{
		r26 = add(r26,#2048)
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB12_617
		if (p0.new) r2 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
// %bb.467:                             // %for.cond2187
                                        //   in Loop: Header=BB12_465 Depth=4
	{
		r21 = add(r21,r2)
		r19 = add(r19,#-1)
		r0 = memw(r29+#268)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB12_465
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_468:                             // %do.body2211
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_471
	}
// %bb.469:                             // %if.then2213
                                        //   in Loop: Header=BB12_455 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.470:                             // %if.then2213
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_471:                             // %do.end2217
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r19 = #0
		r2 = r16
		r3 = memw(r29+#424)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r3,#0)
		r3 = memw(r29+#388)
		if (!p2.new) r1:0 = memd(r29+##1680)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r18,r3)
		if (p2) jump:nt .LBB12_473
		if (!p2) r3 = memw(r29+##268)
	}                                       // 4-byte Folded Reload
// %bb.472:                             // %if.then.i5495
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = add(r3,r2)
		r6 = memw(r29+#424)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_475
		v0 = vmem(r2+#0)
	}
	.falign
.LBB12_473:                             // %if.end.i5498
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#268)
		r1 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.474:                             // %if.end.i5498
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r19 = r0
	}
	.falign
.LBB12_475:                             // %moe_acc_read.exit
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_478
	}
// %bb.476:                             // %if.then2223
                                        //   in Loop: Header=BB12_455 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.477:                             // %if.then2223
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_478:                             // %do.end2229
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r0 = r19
		p0 = cmp.eq(r19,#0); if (!p0.new) jump:nt .LBB12_617
	}
// %bb.479:                             // %for.cond2149
                                        //   in Loop: Header=BB12_455 Depth=3
	{
		r18 = add(r18,#1)
		if (!cmp.eq(r18.new,r27)) jump:t .LBB12_455
	}
	{
		jump .LBB12_419
	}
	.falign
.LBB12_480:                             // %do.body2506
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_483
	}
// %bb.481:                             // %if.then2508
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.482:                             // %if.then2508
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_483:                             // %do.end2512
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.484:                             // %do.end2512
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_487
	}
// %bb.485:                             // %if.then2515
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.486:                             // %if.then2515
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_487:                             // %do.end2521
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r18 = add(r29,#792)
		r3:2 = memd(r29+#1680)
	}                                       // 8-byte Folded Reload
	{
		call memset
		r1:0 = combine(r3,r18)
		r2 = #856
	}
	.falign
// %bb.488:                             // %do.end2521
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#220)
		memw(r29+#1652) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#500)
		memw(r29+#1648) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#4,r18)
		r0 = memw(r29+#368)
		r4 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#592)
		memw(r29+#1660) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#588)
		memw(r29+#1656) = r4
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#536)
		memw(r29+#1664) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		memw(r29+#1668) = r6
	}
	.falign
// %bb.489:                             // %do.end2521
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		jump .LBB12_510
	}
	.falign
.LBB12_491:                             // %cond.end2560
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#196)
		r1 = memw(r29+#1704)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#464)
		r0 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r17 = memw(r2+#0)
		if (p2.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
	{
		if (!p2) jump:nt .LBB12_499
		r16 = memw(r1+r3<<#2)
	}
// %bb.492:                             // %do.body2564
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_495
	}
// %bb.493:                             // %if.then2566
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.494:                             // %if.then2566
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_495:                             // %do.end2570
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.496:                             // %do.end2570
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_499
	}
// %bb.497:                             // %if.then2573
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.498:                             // %if.then2573
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_499:                             // %if.end2580
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		p1 = cmp.eq(r22,#0)
	}
	{
		r2 = p1
		if (p1) jump:nt .LBB12_507
		memw(r29+#580) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.500:                             // %do.body2583
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_503
	}
// %bb.501:                             // %if.then2585
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.502:                             // %if.then2585
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_503:                             // %do.end2589
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#596)
		r1 = memw(r29+#632)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#464)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r2 = #-1
		r3 = memw(r2+r3<<#2)
	}
	{
		r1 += mpyi(r3,#96)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.504:                             // %do.end2589
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_507
	}
// %bb.505:                             // %if.then2598
                                        //   in Loop: Header=BB12_347 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.506:                             // %if.then2598
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_507:                             // %if.end2605
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r4 = add(r29,#2456)
		r25 = memw(r29+#244)
		r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r25 += mpyi(r17,#96)
		r2 = and(r2,#1)
		r0 = memw(r29+#452)
		memw(r29+#556) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r17 = togglebit(r2,#0)
		r3 = memw(r29+#536)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r17,r0)
		r1 = memw(r25+#20)
		memw(r29+#476) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p2 = cmp.eq(r1,#0)
		if (p2.new) jump:nt .LBB12_509
		if (!p2.new) r3 = memw(r29+##588)
	}                                       // 4-byte Folded Reload
// %bb.508:                             // %if.then2608
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r0 = memw(r29+#476)
		r1 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r17,#8)
		call hexkl_wh_affine_sums
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_509:                             // %if.end2617
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r27 = #0
		r20 = #0
		r2 = memw(r29+#264)
		if (cmp.gtu(r2.new,#31)) jump:t .LBB12_517
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_510:                             // %if.end3077
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) r16 = add(r29,##2008)
		if (p3.new) jump:nt .LBB12_865
	}
// %bb.511:                             // %if.end3080
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#528)
		r25 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,r25)
		if (p3.new) jump:t .LBB12_516
		r21 = memw(r29+#276)
		r23 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
// %bb.512:                             // %if.then3084
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r2 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		if (p0.new) r17 = #0
		p0 = cmp.gtu(r2,#31); if (!p0.new) jump:t .LBB12_516
		if (p0.new) r2 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.513:                             //   in Loop: Header=BB12_347 Depth=1
	{
		r20 = #0
		r19 = r21
	}
	{
		r3 = memw(r29+#372)
		r18 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r3<<#2)
	}
	{
		r18 += mpyi(r2,#96)
	}
	.falign
.LBB12_514:                             // %for.body3095
                                        //   Parent Loop BB12_347 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r5:4 = combine(r21,r23)
		r24 = memw(r29+#280)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r19,r24)
		r1 = memw(r29+#208)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1688)
		memw(r29+#16) = r20
	}                                       // 8-byte Folded Reload
	{
		r2 = r3
		r3 = r18
		memw(r29+#12) = r25
		memw(r29+#0) = r17
	}
	{
		call moe_push_weight_chunk
		memw(r29+#8) = #3
	}
	.falign
// %bb.515:                             // %for.body3095
                                        //   in Loop: Header=BB12_514 Depth=2
	{
		r17 = add(r17,r24)
		r20 = add(r20,#1)
		r16 = add(r16,#4)
		memw(r16+#0) = r0
	}
	{
		r19 = sub(r19,r24)
		p1 = cmp.gtu(r21,r17); if (p1.new) jump:t .LBB12_514
	}
	.falign
.LBB12_516:                             // %for.inc3122
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r0 = memw(r29+#496)
		memw(r29+#464) = r25
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		r2 = memw(r29+#232)
		memw(r29+#528) = r25
	}                                       // 4-byte Folded Reload
	{
		p0 = not(p0)
		r2 = add(r2,#1)
		r0 = memw(r29+#372)
		memw(r29+#468) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = p0
		r0 = memw(r29+#220)
		memw(r29+#496) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#460)
		memw(r29+#572) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#480)
		memw(r29+#484) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#440)
		memw(r29+#232) = r2
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#420)
		memw(r29+#516) = r1
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_347
		memw(r29+#540) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_517:                             // %for.body2623.lr.ph
                                        //   in Loop: Header=BB12_347 Depth=1
	{
		r6 = memw(r29+#452)
		r3 = memw(r29+#1704)
	}                                       // 4-byte Folded Reload
	{
		r9 = memw(r29+#484)
		r8 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r2 = +mpyi(r6,#1)
		r5 = asl(r9,#2)
		r0 = memw(r29+#516)
		r4 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r4,#2)
		r4 = asl(r8,#8)
		p3 = cmp.eq(r0,#0)
		r7 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r7,#0)
		r1 = memw(r29+#324)
		r7 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		p2 = r7
		p0 = not(p0)
		p1 = cmp.eq(r1,#0)
		r7 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p1)
		r1 = p3
		r15 = memw(r29+#588)
		memw(r29+#672) = r1.new
	}                                       // 4-byte Folded Reload
	{
		p1 = and(p1,and(p2,p0))
		p0 = and(p2,!p3)
		r1 = add(r7,r4)
		memw(r29+#676) = r3
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		r3 = add(r9,#3)
		r4 = add(r15,r4)
		memw(r29+#684) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p0
		r3 = lsr(r3,#2)
		memw(r29+#648) = r0
		memw(r29+#688) = r4
	}                                       // 4-byte Folded Spill
	{
		r1:0 = memd(r29+#1680)
		memw(r29+#640) = r0
	}                                       // 8-byte Folded Reload
	{
		r0 = memw(r29+#496)
		memw(r29+#656) = r3
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r17,#8)
		p2 = r0
		r0 = memw(r29+#272)
		memw(r29+#644) = r5
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r0,r16,#2)
		if (!p2) r2 = add(r1,#0)
		r1 = memw(r29+#288)
		r12 = memw(r29+#536)
	}                                       // 4-byte Folded Reload
	{
		r4 = addasl(r1,r16,#2)
		r12 += mpyi(r8,r6)
		r1 = #4
		r0 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r2)
		r0 = add(r7,r5)
		memw(r29+#540) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = maxu(r9,r1)
		r1 = add(r15,r5)
		r0 = memw(r29+#572)
		memw(r29+#660) = r0
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r0,#2)
		r1 = memw(r29+#208)
		memw(r29+#664) = r1
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r4,r0,#2)
		r0 = memw(r29+#276)
		memw(r29+#692) = r2
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#680) = r12
		memw(r29+#668) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#572) = r2
		memw(r29+#464) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#516) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_518:                             // %for.body2623
                                        //   Parent Loop BB12_347 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_586 Depth 3
                                        //         Child Loop BB12_595 Depth 4
                                        //         Child Loop BB12_591 Depth 4
	{
		r17 = memw(r29+#504)
		r16 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.519:                             // %for.body2623
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		p2 = cmp.gtu(r16,r17)
		r1 = add(r29,#2072)
		r21 = r0
		r2 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r0,#5)
		p0 = r2
		memw(r29+#196) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p3 = or(p0,p2)
		if (p3.new) jump:t .LBB12_527
		if (!p3.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.520:                             // %do.body2642
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_523
	}
// %bb.521:                             // %if.then2644
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.522:                             // %if.then2644
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_523:                             // %do.end2648
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		call hvx_worker_pool_wait_bg
		r2 = #-1
		r0 = memw(r29+#368)
		r1 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.524:                             // %do.end2648
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_527
	}
// %bb.525:                             // %if.then2652
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.526:                             // %if.then2652
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_527:                             // %if.end2659
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#276)
		r0 = memw(r29+#640)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r2 = sub(r2,r27)
		if (p3.new) r16 = add(r20,#8)
		r3 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r3)
		if (!p3) jump:nt .LBB12_537
		memw(r29+#532) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.528:                             // %land.lhs.true2670
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r17 = add(r29,#1752)
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r17+r16<<#2)
	}
	{
		p2 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p2) jump:nt .LBB12_539
		r2 = memw(r3+#0)
	}
// %bb.529:                             // %do.body2675
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_532
	}
// %bb.530:                             // %if.then2677
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.531:                             // %if.then2677
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_532:                             // %do.end2681
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r16,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.533:                             // %do.end2681
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_536
	}
// %bb.534:                             // %if.then2686
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.535:                             // %if.then2686
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_536:                             // %do.end2692
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = addasl(r17,r16,#2)
	}
	{
		jump .LBB12_550
		memw(r2+#0) = #0
	}
	.falign
.LBB12_537:                             // %if.else2695
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#672)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_550
		if (!p0.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.538:                             // %if.else2695.do.body2699_crit_edge
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_539:                             // %do.body2699
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r0 = add(r29,#2008)
		p1 = cmp.eq(r2,#0)
	}
	{
		r16 = addasl(r0,r20,#2)
		if (p1) jump:nt .LBB12_543
	}
// %bb.540:                             // %do.end2705
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.541:                             // %do.end2705
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1712) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_543
	}
// %bb.542:                             // %if.then2707
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #2
		r2 = memw(r16+#0)
	}
	.falign
.LBB12_543:                             // %if.end2710
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r16+#0)
	}
	.falign
// %bb.544:                             // %if.end2710
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_549
	}
// %bb.545:                             // %do.body2716
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.546:                             // %do.body2716
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_549
	}
// %bb.547:                             // %if.then2718
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.548:                             // %if.then2718
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_549:                             // %do.end2724
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#368)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#532)
		memw(r29+#4) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1688)
		memw(r29+#0) = r27
	}                                       // 8-byte Folded Reload
	{
		r2 = r3
		r3 = r25
		r1 = memw(r29+#208)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
		r4 = memw(r29+#284)
		r5 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_550:                             // %do.body2728
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_553
	}
// %bb.551:                             // %if.then2730
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.552:                             // %if.then2730
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_553:                             // %do.end2734
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r17 = #0
		r0 = memw(r29+#492)
		r16 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r0,r21)
		r2 = memw(r29+#276)
		if (!cmp.eq(r2.new,r27)) jump:t ##.LBB12_585
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_554:                             // %do.body2824
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_557
	}
// %bb.555:                             // %if.then2826
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.556:                             // %if.then2826
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_557:                             // %do.end2837
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#576)
		r0 = memw(r29+#648)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		p3 = cmp.gtu(r2,r20)
	}
	{
		p0 = and(p2,p3)
		if (!p0.new) jump:t .LBB12_567
		if (p0.new) r3 = memw(r29+##1696)
	}                                       // 4-byte Folded Reload
// %bb.558:                             // %if.then2847
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#256)
		r0 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r2+r3<<#2)
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_561
	}
// %bb.559:                             // %if.then2865
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.560:                             // %if.then2865
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_561:                             // %do.end2869
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r20<<#2)
	}
	.falign
// %bb.562:                             // %do.end2869
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_565
	}
// %bb.563:                             // %if.then2873
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.564:                             // %if.then2873
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_565:                             // %do.end2879
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = add(r29,#5632)
		r4 = add(r29,#2712)
		r8 = memw(r29+#544)
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r20,#192)
		r6 = add(r29,#2328)
		r7 = memw(r29+#292)
		memw(r29+#12) = r5
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r20,r8)
		r5 = memw(r29+#244)
		r9 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r5 += mpyi(r17,#96)
		r0 = add(r3,r9)
		r1 = memw(r29+#400)
		memw(r29+#8) = r7
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r20,#5)
		r7 = sub(r9,r3)
		memw(r29+#0) = r1
		memw(r29+#20) = r0
	}
	{
		r3 = addasl(r6,r20,#3)
		r6 = minu(r7,r8)
		memw(r29+#16) = r3
		memw(r29+#4) = r5
	}
	{
		r0 = memw(r29+#368)
		memw(r29+#24) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_submit
		r4 = memw(r29+#268)
		r5 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.566:                             // %do.end2879
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r20<<#2) = r3
	}
	.falign
.LBB12_567:                             // %if.end2887
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r19 = add(r29,#8704)
		r1 = #880
		p2 = cmp.eq(r20,#0)
		r0 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r19 += mpyi(r21,r1)
		p0 = r0
	}
	{
		r2 = p2
		if (p0) jump:nt .LBB12_578
		memw(r29+#568) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.568:                             // %if.end2887
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#568)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:nt .LBB12_578
		if (p3.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.569:                             // %do.body2893
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_572
	}
// %bb.570:                             // %if.then2895
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.571:                             // %if.then2895
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_572:                             // %do.end2899
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.573:                             // %do.end2899
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_576
	}
// %bb.574:                             // %if.then2902
                                        //   in Loop: Header=BB12_518 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.575:                             // %if.then2902
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_576:                             // %do.end2908
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = add(r29,#3872)
		r6 = #880
		r3 = memw(r29+#600)
		r4 = memw(r29+#500)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r5 = memw(r29+#220)
		r7 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r5,r4)
		r5 = memw(r29+#684)
		r4 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r7,r6)
		r6 = memw(r29+#680)
		r7 = memw(r29+#688)
	}                                       // 4-byte Folded Reload
	{
		r3 = mux(p0,r19,r2)
		r7:6 = combine(r6,r7)
	}
	{
		memd(r3+#856) = r1:0
		memd(r3+#864) = r5:4
	}
	{
		if (!p0) r3 = #4
		if (p0) jump:nt .LBB12_578
		memw(r3+#12) = #0
		memd(r3+#872) = r7:6
	}
// %bb.577:                             // %if.then2937
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
	}
	.falign
.LBB12_578:                             // %if.end2939
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r17 = add(r29,#8704)
		r3 = #880
		r2 = memw(r25+#20)
		r0 = memw(r29+#616)
	}                                       // 4-byte Folded Reload
	{
		r17 += mpyi(r21,r3)
		r1:0 = combine(r2,r0)
		p1 = cmp.eq(r2,#0)
	}
	{
		if (!p1) r1 = add(r29,##2456)
		if (p1) jump:nt .LBB12_580
		memd(r17+#544) = r1:0
	}
// %bb.579:                             // %if.then2948
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		call memcpy
		r0 = add(r17,#552)
		r2 = memw(r29+#644)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_580:                             // %if.end2954
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r18 = add(r17,#32)
		r4 = memw(r29+#520)
		r5 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r5,r27)
		r2 = memw(r29+#268)
		r6 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r16)
		r3 = memw(r4+#8)
		memd(r17+#8) = r1:0

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		r0 = memw(r29+#484)
		memw(r17+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#644)
		memw(r19+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r4+#12)
		r1 = memw(r29+#660)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r0,r2)
		r0 = r18
		r2 = r16
	}
	{
		call memcpy
		memd(r17+#16) = r5:4
	}
	.falign
// %bb.581:                             // %if.end2954
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r24 = add(r17,#288)
		r2 = r16
		r1 = memw(r29+#664)
	}                                       // 4-byte Folded Reload
	{
		call memcpy
		r0 = r24
	}
	.falign
// %bb.582:                             // %if.end2954
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r1:0 = combine(r24,r18)
		r3:2 = memd(r25+#8)
	}
	{
		r3:2 = combine(r2,r3)
		r0 = r27
		r1 = memw(r29+#280)
		memd(r17+#24) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r25+#16)
		memd(r17+#808) = r3:2
	}
	{
		r2 = memw(r29+#552)
		memw(r17+#816) = r2
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		memw(r17+#820) = r2
	}
	.falign
// %bb.583:                             // %if.end2954
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r5:4 = memd(r29+#1672)
		r2 = memw(r29+#560)
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#668)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r0,r4)
	}
	{
		r1:0 = combine(r3,r2)
		r2 = memw(r29+#264)
		r3 = memw(r29+#572)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		r0 = memw(r29+#580)
		memd(r17+#824) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		if (p2.new) jump:nt .LBB12_610
		memd(r17+#832) = r3:2
	}
// %bb.584:                             // %if.then2997
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r2 = memw(r29+#676)
		r4 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#188)
		r5 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		r6 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r2,#2)
		r2 = addasl(r6,r2,#2)
		r4 = memw(r3+r4<<#2)
		r3 = memw(r22+#28)
	}
	{
		r6 = sub(r4,r3)
		r4 = memw(r22+#24)
	}
	{
		r5 = addasl(r5,r6,#2)
		r6 = addasl(r2,r6,#2)
		jump .LBB12_611
	}
	.falign
.LBB12_585:                             //   in Loop: Header=BB12_518 Depth=2
	{
		r0 = #1
		r2 = memw(r29+#280)
		r3 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r3,r2)
		r18 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r23 = maxu(r2,r0)
	}
	.falign
.LBB12_586:                             // %for.body2740
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_518 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_595 Depth 4
                                        //         Child Loop BB12_591 Depth 4
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.587:                             // %for.body2740
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r2 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r26 = add(r18,#0)
		if (!p1.new) jump:t .LBB12_594
		if (!p1.new) r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
// %bb.588:                             // %if.then2742
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r4 = add(r17,r27)
		r2 = memw(r29+#252)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_598
	}                                       // 4-byte Folded Reload
// %bb.589:                             // %for.body2759.preheader
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r3 = memw(r29+#284)
		r2 = memw(r29+#612)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r4,#9)
		r5 = lsr(r3,#1)
		r3 = and(r3,#1)
		r4 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r5,#0)
		if (!p2.new) jump:t .LBB12_592
	}
// %bb.590:                             //   in Loop: Header=BB12_586 Depth=3
	{
		loop0(.LBB12_591,r5)
	}
	.falign
.LBB12_591:                             //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_518 Depth=2
                                        //       Parent Loop BB12_586 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7 = #31
		r8 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r5 = add(r4,#2048)
		r6 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r6)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r4 = add(r4,#4096)
		r2 = add(r2,r6)
	} :endloop0
	.falign
.LBB12_592:                             //   in Loop: Header=BB12_586 Depth=3
	{
		r5 = #384
		p3 = cmp.gtu(r3,#0)
		if (p3.new) r3 = #31
		if (!p3.new) jump:t .LBB12_598
	}
	.falign
.LBB12_593:                             // Block address taken
                                        // %for.body2759
                                        //   in Loop: Header=BB12_586 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r3):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	{
		jump .LBB12_598
	}
	.falign
.LBB12_594:                             // %for.cond2769.preheader
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		p0 = cmp.gtu(r2,#31)
		r0 = memw(r29+#268)
		r19 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) jump:nt .LBB12_598
		r24 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_595:                             // %for.body2773
                                        //   Parent Loop BB12_347 Depth=1
                                        //     Parent Loop BB12_518 Depth=2
                                        //       Parent Loop BB12_586 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r24
		r2 = r26
	}
	.falign
// %bb.596:                             // %for.body2773
                                        //   in Loop: Header=BB12_595 Depth=4
	{
		r24 = add(r24,#2048)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB12_653
	}
// %bb.597:                             // %for.cond2769
                                        //   in Loop: Header=BB12_595 Depth=4
	{
		r2 = memw(r29+#448)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r26 = add(r26,r2)
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB12_595
	}
	.falign
.LBB12_598:                             // %do.body2796
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_601
	}
// %bb.599:                             // %if.then2798
                                        //   in Loop: Header=BB12_586 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.600:                             // %if.then2798
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_601:                             // %do.end2802
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r19 = #0
		r2 = r16
		r3 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r3,#0)
		r3 = memw(r29+#388)
		if (!p3.new) r1:0 = memd(r29+##1680)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r17,r3)
		if (p3) jump:nt .LBB12_603
		if (!p3) r3 = memw(r29+##268)
	}                                       // 4-byte Folded Reload
// %bb.602:                             // %if.then.i5524
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r2 = add(r3,r2)
		r6 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_605
		v1 = vmem(r2+#0)
	}
	.falign
.LBB12_603:                             // %if.end.i5532
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#268)
		r1 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.604:                             // %if.end.i5532
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r19 = r0
	}
	.falign
.LBB12_605:                             // %moe_acc_read.exit5534
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_608
	}
// %bb.606:                             // %if.then2808
                                        //   in Loop: Header=BB12_586 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.607:                             // %if.then2808
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_608:                             // %do.end2814
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r18 = add(r18,#512)
		r0 = r19
		p1 = cmp.eq(r19,#0); if (!p1.new) jump:nt .LBB12_653
	}
// %bb.609:                             // %for.cond2736
                                        //   in Loop: Header=BB12_586 Depth=3
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r23)) jump:t .LBB12_586
	}
	{
		jump .LBB12_554
	}
	.falign
.LBB12_610:                             //   in Loop: Header=BB12_518 Depth=2
	{
		r5:4 = combine(#0,#0)
		r3 = #0
		r6 = #0
	}
	.falign
.LBB12_611:                             // %if.end3017
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r1:0 = combine(r5,r4)
		r5:4 = combine(r3,r6)
		r3 = add(r29,#2072)
		r7 = memw(r29+#568)
	}                                       // 4-byte Folded Reload
	{
		p0 = r7
		r0 = add(r29,#2200)
		r2 = memw(r29+#500)
		memd(r17+#840) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_dn_unit@PCREL)
		r6 = addasl(r0,r21,#5)
		r8 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r21,#5)
		if (!p0) r2 = #0
		r0 = memw(r29+#600)
		r7 = memw(r29+#656)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r1:0 = combine(r6,r7)
		r6 = memw(r29+#1720)
		memw(r8+#0) = r1
	}                                       // 4-byte Folded Reload
	{
		r4 = setbit(r3,#2)
		p1 = r6
		if (!p2) r2 = #0
		memd(r17+#848) = r5:4
	}
	{
		if (p1) r2 = #0
		r3 = memw(r29+#488)
		memd(r3+#8) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		if (!p2.new) jump:t .LBB12_614
		memw(r17+#856) = r2
		memw(r4+#0) = r19
	}
// %bb.612:                             // %if.then3041
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r1 = add(pc,##moe_dn_fg_worker@PCREL)
		p2 = cmp.eq(r2,#0)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#484)
		r4 = memw(r29+#692)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r3 = add(r2,#0)
		r2 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		if (!p2) r3 = add(r4,#0)
	}
	.falign
// %bb.613:                             // %if.then3041
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		jump .LBB12_616
	}
	.falign
.LBB12_614:                             // %if.else3053
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r16 = memw(r29+#196)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit_bg
		r1 = r16
	}
	.falign
// %bb.615:                             // %if.else3053
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		memw(r29+#524) = r16
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_616:                             // %for.inc3061
                                        //   in Loop: Header=BB12_518 Depth=2
	{
		r20 = add(r20,#1)
		r3 = memw(r29+#280)
		r2 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r27,r3)
		r1 = memw(r29+#504)
		r0 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,r27)
		r2 = add(r1,#1)
		r1 = memw(r29+#620)
		memw(r29+#504) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r0,r3)
		r0 = memw(r29+#464)
		memw(r29+#516) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		if (p2) jump:nt .LBB12_518
		memw(r29+#464) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_510
	}
	.falign
.LBB12_617:                             // %cleanup2496
	{
		r22 = r0 ; jump .LBB12_654
	}
	.falign
.LBB12_618:                             // %if.else1048
	{
		r2 = memw(r29+#1680)
		memd(r29+#1720) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_310
		if (p2.new) r19 = memw(r29+##292)
	}                                       // 4-byte Folded Reload
// %bb.619:                             // %for.cond1052.preheader
	{
		r2 = #2
		r16 = add(r29,#1880)
		r18 = #0
		r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r20 = minu(r3,r2)
		r23 = memw(r29+#256)
		r17 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r21 = memw(r29+#296)
		memd(r29+#1720) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_620:                             // %for.body1061
                                        // =>This Inner Loop Header: Depth=1
	{
		p0 = tstbit(r18,#0)
		r3 = r19
		r2 = memw(r17+#0)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p0,r25,#0)
		r5:4 = combine(#1,r21)
		r17 = add(r17,#4)
	}
	{
		r6 = memw(r23+r2<<#2)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#0) = r18
	}
	{
		r2 += mpyi(r6,#96)
		call moe_m1_push
	}
	.falign
// %bb.621:                             // %for.body1061
                                        //   in Loop: Header=BB12_620 Depth=1
	{
		r16 = add(r16,#4)
		r18 = add(r18,#1)
		r20 = add(r20,#-1)
		memw(r16+#0) = r0
	}
	{
		p0 = cmp.eq(r20,#0); if (!p0.new) jump:t .LBB12_620
	}
	{
		jump .LBB12_310
	}
	.falign
.LBB12_622:                             // %if.else1243.peel
	{
		r2 = memw(r29+#548)
		r5 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		r20 = memw(r29+#428)
		r0 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+#0)
		r2 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r16,#2)
		r4 = memw(r29+#248)
		r3 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r16,#2)
		r2 = #0
		r18 = memw(r2+#0)
		r3 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r20 += mpyi(r16,r4)
		r6 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r6,r16,#2)
		r3 = memw(r3+r18<<#2)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		call hvx_quant_pack_u8_ah_rows
		memw(r29+#4) = r20
	}
	.falign
.LBB12_623:                             // %if.end1253.peel
	{
		r2 = memw(r29+#232)
		memw(r29+##8704) = r20
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r2,#8236)
		r2 = memw(r29+#256)
		memw(r29+#200) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#244)
		r6 = memw(r6+#0)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r6,#0)
		r2 = r4
		r5 = memw(r29+#240)
		r3 = memw(r2+r18<<#2)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r3,#96)
		r5 = memw(r5+r18<<#2)
		memw(r29+##8708) = r2.new
	}
	{
		r4 += mpyi(r5,#96)
		if (p3) jump:nt .LBB12_627
		memw(r29+##8712) = r4.new
	}
// %bb.624:                             // %land.lhs.true1265.peel
	{
		r19 = add(r29,#8704)
		r3 = memw(r2+#44)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_627
	}
// %bb.625:                             // %if.then1269.peel
	{
		r0 = add(r2,#88)
		r1 = add(r19,#128)
	}
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.626:                             // %if.then1269.peel
	{
		r1 = add(r19,#256)
		r2 = memw(r29+##8712)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
.LBB12_627:                             // %if.end1278.peel
	{
		r3 = memw(r29+#1680)
		r5 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		r4 = r5
		r6 = memw(r29+#188)
		r7 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+##8708)
		if (!p3) r3 = memw(r29+##8712)
	}
	{
		r1 = memw(r6+r18<<#2)
		r6 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r16,#2)
		if (!p3) r5 = memw(r3+#4)
		r3 = memw(r29+#528)
	}                                       // 4-byte Folded Reload
	{
		r12 = memw(r29+#620)
		r8 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r12,r3)
		if (!p3) r4 = memw(r2+#4)
		memw(r29+##8724) = r6

	} :mem_noshuf
	{
		r7 = add(r3,r7)
		r6 = memw(r29+#524)
		memw(r29+##8740) = r7.new
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r7,r6)
		r7 = memw(r29+#1672)
		r15:14 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r6,r8)
		memw(r29+##8744) = r6
	}
	{
		r7 = memw(r7+#0)
		memw(r29+##8736) = r3
	}
	{
		r7 = add(r7,r14)
		r3 = memw(r29+#404)
		memw(r29+##9092) = r1
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r16,#2)
		r7 = add(r6,#256)
		memw(r29+##9088) = r7
	}
	{
		memw(r29+##8748) = r6
		memw(r29+##8728) = r3
	}
	{
		r6 = add(r7,#256)
		memw(r29+##8752) = r7
	}
	{
		memw(r29+##8732) = r12
		memw(r29+##8756) = r6
	}
	{
		r2 = memw(r2+#20)
		memw(r29+##8716) = r4
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB12_629
		memw(r29+##8720) = r5
	}
// %bb.628:                             // %if.then1324.peel
	{
		r4 = add(r29,#8760)
		r0 = memw(r29+##8704)
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_sums
	}
	.falign
.LBB12_629:                             // %if.end1329.peel
	{
		r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#1)
		if (!p2.new) r9 = add(r29,##8704)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = p2
		if (!p2) r23 = #1
		if (p2) jump:nt .LBB12_646
		memw(r29+#280) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.630:                             // %for.body1224.preheader
	{
		r26 = add(r9,#900)
		r3 = memw(r29+#276)
		r14 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#22,#0)
		r5 = add(r14,r14)
		r7 = memw(r29+#1744)
		r1:0 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r3 = asl(r3,#10)
		r7 = lsr(r7,#7)
		r10 = memw(r29+#524)
		r28 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r28 += mpyi(r7,r17)
		r7 = add(r5,r3)
		r6 = memw(r29+#476)
		r8 = memw(r29+#528)
	}                                       // 4-byte Folded Reload
	{
		r4 = extractu(r10,#24,#7)
		r25 = add(r6,r0)
		r12 = memw(r29+#236)
		r15 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r12 = asl(r12,#12)
		r6 = r10
		r8 = add(r14,r8)
		r22 = memw(r29+#632)
	}                                       // 4-byte Folded Reload
	{
		r10 += add(r5,r15)
		r13 = add(r7,r10)
		r11 = add(r22,#512)
		r5 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r8,r15)
		r4 = asl(r4,#8)
		r21 = add(r13,r11)
		r20 = add(r10,r11)
	}
	{
		r3 += add(r12,r14)
		r27 = add(r5,add(r28,##1028))
		r5 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r6,add(r5,##512))
		r7 = add(r7,r4)
		r18 = add(r6,r11)
	}
	{
		r22 += add(r3,r4)
		r17 = add(r7,r11)
		r6 = memw(r29+#1736)
		memw(r29+#208) = r5
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r27,r6)
	}
	.falign
.LBB12_631:                             // %for.body1224
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = memw(r27+#0)
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r3,r6,#2)
		r3 = memw(r29+#404)
		r16 = memw(r24+#0)
	}                                       // 4-byte Folded Reload
	{
		r8 = addasl(r3,r6,#2)
		r3 = memw(r29+#188)
		r19 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r9 = addasl(r3,r16,#2)
		r3 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:t .LBB12_634
		if (!p1.new) r2 = memw(r29+##540)
	}                                       // 4-byte Folded Reload
// %bb.632:                             // %if.else1243
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r18 = r27
		r27 = r25
		r4 = memw(r29+#248)
		memw(r29+#224) = r18
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r2,r6,#2)
		r2 = #0
		r19 = memw(r29+#428)
		r0 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r19 += mpyi(r6,r4)
		r25:24 = combine(r8,r20)
		r3 = memw(r9+#0)
		memw(r29+#220) = r24
	}                                       // 4-byte Folded Spill
	{
		r21:20 = combine(r9,r17)
		memw(r29+#216) = r21
		memw(r29+#0) = r8
	}                                       // 4-byte Folded Spill
	{
		call hvx_quant_pack_u8_ah_rows
		r17 = r5
		memw(r29+#4) = r19
	}
	.falign
// %bb.633:                             // %if.else1243
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r5 = r17
		r17 = r20
		r20 = r24
		r24 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		r9:8 = combine(r21,r25)
		r25 = r27
		r27 = r18
		r18 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r21 = memw(r29+#216)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_634:                             // %if.end1253
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r6 = r2
		r3 = memw(r29+#256)
		memw(r26+#-388) = r19
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r3+r16<<#2)
		r3 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r3 = r2
		r7 = memw(r3+r16<<#2)
	}
	{
		r3 += mpyi(r4,#96)
		r4 = memw(r29+#200)
		memw(r26+#-384) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r6 += mpyi(r7,#96)
		memw(r26+#-380) = r6.new
	}
	{
		r4 = memw(r4+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_639
	}
// %bb.635:                             // %land.lhs.true1265
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r19 = r9
		r1 = add(r26,#-260)
		r4 = memw(r3+#44)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB12_639
	}
// %bb.636:                             // %if.then1269
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r0 = add(r3,#88)
		r16 = r5
		memw(r29+#216) = r8
	}                                       // 4-byte Folded Spill
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.637:                             // %if.then1269
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r1 = add(r26,#-132)
		r2 = memw(r26+#-380)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
// %bb.638:                             // %if.then1269
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r5 = r16
		r9 = r19
		r8 = memw(r29+#216)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_639:                             // %if.end1278
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r3 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) jump:t .LBB12_641
		if (p1.new) r4 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
// %bb.640:                             // %cond.true1288
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		p0 = tstbit(r23,#0)
		r3 = asl(r23,#30)
		r6 = r4
		r7 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r12 = mux(p0,r4,#0)
		r4 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		if (!p0) r4 = #0
		r12 = add(r7,r12)
		r3 = memw(r26+#-384)
	}
	{
		r4 += add(r7,r6)
		jump .LBB12_642
	}
	.falign
.LBB12_641:                             // %cond.false1291
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r3 = memw(r26+#-384)
		r4 = memw(r26+#-380)
	}
	{
		r12 = memw(r3+#4)
		r4 = memw(r4+#4)
	}
	.falign
.LBB12_642:                             // %cond.end1294
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r7 = memw(r29+#440)
		memw(r26+#-376) = r12
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r18,r7)
		r6 = add(r20,r7)
		r12 = add(r22,r7)
		memw(r26+#-372) = r4
	}
	{
		r6 = add(r21,r7)
		r4 = add(r17,r7)
		memw(r26+#-356) = r6
		memw(r26+#-360) = r4
	}
	{
		r7 = add(r12,#512)
		memw(r26+#-352) = r6
		memw(r26+#-368) = r5
	}
	{
		r6 = add(r7,#256)
		memw(r26+#-340) = r6.new
	}
	{
		r7 = add(r7,#512)
		r6 = memw(r29+#1672)
		memw(r26+#-344) = r7
	}                                       // 4-byte Folded Reload
	{
		memw(r26+#-364) = r8
		memw(r26+#-348) = r4
	}
	{
		memw(r26+#-336) = r7
		r4 = memw(r6+#0)

	} :mem_noshuf
	{
		r4 = add(r4,r25)
		r1 = memw(r9+#0)
		memw(r26+#0) = r1.new
	}
	{
		memw(r26+#-4) = r4
	}
	{
		r4 = add(r26,#-332)
		r3 = memw(r3+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_645
	}
// %bb.643:                             // %if.then1324
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		call hexkl_wh_affine_sums
		r3 = r8
		r0 = memw(r26+#-388)
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.644:                             // %if.then1324
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_645:                             // %if.end1329
                                        //   in Loop: Header=BB12_631 Depth=1
	{
		r23 = add(r23,#1)
		r27 = add(r27,#4)
		r24 = add(r24,#4)
		r3 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		r25 = add(r25,r3)
		r26 = add(r26,#512)
		r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r3,r23)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r22,r3)
		r17 = add(r17,r3)
		r18 = add(r18,r3)
		r21 = add(r21,r3)
	}
	{
		r20 = add(r20,r3)
		if (!p1) jump:nt .LBB12_631
	}
	.falign
.LBB12_646:                             // %for.cond.cleanup1223
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_649
	}
// %bb.647:                             // %if.then1336
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.648:                             // %if.then1336
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_649:                             // %do.end1342
	{
		r2 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) r16 = #0
		if (p3.new) jump:nt .LBB12_672
	}
// %bb.650:                             // %if.then1344
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_666
	}
// %bb.651:                             // %if.then1348
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.652:                             // %if.then1348
	{
		r21:20 = combine(r1,r0)
		jump .LBB12_667
	}
	.falign
.LBB12_653:                             // %cleanup3065
	{
		r22 = r0
	}
	.falign
.LBB12_654:                             // %out3220
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.655:                             // %out3220
	{
		r2 = memw(r29+#524)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_812
	}                                       // 4-byte Folded Reload
// %bb.656:                             // %if.then3222
	{
		call hvx_worker_pool_wait_bg
		r2 = #-1
		r0 = memw(r29+#368)
		r1 = memw(r29+#524)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.657:                             // %if.then3222
	{
		jump .LBB12_812
	}
	.falign
.LBB12_659:
	{
		jump .LBB12_254
		r17 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_660:                             // %if.then1020
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r4 = #0
		memw(r29+#784) = r4.new
	}
	.falign
// %bb.661:                             // %if.then1020
	{
		r1 = #1
	}
	{
		jump .LBB12_310
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_662:                             // %if.then1232.peel
	{
		r3 = ##-1431655765
		r1 = memw(r29+#248)
		r4 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,#23)
		r20 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyu(r2,r3)
		r2 = #0
		r0 = r20
		r4 = memw(r4+#0)
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
// %bb.663:                             // %if.then1232.peel
	{
		r2 = memw(r29+#352)
		r3 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,r3)
		r2 = memw(r29+#380)
		if (!p1.new) r3 = memw(r29+##404)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r2+#0)
		r2 = memw(r29+#548)
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB12_623
		r16 = memw(r2+#0)
		if (!p1) r2 = memw(r29+##408)
	}                                       // 4-byte Folded Reload
// %bb.664:                             // %if.then1238.peel
	{
		r0 = memw(r29+#480)
		r1 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r16<<#2)
		r3 = memw(r3+r16<<#2)
	}
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		r4 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.665:                             // %if.then1238.peel
	{
		jump .LBB12_623
	}
	.falign
.LBB12_666:
	{
		r21:20 = combine(#0,#0)
	}
	.falign
.LBB12_667:                             // %do.end1352
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.668:                             // %do.end1352
	{
		r2 = memw(r29+#376)
		memw(r29+#768) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_672
	}
// %bb.669:                             // %do.body1362
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.670:                             // %do.body1362
	{
		r1:0 = sub(r1:0,r21:20)
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_672
	}
// %bb.671:                             // %if.then1364
	{
		r1 = #0
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#80)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_672:                             // %if.end1371
	{
		r1 = #0
		r6 = memw(r29+#192)
		r4 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r6,#1,#16)
		p1 = !tstbit(r6,#7)
		r2 = r6
		r5 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(##16320,lsr(r2,#2))
		p3 = !tstbit(r6,#6)
		r14 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		p2 = r4
		if (p1) r2 = #192
		if (p3) r3 = #1
		r6 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r2 = add(r1,#0)
		r4 = mux(p2,#1,#0)
		r5 = memw(r29+#212)
		memw(r14+#72) = r5
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r6,r5)
		r5 = memw(r29+#252)
		memd(r14+#32) = r3:2
	}                                       // 4-byte Folded Reload
	{
		r8 = memw(r29+#284)
		memd(r14+#0) = r7:6
	}                                       // 4-byte Folded Reload
	{
		r9:8 = combine(r8,r5)
		r5 = memw(r29+#296)
		memw(r14+#40) = r4
	}                                       // 4-byte Folded Reload
	{
		r12 = memw(r29+#416)
		memd(r14+#8) = r9:8
	}                                       // 4-byte Folded Reload
	{
		r13:12 = combine(r5,r12)
		r5 = memw(r29+#264)
		r6 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r5,r6)
		r2 = memw(r29+#376)
		memd(r14+#16) = r13:12
	}                                       // 4-byte Folded Reload
	{
		memd(r14+#24) = r7:6
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_675
	}
// %bb.673:                             // %if.then1406
	{
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = memw(r29+#376)
		if (p3.new) r0 = memw(r29+##776)
	}                                       // 4-byte Folded Reload
	{
		if (!p3) r0 = add(r1,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#232)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#232) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.674:                             // %if.then1406
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_675:                             // %do.end1410
	{
		r3 = add(r29,#8704)
		r0 = memw(r29+#1680)
		r2 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r18 = add(r3,#8260)
		r19 = add(r3,#8256)
		r4 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r2,r4)
		if (!p3) jump:nt .LBB12_695
		if (!p3) r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.676:                             // %if.else1415
	{
		r2 = memw(r29+#772)
		r3 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#8248)
		p0 = cmp.gtu(r2,#1); if (!p0.new) jump:t .LBB12_697
		memw(r29+#1672) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.677:                             // %if.then1428.peel
	{
		r1 = r22
		r0 = add(r29,#728)
		r21 = add(r29,#8704)
		r3 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (p3.new) jump:t .LBB12_680
		if (!p3.new) r2 = memw(r29+##9220)
	}
// %bb.678:                             // %if.then1431.peel
	{
		call moe_m1_q_post
		r4 = memw(r29+#296)
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.679:                             // %if.then1431.peel
	{
		r2 = memw(r29+#772)
	}
	.falign
.LBB12_680:                             // %if.end1440.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r3 = memw(r29+#416)
		memw(r18+#0) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r2,r3)
		r4 = add(r29,#8704)
		r2 = add(r29,#728)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(pc,##moe_m1_pair_worker@PCREL)
		memw(r19+#0) = #0
		memw(r29+#788) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r29+#784) = r17
	}
	.falign
// %bb.681:                             // %if.end1440.peel
	{
		r20 = #0
		r2 = memw(r29+##8708)
		memw(r29+#768) = r20.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_684
	}
// %bb.682:                             // %if.end1440.peel
	{
		r2 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_684
	}
// %bb.683:                             // %if.then1454.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_684:                             // %for.inc1456.peel
	{
		r2 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) r16 = #0
		if (p0.new) jump:t .LBB12_693
		if (!p0.new) r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.685:                             // %for.body1425.preheader
	{
		r20 = add(pc,##moe_m1_q_worker@PCREL)
		r27 = add(r21,#516)
		r1 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r21 = asl(r1,#1)
		r26 = add(r2,#-1)
		r25 = #0
	}
	{
		r0 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		memw(r29+#188) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_686:                             // %for.body1425
                                        // =>This Inner Loop Header: Depth=1
	{
		r23 = add(r29,#728)
		r24 = add(r29,#8704)
		r2 = r25
		r4 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r1:0 = combine(r24,r23)
		r3 = memw(r29+#268)
		r5 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.687:                             // %for.body1425
                                        //   in Loop: Header=BB12_686 Depth=1
	{
		r2 = add(r21,r16)
		r1 = r20
		r0 = memw(r29+#772)
		memw(r18+#0) = r2.new
	}
	{
		r2 = r23
		r4 = memw(r29+#416)
		memw(r29+#788) = r24
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r0,r4)
		r16 = add(r4,r16)
		r0 = memw(r29+#368)
		memw(r19+#0) = r16.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#784) = r17
	}
	.falign
// %bb.688:                             // %for.body1425
                                        //   in Loop: Header=BB12_686 Depth=1
	{
		r0 = #0
		r2 = memw(r27+#0)
		memw(r29+#768) = r0.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_691
	}
// %bb.689:                             // %for.body1425
                                        //   in Loop: Header=BB12_686 Depth=1
	{
		r2 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_691
	}
// %bb.690:                             // %if.then1454
                                        //   in Loop: Header=BB12_686 Depth=1
	{
		r2 = add(r29,#8704)
		r0 = memw(r29+#368)
		r1 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_691:                             // %for.inc1456
                                        //   in Loop: Header=BB12_686 Depth=1
	{
		r25 = add(r25,#1)
		r27 = add(r27,#512)
		r26 = add(r26,#-1)
		if (!cmp.eq(r26.new,#0)) jump:t .LBB12_686
	}
// %bb.692:                             // %for.cond.cleanup1424
	{
		r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r2,#-1)
	}
	{
		p1 = tstbit(r20,#0); if (p1.new) jump:t .LBB12_741
	}
	.falign
.LBB12_693:                             // %if.then1464
	{
		r0 = add(r29,#728)
		r1 = add(r29,#8704)
		r2 = r20
		r4 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r3 = memw(r29+#268)
		r5 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.694:                             // %if.then1464
	{
		jump .LBB12_741
	}
	.falign
.LBB12_695:                             // %if.then1412
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r2 = add(r29,#8704)
		r4 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#368)
		memw(r19+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r4)
		call hvx_worker_pool_run
		memw(r18+#0) = r3.new
	}
	.falign
// %bb.696:                             // %if.then1412
	{
		jump .LBB12_741
	}
	.falign
.LBB12_697:                             // %for.cond1469.preheader
	{
		r25 = #0
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_706
	}
// %bb.698:                             // %if.then1477.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.699:                             // %if.then1477.peel
	{
		r21:20 = combine(r1,r0)
		jump .LBB12_707
	}
	.falign
.LBB12_700:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB12_701:                             // %do.end1028
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r17 = #0
		r2 = add(r29,#728)
	}
	{
		r0 = memw(r29+#368)
		memw(r29+#784) = r17
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#788) = r17
	}
	.falign
// %bb.702:                             // %do.end1028
	{
		r1 = #0
		r2 = memw(r29+#376)
		memw(r29+#768) = r17
	}                                       // 4-byte Folded Reload
	{
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_313
	}
// %bb.703:                             // %do.body1039
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.704:                             // %do.body1039
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_313
	}
// %bb.705:                             // %if.then1041
	{
		r5 = #0
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r3,#10)
		r3 = #0
	}
	{
		r1:0 = memd(r2+#80)
		memd(r29+#1720) = r3:2
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		jump .LBB12_310
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_706:
	{
		r21:20 = combine(#0,#0)
	}
	.falign
.LBB12_707:                             // %do.end1481.peel
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r29+#1880)
	}
	.falign
// %bb.708:                             // %do.end1481.peel
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_712
	}
// %bb.709:                             // %do.body1495.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.710:                             // %do.body1495.peel
	{
		r1:0 = sub(r1:0,r21:20)
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_712
	}
// %bb.711:                             // %if.then1497.peel
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r24 = lsr(r3,#10)
	}
	{
		r1:0 = memd(r2+#80)
	}
	{
		r1:0 = add(r1:0,r25:24)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_712:                             // %if.end1504.peel
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r2 = add(r29,#8704)
		r3 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#368)
		memw(r19+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r18+#0) = r3
	}
	.falign
// %bb.713:                             // %if.end1504.peel
	{
		r2 = memw(r29+##8708)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_716
	}
// %bb.714:                             // %if.end1504.peel
	{
		r2 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_716
	}
// %bb.715:                             // %if.then1518.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_716:                             // %if.end1519.peel
	{
		r1 = #0
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,#2)) jump:t .LBB12_719
	}                                       // 4-byte Folded Reload
// %bb.717:                             // %if.then1523.peel
	{
		r1 = #0
		r2 = memw(r29+##9732)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r5 = #1
		r3 = memw(r29+#292)
		memw(r29+#0) = #2
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.718:                             // %if.then1523.peel
	{
		jump .LBB12_723
		memw(r29+#1888) = r0
	}
	.falign
.LBB12_719:                             // %for.inc1555.peel
	{
		r5 = #3
		r2 = memw(r29+##8712)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#268)
		memw(r29+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.720:                             // %for.inc1555.peel
	{
		r5 = #3
		r2 = memw(r29+#280)
		memw(r29+#1944) = r0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB12_741
		if (!p1.new) r2 = memw(r29+##9224)
	}
// %bb.721:                             // %if.then1547.1.peel
	{
		r1 = memw(r29+#384)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#284)
		memw(r29+#0) = #1
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.722:                             // %if.then1547.1.peel
	{
		memw(r29+#1948) = r0
	}
	.falign
.LBB12_723:                             // %for.body1473.preheader
	{
		r25:24 = combine(#2,#1)
		r2 = add(r29,#8704)
		r3 = add(r29,#1880)
		r4 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(pc,##moe_m1_pair_worker@PCREL)
		r23 = asl(r4,#1)
		r21 = #0
	}
	{
		r27 = add(r2,#1540)
		r17 = add(r3,#12)
	}
	{
		r0 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		memw(r29+#188) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_724:                             // %for.body1473
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_726
	}
// %bb.725:                             // %if.then1477
                                        //   in Loop: Header=BB12_724 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
.LBB12_726:                             // %do.end1481
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r17+#-8)
	}
	.falign
// %bb.727:                             // %do.end1481
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r1 = r20
		r2 = add(r29,#8704)
		r16 = memw(r29+#416)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r3 = r16
		r4 = add(r23,r21)
		r21 = add(r16,r21)
		memw(r18+#0) = r4.new
	}
	{
		call hvx_worker_pool_run
		memw(r19+#0) = r21
	}
	.falign
// %bb.728:                             // %do.end1481
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = memw(r27+#-1024)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_731
	}
// %bb.729:                             // %do.end1481
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_731
	}
// %bb.730:                             // %if.then1518
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = add(r29,#8704)
		r3 = r16
		r0 = memw(r29+#368)
		r1 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
	}
	.falign
.LBB12_731:                             // %if.end1519
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r3 = add(r24,#2)
	}
	{
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_734
	}                                       // 4-byte Folded Reload
// %bb.732:                             // %if.then1523
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		p0 = tstbit(r24,#0)
		r5 = #1
		r3 = memw(r29+#196)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p0,r3,#0)
		r0 = memw(r29+#268)
		r2 = memw(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r3 = memw(r29+#292)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.733:                             // %if.then1523
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		jump .LBB12_740
		memw(r17+#0) = r0
	}
	.falign
.LBB12_734:                             // %if.else1534
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r16 = and(r25,#2)
	}
	{
		p1 = cmp.eq(r16,#0)
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,r16)) jump:t .LBB12_737
	}                                       // 4-byte Folded Reload
// %bb.735:                             // %if.then1547
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = add(r29,#8704)
		r5 = #3
		r6 = memw(r29+#196)
		memw(r29+#0) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r16,#9)
		r1 = mux(p1,#0,r6)
		r0 = memw(r29+#268)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r2 = memw(r2+#0)
	}
	.falign
// %bb.736:                             // %if.then1547
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r16<<#2) = r0
	}
	.falign
.LBB12_737:                             // %for.inc1555
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r26 = setbit(r16,#0)
	}
	{
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,r26)) jump:t .LBB12_740
	}                                       // 4-byte Folded Reload
// %bb.738:                             // %if.then1547.1
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = add(r29,#8704)
		p2 = cmp.eq(r16,#0)
		r5 = memw(r29+#196)
		memw(r29+#0) = r26
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r26,#9)
		r6 = mux(p2,#0,r5)
		r7 = memw(r29+#384)
		r0 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r5 = #3
		r3 = memw(r29+#284)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r2 = memw(r2+#0)
	}
	.falign
// %bb.739:                             // %if.then1547.1
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r26<<#2) = r0
	}
	.falign
.LBB12_740:                             // %if.end1559
                                        //   in Loop: Header=BB12_724 Depth=1
	{
		r24 = add(r24,#1)
		r25 = add(r25,#2)
		r27 = add(r27,#512)
		r17 = add(r17,#4)
	}
	{
		r2 = memw(r29+#212)
		if (!cmp.eq(r2.new,r24)) jump:t .LBB12_724
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_741:                             // %do.body1566
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_746
	}
// %bb.742:                             // %do.body1575
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.743:                             // %do.body1575
	{
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_746
	}
// %bb.744:                             // %if.then1577
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.745:                             // %if.then1577
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_746:                             // %do.end1581
	{
		r2 = memw(r29+#768)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_749
	}
// %bb.747:                             // %if.then1585
	{
		r2 = add(pc,##moe_m1_requant_worker@PCREL)
		r0 = memw(r29+#368)
		r3 = memw(r29+#772)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r29,#8704)
		r2 = add(r29,#728)
		r5 = memw(r29+#212)
		memw(r29+#784) = r2
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r3 = maxu(r3,r5)
		memw(r29+#788) = r4
	}
	{
		call hvx_worker_pool_run
	}
	.falign
// %bb.748:                             // %if.then1585
	{
		r2 = #0 ; jump .LBB12_750
		memw(r29+#768) = r2.new
	}
	.falign
.LBB12_749:                             // %if.else1586
	{
		r1 = add(pc,##moe_m1_requant_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_750:                             // %do.body1588
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_755
	}
// %bb.751:                             // %do.body1597
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.752:                             // %do.body1597
	{
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_755
	}
// %bb.753:                             // %if.then1599
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.754:                             // %if.then1599
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_755:                             // %do.end1603
	{
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB12_774
		if (!p0.new) r3 = memw(r29+##276)
	}                                       // 4-byte Folded Reload
// %bb.756:                             // %if.else1610
	{
		r2 = memw(r29+#772)
	}
	{
		r2 = add(r29,#8704)
		p1 = cmp.gtu(r2,#1); if (!p1.new) jump:t .LBB12_776
	}
// %bb.757:                             // %land.lhs.true1623.peel
	{
		r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		p3 = tstbit(r2,#0)
		if (!p3.new) r1 = add(r22,#0)
		if (p3.new) jump:nt .LBB12_760
	}
// %bb.758:                             // %land.lhs.true1623.peel
	{
		r0 = add(r29,#728)
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,#2)) jump:nt .LBB12_760
	}                                       // 4-byte Folded Reload
// %bb.759:                             // %if.then1631.peel
	{
		r2 = memw(r29+##9736)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_760:                             // %if.end1654.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r5 = memw(r29+#276)
		r3 = memw(r29+#772)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r2 = add(r29,#728)
		r4 = add(r29,#8704)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(pc,##moe_m1_down_worker@PCREL)
		memw(r19+#0) = #0
		memw(r18+#0) = r5
	}
	{
		call hvx_worker_pool_run
		memw(r29+#788) = r4
		memw(r29+#784) = r20
	}
	.falign
// %bb.761:                             // %if.end1654.peel
	{
		r2 = #0
		r0 = memw(r29+#280)
		memw(r29+#768) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		if (p2.new) jump:t .LBB12_783
		if (!p2.new) r2 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.762:                             // %land.lhs.true1623.peel5951
	{
		r2 = and(r2,#1)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_765
	}
// %bb.763:                             // %land.lhs.true1623.peel5951
	{
		r0 = add(r29,#728)
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,#3)) jump:nt .LBB12_765
	}                                       // 4-byte Folded Reload
// %bb.764:                             // %if.then1631.peel5955
	{
		r2 = memw(r29+#384)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r22,r2)
		r2 = memw(r29+##10248)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
	}
	.falign
.LBB12_765:                             // %if.end1639.peel5959
	{
		r0 = add(r29,#728)
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,#4)) jump:t .LBB12_767
	}                                       // 4-byte Folded Reload
// %bb.766:                             // %if.then1646.peel5962
	{
		r2 = memw(r29+##10760)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r1 = memw(r29+#268)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_767:                             // %if.end1654.peel5969
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r5 = memw(r29+#276)
		r3 = memw(r29+#772)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r2 = add(r29,#728)
		r4 = add(r29,#8704)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r21 = asl(r5,#1)
		memw(r19+#0) = r5
		memw(r29+#788) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r18+#0) = r21
		memw(r29+#784) = r20
	}
	.falign
// %bb.768:                             // %if.end1654.peel5969
	{
		r22 = #0
		r2 = memw(r29+#212)
		memw(r29+#768) = r22.new
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#2)
		if (p2.new) jump:t .LBB12_783
		if (!p2.new) r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.769:                             // %for.body1620.preheader
	{
		r17 = add(pc,##moe_m1_q_worker@PCREL)
		r27:26 = combine(#0,#5)
		r2 = add(r29,#8704)
	}
	{
		r24 = add(r3,#-2)
		r23 = add(r2,#2568)
		r3 = memw(r29+#276)
		r16 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r25 = +mpyi(r3,#3)
	}
	.falign
.LBB12_770:                             // %for.body1620
                                        // =>This Inner Loop Header: Depth=1
	{
		r3 = asl(r26,#30)
		p2 = tstbit(r26,#0)
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,r26)) jump:t .LBB12_772
	}                                       // 4-byte Folded Reload
// %bb.771:                             // %if.then1646
                                        //   in Loop: Header=BB12_770 Depth=1
	{
		r0 = add(r29,#728)
		r6 = memw(r29+#196)
		r5 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		r4 = memw(r29+#384)
		r2 = memw(r23+#0)
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p2,r4,#0)
		r3 = memw(r29+#284)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r1 += add(r5,r6)
		call moe_m1_q_post
	}
	.falign
.LBB12_772:                             // %if.end1654
                                        //   in Loop: Header=BB12_770 Depth=1
	{
		r2 = add(r21,r27)
		r1 = r17
		r3 = memw(r29+#772)
		memw(r19+#0) = r2.new
	}
	{
		r3 = maxu(r3,r16)
		r2 = add(r25,r27)
		r0 = memw(r29+#368)
		memw(r18+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#728)
		r4 = add(r29,#8704)
		memw(r29+#788) = r4.new
	}
	{
		call hvx_worker_pool_run
		memw(r29+#784) = r20
	}
	.falign
// %bb.773:                             // %if.end1654
                                        //   in Loop: Header=BB12_770 Depth=1
	{
		r24 = add(r24,#-1)
		r27 = add(r27,r16)
		r26 = add(r26,#1)
		r23 = add(r23,#512)
	}
	{
		p1 = cmp.eq(r24,#0)
		if (!p1.new) jump:t .LBB12_770
		memw(r29+#768) = r22
	}
	{
		jump .LBB12_783
	}
	.falign
.LBB12_774:                             // %if.then1605
	{
		r1 = add(pc,##moe_m1_down_worker@PCREL)
		r2 = add(r29,#8704)
	}
	{
		r4 = memw(r29+#212)
		memw(r19+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r4,r3)
		call hvx_worker_pool_run
		memw(r18+#0) = r3.new
	}
	.falign
// %bb.775:                             // %if.then1605
	{
		jump .LBB12_783
	}
	.falign
.LBB12_776:                             // %for.cond1666.preheader
	{
		r17 = add(pc,##moe_m1_down_worker@PCREL)
		r3 = add(r29,#1944)
		r20 = add(r2,#2056)
	}
	{
		r24 = add(r3,#16)
		r21 = #0
		r23 = #0
	}
	.falign
.LBB12_777:                             // %for.body1670
                                        // =>This Inner Loop Header: Depth=1
	{
		call moe_m1_wait
		r1 = #2
		r0 = memw(r24+#-16)
	}
	.falign
// %bb.778:                             // %for.body1670
                                        //   in Loop: Header=BB12_777 Depth=1
	{
		r1 = r17
		r2 = add(r29,#8704)
		r0 = memw(r29+#368)
		memw(r19+#0) = r21
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r21 = add(r3,r21)
		memw(r18+#0) = r21.new
	}
	.falign
// %bb.779:                             // %for.body1670
                                        //   in Loop: Header=BB12_777 Depth=1
	{
		r3 = add(r23,#4)
	}
	{
		r2 = memw(r29+#212)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_782
	}                                       // 4-byte Folded Reload
// %bb.780:                             // %if.then1680
                                        //   in Loop: Header=BB12_777 Depth=1
	{
		p0 = tstbit(r23,#0)
		r4 = asl(r23,#30)
		r6 = memw(r29+#196)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r4,#31)
		r5 = #3
		r3 = memw(r29+#384)
		r2 = memw(r20+#0)
	}                                       // 4-byte Folded Reload
	{
		r7 = mux(p0,r3,#0)
		r0 = memw(r29+#268)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.781:                             // %if.then1680
                                        //   in Loop: Header=BB12_777 Depth=1
	{
		memw(r24+#0) = r0
	}
	.falign
.LBB12_782:                             // %for.inc1692
                                        //   in Loop: Header=BB12_777 Depth=1
	{
		r23 = add(r23,#1)
		r24 = add(r24,#4)
		r20 = add(r20,#512)
	}
	{
		r2 = memw(r29+#1720)
		if (!cmp.eq(r2.new,r23)) jump:t .LBB12_777
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_783:                             // %do.body1698
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_788
	}
// %bb.784:                             // %do.body1707
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.785:                             // %do.body1707
	{
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_788
	}
// %bb.786:                             // %if.then1709
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.787:                             // %if.then1709
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_788:                             // %do.end1713
	{
		r16 = #0
		r25 = memw(r29+#264)
		r2 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		r17 = asl(r25,#2)
		p1 = cmp.eq(r2,#0)
		r24 = memw(r29+#300)
		r22 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r2 = p1
		r26 = memw(r29+#552)
		memw(r29+#1672) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#1704)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_789:                             // %for.body1719
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_795 Depth 2
	{
		r27 = r2
		r18 = add(r29,#8704)
		r2 = memw(r2+#0)
		r3 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r21 = addasl(r3,r2,#2)
		r18 += asl(r16,#9)
		r3 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		if (!p2.new) r2 = add(r17,#0)
		if (p2.new) jump:t .LBB12_793
	}
// %bb.790:                             // %if.then1728
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		r3 = mpyi(r16,r25)
	}
	{
		r20 = addasl(r24,r3,#2)
	}
	{
		call memset
		r1:0 = combine(#0,r20)
	}
	.falign
// %bb.791:                             // %if.then1728
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		r0 = r20
		r3 = r25
		r1 = memw(r18+#52)
		r2 = memw(r21+#0)
	}
	{
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.792:                             // %if.then1728
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		jump .LBB12_797
	}
	.falign
.LBB12_793:                             // %for.cond1737.preheader
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		r23 = #0
		r20 = #0
		r3 = memw(r18+#388)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_797
	}
// %bb.794:                             // %for.body1742.lr.ph
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		r3 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r19 = addasl(r3,r2,#2)
	}
	.falign
.LBB12_795:                             // %for.body1742
                                        //   Parent Loop BB12_789 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = memw(r19++#4)
		r4 = memw(r18+#52)
	}
	{
		r1 = add(r4,r20)
		r2 = memw(r21++#4)
	}
	{
		r5 = mpyi(r3,r25)
		r3 = r25
	}
	{
		r0 = addasl(r26,r5,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.796:                             // %for.body1742
                                        //   in Loop: Header=BB12_795 Depth=2
	{
		r23 = add(r23,#1)
		r20 = add(r20,r17)
	}
	{
		r2 = memw(r18+#388)
		if (cmp.gtu(r2.new,r23)) jump:t .LBB12_795
	}
	.falign
.LBB12_797:                             // %cleanup1754
                                        //   in Loop: Header=BB12_789 Depth=1
	{
		r2 = add(r27,#4)
		r16 = add(r16,#1)
		if (!cmp.eq(r16.new,r22)) jump:t .LBB12_789
	}
// %bb.798:                             // %for.cond.cleanup1718
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_801
	}
// %bb.799:                             // %if.then1765
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.800:                             // %if.then1765
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_801:                             // %do.end1771
	{
		r2 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:t .LBB12_803
		if (p3.new) r2 = memw(r29+##376)
	}                                       // 4-byte Folded Reload
// %bb.802:                             // %if.then1773
	{
		r2 = memw(r29+#780)
		r22 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (p3.new) r22 = #0
	}
	{
		if (!p3) r22 = add(r2,##-32767)
		jump .LBB12_811
	}
	.falign
.LBB12_803:                             // %do.body1778
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_806
	}
// %bb.804:                             // %if.then1780
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.805:                             // %if.then1780
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_806:                             // %do.end1784
	{
		r3 = #0
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#300)
		r2 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r1 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.807:                             // %do.end1784
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_810
	}
// %bb.808:                             // %if.then1789
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.809:                             // %if.then1789
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_810:                             // %do.end1795
	{
		r2 = memw(r29+#780)
		r22 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (p1.new) r22 = #0
	}
	{
		if (!p1) r22 = add(r2,##-32767)
	}
	.falign
.LBB12_811:                             // %out3220.thread
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_812:                             // %for.body3229
	{
		r2 = memw(r29+#1752)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_814
	}
// %bb.813:                             // %if.then3232
	{
		call hvx_worker_pool_wait_bg
		r1 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_814:                             // %for.inc3235
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1756)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_816
	}
// %bb.815:                             // %if.then3232.1
	{
		r2 = #-1
		r1 = add(r3,#32)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_816:                             // %for.inc3235.1
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1760)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_818
	}
// %bb.817:                             // %if.then3232.2
	{
		r2 = #-1
		r1 = add(r3,#64)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_818:                             // %for.inc3235.2
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1764)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_820
	}
// %bb.819:                             // %if.then3232.3
	{
		r2 = #-1
		r1 = add(r3,#96)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_820:                             // %for.inc3235.3
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1768)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_822
	}
// %bb.821:                             // %if.then3232.4
	{
		r2 = #-1
		r1 = add(r3,#128)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_822:                             // %for.inc3235.4
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1772)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_824
	}
// %bb.823:                             // %if.then3232.5
	{
		r2 = #-1
		r1 = add(r3,#160)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_824:                             // %for.inc3235.5
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1776)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_826
	}
// %bb.825:                             // %if.then3232.6
	{
		r2 = #-1
		r1 = add(r3,#192)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_826:                             // %for.inc3235.6
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1780)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_828
	}
// %bb.827:                             // %if.then3232.7
	{
		r2 = #-1
		r1 = add(r3,#224)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_828:                             // %for.inc3235.7
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1784)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_830
	}
// %bb.829:                             // %if.then3232.8
	{
		r2 = #-1
		r1 = add(r3,#256)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_830:                             // %for.inc3235.8
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1788)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_832
	}
// %bb.831:                             // %if.then3232.9
	{
		r2 = #-1
		r1 = add(r3,#288)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_832:                             // %for.inc3235.9
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1792)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_834
	}
// %bb.833:                             // %if.then3232.10
	{
		r2 = #-1
		r1 = add(r3,#320)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_834:                             // %for.inc3235.10
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1796)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_836
	}
// %bb.835:                             // %if.then3232.11
	{
		r2 = #-1
		r1 = add(r3,#352)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_836:                             // %for.inc3235.11
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1800)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_838
	}
// %bb.837:                             // %if.then3232.12
	{
		r2 = #-1
		r1 = add(r3,#384)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_838:                             // %for.inc3235.12
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1804)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_840
	}
// %bb.839:                             // %if.then3232.13
	{
		r2 = #-1
		r1 = add(r3,#416)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_840:                             // %for.inc3235.13
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1808)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_842
	}
// %bb.841:                             // %if.then3232.14
	{
		r2 = #-1
		r1 = add(r3,#448)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_842:                             // %for.inc3235.14
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1812)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_844
	}
// %bb.843:                             // %if.then3232.15
	{
		r2 = #-1
		r1 = add(r3,#480)
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_844:                             // %for.inc3235.15
	{
		r16 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_853
	}
// %bb.845:                             // %if.then3240
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_finish
		r2 = add(r29,#2456)
	}
	.falign
// %bb.846:                             // %if.then3240
	{
		r21 = #0
		r20 = memw(r29+#2456)
		r16 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r20 = memw(r29+#2460)
		memd(r16+#144) = r21:20
	}
	{
		r20 = memw(r29+#2464)
		memd(r16+#152) = r21:20
	}
	{
		r20 = memw(r29+#2468)
		memd(r16+#160) = r21:20
	}
	{
		r20 = memw(r29+#2472)
		memd(r16+#200) = r21:20
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.847:                             // %if.then3240
	{
		r20 = memw(r29+#2476)
		memd(r16+#168) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.848:                             // %if.then3240
	{
		r20 = memw(r29+#2480)
		memd(r16+#176) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.849:                             // %if.then3240
	{
		r20 = memw(r29+#2484)
		memd(r16+#184) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.850:                             // %if.then3240
	{
		r20 = memw(r29+#2488)
		memd(r16+#192) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.851:                             // %if.then3240
	{
		r20 = memw(r29+#2492)
		memd(r16+#208) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r21,r20)
	}
	.falign
// %bb.852:                             // %if.then3240
	{
		memd(r16+#216) = r1:0
	}
	.falign
.LBB12_853:                             // %if.end3258
	{
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r2 = #1536
		if (!p0.new) jump:nt .LBB12_863
	}
// %bb.854:                             // %if.end3258
	{
		r3 = memw(r29+#252)
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB12_863
	}                                       // 4-byte Folded Reload
// %bb.855:                             // %if.end3258
	{
		r2 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB12_863
		if (p1.new) r2 = memw(r29+##364)
	}                                       // 4-byte Folded Reload
// %bb.856:                             // %if.end3258
	{
		p1 = r2
		p3 = cmp.eq(r22,#0)
		r0 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
	}
	{
		p0 = and(p0,and(p1,p3))
		if (!p0.new) jump:nt .LBB12_863
		if (p0.new) r2 = memw(r29+##328)
	}                                       // 4-byte Folded Reload
// %bb.857:                             // %if.end3258
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_863
		if (!p0.new) r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
// %bb.858:                             // %if.then3278
	{
		r16 = memw(r2+#0)
		r17 = memw(r2+#4)
	}
	{
		r0 = memw(r29+#368)
		r18 = memw(r2+#8)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_workers
		r19 = memw(r2+#12)
	}
	.falign
// %bb.859:                             // %if.then3278
	{
		r3 = #48
		r4 = add(r0,#1)
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		r5 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r4,r3)
		p1 = cmp.eq(r2,#0)
		r5 = sub(r18,r5)
		r3 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r16,r3)
		r4 = memw(r29+#308)
		r6 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r4 = sub(r17,r4)
		r6 = sub(r19,r6)
		if (p1) jump:nt .LBB12_862
		if (!p1) memw(r29+#0) = #1
	}
// %bb.860:                             // %if.else3305
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = memw(r29+#352)
		memw(r29+#20) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3 = #2048
		r0 = memw(r29+#212)
		memw(r29+#28) = r3
	}                                       // 4-byte Folded Reload
	{
		r0 = #1536
		r2 = #3635
		memw(r29+#16) = r0
		memw(r29+#24) = r2
	}
	{
		r0 = #3
		memw(r29+#8) = r0
		memw(r29+#12) = r3
	}
	{
		r3 = add(pc,##.L.str.1@PCREL)
		memw(r29+#4) = r3
		memw(r29+#40) = r6
	}
	{
		memw(r29+#36) = r5
		memw(r29+#32) = r4
	}
	{
		call HAP_debug_v2
	}
	.falign
// %bb.861:                             // %if.else3305
	{
		jump .LBB12_863
	}
	.falign
.LBB12_862:                             // %if.then3292
	{
		r2 = memw(r29+#352)
		memw(r29+#24) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#212)
		memw(r29+#20) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = #2048
		r2 = #1536
		memw(r29+#28) = r3
		memw(r29+#16) = r2
	}
	{
		memw(r29+#40) = r6
		memw(r29+#36) = r5
	}
	{
		memw(r29+#32) = r4
		memw(r29+#12) = r3
	}
	{
		memw(r29+#8) = r2
		memw(r29+#4) = r3
	}
	{
		call _HAP_debug_v2
		memw(r29+#0) = #1
	}
	.falign
.LBB12_863:                             // %cleanup3322
	{
		r4 = r22
	}
	.falign
.LBB12_864:                             // %cleanup3438
	{
		r0 = r4
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB12_865:                             // %do.body3127
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_868
	}
// %bb.866:                             // %if.then3129
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.867:                             // %if.then3129
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_868:                             // %do.end3133
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.869:                             // %do.end3133
	{
		r2 = memw(r29+#504)
		r0 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		p3 = cmp.eq(r2,#0)
	}
	{
		p0 = or(p1,p3)
		if (p0.new) jump:t .LBB12_872
		if (!p0.new) r2 = memw(r29+##504)
	}                                       // 4-byte Folded Reload
// %bb.870:                             // %if.then3138
	{
		r0 = add(r2,#-1)
		r1 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.871:                             // %if.then3138
	{
		r3 = add(r29,#2072)
		r2 = #-1
	}
	{
		r1 = addasl(r3,r0,#5)
		call hvx_worker_pool_wait_bg
		r0 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_872:                             // %if.end3143
	{
		r17 = #0
		r2 = memw(r29+#264)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_880
	}                                       // 4-byte Folded Reload
// %bb.873:                             // %for.body3170.lr.ph.preheader
	{
		r2 = memw(r29+#544)
		r3 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r2,#24,#0)
		r16 = asl(r3,#2)
	}
	{
		r20 = asl(r2,#8)
	}
	.falign
.LBB12_874:                             // %for.body3170.lr.ph
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_876 Depth 2
	{
		r18 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.875:                             // %for.body3170.lr.ph
                                        //   in Loop: Header=BB12_874 Depth=1
	{
		r2 = memw(r29+#276)
		r5:4 = memd(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r17)
		r23 = r4
		r21 = memw(r29+#560)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r18)
		r21 += mpyi(r0,r4)
		r18 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	{
		r19 = asl(r2,#7)
	}
	.falign
.LBB12_876:                             // %for.body3170
                                        //   Parent Loop BB12_874 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = memb(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB12_878
	}
// %bb.877:                             // %if.then3173
                                        //   in Loop: Header=BB12_876 Depth=2
	{
		call memset
		r2 = r19
		r1:0 = combine(#0,r18)
	}
	.falign
.LBB12_878:                             // %for.inc3181
                                        //   in Loop: Header=BB12_876 Depth=2
	{
		r21 = add(r21,#1)
		r18 = add(r18,r16)
		r23 = add(r23,#-1)
		if (!cmp.eq(r23.new,#0)) jump:t .LBB12_876
	}
// %bb.879:                             // %for.cond.cleanup3169
                                        //   in Loop: Header=BB12_874 Depth=1
	{
		r2 = memw(r29+#280)
		r1 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r17,r2)
		r0 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r1,r17)
		r2 = add(r0,r20)
		if (p3.new) jump:t .LBB12_874
		memw(r29+#552) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_880:                             // %for.cond.cleanup3148
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_885
	}
// %bb.881:                             // %do.body3199
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.882:                             // %do.body3199
	{
		r3 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_885
	}
// %bb.883:                             // %if.then3201
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.884:                             // %if.then3201
	{
		memd(r29+#1712) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_885:                             // %do.end3205
	{
		r2 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) r3 = #0
		if (p3.new) jump:t .LBB12_887
	}
// %bb.886:                             // %if.then3207
	{
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#300)
		r1 = memw(r29+#624)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_887:                             // %do.body3211
	{
		r22 = #0
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_654
	}
// %bb.888:                             // %if.then3213
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.889:                             // %if.then3213
	{
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB12_654
		memd(r2+#8) = r1:0
	}
.Lfunc_end12:
	.size	hexkl_mm_u8i4_moe_layer_run, .Lfunc_end12-hexkl_mm_u8i4_moe_layer_run
                                        // -- End function
	.falign
	.type	moe_all_4bit,@function          // -- Begin function moe_all_4bit
moe_all_4bit:                           // @moe_all_4bit
// %bb.0:                               // %entry
	{
		loop0(.LBB13_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB13_8
	}
	.falign
.LBB13_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB13_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (p0.new) jump:nt .LBB13_7
		if (!p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (cmp.eq(r6.new,#2)) jump:nt .LBB13_7
	}
	.falign
.LBB13_5:                               // %for.inc
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB13_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB13_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end13:
	.size	moe_all_4bit, .Lfunc_end13-moe_all_4bit
                                        // -- End function
	.falign
	.type	moe_all_2bit,@function          // -- Begin function moe_all_2bit
moe_all_2bit:                           // @moe_all_2bit
// %bb.0:                               // %entry
	{
		loop0(.LBB14_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB14_8
	}
	.falign
.LBB14_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB14_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (!p0.new) jump:nt .LBB14_7
		if (p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (!cmp.eq(r6.new,#2)) jump:nt .LBB14_7
	}
	.falign
.LBB14_5:                               // %for.inc
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB14_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB14_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end14:
	.size	moe_all_2bit, .Lfunc_end14-moe_all_2bit
                                        // -- End function
	.falign
	.type	htp_tl2_palette_magnitude,@function // -- Begin function htp_tl2_palette_magnitude
htp_tl2_palette_magnitude:              // @htp_tl2_palette_magnitude
// %bb.0:                               // %entry
	{
		r2 = memb(r0+#0)
	}
	{
		r2 = abs(r2)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_3
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#7); if (p1.new) jump:nt .LBB15_3
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_3:                               // %for.inc
	{
		r3 = memb(r0+#1)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_8
	}
// %bb.4:                               // %for.inc
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB15_6
	}
// %bb.5:                               // %for.inc
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_6:                               // %lor.lhs.false.1
	{
		if (p0) jump:nt .LBB15_9
	}
// %bb.7:                               // %lor.lhs.false.1
	{
		p0 = cmp.eq(r2,r3); if (!p0.new) jump:t .LBB15_20
	}
	{
		jump .LBB15_9
	}
	.falign
.LBB15_8:
	{
		r3 = r2
	}
	.falign
.LBB15_9:                               // %for.inc.1
	{
		r2 = memb(r0+#2)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_14
	}
// %bb.10:                              // %for.inc.1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB15_12
	}
// %bb.11:                              // %for.inc.1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_12:                              // %lor.lhs.false.2
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB15_15
	}
// %bb.13:                              // %lor.lhs.false.2
	{
		p1 = cmp.eq(r3,r2); if (!p1.new) jump:t .LBB15_20
	}
	{
		jump .LBB15_15
	}
	.falign
.LBB15_14:
	{
		r2 = r3
	}
	.falign
.LBB15_15:                              // %for.inc.2
	{
		r3 = memb(r0+#3)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_21
	}
// %bb.16:                              // %for.inc.2
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB15_18
	}
// %bb.17:                              // %for.inc.2
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB15_20
	}
	.falign
.LBB15_18:                              // %lor.lhs.false.3
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB15_22
	}
// %bb.19:                              // %lor.lhs.false.3
	{
		p0 = cmp.eq(r2,r3); if (p0.new) jump:nt .LBB15_22
	}
	.falign
.LBB15_20:                              // %cleanup21
	{
		r0 = #0
		jumpr r31
	}
	.falign
.LBB15_21:
	{
		r3 = r2
	}
	.falign
.LBB15_22:                              // %for.inc.3
	{
		r2 = #1
	}
	{
		r0 = maxu(r3,r2)
		jumpr r31
	}
.Lfunc_end15:
	.size	htp_tl2_palette_magnitude, .Lfunc_end15-htp_tl2_palette_magnitude
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_usable,@function  // -- Begin function hexkl_acc_i24_usable
hexkl_acc_i24_usable:                   // @hexkl_acc_i24_usable
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB16_3
		r0 = #0
		r4 = r0
	}
// %bb.1:                               // %land.lhs.true
	{
		r5 = memw(r3+#4)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB16_3
	}
// %bb.2:                               // %land.lhs.true2
	{
		r5 = memw(r3+#8)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB16_4
	}
	.falign
.LBB16_3:                               // %land.end
	{
		jumpr r31
	}
	.falign
.LBB16_4:                               // %land.lhs.true3
	{
		r3 = memw(r3+#12)
	}
	{
		p1 = cmp.eq(r3,#32)
		if (p1.new) r3 = add(r1,#-1)
		if (!p1.new) jump:t .LBB16_3
	}
// %bb.5:                               // %land.rhs
	{
		p0 = cmp.gtu(r2,#7)
		if (p0.new) jumpr:nt r31
	}
.LBB16_6:                               // %land.rhs
	{
		p1 = cmp.eq(r4,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB16_7:                               // %land.rhs
	{
		r5 = #-9
		if (cmp.gtu(r5.new,r3)) jump:nt .LBB16_3
	}
// %bb.8:                               // %if.end.i
	{
		r3 = #255
		r5 = sub(#0,r1)
		r6 = ##8388609
	}
	{
		r13:12 = mpyu(r4,r3)
		r7 = #0
		r8 = ##8388608
	}
	{
		r9 = #0
	}
	{
		r15:14 = mpyu(r12,r5)
		r11:10 = mpyu(r12,r2)
	}
	{
		r15 += mpyi(r5,r13)
		r11 += mpyi(r2,r13)
	}
	{
		p1 = cmp.gtu(r7:6,r15:14)
		p0 = cmp.gtu(r9:8,r11:10)
	}
	{
		p1 = and(p1,p0)
	}
	{
		r0 = mux(p1,#1,#0)
		jumpr r31
	}
.Lfunc_end16:
	.size	hexkl_acc_i24_usable, .Lfunc_end16-hexkl_acc_i24_usable
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_banks,@function   // -- Begin function hexkl_acc_i24_banks
hexkl_acc_i24_banks:                    // @hexkl_acc_i24_banks
// %bb.0:                               // %entry
	{
		r7 = #0
		if (!p0.new) r8 = add(r3,#0)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB17_8
	}
// %bb.1:                               // %entry
	{
		r9 = and(r2,#1)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB17_8
	}
// %bb.2:                               // %lor.lhs.false2
	{
		p0 = cmp.gtu(r2,#1); if (!p0.new) jump:nt .LBB17_8
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r15:14 = combine(#0,#0)
		r3 = r1
		r6 = r1
	}
	{
		r3 = or(r9,and(r3,##2047))
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB17_8
	}
// %bb.4:                               // %if.end
	{
		r3 = #24576
		r9 = #0
	}
	{
		r13:12 = mpyu(r2,r3)
	}
	{
		r13:12 = add(r13:12,r7:6)
	}
	{
		r9:8 = add(r13:12,r9:8)
	}
	{
		r11:10 = combine(#0,r9)
	}
	{
		p0 = cmp.eq(r11:10,r15:14)
		if (p0.new) r3 = add(r0,##-3072)
		if (!p0.new) jump:t .LBB17_8
	}
// %bb.5:                               // %lor.lhs.false15
	{
		p1 = cmp.gtu(r0,##3071)
		if (!p1.new) jump:nt .LBB17_8
	}
// %bb.6:                               // %lor.lhs.false15
	{
		r3 = insert(r14,#11,#0)
		if (cmp.gtu(r8,r3.new)) jump:nt .LBB17_8
	}
// %bb.7:                               // %if.end20
	{
		r6 += mpyi(r2,##12288)
		r7 = #1
		memw(r4+#0) = r6.new
	}
	{
		r0 = r7
		jumpr r31
		memw(r5+#0) = r12
	}
	.falign
.LBB17_8:                               // %return
	{
		r0 = r7
		jumpr r31
	}
.Lfunc_end17:
	.size	hexkl_acc_i24_banks, .Lfunc_end17-hexkl_acc_i24_banks
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_prepare,@function // -- Begin function hexkl_acc_i24_prepare
hexkl_acc_i24_prepare:                  // @hexkl_acc_i24_prepare
// %bb.0:                               // %entry
	{
		r3 = #16384
		r1 = add(r0,#1024)
		v0 = vxor(v0,v0)
		vmem(r0+#2) = v0.new
	}
	{
		v2 = vsplat(r3)
		r1 = add(r0,#1152)
		r2 = #24576
		vmem(r1+#0) = v2.new
	}
	{
		v1 = vsplat(r2)
		r1 = add(r0,#1280)
		r3 = add(r0,#1408)
		vmem(r1+#0) = v2
	}
	{
		r1 = add(r0,#1536)
		r2 = #8192
		vmem(r1+#0) = v0
	}
	{
		v3 = vsplat(r2)
		r1 = add(r0,#1792)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2304)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2560)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2048)
		vmem(r1+#0) = v0
	}
	{
		r3 = add(r0,#1664)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2176)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#1920)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2688)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#2432)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2816)
		vmem(r1+#0) = v0
	}
	{
		vmem(r0+#0) = v1
	}
	{
		vmem(r0+#3) = v0
	}
	{
		vmem(r0+#4) = v0
	}
	{
		vmem(r0+#1) = v1
	}
	{
		vmem(r0+#5) = v0
	}
	{
		vmem(r0+#6) = v0
	}
	{
		r0 = add(r0,#2944)
		vmem(r0+#7) = v0
	}
	{
		vmem(r3+#0) = v0
	}
	{
		vmem(r1+#0) = v0
	}
	{
		jumpr r31
		vmem(r0+#0) = v0
	}
.Lfunc_end18:
	.size	hexkl_acc_i24_prepare, .Lfunc_end18-hexkl_acc_i24_prepare
                                        // -- End function
	.falign
	.type	moe_push_gate_up_chunks,@function // -- Begin function moe_push_gate_up_chunks
moe_push_gate_up_chunks:                // @moe_push_gate_up_chunks
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#168)
	}                                       // 8-byte Folded Spill
	{
		r23 = memw(r29+#176)
		memd(r29+#136) = r23:22
	}
	{
		p1 = cmp.eq(r23,#0)
		memd(r29+#152) = r19:18
		memd(r29+#144) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#128) = r25:24
		memd(r29+#120) = r27:26
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#28) = r4
		memw(r29+#40) = r2
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB19_59
		if (!p1) r27 = memw(r29+#188)
		memw(r29+#36) = r1
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r3 = asl(r5,#9)
		r17:16 = combine(r3,#0)
		r25:24 = combine(#0,#0)
		r22 = memw(r29+#180)
	}
	{
		r3 = lsr(r3,#1)
		r21:20 = combine(#0,r23)
		r18 = r0
		memw(r29+#48) = r3
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#36)
		memw(r29+#68) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
		r1:0 = vaslw(r23:22,#9)
		r4 = add(r0,r2)
	}
	{
		r3 = #0
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r6 = memw(r29+#184)
		memd(r29+#96) = r3:2
	}
	{
		r2 = add(r2,r1)
		memw(r29+#44) = r4
		memw(r29+#24) = r6
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#88) = r1:0
		memw(r29+#72) = r2
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#56) = r18
		memw(r29+#20) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB19_2:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = minu(r22,r20)
		r5 = add(r23,r16)
		r3 = #0
		r2 = memw(r17+#44)
	}
	{
		r26 = minu(r5,r22)
		r3 = insert(r4,#23,#8)
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r3)
		if (!p0) r5:4 = combine(r26,r25)
		if (p0) jump:nt .LBB19_8
		memw(r29+#32) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.3:                               // %if.then.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = add(r29,#76)
		r0 = r18
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r6 = memw(r29+#24)
		memw(r29+#76) = #1
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		r2 = memw(r29+#40)
		memw(r29+#84) = r24
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_4:                               // %moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r4 = add(r23,r25)
		r2 = memw(r17+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_13
	}
// %bb.5:                               // %if.then.i30
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = add(r29,#76)
		r5 = r26
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r0 = r18
		r6 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#76) = #2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#40)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		memw(r29+#84) = r24
	}
	.falign
// %bb.6:                               // %if.then.i30
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
	}
	.falign
.LBB19_7:                               // %moe_push_weight_chunk.exit41
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r25 = add(r25,r22)
		r24 = add(r24,#1)
		r1:0 = memd(r29+#88)
		memw(r27++#4) = r26
	}                                       // 8-byte Folded Reload
	{
		p0 = cmp.gtu(r23,r25)
		r21 = add(r21,r0)
		r20 = sub(r20,r22)
		r16 = sub(r16,r22)
	}
	{
		if (p0) jump:nt .LBB19_2
	}
	{
		jump .LBB19_59
	}
	.falign
.LBB19_8:                               // %if.end.i48
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p1 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p0 = cmp.eq(r3,#0)
	}
	{
		r3 = p0
		if (!p1) jump:nt .LBB19_18
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.9:                               // %if.then3.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.10:                              // %if.then3.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_26
	}
// %bb.11:                              // %if.then12.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then12.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB19_27
		r5 = memw(r17+#4)
	}
	{
		jump .LBB19_29
	}
	.falign
.LBB19_13:                              // %if.end.i58
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p0 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		r3 = p1
		if (!p0) jump:nt .LBB19_22
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:                              // %if.then3.i90
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.15:                              // %if.then3.i90
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r19

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_32
	}
// %bb.16:                              // %if.then12.i95
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.17:                              // %if.then12.i95
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB19_33
		r3 = memw(r17+#4)
	}
	{
		jump .LBB19_35
	}
	.falign
.LBB19_18:                              // %if.end30.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.19:                              // %if.end30.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_38
	}
// %bb.20:                              // %if.then44.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.21:                              // %if.then44.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB19_39
		r2 = memw(r17+#4)
	}
	{
		jump .LBB19_41
	}
	.falign
.LBB19_22:                              // %if.end30.i61
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.23:                              // %if.end30.i61
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_48
	}
// %bb.24:                              // %if.then44.i64
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then44.i64
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB19_49
		r5 = memw(r17+#4)
	}
	{
		jump .LBB19_51
	}
	.falign
.LBB19_26:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB19_29
		r5 = memw(r17+#4)
	}
	.falign
.LBB19_27:                              // %land.rhs.i.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_29
	}
// %bb.28:                              // %lor.rhs.i.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_29:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r6 = lsr(r21,#1)
		r4 = r19
		r2 = memw(r29+#32)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r1 = add(r5,r6)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = memw(r29+#68)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.30:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.31:                              // %if.then24.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB19_44
	}
	.falign
.LBB19_32:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB19_35
		r3 = memw(r17+#4)
	}
	.falign
.LBB19_33:                              // %land.rhs.i.i110
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_35
	}
// %bb.34:                              // %lor.rhs.i.i120
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_35:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r0 = r21
		r5:4 = memd(r29+#88)
		memw(r29+#0) = r18
	}                                       // 8-byte Folded Reload
	{
		r2 = add(r5,r21)
		r6 = memw(r29+#32)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r2,#1)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r3,r4)
		r3 = memw(r29+#68)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r5)
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.36:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_58
	}
// %bb.37:                              // %if.then24.i116
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB19_54
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_38:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB19_41
		r2 = memw(r17+#4)
	}
	.falign
.LBB19_39:                              // %land.rhs.i105.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r3 = memw(r17+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB19_41
	}
// %bb.40:                              // %lor.rhs.i109.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r3,#0)
	}
	.falign
.LBB19_41:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r1 = add(r2,r21)
		r2 = memw(r29+#44)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = r2
		r4 = memw(r29+#52)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.42:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.43:                              // %if.then56.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB19_44:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.46:                              // %if.then6.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3 = #1
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r2 = memw(r29+#64)
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.47:                              // %if.then6.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_4
	}
	.falign
.LBB19_48:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r1:0 = combine(#0,#0)
	}
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB19_51
		r5 = memw(r17+#4)
	}
	.falign
.LBB19_49:                              // %land.rhs.i105.i77
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_51
	}
// %bb.50:                              // %lor.rhs.i109.i87
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_51:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r1:0 = combine(r21,r21)
		r2 = memw(r29+#48)
		r7:6 = memd(r29+#88)
	}                                       // 8-byte Folded Reload
	{
		r1 += add(r5,r7)
		r3 = r2
		r5 = memw(r29+#28)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#56)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#72)
		r4 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r18,r6)
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.52:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_7
	}
// %bb.53:                              // %if.then56.i83
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB19_54:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.55:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_7
	}
// %bb.56:                              // %if.then6.i38
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#2,r26)
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.57:                              // %if.then6.i38
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_7
	}
	.falign
.LBB19_58:                              //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_7
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_59:                              // %for.cond.cleanup
	{
		r17:16 = memd(r29+#160)
		r19:18 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#144)
		r23:22 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#128)
		r27:26 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end19:
	.size	moe_push_gate_up_chunks, .Lfunc_end19-moe_push_gate_up_chunks
                                        // -- End function
	.falign
	.type	moe_m1_q_post,@function         // -- Begin function moe_m1_q_post
moe_m1_q_post:                          // @moe_m1_q_post
// %bb.0:                               // %entry
	{
		r4 = asl(r4,#9)
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r5 = memw(r0+#40)
		r6 = memw(r16+#84)
	}
	{
		r6 = lsr(r4,#1)
		r7 = add(r5,#1)
		p1 = cmp.eq(r6,#2)
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		if (!p1) r6 = add(r4,#0)
		r7 = memw(r16+#44)
		r2 = memw(r2+#4)
	}
	{
		r17 = add(r0,r5)
		p0 = cmp.eq(r7,#0)
	}
	{
		memw(r17+#4) = r2
		memw(r17+#8) = r6
	}
	{
		if (p0) jump:nt .LBB20_3
		memw(r17+#12) = r3
		memw(r0+r5<<#0) = r1
	}
// %bb.1:                               // %if.then
	{
		r0 = memw(r16+#28)
		memw(r17+#8) = ##640
	}
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r16+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r3 = lsr(r2,#9)
		memw(r17+#12) = r3.new
	}
	.falign
.LBB20_3:                               // %if.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_6
	}
// %bb.4:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB20_7
	}
// %bb.5:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB20_7
	}
	.falign
.LBB20_6:
	{
		r2 = #0
	}
	.falign
.LBB20_7:                               // %moe_weight_src_bypass.exit
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r17+#16) = r2
	}
	{
		r2 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_9
	}
// %bb.8:                               // %if.then7
	{
		r1 = #0
		r2 = memw(r17+#8)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		r0 = lsr(r2,#10)
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB20_9:                               // %do.end
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end20:
	.size	moe_m1_q_post, .Lfunc_end20-moe_m1_q_post
                                        // -- End function
	.falign
	.type	moe_m1_push,@function           // -- Begin function moe_m1_push
moe_m1_push:                            // @moe_m1_push
// %bb.0:                               // %entry
	{
		r16 = r5
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		r2 = memw(r2+#44)
		memd(r29+#32) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r21:20
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p0) r17 = add(r3,#0)
		if (p0) jump:nt .LBB21_3
		if (p0) r0 = memw(r18+#84)
	}
// %bb.1:                               // %if.then
	{
		call hvx_tl2_weight_bytes
		r0 = memw(r18+#28)
		r1 = memw(r18+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
		r19 = #640
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r17 = lsr(r2,#9)
		jump .LBB21_4
	}
	.falign
.LBB21_3:                               // %cond.end3.thread
	{
		r2 = asl(r4,#9)
		p1 = cmp.eq(r0,#2)
	}
	{
		r19 = lsr(r2,#1)
	}
	{
		if (!p1) r19 = add(r2,#0)
	}
	.falign
.LBB21_4:                               // %if.end
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.5:                               // %if.end
	{
		r23 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r3 = mpyi(r17,r19)
		r22 = r0
	}
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_7
	}
// %bb.6:                               // %if.then10
	{
		r1 = #0
		r2 = memw(r23+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB21_7:                               // %do.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
		r1 = memw(r18+#4)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_10
	}
// %bb.8:                               // %land.rhs.i
	{
		r2 = memw(r18+#36)
	}
	{
		r2 = #1
		p0 = cmp.eq(r2,#0); if (!p0.new) jump:t .LBB21_11
	}
// %bb.9:                               // %lor.rhs.i
	{
		r2 = memw(r18+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB21_11
	}
	.falign
.LBB21_10:
	{
		r2 = #0
	}
	.falign
.LBB21_11:                              // %moe_weight_src_bypass.exit
	{
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
		r5:4 = combine(r17,r19)
		memw(r29+#0) = r2
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.12:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_14
	}
// %bb.13:                              // %if.then15
	{
		r4 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = combine(r16,r22)
		r5 = #0
		memw(r29+#0) = r19
		memw(r29+#4) = r17
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r19
	}
	.falign
.LBB21_14:                              // %if.end17
	{
		r0 = r22
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end21:
	.size	moe_m1_push, .Lfunc_end21-moe_m1_push
                                        // -- End function
	.falign
	.type	hexkl_wh_affine_sums,@function  // -- Begin function hexkl_wh_affine_sums
hexkl_wh_affine_sums:                   // @hexkl_wh_affine_sums
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r1,#0)
		allocframe(r29,#128):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		if (p1) jump:nt .LBB22_17
		r31:30 = deallocframe(r30):raw
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r8 = add(r1,#3)
		p0 = cmp.gtu(r2,#31); if (p0.new) jump:t .LBB22_7
		v0 = vxor(v0,v0)
	}
// %bb.2:                               // %for.body.lr.ph.split
	{
		r6 = add(r1,#3)
		v11 = valign(v0,v0,#4)
		r5 = #8
		r7 = #16
	}
	{
		r8 = lsr(r6,#2)
		r6 = #1
		v12.w = vadd(v0.w,v11.w)
	}
	{
		loop0(.LBB22_3,r8)
	}
	{
		r5 = #0
		v13 = vror(v12,r5)
	}
	{
		v14.w = vadd(v12.w,v13.w)
	}
	{
		v15 = vror(v14,r7)
	}
	{
		v1.w = vadd(v14.w,v15.w)
	}
	.falign
.LBB22_3:                               // Block address taken
                                        // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB22_4 Depth 2
	{
		r7 = addasl(r3,r5,#2)
		r8 = addasl(r4,r5,#2)
		r9 = add(r29,#0)
		r12 = #0
	}
	{
		vmem(r29+#0) = v1
	}
	.falign
.LBB22_4:                               // %for.body11
                                        //   Parent Loop BB22_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p0 = cmp.gtu(r12,#2)
		r13 = memw(r7++#4)
		r14 = memw(r9+#0)
	}
	{
		r14 -= mpyi(r13,r2)
		if (p0) jump:nt .LBB22_6
		memw(r8++#4) = r14.new
	}
// %bb.5:                               // %for.body11
                                        //   in Loop: Header=BB22_4 Depth=2
	{
		r13 = add(r6,r12)
		r9 = add(r9,#32)
		r12 = add(r12,#1)
	}
	{
		p1 = cmp.gtu(r1,r13)
		if (p1.new) jump:t .LBB22_4
	}
	.falign
.LBB22_6:                               // %for.cond.cleanup10
                                        //   in Loop: Header=BB22_3 Depth=1
	{
		nop
		r5 = add(r5,#4)
		r6 = add(r6,#4)
	} :endloop0
	{
		jump .LBB22_17
	}
	.falign
.LBB22_7:
	{
		r13 = lsr(r8,#2)
		r5 = lsr(r2,#5)
		r7:6 = combine(#1,#0)
		r9 = #8
	}
	{
		r8 = ##16843009
		r12 = #16
	}
	{
		loop1(.LBB22_8,r13)
	}
	.falign
.LBB22_8:                               // Block address taken
                                        // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB22_10 Depth 2
                                        //     Child Loop BB22_14 Depth 2
	{
		r13 = addasl(r0,r6,#5)
		p1 = cmp.gtu(r5,#1)
		if (p1.new) r14 = add(r5,#-2)
		v2 = v0
	}
	{
		r13 = add(r13,#2048)
		if (!p1) jump:nt .LBB22_13
		v3 = vmemu(r13+#0)
	}
// %bb.9:                               // %for.body4.us
                                        //   in Loop: Header=BB22_8 Depth=1
	{
		p0 = cmp.gtu(r5,#2)
		v4 = vmemu(r13+#0)
	}
	{
		loop0(.LBB22_10,r14)
		r13 = add(r13,#2048)
		if (!p0) jump:nt .LBB22_11
		v2 = v0
	}
	.balign 32
.LBB22_10:                              // %for.body4.us
                                        //   Parent Loop BB22_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
		v4 = vmemu(r13+#0)
	}
	{
		r13 = add(r13,#2048)
		nop
	} :endloop0
	.falign
.LBB22_11:                              //   in Loop: Header=BB22_8 Depth=1
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
	}
	.falign
.LBB22_13:                              //   in Loop: Header=BB22_8 Depth=1
	{
		r13 = addasl(r3,r6,#2)
		v2.uw += vrmpy(v3.ub,r8.ub)
		r15 = #0
		r28 = add(r29,#0)
	}
	{
		r14 = addasl(r4,r6,#2)
	}
	{
		v5 = valign(v2,v2,#4)
	}
	{
		v6.w = vadd(v2.w,v5.w)
	}
	{
		v7 = vror(v6,r9)
	}
	{
		v8.w = vadd(v6.w,v7.w)
	}
	{
		v9 = vror(v8,r12)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		vmem(r29+#0) = v10.new
	}
	.falign
.LBB22_14:                              // %for.body11.us
                                        //   Parent Loop BB22_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p1 = cmp.gtu(r15,#2)
		r10 = memw(r13++#4)
		r11 = memw(r28+#0)
	}
	{
		r11 -= mpyi(r10,r2)
		if (p1) jump:nt .LBB22_16
		memw(r14++#4) = r11.new
	}
// %bb.15:                              // %for.body11.us
                                        //   in Loop: Header=BB22_14 Depth=2
	{
		r10 = add(r7,r15)
		r28 = add(r28,#32)
		r15 = add(r15,#1)
	}
	{
		p0 = cmp.gtu(r1,r10)
		if (p0.new) jump:t .LBB22_14
	}
	.falign
.LBB22_16:                              // %for.cond.cleanup10.us
                                        //   in Loop: Header=BB22_8 Depth=1
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	.falign
.LBB22_17:                              // %for.cond.cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end22:
	.size	hexkl_wh_affine_sums, .Lfunc_end22-hexkl_wh_affine_sums
                                        // -- End function
	.falign
	.type	moe_m1_pair_worker,@function    // -- Begin function moe_m1_pair_worker
moe_m1_pair_worker:                     // @moe_m1_pair_worker
// %bb.0:                               // %entry
	{
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#176)
	}                                       // 8-byte Folded Spill
	{
		r19 = add(r2,#8208)
		r22 = r1
		memd(r29+#160) = r19:18
		memd(r29+#144) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r19+#48)
		memd(r29+#152) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r18 = memw(r19+#0)
		memd(r29+#136) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r29+#128) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r16
		r25 = add(r16,#8196)
		r17 = add(r16,#8200)
		r24 = add(r22,#1)
	}
	{
		r2 += asl(r0,#9)
	}
	{
		r2 = memw(r2+#4)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_13
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r2 = memw(r25+#64)
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		r0 = sub(r2,r23)
	}
	.falign
// %bb.3:                               // %if.then
	{
		r26 = r20
		r2 = memw(r17+#0)
		r3 = memw(r19+#36)
	}
	{
		r2 = add(#127,asl(r2,#1))
		r1 = r26
		r21 = memw(r25+#0)
	}
	{
		r17 = lsr(r2,#7)
	}
	{
		r18 = mpyi(r17,r3)
	}
	{
		r20 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r20,r22)
		call __hexagon_udivsi3
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r20,r24)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r26
	}
	.falign
// %bb.5:                               // %if.then
	{
		r21 = or(#16,asl(r21,#5))
		r25 = r0
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB23_92
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r26 = add(r16,#8252)
		r2 = ##-1431655765
		r20 = r16
	}
	{
		r3 = add(r16,#8244)
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyu(r21,r2)
	}
	{
		r27 = lsr(r2,#4)
	}
	.falign
.LBB23_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r2 = r0
		r16 = r17
		r21 = r19
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r21 -= mpyi(r0,r18)
	}
	{
		r22 = memw(r3+#0)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
		r17 = add(r2,r3)
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r21 -= mpyi(r0,r22)
		r23 = r0
		r1 = r22
	}
	{
		r0 = mpyi(r21,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.10:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r24 = r0
		r1 = r22
		r2 = add(r21,#1)
	}
	{
		r0 = mpyi(r2,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.11:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r3 = r20
		r4 = r24
		r5 = sub(r0,r24)
		r2 = memw(r26+#0)
	}
	{
		r3 += asl(r17,#9)
		r4 += mpyi(r23,r27)
		r17 = r16
	}
	{
		r23 += mpyi(r21,r16)
		r1 = +mpyi(r5,#24)
	}
	{
		r2 += asl(r24,#9)
		r0 = memw(r3+#12)
		r3 = memw(r3+#28)
	}
	{
		r0 += mpyi(r4,##640)
		r3 += asl(r23,#9)
	}
	{
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.12:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r19 = add(r19,#1)
		if (cmp.gtu(r25,r19.new)) jump:t .LBB23_7
	}
	{
		jump .LBB23_92
	}
	.falign
.LBB23_13:                              // %if.end
	{
		r4 = add(r16,#8232)
		r2 = memw(r19+#16)
		memw(r29+#52) = r16
	}                                       // 4-byte Folded Spill
	{
		if (!p0.new) r18 = add(r20,#0)
		p0 = cmp.eq(r2,#0)
		memw(r29+#68) = r17
	}                                       // 4-byte Folded Spill
	{
		r3 = p0
		if (p0) jump:nt .LBB23_15
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:
	{
		p0 = or(p0,!p0)
	}
	{
		r3 = p0
		jump .LBB23_16
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_15:                              // %lor.rhs
	{
		r18 = r20
		r3 = memw(r4+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_16:                              // %lor.end
	{
		r5 = #512
		r1:0 = combine(#0,r2)
		r3 = memw(r25+#0)
		r6 = memw(r19+#28)
	}
	{
		r2 = lsr(r5,r6)
		r1:0 = asl(r1:0,#10)
		r21 = #0
		memw(r29+#56) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r3,r2)
	}
	{
		r20 = asl(r2,#1)
	}
	{
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.17:                              // %lor.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r5:4 = combine(#0,#0)
		memw(r29+#100) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#104) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_20
	}
// %bb.18:                              // %if.then6
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r2,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.19:                              // %if.then6
	{
		r5:4 = combine(r1,r0)
		r23 = memw(r17+#0)
	}
	.falign
.LBB23_20:                              // %do.end
	{
		r20 = r18
		r2 = memw(r25+#64)
		memd(r29+#112) = r5:4
	}                                       // 8-byte Folded Spill
	{
		r16 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r16,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.21:                              // %do.end
	{
		r1:0 = mpyu(r16,r24)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.22:                              // %do.end
	{
		r2 = add(r23,r0)
		r22 = memw(r29+#52)
		memw(r29+#92) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r22,#8236)
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB23_88
		if (p1.new) r1:0 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
// %bb.23:                              // %cond.end
	{
		r3:2 = combine(#127,#1)
		r20 = memw(r19+#0)
	}
	{
		r2 = maxu(r0,r2)
		r1:0 = combine(r20,r17)
	}
	{
		r16 = minu(r2,r3)
		call __hexagon_udivsi3
	}
	.falign
// %bb.24:                              // %cond.end
	{
		r2 = add(r0,#1)
		r3 = add(r17,r16)
		r16 = memw(r29+#100)
		memw(r29+#96) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r3 = minu(r2,r3)
		memw(r29+#84) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:nt .LBB23_35
	}
// %bb.25:                              // %cond.end
	{
		if (p0.new) r3:2 = combine(r22,r17)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB23_35
		if (p0.new) r4 = memw(r27+#0)
	}
// %bb.26:                              // %if.then17
	{
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r20 = sub(r4,r17)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB23_29
		r3 = r20
		r0 = memw(r3+#4)
	}
// %bb.27:                              // %if.then.i
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.28:                              // %if.then.i
	{
		jump .LBB23_30
	}
	.falign
.LBB23_29:                              // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB23_30:                              // %moe_m1_pf_gu.exit
	{
		r21 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.31:                              // %moe_m1_pf_gu.exit
	{
		r3:2 = combine(r17,r22)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r21)
		p0 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r21)
		r3 = r20
		r5 = memw(r2+#4)
	}
	{
		if (p0) jump:nt .LBB23_34
		r0 = memw(r5+#4)
	}
// %bb.32:                              // %if.then.i329
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.33:                              // %if.then.i329
	{
		jump .LBB23_35
	}
	.falign
.LBB23_34:                              // %if.else.i330
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB23_35:                              // %for.body.lr.ph
	{
		r18 = add(r22,#8228)
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		r0 = add(r22,#8264)
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
		if (p1) r5 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
	}
	{
		if (!p1) r5 = add(r3,#0)
		memw(r29+#80) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#76) = r5
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_36:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB23_41 Depth 2
                                        //       Child Loop BB23_74 Depth 3
                                        //       Child Loop BB23_81 Depth 3
	{
		r17 = memw(r29+#84)
		memw(r29+#60) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r17)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB23_39
		memw(r29+#88) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.37:                              // %cond.true23
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r20 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.38:                              // %cond.true23
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#96)
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r2 = minu(r2,r0)
		memw(r29+#84) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_39:                              // %cond.end27
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = memw(r29+#60)
		if (!cmp.gtu(r17,r2.new)) jump:t ##.LBB23_87
	}                                       // 4-byte Folded Reload
// %bb.40:                              // %for.body33.lr.ph
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r21 = memw(r29+#60)
		r2 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,r17)
		r3 = sub(r2,r17)
		memw(r29+#64) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_41:                              // %for.body33
                                        //   Parent Loop BB23_36 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB23_74 Depth 3
                                        //       Child Loop BB23_81 Depth 3
	{
		r23 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r21)
	}
	.falign
// %bb.42:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r24 = r0
		r16 = r22
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r16 += asl(r0,#9)
		p0 = r2
	}
	{
		if (p0) jump:nt .LBB23_50
		r20 = memw(r16+#28)
	}
// %bb.43:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#60)
		if (!cmp.eq(r2.new,r21)) jump:nt .LBB23_50
	}                                       // 4-byte Folded Reload
// %bb.44:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r1:0 = combine(r23,r17)
		if (!p0.new) jump:nt .LBB23_50
	}
// %bb.45:                              // %if.then48
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.46:                              // %if.then48
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3:2 = combine(r22,r17)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r23)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB23_49
		r0 = memw(r3+#4)
		if (!p1) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.47:                              // %if.then.i352
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.48:                              // %if.then.i352
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_50
	}
	.falign
.LBB23_49:                              // %if.else.i353
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
		r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_50:                              // %if.end49
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r22 = r21
	}
	{
		r22 -= mpyi(r24,r23)
	}
	{
		r0 = asl(r22,#10)
	}
	{
		r23 = add(r20,r0)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_54
	}
// %bb.51:                              // %land.lhs.true53
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r5 = add(r16,#128)
		r0 = memw(r16+#0)
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r16+#388)
		r3 = memw(r16+#12)
	}
	{
		r2 = memw(r2+#0)
		r4 = memw(r27+#-24)
	}
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB23_56
		r2 = memw(r25+#0)
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then57
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r19+#0)
		r7 = memw(r18+#0)
	}
	{
		r5 = r22
		r7 = add(r23,#512)
		memw(r29+#8) = r5
		memw(r29+#4) = r7
	}
	{
		r6 = add(r6,r22)
		memw(r29+#12) = r23
		memw(r29+#16) = r7
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#0) = r6
	}
	.falign
// %bb.53:                              // %if.then57
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_57
	}
	.falign
.LBB23_54:                              // %if.else75
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r5 = memw(r18+#0)
	}
	{
		r1 = memw(r16+#388)
		r2 = memw(r25+#0)
	}
	{
		r3 = memw(r16+#12)
		r4 = memw(r27+#-24)
	}
	{
		r5 = r22
		r6 = memw(r29+#76)
		memw(r29+#0) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r23
	}
	{
		callr r6
	}
	.falign
// %bb.55:                              // %if.else75
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_57
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_56:                              // %if.then64
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r18+#0)
		memw(r29+#0) = r6.new
	}
	{
		r5 = r22
		r6 = memw(r29+#80)
		memw(r29+#4) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r23
	}
	{
		callr r6
	}
	.falign
.LBB23_57:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r21 = add(r21,#1)
		r0 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r21,r17)
	}
	{
		r2 = p1
		p1 = r0
		if (p1.new) jump:nt .LBB23_63
		memw(r29+#44) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.58:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB23_63
		if (p1.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.59:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB23_63
		if (p0.new) r24 = memw(r19+#0)
	}
// %bb.60:                              // %if.then94
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r17)
	}
	.falign
// %bb.61:                              // %if.then94
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3 = r17
		r2 = memw(r29+#52)
		r4 = memw(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r24)
		p0 = cmp.eq(r4,#0)
		r1 = memw(r27+#-24)
	}
	{
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r24)
		r5 = memw(r2+#4)
		if (!p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB23_67
		r0 = memw(r5+#4)
		if (p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %if.then.i367
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB23_63:                              // %if.end95
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_69
	}
	.falign
.LBB23_64:                              // %land.lhs.true99
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB23_70
	}
// %bb.65:                              // %if.then108
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = add(r16,#128)
		memw(r29+#8) = r6
	}
	{
		r6 = memw(r29+#80)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.66:                              // %if.then108
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_70
	}
	.falign
.LBB23_67:                              // %if.else.i368
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.68:                              // %if.else.i368
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB23_64
	}
	.falign
.LBB23_69:                              // %if.else122
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = memw(r29+#76)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
.LBB23_70:                              // %if.end135
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r2 = memw(r4+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_85
	}
// %bb.71:                              // %if.then138
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3 = asl(r22,#5)
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB23_85
	}
// %bb.72:                              // %for.body.us.i
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r9 = lsr(r5,#1)
		r5 = r23
		r4 = and(r5,#1)
	}
	{
		r7 = addasl(r2,r3,#2)
		r2 = add(r16,#56)
		p1 = cmp.gtu(r9,#0)
		if (p1.new) r5 = add(r23,#0)
	}
	{
		if (p1) r8 = add(r2,#0)
		r6 = r2
	}
	{
		if (!p1) jump:nt .LBB23_75
		v0 = vmemu(r7+#0)
	}
// %bb.73:                              //   in Loop: Header=BB23_41 Depth=2
	{
		loop0(.LBB23_74,r9)
		r7:6 = combine(r23,r2)
	}
	.balign 32
.LBB23_74:                              //   Parent Loop BB23_36 Depth=1
                                        //     Parent Loop BB23_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r6++#8)
	}
	{
		v2 = vsplat(r9)
		v3 = vmemu(r7+#0)
	}
	{
		v5 = vmemu(r7+#1)
	}
	{
		v3.w += vmpyie(v2.w,v0.h)
	}
	{
		vmemu(r5++#2) = v3
	}
	{
		r8 = memw(r8+#4)
	}
	{
		v4 = vsplat(r8)
		r8 = r6
	}
	{
		v5.w += vmpyie(v4.w,v0.h)
	}
	{
		r7 = r5
		vmemu(r7+#1) = v5
	} :endloop0
	.falign
.LBB23_75:                              //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = cmp.gtu(r4,#0); if (!p0.new) jump:t .LBB23_77
		if (p0.new) r4 = memw(r6+#0)
	}
	.falign
.LBB23_76:                              // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		v6 = vsplat(r4)
		v7 = vmemu(r5+#0)
	}
	{
		v7.w += vmpyie(v6.w,v0.h)
	}
	{
		vmemu(r5++#1) = v7
	}
	.falign
.LBB23_77:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r6 = memw(r4+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB23_85
	}
// %bb.78:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB23_85
	}
// %bb.79:                              // %for.body.us.i376
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r7 = lsr(r5,#1)
		r5 = and(r5,#1)
		r4 = memw(r20+#0)
	}
	{
		r4 = addasl(r6,r4,#2)
		r6 = add(r23,#512)
		p1 = cmp.gtu(r7,#0)
	}
	{
		r3 = addasl(r4,r3,#2)
		r4 = r2
	}
	{
		r3 = r6
		if (!p1) jump:nt .LBB23_82
		v1 = vmemu(r3+#0)
	}
// %bb.80:                              //   in Loop: Header=BB23_41 Depth=2
	{
		loop0(.LBB23_81,r7)
	}
	.balign 32
.LBB23_81:                              //   Parent Loop BB23_36 Depth=1
                                        //     Parent Loop BB23_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r4++#8)
	}
	{
		v8 = vsplat(r7)
		v9 = vmemu(r6+#0)
	}
	{
		v11 = vmemu(r6+#1)
	}
	{
		v9.w += vmpyie(v8.w,v1.h)
	}
	{
		vmemu(r3++#2) = v9
	}
	{
		r2 = memw(r2+#4)
	}
	{
		v10 = vsplat(r2)
		r2 = r4
	}
	{
		v11.w += vmpyie(v10.w,v1.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v11
	} :endloop0
	.falign
.LBB23_82:                              //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = cmp.gtu(r5,#0); if (!p0.new) jump:t .LBB23_84
		if (p0.new) r2 = memw(r4+#0)
	}
	.falign
.LBB23_83:                              // Block address taken
                                        // %for.body3.us.i379
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		v12 = vsplat(r2)
		v13 = vmemu(r3+#0)
	}
	{
		v13.w += vmpyie(v12.w,v1.h)
	}
	{
		vmemu(r3++#1) = v13
	}
	.falign
.LBB23_84:                              // %if.end154.loopexit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	.falign
.LBB23_85:                              // %if.end154
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r29+#72)
		r5 = memw(r16+#388)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r4+#8)
		r2 = memw(r16+#20)
	}
	{
		r3 = memw(r16+#24)
		r4 = memw(r4+#16)
	}
	{
		r6 = memw(r6+#0)
		r7 = memw(r16+#36)
	}
	{
		r4 = #32
		r8 = memw(r20+#0)
		memw(r29+#16) = r4

	} :mem_noshuf
	{
		r0 = r23
		r1 = #512
		memw(r29+#12) = r0
		memw(r29+#8) = r1
	}
	{
		r3:2 = combine(r22,#1)
		memw(r29+#4) = r3
		memw(r29+#0) = r2
	}
	{
		memw(r29+#36) = #0
		memw(r29+#32) = r8
	}
	{
		memw(r29+#28) = r7
		memw(r29+#24) = r6
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#20) = r8
	}
	.falign
// %bb.86:                              // %if.end154
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#44)
		r22 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB23_41
	}
	.falign
.LBB23_87:                              // %for.cond.loopexit
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB23_36
	}
	.falign
.LBB23_88:                              // %for.cond.cleanup
	{
		r16 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_92
	}
// %bb.89:                              // %if.then.i332
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.90:                              // %if.then.i332
	{
		r3:2 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB23_91:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB23_91
	}
	.falign
.LBB23_92:                              // %cleanup
	{
		r17:16 = memd(r29+#168)
		r19:18 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#152)
		r23:22 = memd(r29+#144)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#136)
		r27:26 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end23:
	.size	moe_m1_pair_worker, .Lfunc_end23-moe_m1_pair_worker
                                        // -- End function
	.falign
	.type	moe_m1_q_post_after_a,@function // -- Begin function moe_m1_q_post_after_a
moe_m1_q_post_after_a:                  // @moe_m1_q_post_after_a
// %bb.0:                               // %entry
	{
		r6 = add(r2,#2)
		r14 = #640
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(r1,#8192)
		r16 = ##-858960692
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r7 = memw(r20+#0)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r7,r6)
		memd(r29+#32) = r23:22
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p1) r22 = add(r1,##8204)
		if (!p1) jump:nt .LBB24_7
		memd(r29+#16) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r1 += asl(r6,#9)
		p0 = tstbit(r2,#0)
		r5 = memw(r0+#40)
		r2 = memw(r20+#20)
	}
	{
		r6 = asl(r2,#9)
		r7 = add(r5,#1)
		if (!p0) r4 = #0
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		r3 = add(r3,r4)
		r19 = memw(r1+#4)
		r2 = memw(r20+#4)
	}
	{
		r4 = lsr(r6,#1)
		r18 = add(r0,r5)
	}
	{
		r3 = memw(r19+#84)
		memw(r0+r5<<#0) = r3
	}
	{
		p1 = cmp.eq(r3,#2)
		r0 = memw(r19+#44)
		r3 = memw(r19+#4)
	}
	{
		p0 = cmp.eq(r0,#0)
		if (!p1) r4 = add(r6,#0)
		memw(r18+#4) = r3
		memw(r18+#12) = r2
	}
	{
		if (p0) jump:nt .LBB24_4
		if (!p0) r0 = memw(r19+#28)
		memw(r18+#8) = r4
	}
// %bb.2:                               // %if.then.i
	{
		r1 = memw(r19+#32)
		memw(r18+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.3:                               // %if.then.i
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r18+#12) = r2.new
	}
	.falign
.LBB24_4:                               // %if.end.i
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_14
	}
// %bb.5:                               // %land.rhs.i.i
	{
		r3 = memw(r19+#36)
	}
	{
		r3 = #1
		p0 = cmp.eq(r3,#0); if (!p0.new) jump:t .LBB24_15
	}
// %bb.6:                               // %lor.rhs.i.i
	{
		r3 = memw(r19+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB24_15
	}
	.falign
.LBB24_7:                               // %if.end
	{
		r17 = add(pc,##g_moe_src_bypass@PCREL)
		r2 = and(#2,asl(r2,#1))
		r25 = add(r1,#8216)
	}
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p0 = cmp.gtu(r7,r2)
		p2 = cmp.eq(r2,#0)
	}
	{
		r7 = r1
		if (!p0) jump:nt .LBB24_20
		if (p0) r8 = memw(r0+#40)
		if (p0) r6 = memw(r25+#0)
	}
// %bb.8:                               // %if.then9
	{
		r7 += asl(r2,#9)
		r12 = asl(r6,#9)
		r9 = mux(p2,#0,r4)
		r6 = memw(r22+#0)
	}
	{
		r13 = +mpyi(r8,#20)
		r8 = add(r8,#1)
		r10 = add(r3,r9)
		memw(r0+#40) = r8.new
	}
	{
		r23 = add(r0,r13)
		r24 = memw(r7+#8)
	}
	{
		memw(r0+r13<<#0) = r10
		memw(r23+#12) = r6
	}
	{
		r7 = memw(r24+#84)
		r11 = memw(r24+#44)
	}
	{
		r7 = lsr(r12,#1)
		p0 = cmp.eq(r7,#2)
		p1 = cmp.eq(r11,#0)
		r13 = memw(r24+#4)
	}
	{
		if (!p0) r7 = add(r12,#0)
		memw(r23+#4) = r13
	}
	{
		if (p1) jump:nt .LBB24_11
		memw(r23+#8) = r7
	}
// %bb.9:                               // %if.then.i49
	{
		r27:26 = combine(r3,r1)
		r21 = r18
		r6 = memw(r24+#28)
		memw(r29+#4) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		r0 = r6
		r19:18 = combine(r2,r17)
		r6 = memw(r24+#32)
	}
	{
		r1 = r6
		r17:16 = combine(r4,r5)
		memw(r23+#8) = r14
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Spill
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.10:                              // %if.then.i49
	{
		r5:4 = combine(r16,r17)
		r16 = ##-858960692
		r2 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r7 = add(r16,#-32767)
		r6 = r0
		r0 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r6 = mpyu(r6,r7)
		r17 = r18
		r14 = #640
		r3:2 = combine(r27,r19)
	}
	{
		r6 = lsr(r6,#9)
		r18 = r21
		r1 = r26
		memw(r23+#12) = r6.new
	}
	.falign
.LBB24_11:                              // %if.end.i54
	{
		r7 = memw(r17+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_17
	}
// %bb.12:                              // %land.rhs.i.i56
	{
		r7 = memw(r24+#36)
	}
	{
		r7 = #1
		p1 = cmp.eq(r7,#0); if (!p1.new) jump:t .LBB24_18
	}
// %bb.13:                              // %lor.rhs.i.i68
	{
		r7 = memw(r24+#40)
	}
	{
		r7 = !cmp.eq(r7,#0)
		jump .LBB24_18
	}
	.falign
.LBB24_14:
	{
		r3 = #0
	}
	.falign
.LBB24_15:                              // %moe_weight_src_bypass.exit.i
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r18+#16) = r3
	}
	{
		r3 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_31
	}
// %bb.16:
	{
		r3 = add(r18,#8)
		jump .LBB24_30
	}
	.falign
.LBB24_17:
	{
		r7 = #0
	}
	.falign
.LBB24_18:                              // %moe_weight_src_bypass.exit.i59
	{
		memw(r23+#16) = r7
	}
	{
		r7 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r7 = memw(r7+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_20
	}
// %bb.19:                              // %if.then7.i63
	{
		r7 = memw(r23+#8)
		r8 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r6 = mpyi(r7,r6)
		r7 = #0
		r13:12 = memd(r8+#56)
	}
	{
		r6 = lsr(r6,#10)
	}
	{
		r7:6 = add(r13:12,r7:6)
	}
	{
		memd(r8+#56) = r7:6
	}
	.falign
.LBB24_20:                              // %for.inc
	{
		r2 = setbit(r2,#0)
	}
	{
		r1 += asl(r2,#9)
		r6 = memw(r20+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t .LBB24_31
	}
// %bb.21:                              // %if.then9.1
	{
		r7 = mux(p2,#0,r4)
		r6 = memw(r0+#40)
		r2 = memw(r25+#0)
	}
	{
		r8 = asl(r2,#9)
		r4 = add(r6,#1)
		memw(r0+#40) = r4.new
	}
	{
		r6 = +mpyi(r6,#20)
		r5 += add(r3,r7)
		r21 = memw(r1+#8)
		r2 = memw(r22+#0)
	}
	{
		r4 = lsr(r8,#1)
		r20 = add(r0,r6)
	}
	{
		r3 = memw(r21+#84)
		memw(r0+r6<<#0) = r5
	}
	{
		p0 = cmp.eq(r3,#2)
		r0 = memw(r21+#44)
		r3 = memw(r21+#4)
	}
	{
		p1 = cmp.eq(r0,#0)
		if (!p0) r4 = add(r8,#0)
		memw(r20+#4) = r3
		memw(r20+#12) = r2
	}
	{
		if (p1) jump:nt .LBB24_24
		if (!p1) r0 = memw(r21+#28)
		memw(r20+#8) = r4
	}
// %bb.22:                              // %if.then.i49.1
	{
		r1 = memw(r21+#32)
		memw(r20+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.23:                              // %if.then.i49.1
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r20+#12) = r2.new
	}
	.falign
.LBB24_24:                              // %if.end.i54.1
	{
		r3 = memw(r17+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_27
	}
// %bb.25:                              // %land.rhs.i.i56.1
	{
		r3 = memw(r21+#36)
	}
	{
		r3 = #1
		p1 = cmp.eq(r3,#0); if (!p1.new) jump:t .LBB24_28
	}
// %bb.26:                              // %lor.rhs.i.i68.1
	{
		r3 = memw(r21+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB24_28
	}
	.falign
.LBB24_27:
	{
		r3 = #0
	}
	.falign
.LBB24_28:                              // %moe_weight_src_bypass.exit.i59.1
	{
		memw(r20+#16) = r3
	}
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_31
	}
// %bb.29:
	{
		r3 = add(r20,#8)
	}
	.falign
.LBB24_30:                              // %for.end.sink.split
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r1 = #0
		r3 = memw(r3+#0)
	}
	{
		r2 = mpyi(r3,r2)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r2,#10)
	}
	{
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB24_31:                              // %for.end
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end24:
	.size	moe_m1_q_post_after_a, .Lfunc_end24-moe_m1_q_post_after_a
                                        // -- End function
	.falign
	.type	moe_tl2_gate_epilogue_worker,@function // -- Begin function moe_tl2_gate_epilogue_worker
moe_tl2_gate_epilogue_worker:           // @moe_tl2_gate_epilogue_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#640):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = add(r2,#8196)
		r17:16 = combine(r1,r2)
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r19 = add(r16,#8200)
		r2 = memw(r22+#12)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#48)
		r20 = add(r16,#8244)
		r3 = memw(r22+#64)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r21 = add(r16,#8264)
		r23 = memw(r22+#60)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r24 = sub(r3,r23)
		if (p0) r3 = add(r23,#0)
		if (!p0) jump:nt .LBB25_23
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r24,#48)
		if (p1.new) r2 = ##-1431655765
		if (!p1.new) jump:nt .LBB25_23
	}
// %bb.2:                               // %entry
	{
		r2 = mpyu(r23,r2)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r3 -= mpyi(r2,#48)
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB25_23
	}
// %bb.3:                               // %land.lhs.true7
	{
		r3 = memw(r22+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB25_23
	}
// %bb.4:                               // %lor.lhs.false.i
	{
		r3 = #64
	}
	{
		r3 = memw(r22+#0)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB25_23
	}
// %bb.5:                               // %lor.lhs.false1.i
	{
		r3 = #1536
	}
	{
		r3 = memw(r19+#0)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB25_23
	}
// %bb.6:                               // %lor.lhs.false5.i
	{
		r3 = #2048
	}
	{
		r3 = memw(r22+#24)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB25_23
	}
// %bb.7:                               // %lor.lhs.false7.i
	{
		r25 = r16
		r3 = memw(r20+#0)
		if (!cmp.eq(r3.new,#1)) jump:t .LBB25_23
	}
// %bb.8:                               // %lor.lhs.false9.i
	{
		r3 = memw(r21+#0)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB25_23
	}
// %bb.9:                               // %lor.lhs.false11.i
	{
		r25 += asl(r2,#9)
	}
	{
		r2 = memw(r25+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB25_23
	}
// %bb.10:                              // %lor.lhs.false13.i
	{
		r26 = memw(r25+#4)
	}
	{
		r2 = memw(r26+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_23
	}
// %bb.11:                              // %lor.lhs.false15.i
	{
		r27 = memw(r25+#8)
	}
	{
		r2 = memw(r27+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_23
	}
// %bb.12:                              // %lor.lhs.false18.i
	{
		call htp_tl2_palette_magnitude
		r0 = add(r26,#88)
	}
	.falign
// %bb.13:                              // %lor.lhs.false18.i
	{
		if (p0.new) r0 = add(r27,#88)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB25_23
	}
// %bb.14:                              // %lor.lhs.false21.i
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.15:                              // %lor.lhs.false21.i
	{
		if (p1.new) r1:0 = combine(r17,r18)
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB25_23
		if (p1.new) r3:2 = memd(r25+#24)
	}
// %bb.16:                              // %if.end.i
	{
		r19 = #0
		r4 = memw(r25+#36)
		memw(r29+#268) = r19.new
	}
	{
		r3 = #128
		memw(r29+#256) = r3
	}
	{
		r3 = #48
		memw(r29+#260) = r3
	}
	{
		r2 = add(r29,#256)
		r3 = #32
		memw(r29+#264) = r3
		memw(r29+#284) = r2
	}
	{
		r3 = #1
		memw(r29+#272) = r3
	}
	{
		r3 = memw(r25+#20)
		memw(r29+#276) = r3
	}
	{
		memw(r29+#280) = r3
		r5 = memw(r26+#12)

	} :mem_noshuf
	{
		r3 = #1536
		memw(r29+#288) = r5
		r5 = memw(r26+#8)

	} :mem_noshuf
	{
		memw(r29+#292) = r5
		r5 = memw(r26+#16)

	} :mem_noshuf
	{
		memw(r29+#296) = r5
		memw(r29+#300) = r3
	}
	{
		memw(r29+#304) = r4
		memw(r29+#308) = r3
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#312) = r19
	}
	.falign
// %bb.17:                              // %if.end.i
	{
		r2 = memw(r22+#52)
		r21 = memw(r29+#264)
	}
	{
		p1 = cmp.eq(r2,#0)
		r3:2 = combine(r19,r18)
	}
	{
		r1:0 = mpyu(r21,r17)
		call __hexagon_udivdi3
		r20 = mux(p1,#2,#0)
	}
	.falign
// %bb.18:                              // %if.end.i
	{
		r2 = add(r17,#1)
		r17:16 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r21,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.19:                              // %if.end.i
	{
		r2 = add(pc,##tl2_gu_trace@PCREL)
	}
	{
		r3 = addasl(r2,r20,#2)
	}
	.balign 32
.LBB25_20:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = memw_locked(r3)
	}
	{
		r4 = add(r4,#1)
	}
	{
		memw_locked(r3,p0) = r4
	}
	{
		if (!p0) jump:nt .LBB25_20
	}
// %bb.21:                              // %atomicrmw.end
	{
		r4 = asl(r20,#2)
		r3 = sub(r0,r16)
	}
	{
		r2 = add(r2,add(r4,#4))
	}
	.balign 32
.LBB25_22:                              // %atomicrmw.start65
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = memw_locked(r2)
	}
	{
		r4 = add(r4,r3)
	}
	{
		memw_locked(r2,p1) = r4
	}
	{
		if (!p1) jump:nt .LBB25_22
	}
	{
		jump .LBB25_94
	}
	.falign
.LBB25_23:                              // %if.end
	{
		r0 = mpyi(r24,r17)
		call __hexagon_udivsi3
		r1 = r18
	}
	.falign
// %bb.24:                              // %if.end
	{
		r17 = add(r0,r23)
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r24,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.25:                              // %if.end
	{
		r24 = #3
		r22 = add(r0,r23)
		if (!cmp.gtu(r22.new,r17)) jump:t ##.LBB25_94
	}
// %bb.26:                              // %for.body.lr.ph.i
	{
		r23 = add(r16,#8208)
		r2 = memw(r19+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r25 = and(r2,#-128)
	}
	.falign
.LBB25_27:                              // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB25_31 Depth 2
                                        //     Child Loop BB25_35 Depth 2
                                        //     Child Loop BB25_63 Depth 2
                                        //     Child Loop BB25_67 Depth 2
	{
		r18 = memw(r23+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.28:                              // %for.body.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r3:2 = combine(r16,r17)
		r5 = #1
		r6 = memw(r20+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB25_37
		v0 = vmem(r4+#0)
	}
// %bb.29:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r12 = mpyi(r5,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB25_33
	}
// %bb.30:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_31,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r4,r13,#2)
		v3.w = vadd(v0.w,v23.w)
		v23.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB25_32
	}
	.falign
.LBB25_31:                              //   Parent Loop BB25_27 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r25)
		v25.w = vadd(v3.w,v24.w)
		v24.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v26 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r5,#3)
		v27.w = vadd(v25.w,v26.w)
		v28 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r5 = add(r5,#4)
		v29.w = vadd(v27.w,v28.w)
		v30 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r4,r9,#2)
		v3.w = vadd(v29.w,v30.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_32:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r12 = addasl(r4,r12,#2)
		v0.w = vadd(v3.w,v31.w)
		v31.cur = vmem(r13+#0)
	}
	{
		v2.w = vadd(v0.w,v1.w)
		v1.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v2.w,v3.w)
		v3.cur = vmem(r12+#0)
	}
	.falign
.LBB25_33:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = mpyi(r5,r25)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB25_37
	}
// %bb.34:                              // %for.body13.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB25_35,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB25_36
	}
	.balign 32
.LBB25_35:                              // %for.body13.i
                                        //   Parent Loop BB25_27 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r5,r25)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v4.w)
		v4.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_36:                              //   in Loop: Header=BB25_27 Depth=1
	{
		v0.w = vadd(v0.w,v5.w)
		v5.cur = vmem(r8+#0)
	}
	.falign
.LBB25_37:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r5 = memw(r3+#4)
		vmem(r29+#2) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r19+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB25_40
	}
// %bb.38:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB25_40
	}
// %bb.39:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_60
	}
	.falign
.LBB25_40:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_45
	}
// %bb.41:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_43
	}
// %bb.42:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB25_60
	}
	.falign
.LBB25_43:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		if (p1) jump:nt .LBB25_46
	}
// %bb.44:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_60
	}
	{
		jump .LBB25_46
	}
	.falign
.LBB25_45:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_46:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB25_51
	}
// %bb.47:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB25_49
	}
// %bb.48:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_60
	}
	.falign
.LBB25_49:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB25_52
	}
// %bb.50:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB25_60
	}
	{
		jump .LBB25_52
	}
	.falign
.LBB25_51:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r8 = r9
	}
	.falign
.LBB25_52:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_57
	}
// %bb.53:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_55
	}
// %bb.54:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB25_60
	}
	.falign
.LBB25_55:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB25_58
	}
// %bb.56:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_60
	}
	{
		jump .LBB25_58
	}
	.falign
.LBB25_57:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_58:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB25_60
		v4.w = vasl(v0.w,r24)
	}
// %bb.59:                              // %if.end.i.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		v5.w = vsub(v4.w,v0.w)
		vmem(r29+#2) = v5.new
	}
	.falign
.LBB25_60:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB25_69
		v1 = vmem(r7+#0)
	}
// %bb.61:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r12 = mpyi(r6,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB25_65
	}
// %bb.62:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_63,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r7,r13,#2)
		v2.w = vadd(v1.w,v6.w)
		v6.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB25_64
	}
	.falign
.LBB25_63:                              //   Parent Loop BB25_27 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r25)
		v8.w = vadd(v2.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v9 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r6,#3)
		v10.w = vadd(v8.w,v9.w)
		v11 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r6 = add(r6,#4)
		v12.w = vadd(v10.w,v11.w)
		v13 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r7,r9,#2)
		v2.w = vadd(v12.w,v13.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_64:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r12 = addasl(r7,r12,#2)
		v15.w = vadd(v2.w,v14.w)
		v14.cur = vmem(r13+#0)
	}
	{
		v17.w = vadd(v15.w,v16.w)
		v16.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v17.w,v18.w)
		v18.cur = vmem(r12+#0)
	}
	.falign
.LBB25_65:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r9 = mpyi(r6,r25)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB25_69
	}
// %bb.66:                              // %for.body13.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB25_67,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB25_68
	}
	.balign 32
.LBB25_67:                              // %for.body13.1.i
                                        //   Parent Loop BB25_27 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r6,r25)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v19.w)
		v19.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_68:                              //   in Loop: Header=BB25_27 Depth=1
	{
		v1.w = vadd(v1.w,v20.w)
		v20.cur = vmem(r8+#0)
	}
	.falign
.LBB25_69:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		vmem(r29+#3) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_72
	}
// %bb.70:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_72
	}
// %bb.71:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB25_92
	}
	.falign
.LBB25_72:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_77
	}
// %bb.73:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_75
	}
// %bb.74:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_92
	}
	.falign
.LBB25_75:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		if (p0) jump:nt .LBB25_78
	}
// %bb.76:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB25_92
	}
	{
		jump .LBB25_78
	}
	.falign
.LBB25_77:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_78:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB25_83
	}
// %bb.79:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_81
	}
// %bb.80:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB25_92
	}
	.falign
.LBB25_81:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB25_84
	}
// %bb.82:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB25_92
	}
	{
		jump .LBB25_84
	}
	.falign
.LBB25_83:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r6 = r7
	}
	.falign
.LBB25_84:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_89
	}
// %bb.85:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_87
	}
// %bb.86:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_92
	}
	.falign
.LBB25_87:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_90
	}
// %bb.88:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB25_92
	}
	{
		jump .LBB25_90
	}
	.falign
.LBB25_89:                              //   in Loop: Header=BB25_27 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_90:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB25_92
		v21.w = vasl(v1.w,r24)
	}
// %bb.91:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		v22.w = vsub(v21.w,v1.w)
		vmem(r29+#3) = v22.new
	}
	.falign
.LBB25_92:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#256)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.93:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_27 Depth=1
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r22)) jump:t ##.LBB25_27
	}
	.falign
.LBB25_94:                              // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end25:
	.size	moe_tl2_gate_epilogue_worker, .Lfunc_end25-moe_tl2_gate_epilogue_worker
                                        // -- End function
	.falign
	.type	moe_m1_wait,@function           // -- Begin function moe_m1_wait
moe_m1_wait:                            // @moe_m1_wait
// %bb.0:                               // %entry
	{
		r17 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r16 = r0
	}
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_2
	}
// %bb.1:                               // %if.then
	{
		r3 = r1
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r16
	}
	.falign
.LBB26_2:                               // %if.end
	{
		call hexkl_dma_ring_wait
		r0 = r16
	}
	.falign
// %bb.3:                               // %if.end
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_5
	}
// %bb.4:                               // %if.then2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump hexkl_dma_trace_wait_end
		r17:16 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB26_5:                               // %if.end4
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end26:
	.size	moe_m1_wait, .Lfunc_end26-moe_m1_wait
                                        // -- End function
	.falign
	.type	moe_m1_requant_worker,@function // -- Begin function moe_m1_requant_worker
moe_m1_requant_worker:                  // @moe_m1_requant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r23 = add(r2,#8192)
		r17 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r25:24 = combine(#0,r0)
		r16 = memw(r23+#0)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r19 = r2
		r3:2 = combine(r25,r24)
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r16,r1)
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r3 = r25
		r21:20 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r16,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r25,r24)
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
// %bb.2:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r20)
		if (p0.new) r25 = add(r19,##8200)
	}
	{
		if (p0) r26 = ##16843009
		if (!p0) jump:nt .LBB27_122
		memd(r29+#240) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %for.body.lr.ph
	{
		r21 = #8
		r22 = #16
		v20 = vxor(v20,v20)
		vmem(r29+#2) = v20.new
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#236) = r23
	}                                       // 4-byte Folded Spill
	{
		v7 = valign(v20,v20,#4)
	}
	{
		v8.w = vadd(v20.w,v7.w)
	}
	{
		v9 = vror(v8,r21)
	}
	{
		v10.w = vadd(v8.w,v9.w)
	}
	{
		v11 = vror(v10,r22)
	}
	{
		v22.w = vadd(v10.w,v11.w)
		vmem(r29+#3) = v22.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB27_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB27_21 Depth 2
                                        //     Child Loop BB27_23 Depth 2
                                        //     Child Loop BB27_27 Depth 2
                                        //       Child Loop BB27_31 Depth 3
                                        //       Child Loop BB27_35 Depth 3
                                        //       Child Loop BB27_63 Depth 3
                                        //       Child Loop BB27_67 Depth 3
                                        //     Child Loop BB27_113 Depth 2
                                        //       Child Loop BB27_115 Depth 3
                                        //       Child Loop BB27_119 Depth 3
                                        //     Child Loop BB27_108 Depth 2
                                        //       Child Loop BB27_109 Depth 3
	{
		r17:16 = combine(r20,r19)
	}
	{
		r16 += asl(r20,#9)
		r20 = add(r20,#1)
	}
	{
		r18 = memw(r16+#4)
	}
	{
		r2 = memw(r18+#44)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_95
	}
// %bb.5:                               // %land.lhs.true
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r27 = add(r19,#8208)
		r2 = memw(r23+#56)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_95
	}
// %bb.6:                               // %land.lhs.true2
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r22 = add(r19,#8244)
		r21 = add(r19,#8264)
	}
	{
		r2 = memw(r23+#48)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_24
	}
// %bb.7:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r24 = memw(r25+#0)
	}
	{
		r2 = memw(r23+#4)
		if (!cmp.eq(r2.new,r2)) jump:nt .LBB27_25
	}
// %bb.8:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #48
		p1 = cmp.eq(r24,##1536)
		if (!p1.new) jump:nt .LBB27_25
	}
// %bb.9:                               // %lor.lhs.false3.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = #1536
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_25
	}
// %bb.10:                              // %lor.lhs.false5.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #2048
	}
	{
		r2 = memw(r23+#28)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_25
	}
// %bb.11:                              // %lor.lhs.false7.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_25
	}
// %bb.12:                              // %lor.lhs.false9.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB27_25
	}
// %bb.13:                              // %lor.lhs.false11.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_25
	}
// %bb.14:                              // %lor.lhs.false15.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r23 = memw(r16+#8)
	}
	{
		r2 = memw(r23+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_25
	}
// %bb.15:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
		r0 = add(r18,#88)
	}
	.falign
// %bb.16:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		if (p0.new) r0 = add(r23,#88)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB27_25
	}
// %bb.17:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.18:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = add(r29,#512)
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB27_25
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.19:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1:0 = combine(#0,#1)
		r17 = add(r19,#8248)
		r3 = memw(r16+#20)
		memw(r29+#536) = r3.new
	}
	{
		r3 = #32
		r5:4 = memd(r16+#24)
		memw(r29+#528) = r3.new
	}
	{
		r3 = #1
		memw(r29+#512) = r5
		memw(r29+#540) = r4
	}
	{
		r3 = #48
		r5:4 = memd(r29+#248)
		memw(r29+#532) = r3
	}                                       // 8-byte Folded Reload
	{
		r4 = #1536
		memw(r29+#524) = r5
		memw(r29+#520) = r3
	}
	{
		r3 = memw(r18+#12)
		memw(r29+#544) = r3.new
	}
	{
		r3 = memw(r18+#8)
		memw(r29+#548) = r3.new
	}
	{
		r3 = #128
		memw(r29+#516) = r3.new
	}
	{
		r3 = memw(r18+#16)
		memw(r29+#552) = r3.new
	}
	{
		r3 = memw(r16+#36)
		memw(r29+#556) = r4
	}
	{
		memw(r29+#564) = r4
		memw(r29+#568) = r5
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#560) = r3
	}
	.falign
// %bb.20:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = add(pc,##tl2_gu_trace@PCREL)
		r3 = memw(r17+#0)
	}
	{
		p0 = cmp.eq(r3,#0)
		r3 = memw(r29+#520)
	}
	{
		r4 = mux(p0,#2,#0)
	}
	{
		r5 = addasl(r2,r4,#2)
	}
	.balign 32
.LBB27_21:                              // %atomicrmw.start
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r6 = memw_locked(r5)
	}
	{
		r6 = add(r6,#1)
	}
	{
		memw_locked(r5,p1) = r6
	}
	{
		if (!p1) jump:nt .LBB27_21
	}
// %bb.22:                              // %atomicrmw.end
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r4 = asl(r4,#2)
		r21 = #8
		r22 = #16
	}
	{
		r2 = add(r2,add(r4,#4))
	}
	.balign 32
.LBB27_23:                              // %atomicrmw.start156
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r4 = memw_locked(r2)
	}
	{
		r4 = add(r4,r3)
	}
	{
		memw_locked(r2,p0) = r4
	}
	{
		if (!p0) jump:nt .LBB27_23
	}
	{
		jump .LBB27_95
	}
	.falign
.LBB27_24:                              // %land.lhs.true2.if.then_crit_edge
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = memw(r25+#0)
	}
	.falign
.LBB27_25:                              // %if.then
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r27+#0)
	}
	{
		r17 = mpyi(r2,r17)
	}
	{
		r23 = mpyi(r2,r20)
		if (!cmp.gtu(r23.new,r17)) jump:t ##.LBB27_94
	}
// %bb.26:                              // %for.body.i.preheader
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = add(#127,asl(r24,#1))
	}
	{
		r24 = and(r24,#-128)
	}
	.falign
.LBB27_27:                              // %for.body.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_31 Depth 3
                                        //       Child Loop BB27_35 Depth 3
                                        //       Child Loop BB27_63 Depth 3
                                        //       Child Loop BB27_67 Depth 3
	{
		r18 = memw(r27+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.28:                              // %for.body.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r3:2 = combine(r19,r17)
		r5 = #1
		r6 = memw(r22+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB27_37
		v0 = vmem(r4+#0)
	}
// %bb.29:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r12 = mpyi(r5,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB27_33
	}
// %bb.30:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_31,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r4,r13,#2)
		v5.w = vadd(v0.w,v31.w)
		v31.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB27_32
	}
	.falign
.LBB27_31:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_27 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r24)
		v1.w = vadd(v5.w,v0.w)
		v0.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v2 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r5,#3)
		v3.w = vadd(v1.w,v2.w)
		v4 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r5 = add(r5,#4)
		v5.w = vadd(v3.w,v4.w)
		v6 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r4,r9,#2)
		v5.w = vadd(v5.w,v6.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_32:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r12 = addasl(r4,r12,#2)
		v8.w = vadd(v5.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		v9.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v10.w,v11.w)
		v11.cur = vmem(r12+#0)
	}
	.falign
.LBB27_33:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = mpyi(r5,r24)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB27_37
	}
// %bb.34:                              // %for.body13.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB27_35,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB27_36
	}
	.balign 32
.LBB27_35:                              // %for.body13.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_27 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r5,r24)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v12.w)
		v12.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_36:                              //   in Loop: Header=BB27_27 Depth=2
	{
		v0.w = vadd(v0.w,v13.w)
		v13.cur = vmem(r8+#0)
	}
	.falign
.LBB27_37:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r5 = memw(r3+#4)
		vmem(r29+#4) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r25+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB27_40
	}
// %bb.38:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB27_40
	}
// %bb.39:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_60
	}
	.falign
.LBB27_40:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_45
	}
// %bb.41:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_43
	}
// %bb.42:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB27_60
	}
	.falign
.LBB27_43:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		if (p1) jump:nt .LBB27_46
	}
// %bb.44:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_46
	}
	.falign
.LBB27_45:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_46:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB27_51
	}
// %bb.47:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB27_49
	}
// %bb.48:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_60
	}
	.falign
.LBB27_49:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB27_52
	}
// %bb.50:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_52
	}
	.falign
.LBB27_51:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r8 = r9
	}
	.falign
.LBB27_52:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_57
	}
// %bb.53:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_55
	}
// %bb.54:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB27_60
	}
	.falign
.LBB27_55:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB27_58
	}
// %bb.56:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_60
	}
	{
		jump .LBB27_58
	}
	.falign
.LBB27_57:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_58:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r8 = #3
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB27_60
	}
// %bb.59:                              // %if.end.i.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		v12.w = vasl(v0.w,r8)
	}
	{
		v13.w = vsub(v12.w,v0.w)
		vmem(r29+#4) = v13.new
	}
	.falign
.LBB27_60:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB27_69
		v1 = vmem(r7+#0)
	}
// %bb.61:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r12 = mpyi(r6,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB27_65
	}
// %bb.62:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_63,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r7,r13,#2)
		v4.w = vadd(v1.w,v14.w)
		v14.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB27_64
	}
	.falign
.LBB27_63:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_27 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r24)
		v16.w = vadd(v4.w,v15.w)
		v15.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v17 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r6,#3)
		v18.w = vadd(v16.w,v17.w)
		v19 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r6 = add(r6,#4)
		v20.w = vadd(v18.w,v19.w)
		v21 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r7,r9,#2)
		v4.w = vadd(v20.w,v21.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_64:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r12 = addasl(r7,r12,#2)
		v23.w = vadd(v4.w,v22.w)
		v22.cur = vmem(r13+#0)
	}
	{
		v25.w = vadd(v23.w,v24.w)
		v24.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v25.w,v26.w)
		v26.cur = vmem(r12+#0)
	}
	.falign
.LBB27_65:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r9 = mpyi(r6,r24)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB27_69
	}
// %bb.66:                              // %for.body13.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB27_67,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB27_68
	}
	.balign 32
.LBB27_67:                              // %for.body13.1.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_27 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r6,r24)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v27.w)
		v27.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_68:                              //   in Loop: Header=BB27_27 Depth=2
	{
		v1.w = vadd(v1.w,v28.w)
		v28.cur = vmem(r8+#0)
	}
	.falign
.LBB27_69:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		vmem(r29+#5) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_72
	}
// %bb.70:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_72
	}
// %bb.71:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB27_92
	}
	.falign
.LBB27_72:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_77
	}
// %bb.73:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_75
	}
// %bb.74:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_92
	}
	.falign
.LBB27_75:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		if (p0) jump:nt .LBB27_78
	}
// %bb.76:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB27_92
	}
	{
		jump .LBB27_78
	}
	.falign
.LBB27_77:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_78:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB27_83
	}
// %bb.79:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_81
	}
// %bb.80:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB27_92
	}
	.falign
.LBB27_81:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB27_84
	}
// %bb.82:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB27_92
	}
	{
		jump .LBB27_84
	}
	.falign
.LBB27_83:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r6 = r7
	}
	.falign
.LBB27_84:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_89
	}
// %bb.85:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_87
	}
// %bb.86:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_92
	}
	.falign
.LBB27_87:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_90
	}
// %bb.88:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB27_92
	}
	{
		jump .LBB27_90
	}
	.falign
.LBB27_89:                              //   in Loop: Header=BB27_27 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_90:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r6 = #3
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB27_92
	}
// %bb.91:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		v29.w = vasl(v1.w,r6)
	}
	{
		v30.w = vsub(v29.w,v1.w)
		vmem(r29+#5) = v30.new
	}
	.falign
.LBB27_92:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#512)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.93:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_27 Depth=2
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r23)) jump:t ##.LBB27_27
	}
	.falign
.LBB27_94:                              // %moe_tl2_gate_epilogue.exit
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r21 = #8
		r22 = #16
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB27_95:                              // %if.end
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_99
	}
// %bb.96:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #1
		r2 = #1
		r7:6 = memd(r16+#40)
		r0 = memw(r16+#36)
	}
	{
		r4 = r7
		r3 = memw(r25+#0)
		r5 = memw(r16+#48)
	}
	{
		memw(r29+#0) = r6
		memw(r29+#16) = #0
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_rows_u8_params_rm
		memw(r29+#4) = #0
	}
	.falign
// %bb.97:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = ##-1431655765
		r1 = memw(r25+#0)
		r0 = memw(r16+#40)
	}
	{
		r2 = add(r1,#23)
		r4 = memw(r16+#384)
	}
	{
		r3 = mpyu(r2,r3)
		r2 = #0
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
.LBB27_98:                              // %cleanup
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1:0 = memd(r29+#240)
	}                                       // 8-byte Folded Reload
	{
		p2 = cmp.gtu(r0,r20)
		if (p2.new) jump:t .LBB27_4
	}
	{
		jump .LBB27_122
	}
	.falign
.LBB27_99:                              // %if.end13
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	{
		r2 = add(r1,#3)
	}
	{
		r17 = and(r2,#-4)
		if (!cmp.gtu(r17.new,r1)) jump:t .LBB27_102
	}
// %bb.100:                             // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = mpyi(r3,r1)
		r2 = sub(r17,r1)
		r1 = #0
		r4 = memw(r16+#36)
	}
	{
		r2 = mpyi(r2,r3)
		r0 = addasl(r4,r5,#2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.101:                             // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	.falign
.LBB27_102:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r0 = memw(r16+#36)
		r4 = memw(r16+#44)
	}
	{
		call hvx_quant_rows_u8_params
		r5 = memw(r16+#48)
		memw(r29+#0) = #0

	} :mem_noshuf
	.falign
// %bb.103:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #0
		r7:6 = memd(r16+#40)
		r2 = memw(r16+#48)
	}
	{
		r5 = r7
		r0 = memw(r16+#36)
		r4 = memw(r25+#0)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r17,#0)
		memw(r29+#0) = r2
		memw(r29+#4) = r6
	}
	.falign
// %bb.104:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_98
	}
// %bb.105:                             // %if.then41
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = add(r16,#72)
		r9:8 = combine(#1,#0)
		r2 = memw(r16+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_98
	}
// %bb.106:                             // %for.body.lr.ph.i114
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = memw(r25+#0)
		r4 = memw(r16+#48)
	}
	{
		p2 = cmp.gtu(r3,#31)
		if (p2.new) r7 = add(r2,#3)
		if (p2.new) jump:t .LBB27_112
		r6 = memw(r16+#40)
	}
// %bb.107:                             // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r6 = add(r2,#3)
	}
	{
		r8 = lsr(r6,#2)
		r7:6 = combine(#1,#0)
	}
	{
		loop1(.LBB27_108,r8)
	}
	.falign
.LBB27_108:                             // Block address taken
                                        // %for.body.i116
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_109 Depth 3
	{
		r8 = addasl(r4,r6,#2)
		r9 = addasl(r5,r6,#2)
		r12 = add(r29,#512)
		r13 = #0
	}
	{
		v21.cur = vmem(r29+#3)
		vmem(r29+#4) = v21
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_109:                             // %for.body11.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_108 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r13,#2)
		r14 = memw(r8++#4)
		r15 = memw(r12+#0)
	}
	{
		r15 -= mpyi(r14,r3)
		if (p1) jump:nt .LBB27_111
		memw(r9++#4) = r15.new
	}
// %bb.110:                             // %for.body11.i
                                        //   in Loop: Header=BB27_109 Depth=3
	{
		r14 = add(r7,r13)
		r12 = add(r12,#32)
		r13 = add(r13,#1)
	}
	{
		p0 = cmp.gtu(r2,r14)
		if (p0.new) jump:t .LBB27_109
	}
	.falign
.LBB27_111:                             // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB27_108 Depth=2
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	{
		jump .LBB27_98
	}
	.falign
.LBB27_112:                             //   in Loop: Header=BB27_4 Depth=1
	{
		r12 = lsr(r7,#2)
		r7 = lsr(r3,#5)
	}
	{
		loop1(.LBB27_113,r12)
	}
	.falign
.LBB27_113:                             // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_115 Depth 3
                                        //       Child Loop BB27_119 Depth 3
	{
		r12 = addasl(r6,r8,#5)
		p1 = cmp.gtu(r7,#2)
		r13 = add(r7,#-2)
		p2 = cmp.gtu(r7,#1)
	}
	{
		r12 = add(r12,#2048)
		if (!p2) jump:nt .LBB27_117
		v3 = vmemu(r12+#0)
	}
// %bb.114:                             // %for.body4.us.i
                                        //   in Loop: Header=BB27_113 Depth=2
	{
		loop0(.LBB27_115,r13)
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		if (!p1) jump:nt .LBB27_116
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.balign 32
.LBB27_115:                             // %for.body4.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_113 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		v3 = v6
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		nop
	} :endloop0
	.falign
.LBB27_116:                             //   in Loop: Header=BB27_113 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		jump .LBB27_118
		v3 = v6
	}
	.falign
.LBB27_117:                             //   in Loop: Header=BB27_113 Depth=2
	{
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_118:                             //   in Loop: Header=BB27_113 Depth=2
	{
		r12 = addasl(r4,r8,#2)
		v2.uw += vrmpy(v3.ub,r26.ub)
		r14 = #0
		r15 = add(r29,#512)
	}
	{
		r13 = addasl(r5,r8,#2)
	}
	{
		v14 = valign(v2,v2,#4)
	}
	{
		v15.w = vadd(v2.w,v14.w)
	}
	{
		v16 = vror(v15,r21)
	}
	{
		v17.w = vadd(v15.w,v16.w)
	}
	{
		v18 = vror(v17,r22)
	}
	{
		v19.w = vadd(v17.w,v18.w)
		vmem(r29+#4) = v19.new
	}
	.falign
.LBB27_119:                             // %for.body11.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_113 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r14,#2)
		r28 = memw(r12++#4)
		r0 = memw(r15+#0)
	}
	{
		r0 -= mpyi(r28,r3)
		if (p1) jump:nt .LBB27_121
		memw(r13++#4) = r0.new
	}
// %bb.120:                             // %for.body11.us.i
                                        //   in Loop: Header=BB27_119 Depth=3
	{
		r28 = add(r9,r14)
		r15 = add(r15,#32)
		r14 = add(r14,#1)
	}
	{
		p0 = cmp.gtu(r2,r28)
		if (p0.new) jump:t .LBB27_119
	}
	.falign
.LBB27_121:                             // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB27_113 Depth=2
	{
		r8 = add(r8,#4)
		r9 = add(r9,#4)
		nop
	} :endloop1
	{
		jump .LBB27_98
	}
	.falign
.LBB27_122:                             // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end27:
	.size	moe_m1_requant_worker, .Lfunc_end27-moe_m1_requant_worker
                                        // -- End function
	.falign
	.type	moe_m1_down_worker,@function    // -- Begin function moe_m1_down_worker
moe_m1_down_worker:                     // @moe_m1_down_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r21 = add(r2,#8196)
		r22 = r1
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r21+#60)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r25 = r2
		r18 = memw(r21+#20)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r30+#-8) = r17:16
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r25
		r19 = add(r25,#8260)
		r16 = add(r22,#1)
		memw(r29+#212) = r25
	}                                       // 4-byte Folded Spill
	{
		r2 += asl(r0,#9)
		r24 = add(r19,#-40)
		memw(r29+#208) = r24.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+#8)
	}
	{
		r2 = memw(r2+#44)
	}
	{
		if (!p0.new) r17 = add(r0,#0)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB28_161
		if (!p0.new) r2 = memw(r19+#0)
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r0 = sub(r2,r23)
	}
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.3:                               // %if.then
	{
		r1 = r20
		r2 = memw(r24+#0)
	}
	{
		r2 = add(r2,#127)
	}
	{
		r18 = lsr(r2,#7)
	}
	{
		r23 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r23,r22)
		call __hexagon_udivsi3
		r22 = memw(r21+#4)
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r23,r16)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r20
	}
	.falign
// %bb.5:                               // %if.then
	{
		r20 = r0
		r2 = add(r22,#23)
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB28_222
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r3 = ##-1431655765
		r22 = add(r25,#8200)
		r23 = add(r25,#8240)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r2 = lsr(r2,#4)
	}
	{
		r26 = +mpyi(r2,##640)
	}
	.falign
.LBB28_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r27 = r25
		r2 = add(r0,r17)
		r16 = r19
		r1 = memw(r22+#0)
	}
	{
		r27 += asl(r2,#9)
		r16 -= mpyi(r0,r18)
		r3 = add(r29,#256)
	}
	{
		r0 = memw(r27+#16)
		r2 = memw(r27+#384)
	}
	{
		r0 += mpyi(r26,r16)
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r23+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB28_60
	}
// %bb.10:                              // %land.lhs.true.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = #64
	}
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB28_60
	}
// %bb.11:                              // %land.lhs.true19.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = #1536
	}
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB28_60
	}
// %bb.12:                              // %land.lhs.true22.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:t .LBB28_60
	}
// %bb.13:                              // %land.lhs.true25.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r27+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB28_60
	}
// %bb.14:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r27+#4)
	}
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_17
	}
// %bb.15:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_17
	}
// %bb.16:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_17:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_22
	}
// %bb.18:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_20
	}
// %bb.19:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_20:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_23
	}
// %bb.21:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_23
	}
	.falign
.LBB28_22:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_23:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_28
	}
// %bb.24:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_26
	}
// %bb.25:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_26:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_29
	}
// %bb.27:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_29
	}
	.falign
.LBB28_28:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_29:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_34
	}
// %bb.30:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB28_32
	}
// %bb.31:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_32:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_35
	}
// %bb.33:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r2); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_35
	}
	.falign
.LBB28_34:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = r3
	}
	.falign
.LBB28_35:                              // %htp_tl2_palette_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.gtu(r2,#1); if (p0.new) jump:t .LBB28_60
		if (!p0.new) r2 = memw(r27+#8)
	}
// %bb.36:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_39
	}
// %bb.37:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_39
	}
// %bb.38:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_39:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_44
	}
// %bb.40:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_42
	}
// %bb.41:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_42:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_45
	}
// %bb.43:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_45
	}
	.falign
.LBB28_44:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_45:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_50
	}
// %bb.46:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_48
	}
// %bb.47:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_48:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_51
	}
// %bb.49:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r3); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_51
	}
	.falign
.LBB28_50:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_51:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_56
	}
// %bb.52:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_54
	}
// %bb.53:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_54:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_57
	}
// %bb.55:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_57
	}
	.falign
.LBB28_56:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_57:                              // %htp_tl2_palette_magnitude.exit168.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r9 = asl(r16,#9)
		r0 = add(r29,#256)
		p1 = cmp.gtu(r4,#1); if (p1.new) jump:t .LBB28_60
	}
// %bb.58:                              // %if.then.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r8 = memw(r27+#44)
		r7:6 = memd(r27+#48)
	}
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r3 = add(r5,r9)
		r5 = add(r2,r9)
		r4 = add(r4,r9)
		r2 = memw(r6+#0)
	}
	{
		call hvx_dequant_acc_4tiles_m1_f32
		r6 = add(r7,r9)
		r1 = memw(r8+#0)
		memw(r29+#0) = r6.new
	}
	.falign
// %bb.59:                              // %if.then.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		jump .LBB28_160
	}
	.falign
.LBB28_60:                              // %if.end.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r25 = asl(r16,#7)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r25)) jump:t ##.LBB28_160
	}
// %bb.61:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r6 = memw(r27+#8)
	}
	{
		r3 = memb(r6+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_64
	}
// %bb.62:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_64
	}
// %bb.63:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_64:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r6+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_69
	}
// %bb.65:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_67
	}
// %bb.66:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_67:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_70
	}
// %bb.68:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_70
	}
	.falign
.LBB28_69:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_70:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r6+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_75
	}
// %bb.71:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_73
	}
// %bb.72:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_73:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_76
	}
// %bb.74:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_76
	}
	.falign
.LBB28_75:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_76:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r6+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_81
	}
// %bb.77:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_79
	}
// %bb.78:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_84
	}
	.falign
.LBB28_79:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_82
	}
// %bb.80:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_82
	}
	.falign
.LBB28_81:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_82:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = #3
		p0 = cmp.eq(r4,#7); if (!p0.new) jump:t .LBB28_84
	}
// %bb.83:                              // %if.end.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v2.w = vasl(v1.w,r3)
		v1.cur = vmem(r29+#2)
	}
	{
		v3.w = vsub(v2.w,v1.w)
		vmem(r29+#2) = v3.new
	}
	.falign
.LBB28_84:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r29,#256)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r6+#8)
	}
	{
		r3 = memw(r27+#44)
		r6 = memw(r6+#16)
	}
	{
		r2 = addasl(r5,r25,#2)
		r5 = addasl(r9,r25,#2)
		memw(r29+#12) = r2
		memw(r29+#16) = #0
	}
	{
		r2 = addasl(r6,r25,#2)
		memw(r29+#8) = r2
	}
	{
		r2 = addasl(r8,r25,#2)
		memw(r29+#4) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
		r2 = #1
		memw(r29+#0) = r2
	}
	.falign
// %bb.85:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = setbit(r25,#5)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB28_160
	}
// %bb.86:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_89
	}
// %bb.87:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_89
	}
// %bb.88:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_89:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_94
	}
// %bb.90:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_92
	}
// %bb.91:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_92:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_95
	}
// %bb.93:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_95
	}
	.falign
.LBB28_94:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_95:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_100
	}
// %bb.96:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_98
	}
// %bb.97:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_98:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB28_101
	}
// %bb.99:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_101
	}
	.falign
.LBB28_100:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_101:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_106
	}
// %bb.102:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_104
	}
// %bb.103:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_109
	}
	.falign
.LBB28_104:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_107
	}
// %bb.105:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_107
	}
	.falign
.LBB28_106:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_107:                             // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB28_109
	}
// %bb.108:                             // %if.end.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v5.w = vasl(v4.w,r4)
		v4.cur = vmem(r29+#3)
	}
	{
		v6.w = vsub(v5.w,v4.w)
		vmem(r29+#3) = v6.new
	}
	.falign
.LBB28_109:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#128)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.110:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = setbit(r25,#6)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB28_160
	}
// %bb.111:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_114
	}
// %bb.112:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_114
	}
// %bb.113:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_114:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_119
	}
// %bb.115:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB28_117
	}
// %bb.116:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_117:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_120
	}
// %bb.118:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_120
	}
	.falign
.LBB28_119:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_120:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_125
	}
// %bb.121:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_123
	}
// %bb.122:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_123:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB28_126
	}
// %bb.124:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,r4); if (!p0.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_126
	}
	.falign
.LBB28_125:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_126:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_131
	}
// %bb.127:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB28_129
	}
// %bb.128:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_134
	}
	.falign
.LBB28_129:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_132
	}
// %bb.130:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_132
	}
	.falign
.LBB28_131:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_132:                             // %for.inc.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p0 = cmp.eq(r5,#7); if (!p0.new) jump:t .LBB28_134
	}
// %bb.133:                             // %if.end.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v8.w = vasl(v7.w,r4)
		v7.cur = vmem(r29+#4)
	}
	{
		v9.w = vsub(v8.w,v7.w)
		vmem(r29+#4) = v9.new
	}
	.falign
.LBB28_134:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#256)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.135:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r6 = or(r25,#96)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r6)) jump:t .LBB28_160
	}
// %bb.136:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_139
	}
// %bb.137:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_139
	}
// %bb.138:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_139:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_144
	}
// %bb.140:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_142
	}
// %bb.141:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_142:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_145
	}
// %bb.143:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_145
	}
	.falign
.LBB28_144:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_145:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_150
	}
// %bb.146:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_148
	}
// %bb.147:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_148:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB28_151
	}
// %bb.149:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_151
	}
	.falign
.LBB28_150:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_151:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_156
	}
// %bb.152:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_154
	}
// %bb.153:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_159
	}
	.falign
.LBB28_154:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_157
	}
// %bb.155:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_157
	}
	.falign
.LBB28_156:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_157:                             // %for.inc.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB28_159
	}
// %bb.158:                             // %if.end.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v11.w = vasl(v10.w,r4)
		v10.cur = vmem(r29+#5)
	}
	{
		v12.w = vsub(v11.w,v10.w)
		vmem(r29+#5) = v12.new
	}
	.falign
.LBB28_159:                             // %moe_tl2_restore_magnitude.exit.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#384)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r6,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#8) = r5
	}
	{
		r7 = addasl(r7,r6,#2)
		r6 = addasl(r8,r6,#2)
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
.LBB28_160:                             // %cleanup.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r19 = add(r19,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r20,r19.new)) jump:t ##.LBB28_7
	}                                       // 4-byte Folded Reload
	{
		jump .LBB28_222
	}
	.falign
.LBB28_161:                             // %if.end
	{
		r24 = add(r25,#8232)
		r2 = memw(r21+#28)
	}
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r3 = p1
		if (p1) jump:nt .LBB28_163
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.162:
	{
		p0 = or(p0,!p0)
		r26 = add(r25,#8204)
	}
	{
		r3 = p0
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB28_164
	}
	{
		jump .LBB28_165
	}
	.falign
.LBB28_163:                             // %lor.rhs
	{
		r26 = add(r25,#8204)
		r3 = memw(r24+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_165
	}
	.falign
.LBB28_164:                             // %land.lhs.true
	{
		r0 = #2
		r4 = memw(r24+#0)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r4,#0); if (!p1.new) jump:t .LBB28_167
	}
	.falign
.LBB28_165:                             // %cond.false
	{
		r4 = #512
		r1:0 = combine(#0,r2)
		r5 = memw(r26+#0)
	}
	{
		r2 = lsr(r4,r3)
		r1:0 = asl(r1:0,#10)
		r3 = #0
	}
	{
		r2 = mpyi(r5,r2)
		call __hexagon_udivdi3
	}
	.falign
// %bb.166:                             // %cond.false
	{
		r2 = #1
		r3 = #127
	}
	{
		r2 = maxu(r0,r2)
	}
	{
		r2 = minu(r2,r3)
		memw(r29+#240) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_167:                             // %cond.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r21 = #0
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_170
	}
// %bb.168:                             // %if.then12
	{
		r17 = add(r25,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.169:                             // %if.then12
	{
		jump .LBB28_171
		r23 = memw(r17+#0)
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB28_170:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB28_171:                             // %do.end
	{
		r2 = memw(r19+#0)
	}
	{
		r18 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r18,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.172:                             // %do.end
	{
		r1:0 = mpyu(r18,r16)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.173:                             // %do.end
	{
		r2 = add(r23,r0)
		r27 = add(r25,#8236)
		r18 = add(r25,#8216)
		memw(r29+#232) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB28_218
		if (p1.new) r20 = memw(r18+#0)
	}
// %bb.174:                             // %cond.end22
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.175:                             // %cond.end22
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r19 = minu(r2,r3)
		r3 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) r3 = sub(r19,r17)
		if (p1.new) jump:nt .LBB28_181
	}
// %bb.176:                             // %cond.end22
	{
		if (p0.new) r4 = add(r25,#0)
		if (p0.new) r2 = add(r17,#0)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB28_181
	}
// %bb.177:                             // %if.then28
	{
		r4 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		r1 = r20
	}
	{
		r6 = memw(r4+#8)
		r4 = memw(r26+#0)
	}
	{
		r0 = memw(r6+#4)
	}
	{
		r5 = memw(r27+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_180
	}
// %bb.178:                             // %if.then.i270
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.179:                             // %if.then.i270
	{
		jump .LBB28_181
	}
	.falign
.LBB28_180:                             // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB28_181:                             // %for.body.lr.ph
	{
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
	}
	{
		memw(r29+#220) = r4
	}                                       // 4-byte Folded Spill
	{
		r16 = add(r25,#8228)
		if (!p1) r2 = add(r3,#0)
		if (p1) r2 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		memw(r29+#216) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_182:                             // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB28_191 Depth 2
                                        //       Child Loop BB28_205 Depth 3
	{
		r20 = r17
		r17 = r19
		r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r19)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB28_185
		memw(r29+#228) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.183:                             // %cond.true34
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r21 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r19)
	}
	.falign
// %bb.184:                             // %cond.true34
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r21)
		r3 = add(r19,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r19 = minu(r2,r0)
	}
	.falign
.LBB28_185:                             // %cond.end38
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB28_190
	}
// %bb.186:                             // %cond.end38
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r19,r17); if (!p0.new) jump:nt .LBB28_190
		if (p0.new) r21 = memw(r18+#0)
	}
// %bb.187:                             // %if.then44
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.188:                             // %if.then44
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = r25
		r1 = r21
		r3 = memw(r27+#0)
		r4 = memw(r26+#0)
	}
	{
		r2 += asl(r0,#9)
		p1 = cmp.eq(r3,#0)
		r3 = sub(r19,r17)
	}
	{
		r2 = r17
		r5 = memw(r2+#8)
	}
	{
		r2 -= mpyi(r0,r21)
	}
	{
		if (p1) jump:nt .LBB28_216
		r0 = memw(r5+#4)
	}
// %bb.189:                             // %if.then.i291
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB28_190:                             // %if.end45
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB28_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_191:                             // %for.body50
                                        //   Parent Loop BB28_182 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB28_205 Depth 3
	{
		r23 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r20)
	}
	.falign
// %bb.192:                             // %for.body50
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r25 += asl(r0,#9)
		r22 = r20
		r19 = add(r20,#1)
	}
	{
		r22 -= mpyi(r0,r23)
	}
	{
		r21 = memw(r25+#32)
	}
	{
		r21 += asl(r22,#9)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_197
	}
// %bb.193:                             // %land.lhs.true61
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = add(r25,#256)
		r2 = memw(r24+#0)
		r0 = memw(r25+#40)
	}
	{
		p0 = cmp.eq(r2,#0)
		if (!p0.new) r6 = add(r22,#1)
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		if (!p0) r7 = add(r21,##512)
		if (p0) jump:nt .LBB28_199
		r3 = memw(r25+#16)
	}
// %bb.194:                             // %land.lhs.true61
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r17,r19); if (!p1.new) jump:nt .LBB28_199
	}
// %bb.195:                             // %if.then68
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#8) = r4

	} :mem_noshuf
	{
		r5:4 = combine(r22,r23)
		memw(r29+#4) = r5
		memw(r29+#12) = r21
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#16) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.196:                             // %if.then68
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB28_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_197:                             // %if.else87
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = memw(r16+#0)
		r0 = memw(r25+#40)
	}
	{
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		r5:4 = combine(r22,r23)
		r3 = memw(r25+#16)
		memw(r29+#0) = r4

	} :mem_noshuf
	{
		r6 = memw(r29+#216)
		memw(r29+#4) = r21
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.198:                             // %if.else87
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p0 = or(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB28_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_199:                             // %if.then76
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#0) = r5.new
	}
	{
		r5:4 = combine(r22,r23)
		r6 = memw(r29+#220)
		memw(r29+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r21
	}
	{
		callr r6
	}
	.falign
// %bb.200:                             // %if.then76
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_201:                             // %if.end97
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r22 = asl(r22,#5)
		r6 = memw(r25+#8)
		r23 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r6+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_210
	}
// %bb.202:                             // %if.then100
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = add(r25,#72)
		r2 = memw(r25+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_210
	}
// %bb.203:                             // %for.body.us.i
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r6 = addasl(r3,r22,#2)
		r3 = lsr(r2,#1)
		r4 = and(r2,#1)
	}
	{
		p0 = cmp.gtu(r3,#0)
		if (!p0.new) r3 = add(r21,#0)
		r2 = r5
	}
	{
		if (!p0) jump:nt .LBB28_208
		v0 = vmemu(r6+#0)
	}
// %bb.204:                             //   in Loop: Header=BB28_191 Depth=2
	{
		loop0(.LBB28_205,r3)
		r6 = r21
		r3 = r21
	}
	.balign 32
.LBB28_205:                             //   Parent Loop BB28_182 Depth=1
                                        //     Parent Loop BB28_191 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r2++#8)
	}
	{
		v13 = vsplat(r7)
		v14 = vmemu(r6+#0)
	}
	{
		v16 = vmemu(r6+#1)
	}
	{
		v14.w += vmpyie(v13.w,v0.h)
	}
	{
		vmemu(r3++#2) = v14
	}
	{
		r5 = memw(r5+#4)
	}
	{
		v15 = vsplat(r5)
		r5 = r2
	}
	{
		v16.w += vmpyie(v15.w,v0.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v16
	} :endloop0
// %bb.206:                             //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (!p1.new) jump:t .LBB28_209
	}
	.falign
.LBB28_207:                             // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = memw(r2+#0)
	}
	{
		v17 = vsplat(r4)
		v18 = vmemu(r3+#0)
	}
	{
		v18.w += vmpyie(v17.w,v0.h)
	}
	{
		jump .LBB28_209
		vmemu(r3++#1) = v18
	}
	.falign
.LBB28_208:                             //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (p1.new) jump:t .LBB28_207
	}
	.falign
.LBB28_209:                             // %if.end106.loopexit
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r6 = memw(r25+#8)
	}
	.falign
.LBB28_210:                             // %if.end106
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5:4 = memd(r25+#48)
		r7 = memw(r6+#16)
	}
	{
		r0 = addasl(r7,r22,#2)
		r5 = addasl(r5,r22,#2)
		r9:8 = memd(r6+#8)
		r1 = memw(r23+#0)
	}
	{
		r6 = addasl(r9,r22,#2)
		r7 = addasl(r8,r22,#2)
		r2 = memw(r25+#388)
		r3 = memw(r25+#44)
	}
	{
		r5 = r6
		memw(r29+#8) = r5
		memw(r29+#12) = r1
	}
	{
		r1:0 = combine(#32,r21)
		memw(r29+#4) = r0
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r7
	}
	.falign
// %bb.211:                             // %if.end106
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r2 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB28_214
		if (!p0.new) r5:4 = memd(r25+#48)
		if (!p0.new) r6 = memw(r25+#8)
	}
// %bb.212:                             // %if.then116
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r22 = add(#128,asl(r22,#2))
		r1 = #32
		r0 = add(r21,#512)
		r2 = memw(r25+#388)
	}
	{
		r5 = add(r5,r22)
		r3 = memw(r25+#44)
		r9:8 = memd(r6+#8)
	}
	{
		r12 = memw(r6+#16)
	}
	{
		r6 = add(r9,r22)
		r7 = memw(r23+#0)
		memw(r29+#8) = r5

	} :mem_noshuf
	{
		r7 = add(r12,r22)
		r6 = add(r8,r22)
		r5 = r6
		memw(r29+#12) = r7
	}
	{
		memw(r29+#16) = #0
		memw(r29+#4) = r7
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.213:                             // %if.then116
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r20 = r19
	}
	.falign
.LBB28_214:                             // %if.end134
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r20 = add(r20,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r17,r20.new)) jump:t .LBB28_191
	}                                       // 4-byte Folded Reload
	.falign
.LBB28_215:                             // %for.cond.loopexit
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r19 = memw(r29+#224)
		r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB28_182
	}
	{
		jump .LBB28_218
	}
	.falign
.LBB28_216:                             // %if.else.i293
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.217:                             // %if.else.i293
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB28_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	{
		jump .LBB28_191
	}
	.falign
.LBB28_218:                             // %for.cond.cleanup
	{
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_222
	}
// %bb.219:                             // %if.then.i273
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.220:                             // %if.then.i273
	{
		r3:2 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB28_221:                             // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB28_221
	}
	.falign
.LBB28_222:                             // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end28:
	.size	moe_m1_down_worker, .Lfunc_end28-moe_m1_down_worker
                                        // -- End function
	.falign
	.type	moe_push_act_block,@function    // -- Begin function moe_push_act_block
moe_push_act_block:                     // @moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17 = asl(r5,#11)
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(r3,r4)
		r19 = r2
		memd(r29+#32) = r19:18
		memd(r29+#24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r23:22 = combine(r0,r1)
		if (p0) jump:nt .LBB29_2
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = tstbit(r5,#0)
		p0 = bitsclr(r5,#3)
		if (p1.new) r16 = ##2048
	}
	{
		if (!p1) r16 = ##4096
	}
	{
		if (p0) r16 = ##8192
		jump .LBB29_3
	}
	.falign
.LBB29_2:
	{
		r16 = #16384
	}
	.falign
.LBB29_3:                               // %hexkl_moe_push_act_block.exit
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.4:                               // %hexkl_moe_push_act_block.exit
	{
		call __hexagon_udivsi3
		r18 = r0
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.5:                               // %hexkl_moe_push_act_block.exit
	{
		r19 += mpyi(r20,r21)
		r5:4 = combine(r0,r16)
		r0 = add(r23,r22)
		r3:2 = combine(r16,r16)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r19
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.6:                               // %hexkl_moe_push_act_block.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB29_9
	}
// %bb.7:                               // %if.then
	{
		r19 = memw(r29+#60)
		r20 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r23:22 = c31:30
	}
	//# InlineAsm End
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.8:                               // %if.then
	{
		r5:4 = combine(r19,r20)
		r1:0 = combine(r23,r22)
		r3:2 = combine(#0,r18)
		memw(r29+#4) = r0
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#0) = r16
		memw(r29+#8) = r16
	}
	.falign
.LBB29_9:                               // %if.end
	{
		r0 = r18
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end29:
	.size	moe_push_act_block, .Lfunc_end29-moe_push_act_block
                                        // -- End function
	.falign
	.type	moe_expand_submit,@function     // -- Begin function moe_expand_submit
moe_expand_submit:                      // @moe_expand_submit
// %bb.0:                               // %entry
	{
		r17:16 = combine(r2,r3)
		r8 = add(r4,r5)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r18 = r1
		r3 = memw(r29+#48)
		memd(r29+#16) = r19:18
	}
	{
		r9 = memw(r29+#60)
		memd(r29+#8) = r21:20
	}
	{
		p1 = cmp.eq(r9,#-1)
		r6 = memw(r29+#44)
		r14 = memw(r29+#52)
	}
	{
		r12 = memw(r29+#64)
		memd(r29+#0) = r23:22
	}
	{
		r4 = r12
		r13 = memw(r29+#56)
		r7 = memw(r29+#40)
	}
	{
		r2 = asl(r14,#9)
		memw(r2+#152) = #0
		memw(r17+#8) = #1
	}
	{
		r4 = and(##2147483392,asl(r4,#8))
		r2 = r8
		memw(r17+#12) = r2
	}
	{
		r2 += asl(r13,#9)
		r5:4 = combine(r3,r4)
		if (!p1) r3 = add(r8,#0)
		if (!p1) memw(r17+#8) = #2
	}
	{
		r2 = add(r6,#88)
		if (p1) jump:nt .LBB30_8
		memw(r17+#0) = r2
		memd(r17+#16) = r5:4
	}
// %bb.1:                               // %if.end.thread
	{
		r3 += asl(r9,#9)
		memw(r17+#4) = r3.new
	}
	{
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB30_18
	}
// %bb.2:                               // %for.body.i
	{
		r12 = lsr(r13,#2)
		r15:14 = combine(#0,#1)
		r3 = add(r12,#3)
	}
	{
		r4 = add(r3,r13)
	}
	{
		r13 = lsr(r4,#2)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r13,r12)
		if (p0.new) r13 = sub(r13,r12)
		if (!p0.new) jump:t .LBB30_5
	}
// %bb.3:
	{
		loop0(.LBB30_4,r13)
	}
	.falign
.LBB30_4:                               // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r15:14,r12)
		r12 = add(r12,#1)
	} :endloop0
	.falign
.LBB30_5:                               // %for.cond.cleanup7.i
	{
		r3 = lsr(r9,#2)
		r12 = add(r3,r9)
	}
	{
		r9 = lsr(r12,#2)
	}
	{
		r13:12 = combine(#0,#1)
		p1 = cmp.gtu(r9,r3)
		if (p1.new) r9 = sub(r9,r3)
		if (!p1.new) jump:t .LBB30_12
	}
// %bb.6:
	{
		loop0(.LBB30_7,r9)
	}
	.falign
.LBB30_7:                               // Block address taken
                                        // %for.body8.i.1
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	{
		jump .LBB30_12
	}
	.falign
.LBB30_8:                               // %if.end
	{
		r4 = add(r12,add(r13,#3))
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB30_18
	}
// %bb.9:                               // %for.body.i.us
	{
		r3 = lsr(r13,#2)
	}
	{
		r9 = lsr(r4,#2)
		r13:12 = combine(#0,#1)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r9,r3)
		if (p0.new) r9 = sub(r9,r3)
		if (!p0.new) jump:t .LBB30_12
	}
// %bb.10:
	{
		loop0(.LBB30_11,r9)
	}
	.falign
.LBB30_11:                              // Block address taken
                                        // %for.body8.i.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB30_12:                              // %for.cond.cleanup.i
	{
		r11:10 = combine(r7,r8)
		r14 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r12 = ##-1431655765
		r7 = add(r14,#23)
		r13 = add(r3,#127)
	}
	{
		r7 = mpyu(r7,r12)
		p0 = cmp.gtu(r13,#127)
		r15 = add(r14,#95)
		r9:8 = memd(r6+#56)
	}
	{
		r28 = mpyu(r15,r12)
		r15 = lsr(r13,#7)
		memd(r17+#152) = r11:10
		memw(r17+#184) = #0
	}
	{
		r1 = lsr(r7,#4)
		r7 = lsr(r28,#6)
		r11:10 = combine(r15,r14)
	}
	{
		r14 = +mpyi(r1,##640)
		r13:12 = and(r5:4,~r9:8)
		memd(r17+#168) = r11:10
	}
	{
		r11:10 = combine(r14,r7)
		if (p0) r14 = #0
		memd(r17+#160) = r13:12
	}
	{
		if (!p0) jump:nt .LBB30_21
		memd(r17+#176) = r11:10
	}
// %bb.13:
	{
		r1 = lsr(r15,#1)
		r21:20 = combine(#0,#1)
		r11:10 = combine(#0,#0)
	}
	{
		r28 = and(r15,#1)
		if (!p1.new) r15 = #0
		p1 = cmp.gtu(r1,#0); if (!p1.new) jump:t .LBB30_20
	}
// %bb.14:
	{
		loop0(.LBB30_15,r1)
		r15 = #0
	}
	.falign
.LBB30_15:                              // =>This Inner Loop Header: Depth=1
	{
		r23:22 = combine(r13,r12)
		r1 = add(r14,r7)
		r19 = add(r15,#1)
	}
	{
		r23:22 &= asl(r21:20,r15)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r23:22 = combine(r13,r12)
	}
	{
		r23:22 &= asl(r21:20,r19)
		if (!p0) r14 = add(r1,#0)
		if (!p0) memw(r17+#184) = r1
	}
	{
		p1 = cmp.eq(r23:22,r11:10)
		r19 = add(r14,r7)
	}
	{
		if (!p1) r14 = add(r19,#0)
		if (!p1) memw(r17+#184) = r19
	} :endloop0
// %bb.16:
	{
		p0 = cmp.gtu(r28,#0)
		if (!p0.new) jump:t .LBB30_21
	}
	.falign
.LBB30_17:                              // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r21:20,r15)
		r7 = add(r14,r7)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		jump .LBB30_21
		if (!p1.new) memw(r17+#184) = r7
	}
	.falign
.LBB30_18:                              // %if.else
	{
		call hvx_expand_i2i4_table
		r1 = add(r17,#24)
		r19 = r0
		r0 = r2
	}
	.falign
// %bb.19:                              // %if.else
	{
		r0 = r19 ; jump .LBB30_44
	}
	.falign
.LBB30_20:
	{
		p0 = cmp.gtu(r28,#0)
		if (p0.new) jump:t .LBB30_17
	}
	.falign
.LBB30_21:                              // %for.cond.cleanup24.i
	{
		r2 = memb(r2+#0)
	}
	{
		r7 = abs(r2)
		r2 = #0
	}
	{
		p1 = cmp.eq(r7,#0); if (p1.new) jump:nt .LBB30_24
	}
// %bb.22:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#7); if (p0.new) jump:nt .LBB30_24
	}
// %bb.23:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB30_43
	}
	.falign
.LBB30_24:                              // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB30_29
	}
// %bb.25:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB30_27
	}
// %bb.26:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB30_43
	}
	.falign
.LBB30_27:                              // %lor.lhs.false.1.i.i
	{
		if (p1) jump:nt .LBB30_30
	}
// %bb.28:                              // %lor.lhs.false.1.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB30_43
	}
	{
		jump .LBB30_30
	}
	.falign
.LBB30_29:
	{
		r12 = r7
	}
	.falign
.LBB30_30:                              // %for.inc.1.i.i
	{
		r7 = memb(r6+#90)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB30_35
	}
// %bb.31:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r7,#7); if (p1.new) jump:nt .LBB30_33
	}
// %bb.32:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB30_43
	}
	.falign
.LBB30_33:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,#0)
		if (p1.new) jump:nt .LBB30_36
	}
// %bb.34:                              // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,r7)
		if (!p0.new) jump:t .LBB30_43
	}
	{
		jump .LBB30_36
	}
	.falign
.LBB30_35:
	{
		r7 = r12
	}
	.falign
.LBB30_36:                              // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB30_41
	}
// %bb.37:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB30_39
	}
// %bb.38:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB30_43
	}
	.falign
.LBB30_39:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r7,#0); if (p0.new) jump:nt .LBB30_42
	}
// %bb.40:                              // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB30_43
	}
	{
		jump .LBB30_42
	}
	.falign
.LBB30_41:
	{
		r12 = r7
	}
	.falign
.LBB30_42:                              // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r2 = maxu(r12,r2)
	}
	.falign
.LBB30_43:                              // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r17+#188) = r2
	}
	{
		memw(r17+#12) = r3
		memd(r6+#56) = r5:4
	}
	.falign
.LBB30_44:                              // %if.end13
	{
		r2 = add(pc,##moe_expand_unit@PCREL)
		r1 = r18
		memw(r18+#4) = r17
	}
	{
		memw(r18+#12) = r16
		memw(r18+#0) = r2
	}
	{
		r17:16 = memd(r29+#24)
		memw(r18+#8) = #8
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#16)
		r21:20 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hvx_worker_pool_submit_bg
		r23:22 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
.Lfunc_end30:
	.size	moe_expand_submit, .Lfunc_end30-moe_expand_submit
                                        // -- End function
	.falign
	.type	moe_gu_worker,@function         // -- Begin function moe_gu_worker
moe_gu_worker:                          // @moe_gu_worker
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB31_5
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r5:4 = c31:30
	}
	//# InlineAsm End
	{
		r20 = r0
		r1:0 = combine(r5,r4)
		r19 = r1
		r16 = r2
	}
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = r16
		r17:16 = combine(r1,r0)
		r1:0 = combine(r19,r20)
	}
	{
		r3 = memw(r2+#60)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB31_6
	}
	.falign
.LBB31_3:                               // %if.then2
	{
		call hvx_dq_swiglu_i24
	}
	.falign
// %bb.4:                               // %if.then2
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB31_11
	}
	{
		jump .LBB31_14
	}
	.falign
.LBB31_5:
	{
		r17:16 = combine(#0,#0)
		r3 = memw(r2+#60)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB31_3
	}
	.falign
.LBB31_6:                               // %if.else
	{
		r3 = memw(r2+#64)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB31_9
	}
// %bb.7:                               // %if.then4
	{
		call hvx_dq_swiglu_affine
		r4 = add(r2,#68)
	}
	.falign
// %bb.8:                               // %if.then4
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB31_11
	}
	{
		jump .LBB31_14
	}
	.falign
.LBB31_9:                               // %if.else7
	{
		call hvx_dq_swiglu_worker
	}
	.falign
// %bb.10:                              // %if.else7
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB31_14
	}
	.falign
.LBB31_11:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB31_13:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB31_13
	}
	.falign
.LBB31_14:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end31:
	.size	moe_gu_worker, .Lfunc_end31-moe_gu_worker
                                        // -- End function
	.falign
	.type	moe_dn_worker,@function         // -- Begin function moe_dn_worker
moe_dn_worker:                          // @moe_dn_worker
// %bb.0:                               // %entry
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r0)
		r20 = r2
		memd(r29+#56) = r21:20
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#48) = r23:22
		memd(r29+#40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#32) = r27:26
		memw(r29+#20) = r3
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB32_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB32_4
	}
	{
		jump .LBB32_13
	}
	.falign
.LBB32_3:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB32_13
	}
	.falign
.LBB32_4:                               // %if.then2
	{
		r19:18 = vaslw(r17:16,#6)
		r27:26 = vaslw(r17:16,#4)
		p0 = cmp.gtu(r17,#3); if (p0.new) jump:t .LBB32_13
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r25 = sub(#0,r27)
		r2 = memw(r20+#860)
	}
	{
		r2 = add(r2,#3)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r5 = and(r2,#-4)
		memw(r29+#16) = r5.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB32_6:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r5,r27)
		if (!p1.new) jump:nt .LBB32_13
		if (p1.new) r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
// %bb.7:                               // %if.end6
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r2 = add(r2,r25)
		r3 = memw(r20+#864)
		r4 = memw(r20+#860)
	}
	{
		r0 = mpyi(r3,r27)
		p0 = cmp.gtu(r2,#15)
		r2 = add(r25,r4)
		r1 = memw(r20+#856)
	}
	{
		r24 = addasl(r1,r0,#2)
		if (p0) r21 = add(r27,#16)
		if (!p0) r21 = add(r5,#0)
	}
	{
		r22 = add(r21,r25)
	}
	{
		r4 = maxu(r22,r2)
		r23 = minu(r2,r22)
		p1 = cmp.gtu(r22,r2); if (!p1.new) jump:t .LBB32_10
	}
// %bb.8:                               // %if.then24
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r5 = mpyi(r23,r3)
		r1 = #0
	}
	{
		r0 = addasl(r24,r5,#2)
		r2 = sub(r4,r2)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.9:                               // %if.then24
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r3 = memw(r20+#864)
	}
	.falign
.LBB32_10:                              // %for.inc
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r1:0 = combine(r23,r24)
		r5 = memw(r20+#872)
		r2 = memw(r20+#868)
	}
	{
		r4 = add(r2,r19)
		r5 = add(r5,r19)
		r2 = r22
		memw(r29+#0) = #0
	}
	{
		call hvx_quant_rows_u8_params
	}
	.falign
// %bb.11:                              // %for.inc
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r1 = #0
		r2 = memw(r20+#872)
		r4 = memw(r20+#864)
	}
	{
		r3 = memw(r20+#876)
		r0 = memw(r20+#856)
	}
	{
		r5 = memw(r20+#868)
		memw(r29+#4) = r3

	} :mem_noshuf
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r21,r27)
		memw(r29+#0) = r2
	}
	.falign
// %bb.12:                              // %for.inc
                                        //   in Loop: Header=BB32_6 Depth=1
	{
		r27 = add(r27,r26)
		r25 = sub(r25,r26)
		r19 = add(r19,r18)
		r5 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r17,r16)
		if (!cmp.gtu(r17.new,#3)) jump:t .LBB32_6
	}
	.falign
.LBB32_13:                              // %if.end44
	{
		r16 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB32_17
	}
// %bb.14:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.15:                              // %if.then.i
	{
		r3:2 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB32_16:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB32_16
	}
	.falign
.LBB32_17:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end32:
	.size	moe_dn_worker, .Lfunc_end32-moe_dn_worker
                                        // -- End function
	.falign
	.type	moe_dn_unit,@function           // -- Begin function moe_dn_unit
moe_dn_unit:                            // @moe_dn_unit
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#0) = r21:20
		memd(r29+#8) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r1,r2)
	}
	{
		r3 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB33_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = combine(r1,r0)
		jump .LBB33_4
	}
	.falign
.LBB33_3:
	{
		r17:16 = combine(#0,#0)
	}
	.falign
.LBB33_4:                               // %do.end
	{
		r1 = asl(r19,#2)
		r0 = r18
		r2 = #4
		r3 = memw(r18+#20)
	}
	{
		r2 = addasl(r2,r19,#2)
		r4 = sub(r3,r1)
	}
	{
		call moe_dn_rows
		p1 = cmp.gtu(r4,#3)
		if (!p1.new) r2 = add(r3,#0)
	}
	.falign
// %bb.5:                               // %do.end
	{
		r2 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB33_9
	}
// %bb.6:                               // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB33_8:                               // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r20+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB33_8
	}
	.falign
.LBB33_9:                               // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end33:
	.size	moe_dn_unit, .Lfunc_end33-moe_dn_unit
                                        // -- End function
	.falign
	.type	moe_dn_fg_worker,@function      // -- Begin function moe_dn_fg_worker
moe_dn_fg_worker:                       // @moe_dn_fg_worker
// %bb.0:                               // %entry
	{
		r17 = r0
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r20 = r1
		r16 = memw(r2+#4)
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#16) = r19:18
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r16+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_2
	}
// %bb.1:                               // %if.then
	{
		call moe_dn_worker
		r1:0 = combine(r20,r17)
		r2 = r16
	}
	.falign
.LBB34_2:                               // %if.end
	{
		r21 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_5
	}
// %bb.3:                               // %if.then3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.4:                               // %if.then3
	{
		r19:18 = combine(r1,r0)
		jump .LBB34_6
	}
	.falign
.LBB34_5:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB34_6:                               // %do.end
	{
		r1 = r17
		r22 = memw(r16+#20)
	}
	{
		r0 = mpyi(r22,r20)
		call __hexagon_udivsi3
	}
	.falign
// %bb.7:                               // %do.end
	{
		r20 = r0
		r1 = r17
		r2 = add(r20,#1)
	}
	{
		r0 = mpyi(r22,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %do.end
	{
		call moe_dn_rows
		r2 = r0
		r1:0 = combine(r20,r16)
	}
	.falign
// %bb.9:                               // %do.end
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_13
	}
// %bb.10:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r19:18)
	}
	.balign 32
.LBB34_12:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB34_12
	}
	.falign
.LBB34_13:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end34:
	.size	moe_dn_fg_worker, .Lfunc_end34-moe_dn_fg_worker
                                        // -- End function
	.falign
	.type	moe_push_weight_chunk,@function // -- Begin function moe_push_weight_chunk
moe_push_weight_chunk:                  // @moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r18 = r5
		r6 = memw(r3+#44)
		memd(r29+#40) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r6,#0)
		r5 = memw(r29+#64)
		memd(r29+#32) = r21:20
	}
	{
		if (p0) r2 = add(r3,#0)
		r21 = r4
		r17 = memw(r29+#76)
		r16 = memw(r29+#80)
	}
	{
		if (p0) jump:nt .LBB35_3
		r20 = memw(r29+#72)
		r19 = memw(r29+#68)
	}
// %bb.1:                               // %if.then
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
		r4 = add(r29,#20)
		memw(r29+#4) = r4.new
	}
	{
		r4 = r5
		r5 = r19
		memw(r29+#20) = r20
		memw(r29+#24) = r17
	}
	{
		r6 = memw(r6+#0)
		memw(r29+#28) = r16
	}
	{
		call moe_push_native_chunk
		memw(r29+#0) = r6
	}
	.falign
.LBB35_2:                               // %return
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB35_3:                               // %if.end
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r4 = r18
		r3 = r4
		memw(r29+#0) = r19
	}
	{
		call hexkl_moe_push_weight_chunk
		r6 = memw(r6+#0)
		memw(r29+#4) = r6.new
	}
	.falign
// %bb.4:                               // %if.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB35_2
	}
// %bb.5:                               // %if.then6
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r7:6 = vaslw(r19:18,#9)
		r18 = r0
		r1:0 = combine(r3,r2)
		r5:4 = combine(r16,r17)
	}
	{
		r3:2 = combine(r20,r18)
		memw(r29+#0) = r7
		memw(r29+#4) = r21
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
// %bb.6:                               // %if.then6
	{
		r0 = r18
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end35:
	.size	moe_push_weight_chunk, .Lfunc_end35-moe_push_weight_chunk
                                        // -- End function
	.balign 32                              // -- Begin function _HAP_debug_v2
	.type	_HAP_debug_v2,@function
_HAP_debug_v2:                          // @_HAP_debug_v2
// %bb.0:                               // %entry
	{
		r2 = add(pc,##.L.str.1@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(r29,#280):raw
	}                                       // 8-byte Folded Spill
	{
		r1 = #256
		r16 = add(r29,#8)
		r3 = add(r29,#288)
		memw(r29+#4) = r3.new
	}
	{
		call vsnprintf
		r0 = r16
	}
	{
		r2 = add(pc,##.L.str@PCREL)
		r1:0 = combine(#3,r16)
		r3 = #3635
	}
	{
		call HAP_debug
	}
	{
		r17:16 = memd(r29+#272)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end36:
	.size	_HAP_debug_v2, .Lfunc_end36-_HAP_debug_v2
                                        // -- End function
	.globl	hexkl_mm_u8i4_fc_m1_run         // -- Begin function hexkl_mm_u8i4_fc_m1_run
	.falign
	.type	hexkl_mm_u8i4_fc_m1_run,@function
hexkl_mm_u8i4_fc_m1_run:                // @hexkl_mm_u8i4_fc_m1_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#656):raw
	}                                       // 8-byte Folded Spill
	{
		r23 = ##-2147449856
		memd(r29+#624) = r23:22
		memd(r29+#640) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19 = r0
		r0 = add(r23,#-32754)
		memd(r29+#632) = r21:20
		memd(r29+#616) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB37_34
		memd(r29+#608) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r26 = memw(r29+#664)
		if (cmp.eq(r26.new,#0)) jump:nt ##.LBB37_34
	}
// %bb.2:                               // %entry
	{
		r18 = memw(r29+#668)
		if (cmp.eq(r18.new,#0)) jump:nt ##.LBB37_34
	}
// %bb.3:                               // %entry
	{
		r24 = memw(r29+#672)
		if (cmp.eq(r24.new,#0)) jump:nt ##.LBB37_34
	}
// %bb.4:                               // %entry
	{
		r22 = memw(r29+#680)
		if (cmp.eq(r22.new,#0)) jump:nt .LBB37_34
	}
// %bb.5:                               // %if.end
	{
		r6 = add(r5,#-65)
		r0 = add(r23,#-32751)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB37_34
	}
// %bb.6:                               // %lor.lhs.false8
	{
		p1 = !bitsclr(r4,#31)
		if (p1.new) jump:nt .LBB37_34
	}
// %bb.7:                               // %lor.lhs.false8
	{
		r20 = add(r29,#32)
		r7 = #-64
		if (cmp.gtu(r7.new,r6)) jump:nt .LBB37_34
	}
// %bb.8:                               // %for.body.lr.ph
	{
		r2 = #568
		memw(r29+#12) = r1
		memw(r29+#20) = r2
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(#0,r20)
		r17:16 = combine(r4,r5)
		r3 = memw(r29+#676)
		memw(r29+#16) = r3
	}
	{
		call memset
		r25 = memw(r29+#684)
		memw(r29+#24) = r3
	}
	.falign
// %bb.9:                               // %for.body.lr.ph
	{
		r4 = lsr(r17,#5)
		r21 = add(r20,#12)
		r3:2 = combine(r17,r16)
		memw(r29+#564) = r4.new
	}
	{
		r0 = add(r23,#-32752)
		r5:4 = combine(r21,r16)
	}
	.falign
.LBB37_10:                              // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = #4095
	}
	{
		r6 = memw(r26+#0)
		if (cmp.gtu(r6.new,r6)) jump:nt .LBB37_34
	}
// %bb.11:                              // %cond.end
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		r6 = +mpyi(r6,#96)
	}
	{
		r7 = memw(r19+r6<<#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB37_34
	}
// %bb.12:                              // %lor.lhs.false23
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		r6 = add(r19,r6)
	}
	{
		r7 = memw(r6+#28)
		if (!cmp.eq(r7.new,r3)) jump:nt .LBB37_34
	}
// %bb.13:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		r7 = memw(r6+#32)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB37_34
	}
// %bb.14:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		r8 = and(r7,#31)
		if (!cmp.eq(r8.new,#0)) jump:nt .LBB37_34
	}
// %bb.15:                              // %lor.lhs.false32
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		r26 = add(r26,#4)
		r4 = add(r4,#-1)
		r8 = memw(r6+#84)
		if (cmp.eq(r8.new,#2)) jump:nt .LBB37_34
	}
// %bb.16:                              // %for.inc
                                        //   in Loop: Header=BB37_10 Depth=1
	{
		p1 = cmp.eq(r4,#0)
		r8 = memw(r5+#256)
	}
	{
		r8 += lsr(r7,#5)
		memw(r5+#260) = r8.new
	}
	{
		if (!p1) jump:nt .LBB37_10
		if (p1) r6 = memw(r29+##564)
		memw(r5++#4) = r6
	}
// %bb.17:                              // %for.end
	{
		r26 = asl(r6,#11)
		r7 = add(r29,#32)
		r1:0 = combine(#0,#1)
		memw(r29+#28) = r0
	}                                       // 4-byte Folded Spill
	{
		r7 = addasl(r7,r2,#2)
		r19 = setbit(r26,#9)
		r9:8 = combine(#0,#0)
		r5:4 = memd(r22+#24)
	}
	{
		r1:0 = add(r5:4,r1:0)
		memw(r29+#560) = r2
		memd(r22+#40) = r9:8
	}
	{
		r0 = memw(r22+#8)
		memd(r22+#24) = r1:0
	}
	{
		p0 = cmp.gtu(r19,r0)
		r2 = memw(r7+#268)
		memd(r22+#56) = r9:8
	}
	{
		if (!p0) jump:nt .LBB37_22
		memw(r22+#48) = #0
		memw(r29+#568) = r2
	}
// %bb.18:                              // %hexkl_moe_scratch_free.exit.i
	{
		r3:2 = combine(#0,#2)
		r0 = memw(r22+#0)
		memw(r22+#56) = #0
	}
	{
		r3:2 = add(r5:4,r3:2)
	}
	{
		call free
		memd(r22+#24) = r3:2
	}
	.falign
// %bb.19:                              // %hexkl_moe_scratch_free.exit.i
	{
		r0 = or(r26,##640)
		memw(r22+#4) = #0
		memw(r22+#8) = #0
	}
	{
		call malloc
	}
	.falign
// %bb.20:                              // %hexkl_moe_scratch_free.exit.i
	{
		if (!p1.new) r2 = add(r0,#127)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB37_35
		memw(r22+#0) = r0
	}
// %bb.21:                              // %if.end3.i
	{
		r3 = r17
		memw(r22+#8) = r19
	}
	{
		r19 = and(r2,#-128)
		jump .LBB37_23
		memw(r22+#4) = r19.new
	}
	.falign
.LBB37_22:                              // %for.end.if.end56_crit_edge
	{
		r19 = memw(r22+#4)
	}
	.falign
.LBB37_23:                              // %for.body78.lr.ph
	{
		r20 = add(r19,r26)
		r1:0 = combine(#1,r18)
		r2 = #64
		memw(r29+#0) = #0
	}
	{
		r27 = add(r20,#256)
		r22 = r3
	}
	{
		call hvx_quant_rows_u8_params
		r5:4 = combine(r27,r20)
	}
	.falign
// %bb.24:                              // %for.body78.lr.ph
	{
		r1:0 = combine(r22,r18)
		r4 = r19
		r2 = memw(r19+r26<<#0)
		r3 = memw(r20+#256)
	}
	{
		memw(r20+#4) = r2
		memw(r20+#260) = r3
	}
	{
		memw(r20+#8) = r2
		memw(r20+#264) = r3
	}
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		memw(r20+#12) = r2
		memw(r20+#268) = r3
	}
	.falign
// %bb.25:                              // %for.body78.lr.ph
	{
		r2 = memw(r29+#16)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
.LBB37_26:                              // %for.body78
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r21+#0)
	}
	{
		r21 = add(r21,#4)
		r5 = memw(r5+#20)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB37_28
	}
// %bb.27:                              // %for.cond75
                                        //   in Loop: Header=BB37_26 Depth=1
	{
		r16 = add(r16,#-1)
		if (!cmp.eq(r16.new,#0)) jump:t .LBB37_26
	}
	{
		jump .LBB37_30
	}
	.falign
.LBB37_28:                              // %if.then82
	{
		r4 = add(r29,#32)
		r1:0 = combine(#1,r19)
		r3:2 = combine(r27,r17)
	}
	{
		call hexkl_wh_affine_sums
		r4 = add(r4,#540)
	}
	.falign
// %bb.29:                              // %if.then82
	{
		r3 = memw(r29+#20)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	.falign
.LBB37_30:                              // %cleanup86
	{
		r7 = extractu(r25,#1,#16)
		p1 = !tstbit(r25,#6)
		r5 = and(r25,##131104)
	}
	{
		r6 = extractu(r25,#1,#18)
		p0 = cmp.eq(r5,#32)
		if (p1) r7 = #1
		memw(r29+#32) = r19
	}
	{
		r2 = minu(r3,r2)
		r5 = mux(p0,#0,r4)
		memw(r29+#36) = r20
		memw(r29+#40) = r27
	}
	{
		p0 = cmp.eq(r5,#0)
		memw(r29+#576) = r24
		memw(r29+#588) = r7
	}
	{
		memw(r29+#592) = r6
		memw(r29+#584) = r2
	}
	{
		if (p0) jump:nt .LBB37_32
		memw(r29+#580) = r5
	}
// %bb.31:                              // %if.then109
	{
		call hexkl_dma_ring_drain
	}
	.falign
.LBB37_32:                              // %if.end110
	{
		r1 = add(pc,##fc_m1_worker@PCREL)
		r3 = #8
		r2 = memw(r29+#568)
	}
	{
		r3 = minu(r2,r3)
		call hvx_worker_pool_run
		r2 = add(r29,#32)
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.33:                              // %if.end110
	{
		r2 = memw(r29+#596)
		r0 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		if (p1.new) r0 = #0
		if (!p1.new) r0 = add(r23,##-32767)
	}
	.falign
.LBB37_34:                              // %cleanup128
	{
		r17:16 = memd(r29+#648)
		r19:18 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#632)
		r23:22 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#616)
		r27:26 = memd(r29+#608)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB37_35:
	{
		r0 = add(r23,#-32766)
		jump .LBB37_34
	}
.Lfunc_end37:
	.size	hexkl_mm_u8i4_fc_m1_run, .Lfunc_end37-hexkl_mm_u8i4_fc_m1_run
                                        // -- End function
	.falign
	.type	fc_m1_worker,@function          // -- Begin function fc_m1_worker
fc_m1_worker:                           // @fc_m1_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = r0
		r24 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r1 = r22
		r16 = r2
		r0 = memw(r2+#552)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-24) = r21:20
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r20 = memw(r2+#532)
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r26 = asl(r20,#10)
		r17 = and(r0,#-128)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r26,r17)
	}
	.falign
// %bb.2:                               // %entry
	{
		r23 = #0
		r25 = r0
		r5:4 = combine(#0,#0)
		r27 = memw(r16+#536)
	}
	{
		r3:2 = combine(r23,r22)
		r21 = memw(r16+#548)
		memd(r29+#240) = r5:4
	}
	{
		r1:0 = mpyu(r27,r24)
		call __hexagon_udivdi3
	}
	.falign
// %bb.3:                               // %entry
	{
		r2 = add(r24,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r27,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r23,r22)
	}
	.falign
// %bb.4:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r18)
	}
	{
		if (!p0) jump:nt .LBB38_71
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.5:                               // %if.end
	{
		p1 = cmp.gtu(r26,r17)
		r4 = #1
		p0 = cmp.eq(r21,#0)
	}
	{
		p1 = not(p1)
	}
	{
		p1 = and(p1,!p0)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB38_10
		if (p1) r1:0 = memd(r29+#248)
		memw(r29+#216) = r2.new
	}                                       // 8-byte Folded Reload
// %bb.6:                               // %if.then5
	{
		r2 = add(r0,sub(#3,r18))
	}
	{
		r4 = lsr(r2,#2)
		r2 = asl(r20,#9)
	}
	{
		r4 = minu(r4,r25)
		r3 = memw(r16+#556)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB38_9
	}
// %bb.7:                               // %if.then5
	{
		r3 = add(r4,#3)
		p1 = cmp.gtu(r25,#3)
		if (!p1.new) jump:nt .LBB38_9
	}
// %bb.8:                               // %if.then11
	{
		r4 = and(r4,##1073741820)
		r3 = and(r3,##2147483644)
	}
	{
		p0 = cmp.gtu(r3,r25)
		if (!p0.new) r4 = add(r3,#0)
	}
	.falign
.LBB38_9:                               // %if.end20
	{
		r21 += mpyi(r17,r24)
		memw(r29+#240) = r21.new
	}
	{
		r21 += mpyi(r2,r4)
		r23 = r21
		memw(r29+#244) = r21.new
	}
	.falign
.LBB38_10:                              // %if.end28
	{
		r25 = add(r16,#272)
	}
	{
		r3 = r25
	}
	.balign 32
.LBB38_11:                              // %while.cond.i.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p1 = cmp.gtu(r3,r18); if (!p1.new) jump:t .LBB38_11
	}
// %bb.12:                              // %fc_m1_block_end.exit
	{
		r3 = add(r4,r18)
		r2 = memw(r2+#0)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r5 = add(pc,##g_fc_m1_desc@PCREL)
		r2 = minu(r3,r2)
		memw(r29+#236) = r4
	}                                       // 4-byte Folded Spill
	{
		r5 += asl(r24,#8)
		r3 = r25
	}
	{
		r26 = minu(r2,r0)
		r0 = memw(r29+#216)
		memw(r29+#232) = r5
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (!p0.new) jump:t .LBB38_20
	}
	.balign 32
.LBB38_14:                              // %while.cond.i.i318
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p0 = cmp.gtu(r3,r18); if (!p0.new) jump:t .LBB38_14
	}
// %bb.15:                              // %fc_m1_part.exit.i
	{
		r4 = memw(r2+#-260)
		r3 = memw(r16+#560)
	}
	{
		p1 = cmp.eq(r3,#0)
		r6 = memw(r4+#36)
		r2 = memw(r2+#-4)
	}
	{
		if (p1) r6 = #0
		if (p1) jump:nt .LBB38_19
		r3 = memw(r4+#4)
		r5 = memw(r4+#32)
	}
// %bb.16:                              // %land.rhs.i.i
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB38_19
		if (p0.new) r4 = memw(r4+#40)
	}
// %bb.17:                              // %lor.rhs.i.i
	{
		r6 = !cmp.eq(r4,#0)
	}
	.falign
.LBB38_19:                              // %fc_m1_push.exit
	{
		r5 = and(##-512,asl(r5,#4))
		r7 = sub(r18,r2)
		r4 = sub(r26,r18)
	}
	{
		r4 = asl(r4,#9)
		r1 = #0
		r2 = r23
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r7,#9)
		memw(r29+#8) = r6
		memw(r29+#4) = r20
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	.falign
.LBB38_20:                              // %while.body.lr.ph
	{
		r23 = #0
		r17 = r26
	}
	.falign
.LBB38_21:                              // %while.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB38_22 Depth 2
                                        //     Child Loop BB38_29 Depth 2
                                        //     Child Loop BB38_36 Depth 2
                                        //     Child Loop BB38_39 Depth 2
                                        //       Child Loop BB38_54 Depth 3
                                        //       Child Loop BB38_58 Depth 3
	{
		r3 = r25
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.gtu(r0,r26)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB38_24
		memw(r29+#220) = r2.new
	}                                       // 4-byte Folded Spill
	.balign 32
.LBB38_22:                              // %while.cond.i.i328
                                        //   Parent Loop BB38_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.gtu(r3,r26)
		r3 = add(r2,#4)
		if (!p1.new) jump:t .LBB38_22
	}
// %bb.23:                              // %fc_m1_block_end.exit340
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r3 = memw(r29+#236)
		r2 = memw(r2+#0)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r26,r3)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r2 = minu(r3,r2)
	}
	{
		r17 = minu(r2,r0)
	}
	.falign
.LBB38_24:                              // %cond.end39
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r19 = togglebit(r23,#0)
		r2 = r25
		r3 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB38_36
		if (p0.new) r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
// %bb.25:                              // %if.then42
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r0 = addasl(r2,r23,#7)
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.26:                              // %if.then42
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r2 = r25
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB38_70
	}
// %bb.27:                              // %if.end47
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r5 = r25
		p1 = cmp.gtu(r17,r26)
		if (!p1.new) jump:t .LBB38_36
	}
// %bb.28:                              // %if.then49
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r4 = togglebit(r23,#0)
		r2 = add(r29,#240)
	}
	{
		r2 = memw(r2+r4<<#2)
	}
	.balign 32
.LBB38_29:                              // %while.cond.i.i342
                                        //   Parent Loop BB38_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = r5
		r5 = memw(r5+#0)
	}
	{
		p0 = cmp.gtu(r5,r26)
		r5 = add(r3,#4)
		if (!p0.new) jump:t .LBB38_29
	}
// %bb.30:                              // %fc_m1_part.exit.i348
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r5 = memw(r16+#560)
	}
	{
		if (p1.new) r6 = #0
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB38_34
		r5 = memw(r3+#-260)
	}
// %bb.31:                              // %land.rhs.i.i358
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r6 = memw(r5+#36)
	}
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB38_34
	}
// %bb.32:                              // %lor.rhs.i.i368
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r6 = memw(r5+#40)
	}
	{
		r6 = !cmp.eq(r6,#0)
	}
	.falign
.LBB38_34:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r8 = sub(r17,r26)
		r1 = #0
		r7 = memw(r3+#-4)
		r3 = memw(r5+#4)
	}
	{
		r5 = memw(r5+#32)
		r9 = memw(r16+#532)
	}
	{
		r6 = sub(r26,r7)
		r12 = memw(r29+#232)
		memw(r29+#8) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = and(##-512,asl(r5,#4))
		r0 = addasl(r12,r4,#7)
		memw(r29+#12) = #1
	}
	{
		r3 += asl(r6,#9)
		r4 = asl(r8,#9)
		memw(r29+#4) = r9
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#0) = r4
	}
	.falign
// %bb.35:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r2 = r25
	}
	.balign 32
.LBB38_36:                              // %while.cond.i
                                        //   Parent Loop BB38_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r22 = r2
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r22,#4)
		p1 = cmp.gtu(r2,r18); if (!p1.new) jump:t .LBB38_36
	}
// %bb.37:                              // %fc_m1_part.exit
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		p0 = cmp.gtu(r26,r18)
		if (!p0.new) jump:t .LBB38_69
		memw(r29+#228) = r19
		memw(r29+#224) = r17
	}                                       // 4-byte Folded Spill
// %bb.38:                              // %for.body.lr.ph
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r19 = sub(r26,r18)
		r20 = r18
		r17 = memw(r22+#-260)
	}
	.falign
.LBB38_39:                              // %for.body
                                        //   Parent Loop BB38_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB38_54 Depth 3
                                        //       Child Loop BB38_58 Depth 3
	{
		r6 = add(r29,#256)
		r1 = #1
		r24 = memw(r22+#-4)
		r2 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r21 = sub(r20,r24)
		if (!p1.new) jump:t .LBB38_44
		if (!p1.new) r4 = memw(r17+#32)
	}
// %bb.40:                              // %land.lhs.true62
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r4 = add(r29,#256)
		r5 = sub(r20,r18)
		r3 = add(r29,#240)
		r0 = memw(r16+#0)
	}
	{
		r3 = addasl(r3,r23,#2)
		r1 = #1
		r2 = memw(r16+#556)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB38_46
	}
// %bb.41:                              // %if.then65
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r4 = r19
		r2 = sub(r26,r20)
		if (!cmp.gtu(r2.new,#3)) jump:t .LBB38_48
	}
// %bb.42:                              // %if.then68
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r3 = add(r29,#256)
		r2 = memw(r3+#0)
		r0 = memw(r16+#0)
	}
	{
		call hvx_gemv_u8i4_wh_4col_nopf
		r3 = #512
		r1 = memw(r16+#532)
		memw(r29+#0) = r3

	} :mem_noshuf
	.falign
// %bb.43:                              // %if.then68
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #4
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB38_53
	}
	{
		jump .LBB38_61
	}
	.falign
.LBB38_44:                              // %if.else102
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r27 = #1
		r5 = memw(r16+#556)
		r0 = memw(r16+#0)
	}
	{
		r4 = lsr(r4,#5)
		r2 = memw(r16+#532)
	}
	{
		r5 = r21
		r3 = memw(r17+#4)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		call hvx_gemm_u8i4_wh_col
		memw(r29+#4) = r6
	}
	.falign
// %bb.45:                              // %if.else102
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB38_53
	}
	{
		jump .LBB38_61
	}
	.falign
.LBB38_46:                              // %if.then94
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r27 = #1
		r2 = memw(r16+#532)
	}
	{
		r4 = r19
		r3 = memw(r3+#0)
		memw(r29+#4) = r4
	}
	{
		call hvx_gemm_u8i4_wh_col_nopf
		memw(r29+#0) = #0
	}
	.falign
// %bb.47:                              // %if.then94
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB38_53
	}
	{
		jump .LBB38_61
	}
	.falign
.LBB38_48:                              // %if.else
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = add(r29,#256)
		p1 = cmp.eq(r2,#3)
		r0 = memw(r16+#0)
		r1 = memw(r16+#532)
	}
	{
		if (!p1) r3 = add(r19,#0)
		if (!p1) jump:nt .LBB38_51
		r4 = r5
		r2 = memw(r3+#0)
	}
// %bb.49:                              // %if.then76
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r3 = add(r29,#256)
		r4 = r19
		memw(r29+#0) = r3.new
	}
	{
		call hvx_gemv_u8i4_wh_3col_nopf
		r3 = #512
	}
	.falign
// %bb.50:                              // %if.then76
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #3
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB38_53
	}
	{
		jump .LBB38_61
	}
	.falign
.LBB38_51:                              // %if.else83
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		call hvx_gemv_u8i4_wh_col_aligned_nopf
		r5 = r6
	}
	.falign
// %bb.52:                              // %if.else83
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #1
		r4 = memw(r17+#20)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB38_61
	}
	.falign
.LBB38_53:                              // %if.then112
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r8 = addasl(r4,r6,#2)
		r7 = asl(r20,#7)
		r5 = add(r29,#256)
		r2 = memw(r16+#540)
	}
	{
		r7 -= asl(r24,#7)
		v0 = vsplat(r2)
		r14 = #0
		r13 = add(r5,#128)
	}
	{
		r12 = add(r4,add(r7,##128))
		r3 = asl(r27,#5)
	}
	.balign 32
.LBB38_54:                              // %for.body.us.i
                                        //   Parent Loop BB38_21 Depth=1
                                        //     Parent Loop BB38_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r14,#64)
		r9 = r14
		v2 = vmemu(r8+#0)
	}
	{
		r4 = r13
		p1 = cmp.gtu(r7,r3)
		r7 = r12
		v1 = vmem(r5+#0)
	}
	{
		v1.w += vmpyie(v0.w,v2.h)
		r8 = add(r8,#128)
		r14 = add(r14,#32)
		vmem(r5+#0) = v1.new
	}
	{
		r13 = add(r13,#128)
		r12 = add(r12,#128)
		r5 = add(r5,#128)
		if (!p1) jump:nt .LBB38_54
	}
// %bb.55:                              // %for.cond10.preheader.i
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r8 = add(r3,sub(#-32,r9))
		r5 = r7
		p0 = cmp.gtu(r3,r14)
		if (!p0.new) jump:t .LBB38_61
	}
// %bb.56:                              // %for.body17.us.i.preheader
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r9 = lsr(r8,#1)
		r3 = r4
		r8 = and(r8,#1)
	}
	{
		loop0(.LBB38_58,r9)
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB38_59
	}
	.falign
.LBB38_58:                              //   Parent Loop BB38_21 Depth=1
                                        //     Parent Loop BB38_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r5++#8)
		r12 = memw(r4+#0)
	}
	{
		r1 = memw(r4+#4)
	}
	{
		r12 += mpyi(r9,r2)
		memw(r3++#8) = r12.new
	}
	{
		r7 = r5
		r9 = memw(r7+#4)
	}
	{
		r1 += mpyi(r9,r2)
		r4 = r3
		memw(r4+#4) = r1.new
	} :endloop0
	.falign
.LBB38_59:                              //   in Loop: Header=BB38_39 Depth=2
	{
		p0 = cmp.gtu(r8,#0)
		if (!p0.new) jump:t .LBB38_61
		if (p0.new) r0 = memw(r3+#0)
		if (p0.new) r4 = memw(r5+#0)
	}
	.falign
.LBB38_60:                              // Block address taken
                                        // %for.body17.us.i
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r0 += mpyi(r4,r2)
		memw(r3++#4) = r0.new
	}
	.falign
.LBB38_61:                              // %if.end118
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r0 = add(r29,#256)
		p1 = cmp.eq(r27,#3)
		r2 = memw(r16+#544)
		r3 = memw(r16+#4)
	}
	{
		r7 = addasl(r2,r20,#7)
		if (p1) jump:nt .LBB38_65
		if (p1) r5:4 = memd(r17+#8)
		if (p1) r2 = memw(r16+#8)
	}
// %bb.62:                              // %if.end118
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r0 = add(r29,#256)
		p0 = cmp.eq(r27,#4)
		if (!p0.new) jump:nt .LBB38_67
		if (p0.new) r2 = memw(r16+#8)
	}
// %bb.63:                              // %if.then123
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r5:4 = memd(r17+#8)
		r8 = memw(r17+#16)
	}
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_4tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.64:                              // %if.then123
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t .LBB38_39
	}
	{
		jump .LBB38_69
	}
	.falign
.LBB38_65:                              // %if.then132
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r8 = memw(r17+#16)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_3tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.66:                              // %if.then132
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB38_39
	}
	{
		jump .LBB38_69
	}
	.falign
.LBB38_67:                              // %if.else144
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r0 = add(r29,#256)
		r1 = #32
		r5 = memw(r17+#16)
		r2 = memw(r16+#536)
	}
	{
		r5 = addasl(r5,r6,#2)
		r2 = asl(r2,#5)
		r9:8 = memd(r17+#8)
		r4 = memw(r16+#8)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#4) = r5
	}
	{
		r6 = addasl(r8,r6,#2)
		memw(r29+#8) = r7
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.68:                              // %if.else144
                                        //   in Loop: Header=BB38_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB38_39
	}
	.falign
.LBB38_69:                              // %cleanup
                                        //   in Loop: Header=BB38_21 Depth=1
	{
		r18 = r26
		r23 = memw(r29+#228)
		r2 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r17 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r26 = r17
		if (p0) jump:nt .LBB38_21
	}
	{
		jump .LBB38_71
	}
	.falign
.LBB38_70:                              // %cleanup.thread
	{
		r2 = #1
		memw(r16+#564) = r2.new
	}
	.falign
.LBB38_71:                              // %cleanup163
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end38:
	.size	fc_m1_worker, .Lfunc_end38-fc_m1_worker
                                        // -- End function
	.falign
	.type	moe_expand_unit,@function       // -- Begin function moe_expand_unit
moe_expand_unit:                        // @moe_expand_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2816):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r1 = memw(r2+#152)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r1,#0)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB39_7
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		p0 = and(p0,!p0)
		r2 = memw(r16+#156)
	}
	{
		r0 = p0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB39_16
		memw(r29+#124) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %land.rhs
	{
		r2 = #1536
	}
	{
		r2 = memw(r16+#168)
		if (cmp.eq(r2.new,r2)) jump:nt .LBB39_14
	}
// %bb.3:                               // %land.rhs
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:nt .LBB39_16
	}
// %bb.4:                               // %land.lhs.true
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#24)) jump:t .LBB39_16
	}
// %bb.5:                               // %land.lhs.true3
	{
		r2 = memw(r16+#12)
	}
	{
		p1 = cmp.eq(r2,##49152)
		if (!p1.new) jump:t .LBB39_16
	}
// %bb.6:
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB39_16
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB39_7:                               // %if.end126
	{
		r1 = r18
		r2 = memw(r16+#8)
		r3 = memw(r16+#20)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		r0 = mpyi(r19,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %if.end126
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r19,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.9:                               // %if.end126
	{
		r19 = add(r16,#24)
		r18 = r0
		p0 = cmp.gtu(r0,r17); if (!p0.new) jump:t .LBB39_43
	}
	.falign
.LBB39_11:                              // %for.body135
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.12:                              // %for.body135
                                        //   in Loop: Header=BB39_11 Depth=1
	{
		r2 = r17
		r4 = memw(r16+#12)
		r3 = memw(r16+r0<<#2)
	}
	{
		r2 -= mpyi(r0,r20)
		r1 = memw(r16+#16)
	}
	{
		r3 += mpyi(r4,r2)
		r2 = r19
	}
	{
		call hvx_expand_i2i4
		r0 = add(r3,r1)
	}
	.falign
// %bb.13:                              // %for.body135
                                        //   in Loop: Header=BB39_11 Depth=1
	{
		r17 = add(r17,#1)
		if (cmp.gtu(r18,r17.new)) jump:t .LBB39_11
	}
	{
		jump .LBB39_43
	}
	.falign
.LBB39_14:                              // %land.lhs.true7
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#16)) jump:t .LBB39_16
	}
// %bb.15:                              // %land.rhs10
	{
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r2,##32768)
	}
	{
		r2 = p0
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB39_16:                              // %land.end13
	{
		r1 = r18
		r20 = memw(r16+#184)
		r19 = memw(r16+#176)
	}
	{
		r0 = mpyi(r20,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.17:                              // %land.end13
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r20,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.18:                              // %land.end13
	{
		p1 = cmp.eq(r17,r0); if (p1.new) jump:t .LBB39_43
		r3 = #0
		r18 = r0
	}
// %bb.19:                              // %if.end
	{
		r2 = memw(r16+#172)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB39_43
	}
// %bb.20:                              // %for.body.lr.ph
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r26 = #0
		r25:24 = combine(#2,#96)
	}
	.falign
.LBB39_21:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB39_26 Depth 2
                                        //       Child Loop BB39_35 Depth 3
                                        //       Child Loop BB39_39 Depth 3
	{
		r1:0 = memd(r16+#160)
	}
	{
		r1:0 &= asl(r7:6,r26)
	}
	{
		p1 = cmp.eq(r1:0,r9:8)
		if (!p1.new) r27 = add(r3,r19)
		if (p1.new) jump:nt .LBB39_40
	}
// %bb.22:                              // %if.end23
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		p0 = cmp.gtu(r18,r3); if (!p0.new) jump:nt .LBB39_42
	}
// %bb.23:                              // %if.end23
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r4 = maxu(r17,r3)
		p1 = cmp.gtu(r27,r17)
		if (!p1.new) jump:nt .LBB39_42
	}
// %bb.24:                              // %if.end28
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r22 = asl(r26,#11)
		p0 = cmp.gtu(r27,r18)
		if (p0.new) r20 = sub(r18,r3)
		if (!p0.new) r20 = add(r19,#0)
	}
	{
		r21 = sub(r4,r3)
		if (!cmp.gtu(r20,r21.new)) jump:t .LBB39_42
	}
	.falign
.LBB39_26:                              // %for.body39
                                        //   Parent Loop BB39_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB39_35 Depth 3
                                        //       Child Loop BB39_39 Depth 3
	{
		r5 = r22
		r3 = memw(r16+#12)
		r7:6 = memd(r16+#152)
	}
	{
		p0 = cmp.eq(r7,#0)
		r2 = memw(r16+#168)
	}
	{
		r4 = mpyi(r21,r3)
		r2 -= mpyi(r21,#96)
	}
	{
		r1 = minu(r2,r24)
		r4 = +mpyi(r4,#3)
		if (!p0) r2 = memw(r16+#180)
	}
	{
		r5 += add(r6,r4)
		if (p0) jump:nt .LBB39_33
	}
// %bb.27:                              // %if.then51
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		r7 += mpyi(r2,r26)
	}
	{
		r7 += mpyi(r21,##2560)
	}
	.falign
.LBB39_28:                              // %if.end95
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		r0 = r7
		r2 = memw(r29+#124)
		r4 = memw(r16+#188)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r2 = #128
		if (!p1.new) jump:t .LBB39_31
	}
// %bb.29:                              // %if.then97
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		call hvx_tl2_expand_wh96_disjoint
		r2 = #128
	}
	.falign
// %bb.30:                              // %if.then97
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB39_26
	}
	{
		jump .LBB39_41
	}
	.falign
.LBB39_31:                              // %if.else104
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		call hvx_tl2_expand_wh96
	}
	.falign
// %bb.32:                              // %if.else104
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB39_26
	}
	{
		jump .LBB39_41
	}
	.falign
.LBB39_33:                              // %if.else
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB39_28
		r7 = add(r29,#128)
		r6 = r5
	}
// %bb.34:                              //   in Loop: Header=BB39_26 Depth=2
	{
		r4 = add(##989,mpyi(r1,#43))
	}
	{
		r4 = lsr(r4,#10)
	}
	{
		r8 = minu(r4,r25)
	}
	{
		r8 = +mpyi(r8,#5)
	}
	{
		loop0(.LBB39_35,r8)
	}
	.falign
.LBB39_35:                              // Block address taken
                                        // %for.body73
                                        //   Parent Loop BB39_21 Depth=1
                                        //     Parent Loop BB39_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0.cur = vmem(r6++#1)
		vmem(r7++#1) = v0
	} :endloop0
// %bb.36:                              // %for.cond.cleanup72
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		p0 = cmp.gtu(r2,#48)
		r7 = add(r29,#128)
		if (!p0.new) jump:t .LBB39_28
	}
// %bb.37:                              // %for.cond79.preheader
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		r4 = add(##-10,mpyi(r4,#5))
	}
	{
		if (!p1.new) r2 = add(r5,r3)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB39_28
	}
// %bb.38:                              // %for.body84.lr.ph
                                        //   in Loop: Header=BB39_26 Depth=2
	{
		loop0(.LBB39_39,r4)
		r6 = add(r29,#128)
	}
	{
		r4 = add(r6,#1280)
	}
	.falign
.LBB39_39:                              // Block address taken
                                        // %for.body84
                                        //   Parent Loop BB39_21 Depth=1
                                        //     Parent Loop BB39_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r29,#128)
		v1.cur = vmem(r2++#1)
		vmem(r4++#1) = v1
	} :endloop0
	{
		jump .LBB39_28
	}
	.falign
.LBB39_40:                              //   in Loop: Header=BB39_21 Depth=1
	{
		r27 = r3
		jump .LBB39_42
	}
	.falign
.LBB39_41:                              // %for.inc116.loopexit
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r2 = memw(r16+#172)
	}
	.falign
.LBB39_42:                              // %for.inc116
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r3 = r27
		r26 = add(r26,#1)
		if (cmp.gtu(r2,r26.new)) jump:t .LBB39_21
	}
	.falign
.LBB39_43:                              // %cleanup150
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end39:
	.size	moe_expand_unit, .Lfunc_end39-moe_expand_unit
                                        // -- End function
	.falign
	.type	moe_m1_q_worker,@function       // -- Begin function moe_m1_q_worker
moe_m1_q_worker:                        // @moe_m1_q_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#72)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#56) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r18 = minu(r2,r0)
		r20 = #0
		memd(r29+#48) = r21:20
		memd(r29+#40) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r18,r1); if (!p1.new) jump:t .LBB40_10
		memd(r29+#32) = r25:24
		memd(r29+#24) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %for.cond.preheader
	{
		r24 = memw(r16+#40)
		memw(r29+#20) = r0
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r24,#0)
		if (p0.new) jump:nt .LBB40_9
		if (!p0.new) r19 = #0
		memw(r29+#16) = r16
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %for.body.lr.ph
	{
		r21 = add(pc,##g_m1q_desc@PCREL)
		r25 = add(r17,#1)
		r27:26 = combine(#0,r16)
	}
	{
		r21 += asl(r17,#8)
	}
	.falign
.LBB40_3:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r3:2 = combine(r19,r18)
		r16 = memw(r26+#12)
	}
	{
		r1:0 = mpyu(r16,r17)
		call __hexagon_udivdi3
	}
	.falign
// %bb.4:                               // %for.body
                                        //   in Loop: Header=BB40_3 Depth=1
	{
		r1:0 = mpyu(r16,r25)
		call __hexagon_udivdi3
		r23:22 = combine(r1,r0)
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB40_3 Depth=1
	{
		if (p0.new) r0 = sub(r0,r22)
		p0 = cmp.gtu(r0,r22); if (!p0.new) jump:t .LBB40_8
		if (p0.new) r4 = memw(r26+#8)
	}
// %bb.6:                               // %if.then6
                                        //   in Loop: Header=BB40_3 Depth=1
	{
		r5 = r4
		r2 = memw(r26+#0)
		r6 = memw(r26+#16)
	}
	{
		r3 = memw(r26+#4)
	}
	{
		r6 = mpyi(r4,r22)
		r1:0 = combine(r20,r21)
		memw(r29+#8) = r6
		memw(r29+#4) = r0
	}
	{
		r2 = add(r2,r6)
		r3 = add(r3,r6)
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	{
		call hexkl_dma_lane_push2d
	}
	.falign
// %bb.7:                               // %if.then6
                                        //   in Loop: Header=BB40_3 Depth=1
	{
		r20 = r21
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r2+#40)
	}
	.falign
.LBB40_8:                               // %if.end
                                        //   in Loop: Header=BB40_3 Depth=1
	{
		r26 = add(r26,#20)
		r21 = add(r21,#128)
		r27 = add(r27,#1)
		if (cmp.gtu(r24,r27.new)) jump:t .LBB40_3
	}
	.falign
.LBB40_9:                               // %for.cond.cleanup
	{
		p1 = cmp.eq(r17,#0)
		if (p1.new) r16 = memw(r29+#16)
		if (p1.new) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r16 = memw(r29+#16)
		if (p1) memw(r16+#48) = r18
	}                                       // 4-byte Folded Reload
	.falign
.LBB40_10:                              // %if.end18
	{
		r3 = memw(r16+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB40_12
	}
// %bb.11:                              // %if.then20
	{
		callr r3
		r1 = r17
		r2 = memw(r16+#60)
	}
	.falign
.LBB40_12:                              // %if.end22
	{
		if (!p0.new) r0 = add(r20,#0)
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB40_15
	}
// %bb.13:                              // %land.lhs.true
	{
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.14:                              // %land.lhs.true
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) memw(r16+#52) = #1
	}
	.falign
.LBB40_15:                              // %if.end26
	{
		r17:16 = memd(r29+#64)
		r19:18 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#48)
		r23:22 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#32)
		r27:26 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end40:
	.size	moe_m1_q_worker, .Lfunc_end40-moe_m1_q_worker
                                        // -- End function
	.falign
	.type	moe_dn_rows,@function           // -- Begin function moe_dn_rows
moe_dn_rows:                            // @moe_dn_rows
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r0)
		r6 = r2
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r0+#544)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r3,#0)
		r4 = memw(r0+#8)
		if (!p1.new) r0 = memw(r16+#0)
	}
	{
		r18 = asl(r4,#5)
		if (p1) jump:nt .LBB41_3
		if (!p1) r5 = memw(r16+#24)
		if (!p1) r2 = memw(r16+#12)
	}
// %bb.1:                               // %if.then
	{
		r4 = memw(r16+#808)
		r8 = memw(r16+#816)
	}
	{
		r4 = addasl(r4,r18,#2)
		r8 = addasl(r8,r18,#2)
		r1 = memw(r16+#4)
		r3 = memw(r16+#28)
	}
	{
		r12 = memw(r16+#836)
		r13 = memw(r16+#828)
	}
	{
		r7 = memw(r16+#812)
		r9 = memw(r16+#820)
	}
	{
		r7 = addasl(r7,r18,#2)
		r9 = addasl(r9,r18,#2)
		r14 = memw(r16+#832)
	}
	{
		r4 = r6
		r15 = memw(r16+#824)
		memw(r29+#4) = r4

	} :mem_noshuf
	{
		r3 = r17
		memw(r29+#0) = r3
		memw(r29+#32) = r15
	}
	{
		memw(r29+#28) = r14
		memw(r29+#24) = r13
	}
	{
		memw(r29+#20) = r12
		memw(r29+#16) = r9
	}
	{
		call hvx_dequant_i24_tiles_scatter_rows_f32
		memw(r29+#12) = r8
		memw(r29+#8) = r7
	}
	.falign
// %bb.2:                               // %if.then
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB41_15
	}
	{
		jump .LBB41_8
	}
	.falign
.LBB41_3:                               // %if.else
	{
		r5 = memw(r16+#548)
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r5,#0)
		r0 = memw(r16+#0)
		r3 = memw(r16+#16)
	}
	{
		r4 = memw(r16+#24)
		r8 = memw(r16+#808)
	}
	{
		r8 = addasl(r8,r18,#2)
		r14 = memw(r16+#816)
		r1 = memw(r16+#4)
	}
	{
		r14 = addasl(r14,r18,#2)
		r7 = memw(r16+#28)
		r12 = memw(r16+#812)
	}
	{
		r12 = addasl(r12,r18,#2)
		r15 = memw(r16+#820)
		r9 = memw(r16+#836)
	}
	{
		r15 = addasl(r15,r18,#2)
		r13 = memw(r16+#828)
		r28 = memw(r16+#832)
	}
	{
		if (p0) jump:nt .LBB41_6
		r10 = memw(r16+#824)
	}
// %bb.4:                               // %if.then5
	{
		r7 = add(r16,#552)
		memw(r29+#4) = r7
		memw(r29+#36) = r10
	}
	{
		r7 = addasl(r5,r18,#2)
		r5:4 = combine(r6,r17)
		memw(r29+#44) = r7
		memw(r29+#0) = r4
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		memw(r29+#8) = r8
		memw(r29+#40) = r7
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_affine_f32
	}
	.falign
// %bb.5:                               // %if.then5
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB41_15
	}
	{
		jump .LBB41_8
	}
	.falign
.LBB41_6:                               // %if.else25
	{
		r5:4 = combine(r6,r17)
		memw(r29+#0) = r4
		memw(r29+#36) = r10
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_f32
		memw(r29+#8) = r8
		memw(r29+#4) = r7
	}
	.falign
// %bb.7:                               // %if.else25
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB41_15
	}
	.falign
.LBB41_8:                               // %land.rhs.lr.ph
	{
		r19 = #0
		r17 = #0
		r2 = memw(r16+#852)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB41_15
	}
	.falign
.LBB41_10:                              // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1 = #0
		r2 = memw(r16+#844)
		r3 = memw(r16+#824)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r4 = memb(r3+r2<<#0)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB41_13
	}
// %bb.11:                              // %if.then49.us
                                        //   in Loop: Header=BB41_10 Depth=1
	{
		r2 = add(r3,r2)
	}
	{
		memb(r2+#0) = #1
		r2 = memw(r16+#844)

	} :mem_noshuf
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#820)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r2 = mpyi(r3,r2)
		r3 = memw(r16+#12)
	}
	{
		r4 = addasl(r4,r2,#2)
		r2 = asl(r3,#7)
	}
	{
		r0 = addasl(r4,r18,#2)
		call memset
	}
	.falign
// %bb.12:                              // %if.then49.us
                                        //   in Loop: Header=BB41_10 Depth=1
	{
		r2 = memw(r16+#844)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	.falign
.LBB41_13:                              // %if.end64.us
                                        //   in Loop: Header=BB41_10 Depth=1
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#848)
	}
	{
		r6 = memw(r16+#12)
		r5 = memw(r16+#820)
	}
	{
		r7 = mpyi(r3,r2)
		r9 = mpyi(r3,r19)
		r8 = memw(r16+#840)
		r2 = memw(r4+r17<<#0)
	}
	{
		r7 = addasl(r5,r7,#2)
		r3 = asl(r6,#5)
	}
	{
		r6 = addasl(r8,r9,#2)
		r0 = addasl(r7,r18,#2)
	}
	{
		r1 = addasl(r6,r18,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.14:                              // %if.end64.us
                                        //   in Loop: Header=BB41_10 Depth=1
	{
		r17 = add(r17,#4)
		r19 = add(r19,#1)
	}
	{
		r2 = memw(r16+#852)
		if (cmp.gtu(r2.new,r19)) jump:t .LBB41_10
	}
	.falign
.LBB41_15:                              // %for.cond.cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end41:
	.size	moe_dn_rows, .Lfunc_end41-moe_dn_rows
                                        // -- End function
	.type	g_moe_src_bypass,@object        // @g_moe_src_bypass
	.lcomm	g_moe_src_bypass,4,4
	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.8,"aMS",@progbits,1
	.p2align	3, 0x0
.L.str:
	.string	"/tmp/nntr-lfm2-tl2-gu-epilogue-20261016/trace/candidate/nntrainer/tensor/htp_backend/hmx/hexkl_mm_u8i4_moe.c"
	.size	.L.str, 109

	.type	.L.str.1,@object                // @.str.1
	.p2align	3, 0x0
.L.str.1:
	.string	"[nntr-tl2-gu-direct] M=%u K=%u I=%u N=%u E=%u native=%u lanes=%u fc=%u ft=%u uc=%u ut=%u !"
	.size	.L.str.1, 91

	.type	tl2_gu_trace,@object            // @tl2_gu_trace
	.lcomm	tl2_gu_trace,16,8
	.type	g_m1q_desc,@object              // @g_m1q_desc
	.lcomm	g_m1q_desc,1024,128
	.type	g_fc_m1_desc,@object            // @g_fc_m1_desc
	.lcomm	g_fc_m1_desc,2048,128
	.weak	HAP_debug_v2
	.weak	HAP_debug
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym hexkl_moe_pack_bg_worker
	.addrsig_sym moe_m1_pair_worker
	.addrsig_sym moe_tl2_gate_epilogue_worker
	.addrsig_sym moe_m1_requant_worker
	.addrsig_sym moe_m1_down_worker
	.addrsig_sym moe_gu_worker
	.addrsig_sym moe_dn_worker
	.addrsig_sym moe_dn_unit
	.addrsig_sym moe_dn_fg_worker
	.addrsig_sym HAP_debug_v2
	.addrsig_sym fc_m1_worker
	.addrsig_sym moe_expand_unit
	.addrsig_sym moe_m1_q_worker
	.addrsig_sym hexkl_probe_us
	.addrsig_sym tl2_gu_trace
	.addrsig_sym g_m1q_desc
	.addrsig_sym g_fc_m1_desc
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#hexkl_moe_pack_bg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_pair_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_tl2_gate_epilogue_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_requant_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_down_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_gu_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_fg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#HAP_debug_v2#(void)#(i32, ptr, i32, ptr, ...)#1##"
	.ascii	"C#fc_m1_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_expand_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_q_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"

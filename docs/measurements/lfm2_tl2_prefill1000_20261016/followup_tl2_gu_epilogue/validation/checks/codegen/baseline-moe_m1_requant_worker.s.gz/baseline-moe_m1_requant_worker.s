moe_m1_requant_worker:                  // @moe_m1_requant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = add(r2,#8192)
		r17 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		r16 = memw(r22+#0)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r27 = r2
		r3:2 = combine(r21,r20)
		memd(r30+#-48) = r27:26
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r16,r1)
		call __hexagon_udivdi3
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r16,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r21:20 = combine(r1,r0)
	}
	{
		r21 = #16
		if (p0.new) r19 = #8
		p0 = cmp.gtu(r20,r18); if (!p0.new) jump:t .LBB26_103
	}
// %bb.3:                               // %for.body.lr.ph
	{
		r24 = add(r27,#8200)
		v20 = vxor(v20,v20)
		vmem(r29+#2) = v20.new
	}                                       // 128-byte Folded Spill
	{
		r25 = ##16843009
		memw(r29+#244) = r22
		memd(r29+#248) = r21:20
	}                                       // 4-byte Folded Spill
	{
		v7 = valign(v20,v20,#4)
	}
	{
		v8.w = vadd(v20.w,v7.w)
	}
	{
		v9 = vror(v8,r19)
	}
	{
		v10.w = vadd(v8.w,v9.w)
	}
	{
		v11 = vror(v10,r21)
	}
	{
		v22.w = vadd(v10.w,v11.w)
		vmem(r29+#3) = v22.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB26_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB26_8 Depth 2
                                        //       Child Loop BB26_12 Depth 3
                                        //       Child Loop BB26_16 Depth 3
                                        //       Child Loop BB26_44 Depth 3
                                        //       Child Loop BB26_48 Depth 3
                                        //     Child Loop BB26_94 Depth 2
                                        //       Child Loop BB26_96 Depth 3
                                        //       Child Loop BB26_100 Depth 3
                                        //     Child Loop BB26_89 Depth 2
                                        //       Child Loop BB26_90 Depth 3
	{
		r16 = r27
		r2 = r18
	}
	{
		r16 += asl(r18,#9)
		r18 = add(r18,#1)
	}
	{
		r3 = memw(r16+#4)
	}
	{
		r3 = memw(r3+#44)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB26_76
	}
// %bb.5:                               // %land.lhs.true
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r22+#56)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB26_76
	}
// %bb.6:                               // %if.then
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r22+#16)
	}
	{
		r17 = mpyi(r3,r2)
	}
	{
		r26 = mpyi(r3,r18)
		if (!cmp.gtu(r26.new,r17)) jump:t ##.LBB26_75
	}
// %bb.7:                               // %for.body.i.preheader
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r22 = add(r27,#8208)
		r20 = add(r27,#8244)
		r21 = add(r27,#8264)
		r2 = memw(r24+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r23 = and(r2,#-128)
	}
	.falign
.LBB26_8:                               // %for.body.i
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_12 Depth 3
                                        //       Child Loop BB26_16 Depth 3
                                        //       Child Loop BB26_44 Depth 3
                                        //       Child Loop BB26_48 Depth 3
	{
		r19 = memw(r22+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r17)
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r3:2 = combine(r27,r17)
		r5 = #1
		r6 = memw(r20+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r19)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB26_18
		v0 = vmem(r4+#0)
	}
// %bb.10:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = mpyi(r5,r23)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB26_14
	}
// %bb.11:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r23)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB26_12,r9)
		r14 = mpyi(r14,r23)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r23)
		r13 = addasl(r4,r13,#2)
		v5.w = vadd(v0.w,v31.w)
		v31.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB26_13
	}
	.falign
.LBB26_12:                              //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r23)
		v1.w = vadd(v5.w,v0.w)
		v0.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v2 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r23)
		r12 = add(r5,#3)
		v3.w = vadd(v1.w,v2.w)
		v4 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r23)
		r5 = add(r5,#4)
		v5.w = vadd(v3.w,v4.w)
		v6 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r23)
		r9 = addasl(r4,r9,#2)
		v5.w = vadd(v5.w,v6.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB26_13:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = addasl(r4,r12,#2)
		v8.w = vadd(v5.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		v9.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v10.w,v11.w)
		v11.cur = vmem(r12+#0)
	}
	.falign
.LBB26_14:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = mpyi(r5,r23)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB26_18
	}
// %bb.15:                              // %for.body13.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB26_16,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB26_17
	}
	.balign 32
.LBB26_16:                              // %for.body13.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r5,r23)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v12.w)
		v12.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB26_17:                              //   in Loop: Header=BB26_8 Depth=2
	{
		v0.w = vadd(v0.w,v13.w)
		v13.cur = vmem(r8+#0)
	}
	.falign
.LBB26_18:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r5 = memw(r3+#4)
		vmem(r29+#4) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r24+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB26_21
	}
// %bb.19:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB26_21
	}
// %bb.20:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_21:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB26_26
	}
// %bb.22:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB26_24
	}
// %bb.23:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_24:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		if (p1) jump:nt .LBB26_27
	}
// %bb.25:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_27
	}
	.falign
.LBB26_26:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB26_27:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB26_32
	}
// %bb.28:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB26_30
	}
// %bb.29:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB26_41
	}
	.falign
.LBB26_30:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB26_33
	}
// %bb.31:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_33
	}
	.falign
.LBB26_32:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = r9
	}
	.falign
.LBB26_33:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB26_38
	}
// %bb.34:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB26_36
	}
// %bb.35:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB26_41
	}
	.falign
.LBB26_36:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB26_39
	}
// %bb.37:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB26_41
	}
	{
		jump .LBB26_39
	}
	.falign
.LBB26_38:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB26_39:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r8 = #3
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB26_41
	}
// %bb.40:                              // %if.end.i.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		v12.w = vasl(v0.w,r8)
	}
	{
		v13.w = vsub(v12.w,v0.w)
		vmem(r29+#4) = v13.new
	}
	.falign
.LBB26_41:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB26_50
		v1 = vmem(r7+#0)
	}
// %bb.42:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = mpyi(r6,r23)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB26_46
	}
// %bb.43:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r23)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB26_44,r9)
		r14 = mpyi(r14,r23)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r23)
		r13 = addasl(r7,r13,#2)
		v4.w = vadd(v1.w,v14.w)
		v14.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB26_45
	}
	.falign
.LBB26_44:                              //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r23)
		v16.w = vadd(v4.w,v15.w)
		v15.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v17 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r23)
		r12 = add(r6,#3)
		v18.w = vadd(v16.w,v17.w)
		v19 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r23)
		r6 = add(r6,#4)
		v20.w = vadd(v18.w,v19.w)
		v21 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r23)
		r9 = addasl(r7,r9,#2)
		v4.w = vadd(v20.w,v21.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB26_45:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r12 = addasl(r7,r12,#2)
		v23.w = vadd(v4.w,v22.w)
		v22.cur = vmem(r13+#0)
	}
	{
		v25.w = vadd(v23.w,v24.w)
		v24.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v25.w,v26.w)
		v26.cur = vmem(r12+#0)
	}
	.falign
.LBB26_46:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r9 = mpyi(r6,r23)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB26_50
	}
// %bb.47:                              // %for.body13.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB26_48,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB26_49
	}
	.balign 32
.LBB26_48:                              // %for.body13.1.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_8 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r6,r23)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v27.w)
		v27.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB26_49:                              //   in Loop: Header=BB26_8 Depth=2
	{
		v1.w = vadd(v1.w,v28.w)
		v28.cur = vmem(r8+#0)
	}
	.falign
.LBB26_50:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		vmem(r29+#5) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB26_53
	}
// %bb.51:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB26_53
	}
// %bb.52:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB26_73
	}
	.falign
.LBB26_53:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB26_58
	}
// %bb.54:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB26_56
	}
// %bb.55:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB26_73
	}
	.falign
.LBB26_56:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		if (p0) jump:nt .LBB26_59
	}
// %bb.57:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_59
	}
	.falign
.LBB26_58:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB26_59:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB26_64
	}
// %bb.60:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB26_62
	}
// %bb.61:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB26_73
	}
	.falign
.LBB26_62:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB26_65
	}
// %bb.63:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_65
	}
	.falign
.LBB26_64:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = r7
	}
	.falign
.LBB26_65:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB26_70
	}
// %bb.66:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB26_68
	}
// %bb.67:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB26_73
	}
	.falign
.LBB26_68:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB26_71
	}
// %bb.69:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB26_73
	}
	{
		jump .LBB26_71
	}
	.falign
.LBB26_70:                              //   in Loop: Header=BB26_8 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB26_71:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r6 = #3
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB26_73
	}
// %bb.72:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		v29.w = vasl(v1.w,r6)
	}
	{
		v30.w = vsub(v29.w,v1.w)
		vmem(r29+#5) = v30.new
	}
	.falign
.LBB26_73:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#512)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.74:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB26_8 Depth=2
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r26)) jump:t ##.LBB26_8
	}
	.falign
.LBB26_75:                              // %moe_tl2_gate_epilogue.exit
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r19 = #8
		r21:20 = memd(r29+#248)
		r22 = memw(r29+#244)
	}                                       // 8-byte Folded Reload
	{
		r21 = #16
	}
	.falign
.LBB26_76:                              // %if.end
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_80
	}
// %bb.77:                              // %if.then6
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = #1
		r2 = #1
		r7:6 = memd(r16+#40)
		r0 = memw(r16+#36)
	}
	{
		r4 = r7
		r3 = memw(r24+#0)
		r5 = memw(r16+#48)
	}
	{
		memw(r29+#0) = r6
		memw(r29+#16) = #0
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_rows_u8_params_rm
		memw(r29+#4) = #0
	}
	.falign
// %bb.78:                              // %if.then6
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = ##-1431655765
		r1 = memw(r24+#0)
		r0 = memw(r16+#40)
	}
	{
		r2 = add(r1,#23)
		r4 = memw(r16+#384)
	}
	{
		r3 = mpyu(r2,r3)
		r2 = #0
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
.LBB26_79:                              // %cleanup
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		p2 = cmp.gtu(r20,r18)
		if (p2.new) jump:t .LBB26_4
	}
	{
		jump .LBB26_103
	}
	.falign
.LBB26_80:                              // %if.end11
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r24+#0)
	}
	{
		r2 = add(r1,#3)
	}
	{
		r17 = and(r2,#-4)
		if (!cmp.gtu(r17.new,r1)) jump:t .LBB26_83
	}
// %bb.81:                              // %if.then17
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r5 = mpyi(r3,r1)
		r2 = sub(r17,r1)
		r1 = #0
		r4 = memw(r16+#36)
	}
	{
		r2 = mpyi(r2,r3)
		r0 = addasl(r4,r5,#2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.82:                              // %if.then17
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r24+#0)
	}
	.falign
.LBB26_83:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = #64
		r0 = memw(r16+#36)
		r4 = memw(r16+#44)
	}
	{
		call hvx_quant_rows_u8_params
		r5 = memw(r16+#48)
		memw(r29+#0) = #0

	} :mem_noshuf
	.falign
// %bb.84:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r1 = #0
		r7:6 = memd(r16+#40)
		r2 = memw(r16+#48)
	}
	{
		r5 = r7
		r0 = memw(r16+#36)
		r4 = memw(r24+#0)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r17,#0)
		memw(r29+#0) = r2
		memw(r29+#4) = r6
	}
	.falign
// %bb.85:                              // %if.end26
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_79
	}
// %bb.86:                              // %if.then39
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r5 = add(r16,#72)
		r9:8 = combine(#1,#0)
		r2 = memw(r16+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_79
	}
// %bb.87:                              // %for.body.lr.ph.i93
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r3 = memw(r24+#0)
		r4 = memw(r16+#48)
	}
	{
		p2 = cmp.gtu(r3,#31)
		if (p2.new) r7 = add(r2,#3)
		if (p2.new) jump:t .LBB26_93
		r6 = memw(r16+#40)
	}
// %bb.88:                              // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB26_4 Depth=1
	{
		r6 = add(r2,#3)
	}
	{
		r8 = lsr(r6,#2)
		r7:6 = combine(#1,#0)
	}
	{
		loop1(.LBB26_89,r8)
	}
	.falign
.LBB26_89:                              // Block address taken
                                        // %for.body.i95
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_90 Depth 3
	{
		r8 = addasl(r4,r6,#2)
		r9 = addasl(r5,r6,#2)
		r12 = add(r29,#512)
		r13 = #0
	}
	{
		v21.cur = vmem(r29+#3)
		vmem(r29+#4) = v21
	}                                       // 128-byte Folded Reload
	.falign
.LBB26_90:                              // %for.body11.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_89 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r13,#2)
		r14 = memw(r8++#4)
		r15 = memw(r12+#0)
	}
	{
		r15 -= mpyi(r14,r3)
		if (p1) jump:nt .LBB26_92
		memw(r9++#4) = r15.new
	}
// %bb.91:                              // %for.body11.i
                                        //   in Loop: Header=BB26_90 Depth=3
	{
		r14 = add(r7,r13)
		r12 = add(r12,#32)
		r13 = add(r13,#1)
	}
	{
		p0 = cmp.gtu(r2,r14)
		if (p0.new) jump:t .LBB26_90
	}
	.falign
.LBB26_92:                              // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB26_89 Depth=2
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	{
		jump .LBB26_79
	}
	.falign
.LBB26_93:                              //   in Loop: Header=BB26_4 Depth=1
	{
		r12 = lsr(r7,#2)
		r7 = lsr(r3,#5)
	}
	{
		loop1(.LBB26_94,r12)
	}
	.falign
.LBB26_94:                              // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB26_96 Depth 3
                                        //       Child Loop BB26_100 Depth 3
	{
		r12 = addasl(r6,r8,#5)
		p1 = cmp.gtu(r7,#2)
		r13 = add(r7,#-2)
		p2 = cmp.gtu(r7,#1)
	}
	{
		r12 = add(r12,#2048)
		if (!p2) jump:nt .LBB26_98
		v3 = vmemu(r12+#0)
	}
// %bb.95:                              // %for.body4.us.i
                                        //   in Loop: Header=BB26_94 Depth=2
	{
		loop0(.LBB26_96,r13)
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		if (!p1) jump:nt .LBB26_97
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.balign 32
.LBB26_96:                              // %for.body4.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_94 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r25.ub)
		v3 = v6
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		nop
	} :endloop0
	.falign
.LBB26_97:                              //   in Loop: Header=BB26_94 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r25.ub)
		jump .LBB26_99
		v3 = v6
	}
	.falign
.LBB26_98:                              //   in Loop: Header=BB26_94 Depth=2
	{
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB26_99:                              //   in Loop: Header=BB26_94 Depth=2
	{
		r12 = addasl(r4,r8,#2)
		v2.uw += vrmpy(v3.ub,r25.ub)
		r14 = #0
		r15 = add(r29,#512)
	}
	{
		r13 = addasl(r5,r8,#2)
	}
	{
		v14 = valign(v2,v2,#4)
	}
	{
		v15.w = vadd(v2.w,v14.w)
	}
	{
		v16 = vror(v15,r19)
	}
	{
		v17.w = vadd(v15.w,v16.w)
	}
	{
		v18 = vror(v17,r21)
	}
	{
		v19.w = vadd(v17.w,v18.w)
		vmem(r29+#4) = v19.new
	}
	.falign
.LBB26_100:                             // %for.body11.us.i
                                        //   Parent Loop BB26_4 Depth=1
                                        //     Parent Loop BB26_94 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r14,#2)
		r28 = memw(r12++#4)
		r0 = memw(r15+#0)
	}
	{
		r0 -= mpyi(r28,r3)
		if (p1) jump:nt .LBB26_102
		memw(r13++#4) = r0.new
	}
// %bb.101:                             // %for.body11.us.i
                                        //   in Loop: Header=BB26_100 Depth=3
	{
		r28 = add(r9,r14)
		r15 = add(r15,#32)
		r14 = add(r14,#1)
	}
	{
		p0 = cmp.gtu(r2,r28)
		if (p0.new) jump:t .LBB26_100
	}
	.falign
.LBB26_102:                             // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB26_94 Depth=2
	{
		r8 = add(r8,#4)
		r9 = add(r9,#4)
		nop
	} :endloop1
	{
		jump .LBB26_79
	}
	.falign
.LBB26_103:                             // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end26:
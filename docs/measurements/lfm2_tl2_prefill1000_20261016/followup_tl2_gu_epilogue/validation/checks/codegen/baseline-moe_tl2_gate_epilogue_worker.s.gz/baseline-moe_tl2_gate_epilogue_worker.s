moe_tl2_gate_epilogue_worker:           // @moe_tl2_gate_epilogue_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#640):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r19 = add(r2,#8200)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r2)
		r21:20 = memd(r19+#56)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r21 = sub(r21,r20)
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r0 = mpyi(r21,r1)
		call __hexagon_udivsi3
		r1 = r18
	}
	.falign
// %bb.1:                               // %entry
	{
		r17 = add(r0,r20)
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r21,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.2:                               // %entry
	{
		r21 = add(r16,#8208)
		r20 = add(r0,r20)
		if (!cmp.gtu(r20.new,r17)) jump:t ##.LBB24_71
	}
// %bb.3:                               // %for.body.lr.ph.i
	{
		r22 = add(r16,#8244)
		r23 = add(r16,#8264)
		r24 = #3
		r2 = memw(r19+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r25 = and(r2,#-128)
	}
	.falign
.LBB24_4:                               // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB24_8 Depth 2
                                        //     Child Loop BB24_12 Depth 2
                                        //     Child Loop BB24_40 Depth 2
                                        //     Child Loop BB24_44 Depth 2
	{
		r18 = memw(r21+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.5:                               // %for.body.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r3:2 = combine(r16,r17)
		r5 = #1
		r6 = memw(r22+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB24_14
		v0 = vmem(r4+#0)
	}
// %bb.6:                               // %for.body13.i.preheader
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = mpyi(r5,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB24_10
	}
// %bb.7:                               //   in Loop: Header=BB24_4 Depth=1
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB24_8,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r4,r13,#2)
		v3.w = vadd(v0.w,v23.w)
		v23.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB24_9
	}
	.falign
.LBB24_8:                               //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r25)
		v25.w = vadd(v3.w,v24.w)
		v24.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v26 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r5,#3)
		v27.w = vadd(v25.w,v26.w)
		v28 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r5 = add(r5,#4)
		v29.w = vadd(v27.w,v28.w)
		v30 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r4,r9,#2)
		v3.w = vadd(v29.w,v30.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB24_9:                               //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = addasl(r4,r12,#2)
		v0.w = vadd(v3.w,v31.w)
		v31.cur = vmem(r13+#0)
	}
	{
		v2.w = vadd(v0.w,v1.w)
		v1.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v2.w,v3.w)
		v3.cur = vmem(r12+#0)
	}
	.falign
.LBB24_10:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = mpyi(r5,r25)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB24_14
	}
// %bb.11:                              // %for.body13.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB24_12,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB24_13
	}
	.balign 32
.LBB24_12:                              // %for.body13.i
                                        //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r5,r25)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v4.w)
		v4.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB24_13:                              //   in Loop: Header=BB24_4 Depth=1
	{
		v0.w = vadd(v0.w,v5.w)
		v5.cur = vmem(r8+#0)
	}
	.falign
.LBB24_14:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r5 = memw(r3+#4)
		vmem(r29+#2) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r19+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB24_17
	}
// %bb.15:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB24_17
	}
// %bb.16:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_17:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB24_22
	}
// %bb.18:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB24_20
	}
// %bb.19:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_20:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		if (p1) jump:nt .LBB24_23
	}
// %bb.21:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_23
	}
	.falign
.LBB24_22:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB24_23:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB24_28
	}
// %bb.24:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB24_26
	}
// %bb.25:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB24_37
	}
	.falign
.LBB24_26:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB24_29
	}
// %bb.27:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_29
	}
	.falign
.LBB24_28:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r8 = r9
	}
	.falign
.LBB24_29:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB24_34
	}
// %bb.30:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB24_32
	}
// %bb.31:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB24_37
	}
	.falign
.LBB24_32:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB24_35
	}
// %bb.33:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB24_37
	}
	{
		jump .LBB24_35
	}
	.falign
.LBB24_34:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB24_35:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB24_37
		v4.w = vasl(v0.w,r24)
	}
// %bb.36:                              // %if.end.i.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		v5.w = vsub(v4.w,v0.w)
		vmem(r29+#2) = v5.new
	}
	.falign
.LBB24_37:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB24_46
		v1 = vmem(r7+#0)
	}
// %bb.38:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = mpyi(r6,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB24_42
	}
// %bb.39:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB24_40,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r7,r13,#2)
		v2.w = vadd(v1.w,v6.w)
		v6.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB24_41
	}
	.falign
.LBB24_40:                              //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r25)
		v8.w = vadd(v2.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v9 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r6,#3)
		v10.w = vadd(v8.w,v9.w)
		v11 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r6 = add(r6,#4)
		v12.w = vadd(v10.w,v11.w)
		v13 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r7,r9,#2)
		v2.w = vadd(v12.w,v13.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB24_41:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r12 = addasl(r7,r12,#2)
		v15.w = vadd(v2.w,v14.w)
		v14.cur = vmem(r13+#0)
	}
	{
		v17.w = vadd(v15.w,v16.w)
		v16.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v17.w,v18.w)
		v18.cur = vmem(r12+#0)
	}
	.falign
.LBB24_42:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r9 = mpyi(r6,r25)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB24_46
	}
// %bb.43:                              // %for.body13.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB24_44,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB24_45
	}
	.balign 32
.LBB24_44:                              // %for.body13.1.i
                                        //   Parent Loop BB24_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r6,r25)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v19.w)
		v19.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB24_45:                              //   in Loop: Header=BB24_4 Depth=1
	{
		v1.w = vadd(v1.w,v20.w)
		v20.cur = vmem(r8+#0)
	}
	.falign
.LBB24_46:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		vmem(r29+#3) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB24_49
	}
// %bb.47:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB24_49
	}
// %bb.48:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB24_69
	}
	.falign
.LBB24_49:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_54
	}
// %bb.50:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB24_52
	}
// %bb.51:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB24_69
	}
	.falign
.LBB24_52:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		if (p0) jump:nt .LBB24_55
	}
// %bb.53:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_55
	}
	.falign
.LBB24_54:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB24_55:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB24_60
	}
// %bb.56:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB24_58
	}
// %bb.57:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB24_69
	}
	.falign
.LBB24_58:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB24_61
	}
// %bb.59:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_61
	}
	.falign
.LBB24_60:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r6 = r7
	}
	.falign
.LBB24_61:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_66
	}
// %bb.62:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB24_64
	}
// %bb.63:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB24_69
	}
	.falign
.LBB24_64:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB24_67
	}
// %bb.65:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB24_69
	}
	{
		jump .LBB24_67
	}
	.falign
.LBB24_66:                              //   in Loop: Header=BB24_4 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB24_67:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB24_69
		v21.w = vasl(v1.w,r24)
	}
// %bb.68:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		v22.w = vsub(v21.w,v1.w)
		vmem(r29+#3) = v22.new
	}
	.falign
.LBB24_69:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r23+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#256)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.70:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB24_4 Depth=1
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r20)) jump:t ##.LBB24_4
	}
	.falign
.LBB24_71:                              // %moe_tl2_gate_epilogue.exit
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end24:
moe_m1_requant_worker:                  // @moe_m1_requant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r23 = add(r2,#8192)
		r17 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r25:24 = combine(#0,r0)
		r16 = memw(r23+#0)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r19 = r2
		r3:2 = combine(r25,r24)
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r16,r1)
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r3 = r25
		r21:20 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r16,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r25,r24)
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
// %bb.2:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r20)
		if (p0.new) r25 = add(r19,##8200)
	}
	{
		if (p0) r26 = ##16843009
		if (!p0) jump:nt .LBB27_119
		memd(r29+#240) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %for.body.lr.ph
	{
		r21 = #8
		r22 = #16
		v20 = vxor(v20,v20)
		vmem(r29+#2) = v20.new
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#236) = r23
	}                                       // 4-byte Folded Spill
	{
		v7 = valign(v20,v20,#4)
	}
	{
		v8.w = vadd(v20.w,v7.w)
	}
	{
		v9 = vror(v8,r21)
	}
	{
		v10.w = vadd(v8.w,v9.w)
	}
	{
		v11 = vror(v10,r22)
	}
	{
		v22.w = vadd(v10.w,v11.w)
		vmem(r29+#3) = v22.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB27_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB27_24 Depth 2
                                        //       Child Loop BB27_28 Depth 3
                                        //       Child Loop BB27_32 Depth 3
                                        //       Child Loop BB27_60 Depth 3
                                        //       Child Loop BB27_64 Depth 3
                                        //     Child Loop BB27_110 Depth 2
                                        //       Child Loop BB27_112 Depth 3
                                        //       Child Loop BB27_116 Depth 3
                                        //     Child Loop BB27_105 Depth 2
                                        //       Child Loop BB27_106 Depth 3
	{
		r17:16 = combine(r20,r19)
	}
	{
		r16 += asl(r20,#9)
		r20 = add(r20,#1)
	}
	{
		r18 = memw(r16+#4)
	}
	{
		r2 = memw(r18+#44)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_92
	}
// %bb.5:                               // %land.lhs.true
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r27 = add(r19,#8208)
		r2 = memw(r23+#56)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_92
	}
// %bb.6:                               // %land.lhs.true2
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r22 = add(r19,#8244)
		r21 = add(r19,#8264)
	}
	{
		r2 = memw(r23+#48)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_21
	}
// %bb.7:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r24 = memw(r25+#0)
	}
	{
		r2 = memw(r23+#4)
		if (!cmp.eq(r2.new,r2)) jump:nt .LBB27_22
	}
// %bb.8:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #48
		p1 = cmp.eq(r24,##1536)
		if (!p1.new) jump:nt .LBB27_22
	}
// %bb.9:                               // %lor.lhs.false3.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = #1536
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_22
	}
// %bb.10:                              // %lor.lhs.false5.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #2048
	}
	{
		r2 = memw(r23+#28)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_22
	}
// %bb.11:                              // %lor.lhs.false7.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_22
	}
// %bb.12:                              // %lor.lhs.false9.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB27_22
	}
// %bb.13:                              // %lor.lhs.false11.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_22
	}
// %bb.14:                              // %lor.lhs.false15.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r23 = memw(r16+#8)
	}
	{
		r2 = memw(r23+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_22
	}
// %bb.15:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
		r0 = add(r18,#88)
	}
	.falign
// %bb.16:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		if (p0.new) r0 = add(r23,#88)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB27_22
	}
// %bb.17:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.18:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = #32
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB27_22
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.19:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = add(r29,#512)
		r0 = #1
		r5:4 = memd(r16+#24)
		r7:6 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = combine(#0,#1)
		memw(r29+#528) = r3
		memw(r29+#532) = r0
	}
	{
		r4 = #1536
		r3 = memw(r16+#20)
		memw(r29+#540) = r4
	}
	{
		memw(r29+#536) = r3
		memw(r29+#524) = r7
	}
	{
		r3 = memw(r18+#12)
		memw(r29+#544) = r3.new
	}
	{
		r3 = #48
		memw(r29+#520) = r3.new
	}
	{
		r3 = memw(r18+#8)
		memw(r29+#512) = r5
	}
	{
		r3 = #128
		memw(r29+#548) = r3
	}
	{
		r3 = memw(r18+#16)
		memw(r29+#516) = r3
	}
	{
		r3 = memw(r16+#36)
		memw(r29+#552) = r3
	}
	{
		memw(r29+#556) = r4
		memw(r29+#564) = r4
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#568) = r7
		memw(r29+#560) = r3
	}
	.falign
// %bb.20:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r21 = #8 ; jump .LBB27_92
		r22 = #16
	}
	.falign
.LBB27_21:                              // %land.lhs.true2.if.then_crit_edge
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = memw(r25+#0)
	}
	.falign
.LBB27_22:                              // %if.then
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r27+#0)
	}
	{
		r17 = mpyi(r2,r17)
	}
	{
		r23 = mpyi(r2,r20)
		if (!cmp.gtu(r23.new,r17)) jump:t ##.LBB27_91
	}
// %bb.23:                              // %for.body.i.preheader
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = add(#127,asl(r24,#1))
	}
	{
		r24 = and(r24,#-128)
	}
	.falign
.LBB27_24:                              // %for.body.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_28 Depth 3
                                        //       Child Loop BB27_32 Depth 3
                                        //       Child Loop BB27_60 Depth 3
                                        //       Child Loop BB27_64 Depth 3
	{
		r18 = memw(r27+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.25:                              // %for.body.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r3:2 = combine(r19,r17)
		r5 = #1
		r6 = memw(r22+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB27_34
		v0 = vmem(r4+#0)
	}
// %bb.26:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = mpyi(r5,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB27_30
	}
// %bb.27:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_28,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r4,r13,#2)
		v5.w = vadd(v0.w,v31.w)
		v31.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB27_29
	}
	.falign
.LBB27_28:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r24)
		v1.w = vadd(v5.w,v0.w)
		v0.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v2 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r5,#3)
		v3.w = vadd(v1.w,v2.w)
		v4 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r5 = add(r5,#4)
		v5.w = vadd(v3.w,v4.w)
		v6 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r4,r9,#2)
		v5.w = vadd(v5.w,v6.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_29:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = addasl(r4,r12,#2)
		v8.w = vadd(v5.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		v9.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v10.w,v11.w)
		v11.cur = vmem(r12+#0)
	}
	.falign
.LBB27_30:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = mpyi(r5,r24)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB27_34
	}
// %bb.31:                              // %for.body13.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB27_32,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB27_33
	}
	.balign 32
.LBB27_32:                              // %for.body13.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r5,r24)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v12.w)
		v12.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_33:                              //   in Loop: Header=BB27_24 Depth=2
	{
		v0.w = vadd(v0.w,v13.w)
		v13.cur = vmem(r8+#0)
	}
	.falign
.LBB27_34:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r5 = memw(r3+#4)
		vmem(r29+#4) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r25+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB27_37
	}
// %bb.35:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB27_37
	}
// %bb.36:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_37:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_42
	}
// %bb.38:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_40
	}
// %bb.39:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_40:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		if (p1) jump:nt .LBB27_43
	}
// %bb.41:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_43
	}
	.falign
.LBB27_42:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_43:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB27_48
	}
// %bb.44:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB27_46
	}
// %bb.45:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_46:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB27_49
	}
// %bb.47:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_49
	}
	.falign
.LBB27_48:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = r9
	}
	.falign
.LBB27_49:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_54
	}
// %bb.50:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_52
	}
// %bb.51:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB27_57
	}
	.falign
.LBB27_52:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB27_55
	}
// %bb.53:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_55
	}
	.falign
.LBB27_54:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_55:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = #3
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB27_57
	}
// %bb.56:                              // %if.end.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		v12.w = vasl(v0.w,r8)
	}
	{
		v13.w = vsub(v12.w,v0.w)
		vmem(r29+#4) = v13.new
	}
	.falign
.LBB27_57:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB27_66
		v1 = vmem(r7+#0)
	}
// %bb.58:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = mpyi(r6,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB27_62
	}
// %bb.59:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_60,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r7,r13,#2)
		v4.w = vadd(v1.w,v14.w)
		v14.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB27_61
	}
	.falign
.LBB27_60:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r24)
		v16.w = vadd(v4.w,v15.w)
		v15.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v17 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r6,#3)
		v18.w = vadd(v16.w,v17.w)
		v19 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r6 = add(r6,#4)
		v20.w = vadd(v18.w,v19.w)
		v21 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r7,r9,#2)
		v4.w = vadd(v20.w,v21.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_61:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = addasl(r7,r12,#2)
		v23.w = vadd(v4.w,v22.w)
		v22.cur = vmem(r13+#0)
	}
	{
		v25.w = vadd(v23.w,v24.w)
		v24.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v25.w,v26.w)
		v26.cur = vmem(r12+#0)
	}
	.falign
.LBB27_62:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = mpyi(r6,r24)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB27_66
	}
// %bb.63:                              // %for.body13.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB27_64,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB27_65
	}
	.balign 32
.LBB27_64:                              // %for.body13.1.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r6,r24)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v27.w)
		v27.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_65:                              //   in Loop: Header=BB27_24 Depth=2
	{
		v1.w = vadd(v1.w,v28.w)
		v28.cur = vmem(r8+#0)
	}
	.falign
.LBB27_66:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		vmem(r29+#5) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_69
	}
// %bb.67:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_69
	}
// %bb.68:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB27_89
	}
	.falign
.LBB27_69:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_74
	}
// %bb.70:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_72
	}
// %bb.71:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_89
	}
	.falign
.LBB27_72:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		if (p0) jump:nt .LBB27_75
	}
// %bb.73:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_75
	}
	.falign
.LBB27_74:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_75:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB27_80
	}
// %bb.76:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_78
	}
// %bb.77:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB27_89
	}
	.falign
.LBB27_78:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB27_81
	}
// %bb.79:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_81
	}
	.falign
.LBB27_80:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = r7
	}
	.falign
.LBB27_81:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_86
	}
// %bb.82:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_84
	}
// %bb.83:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_89
	}
	.falign
.LBB27_84:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_87
	}
// %bb.85:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_87
	}
	.falign
.LBB27_86:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_87:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = #3
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB27_89
	}
// %bb.88:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		v29.w = vasl(v1.w,r6)
	}
	{
		v30.w = vsub(v29.w,v1.w)
		vmem(r29+#5) = v30.new
	}
	.falign
.LBB27_89:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#512)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.90:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r23)) jump:t ##.LBB27_24
	}
	.falign
.LBB27_91:                              // %moe_tl2_gate_epilogue.exit
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r21 = #8
		r22 = #16
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB27_92:                              // %if.end
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_96
	}
// %bb.93:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #1
		r2 = #1
		r7:6 = memd(r16+#40)
		r0 = memw(r16+#36)
	}
	{
		r4 = r7
		r3 = memw(r25+#0)
		r5 = memw(r16+#48)
	}
	{
		memw(r29+#0) = r6
		memw(r29+#16) = #0
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_rows_u8_params_rm
		memw(r29+#4) = #0
	}
	.falign
// %bb.94:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = ##-1431655765
		r1 = memw(r25+#0)
		r0 = memw(r16+#40)
	}
	{
		r2 = add(r1,#23)
		r4 = memw(r16+#384)
	}
	{
		r3 = mpyu(r2,r3)
		r2 = #0
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
.LBB27_95:                              // %cleanup
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1:0 = memd(r29+#240)
	}                                       // 8-byte Folded Reload
	{
		p2 = cmp.gtu(r0,r20)
		if (p2.new) jump:t .LBB27_4
	}
	{
		jump .LBB27_119
	}
	.falign
.LBB27_96:                              // %if.end13
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	{
		r2 = add(r1,#3)
	}
	{
		r17 = and(r2,#-4)
		if (!cmp.gtu(r17.new,r1)) jump:t .LBB27_99
	}
// %bb.97:                              // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = mpyi(r3,r1)
		r2 = sub(r17,r1)
		r1 = #0
		r4 = memw(r16+#36)
	}
	{
		r2 = mpyi(r2,r3)
		r0 = addasl(r4,r5,#2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.98:                              // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	.falign
.LBB27_99:                              // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r0 = memw(r16+#36)
		r4 = memw(r16+#44)
	}
	{
		call hvx_quant_rows_u8_params
		r5 = memw(r16+#48)
		memw(r29+#0) = #0

	} :mem_noshuf
	.falign
// %bb.100:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #0
		r7:6 = memd(r16+#40)
		r2 = memw(r16+#48)
	}
	{
		r5 = r7
		r0 = memw(r16+#36)
		r4 = memw(r25+#0)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r17,#0)
		memw(r29+#0) = r2
		memw(r29+#4) = r6
	}
	.falign
// %bb.101:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_95
	}
// %bb.102:                             // %if.then41
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = add(r16,#72)
		r9:8 = combine(#1,#0)
		r2 = memw(r16+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_95
	}
// %bb.103:                             // %for.body.lr.ph.i111
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = memw(r25+#0)
		r4 = memw(r16+#48)
	}
	{
		p2 = cmp.gtu(r3,#31)
		if (p2.new) r7 = add(r2,#3)
		if (p2.new) jump:t .LBB27_109
		r6 = memw(r16+#40)
	}
// %bb.104:                             // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r6 = add(r2,#3)
	}
	{
		r8 = lsr(r6,#2)
		r7:6 = combine(#1,#0)
	}
	{
		loop1(.LBB27_105,r8)
	}
	.falign
.LBB27_105:                             // Block address taken
                                        // %for.body.i113
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_106 Depth 3
	{
		r8 = addasl(r4,r6,#2)
		r9 = addasl(r5,r6,#2)
		r12 = add(r29,#512)
		r13 = #0
	}
	{
		v21.cur = vmem(r29+#3)
		vmem(r29+#4) = v21
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_106:                             // %for.body11.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_105 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r13,#2)
		r14 = memw(r8++#4)
		r15 = memw(r12+#0)
	}
	{
		r15 -= mpyi(r14,r3)
		if (p1) jump:nt .LBB27_108
		memw(r9++#4) = r15.new
	}
// %bb.107:                             // %for.body11.i
                                        //   in Loop: Header=BB27_106 Depth=3
	{
		r14 = add(r7,r13)
		r12 = add(r12,#32)
		r13 = add(r13,#1)
	}
	{
		p0 = cmp.gtu(r2,r14)
		if (p0.new) jump:t .LBB27_106
	}
	.falign
.LBB27_108:                             // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB27_105 Depth=2
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	{
		jump .LBB27_95
	}
	.falign
.LBB27_109:                             //   in Loop: Header=BB27_4 Depth=1
	{
		r12 = lsr(r7,#2)
		r7 = lsr(r3,#5)
	}
	{
		loop1(.LBB27_110,r12)
	}
	.falign
.LBB27_110:                             // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_112 Depth 3
                                        //       Child Loop BB27_116 Depth 3
	{
		r12 = addasl(r6,r8,#5)
		p1 = cmp.gtu(r7,#2)
		r13 = add(r7,#-2)
		p2 = cmp.gtu(r7,#1)
	}
	{
		r12 = add(r12,#2048)
		if (!p2) jump:nt .LBB27_114
		v3 = vmemu(r12+#0)
	}
// %bb.111:                             // %for.body4.us.i
                                        //   in Loop: Header=BB27_110 Depth=2
	{
		loop0(.LBB27_112,r13)
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		if (!p1) jump:nt .LBB27_113
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.balign 32
.LBB27_112:                             // %for.body4.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_110 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		v3 = v6
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		nop
	} :endloop0
	.falign
.LBB27_113:                             //   in Loop: Header=BB27_110 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		jump .LBB27_115
		v3 = v6
	}
	.falign
.LBB27_114:                             //   in Loop: Header=BB27_110 Depth=2
	{
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_115:                             //   in Loop: Header=BB27_110 Depth=2
	{
		r12 = addasl(r4,r8,#2)
		v2.uw += vrmpy(v3.ub,r26.ub)
		r14 = #0
		r15 = add(r29,#512)
	}
	{
		r13 = addasl(r5,r8,#2)
	}
	{
		v14 = valign(v2,v2,#4)
	}
	{
		v15.w = vadd(v2.w,v14.w)
	}
	{
		v16 = vror(v15,r21)
	}
	{
		v17.w = vadd(v15.w,v16.w)
	}
	{
		v18 = vror(v17,r22)
	}
	{
		v19.w = vadd(v17.w,v18.w)
		vmem(r29+#4) = v19.new
	}
	.falign
.LBB27_116:                             // %for.body11.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_110 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r14,#2)
		r28 = memw(r12++#4)
		r0 = memw(r15+#0)
	}
	{
		r0 -= mpyi(r28,r3)
		if (p1) jump:nt .LBB27_118
		memw(r13++#4) = r0.new
	}
// %bb.117:                             // %for.body11.us.i
                                        //   in Loop: Header=BB27_116 Depth=3
	{
		r28 = add(r9,r14)
		r15 = add(r15,#32)
		r14 = add(r14,#1)
	}
	{
		p0 = cmp.gtu(r2,r28)
		if (p0.new) jump:t .LBB27_116
	}
	.falign
.LBB27_118:                             // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB27_110 Depth=2
	{
		r8 = add(r8,#4)
		r9 = add(r9,#4)
		nop
	} :endloop1
	{
		jump .LBB27_95
	}
	.falign
.LBB27_119:                             // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end27:
moe_tl2_gate_epilogue_worker:           // @moe_tl2_gate_epilogue_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#640):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r2 = add(r2,#8196)
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r19 = add(r16,#8200)
		r3 = memw(r2+#12)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r3,#48)
		r20 = add(r16,#8244)
		r4 = memw(r2+#64)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r21 = add(r16,#8264)
		r22 = memw(r2+#60)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r23 = sub(r4,r22)
		if (p1) r4 = add(r22,#0)
		if (!p1) jump:nt .LBB25_18
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r23,#48)
		if (p0.new) r3 = ##-1431655765
		if (!p0.new) jump:nt .LBB25_18
	}
// %bb.2:                               // %entry
	{
		r3 = mpyu(r22,r3)
	}
	{
		r3 = lsr(r3,#5)
	}
	{
		r4 -= mpyi(r3,#48)
		if (!cmp.eq(r4.new,#0)) jump:nt .LBB25_18
	}
// %bb.3:                               // %land.lhs.true7
	{
		r4 = memw(r2+#44)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB25_18
	}
// %bb.4:                               // %lor.lhs.false.i
	{
		r4 = #64
	}
	{
		r4 = memw(r2+#0)
		if (!cmp.eq(r4.new,r4)) jump:t .LBB25_18
	}
// %bb.5:                               // %lor.lhs.false1.i
	{
		r4 = #1536
	}
	{
		r4 = memw(r19+#0)
		if (!cmp.eq(r4.new,r4)) jump:t .LBB25_18
	}
// %bb.6:                               // %lor.lhs.false5.i
	{
		r2 = memw(r2+#24)
	}
	{
		p1 = cmp.eq(r2,##2048)
		if (p1.new) r24 = add(r16,#0)
		if (!p1.new) jump:t .LBB25_18
	}
// %bb.7:                               // %lor.lhs.false7.i
	{
		r2 = memw(r20+#0)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB25_18
	}
// %bb.8:                               // %lor.lhs.false9.i
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB25_18
	}
// %bb.9:                               // %lor.lhs.false11.i
	{
		r24 += asl(r3,#9)
	}
	{
		r2 = memw(r24+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB25_18
	}
// %bb.10:                              // %lor.lhs.false13.i
	{
		r25 = memw(r24+#4)
	}
	{
		r2 = memw(r25+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_18
	}
// %bb.11:                              // %lor.lhs.false15.i
	{
		r26 = memw(r24+#8)
	}
	{
		r2 = memw(r26+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_18
	}
// %bb.12:                              // %lor.lhs.false18.i
	{
		call htp_tl2_palette_magnitude
		r0 = add(r25,#88)
	}
	.falign
// %bb.13:                              // %lor.lhs.false18.i
	{
		if (p1.new) r0 = add(r26,#88)
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB25_18
	}
// %bb.14:                              // %lor.lhs.false21.i
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.15:                              // %lor.lhs.false21.i
	{
		r5:4 = combine(#0,#48)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB25_18
		if (p0.new) r3:2 = memd(r24+#24)
	}
// %bb.16:                              // %if.end.i
	{
		r1:0 = combine(r17,r18)
		r6 = #1536
		r7 = memw(r24+#20)
		memw(r29+#268) = r5
	}
	{
		r2 = #32
		r3 = #128
		memw(r29+#284) = r2
		memw(r29+#256) = r3
	}
	{
		r2 = #1
		memw(r29+#272) = r2
		memw(r29+#280) = r7
	}
	{
		memw(r29+#276) = r2
		memw(r29+#260) = r3
	}
	{
		r2 = add(r29,#256)
		memw(r29+#264) = r4
	}
	{
		r3 = memw(r25+#12)
	}
	{
		memw(r29+#288) = r3
		r3 = memw(r25+#8)

	} :mem_noshuf
	{
		memw(r29+#292) = r3
		r3 = memw(r25+#16)

	} :mem_noshuf
	{
		r3 = memw(r24+#36)
		memw(r29+#296) = r3
	}
	{
		memw(r29+#300) = r6
		memw(r29+#308) = r6
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#312) = r5
		memw(r29+#304) = r3
	}
	.falign
// %bb.17:                              // %if.end.i
	{
		jump .LBB25_89
	}
	.falign
.LBB25_18:                              // %if.end
	{
		r0 = mpyi(r23,r17)
		call __hexagon_udivsi3
		r1 = r18
	}
	.falign
// %bb.19:                              // %if.end
	{
		r17 = add(r0,r22)
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r23,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.20:                              // %if.end
	{
		r23 = add(r16,#8208)
		r22 = add(r0,r22)
		if (!cmp.gtu(r22.new,r17)) jump:t ##.LBB25_89
	}
// %bb.21:                              // %for.body.lr.ph.i
	{
		r24 = #3
		r2 = memw(r19+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r25 = and(r2,#-128)
	}
	.falign
.LBB25_22:                              // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB25_26 Depth 2
                                        //     Child Loop BB25_30 Depth 2
                                        //     Child Loop BB25_58 Depth 2
                                        //     Child Loop BB25_62 Depth 2
	{
		r18 = memw(r23+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.23:                              // %for.body.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r3:2 = combine(r16,r17)
		r5 = #1
		r6 = memw(r20+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB25_32
		v0 = vmem(r4+#0)
	}
// %bb.24:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = mpyi(r5,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB25_28
	}
// %bb.25:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_26,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r4,r13,#2)
		v3.w = vadd(v0.w,v23.w)
		v23.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB25_27
	}
	.falign
.LBB25_26:                              //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r25)
		v25.w = vadd(v3.w,v24.w)
		v24.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v26 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r5,#3)
		v27.w = vadd(v25.w,v26.w)
		v28 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r5 = add(r5,#4)
		v29.w = vadd(v27.w,v28.w)
		v30 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r4,r9,#2)
		v3.w = vadd(v29.w,v30.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_27:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = addasl(r4,r12,#2)
		v0.w = vadd(v3.w,v31.w)
		v31.cur = vmem(r13+#0)
	}
	{
		v2.w = vadd(v0.w,v1.w)
		v1.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v2.w,v3.w)
		v3.cur = vmem(r12+#0)
	}
	.falign
.LBB25_28:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = mpyi(r5,r25)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB25_32
	}
// %bb.29:                              // %for.body13.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB25_30,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB25_31
	}
	.balign 32
.LBB25_30:                              // %for.body13.i
                                        //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r5,r25)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v4.w)
		v4.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_31:                              //   in Loop: Header=BB25_22 Depth=1
	{
		v0.w = vadd(v0.w,v5.w)
		v5.cur = vmem(r8+#0)
	}
	.falign
.LBB25_32:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r5 = memw(r3+#4)
		vmem(r29+#2) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r19+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB25_35
	}
// %bb.33:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB25_35
	}
// %bb.34:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_35:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_40
	}
// %bb.36:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_38
	}
// %bb.37:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_38:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		if (p1) jump:nt .LBB25_41
	}
// %bb.39:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_41
	}
	.falign
.LBB25_40:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_41:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB25_46
	}
// %bb.42:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB25_44
	}
// %bb.43:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_44:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB25_47
	}
// %bb.45:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_47
	}
	.falign
.LBB25_46:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r8 = r9
	}
	.falign
.LBB25_47:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_52
	}
// %bb.48:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_50
	}
// %bb.49:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB25_55
	}
	.falign
.LBB25_50:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB25_53
	}
// %bb.51:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_53
	}
	.falign
.LBB25_52:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_53:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB25_55
		v4.w = vasl(v0.w,r24)
	}
// %bb.54:                              // %if.end.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		v5.w = vsub(v4.w,v0.w)
		vmem(r29+#2) = v5.new
	}
	.falign
.LBB25_55:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB25_64
		v1 = vmem(r7+#0)
	}
// %bb.56:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = mpyi(r6,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB25_60
	}
// %bb.57:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_58,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r7,r13,#2)
		v2.w = vadd(v1.w,v6.w)
		v6.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB25_59
	}
	.falign
.LBB25_58:                              //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r25)
		v8.w = vadd(v2.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v9 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r6,#3)
		v10.w = vadd(v8.w,v9.w)
		v11 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r6 = add(r6,#4)
		v12.w = vadd(v10.w,v11.w)
		v13 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r7,r9,#2)
		v2.w = vadd(v12.w,v13.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_59:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = addasl(r7,r12,#2)
		v15.w = vadd(v2.w,v14.w)
		v14.cur = vmem(r13+#0)
	}
	{
		v17.w = vadd(v15.w,v16.w)
		v16.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v17.w,v18.w)
		v18.cur = vmem(r12+#0)
	}
	.falign
.LBB25_60:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = mpyi(r6,r25)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB25_64
	}
// %bb.61:                              // %for.body13.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB25_62,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB25_63
	}
	.balign 32
.LBB25_62:                              // %for.body13.1.i
                                        //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r6,r25)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v19.w)
		v19.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_63:                              //   in Loop: Header=BB25_22 Depth=1
	{
		v1.w = vadd(v1.w,v20.w)
		v20.cur = vmem(r8+#0)
	}
	.falign
.LBB25_64:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		vmem(r29+#3) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_67
	}
// %bb.65:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_67
	}
// %bb.66:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB25_87
	}
	.falign
.LBB25_67:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_72
	}
// %bb.68:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_70
	}
// %bb.69:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_87
	}
	.falign
.LBB25_70:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		if (p0) jump:nt .LBB25_73
	}
// %bb.71:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_73
	}
	.falign
.LBB25_72:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_73:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB25_78
	}
// %bb.74:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_76
	}
// %bb.75:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB25_87
	}
	.falign
.LBB25_76:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB25_79
	}
// %bb.77:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_79
	}
	.falign
.LBB25_78:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r6 = r7
	}
	.falign
.LBB25_79:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_84
	}
// %bb.80:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_82
	}
// %bb.81:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_87
	}
	.falign
.LBB25_82:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_85
	}
// %bb.83:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_85
	}
	.falign
.LBB25_84:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_85:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB25_87
		v21.w = vasl(v1.w,r24)
	}
// %bb.86:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		v22.w = vsub(v21.w,v1.w)
		vmem(r29+#3) = v22.new
	}
	.falign
.LBB25_87:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#256)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.88:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r22)) jump:t ##.LBB25_22
	}
	.falign
.LBB25_89:                              // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end25:
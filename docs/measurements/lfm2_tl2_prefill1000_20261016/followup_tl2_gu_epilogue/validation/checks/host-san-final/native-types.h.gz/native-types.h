#include <hexagon_types.h>
#include <hvx_hexagon_protos.h>
typedef HVX_Vector nntr_unaligned_hvx __attribute__((aligned(1)));
#define HVX_UVector nntr_unaligned_hvx
#define __hexagon__ 1

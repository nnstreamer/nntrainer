// Diagnostic-only host proof. Production helpers and counter are extracted.
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "hexkl_mm_u8i4_moe.h"
#include "hexkl_wh_affine.h"
#include "htp_tl2_opts.h"
#include "hvx_dequant_i32.h"
#include "hvx_expand_i2i4.h"
#include "hvx_gemv_u8tl2.h"
#include "hvx_quant_u8.h"
#define ROUND_UP_U32(v,a) ((((v)+((a)-1))/(a))*(a))
#define candidate_serial_swiglu hvx_dequant_swiglu_acc_tiles_to_f32
#define counted_direct_swiglu hvx_dq_swiglu_worker
#include "counter.inc"
#include "candidate-unit.inc"
#undef candidate_serial_swiglu
#undef counted_direct_swiglu

void hvx_worker_pool_run(hvx_worker_pool *pool,hvx_worker_pool_func fn,void *ctx,uint32_t units) {
  assert(!pool);(void)units;fn(1,0,ctx);
}
enum { I=1536, E=8, REPEATS=32 };
static int32_t acc[E][2*I] __attribute__((aligned(128)));
static int32_t cs[E][2*I] __attribute__((aligned(128)));
static float ws[E][2*I] __attribute__((aligned(128)));
static float bias[E][2*I] __attribute__((aligned(128)));
static float output[E][I] __attribute__((aligned(128)));
static float expected[E][I] __attribute__((aligned(128)));
static float scale[E];static int32_t zp[E];
static hexkl_weight_u8i4 gu[E],dn[E];
static candidate_moe_m1_ctx context;
static uint8_t dummy;
struct thread_arg {unsigned lanes,id,fused;};
static void *run_lane(void *value) {
  struct thread_arg *a=value;
  for(unsigned n=0;n<REPEATS;++n)
    assert(candidate_moe_tl2_gate_direct(&context,a->fused?a->id:0,a->fused?1:a->lanes,a->fused?0:a->id)==1);
  return NULL;
}
int main(void) {
  context.native_tl2=1;context.k_tiles=64;context.inter=I;context.inter_ntiles=48;
  context.N_out=2048;context.tl2_splits=1;context.act=HVX_GLU_SILU;
  for(unsigned e=0;e<E;++e) {
    scale[e]=0.013713f;zp[e]=127;
    for(unsigned j=0;j<2*I;++j) {
      acc[e][j]=(int32_t)((j*7919u+e*17u)%1044481u)-522240;
      cs[e][j]=(int32_t)(j%4097u)-2048;ws[e][j]=(float)(1+j%17)/32768;
      bias[e][j]=(float)((int)(j%31)-15)/128;
    }
    gu[e].pal[0]=gu[e].pal[1]=-1;gu[e].pal[3]=1;
    dn[e].pal[0]=dn[e].pal[1]=-1;dn[e].pal[3]=1;
    gu[e].tl2_bytes=dn[e].tl2_bytes=&dummy;gu[e].colsum_w=cs[e];gu[e].w_scale=ws[e];gu[e].bias=bias[e];
    context.ex[e].g=&gu[e];context.ex[e].d=&dn[e];context.ex[e].m=1;
    context.ex[e].act_scale=&scale[e];context.ex[e].act_zp=&zp[e];context.ex[e].acc_gu=acc[e];context.ex[e].gate_f32=output[e];
    hvx_dq_swiglu_job job={(const uint8_t *)acc[e],128,48,0,32,1,&scale[e],&zp[e],cs[e],ws[e],bias[e],I,expected[e],I,HVX_GLU_SILU};
    hvx_dq_swiglu_worker(1,0,&job);
  }
  const unsigned widths[]={1,2,3,6,8};unsigned groups=0,total_calls=0,total_tiles=0;
  for(unsigned fused=0;fused<2;++fused) for(unsigned w=0;w<5;++w) {
    const unsigned lanes=widths[w];pthread_t thread[E];struct thread_arg a[E];uint32_t before[4],after[4];
    memset(output,0,sizeof output);context.tl2_fused=fused;
    for(unsigned k=0;k<4;++k) __atomic_store_n(&tl2_gu_trace[k],UINT32_MAX-15u,__ATOMIC_RELAXED);
    hexkl_moe_tl2_gu_trace_counts(before);
    for(unsigned t=0;t<lanes;++t) {a[t]=(struct thread_arg){lanes,t,fused};assert(pthread_create(&thread[t],NULL,run_lane,&a[t])==0);}
    for(unsigned t=0;t<lanes;++t) assert(pthread_join(thread[t],NULL)==0);
    hexkl_moe_tl2_gu_trace_counts(after);
    const unsigned calls=lanes*REPEATS, tiles=48u*REPEATS*(fused?lanes:1u), part=fused?0u:2u;
    for(unsigned k=0;k<4;++k) assert(after[k]-before[k]==(k==part?calls:k==part+1?tiles:0u));
    for(unsigned e=0;e<(fused?lanes:1u);++e) assert(memcmp(output[e],expected[e],sizeof output[e])==0);
    context.tl2_splits=2;
    assert(candidate_moe_tl2_gate_direct(&context,0,1,0)==0);
    hexkl_moe_tl2_gu_trace_counts(before);assert(memcmp(before,after,sizeof before)==0);
    context.tl2_splits=1;
    total_calls+=calls;total_tiles+=tiles;++groups;
  }
  printf("PASS: %u actual-HVX concurrent groups; %u direct calls/%u tiles exact; widths1,2,3,6,8 fused/unfused, wraparound, rejection-no-count, float bytes exact\n",groups,total_calls,total_tiles);
}

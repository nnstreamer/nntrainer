// SPDX-License-Identifier: Apache-2.0
// Actual RPC bodies with explicit DMA/reserve/append/kernel stand-ins.
#include "hexkl_attn_q.h"
#include <AEEStdErr.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint32_t uint32;
typedef uint16_t uint16;
typedef uintptr_t remote_handle64;
typedef struct {
  uint8_t *base;
  size_t cap;
} fake_scratch;
typedef struct {
  hexkl_kv_q_table kv_q;
  fake_scratch moe_scratch;
  uint8_t *vtcm_base;
  uint32_t config_off;
  hvx_worker_pool *quant_pool;
} nntr_hvx_session;
#define FARF(...) ((void)0)
static unsigned mode, copies, resets, kernels, appends, cases;
static size_t reserved, qbytes, kvbytes;
static const float *original_q;
static const uint16_t *original_k, *original_v;
static float *original_out;
static int expected_cached;
static nntr_hvx_session *current;
static uint64_t HAP_perf_get_time_us(void) {
  static uint64_t n;
  return ++n;
}
static uint64_t HAP_perf_get_pcycles(void) {
  return HAP_perf_get_time_us() * 1000;
}
static int hexkl_moe_scratch_reserve(fake_scratch *s, size_t bytes) {
  reserved = bytes;
  assert(bytes <= s->cap);
  return mode == 1 ? AEE_ENOMEMORY : AEE_SUCCESS;
}
static void hexkl_dma_ring_reset(void) { ++resets; }
static void hexkl_moe_dma_copy(void *dst, const void *src, size_t bytes, int a,
                               int b) {
  assert(a == 0 && b == 0);
  if (copies == 0) {
    assert(src == original_k && bytes == kvbytes);
  }
  if (copies == 1) {
    assert(src == original_v && bytes == kvbytes);
  }
  if (copies == 2) {
    assert(src == original_q && bytes == qbytes);
  }
  if (copies == 3) {
    assert(dst == original_out && bytes == qbytes && kernels == 1);
  }
  assert(copies < 4);
  memcpy(dst, src, bytes);
  ++copies;
}
const hexkl_kv_q *hexkl_kv_q_get(const hexkl_kv_q_table *t, uint32_t h) {
  return h == 1 ? &t->slots[0] : NULL;
}
int hexkl_kv_q_append_pool(hexkl_kv_q_table *t, uint32_t handle, uint32_t row,
                           uint32_t rows, const uint16_t *k, const uint16_t *v,
                           uint8_t *vtcm, void *pool,
                           hexkl_kv_q_append_stats *st) {
  (void)t;
  (void)row;
  (void)pool;
  assert(handle == 1 && vtcm == current->vtcm_base);
  assert((size_t)rows * 512 * 2 == kvbytes);
  ++appends;
  assert(memcmp(k, original_k, kvbytes) == 0 &&
         memcmp(v, original_v, kvbytes) == 0);
  if (expected_cached) {
    assert(copies == 3 && k != (const void *)original_k &&
           v != (const void *)original_v);
  } else {
    assert(copies == 0 && k == original_k && v == original_v);
  }
  memset(st, 0, sizeof(*st));
  return mode == 4 ? AEE_EFAILED : AEE_SUCCESS;
}
static int check_kernel(const hexkl_attn_f16_shape *s,
                        const hexkl_attn_q_io *io) {
  ++kernels;
  assert(io->q_cached == (uint32_t)expected_cached);
  assert(io->q_stride == s->n_head_q * s->head_dim &&
         io->out_stride == io->q_stride);
  assert(memcmp(io->q, original_q, qbytes) == 0);
  if (expected_cached) {
    assert(copies == 3 && resets == 1);
    assert(io->q == (const void *)(current->moe_scratch.base + 2 * kvbytes));
    assert(io->out ==
           (void *)(current->moe_scratch.base + 2 * kvbytes + qbytes));
    assert(reserved == 2 * (qbytes + kvbytes));
  } else {
    assert(copies == 0 && io->q == original_q && io->out == original_out);
  }
  if (mode == 5)
    return AEE_EFAILED;
  memcpy(io->out, io->q, qbytes);
  return AEE_SUCCESS;
}
int hexkl_attn_q_prefill(uint8_t *vb, uint32_t off,
                         const hexkl_attn_f16_shape *s,
                         const hexkl_attn_f16_tiling *t,
                         const hexkl_attn_q_io *io, hvx_worker_pool *p,
                         hexkl_attn_q_stats *st) {
  (void)t;
  (void)p;
  assert(vb == current->vtcm_base && off == current->config_off);
  if (st)
    memset(st, 0, sizeof(*st));
  return check_kernel(s, io);
}
static int hvx_attn_decode_q(const hexkl_attn_f16_shape *s,
                             const hexkl_attn_q_io *io, hvx_worker_pool *pool,
                             uint64_t *us) {
  (void)pool;
  if (us)
    *us = 1;
  return check_kernel(s, io);
}
#include "attn_qprep_rpc_under_test.h"

static void run_case(unsigned which, uint32_t nq, unsigned m) {
  mode = m;
  copies = resets = kernels = appends = 0;
  reserved = 0;
  hexkl_kv_q *kv = &current->kv_q.slots[0];
  kv->fixed = mode == 2;
  kv->kind = mode == 8 ? HEXKL_KV_Q4 : HEXKL_KV_Q8;
  kv->max_rows = 4096;
  kv->n_head_kv = 8;
  kv->head_dim = 64;
  qbytes = (size_t)nq * 2048 * 4;
  kvbytes = (size_t)nq * 512 * 2;
  float *q = malloc(qbytes), *out = malloc(qbytes);
  uint16_t *k = malloc(kvbytes), *v = malloc(kvbytes);
  assert(q && out && k && v);
  for (size_t i = 0; i < qbytes / 4; ++i)
    q[i] = (float)((int)(i % 511) - 255) * 0.125f;
  memset(k, 0x13, kvbytes);
  memset(v, 0x97, kvbytes);
  memset(out, 0xa5, qbytes);
  original_q = q;
  original_k = k;
  original_v = v;
  original_out = out;
  expected_cached = which == 0 && nq >= 128 && mode != 1 && mode != 2 &&
                    mode != 3 && mode != 6 && mode != 7 && mode != 8;
  uint32 stats[20];
  memset(stats, 0xa5, sizeof(stats));
  int rc;
  if (which == 0) {
    rc = nntr_hvx_attn_q_step((remote_handle64)current, 1, mode == 7 ? 1 : 0, k,
                              (int)(kvbytes / 2), v, (int)(kvbytes / 2), nq, 0,
                              nq, 32, mode == 3 ? 64 : 0, 0, q,
                              (int)(qbytes / 4) - (mode == 6), NULL, 0, out,
                              (int)(qbytes / 4), stats, 20);
  } else if (which == 1) {
    rc = nntr_hvx_attn_q_prefill((remote_handle64)current, 1, nq, 0, nq, 32, 0,
                                 0, 0, 0, q, (int)(qbytes / 4), NULL, 0, out,
                                 (int)(qbytes / 4), stats, 20);
  } else {
    rc = nntr_hvx_attn_q_decode((remote_handle64)current, 1, nq, 0, nq, 32, 0,
                                0, q, (int)(qbytes / 4), NULL, 0, out,
                                (int)(qbytes / 4), stats, 20);
  }
  if (mode == 4 || mode == 5 || mode == 6) {
    assert(rc != AEE_SUCCESS);
    assert(kernels == (mode == 5));
    for (size_t i = 0; i < qbytes; ++i)
      assert(((uint8_t *)out)[i] == 0xa5);
    assert(copies == (expected_cached ? 3u : 0u));
  } else {
    assert(rc == AEE_SUCCESS && kernels == 1 && memcmp(q, out, qbytes) == 0);
    assert(copies == (expected_cached ? 4u : 0u));
    assert(resets == (expected_cached ? 2u : 0u));
  }
  free(q);
  free(out);
  free(k);
  free(v);
  ++cases;
}
int main(void) {
  nntr_hvx_session s;
  memset(&s, 0, sizeof(s));
  current = &s;
  s.moe_scratch.cap = 36u << 20;
  s.moe_scratch.base = malloc(s.moe_scratch.cap);
  s.vtcm_base = malloc(8u << 20);
  s.config_off = 8u << 20;
  assert(s.moe_scratch.base && s.vtcm_base);
  for (unsigned m = 0; m < 9; ++m)
    run_case(0, 2048, m);
  run_case(0, 1024, 0);
  run_case(0, 128, 0);
  run_case(0, 1, 0);
  run_case(1, 2048, 0);
  run_case(1, 1024, 0);
  run_case(2, 1, 0);
  free(s.vtcm_base);
  free(s.moe_scratch.base);
  printf("QPREP_RPC %u actual-body capability/lifecycle cases PASS (DMA/HMX "
         "stand-ins)\n",
         cases);
}

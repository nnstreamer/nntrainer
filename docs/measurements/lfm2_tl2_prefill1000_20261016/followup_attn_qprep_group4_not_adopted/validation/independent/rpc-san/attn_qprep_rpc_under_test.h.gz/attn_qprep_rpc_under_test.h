enum {
  QSTAT_QPREP = 0,
  QSTAT_DMA,
  QSTAT_QK,
  QSTAT_DEQUANT,
  QSTAT_SOFTMAX,
  QSTAT_PQUANT,
  QSTAT_PV,
  QSTAT_OUPD,
  QSTAT_STORE,
  QSTAT_N_BLOCKS,
  QSTAT_US_TOTAL,
  QSTAT_KCYCLES, /**< processor kilocycles of the call */
  QSTAT_COUNT
};
int nntr_hvx_attn_q_prefill(remote_handle64 handle, uint32 kv_handle,
                            uint32 n_q, uint32 cache_from, uint32 cache_to,
                            uint32 n_head_q, uint32 window, uint32 br,
                            uint32 bc, float softcap, const float *q_f32,
                            int q_f32Len, const float *sinks, int sinksLen,
                            float *out_f32, int out_f32Len, uint32 *stats_us,
                            int stats_usLen) {
  nntr_hvx_session *s = (nntr_hvx_session *)handle;
  if (!s) {
    return AEE_EBADPARM;
  }
  const hexkl_kv_q *kv = hexkl_kv_q_get(&s->kv_q, kv_handle);
  if (!kv || cache_to > kv->max_rows) {
    FARF(ERROR, "attn_q_prefill: bad handle or cache_to");
    return AEE_EBADPARM;
  }
  hexkl_attn_f16_shape shape = {n_q,           cache_from,   cache_to, n_head_q,
                                kv->n_head_kv, kv->head_dim, window,   softcap};
  hexkl_attn_f16_tiling tiling = {br, bc, 0, 0};
  if (br == 0 || bc == 0) {
    hexkl_attn_f16_choose_tiling(&shape, &tiling);
  }
  if (hexkl_attn_q_tiling_init(&shape, &tiling) != HEXKL_ATTN_OK) {
    FARF(ERROR, "attn_q_prefill: bad shape/tiling");
    return AEE_EBADPARM;
  }
  const uint64_t q_elems = (uint64_t)n_q * n_head_q * kv->head_dim;
  if ((uint64_t)q_f32Len != q_elems || (uint64_t)out_f32Len != q_elems ||
      stats_usLen < QSTAT_COUNT ||
      (sinksLen != 0 && (uint32)sinksLen != n_head_q)) {
    FARF(ERROR, "attn_q_prefill: bad lengths");
    return AEE_EBADPARM;
  }
  hexkl_attn_q_io io;
  memset(&io, 0, sizeof(io));
  io.q = q_f32;
  io.q_stride = n_head_q * kv->head_dim;
  io.sinks = sinksLen ? sinks : NULL;
  io.out = out_f32;
  io.out_stride = n_head_q * kv->head_dim;
  io.kv = kv;
  hexkl_attn_q_stats st;
  int res = hexkl_attn_q_prefill(s->vtcm_base, s->config_off, &shape, &tiling,
                                 &io, s->quant_pool, &st);
  if (res != AEE_SUCCESS) {
    FARF(ERROR, "attn_q_prefill: kernel failed: 0x%08x", res);
    return res;
  }
  stats_us[QSTAT_QPREP] = (uint32)st.us_qprep;
  stats_us[QSTAT_DMA] = (uint32)st.us_dma;
  stats_us[QSTAT_QK] = (uint32)st.us_qk;
  stats_us[QSTAT_DEQUANT] = (uint32)st.us_dequant;
  stats_us[QSTAT_SOFTMAX] = (uint32)st.us_softmax;
  stats_us[QSTAT_PQUANT] = (uint32)st.us_pquant;
  stats_us[QSTAT_PV] = (uint32)st.us_pv;
  stats_us[QSTAT_OUPD] = (uint32)st.us_oupd;
  stats_us[QSTAT_STORE] = (uint32)st.us_store;
  stats_us[QSTAT_N_BLOCKS] = st.n_blocks;
  stats_us[QSTAT_US_TOTAL] = (uint32)st.us_total;
  stats_us[QSTAT_KCYCLES] = (uint32)(st.pcycles / 1000u);
  return AEE_SUCCESS;
}
int nntr_hvx_attn_q_decode(remote_handle64 handle, uint32 kv_handle, uint32 n_q,
                           uint32 cache_from, uint32 cache_to, uint32 n_head_q,
                           uint32 window, float softcap, const float *q_f32,
                           int q_f32Len, const float *sinks, int sinksLen,
                           float *out_f32, int out_f32Len, uint32 *stats_us,
                           int stats_usLen) {
  nntr_hvx_session *s = (nntr_hvx_session *)handle;
  if (!s) {
    return AEE_EBADPARM;
  }
  const hexkl_kv_q *kv = hexkl_kv_q_get(&s->kv_q, kv_handle);
  if (!kv || cache_to > kv->max_rows) {
    FARF(ERROR, "attn_q_decode: bad handle or cache_to");
    return AEE_EBADPARM;
  }
  hexkl_attn_f16_shape shape = {n_q,           cache_from,   cache_to, n_head_q,
                                kv->n_head_kv, kv->head_dim, window,   softcap};
  const uint64_t q_elems = (uint64_t)n_q * n_head_q * kv->head_dim;
  if ((uint64_t)q_f32Len != q_elems || (uint64_t)out_f32Len != q_elems ||
      stats_usLen < 2 || (sinksLen != 0 && (uint32)sinksLen != n_head_q)) {
    FARF(ERROR, "attn_q_decode: bad lengths");
    return AEE_EBADPARM;
  }
  hexkl_attn_q_io io;
  memset(&io, 0, sizeof(io));
  io.q = q_f32;
  io.q_stride = n_head_q * kv->head_dim;
  io.sinks = sinksLen ? sinks : NULL;
  io.out = out_f32;
  io.out_stride = n_head_q * kv->head_dim;
  io.kv = kv;
  uint64_t us = 0;
  const uint64_t c0 = HAP_perf_get_pcycles();
  int res = hvx_attn_decode_q(&shape, &io, s->quant_pool, &us);
  if (res != AEE_SUCCESS) {
    FARF(ERROR, "attn_q_decode: kernel failed: 0x%08x", res);
    return res;
  }
  stats_us[0] = (uint32)us;
  stats_us[1] = (uint32)((HAP_perf_get_pcycles() - c0) / 1000u);
  return AEE_SUCCESS;
}
int nntr_hvx_attn_q_step(remote_handle64 handle, uint32 kv_handle, uint32 row0,
                         const uint16 *k_rows, int k_rowsLen,
                         const uint16 *v_rows, int v_rowsLen, uint32 n_q,
                         uint32 cache_from, uint32 cache_to, uint32 n_head_q,
                         uint32 window, float softcap, const float *q_f32,
                         int q_f32Len, const float *sinks, int sinksLen,
                         float *out_f32, int out_f32Len, uint32 *stats_us,
                         int stats_usLen) {
  nntr_hvx_session *s = (nntr_hvx_session *)handle;
  if (!s) {
    return AEE_EBADPARM;
  }
  const hexkl_kv_q *kv = hexkl_kv_q_get(&s->kv_q, kv_handle);
  if (!kv || cache_to > kv->max_rows || stats_usLen < 8) {
    FARF(ERROR, "attn_q_step: bad handle, cache_to or stats");
    return AEE_EBADPARM;
  }
  hexkl_kv_q_append_stats ast;
  memset(&ast, 0, sizeof(ast));
  const uint64_t t0 = HAP_perf_get_time_us();
  const uint32_t stride = kv->n_head_kv * kv->head_dim;
  if (k_rowsLen != v_rowsLen || k_rowsLen < 0 ||
      ((uint32_t)k_rowsLen % stride) != 0) {
    FARF(ERROR, "attn_q_step: bad row lengths");
    return AEE_EBADPARM;
  }
  /* LFM2 full prefill: avoid repeated scalar/HVX loads from uncached RPC
   * memory. The session scratch is idle between synchronous layer calls.
   * Allocation failure retains the original path; Gemma's fixed cache and
   * decode never use this staging or the dynamic-head worker path. */
  float *cached_out = NULL;
  const size_t q_bytes = (size_t)n_q * n_head_q * kv->head_dim * sizeof(float);
  const size_t kv_bytes = (size_t)k_rowsLen * sizeof(uint16_t);
  if (n_q >= 128u && n_q <= 4096u && n_q % 128u == 0u && row0 == 0u &&
      cache_from == 0u && cache_to == n_q && n_head_q == 32u &&
      kv->n_head_kv == 8u && kv->head_dim == 64u && kv->kind == HEXKL_KV_Q8 &&
      !kv->fixed && window == 0u && k_rowsLen == (int)(n_q * stride) &&
      q_f32Len == (int)(q_bytes / 4u) && out_f32Len == q_f32Len && q_f32 &&
      out_f32 && k_rows && v_rows &&
      hexkl_moe_scratch_reserve(&s->moe_scratch, 2u * (q_bytes + kv_bytes)) ==
        AEE_SUCCESS) {
    uint8_t *base = s->moe_scratch.base;
    hexkl_dma_ring_reset();
    hexkl_moe_dma_copy(base, k_rows, kv_bytes, 0, 0);
    k_rows = (const uint16_t *)base;
    base += kv_bytes;
    hexkl_moe_dma_copy(base, v_rows, kv_bytes, 0, 0);
    v_rows = (const uint16_t *)base;
    base += kv_bytes;
    hexkl_moe_dma_copy(base, q_f32, q_bytes, 0, 0);
    q_f32 = (const float *)base;
    cached_out = (float *)(base + q_bytes);
  }
  if (k_rowsLen > 0) {
    const int rc = hexkl_kv_q_append_pool(
      &s->kv_q, kv_handle, row0, (uint32_t)k_rowsLen / stride, k_rows, v_rows,
      s->vtcm_base, s->quant_pool, &ast);
    if (rc != AEE_SUCCESS) {
      FARF(ERROR, "attn_q_step: append failed: 0x%08x", rc);
      return rc;
    }
  }
  const uint64_t t1 = HAP_perf_get_time_us();

  hexkl_attn_f16_shape shape = {n_q,           cache_from,   cache_to, n_head_q,
                                kv->n_head_kv, kv->head_dim, window,   softcap};
  const uint64_t q_elems = (uint64_t)n_q * n_head_q * kv->head_dim;
  if ((uint64_t)q_f32Len != q_elems || (uint64_t)out_f32Len != q_elems ||
      (sinksLen != 0 && (uint32)sinksLen != n_head_q)) {
    FARF(ERROR, "attn_q_step: bad lengths");
    return AEE_EBADPARM;
  }
  hexkl_attn_q_io io;
  memset(&io, 0, sizeof(io));
  io.q = q_f32;
  io.q_stride = n_head_q * kv->head_dim;
  io.sinks = sinksLen ? sinks : NULL;
  io.out = cached_out ? cached_out : out_f32;
  io.out_stride = n_head_q * kv->head_dim;
  io.kv = kv;
  io.q_cached = cached_out != NULL;

  hexkl_attn_q_stats prefill_stats;
  memset(&prefill_stats, 0, sizeof(prefill_stats));
  int res;
  const int decode = n_q < 5u && kv->head_dim <= 128u;
  if (decode) {
    res = hvx_attn_decode_q(&shape, &io, s->quant_pool, NULL);
  } else {
    hexkl_attn_f16_tiling tiling = {0, 0, 0, 0};
    hexkl_attn_f16_choose_tiling(&shape, &tiling);
    if (hexkl_attn_q_tiling_init(&shape, &tiling) != HEXKL_ATTN_OK) {
      return AEE_EBADPARM;
    }
    res = hexkl_attn_q_prefill(
      s->vtcm_base, s->config_off, &shape, &tiling, &io, s->quant_pool,
      stats_usLen >= 8 + QSTAT_COUNT ? &prefill_stats : NULL);
  }
  if (res != AEE_SUCCESS) {
    FARF(ERROR, "attn_q_step: kernel failed: 0x%08x", res);
    return res;
  }
  if (cached_out) {
    hexkl_dma_ring_reset();
    hexkl_moe_dma_copy(out_f32, cached_out, q_bytes, 0, 0);
  }
  const uint64_t t2 = HAP_perf_get_time_us();
  stats_us[0] = (uint32)(t1 - t0);
  stats_us[1] = (uint32)(t2 - t1);
  stats_us[2] = decode ? 0u : 1u;
  stats_us[3] = (uint32)(t2 - t0);
  stats_us[4] = ast.quant_us;
  stats_us[5] = ast.stage_us;
  stats_us[6] = ast.bake_us;
  stats_us[7] = (uint32)((uint32_t)k_rowsLen / stride);
  // Optional detail follows the original eight slots; old clients keep the
  // same layout and the same kernel path. Decode has no prefill stages.
  if (stats_usLen >= 8 + QSTAT_COUNT) {
    uint32 *detail = stats_us + 8;
    detail[QSTAT_QPREP] = (uint32)prefill_stats.us_qprep;
    detail[QSTAT_DMA] = (uint32)prefill_stats.us_dma;
    detail[QSTAT_QK] = (uint32)prefill_stats.us_qk;
    detail[QSTAT_DEQUANT] = (uint32)prefill_stats.us_dequant;
    detail[QSTAT_SOFTMAX] = (uint32)prefill_stats.us_softmax;
    detail[QSTAT_PQUANT] = (uint32)prefill_stats.us_pquant;
    detail[QSTAT_PV] = (uint32)prefill_stats.us_pv;
    detail[QSTAT_OUPD] = (uint32)prefill_stats.us_oupd;
    detail[QSTAT_STORE] = (uint32)prefill_stats.us_store;
    detail[QSTAT_N_BLOCKS] = prefill_stats.n_blocks;
    detail[QSTAT_US_TOTAL] = (uint32)prefill_stats.us_total;
    detail[QSTAT_KCYCLES] = (uint32)(prefill_stats.pcycles / 1000u);
  }
  return AEE_SUCCESS;
}

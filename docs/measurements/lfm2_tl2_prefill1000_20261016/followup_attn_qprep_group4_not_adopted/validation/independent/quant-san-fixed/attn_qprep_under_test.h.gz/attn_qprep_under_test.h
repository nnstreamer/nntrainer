#include <hexagon_types.h>
#include <hvx_hexagon_protos.h>
#include <AEEStdErr.h>
#include "hexkl_attn_q.h"
#define TB HEXKL_ATTN_TILE_BYTES
typedef struct unused_acc_layout hexkl_acc_layout;
static inline HVX_Vector hvx_tile_load_u(const void *p) {
  HVX_Vector v;
  memcpy(&v, p, sizeof(v));
  return v;
}
typedef struct {
  uint8_t *vb;
  uint32_t cfg;
  const hexkl_attn_f16_shape *s;
  const hexkl_attn_f16_tiling *t;
  const hexkl_attn_q_io *io;
  const hexkl_kv_q *kv;
  hvx_worker_pool *pool;
  hexkl_attn_q_layout L;
  const hexkl_acc_layout *acc_layout;
  float scale;         /**< log2e / sqrt(hd), folded into the S dequant */
  float *q_scale;      /**< [chunk*g_br] uint8 Q scale times c->scale */
  int32_t *q_zp;       /**< [chunk*g_br] */
  float *l_f32;        /**< [g_br] running sum */
  float *a_f32;        /**< [g_br] this block's rescale, f32 */
  uint16_t *m_hf;      /**< [g_br] running max, fp16 bits */
  uint16_t *a_hf;      /**< [g_br] this block's rescale, fp16 bits */
  HVX_Vector *p_scale; /**< [g_br] uint8 P' scale, each a splat vector so
                            the O update loads it as is. One per row, not
                            per V group: the registry's V scale covers the
                            whole row, so P' is the same for every group */
  HVX_Vector col_idx;
  HVX_Vector cap_hf, inv_cap_hf;
  int softcap_on;
  uint32_t qi; /**< q block index within the current chunk */
  /** per-block parameters handed to the pool workers; frozen while a job
      is in flight */
  uint32_t w_n, w_qb, w_kb, w_buf, w_sbuf;
  int w_masked;
  hexkl_attn_q_stats *st;
} attn_ctx;
static inline uint8_t *q_tile(const attn_ctx *c, uint32_t qi, uint32_t i,
                              uint32_t d) {
  return c->vb + c->L.q_ah +
         ((qi * c->L.n_row_tiles + i) * c->L.n_dot_tiles + d) * TB;
}
static inline float *qx_row(const attn_ctx *c, uint32_t r) {
  return (float *)(c->vb + c->L.qx_f32) + (size_t)r * c->s->head_dim;
}
static int qprep_disjoint(const void *a, size_t an, const void *b, size_t bn) {
  const uintptr_t x = (uintptr_t)a, y = (uintptr_t)b;
  return x >= y ? x - y >= bn : y - x >= an;
}
static int qprep_cached_group4_available(const attn_ctx *c, uint32_t n,
                                         uint32_t qb0, uint32_t n_qb) {
  if (c->io->q_cached != 1u || c->kv->kind != HEXKL_KV_Q8 || c->kv->fixed ||
      c->s->n_q != 2048u || c->s->cache_from != 0u || c->s->cache_to != 2048u ||
      c->s->n_head_q != 32u || c->s->n_head_kv != 8u || c->s->head_dim != 64u ||
      c->s->window != 0u || c->s->softcap != 0.0f || c->io->sinks ||
      c->t->g != 4u || c->t->br != 128u || c->t->bc != 256u ||
      c->t->g_br != 512u || c->io->q_stride != 2048u || n >= 8u || qb0 >= 16u ||
      n_qb == 0u || n_qb > 16u - qb0 || n_qb > c->L.n_qb_chunk ||
      c->L.total > c->cfg || !c->io->q)
    return 0;
  const size_t bytes = (size_t)c->s->n_q * c->io->q_stride * sizeof(float);
  const size_t meta_bytes = (size_t)n_qb * c->t->g_br * sizeof(float);
  return qprep_disjoint(c->io->q, bytes, c->vb, c->L.total) &&
         qprep_disjoint(c->io->q, bytes, c->q_scale, meta_bytes) &&
         qprep_disjoint(c->io->q, bytes, c->q_zp, meta_bytes) &&
         (!c->io->out || (c->io->out_stride == 2048u &&
                          qprep_disjoint(c->io->q, bytes, c->io->out, bytes)));
}
#define hvx_quant_params_pack_u8_ah_group4 checked_group4
#define hvx_quant_rows_u8_params checked_params
#define hvx_quant_pack_u8_ah checked_pack
#define hvx_quant_params_pack_u8_ah checked_fused
static int phase_qprep(attn_ctx *c, uint32_t n, uint32_t qb0, uint32_t n_qb) {
  const uint32_t hd = c->s->head_dim;
  const uint32_t g_br = c->t->g_br;
  const uint32_t rows = n_qb * g_br;
  const uint32_t dt = c->L.n_dot_tiles;
  if (qprep_cached_group4_available(c, n, qb0, n_qb)) {
    for (uint32_t r = 0; r < rows; ++r) {
      c->q_scale[r] = 1.0f;
      c->q_zp[r] = 0;
    }
    const float *src = c->io->q + (size_t)qb0 * c->t->br * c->io->q_stride +
                       (size_t)n * c->t->g * hd;
    const int rc = hvx_quant_params_pack_u8_ah_group4(
      src, rows / 4u, hd, c->io->q_stride, c->q_scale, c->q_zp,
      q_tile(c, 0, 0, 0), c->pool);
    if (rc != AEE_SUCCESS)
      return rc;
    for (uint32_t r = 0; r < rows; ++r)
      c->q_scale[r] *= c->scale;
    // Qx remains allocated at the original extent: the 2048 pipeline later
    // overwrites it with complete next-QK readouts before conversion reads it.
    return AEE_SUCCESS;
  }
  for (uint32_t qi = 0; qi < n_qb; ++qi) {
    for (uint32_t r = 0; r < g_br; ++r) {
      uint32_t q, g;
      HVX_Vector *restrict dst = (HVX_Vector *)qx_row(c, qi * g_br + r);
      if (hexkl_attn_f16_tile_row_to_qg(c->s, c->t, qb0 + qi, r, &q, &g)) {
        const float *src = c->io->q + (size_t)q * c->io->q_stride +
                           (size_t)(n * c->t->g + g) * hd;
        for (uint32_t d = 0; d < dt; ++d) {
          dst[d] = hvx_tile_load_u(src + 32u * d);
        }
      } else {
        for (uint32_t d = 0; d < dt; ++d) {
          dst[d] = Q6_V_vzero();
        }
      }
    }
  }
  int rc;
  if (c->kv->kind == HEXKL_KV_Q8 && !c->kv->fixed && c->s->n_head_q == 32u &&
      c->s->n_head_kv == 8u && hd == 64u && c->s->n_q >= 128u &&
      c->s->n_q % 128u == 0u && c->s->cache_from == 0u &&
      c->s->cache_to == c->s->n_q && c->s->window == 0u &&
      c->s->softcap == 0.0f) {
    // LFM2's two column tiles underfill the separate pack's worker split.
    // Keep the same quantizer and four-row pack, but distribute row groups
    // in one pass without the pack's per-row splat-vector allocations.
    // The fused helper leaves zero rows' parameters alone, including rows
    // zero-padded by the gather above: preserve the separate pass's defaults.
    for (uint32_t r = 0; r < rows; ++r) {
      c->q_scale[r] = 1.0f;
      c->q_zp[r] = 0;
    }
    rc = hvx_quant_params_pack_u8_ah(qx_row(c, 0), NULL, NULL, 0u, rows, rows,
                                     hd, NULL, 0.0f, NULL, c->q_scale, c->q_zp,
                                     q_tile(c, 0, 0, 0), c->pool);
  } else {
    hvx_quant_rows_u8_params(qx_row(c, 0), rows, rows, hd, c->q_scale, c->q_zp,
                             c->pool);
    rc = hvx_quant_pack_u8_ah(qx_row(c, 0), rows, rows, hd, c->q_scale, c->q_zp,
                              q_tile(c, 0, 0, 0), c->pool);
  }
  if (rc != AEE_SUCCESS) {
    return rc;
  }
  // Fold the logit scale into the dequant multiplier.
  for (uint32_t r = 0; r < rows; ++r) {
    c->q_scale[r] *= c->scale;
  }
  return AEE_SUCCESS;
}
#undef hvx_quant_params_pack_u8_ah_group4
#undef hvx_quant_rows_u8_params
#undef hvx_quant_pack_u8_ah
#undef hvx_quant_params_pack_u8_ah

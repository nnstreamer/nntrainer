	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"nntr_hvx_attn_q.c"
	.globl	nntr_hvx_kv_register_q          // -- Begin function nntr_hvx_kv_register_q
	.falign
	.type	nntr_hvx_kv_register_q,@function
nntr_hvx_kv_register_q:                 // @nntr_hvx_kv_register_q
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB0_3
	}
// %bb.1:                               // %entry
	{
		r1 = and(r2,#255)
		r6 = memw(r29+#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB0_3
	}
// %bb.2:                               // %if.end
	{
		r3 = r4
		r2 = r3
		r4 = r5
	}
	{
		r0 = add(r0,##409628)
		r5 = r6
	}
	{
		jump hexkl_kv_q_register
	}
	.falign
.LBB0_3:                                // %cleanup
	{
		r0 = ##-2147482610
		jumpr r31
	}
.Lfunc_end0:
	.size	nntr_hvx_kv_register_q, .Lfunc_end0-nntr_hvx_kv_register_q
                                        // -- End function
	.globl	nntr_hvx_kv_set_fixed_scales_q  // -- Begin function nntr_hvx_kv_set_fixed_scales_q
	.falign
	.type	nntr_hvx_kv_set_fixed_scales_q,@function
nntr_hvx_kv_set_fixed_scales_q:         // @nntr_hvx_kv_set_fixed_scales_q
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r18 = add(r3,#0)
		if (p0) jump:nt .LBB1_10
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r19 = add(r0,##409628)
		r17:16 = combine(r4,r5)
	}
	{
		call hexkl_kv_q_get
		r1:0 = combine(r2,r19)
		r20 = r2
		r21 = memw(r29+#32)
	}
	.falign
// %bb.2:                               // %if.end
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB1_6
	}
// %bb.3:                               // %lor.lhs.false
	{
		r2 = memw(r0+#20)
		if (!cmp.eq(r2.new,r17)) jump:t .LBB1_6
	}
// %bb.4:                               // %lor.lhs.false3
	{
		r2 = memw(r0+#24)
	}
	{
		r2 = mpyi(r2,r17)
		if (!cmp.eq(r2.new,r21)) jump:t .LBB1_6
	}
// %bb.5:                               // %if.end12
	{
		r1:0 = combine(r20,r19)
		r3:2 = combine(r16,r18)
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_kv_q_set_fixed_scales
		r21:20 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB1_6:                                // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB1_9
	}
// %bb.7:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #107
	}
	{
		r3 = add(pc,##.L.str.1@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.8:                               // %if.else
	{
		jump .LBB1_10
	}
	.falign
.LBB1_9:                                // %if.then10
	{
		r3 = add(pc,##.L.str.1@PCREL)
		call _HAP_debug_v2
		r2 = #107
	}
	.falign
.LBB1_10:                               // %cleanup15
	{
		r0 = ##-2147482610
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end1:
	.size	nntr_hvx_kv_set_fixed_scales_q, .Lfunc_end1-nntr_hvx_kv_set_fixed_scales_q
                                        // -- End function
	.balign 32                              // -- Begin function _HAP_debug_v2
	.type	_HAP_debug_v2,@function
_HAP_debug_v2:                          // @_HAP_debug_v2
// %bb.0:                               // %entry
	{
		r4 = r3
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(r29,#280):raw
	}                                       // 8-byte Folded Spill
	{
		r3 = add(r29,#288)
		r1 = #256
		r17 = add(r29,#8)
		r2 = r4
	}
	{
		call vsnprintf
		r0 = r17
		memw(r29+#4) = r3
	}
	{
		r2 = add(pc,##.L.str@PCREL)
		r1:0 = combine(#3,r17)
		r3 = r16
	}
	{
		call HAP_debug
	}
	{
		r17:16 = memd(r29+#272)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end2:
	.size	_HAP_debug_v2, .Lfunc_end2-_HAP_debug_v2
                                        // -- End function
	.globl	nntr_hvx_kv_release_q           // -- Begin function nntr_hvx_kv_release_q
	.balign 32
	.type	nntr_hvx_kv_release_q,@function
nntr_hvx_kv_release_q:                  // @nntr_hvx_kv_release_q
// %bb.0:                               // %entry
	{
		r1 = r2
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB3_2
	}
// %bb.1:                               // %if.end
	{
		r0 = add(r0,##409628)
		jump hexkl_kv_q_release
	}
	.falign
.LBB3_2:                                // %cleanup
	{
		r0 = ##-2147482610
		jumpr r31
	}
.Lfunc_end3:
	.size	nntr_hvx_kv_release_q, .Lfunc_end3-nntr_hvx_kv_release_q
                                        // -- End function
	.globl	nntr_hvx_kv_append_q            // -- Begin function nntr_hvx_kv_append_q
	.falign
	.type	nntr_hvx_kv_append_q,@function
nntr_hvx_kv_append_q:                   // @nntr_hvx_kv_append_q
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#40)
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(r1,r0)
		memd(r29+#16) = r21:20
		memd(r29+#24) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (!p0.new) r21 = add(r5,#0)
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB4_11
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r19 = add(r20,##409628)
		r17:16 = combine(r3,r4)
		r18 = r2
	}
	{
		call hexkl_kv_q_get
		r1:0 = combine(r2,r19)
	}
	.falign
// %bb.2:                               // %if.end
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB4_11
	}
// %bb.3:                               // %if.end3
	{
		p0 = cmp.gt(r21,#0); if (!p0.new) jump:nt .LBB4_7
	}
// %bb.4:                               // %if.end3
	{
		r2 = memw(r29+#52)
		if (!cmp.eq(r2.new,r21)) jump:nt .LBB4_7
	}
// %bb.5:                               // %lor.lhs.false7
	{
		r2 = memw(r0+#20)
		r3 = memw(r0+#24)
	}
	{
		r22 = mpyi(r3,r2)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
	}
	.falign
// %bb.6:                               // %lor.lhs.false7
	{
		r21 -= mpyi(r0,r22)
		r3 = r0
		if (cmp.eq(r21.new,#0)) jump:nt .LBB4_12
	}
	.falign
.LBB4_7:                                // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_10
	}
// %bb.8:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #135
	}
	{
		r3 = add(pc,##.L.str.2@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.9:                               // %if.else
	{
		jump .LBB4_11
	}
	.falign
.LBB4_10:                               // %if.then13
	{
		r3 = add(pc,##.L.str.2@PCREL)
		call _HAP_debug_v2
		r2 = #135
	}
	.falign
.LBB4_11:                               // %cleanup19
	{
		r0 = ##-2147482610
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB4_12:                               // %if.end15
	{
		r1:0 = combine(r18,r19)
		r2 = memw(r20+#0)
		memw(r29+#0) = r2.new
	}
	{
		r2 = r17
		r4 = r16
		r5 = memw(r29+#48)
		memw(r29+#4) = #0
	}
	{
		call hexkl_kv_q_append
	}
	.falign
// %bb.13:                              // %if.end15
	{
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end4:
	.size	nntr_hvx_kv_append_q, .Lfunc_end4-nntr_hvx_kv_append_q
                                        // -- End function
	.globl	nntr_hvx_kv_dump_q              // -- Begin function nntr_hvx_kv_dump_q
	.falign
	.type	nntr_hvx_kv_dump_q,@function
nntr_hvx_kv_dump_q:                     // @nntr_hvx_kv_dump_q
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		if (!p0.new) r1 = add(r2,#0)
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r18 = add(r3,#0)
		if (!p0) r17:16 = combine(r4,r5)
		if (p0) jump:nt .LBB5_12
		memd(r29+#8) = r19:18
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r0 = add(r0,##409628)
	}
	{
		call hexkl_kv_q_get
	}
	.falign
// %bb.2:                               // %if.end
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB5_12
		if (!p1.new) r3 = memw(r29+#64)
		if (!p1.new) r2 = memw(r0+#20)
	}
// %bb.3:                               // %if.end3
	{
		r5:4 = sxtw(r3)
	}
	{
		r3:2 = mpyu(r2,r17)
	}
	{
		p0 = cmp.eq(r3:2,r5:4)
		if (!p0.new) jump:nt .LBB5_10
		if (p0.new) r4 = memw(r29+#56)
	}
// %bb.4:                               // %if.end3
	{
		r5:4 = sxtw(r4)
	}
	{
		p1 = cmp.eq(r3:2,r5:4)
		if (!p1.new) jump:nt .LBB5_10
		if (p1.new) r4 = memw(r29+#48)
	}
// %bb.5:                               // %if.end3
	{
		r5:4 = sxtw(r4)
	}
	{
		p0 = cmp.eq(r3:2,r5:4)
		if (!p0.new) jump:nt .LBB5_10
		if (p0.new) r4 = memw(r29+#32)
		if (p0.new) r6 = memw(r0+#24)
	}
// %bb.6:                               // %if.end3
	{
		r9:8 = sxtw(r4)
	}
	{
		r5:4 = mpyu(r2,r6)
	}
	{
		r5 += mpyi(r6,r3)
	}
	{
		p1 = cmp.eq(r5:4,r9:8)
		if (!p1.new) jump:nt .LBB5_10
		if (p1.new) r2 = memw(r29+#40)
	}
// %bb.7:                               // %if.end3
	{
		r3:2 = sxtw(r2)
	}
	{
		p0 = cmp.eq(r5:4,r3:2)
		if (!p0.new) jump:nt .LBB5_10
	}
// %bb.8:                               // %if.end34
	{
		r2 = memw(r29+#60)
		memw(r29+#4) = r2.new
	}
	{
		r3:2 = combine(r16,r17)
		r1 = memw(r29+#52)
		memw(r29+#0) = r1.new
	}
	{
		call hexkl_kv_q_dump
		r1 = r18
		r5 = memw(r29+#44)
		r4 = memw(r29+#36)
	}
	.falign
// %bb.9:                               // %if.end34
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB5_10:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB5_13
	}
// %bb.11:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #160
	}
	{
		r3 = add(pc,##.L.str.3@PCREL)
		call HAP_debug_v2
	}
	.falign
.LBB5_12:                               // %cleanup38
	{
		r0 = ##-2147482610
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB5_13:                               // %if.then32
	{
		r3 = add(pc,##.L.str.3@PCREL)
		call _HAP_debug_v2
		r2 = #160
	}
	.falign
// %bb.14:                              // %if.then32
	{
		r0 = ##-2147482610
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end5:
	.size	nntr_hvx_kv_dump_q, .Lfunc_end5-nntr_hvx_kv_dump_q
                                        // -- End function
	.globl	nntr_hvx_probe_acc_i32_layout   // -- Begin function nntr_hvx_probe_acc_i32_layout
	.falign
	.type	nntr_hvx_probe_acc_i32_layout,@function
nntr_hvx_probe_acc_i32_layout:          // @nntr_hvx_probe_acc_i32_layout
// %bb.0:                               // %entry
	{
		r5:4 = combine(r1,r0)
		r0 = ##-2147482610
	}
	{
		p0 = cmp.eq(r4,#0)
		if (p0.new) jumpr:nt r31
	}
.LBB6_1:                                // %entry
	{
		p1 = cmp.gt(r3,#2)
		if (!p1.new) jumpr:nt r31
	}
.LBB6_2:                                // %if.end
	{
		r1 = ##67584
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		call hexkl_acc_layout_get
		r16 = r2
		r0 = memw(r4+#0)
	}
	.falign
// %bb.3:                               // %if.end
	{
		r2 = r0
		r3 = memw(r0+#4)
		memw(r16+#0) = r3.new
	}
	{
		r0 = #0
		r3 = memw(r0+#8)
		memw(r16+#4) = r3.new
	}
	{
		r2 = memw(r2+#12)
		memw(r16+#8) = r2.new
	}
	{
		r17:16 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
// %bb.4:                               // %cleanup
	{
		jumpr r31
	}
.Lfunc_end6:
	.size	nntr_hvx_probe_acc_i32_layout, .Lfunc_end6-nntr_hvx_probe_acc_i32_layout
                                        // -- End function
	.globl	nntr_hvx_probe_kv_q_mm          // -- Begin function nntr_hvx_probe_kv_q_mm
	.falign
	.type	nntr_hvx_probe_kv_q_mm,@function
nntr_hvx_probe_kv_q_mm:                 // @nntr_hvx_probe_kv_q_mm
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r0)
		memd(r29+#-16) = r17:16
		allocframe(#104)
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r16,#0)
		r6 = ##-2147449843
		memd(r29+#72) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r22 = add(r6,#-32767)
		if (!p0) r1 = add(r2,#0)
		memd(r29+#88) = r19:18
		memd(r29+#80) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r21:20 = combine(r5,r3)
		if (p0) jump:nt .LBB7_58
		memd(r29+#64) = r25:24
		memd(r29+#56) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r0 = add(r16,##409628)
		r19 = r4
	}
	{
		call hexkl_kv_q_get
	}
	.falign
// %bb.2:                               // %if.end
	{
		r17 = r0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB7_58
		if (!p1.new) r2 = memw(r0+#20)
	}
// %bb.3:                               // %lor.lhs.false
	{
		p0 = cmp.gtu(r2,r20); if (!p0.new) jump:t .LBB7_58
	}
// %bb.4:                               // %lor.lhs.false3
	{
		r2 = memw(r17+#28)
		if (!cmp.gtu(r2.new,r19)) jump:t ##.LBB7_58
	}
// %bb.5:                               // %if.end7
	{
		r27 = memw(r17+#24)
		r3 = memw(r29+#136)
	}
	{
		r2 = asl(r27,#6)
		if (!cmp.eq(r2.new,r3)) jump:nt ##.LBB7_44
	}
// %bb.6:                               // %if.end7
	{
		r3 = #2048
	}
	{
		r3 = memw(r29+#128)
		if (!cmp.eq(r3.new,r3)) jump:nt ##.LBB7_44
	}
// %bb.7:                               // %if.end7
	{
		r3 = #2048
	}
	{
		r3 = memw(r29+#120)
		if (!cmp.eq(r3.new,r3)) jump:nt ##.LBB7_44
	}
// %bb.8:                               // %if.end7
	{
		r3 = memw(r29+#112)
		if (!cmp.eq(r3.new,r2)) jump:nt ##.LBB7_44
	}
// %bb.9:                               // %if.end25
	{
		r23 = ##51200
		r2 = memw(r17+#32)
		r3 = memw(r16+#0)
	}
	{
		r0 = add(r3,##32768)
		p0 = cmp.eq(r2,#0)
		r1 = memw(r29+#116)
	}
	{
		r2 = p0
		memw(r29+#16) = r2
		memw(r29+#12) = r3
	}                                       // 4-byte Folded Spill
	{
		if (p0) r2 = ##2048
		if (p0) jump:nt .LBB7_47
		memw(r29+#40) = r2
	}                                       // 4-byte Folded Spill
// %bb.10:                              // %for.body.preheader
	{
		r22 = asl(r27,#4)
		r23 = #0
		memw(r29+#24) = r0
		memw(r29+#20) = r1
	}                                       // 4-byte Folded Spill
	.falign
.LBB7_11:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_12 Depth 2
	{
		r18 = #64
		r25 = r21
		r24 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r24 += asl(r23,#11)
	}
	.falign
.LBB7_12:                               // %for.body34
                                        //   Parent Loop BB7_11 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1:0 = combine(r25,r24)
		r2 = #32
	}
	.falign
// %bb.13:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r25,r27)
		r0 = add(r24,#32)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.14:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#64)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.15:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#96)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.16:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#128)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.17:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#160)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.18:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#192)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.19:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#224)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.20:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#256)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.21:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#288)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.22:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#320)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.23:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#352)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.24:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#384)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.25:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#416)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.26:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r26 = add(r26,r27)
		r0 = add(r24,#448)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.27:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = add(r26,r27)
		r0 = add(r24,#480)
		r2 = #32
	}
	.falign
// %bb.28:                              // %for.body34
                                        //   in Loop: Header=BB7_12 Depth=2
	{
		r24 = add(r24,#512)
		r25 = add(r25,r22)
		r18 = add(r18,#-16)
		if (!cmp.eq(r18.new,#0)) jump:t .LBB7_12
	}
// %bb.29:                              // %for.cond.cleanup33
                                        //   in Loop: Header=BB7_11 Depth=1
	{
		r21 = add(r21,#32)
		r23 = add(r23,#1)
	}
	{
		r2 = memw(r29+#16)
		if (!cmp.eq(r2.new,r23)) jump:t .LBB7_11
	}                                       // 4-byte Folded Reload
// %bb.30:                              // %for.body50.lr.ph
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r2 = #2048
		r0 = memw(r29+#24)
		r1 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.31:                              // %for.body50.lr.ph
	{
		r18 = #0
		r2 = memw(r29+#12)
		r22 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r21 = add(r2,##34816)
	}
	.falign
.LBB7_32:                               // %for.body50
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = r19
		r6 = r18
		r3 = memw(r17+#28)
		r5 = memw(r17+#32)
	}
	{
		r0 = r21
		r2 = memw(r17+#12)
		r1 = memw(r17+#56)
	}
	{
		r4 += mpyi(r3,r20)
	}
	{
		r6 += mpyi(r4,r5)
	}
	{
		r1 += mpyi(r6,r2)
		call memcpy
	}
	.falign
// %bb.33:                              // %for.body50
                                        //   in Loop: Header=BB7_32 Depth=1
	{
		r3 = r19
		r5 = r18
		r2 = memw(r17+#28)
		r4 = memw(r17+#32)
	}
	{
		r0 = add(r21,#16384)
		r1 = memw(r17+#60)
	}
	{
		r3 += mpyi(r2,r20)
		r2 = memw(r17+#12)
	}
	{
		r5 += mpyi(r3,r4)
	}
	{
		r1 += mpyi(r5,r2)
		call memcpy
	}
	.falign
// %bb.34:                              // %for.body50
                                        //   in Loop: Header=BB7_32 Depth=1
	{
		r18 = add(r18,#1)
		r21 = add(r21,#1024)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB7_32
	}
// %bb.35:                              // %for.body70.lr.ph
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.36:                              // %for.body70.lr.ph
	{
		r20 = #0
		r23 = ##51200
		r18 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r19 = add(r23,#-16384)
	}
	.falign
.LBB7_37:                               // %for.body70
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memb(r17+#4)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB7_40
	}
// %bb.38:                              // %cond.true
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		call hexkl_micro_hmx_mm_u8i4
		r2 = r19
		r1 = r20
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.39:                              // %cond.true
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		r22 = r0 ; jump .LBB7_42
	}
	.falign
.LBB7_40:                               // %cond.false
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		call hexkl_micro_hmx_mm_u8i8
		r2 = r19
		r1 = r20
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.41:                              // %cond.false
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		r22 = r0
	}
	.falign
.LBB7_42:                               // %cond.end
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		r20 = add(r20,#2048)
		r19 = add(r19,#1024)
		p0 = cmp.eq(r22,#0); if (!p0.new) jump:nt .LBB7_58
	}
// %bb.43:                              // %for.cond66
                                        //   in Loop: Header=BB7_37 Depth=1
	{
		r18 = add(r18,#-1)
		if (!cmp.eq(r18.new,#0)) jump:t .LBB7_37
	}
	{
		jump .LBB7_49
	}
	.falign
.LBB7_44:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB7_57
	}
// %bb.45:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #219
	}
	{
		r3 = add(pc,##.L.str.4@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.46:                              // %if.else
	{
		jump .LBB7_58
	}
	.falign
.LBB7_47:                               // %for.cond.cleanup49.thread
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
	}
	.falign
// %bb.48:                              // %for.cond.cleanup49.thread
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
.LBB7_49:                               // %for.end91
	{
		r18 = add(r23,#16384)
		r0 = memw(r16+#0)
	}
	{
		call hexkl_acc_layout_get
		r1 = r18
	}
	.falign
// %bb.50:                              // %for.end91
	{
		r20 = r0
		r2 = r18
		r0 = memw(r16+#0)
		r1 = memw(r16+#8)
	}
	{
		call hexkl_micro_hmx_acc_read_int32
	}
	.falign
// %bb.51:                              // %for.end91
	{
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB7_58
		r4 = #0
		r22 = r0
	}
// %bb.52:                              // %if.end.i
	{
		r2 = memw(r20+#4)
		r0 = memw(r16+#0)
	}
	{
		if (p0.new) r1 = add(r18,#0)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB7_59
		r2 = memw(r29+#124)
	}
// %bb.53:                              // %if.then3.i
	{
		r3 = add(r0,##67584)
		memw(r29+#44) = r18
	}                                       // 4-byte Folded Spill
	{
		loop0(.LBB7_54,#64)
		r5 = add(r3,#4)
		r12 = add(r3,#24)
		memw(r29+#20) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r13 = add(r3,#28)
		r5 = add(r3,#8)
		r14 = add(r3,#32)
		memw(r29+#24) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r15 = add(r3,#36)
		r5 = add(r3,#12)
		r28 = add(r3,#40)
		memw(r29+#28) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r0 = add(r3,#44)
		r5 = add(r3,#16)
		r1 = add(r3,#48)
		memw(r29+#32) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r10 = add(r3,#52)
		r5 = add(r3,#20)
		r11 = add(r3,#56)
		memw(r29+#36) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r21 = add(r3,#60)
		r22 = add(r3,#64)
		r24 = add(r3,#68)
		r25 = add(r3,#72)
	}
	{
		r26 = add(r3,#76)
		r19 = add(r3,#80)
		r5 = add(r3,#84)
		r6 = add(r3,#88)
	}
	{
		r7 = add(r3,#92)
		r8 = add(r3,#96)
		r9 = add(r3,#100)
	}
	.falign
.LBB7_54:                               // Block address taken
                                        // %for.cond6.preheader.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r18 = mpyi(r18,r4)
		r23 = addasl(r3,r23,#2)
	}
	{
		r18 = memw(r23+r18<<#2)
		memw(r2+#0) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#4) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#8) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#12) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#16) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#20) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r12+r23<<#2)
		memw(r2+#24) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r13+r23<<#2)
		memw(r2+#28) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r14+r23<<#2)
		memw(r2+#32) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r15+r23<<#2)
		memw(r2+#36) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r28+r23<<#2)
		memw(r2+#40) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r0+r23<<#2)
		memw(r2+#44) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r1+r23<<#2)
		memw(r2+#48) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r10+r23<<#2)
		memw(r2+#52) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r11+r23<<#2)
		memw(r2+#56) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r21+r23<<#2)
		memw(r2+#60) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r22+r23<<#2)
		memw(r2+#64) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r24+r23<<#2)
		memw(r2+#68) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r25+r23<<#2)
		memw(r2+#72) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r26+r23<<#2)
		memw(r2+#76) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r19+r23<<#2)
		memw(r2+#80) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r5+r23<<#2)
		memw(r2+#84) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r6+r23<<#2)
		memw(r2+#88) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r7+r23<<#2)
		memw(r2+#92) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r8+r23<<#2)
		memw(r2+#96) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
	}
	{
		r18 = memw(r9+r23<<#2)
		memw(r2+#100) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#104)
	}
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#104) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#108)
	}
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#108) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#112)
	}
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#112) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#116)
	}
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#116) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#120)
	}
	{
		r18 = memw(r18+r23<<#2)
		memw(r2+#120) = r18.new
	}
	{
		r18 = memw(r20+#12)
		r23 = memw(r20+#8)
	}
	{
		r23 += mpyi(r18,r4)
		r18 = add(r3,#124)
		r4 = add(r4,#1)
	}
	{
		r2 = add(r2,#128)
		r18 = memw(r18+r23<<#2)
		memw(r2+#124) = r18.new
	} :endloop0
// %bb.55:                              // %for.cond99.preheader
	{
		r23 = ##51200
		r18 = memw(r29+#44)
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		if (!p1.new) jump:t .LBB7_62
		p1 = r2
		jump .LBB7_58
		r22 = #0
	}
// %bb.56:
	.falign
.LBB7_57:                               // %if.then23
	{
		r3 = add(pc,##.L.str.4@PCREL)
		call _HAP_debug_v2
		r2 = #219
	}
	.falign
.LBB7_58:                               // %cleanup139
	{
		r0 = r22
		r17:16 = memd(r29+#96)
		r19:18 = memd(r29+#88)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#80)
		r23:22 = memd(r29+#72)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#64)
		r27:26 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB7_59:                               // %read_acc_tile.exit
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		r3 = #0
		r5:4 = combine(#64,#0)
		memw(r29+#0) = #32
	}
	.falign
// %bb.60:                              // %read_acc_tile.exit
	{
		r22 = r0
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB7_58
		if (p1.new) r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
// %bb.61:                              // %read_acc_tile.exit
	{
		p0 = r2
		if (p0.new) jump:nt .LBB7_58
	}
	.falign
.LBB7_62:                               // %for.body103.lr.ph
	{
		r25 = asl(r27,#2)
		r26 = #0
		r20 = add(r23,#-18432)
		r19 = memw(r29+#132)
	}
	{
		r24 = add(r19,#124)
	}
	.falign
.LBB7_63:                               // %for.body103
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_75 Depth 2
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.64:                              // %for.body103
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r1 = r20
		r2 = memb(r17+#4)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB7_67
	}
// %bb.65:                              // %cond.true108
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r1 = r20
		r2 = ##51200
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r26,#10)
		call hexkl_micro_hmx_mm_u8i4
	}
	.falign
// %bb.66:                              // %cond.true108
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r22 = r0 ; jump .LBB7_69
	}
	.falign
.LBB7_67:                               // %cond.false112
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r2 = ##51200
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r26,#10)
		call hexkl_micro_hmx_mm_u8i8
	}
	.falign
// %bb.68:                              // %cond.false112
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r22 = r0
	}
	.falign
.LBB7_69:                               // %cond.end116
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		p1 = cmp.eq(r22,#0); if (!p1.new) jump:nt .LBB7_58
	}
// %bb.70:                              // %if.end121
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		call hexkl_acc_layout_get
		r1 = r18
		r0 = memw(r16+#0)
	}
	.falign
// %bb.71:                              // %if.end121
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r21 = r0
		r2 = r18
		r0 = memw(r16+#0)
		r1 = memw(r16+#8)
	}
	{
		call hexkl_micro_hmx_acc_read_int32
	}
	.falign
// %bb.72:                              // %if.end121
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r22 = r0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB7_58
		if (p0.new) r2 = memw(r21+#4)
	}
// %bb.73:                              // %if.end.i232
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r0 = memw(r16+#0)
	}
	{
		if (!p1.new) r1 = add(r24,#0)
		if (!p1.new) r3 = #0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB7_76
	}
// %bb.74:                              // %if.then3.i235
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r2 = add(r0,##67584)
	}
	{
		loop0(.LBB7_75,#64)
		r4 = add(r2,#4)
		r5 = add(r2,#8)
		r6 = add(r2,#12)
	}
	{
		r7 = add(r2,#16)
		r8 = add(r2,#20)
		r9 = add(r2,#24)
		r12 = add(r2,#28)
	}
	{
		r13 = add(r2,#32)
		r14 = add(r2,#36)
		r15 = add(r2,#40)
		r28 = add(r2,#44)
	}
	{
		r0 = add(r2,#48)
	}
	.falign
.LBB7_75:                               // Block address taken
                                        // %for.cond6.preheader.i237
                                        //   Parent Loop BB7_63 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r10 = mpyi(r10,r3)
		r11 = addasl(r2,r11,#2)
	}
	{
		r10 = memw(r11+r10<<#2)
		memw(r1+#-124) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r4+r11<<#2)
		memw(r1+#-120) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r5+r11<<#2)
		memw(r1+#-116) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r6+r11<<#2)
		memw(r1+#-112) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r7+r11<<#2)
		memw(r1+#-108) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r8+r11<<#2)
		memw(r1+#-104) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r9+r11<<#2)
		memw(r1+#-100) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r12+r11<<#2)
		memw(r1+#-96) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r13+r11<<#2)
		memw(r1+#-92) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r14+r11<<#2)
		memw(r1+#-88) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r15+r11<<#2)
		memw(r1+#-84) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r28+r11<<#2)
		memw(r1+#-80) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
	}
	{
		r10 = memw(r0+r11<<#2)
		memw(r1+#-76) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#52)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-72) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#56)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-68) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#60)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-64) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#64)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-60) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#68)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-56) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#72)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-52) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#76)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-48) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#80)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-44) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#84)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-40) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#88)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-36) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#92)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-32) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#96)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-28) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#100)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-24) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#104)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-20) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#108)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-16) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#112)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-12) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#116)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-8) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#120)
	}
	{
		r10 = memw(r10+r11<<#2)
		memw(r1+#-4) = r10.new
	}
	{
		r10 = memw(r21+#12)
		r11 = memw(r21+#8)
	}
	{
		r11 += mpyi(r10,r3)
		r10 = add(r2,#124)
		r3 = add(r3,#1)
	}
	{
		r1 = add(r1,r25)
		r10 = memw(r10+r11<<#2)
		memw(r1+#0) = r10.new
	} :endloop0
	{
		jump .LBB7_78
	}
	.falign
.LBB7_76:                               // %read_acc_tile.exit255
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r2 = asl(r26,#7)
		r5:4 = combine(#64,#0)
		r3 = #0
		r1 = r18
	}
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		r2 = add(r19,r2)
		memw(r29+#0) = r27
	}
	.falign
// %bb.77:                              // %read_acc_tile.exit255
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r22 = r0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB7_58
	}
	.falign
.LBB7_78:                               // %for.inc129
                                        //   in Loop: Header=BB7_63 Depth=1
	{
		r26 = add(r26,#1)
		r24 = add(r24,#128)
		r22 = #0
	}
	{
		r2 = memw(r29+#16)
		if (!cmp.eq(r2.new,r26)) jump:t ##.LBB7_63
	}                                       // 4-byte Folded Reload
	{
		jump .LBB7_58
	}
.Lfunc_end7:
	.size	nntr_hvx_probe_kv_q_mm, .Lfunc_end7-nntr_hvx_probe_kv_q_mm
                                        // -- End function
	.falign
	.type	read_acc_tile,@function         // -- Begin function read_acc_tile
read_acc_tile:                          // @read_acc_tile
// %bb.0:                               // %entry
	{
		r17 = r1
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r2,r0)
		r1 = ##67584
		memd(r29+#40) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r0 = memw(r0+#0)
		memd(r29+#32) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r20 = ##67584
		memd(r29+#24) = r23:22
		memd(r29+#16) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call hexkl_acc_layout_get
		memd(r29+#8) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = ##67584
		r16 = r0
		r0 = memw(r18+#0)
	}
	{
		call hexkl_micro_hmx_acc_read_int32
		r1 = memw(r18+#8)
	}
	.falign
// %bb.2:                               // %entry
	{
		r4 = add(r17,#124)
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:t .LBB8_6
		if (p0.new) r2 = memw(r16+#4)
	}
// %bb.3:                               // %if.end
	{
		r0 = memw(r18+#0)
	}
	{
		r3 = add(r0,r20)
		if (!p1.new) r0 = #0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB8_7
	}
// %bb.4:                               // %if.then3
	{
		r2 = asl(r19,#2)
		r5 = add(r3,#4)
		r6 = add(r3,#8)
		r7 = add(r3,#12)
	}
	{
		r8 = add(r3,#16)
		r9 = add(r3,#20)
		r12 = add(r3,#24)
		r13 = add(r3,#28)
	}
	{
		r14 = add(r3,#32)
		r15 = add(r3,#36)
		r28 = add(r3,#40)
		r1 = add(r3,#44)
	}
	{
		r10 = add(r3,#48)
		r11 = add(r3,#52)
		r17 = add(r3,#56)
		r18 = add(r3,#60)
	}
	{
		r19 = add(r3,#64)
		r20 = add(r3,#68)
		r21 = add(r3,#72)
		r22 = add(r3,#76)
	}
	{
		r23 = add(r3,#80)
		r24 = add(r3,#84)
		r25 = #0
	}
	{
		loop0(.LBB8_5,#64)
	}
	.falign
.LBB8_5:                                // Block address taken
                                        // %for.cond6.preheader
                                        // =>This Inner Loop Header: Depth=1
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r26 = mpyi(r26,r25)
		r27 = addasl(r3,r27,#2)
	}
	{
		r26 = memw(r27+r26<<#2)
		memw(r4+#-124) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r5+r27<<#2)
		memw(r4+#-120) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r6+r27<<#2)
		memw(r4+#-116) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r7+r27<<#2)
		memw(r4+#-112) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r8+r27<<#2)
		memw(r4+#-108) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r9+r27<<#2)
		memw(r4+#-104) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r12+r27<<#2)
		memw(r4+#-100) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r13+r27<<#2)
		memw(r4+#-96) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r14+r27<<#2)
		memw(r4+#-92) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r15+r27<<#2)
		memw(r4+#-88) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r28+r27<<#2)
		memw(r4+#-84) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r1+r27<<#2)
		memw(r4+#-80) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r10+r27<<#2)
		memw(r4+#-76) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r11+r27<<#2)
		memw(r4+#-72) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r17+r27<<#2)
		memw(r4+#-68) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r18+r27<<#2)
		memw(r4+#-64) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r19+r27<<#2)
		memw(r4+#-60) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r20+r27<<#2)
		memw(r4+#-56) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r21+r27<<#2)
		memw(r4+#-52) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r22+r27<<#2)
		memw(r4+#-48) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r23+r27<<#2)
		memw(r4+#-44) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
	}
	{
		r26 = memw(r24+r27<<#2)
		memw(r4+#-40) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#88)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-36) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#92)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-32) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#96)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-28) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#100)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-24) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#104)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-20) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#108)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-16) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#112)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-12) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#116)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-8) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#120)
	}
	{
		r26 = memw(r26+r27<<#2)
		memw(r4+#-4) = r26.new
	}
	{
		r26 = memw(r16+#12)
		r27 = memw(r16+#8)
	}
	{
		r27 += mpyi(r26,r25)
		r26 = add(r3,#124)
		r25 = add(r25,#1)
	}
	{
		r4 = add(r4,r2)
		r26 = memw(r26+r27<<#2)
		memw(r4+#0) = r26.new
	} :endloop0
	.falign
.LBB8_6:                                // %cleanup
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#16)
		r27:26 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB8_7:                                // %if.end14
	{
		r5:4 = combine(#64,#0)
		r1 = ##67584
		r3:2 = combine(#0,r17)
	}
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		memw(r29+#0) = r19
	}
	.falign
// %bb.8:                               // %if.end14
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#16)
		r27:26 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	read_acc_tile, .Lfunc_end8-read_acc_tile
                                        // -- End function
	.globl	nntr_hvx_probe_cvt              // -- Begin function nntr_hvx_probe_cvt
	.falign
	.type	nntr_hvx_probe_cvt,@function
nntr_hvx_probe_cvt:                     // @nntr_hvx_probe_cvt
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		r6 = ##-2147449843
		allocframe(#112)
	}
	{
		r23 = add(r6,#-32767)
		memd(r29+#104) = r17:16
		memd(r29+#80) = r23:22
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#96) = r19:18
		memd(r29+#88) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB9_65
		memd(r29+#72) = r25:24
		memd(r29+#64) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r21:20 = combine(r3,r4)
		r0 = add(r0,##409628)
		r4 = r0
	}
	{
		call hexkl_kv_q_get
		r17 = r5
		r1 = r2
		memd(r29+#16) = r5:4
	}                                       // 8-byte Folded Spill
	.falign
// %bb.2:                               // %if.end
	{
		r22 = r0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB9_65
		if (!p1.new) r2 = memw(r0+#20)
	}
// %bb.3:                               // %lor.lhs.false
	{
		p0 = cmp.gtu(r2,r21); if (!p0.new) jump:t .LBB9_65
	}
// %bb.4:                               // %lor.lhs.false3
	{
		r3 = #255
		r2 = memw(r22+#28)
		if (!cmp.gtu(r2.new,r20)) jump:t ##.LBB9_65
	}
// %bb.5:                               // %lor.lhs.false6
	{
		r0 = memw(r29+#136)
		if (cmp.eq(r0.new,#0)) jump:nt ##.LBB9_65
	}
// %bb.6:                               // %lor.lhs.false6
	{
		r2 = memub(r22+#4)
	}
	{
		p1 = !bitsclr(r2,r3)
		if (p1.new) jump:nt .LBB9_65
	}
// %bb.7:                               // %if.end14
	{
		r4 = memw(r29+#176)
		if (!cmp.gt(r4.new,#1)) jump:nt ##.LBB9_59
	}
// %bb.8:                               // %if.end14
	{
		r3 = memw(r29+#168)
	}
	{
		r2 = #2048
		if (!cmp.eq(r2.new,r3)) jump:nt ##.LBB9_59
	}
// %bb.9:                               // %if.end14
	{
		r3 = memw(r29+#160)
		if (!cmp.eq(r3.new,r2)) jump:nt ##.LBB9_59
	}
// %bb.10:                              // %if.end14
	{
		r3 = memw(r29+#152)
		if (!cmp.eq(r3.new,r2)) jump:nt ##.LBB9_59
	}
// %bb.11:                              // %if.end14
	{
		r3 = memw(r29+#144)
		if (!cmp.eq(r3.new,r2)) jump:nt ##.LBB9_59
	}
// %bb.12:                              // %if.end14
	{
		r16 = memw(r22+#24)
		r2 = memw(r29+#120)
	}
	{
		r3 = asl(r16,#6)
		if (!cmp.eq(r3.new,r2)) jump:nt ##.LBB9_59
	}
// %bb.13:                              // %if.end37
	{
		r2 = memw(r29+#132)
		memw(r29+#40) = r2.new
	}
	{
		r25 = memw(r22+#32)
		memd(r29+#48) = r1:0
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r25,#0)
		r3:2 = memd(r29+#16)
		r1 = memw(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r0 = memw(r29+#124)
		memw(r29+#4) = r1
	}
	{
		r0 = p0
		r1 = memw(r2+#0)
		memw(r29+#8) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#12) = r4
		memw(r29+#0) = r1
	}                                       // 4-byte Folded Spill
	{
		if (p0) jump:nt .LBB9_35
		memw(r29+#32) = r0
		if (!p0) memw(r29+#24) = r25
	}                                       // 4-byte Folded Spill
// %bb.14:                              // %for.body.lr.ph
	{
		r18 = asl(r16,#4)
		r19 = #0
		r2 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		r23 = add(r2,##34816)
	}
	.falign
.LBB9_15:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB9_16 Depth 2
	{
		r27 = #64
		r25 = r17
		r24 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		r24 += asl(r19,#11)
	}
	.falign
.LBB9_16:                               // %for.body46
                                        //   Parent Loop BB9_15 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1:0 = combine(r25,r24)
		r2 = #32
	}
	.falign
// %bb.17:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r25,r16)
		r0 = add(r24,#32)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.18:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#64)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.19:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#96)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.20:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#128)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.21:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#160)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.22:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#192)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.23:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#224)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.24:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#256)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.25:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#288)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.26:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#320)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.27:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#352)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.28:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#384)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.29:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#416)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.30:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r26 = add(r26,r16)
		r0 = add(r24,#448)
		r2 = #32
	}
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r26
	}
	.falign
// %bb.31:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = add(r26,r16)
		r0 = add(r24,#480)
		r2 = #32
	}
	.falign
// %bb.32:                              // %for.body46
                                        //   in Loop: Header=BB9_16 Depth=2
	{
		r24 = add(r24,#512)
		r25 = add(r25,r18)
		r27 = add(r27,#-16)
		if (!cmp.eq(r27.new,#0)) jump:t .LBB9_16
	}
// %bb.33:                              // %for.cond.cleanup45
                                        //   in Loop: Header=BB9_15 Depth=1
	{
		r4 = r20
		r6 = r19
		r3 = memw(r22+#28)
		r5 = memw(r22+#32)
	}
	{
		r0 = r23
		r2 = memw(r22+#12)
		r1 = memw(r22+#56)
	}
	{
		r4 += mpyi(r3,r21)
	}
	{
		r6 += mpyi(r4,r5)
	}
	{
		r1 += mpyi(r6,r2)
		call memcpy
	}
	.falign
// %bb.34:                              // %for.cond.cleanup45
                                        //   in Loop: Header=BB9_15 Depth=1
	{
		r23 = add(r23,#1024)
		r17 = add(r17,#32)
		r19 = add(r19,#1)
	}
	{
		r25 = memw(r29+#24)
		if (!cmp.eq(r25.new,r19)) jump:t .LBB9_15
	}                                       // 4-byte Folded Reload
	.falign
.LBB9_35:                               // %for.cond.cleanup
	{
		r2 = #768
		r17 = #0
		r1 = #0
		r16 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		call memset
		r0 = add(r16,##76032)
	}
	.falign
// %bb.36:                              // %for.cond.cleanup
	{
		r24 = add(r16,##75776)
		r1 = #0
		r18 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r16,##77056)
		r2 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		r3 = combine(r18.l,r2.l)
		r2 = #768
		memw(r24+#0) = r3.new
	}
	{
		memw(r24+#128) = r3
		memw(r24+#4) = r3
	}
	{
		memw(r24+#132) = r3
		memw(r24+#8) = r3
	}
	{
		memw(r24+#136) = r3
		memw(r24+#12) = r3
	}
	{
		memw(r24+#140) = r3
		memw(r24+#16) = r3
	}
	{
		memw(r24+#144) = r3
		memw(r24+#20) = r3
	}
	{
		memw(r24+#148) = r3
		memw(r24+#24) = r3
	}
	{
		memw(r24+#152) = r3
		memw(r24+#28) = r3
	}
	{
		memw(r24+#156) = r3
		memw(r24+#32) = r3
	}
	{
		memw(r24+#160) = r3
		memw(r24+#36) = r3
	}
	{
		memw(r24+#164) = r3
		memw(r24+#40) = r3
	}
	{
		memw(r24+#168) = r3
		memw(r24+#44) = r3
	}
	{
		memw(r24+#172) = r3
		memw(r24+#48) = r3
	}
	{
		memw(r24+#176) = r3
		memw(r24+#52) = r3
	}
	{
		memw(r24+#180) = r3
		memw(r24+#56) = r3
	}
	{
		memw(r24+#184) = r3
		memw(r24+#60) = r3
	}
	{
		memw(r24+#188) = r3
		memw(r24+#64) = r3
	}
	{
		memw(r24+#192) = r3
		memw(r24+#68) = r3
	}
	{
		memw(r24+#196) = r3
		memw(r24+#72) = r3
	}
	{
		memw(r24+#200) = r3
		memw(r24+#76) = r3
	}
	{
		memw(r24+#204) = r3
		memw(r24+#80) = r3
	}
	{
		memw(r24+#208) = r3
		memw(r24+#84) = r3
	}
	{
		memw(r24+#212) = r3
		memw(r24+#88) = r3
	}
	{
		memw(r24+#216) = r3
		memw(r24+#92) = r3
	}
	{
		memw(r24+#220) = r3
		memw(r24+#96) = r3
	}
	{
		memw(r24+#224) = r3
		memw(r24+#100) = r3
	}
	{
		memw(r24+#228) = r3
		memw(r24+#104) = r3
	}
	{
		memw(r24+#232) = r3
		memw(r24+#108) = r3
	}
	{
		memw(r24+#236) = r3
		memw(r24+#112) = r3
	}
	{
		memw(r24+#240) = r3
		memw(r24+#116) = r3
	}
	{
		memw(r24+#244) = r3
		memw(r24+#120) = r3
	}
	{
		memw(r24+#248) = r3
		memw(r24+#124) = r3
	}
	{
		call memset
		memw(r24+#252) = r3
	}
	.falign
// %bb.37:                              // %for.cond.cleanup
	{
		r2 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r2 = combine(r18.l,r2.l)
		memw(r24+#1024) = r2.new
	}
	{
		memw(r24+#1152) = r2
		memw(r24+#1028) = r2
	}
	{
		memw(r24+#1156) = r2
		memw(r24+#1032) = r2
	}
	{
		memw(r24+#1160) = r2
		memw(r24+#1036) = r2
	}
	{
		memw(r24+#1164) = r2
		memw(r24+#1040) = r2
	}
	{
		memw(r24+#1168) = r2
		memw(r24+#1044) = r2
	}
	{
		memw(r24+#1172) = r2
		memw(r24+#1048) = r2
	}
	{
		memw(r24+#1176) = r2
		memw(r24+#1052) = r2
	}
	{
		memw(r24+#1180) = r2
		memw(r24+#1056) = r2
	}
	{
		memw(r24+#1184) = r2
		memw(r24+#1060) = r2
	}
	{
		memw(r24+#1188) = r2
		memw(r24+#1064) = r2
	}
	{
		memw(r24+#1192) = r2
		memw(r24+#1068) = r2
	}
	{
		memw(r24+#1196) = r2
		memw(r24+#1072) = r2
	}
	{
		memw(r24+#1200) = r2
		memw(r24+#1076) = r2
	}
	{
		memw(r24+#1204) = r2
		memw(r24+#1080) = r2
	}
	{
		memw(r24+#1208) = r2
		memw(r24+#1084) = r2
	}
	{
		memw(r24+#1212) = r2
		memw(r24+#1088) = r2
	}
	{
		memw(r24+#1216) = r2
		memw(r24+#1092) = r2
	}
	{
		memw(r24+#1220) = r2
		memw(r24+#1096) = r2
	}
	{
		memw(r24+#1224) = r2
		memw(r24+#1100) = r2
	}
	{
		memw(r24+#1228) = r2
		memw(r24+#1104) = r2
	}
	{
		memw(r24+#1232) = r2
		memw(r24+#1108) = r2
	}
	{
		memw(r24+#1236) = r2
		memw(r24+#1112) = r2
	}
	{
		memw(r24+#1240) = r2
		memw(r24+#1116) = r2
	}
	{
		memw(r24+#1244) = r2
		memw(r24+#1120) = r2
	}
	{
		memw(r24+#1248) = r2
		memw(r24+#1124) = r2
	}
	{
		memw(r24+#1252) = r2
		memw(r24+#1128) = r2
	}
	{
		memw(r24+#1256) = r2
		memw(r24+#1132) = r2
	}
	{
		memw(r24+#1260) = r2
		memw(r24+#1136) = r2
	}
	{
		memw(r24+#1264) = r2
		memw(r24+#1140) = r2
	}
	{
		memw(r24+#1268) = r2
		memw(r24+#1144) = r2
	}
	{
		memw(r24+#1272) = r2
		memw(r24+#1148) = r2
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		memw(r24+#1276) = r2
	}
	.falign
// %bb.38:                              // %for.cond.cleanup
	{
		r20 = ##34816
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB9_42
	}
	.falign
.LBB9_39:                               // %for.body93
                                        // =>This Inner Loop Header: Depth=1
	{
		call hexkl_micro_hmx_mm_u8i8
		r2 = r20
		r1 = r17
		r0 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.40:                              // %for.body93
                                        //   in Loop: Header=BB9_39 Depth=1
	{
		r20 = add(r20,#1024)
		r23 = r0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB9_65
	}
// %bb.41:                              // %for.cond89
                                        //   in Loop: Header=BB9_39 Depth=1
	{
		r17 = add(r17,#2048)
		r25 = add(r25,#-1)
		if (!cmp.eq(r25.new,#0)) jump:t .LBB9_39
	}
	.falign
.LBB9_42:                               // %for.body113.lr.ph
	{
		r20 = memw(r29+#164)
		r18 = memw(r29+#172)
	}
	{
		r3 = memw(r29+#0)
		r21 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r3,##76800)
		r22 = memw(r29+#148)
		r0 = memw(r29+#140)
	}
	//# InlineAsm Start
	{
		r5:4 = c15:14
	}
	//# InlineAsm End
	{
		r23 = add(r3,##77824)
		r7:6 = memd(r29+#48)
		memd(r29+#24) = r5:4
	}                                       // 8-byte Folded Reload
	{
		r5 = lsr(r6,#2)
		r3 = #0
		r4 = and(r6,#3)
	}
	{
		p1 = cmp.gtu(r5,#0); if (!p1.new) jump:t .LBB9_45
	}
// %bb.43:
	{
		loop0(.LBB9_44,r5)
	}
	.balign 32
.LBB9_44:                               // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		nop
		nop
	} :endloop0
	.falign
.LBB9_45:
	{
		loop0(.LBB9_47,r4)
		p0 = cmp.gtu(r4,#0); if (!p0.new) jump:t .LBB9_48
	}
	.falign
.LBB9_47:                               // Block address taken
                                        // %for.body113
                                        // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		nop
		nop
	} :endloop0
	.falign
.LBB9_48:
	//# InlineAsm Start
	{
		r5:4 = c15:14
	}
	//# InlineAsm End
	{
		memd(r29+#32) = r5:4
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r5:4 = c15:14
	}
	//# InlineAsm End
	{
		loop0(.LBB9_49,r6)
		v0 = vxor(v0,v0)
		r3 = #0
		memd(r29+#40) = r5:4
	}                                       // 8-byte Folded Spill
	.falign
.LBB9_49:                               // Block address taken
                                        // %for.body127
                                        // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		bias = mxmem(r24)
	}

	{
		mxmem(r23,r3):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		v0 = vor(v0,v1)
		v1.cur = vmem(r23+#0)
	} :endloop0
// %bb.50:                              // %for.cond.cleanup126
	//# InlineAsm Start
	{
		r27:26 = c15:14
	}
	//# InlineAsm End
	{
		r7 = #0
		r19 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r19,##79872)
		r17:16 = combine(r7,r6)
	}
	{
		vmem(r24+#0) = v0
	}
	//# InlineAsm Start
	{
		bias = mxmem(r2)
	}

	{
		mxmem(r24,r7):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1 = r23
		r2 = #2048
	}
	.falign
// %bb.51:                              // %for.cond.cleanup126
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1:0 = combine(r24,r22)
		r2 = #2048
	}
	.falign
// %bb.52:                              // %for.cond.cleanup126
	{
		r19 = add(r19,##81920)
		r1:0 = combine(r24,r23)
	}
	{
		call hexkl_cvt_zip_i16
		r2 = r19
	}
	.falign
// %bb.53:                              // %for.cond.cleanup126
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1:0 = combine(r19,r21)
		r2 = #4096
	}
	//# InlineAsm Start
	{
		r25:24 = c15:14
	}
	//# InlineAsm End
	{
		r2 = #32
		r1:0 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		call read_acc_tile
		r1 = r20
	}
	.falign
// %bb.54:                              // %for.cond.cleanup126
	{
		r23 = r0
	}
	//# InlineAsm Start
	{
		r21:20 = c15:14
	}
	//# InlineAsm End
	{
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB9_65
		if (p1.new) r3:2 = memd(r29+#32)
		if (p1.new) r1:0 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
// %bb.55:                              // %if.end152
	{
		call __hexagon_udivdi3
		r1:0 = sub(r3:2,r1:0)
		r3:2 = combine(r17,r16)
	}
	.falign
// %bb.56:                              // %if.end152
	{
		r2 = memw(r29+#12)
		memw(r18+#0) = r0
	}                                       // 4-byte Folded Reload
	{
		r3:2 = sub(r21:20,r25:24)
		p0 = cmp.gt(r2,#2)
		if (!p0.new) r23 = add(r17,#0)
	}
	{
		if (!p0) jump:nt .LBB9_65
		memw(r18+#4) = r2
	}
// %bb.57:                              // %if.then161
	{
		r3:2 = combine(r17,r16)
		r1:0 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		call __hexagon_udivdi3
		r1:0 = sub(r27:26,r1:0)
	}
	.falign
// %bb.58:                              // %if.then161
	{
		r23 = r17 ; jump .LBB9_65
		memw(r18+#8) = r0
	}
	.falign
.LBB9_59:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB9_62
	}
// %bb.60:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #297
	}
	{
		r3 = add(pc,##.L.str.5@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.61:                              // %if.else
	{
		jump .LBB9_65
	}
	.falign
.LBB9_62:                               // %if.then35
	{
		r3 = add(pc,##.L.str.5@PCREL)
		call _HAP_debug_v2
		r2 = #297
	}
	.falign
// %bb.63:                              // %if.then35
	.falign
.LBB9_65:                               // %cleanup182
	{
		r0 = r23
		r17:16 = memd(r29+#104)
		r19:18 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#88)
		r23:22 = memd(r29+#80)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#72)
		r27:26 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end9:
	.size	nntr_hvx_probe_cvt, .Lfunc_end9-nntr_hvx_probe_cvt
                                        // -- End function
	.falign
	.type	hexkl_cvt_zip_i16,@function     // -- Begin function hexkl_cvt_zip_i16
hexkl_cvt_zip_i16:                      // @hexkl_cvt_zip_i16
// %bb.0:                               // %entry
	{
		r7 = #-1
		r3 = add(r2,#1024)
		r4 = add(r2,#1152)
		v0 = vmem(r1+#0)
	}
	{
		r6 = add(r2,#1408)
		r5 = add(r1,#1024)
		v1 = vmem(r0+#0)
	}
	{
		v1:0 = vshuff(v0,v1,r7)
		vmem(r2+#0) = v0.new
	}
	{
		vmem(r2+#1) = v1
	}
	{
		v2 = vmem(r1+#1)
	}
	{
		v3 = vmem(r0+#1)
	}
	{
		v3:2 = vshuff(v2,v3,r7)
		vmem(r2+#2) = v2.new
	}
	{
		vmem(r2+#3) = v3
	}
	{
		v4 = vmem(r1+#2)
	}
	{
		v5 = vmem(r0+#2)
	}
	{
		v5:4 = vshuff(v4,v5,r7)
		vmem(r2+#4) = v4.new
	}
	{
		vmem(r2+#5) = v5
	}
	{
		v6 = vmem(r1+#3)
	}
	{
		v7 = vmem(r0+#3)
	}
	{
		v7:6 = vshuff(v6,v7,r7)
		vmem(r2+#6) = v6.new
	}
	{
		vmem(r2+#7) = v7
	}
	{
		v8 = vmem(r1+#4)
	}
	{
		v9 = vmem(r0+#4)
	}
	{
		r3 = add(r2,#1280)
		v9:8 = vshuff(v8,v9,r7)
		vmem(r3+#0) = v8.new
	}
	{
		r4 = add(r2,#2176)
		vmem(r4+#0) = v9
	}
	{
		v10 = vmem(r1+#5)
	}
	{
		v11 = vmem(r0+#5)
	}
	{
		r3 = add(r2,#1536)
		v11:10 = vshuff(v10,v11,r7)
		vmem(r3+#0) = v10.new
	}
	{
		r6 = add(r2,#1664)
		vmem(r6+#0) = v11
	}
	{
		v12 = vmem(r1+#6)
	}
	{
		v13 = vmem(r0+#6)
	}
	{
		r3 = add(r2,#1792)
		v13:12 = vshuff(v12,v13,r7)
		vmem(r3+#0) = v12.new
	}
	{
		r6 = add(r2,#1920)
		vmem(r6+#0) = v13
	}
	{
		v14 = vmem(r1+#7)
	}
	{
		v15 = vmem(r0+#7)
	}
	{
		r3 = add(r0,#1024)
		v15:14 = vshuff(v14,v15,r7)
		vmem(r3+#0) = v14.new
	}
	{
		r6 = add(r1,#1152)
		vmem(r6+#0) = v15
	}
	{
		v16 = vmem(r5+#0)
	}
	{
		r3 = add(r2,#2048)
		v17 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1152)
		v17:16 = vshuff(v16,v17,r7)
		vmem(r3+#0) = v16.new
	}
	{
		r4 = add(r2,#2432)
		vmem(r4+#0) = v17
	}
	{
		r6 = add(r1,#1280)
		v18 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#2304)
		v19 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1280)
		v19:18 = vshuff(v18,v19,r7)
		vmem(r3+#0) = v18.new
	}
	{
		r4 = add(r2,#2688)
		vmem(r4+#0) = v19
	}
	{
		r6 = add(r1,#1408)
		v20 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#2560)
		v21 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1408)
		v21:20 = vshuff(v20,v21,r7)
		vmem(r3+#0) = v20.new
	}
	{
		r4 = add(r2,#2944)
		vmem(r4+#0) = v21
	}
	{
		r6 = add(r1,#1536)
		v22 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#2816)
		v23 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1536)
		v23:22 = vshuff(v22,v23,r7)
		vmem(r3+#0) = v22.new
	}
	{
		r4 = add(r2,#3200)
		vmem(r4+#0) = v23
	}
	{
		r6 = add(r1,#1664)
		v24 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#3072)
		v25 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1664)
		v25:24 = vshuff(v24,v25,r7)
		vmem(r3+#0) = v24.new
	}
	{
		r4 = add(r2,#3456)
		vmem(r4+#0) = v25
	}
	{
		r6 = add(r1,#1792)
		r1 = add(r1,#1920)
		v26 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#3328)
		v27 = vmem(r3+#0)
	}
	{
		r3 = add(r0,#1792)
		r0 = add(r0,#1920)
		v27:26 = vshuff(v26,v27,r7)
		vmem(r3+#0) = v26.new
	}
	{
		vmem(r4+#0) = v27
	}
	{
		r6 = add(r2,#3712)
		v28 = vmem(r6+#0)
	}
	{
		r3 = add(r2,#3584)
		v29 = vmem(r3+#0)
	}
	{
		v29:28 = vshuff(v28,v29,r7)
		vmem(r3+#0) = v28.new
	}
	{
		vmem(r6+#0) = v29
	}
	{
		r1 = add(r2,#3840)
		v30 = vmem(r1+#0)
	}
	{
		r0 = add(r2,#3968)
		v31 = vmem(r0+#0)
	}
	{
		v31:30 = vshuff(v30,v31,r7)
		vmem(r1+#0) = v30.new
	}
	{
		jumpr r31
		vmem(r0+#0) = v31
	}
.Lfunc_end10:
	.size	hexkl_cvt_zip_i16, .Lfunc_end10-hexkl_cvt_zip_i16
                                        // -- End function
	.globl	nntr_hvx_attn_q2_prefill        // -- Begin function nntr_hvx_attn_q2_prefill
	.falign
	.type	nntr_hvx_attn_q2_prefill,@function
nntr_hvx_attn_q2_prefill:               // @nntr_hvx_attn_q2_prefill
// %bb.0:                               // %entry
	{
		r6 = ##-2147449843
		memd(r29+#-16) = r17:16
		allocframe(#200)
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r1,r0)
		r16 = add(r6,#-32767)
		memd(r29+#184) = r19:18
		memd(r29+#176) = r21:20
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB11_17
		r17 = r3
		r1 = r2
	}
// %bb.1:                               // %if.end
	{
		r0 = add(r18,##409628)
	}
	{
		call hexkl_kv_q_get
		r21:20 = combine(r4,r5)
	}
	.falign
// %bb.2:                               // %if.end
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB11_17
		if (!p0.new) r7 = memw(r0+#24)
		if (!p0.new) r8 = memw(r29+#208)
	}
// %bb.3:                               // %if.end3
	{
		r2 = memw(r29+#220)
	}
	{
		r5:4 = mpyu(r8,r17)
		r13:12 = sxtw(r2)
	}
	{
		r3:2 = mpyu(r4,r7)
	}
	{
		r3 += mpyi(r7,r5)
	}
	{
		p1 = cmp.eq(r3:2,r13:12)
		if (!p1.new) jump:t .LBB11_13
		if (p1.new) r5 = memw(r29+#236)
	}
// %bb.4:                               // %lor.lhs.false
	{
		r4 = asl(r8,#1)
		if (!cmp.eq(r4.new,r5)) jump:nt .LBB11_13
	}
// %bb.5:                               // %lor.lhs.false
	{
		r5 = memw(r29+#228)
		if (!cmp.eq(r5.new,r4)) jump:nt .LBB11_13
	}
// %bb.6:                               // %lor.lhs.false
	{
		r19 = memw(r29+#252)
		if (!cmp.gt(r19.new,#8)) jump:nt .LBB11_13
	}
// %bb.7:                               // %lor.lhs.false
	{
		r4 = memw(r29+#244)
	}
	{
		r5:4 = sxtw(r4)
	}
	{
		p1 = cmp.eq(r3:2,r5:4)
		if (p1.new) r14 = add(r0,#0)
		if (!p1.new) jump:nt .LBB11_13
		if (p1.new) r2 = memw(r29+#240)
	}
// %bb.8:                               // %if.end29
	{
		r9 = mpyi(r7,r8)
		r6 = memw(r0+#20)
		memw(r29+#76) = #0

	} :mem_noshuf
	{
		r3 = add(r29,#44)
		r5 = add(r29,#80)
		memw(r29+#72) = #0
	}
	{
		r4 = memw(r29+#216)
		memw(r29+#28) = r6
	}
	{
		r2 = add(r29,#12)
		r6 = memw(r18+#0)
		memw(r29+#56) = r2
	}
	{
		r0 = r6
		r4 = memw(r18+##421404)
		memw(r29+#44) = r4
	}
	{
		r1 = memw(r18+#8)
		memw(r29+#12) = r17
	}
	{
		r12 = memw(r29+#232)
		memw(r29+#16) = r21
	}
	{
		r13 = memw(r29+#224)
		memw(r29+#20) = r20
	}
	{
		r6 = memw(r29+#212)
		memw(r29+#36) = r6.new
	}
	{
		memw(r29+#24) = r8
		memw(r29+#32) = r7
	}
	{
		memw(r29+#40) = #0
		memw(r29+#48) = r9
	}
	{
		memw(r29+#52) = r13
		memw(r29+#60) = r9
	}
	{
		call hexkl_attn_q2_prefill
		memw(r29+#64) = r12
		memw(r29+#68) = r14
	}
	.falign
// %bb.9:                               // %if.end29
	{
		r16 = r0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB11_18
		if (p1.new) r7:6 = memd(r29+#160)
	}
// %bb.10:                              // %do.body49
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB11_21
	}
// %bb.11:                              // %if.else53
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #405
	}
	{
		r3 = add(pc,##.L.str.7@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r16
	}
	.falign
// %bb.12:                              // %if.else53
	{
		jump .LBB11_17
	}
	.falign
.LBB11_13:                              // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB11_16
	}
// %bb.14:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #387
	}
	{
		r3 = add(pc,##.L.str.6@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.15:                              // %if.else
	{
		jump .LBB11_17
	}
	.falign
.LBB11_16:                              // %if.then27
	{
		r3 = add(pc,##.L.str.6@PCREL)
		call _HAP_debug_v2
		r2 = #387
	}
	.falign
.LBB11_17:                              // %cleanup93
	{
		r0 = r16
		r17:16 = memd(r29+#192)
		r19:18 = memd(r29+#184)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#176)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB11_18:                              // %if.end57
	{
		p0 = cmp.gtu(r19,#9)
		r8 = ##549755813
		r13:12 = memd(r29+#80)
	}
	{
		r3:2 = combine(r6,r7)
		r6 = ##-481036337
		r11:10 = memd(r29+#112)
	}
	{
		r5:4 = vlsrw(r3:2,#3)
		r2 = memw(r29+#248)
		r3 = memw(r29+#168)
	}
	{
		r5 = insert(r7,#3,#29)
		r15:14 = memd(r29+#88)
	}
	{
		memw(r2+#0) = r12
		memw(r2+#4) = r14
	}
	{
		r1:0 = mpyu(r5,r6)
		r15:14 = mpyu(r5,r8)
		memw(r2+#16) = r10
		memw(r2+#28) = r3
	}
	{
		r1:0 = combine(#0,r1)
	}
	{
		r13:12 = combine(r1,r0)
		r0 = r14
	}
	{
		r13:12 += mpyu(r4,r6)
		r7:6 = memd(r29+#96)
	}
	{
		r7:6 = memd(r29+#104)
		memw(r2+#8) = r6
	}
	{
		r7:6 = add(r13:12,r1:0)
		memw(r2+#12) = r6
	}
	{
		r0 = r7
	}
	{
		r7:6 = combine(r1,r0)
		r0 = r15
	}
	{
		r7:6 += mpyu(r4,r8)
		r5:4 = memd(r29+#120)
	}
	{
		r1:0 = add(r7:6,r1:0)
		r5:4 = memd(r29+#152)
		memw(r2+#20) = r4
	}
	{
		r1:0 = lsr(r1:0,#4)
		memw(r2+#24) = r4
	}
	{
		if (!p0) jump:nt .LBB11_17
		if (p0) r1:0 = memd(r29+#128)
		memw(r2+#32) = r0
	}
// %bb.19:                              // %if.end79
	{
		p1 = cmp.gtu(r19,#11)
		if (p1.new) r1:0 = memd(r29+#136)
		memw(r2+#36) = r0
	}
	{
		if (!p1) jump:nt .LBB11_17
	}
// %bb.20:                              // %if.then82
	{
		r1:0 = memd(r29+#144)
		memw(r2+#40) = r0
	}
	{
		jump .LBB11_17
		memw(r2+#44) = r0
	}
	.falign
.LBB11_21:                              // %if.then52
	{
		r3 = add(pc,##.L.str.7@PCREL)
		r2 = #405
		memw(r29+#0) = r16
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.22:                              // %if.then52
	{
		jump .LBB11_17
	}
.Lfunc_end11:
	.size	nntr_hvx_attn_q2_prefill, .Lfunc_end11-nntr_hvx_attn_q2_prefill
                                        // -- End function
	.globl	nntr_hvx_probe_hvx_rate         // -- Begin function nntr_hvx_probe_hvx_rate
	.falign
	.type	nntr_hvx_probe_hvx_rate,@function
nntr_hvx_probe_hvx_rate:                // @nntr_hvx_probe_hvx_rate
// %bb.0:                               // %entry
	{
		r7:6 = combine(r1,r0)
		r0 = ##-2147482610
	}
	{
		p0 = cmp.eq(r6,#0)
		if (p0.new) jumpr:nt r31
	}
.LBB12_1:                               // %entry
	{
		p1 = cmp.eq(r2,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB12_2:                               // %entry
	{
		if (p0.new) r0 = add(r2,#0)
		p0 = cmp.gt(r4,#11); if (!p0.new) jump:nt .LBB12_6
	}
// %bb.3:                               // %if.end
	{
		r16 = r3
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r17 = add(r29,#0)
		r4 = memw(r6+#0)
	}
	{
		r3 = r17
		r1 = add(r4,##937984)
	}
	{
		call hvx_softmax_q_rate
		r2 = add(r4,##131072)
	}
	.falign
// %bb.4:                               // %if.end
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r1:0 = combine(r17,r16)
		r2 = #48
	}
	.falign
// %bb.5:                               // %if.end
	{
		r0 = #0
		r17:16 = memd(r29+#48)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB12_6:                               // %cleanup
	{
		jumpr r31
	}
.Lfunc_end12:
	.size	nntr_hvx_probe_hvx_rate, .Lfunc_end12-nntr_hvx_probe_hvx_rate
                                        // -- End function
	.globl	nntr_hvx_attn_q2_step           // -- Begin function nntr_hvx_attn_q2_step
	.falign
	.type	nntr_hvx_attn_q2_step,@function
nntr_hvx_attn_q2_step:                  // @nntr_hvx_attn_q2_step
// %bb.0:                               // %entry
	{
		allocframe(r29,#80):raw
	}
	{
		r6 = memw(r29+#120)
	}
	{
		r7 = memw(r29+#144)
		if (!cmp.eq(r7.new,r6)) jump:t .LBB13_3
	}
// %bb.1:                               // %if.end
	{
		memw(r29+#64) = r6
		memw(r29+#40) = r6
	}
	{
		r6 = memw(r29+#148)
		memw(r29+#68) = r6.new
	}
	{
		r6 = memw(r29+#140)
		memw(r29+#60) = r6.new
	}
	{
		r6 = memw(r29+#136)
		memw(r29+#56) = r6.new
	}
	{
		r6 = memw(r29+#132)
		memw(r29+#52) = r6.new
	}
	{
		r7 = memw(r29+#152)
		memw(r29+#72) = r7.new
	}
	{
		r6 = memw(r29+#128)
		memw(r29+#48) = r6.new
	}
	{
		r6 = memw(r29+#124)
		memw(r29+#44) = r6.new
	}
	{
		r6 = memw(r29+#116)
		memw(r29+#28) = r6.new
	}
	{
		r6 = memw(r29+#112)
		memw(r29+#24) = r6.new
	}
	{
		r6 = memw(r29+#108)
		memw(r29+#20) = r6.new
	}
	{
		r6 = memw(r29+#104)
		memw(r29+#16) = r6.new
	}
	{
		r6 = memw(r29+#100)
		memw(r29+#12) = r6.new
	}
	{
		r6 = memw(r29+#96)
		memw(r29+#8) = r6.new
	}
	{
		r6 = memw(r29+#92)
		memw(r29+#4) = r6.new
	}
	{
		r6 = memw(r29+#88)
		memw(r29+#0) = r6.new
	}
	{
		call attn_q2_step_impl
		memw(r29+#36) = #0
		memw(r29+#32) = #0
	}
	.falign
// %bb.2:                               // %if.end
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB13_3:                               // %return
	{
		r0 = ##-2147482610
		dealloc_return
	}
.Lfunc_end13:
	.size	nntr_hvx_attn_q2_step, .Lfunc_end13-nntr_hvx_attn_q2_step
                                        // -- End function
	.falign
	.type	attn_q2_step_impl,@function     // -- Begin function attn_q2_step_impl
attn_q2_step_impl:                      // @attn_q2_step_impl
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(r29,#264):raw
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r1,r0)
		memd(r29+#248) = r19:18
		memd(r29+#224) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r24 = ##-2147449843
		p0 = cmp.eq(r18,#0)
		memd(r29+#216) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r16 = add(r24,#-32767)
		memd(r29+#240) = r21:20
		memd(r29+#232) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r21 = add(r18,##409628)
		if (p0) jump:nt .LBB14_21
	}
// %bb.1:                               // %if.end
	{
		r1:0 = combine(r2,r21)
		r22 = r5
		r19 = r3
	}
	{
		call hexkl_kv_q_get
		r17 = r4
		r20 = r2
	}
	.falign
// %bb.2:                               // %if.end
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB14_14
		if (!p1.new) r25 = memw(r29+##292)
	}
// %bb.3:                               // %lor.lhs.false
	{
		r3 = memw(r29+#328)
	}
	{
		r2 = asl(r25,#1)
		if (!cmp.eq(r2.new,r3)) jump:nt .LBB14_14
	}
// %bb.4:                               // %lor.lhs.false
	{
		r3 = memw(r29+#320)
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB14_14
	}
// %bb.5:                               // %lor.lhs.false
	{
		r23 = memw(r29+#344)
		if (!cmp.gt(r23.new,#7)) jump:nt .LBB14_14
	}
// %bb.6:                               // %lor.lhs.false
	{
		r26 = memw(r29+#288)
	}
	{
		r2 = memw(r0+#16)
		if (cmp.gtu(r26,r2.new)) jump:nt .LBB14_14
	}
// %bb.7:                               // %if.end18
	{
		r3:2 = combine(#0,#0)
		memw(r29+#112) = #0
	}
	{
		memd(r29+#104) = r3:2
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		if (p1.new) r27 = add(r0,#0)
		p1 = cmp.gt(r22,#-1); if (!p1.new) jump:nt .LBB14_11
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.8:                               // %if.end18
	{
		r2 = memw(r29+#276)
		if (!cmp.eq(r2.new,r22)) jump:nt .LBB14_11
	}
// %bb.9:                               // %lor.lhs.false26
	{
		r2 = memw(r0+#20)
		r3 = memw(r0+#24)
	}
	{
		r16 = mpyi(r3,r2)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r22)
	}
	.falign
// %bb.10:                              // %lor.lhs.false26
	{
		r2 = r22
	}
	{
		r2 -= mpyi(r0,r16)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_22
	}
	.falign
.LBB14_11:                              // %do.body30
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_19
	}
// %bb.12:                              // %if.else34
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #466
	}
	{
		r3 = add(pc,##.L.str.26@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.13:                              // %if.else34
	{
		r16 = add(r24,#-32767)
		jump .LBB14_21
	}
	.falign
.LBB14_14:                              // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_17
	}
// %bb.15:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #457
	}
	{
		r3 = add(pc,##.L.str.25@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.16:                              // %if.else
	{
		jump .LBB14_21
	}
	.falign
.LBB14_17:                              // %if.then16
	{
		r3 = add(pc,##.L.str.25@PCREL)
		call _HAP_debug_v2
		r2 = #457
	}
	.falign
// %bb.18:                              // %if.then16
	{
		jump .LBB14_21
	}
	.falign
.LBB14_19:                              // %if.then33
	{
		r3 = add(pc,##.L.str.26@PCREL)
		call _HAP_debug_v2
		r2 = #466
	}
	.falign
// %bb.20:                              // %if.then33
	{
		r16 = add(r24,#-32767)
	}
	.falign
.LBB14_21:                              // %cleanup151
	{
		r0 = r16
		r17:16 = memd(r29+#256)
		r19:18 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#240)
		r23:22 = memd(r29+#232)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#224)
		r27:26 = memd(r29+#216)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB14_22:                              // %if.end38
	{
		r4 = r27
		p1 = cmp.eq(r22,#0)
		r2 = add(r18,##421404)
	}
	{
		if (p1) jump:nt .LBB14_29
		memw(r29+#20) = r2
	}                                       // 4-byte Folded Spill
// %bb.23:                              // %if.then41
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r22)
		r16 = memw(r29+#272)
		memw(r29+#24) = r0
	}
	.falign
// %bb.24:                              // %if.then41
	{
		r2 = memw(r18+#0)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#104)
		r3 = r0
		r4 = memw(r3+#0)
		memw(r29+#0) = r2

	} :mem_noshuf
	{
		r1:0 = combine(r20,r21)
		r2 = r19
		memw(r29+#4) = r4
		memw(r29+#8) = r2
	}
	{
		call hexkl_kv_q_append_pool
		r5:4 = combine(r16,r17)
	}
	.falign
// %bb.25:                              // %if.then41
	{
		r4 = r27
		r16 = r0
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r16,#0); if (p0.new) jump:nt .LBB14_29
	}
// %bb.26:                              // %do.body47
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_39
	}
// %bb.27:                              // %if.else51
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #474
	}
	{
		r3 = add(pc,##.L.str.27@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r16
	}
	.falign
// %bb.28:                              // %if.else51
	{
		jump .LBB14_21
	}
	.falign
.LBB14_29:                              // %if.end56
	{
		r3 = memw(r29+#312)
		r14 = memw(r29+#20)
	}
	{
		r6 = memw(r29+#284)
		r5 = memw(r29+#296)
	}
	{
		r7 = memw(r29+#280)
	}
	//# InlineAsm Start
	{
		r21:20 = c31:30
	}
	//# InlineAsm End
	{
		r13:12 = mpyu(r25,r7)
		r9:8 = sxtw(r3)
		r2 = memw(r4+#24)
		memw(r29+#28) = r7
	}
	{
		r3 = memw(r4+#20)
		memw(r29+#32) = r6
	}
	{
		r7:6 = mpyu(r12,r2)
		memw(r29+#48) = r2
		memw(r29+#36) = r26
	}
	{
		r7 += mpyi(r2,r13)
		memw(r29+#40) = r25
		memw(r29+#44) = r3
	}
	{
		p0 = cmp.eq(r7:6,r9:8)
		if (!p0.new) jump:nt .LBB14_36
		memw(r29+#52) = r5
		memw(r29+#56) = #0
	}
// %bb.30:                              // %if.end56
	{
		r3 = memw(r29+#336)
	}
	{
		r9:8 = sxtw(r3)
	}
	{
		p1 = cmp.eq(r7:6,r9:8)
		if (p1.new) r11 = add(r4,#0)
		if (p1.new) r17 = add(r0,#0)
		if (!p1.new) jump:nt .LBB14_36
	}
// %bb.31:                              // %if.end89
	{
		r6 = mpyi(r2,r25)
		r3 = memw(r29+#332)
		r9 = memw(r29+#308)
	}
	{
		r3 = add(r29,#60)
		r2 = add(r29,#28)
		memw(r29+#72) = r3
	}
	{
		r5 = add(r29,#120)
		r0 = memw(r18+#0)
		memw(r29+#92) = r9
	}
	{
		r1 = memw(r18+#8)
		memw(r29+#64) = r6
	}
	{
		r4 = memw(r14+#0)
		memw(r29+#76) = r6
	}
	{
		r7 = memw(r29+#324)
		memw(r29+#80) = r7.new
	}
	{
		r8 = memw(r29+#316)
		memw(r29+#68) = r8.new
	}
	{
		r12 = memw(r29+#304)
		memw(r29+#88) = r12.new
	}
	{
		r15 = memw(r29+#300)
		memw(r29+#60) = r15.new
	}
	{
		call hexkl_attn_q2_prefill
		memw(r29+#84) = r11
	}
	.falign
// %bb.32:                              // %if.end89
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB14_43
		r2 = #10
		r16 = r0
	}
// %bb.33:                              // %do.body105
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_45
	}
// %bb.34:                              // %if.else109
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #505
	}
	{
		r3 = add(pc,##.L.str.29@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r16
	}
	.falign
// %bb.35:                              // %if.else109
	{
		jump .LBB14_21
	}
	.falign
.LBB14_36:                              // %do.body81
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB14_41
	}
// %bb.37:                              // %if.else85
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #484
	}
	{
		r3 = add(pc,##.L.str.28@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.38:                              // %if.else85
	{
		r16 = add(r24,#-32767)
		jump .LBB14_21
	}
	.falign
.LBB14_39:                              // %if.then50
	{
		r3 = add(pc,##.L.str.27@PCREL)
		r2 = #474
		memw(r29+#0) = r16
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.40:                              // %if.then50
	{
		jump .LBB14_21
	}
	.falign
.LBB14_41:                              // %if.then84
	{
		r3 = add(pc,##.L.str.28@PCREL)
		call _HAP_debug_v2
		r2 = #484
	}
	.falign
// %bb.42:                              // %if.then84
	{
		r16 = add(r24,#-32767)
		jump .LBB14_21
	}
	.falign
.LBB14_43:                              // %if.end113
	{
		r6 = ##-1431622999
		r7 = #10
		r9:8 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = add(r6,#-32766)
	}
	{
		r5:4 = mpyu(r8,r2)
		r7:6 = mpyu(r20,r7)
		r2 = add(r6,#-32767)
	}
	{
		r5 += mpyi(r9,#10)
		r7 += mpyi(r21,#10)
	}
	{
		r13:12 = mpyu(r4,r3)
		r11:10 = mpyu(r6,r3)
	}
	{
		r13:12 = mpyu(r4,r2)
		r19:18 = mpyu(r6,r2)
		r1:0 = combine(#0,r13)
		r9:8 = combine(#0,r11)
	}
	{
		r15:14 = combine(r1,r0)
		r11:10 = combine(r9,r8)
		r0 = r12
		r8 = r18
	}
	{
		r15:14 += mpyu(r5,r3)
		r11:10 += mpyu(r7,r3)
		r4 = memw(r29+#340)
	}
	{
		r15:14 = add(r15:14,r1:0)
		r11:10 = add(r11:10,r9:8)
	}
	{
		r0 = r15
		r8 = r11
	}
	{
		r15:14 = combine(r1,r0)
		r11:10 = combine(r9,r8)
		r0 = r13
		r8 = r19
	}
	{
		r11:10 += mpyu(r7,r2)
		r15:14 += mpyu(r5,r2)
	}
	{
		r1:0 = add(r15:14,r1:0)
		r7:6 = add(r11:10,r9:8)
	}
	{
		r1:0 = lsr(r1:0,#7)
		r7:6 = lsr(r7:6,#7)
	}
	//# InlineAsm Start
	{
		r9:8 = c31:30
	}
	//# InlineAsm End
	{
		r15:14 = sub(r7:6,r1:0)
		p1 = cmp.gtu(r23,#11)
		r5 = #10
		memw(r4+#8) = #0
	}
	{
		r15:14 = mpyu(r8,r5)
		memw(r4+#0) = r14
		memw(r4+#28) = r17
	}
	{
		r15 += mpyi(r9,#10)
	}
	{
		r13:12 = mpyu(r14,r3)
		r11:10 = mpyu(r14,r2)
	}
	{
		r13:12 = combine(#0,r13)
	}
	{
		r9:8 = combine(r13,r12)
		r12 = r10
	}
	{
		r9:8 += mpyu(r15,r3)
	}
	{
		r9:8 = add(r9:8,r13:12)
	}
	{
		r12 = r9
	}
	{
		r9:8 = combine(r13,r12)
		r12 = r11
	}
	{
		r9:8 += mpyu(r15,r2)
	}
	{
		r3:2 = add(r9:8,r13:12)
	}
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r7:6 = sub(r3:2,r7:6)
		r3:2 = sub(r3:2,r1:0)
		r0 = memw(r29+#104)
		memw(r4+#16) = r0.new
	}
	{
		r1 = memw(r29+#108)
		memw(r4+#4) = r6
	}
	{
		r0 = memw(r29+#112)
		memw(r4+#12) = r2
	}
	{
		if (!p1) jump:nt .LBB14_21
		memw(r4+#20) = r1
		memw(r4+#24) = r0
	}
// %bb.44:                              // %if.then130
	{
		r3:2 = memd(r29+#144)
		r1:0 = memd(r29+#136)
	}
	{
		r3:2 = memd(r29+#152)
		memw(r4+#36) = r2
	}
	{
		r3:2 = memd(r29+#168)
		memw(r4+#40) = r2
	}
	{
		jump .LBB14_21
		memw(r4+#32) = r0
		memw(r4+#44) = r2
	}
	.falign
.LBB14_45:                              // %if.then108
	{
		r3 = add(pc,##.L.str.29@PCREL)
		r2 = #505
		memw(r29+#0) = r16
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.46:                              // %if.then108
	{
		jump .LBB14_21
	}
.Lfunc_end14:
	.size	attn_q2_step_impl, .Lfunc_end14-attn_q2_step_impl
                                        // -- End function
	.globl	nntr_hvx_attn_q2_step_fq        // -- Begin function nntr_hvx_attn_q2_step_fq
	.falign
	.type	nntr_hvx_attn_q2_step_fq,@function
nntr_hvx_attn_q2_step_fq:               // @nntr_hvx_attn_q2_step_fq
// %bb.0:                               // %entry
	{
		allocframe(r29,#80):raw
	}
	{
		r6 = memw(r29+#128)
	}
	{
		r7 = memw(r29+#108)
		if (!cmp.eq(r7.new,r6)) jump:nt .LBB15_4
	}
// %bb.1:                               // %entry
	{
		r7 = memw(r29+#120)
	}
	{
		r8 = memw(r29+#152)
		if (!cmp.eq(r8.new,r7)) jump:nt .LBB15_4
	}
// %bb.2:                               // %if.end4
	{
		r6 = memw(r29+#156)
		memw(r29+#20) = r6
	}
	{
		r6 = memw(r29+#148)
		memw(r29+#68) = r6
	}
	{
		r6 = memw(r29+#144)
		memw(r29+#60) = r6
	}
	{
		r6 = memw(r29+#140)
		memw(r29+#56) = r6
	}
	{
		r8 = memw(r29+#160)
		memw(r29+#52) = r6
	}
	{
		r6 = memw(r29+#136)
		memw(r29+#48) = r6.new
	}
	{
		r6 = memw(r29+#132)
		memw(r29+#44) = r6.new
	}
	{
		r6 = memw(r29+#124)
		memw(r29+#36) = r6.new
	}
	{
		r6 = memw(r29+#116)
		memw(r29+#32) = r6.new
	}
	{
		r6 = memw(r29+#112)
		memw(r29+#24) = r6.new
	}
	{
		r6 = memw(r29+#104)
		memw(r29+#16) = r6.new
	}
	{
		r6 = memw(r29+#100)
		memw(r29+#12) = r6.new
	}
	{
		r6 = memw(r29+#96)
		memw(r29+#8) = r6.new
	}
	{
		r6 = memw(r29+#92)
		memw(r29+#4) = r6.new
	}
	{
		r6 = memw(r29+#88)
		memw(r29+#72) = r8
	}
	{
		memw(r29+#64) = r7
		memw(r29+#40) = r7
	}
	{
		call attn_q2_step_impl
		memw(r29+#0) = r6
		memw(r29+#28) = #0
	}
	.falign
// %bb.3:                               // %if.end4
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB15_4:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_7
	}
// %bb.5:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #551
	}
	{
		r3 = add(pc,##.L.str.8@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.6:                               // %if.else
	{
		r0 = ##-2147482610
		dealloc_return
	}
	.falign
.LBB15_7:                               // %if.then3
	{
		r3 = add(pc,##.L.str.8@PCREL)
		call _HAP_debug_v2
		r2 = #551
	}
	.falign
// %bb.8:                               // %if.then3
	{
		r0 = ##-2147482610
		dealloc_return
	}
.Lfunc_end15:
	.size	nntr_hvx_attn_q2_step_fq, .Lfunc_end15-nntr_hvx_attn_q2_step_fq
                                        // -- End function
	.globl	nntr_hvx_attn_q2_step_fqc       // -- Begin function nntr_hvx_attn_q2_step_fqc
	.falign
	.type	nntr_hvx_attn_q2_step_fqc,@function
nntr_hvx_attn_q2_step_fqc:              // @nntr_hvx_attn_q2_step_fqc
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#592):raw
	}                                       // 8-byte Folded Spill
	{
		r27 = ##-2147483648
		memd(r29+#544) = r27:26
		memd(r29+#576) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19 = add(r27,#1038)
		if (!p0) r20 = add(r5,#0)
		memd(r29+#568) = r21:20
		memd(r29+#560) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r21 = add(r0,##409628)
		if (p0) jump:nt .LBB16_11
		memd(r29+#552) = r25:24
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		memd(r29+#264) = r1:0
		memw(r29+#88) = r2
	}                                       // 8-byte Folded Spill
	{
		r1:0 = combine(r2,r21)
		memw(r29+#92) = r3
		memw(r29+#84) = r4
	}                                       // 4-byte Folded Spill
	{
		call hexkl_kv_q_get
		r22 = memw(r29+#620)
	}
	.falign
// %bb.2:                               // %if.end
	{
		p3 = cmp.eq(r22,#0)
		if (p3.new) jump:nt .LBB16_7
	}
// %bb.3:                               // %if.end
	{
		if (!p0.new) r16 = add(r0,#0)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB16_7
	}
// %bb.4:                               // %lor.lhs.false3
	{
		r25 = memw(r0+#20)
		if (cmp.eq(r25.new,#0)) jump:nt .LBB16_7
	}
// %bb.5:                               // %lor.lhs.false6
	{
		call __hexagon_udivsi3
		r1:0 = combine(r25,r22)
	}
	.falign
// %bb.6:                               // %lor.lhs.false6
	{
		r3 = r22
	}
	{
		r3 -= mpyi(r0,r25)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB16_12
	}
	.falign
.LBB16_7:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB16_10
	}
// %bb.8:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #673
	}
	{
		r3 = add(pc,##.L.str.9@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.9:                               // %if.else
	{
		jump .LBB16_11
	}
	.falign
.LBB16_10:                              // %if.then31
	{
		r3 = add(pc,##.L.str.9@PCREL)
		call _HAP_debug_v2
		r2 = #673
	}
	.falign
.LBB16_11:                              // %cleanup322
	{
		r0 = r19
		r17:16 = memd(r29+#584)
		r19:18 = memd(r29+#576)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#568)
		r23:22 = memd(r29+#560)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#552)
		r27:26 = memd(r29+#544)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB16_12:                              // %lor.lhs.false10
	{
		r3 = memw(r29+#604)
		if (!cmp.eq(r3.new,r20)) jump:nt .LBB16_7
	}
// %bb.13:                              // %lor.lhs.false10
	{
		r3 = memw(r29+#648)
	}
	{
		r23 = memw(r29+#632)
		if (!cmp.eq(r23.new,r3)) jump:nt .LBB16_7
	}
// %bb.14:                              // %lor.lhs.false10
	{
		r18 = memw(r16+#24)
	}
	{
		r24 = mpyi(r18,r25)
		r2 = and(r18,#63)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB16_7
	}
// %bb.15:                              // %lor.lhs.false20
	{
		r17 = asl(r22,#2)
		r16 = r0
		r2 = r24
		r3 = memw(r29+#640)
	}
	{
		r2 += add(r25,r17)
		if (!cmp.eq(r2.new,r3)) jump:t .LBB16_7
	}
// %bb.16:                              // %if.end33
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r20)
	}
	.falign
// %bb.17:                              // %if.end33
	{
		r26 = r0
		r1:0 = memd(r29+#264)
	}                                       // 8-byte Folded Reload
	{
		call hvx_worker_pool_workers
		r0 = memw(r0+##421404)
	}
	.falign
// %bb.18:                              // %if.end33
	{
		r2 = mpyi(r26,r24)
		if (!cmp.eq(r2.new,r20)) jump:nt .LBB16_11
	}
// %bb.19:                              // %if.end33
	{
		r3 = add(r0,#1)
		if (cmp.gtu(r3.new,#16)) jump:nt .LBB16_11
	}
// %bb.20:                              // %if.end46
	{
		memw(r29+#96) = r26
		memw(r29+#112) = r18
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#124) = r16
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r19:18 = c31:30
	}
	//# InlineAsm End
	{
		r2 = mpyi(r24,r3)
		r16 = r3
	}
	{
		call malloc
		r0 = asl(r2,#1)
	}
	.falign
// %bb.21:                              // %if.end46
	{
		r2 = mpyi(r25,r16)
		r26 = r0
	}
	{
		call malloc
		r0 = asl(r2,#1)
	}
	.falign
// %bb.22:                              // %if.end46
	{
		r16 = mpyi(r16,r22)
		memw(r29+#116) = r16
		memw(r29+#128) = r0
	}                                       // 4-byte Folded Spill
	{
		call malloc
		r0 = asl(r16,#3)
	}
	.falign
// %bb.23:                              // %if.end46
	{
		p1 = cmp.gtu(r22,#64)
		r13 = r0
		if (p1.new) jump:nt .LBB16_83
	}
// %bb.24:                              // %if.end46
	{
		p3 = cmp.eq(r26,#0)
		if (p3.new) jump:nt .LBB16_83
	}
// %bb.25:                              // %if.end46
	{
		r2 = memw(r29+#128)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB16_83
	}                                       // 4-byte Folded Reload
// %bb.26:                              // %if.end46
	{
		r3 = #10
		p2 = cmp.eq(r13,#0)
		if (p2.new) jump:nt .LBB16_83
		if (!p2.new) r1:0 = memd(r29+#264)
	}                                       // 8-byte Folded Reload
// %bb.27:                              // %if.end70
	{
		r2 = memw(r29+#656)
		memw(r29+#164) = r2.new
	}
	{
		r2 = memw(r29+#652)
		memw(r29+#160) = r2.new
	}
	{
		r6 = memw(r29+#624)
		memw(r29+#220) = r24
	}
	{
		r1:0 = mpyu(r18,r3)
		r2 = add(r0,##421404)
		r4 = memw(r29+#644)
	}
	{
		r3 = ##-1431622999
		memw(r29+#172) = r6
		memw(r29+#168) = r4
	}                                       // 4-byte Folded Spill
	{
		r1 += mpyi(r19,#10)
		r8 = add(r3,#-32766)
		r12 = add(r3,#-32767)
		r14 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = mpyu(r0,r8)
		r11:10 = mpyu(r0,r12)
		r3 = memw(r29+#616)
		memw(r29+#204) = r12
	}
	{
		r5:4 = combine(#0,r7)
		r3 = memw(r29+#612)
		memw(r29+#176) = r3
	}
	{
		r7:6 = combine(r5,r4)
		r4 = r10
		r18 = memw(r29+#636)
		memw(r29+#180) = r3
	}
	{
		r7:6 += mpyu(r1,r8)
		r19 = addasl(r18,r25,#2)
		r3 = memw(r29+#84)
		memw(r29+#208) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r7:6 = add(r7:6,r5:4)
		r3 = memw(r29+#600)
		memw(r29+#200) = r8
	}
	{
		r4 = r7
		memw(r29+#184) = r3
		memw(r29+#212) = r3
	}                                       // 4-byte Folded Spill
	{
		r7:6 = combine(r5,r4)
		r4 = r11
		memw(r29+#216) = r14
		memw(r29+#224) = r25
	}
	{
		r7:6 += mpyu(r1,r12)
		r12 = memw(r29+#112)
		memw(r29+#240) = r22
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r19,r24,#2)
		r1:0 = add(r7:6,r5:4)
		r3 = memw(r29+#628)
		r4 = memw(r29+#608)
	}
	{
		r3 = mpyi(r12,r22)
		r1:0 = lsr(r1:0,#7)
		memw(r29+#188) = r3
		memw(r29+#232) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = maxu(r14,r4)
		memw(r29+#244) = r3
		memw(r29+#236) = r4
	}
	{
		r4 = addasl(r13,r16,#2)
		memw(r29+#192) = r4
		memd(r29+#272) = r1:0
	}                                       // 4-byte Folded Spill
	{
		r1 = add(pc,##q2c_worker@PCREL)
		r2 = add(r29,#208)
		r0 = memw(r2+#0)
	}
	{
		r4 = asl(r22,#1)
		memw(r29+#260) = r4
		memw(r29+#228) = r12
	}
	{
		r4 = addasl(r5,r22,#3)
		r16 = memw(r29+#128)
		memw(r29+#196) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#248) = r26
		memw(r29+#252) = r16
	}
	{
		memw(r29+#100) = r5
		memw(r29+#104) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#148) = r13
		memw(r29+#256) = r13
	}                                       // 4-byte Folded Spill
	{
		call hvx_worker_pool_run
	}
	.falign
// %bb.28:                              // %if.end70
	{
		r2 = asl(r25,#1)
		r3 = #31
		r5:4 = combine(r18,r16)
		r14 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		loop1(.LBB16_29,r25)
		p0 = cmp.eq(r14,#0)
		memw(r29+#152) = r18
	}                                       // 4-byte Folded Spill
	{
		r6 = p0
		memw(r29+#96) = r6.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB16_29:                              // Block address taken
                                        // %for.cond87.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB16_31 Depth 2
	{
		r6 = #0
		if (p0) jump:nt .LBB16_39
	}
// %bb.30:                              //   in Loop: Header=BB16_29 Depth=1
	{
		loop0(.LBB16_31,r14)
		r7:6 = combine(#0,r4)
	}
	.balign 32
.LBB16_31:                              // Block address taken
                                        // %for.body91
                                        //   Parent Loop BB16_29 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r7 = zxth(r7)
		r6 = add(r6,r2)
		r8 = memuh(r6+#0)
	}
	{
		r7 = maxu(r8,r7)
		nop
	} :endloop0
// %bb.32:                              // %for.cond.cleanup90
                                        //   in Loop: Header=BB16_29 Depth=1
	{
		r9 = extractu(r7,#10,#0)
		r8 = extractu(r7,#5,#10)
		r6 = ##-2147483648
	}
	{
		r6 &= asl(r7,#16)
		p1 = cmp.eq(r8,#31)
		if (!p1.new) jump:t .LBB16_34
	}
// %bb.33:                              //   in Loop: Header=BB16_29 Depth=1
	{
		r6 |= asl(r7,#13)
	}
	{
		r6 = or(r6,##2139095040)
		jump .LBB16_39
	}
	.falign
.LBB16_34:                              // %for.cond.cleanup90
                                        //   in Loop: Header=BB16_29 Depth=1
	{
		p3 = cmp.eq(r8,#0)
		if (p3.new) jump:t .LBB16_36
	}
// %bb.35:                              //   in Loop: Header=BB16_29 Depth=1
	{
		r7 = asl(r8,#23)
	}
	{
		r7 |= asl(r9,#13)
	}
	{
		r6 = add(r7,add(r6,##939524096))
		jump .LBB16_39
	}
	.falign
.LBB16_36:                              // %if.then.i
                                        //   in Loop: Header=BB16_29 Depth=1
	{
		r8 = cl0(r9)
		p0 = cmp.eq(r9,#0)
		if (p0.new) jump:nt .LBB16_38
		if (p0.new) r7 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
// %bb.37:                              // %while.body.preheader.i
                                        //   in Loop: Header=BB16_29 Depth=1
	{
		r9 = xor(r8,r3)
	}
	{
		r9 = sub(#9,r9)
	}
	{
		r7 = asl(r7,r9)
	}
	{
		r7 = and(##8372224,asl(r7,#14))
	}
	{
		r7 -= asl(r8,#23)
	}
	{
		r6 = add(r7,add(r6,##1124073472))
		r7 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		p0 = r7
		jump .LBB16_39
	}
	.falign
.LBB16_38:                              //   in Loop: Header=BB16_29 Depth=1
	{
		p0 = r7
	}
	.falign
.LBB16_39:                              // %hexkl_kv_q_hf_to_f32.exit
                                        //   in Loop: Header=BB16_29 Depth=1
	{
		r4 = add(r4,#2)
		nop
		memw(r5++#4) = r6
	} :endloop1
// %bb.40:                              // %for.cond113.preheader
	{
		r5:4 = combine(r19,r26)
		r2 = #1
		r3 = #31
	}
	{
		r12 = maxu(r24,r2)
		r2 = asl(r24,#1)
	}
	{
		loop1(.LBB16_41,r12)
	}
	.falign
.LBB16_41:                              // Block address taken
                                        // %for.cond120.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB16_43 Depth 2
	{
		r6 = #0
		if (p0) jump:nt .LBB16_50
	}
// %bb.42:                              //   in Loop: Header=BB16_41 Depth=1
	{
		loop0(.LBB16_43,r14)
		r7:6 = combine(#0,r4)
	}
	.balign 32
.LBB16_43:                              // Block address taken
                                        // %for.body124
                                        //   Parent Loop BB16_41 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r7 = zxth(r7)
		r6 = add(r6,r2)
		r8 = memuh(r6+#0)
	}
	{
		r7 = maxu(r8,r7)
		nop
	} :endloop0
// %bb.44:                              // %for.cond.cleanup123
                                        //   in Loop: Header=BB16_41 Depth=1
	{
		r9 = extractu(r7,#10,#0)
		r8 = extractu(r7,#5,#10)
		r6 = ##-2147483648
	}
	{
		r6 &= asl(r7,#16)
		p2 = cmp.eq(r8,#31)
		if (!p2.new) jump:t .LBB16_46
	}
// %bb.45:                              //   in Loop: Header=BB16_41 Depth=1
	{
		r6 |= asl(r7,#13)
	}
	{
		r6 = or(r6,##2139095040)
		jump .LBB16_50
	}
	.falign
.LBB16_46:                              // %for.cond.cleanup123
                                        //   in Loop: Header=BB16_41 Depth=1
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:t .LBB16_48
	}
// %bb.47:                              //   in Loop: Header=BB16_41 Depth=1
	{
		r7 = asl(r8,#23)
	}
	{
		r7 |= asl(r9,#13)
	}
	{
		r6 = add(r7,add(r6,##939524096))
		jump .LBB16_50
	}
	.falign
.LBB16_48:                              // %if.then.i513
                                        //   in Loop: Header=BB16_41 Depth=1
	{
		r8 = cl0(r9)
		p3 = cmp.eq(r9,#0)
		if (p3.new) jump:nt .LBB16_50
	}
// %bb.49:                              // %while.body.preheader.i515
                                        //   in Loop: Header=BB16_41 Depth=1
	{
		r9 = xor(r8,r3)
	}
	{
		r9 = sub(#9,r9)
	}
	{
		r7 = asl(r7,r9)
	}
	{
		r7 = and(##8372224,asl(r7,#14))
	}
	{
		r7 -= asl(r8,#23)
	}
	{
		r6 = add(r7,add(r6,##1124073472))
	}
	.falign
.LBB16_50:                              // %hexkl_kv_q_hf_to_f32.exit529
                                        //   in Loop: Header=BB16_41 Depth=1
	{
		r4 = add(r4,#2)
		nop
		memw(r5++#4) = r6
	} :endloop1
// %bb.51:                              // %for.cond157.preheader.lr.ph
	{
		r15 = ##897988541
		r19 = memw(r29+#256)
		memw(r29+#120) = r19
	}                                       // 4-byte Folded Spill
	{
		r18 = ##1199570688
		r21 = memw(r29+#260)
		memw(r29+#136) = r21
	}                                       // 4-byte Folded Spill
	{
		r11 = ##1065353216
		r24 = #0
		memw(r29+#144) = r26
	}                                       // 4-byte Folded Spill
	{
		r26 = memw(r29+#100)
		r16 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r29,#280)
		r2 = memw(r29+#112)
		memw(r29+#132) = r20
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		memw(r29+#156) = r12
		memw(r29+#140) = r23
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#108) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB16_52:                              // %for.cond157.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB16_54 Depth 2
                                        //     Child Loop BB16_61 Depth 2
	{
		r3 = ##-246811958
		r2 = ##1900671690
	}
	{
		if (!p0) r4 = #0
		if (p0) jump:nt .LBB16_55
	}
// %bb.53:                              //   in Loop: Header=BB16_52 Depth=1
	{
		loop0(.LBB16_54,r14)
	}
	.balign 32
.LBB16_54:                              // Block address taken
                                        // %for.body161
                                        //   Parent Loop BB16_52 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r4 = add(r4,r17)
		r5 = memw(r19+r4<<#0)
		r6 = memw(r21+r4<<#0)
	}
	{
		r2 = sfmin(r5,r2)
		r3 = sfmax(r6,r3)
	} :endloop0
	.falign
.LBB16_55:                              // %for.cond.cleanup160
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r3 = sfsub(r3,r2)
		r4 = ##1065353216
	}
	{
		r2 = togglebit(r2,#31)
		r5 = ##1065353216
	}
	{
		r1 = ##1065353216
		r0 = ##1065353216
	}
	{
		r3 = sfmax(r3,r15)
	}
	{
		r6 = sffixupn(r3,r18)
		r7,p1 = sfrecipa(r3,r18)
	}
	{
		r3 = sffixupd(r3,r18)
	}
	{
		r8 = and(r6,r27)
		r9 = r6
	}
	{
		r4 -= sfmpy(r3,r7):lib
		r12 = r8
	}
	{
		r7 += sfmpy(r4,r7):lib
	}
	{
		r12 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r3,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r9 -= sfmpy(r3,r12):lib
	}
	{
		r12 += sfmpy(r9,r7):lib
	}
	{
		r6 -= sfmpy(r12,r3):lib
	}
	{
		r12 += sfmpy(r6,r7,p1):scale
		memw(r26+#0) = r12.new
	}
	{
		r3,p0 = sfrecipa(r2,r12)
		r4 = sffixupd(r2,r12)
	}
	{
		r6 = sffixupn(r2,r12)
	}
	{
		r1 -= sfmpy(r4,r3):lib
	}
	{
		r2 = r6
	}
	{
		r2 = insert(r8,#31,#0)
		r3 += sfmpy(r1,r3):lib
		r1 = r6
	}
	{
		r2 += sfmpy(r6,r3):lib
		r0 -= sfmpy(r4,r3):lib
	}
	{
		r3 += sfmpy(r0,r3):lib
		r1 -= sfmpy(r4,r2):lib
		r0 = ##1258291200
	}
	{
		r2 += sfmpy(r1,r3):lib
	}
	{
		r6 -= sfmpy(r2,r4):lib
	}
	{
		r2 += sfmpy(r6,r3,p0):scale
		r3 = #0
	}
	{
		p0 = sfcmp.uo(r3,r2)
		p2 = sfcmp.gt(r3,r2)
	}
	{
		r3 = togglebit(r2,#31)
		p0 = and(p2,!p0)
	}
	{
		if (!p0) r3 = add(r2,#0)
	}
	{
		p1 = sfcmp.uo(r3,r0)
		p3 = sfcmp.ge(r3,r0)
	}
	{
		p2 = and(p3,!p1)
		if (!p2.new) r5 = ##1056964608
		if (p2.new) jump:t .LBB16_57
	}
// %bb.56:                              // %if.end.i
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r2 = convert_sf2w(r3):chop
	}
	{
		r2 = convert_w2sf(r2)
	}
	{
		r3 = sfsub(r3,r2)
		r4 = sfadd(r2,r11)
	}
	{
		p1 = sfcmp.uo(r3,r5)
		p3 = sfcmp.ge(r3,r5)
	}
	{
		p2 = and(p3,!p1)
		if (!p2.new) r4 = add(r2,#0)
	}
	{
		r2 = togglebit(r4,#31)
	}
	{
		if (!p0) r2 = add(r4,#0)
	}
	.falign
.LBB16_57:                              // %q2c_roundf.exit
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r3 = asl(r24,#1)
		r0 = memw(r29+#108)
		r1 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r23 = setbit(r3,#0)
		p2 = r0
		if (!p2.new) r0 = add(r24,#0)
	}
	{
		if (p2) jump:nt .LBB16_63
		memw(r1+r23<<#2) = r2
	}
// %bb.58:                              // %for.body206.lr.ph
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		call __hexagon_udivsi3
		r1 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.59:                              // %for.body206.lr.ph
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r2 = #0
		r3 = memw(r29+#112)
		r6 = memw(r29+#120)
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r3,#1)
	}
	{
		r5 = mpyi(r0,r3)
		p0 = cmp.gtu(r4,#0)
		r3 = and(r3,#1)
		if (!p0.new) r4 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r6,r5,#2)
		p1 = cmp.gtu(r4,#1)
		if (!p0) jump:nt .LBB16_64
		if (!p0) r14 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
// %bb.60:                              //   in Loop: Header=BB16_52 Depth=1
	{
		r7 = add(r4,#-1)
		r6 = r5
		r4 = memw(r5+#4)
	}
	{
		r11 = ##1065353216
		r8 = memw(r6++#8)
		r5 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r2 = sfmax(r8,r2)
		r15 = ##897988541
		r14 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB16_61,r7)
		p0 = r5
		if (!p1) jump:nt .LBB16_62
	}
	.balign 32
.LBB16_61:                              //   Parent Loop BB16_52 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = sfmax(r4,r2)
		r4 = memw(r6+#4)
		r5 = memw(r6++#8)
	}
	{
		r2 = sfmax(r5,r2)
		nop
	} :endloop0
	.falign
.LBB16_62:                              //   in Loop: Header=BB16_52 Depth=1
	{
		r2 = sfmax(r4,r2)
		r5 = r6
		p2 = cmp.gtu(r3,#0)
		if (!p2.new) jump:t .LBB16_66
	}
	{
		jump .LBB16_65
	}
	.falign
.LBB16_63:                              //   in Loop: Header=BB16_52 Depth=1
	{
		r2 = #0
		r3 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		jump .LBB16_66
	}
	.falign
.LBB16_64:                              //   in Loop: Header=BB16_52 Depth=1
	{
		p0 = r4
		r11 = ##1065353216
		p2 = cmp.gtu(r3,#0)
	}
	{
		r15 = ##897988541
	}
	{
		if (!p2) jump:nt .LBB16_66
	}
	.falign
.LBB16_65:                              // Block address taken
                                        // %for.body206
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r3 = memw(r5+#0)
	}
	{
		r2 = sfmax(r3,r2)
	}
	.falign
.LBB16_66:                              // %for.cond.cleanup205
                                        //   in Loop: Header=BB16_52 Depth=1
	{
		r2 = sfadd(r2,r2)
		r24 = add(r24,#1)
		r3 = ##1065353216
	}
	{
		r4 = ##1065353216
		r5 = ##1065353216
	}
	{
		r6 = ##1065353216
		r21 = add(r21,#4)
	}
	{
		r2 = sfmax(r2,r15)
		r19 = add(r19,#4)
	}
	{
		r7 = sffixupn(r2,r18)
		r8,p3 = sfrecipa(r2,r18)
	}
	{
		r2 = sffixupd(r2,r18)
	}
	{
		r9 = and(r7,r27)
	}
	{
		r3 -= sfmpy(r2,r8):lib
		r13:12 = combine(r9,r7)
	}
	{
		r8 += sfmpy(r3,r8):lib
		r3 = ##1191182336
	}
	{
		r13 += sfmpy(r7,r8):lib
		r4 -= sfmpy(r2,r8):lib
	}
	{
		r8 += sfmpy(r4,r8):lib
		r12 -= sfmpy(r2,r13):lib
	}
	{
		r13 += sfmpy(r12,r8):lib
	}
	{
		r7 -= sfmpy(r13,r2):lib
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		r13 += sfmpy(r7,r8,p3):scale
		p3 = cmp.eq(r24,r22)
		memw(r16++#8) = r13.new
	}
	{
		if (p3) r7 = ##1123942400
		memw(r2+r23<<#2) = r3
		r2 = memw(r26++#8)

	} :mem_noshuf
	{
		r3,p1 = sfrecipa(r11,r2)
		r4 = sffixupd(r11,r2)
	}
	{
		r2 = sffixupn(r11,r2)
	}
	{
		r5 -= sfmpy(r4,r3):lib
	}
	{
		r1 = r2
		r0 = r2
	}
	{
		r1 = insert(r9,#31,#0)
		r3 += sfmpy(r5,r3):lib
		if (p3) r9 = ##1065353216
	}
	{
		r1 += sfmpy(r2,r3):lib
		r6 -= sfmpy(r4,r3):lib
	}
	{
		r0 -= sfmpy(r4,r1):lib
		r3 += sfmpy(r6,r3):lib
	}
	{
		r1 += sfmpy(r0,r3):lib
	}
	{
		r2 -= sfmpy(r1,r4):lib
	}
	{
		r1 += sfmpy(r2,r3,p1):scale
		if (!p3) jump:nt .LBB16_52
		memw(r20++#4) = r1.new
	}
// %bb.67:                              // %for.cond241.preheader
	{
		r3:2 = combine(#1,#0)
		r17 = memw(r29+#152)
		r19 = memw(r29+#120)
	}                                       // 4-byte Folded Reload
	{
		r12 = maxu(r25,r3)
		r3 = r17
		r16 = memw(r29+#136)
		r18 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r12,#1)
		if (p3.new) r15 = add(r12,#-2)
		r8 = memw(r17+#0)
		r20 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		if (p3) r13 = ##1065353216
		r0 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		r5,p0 = sfrecipa(r8,r7)
		r4 = sffixupd(r8,r7)
		if (p3) r28 = ##1065353216
	}
	{
		r6 = sffixupn(r8,r7)
	}
	{
		r9 -= sfmpy(r4,r5):lib
		if (p3) r14 = add(r6,#0)
	}
	{
		r5 += sfmpy(r9,r5):lib
		if (p3) r9 = add(r6,#0)
		if (!p3) jump:nt .LBB16_71
	}
// %bb.68:                              // %for.body245
	{
		p1 = sfcmp.uo(r8,r2)
		p3 = cmp.gtu(r12,#2)
	}
	{
		r9 = insert(r2,#31,#0)
	}
	{
		r13 -= sfmpy(r4,r5):lib
		r9 += sfmpy(r6,r5):lib
	}
	{
		p2 = sfcmp.gt(r8,r2)
		r8 = memw(r17+#4)
	}
	{
		r5 += sfmpy(r13,r5):lib
		p2 = and(p2,!p1)
	}
	{
		r14 -= sfmpy(r4,r9):lib
		r12,p1 = sfrecipa(r8,r7)
	}
	{
		r13 = sffixupn(r8,r7)
	}
	{
		r9 += sfmpy(r14,r5):lib
	}
	{
		r6 -= sfmpy(r9,r4):lib
		r4 = sffixupd(r8,r7)
	}
	{
		r28 -= sfmpy(r4,r12):lib
	}
	{
		loop0(.LBB16_69,r15)
		r12 += sfmpy(r28,r12):lib
		if (!p3) jump:nt .LBB16_70
	}
	.falign
.LBB16_69:                              // %for.body245
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 += sfmpy(r6,r5,p0):scale
		r14 = r13
		r15 = ##1065353216
	}
	{
		r14 = insert(r2,#31,#0)
		r15 -= sfmpy(r4,r12):lib
		r5 = r12
		r28 = r13
	}
	{
		r14 += sfmpy(r13,r12):lib
		p0 = or(p1,p1)
		if (!p2) r9 = add(r11,#0)
		r12 = memw(r3+#8)
	}
	{
		r5 += sfmpy(r15,r5):lib
		r6 = r13
		r15 = ##1065353216
	}
	{
		p3 = sfcmp.uo(r8,r2)
		r10,p1 = sfrecipa(r12,r7)
		memw(r3++#4) = r9
	}
	{
		r1 = sffixupd(r12,r7)
		r28 -= sfmpy(r4,r14):lib
	}
	{
		p2 = sfcmp.gt(r8,r2)
	}
	{
		r15 -= sfmpy(r1,r10):lib
		r13 = sffixupn(r12,r7)
	}
	{
		r14 += sfmpy(r28,r5):lib
		p2 = and(p2,!p3)
	}
	{
		r10 += sfmpy(r15,r10):lib
	}
	{
		r6 -= sfmpy(r14,r4):lib
		r9:8 = combine(r14,r12)
		r4 = r1
	}
	{
		r12 = r10
		nop
	} :endloop0
	.falign
.LBB16_70:
	{
		r9 += sfmpy(r6,r5,p0):scale
		p0 = or(p1,p1)
		r5 = r12
		r6 = r13
	}
	{
		if (!p2) r9 = add(r11,#0)
	}
	{
		memw(r3++#4) = r9
	}
	.falign
.LBB16_71:
	{
		r7 = r6
		r9 = ##1065353216
		r12 = r6
	}
	{
		r7 = insert(r2,#31,#0)
		p1 = sfcmp.uo(r8,r2)
	}
	{
		r9 -= sfmpy(r4,r5):lib
		r7 += sfmpy(r6,r5):lib
	}
	{
		p3 = sfcmp.gt(r8,r2)
	}
	{
		r5 += sfmpy(r9,r5):lib
		r12 -= sfmpy(r4,r7):lib
		r9 = ##1065353216
	}
	{
		r7 += sfmpy(r12,r5):lib
		r12 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r6 -= sfmpy(r7,r4):lib
	}
	{
		r7 += sfmpy(r6,r5,p0):scale
		p0 = and(p3,!p1)
		p3 = cmp.gtu(r12,#1)
		if (p3.new) r15 = add(r12,#-2)
	}
	{
		if (!p0) r7 = add(r11,#0)
		if (p3) r13 = ##1065353216
	}
	{
		r7 = ##1123942400
		memw(r3++#4) = r7
		r8 = memw(r19+#0)

	} :mem_noshuf
	{
		r3:2 = combine(r19,#0)
		if (p3) r28 = ##1065353216
	}
	{
		r5,p1 = sfrecipa(r8,r7)
		r4 = sffixupd(r8,r7)
	}
	{
		r6 = sffixupn(r8,r7)
	}
	{
		r9 -= sfmpy(r4,r5):lib
		if (p3) r14 = add(r6,#0)
	}
	{
		r5 += sfmpy(r9,r5):lib
		if (p3) r9 = add(r6,#0)
		if (!p3) jump:nt .LBB16_75
	}
// %bb.72:                              // %for.body264
	{
		p2 = sfcmp.uo(r8,r2)
		p3 = cmp.gtu(r12,#2)
	}
	{
		r9 = insert(r2,#31,#0)
	}
	{
		r13 -= sfmpy(r4,r5):lib
		r9 += sfmpy(r6,r5):lib
	}
	{
		p0 = sfcmp.gt(r8,r2)
		r8 = memw(r19+#4)
	}
	{
		r5 += sfmpy(r13,r5):lib
		p2 = and(p0,!p2)
	}
	{
		r14 -= sfmpy(r4,r9):lib
		r12,p0 = sfrecipa(r8,r7)
	}
	{
		r13 = sffixupn(r8,r7)
	}
	{
		r9 += sfmpy(r14,r5):lib
	}
	{
		r6 -= sfmpy(r9,r4):lib
		r4 = sffixupd(r8,r7)
	}
	{
		r28 -= sfmpy(r4,r12):lib
	}
	{
		loop0(.LBB16_73,r15)
		r12 += sfmpy(r28,r12):lib
		if (!p3) jump:nt .LBB16_74
	}
	.falign
.LBB16_73:                              // %for.body264
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 += sfmpy(r6,r5,p1):scale
		r14 = r13
		r15 = ##1065353216
	}
	{
		r14 = insert(r2,#31,#0)
		r15 -= sfmpy(r4,r12):lib
		r5 = r12
		r28 = r13
	}
	{
		r14 += sfmpy(r13,r12):lib
		p1 = or(p0,p0)
		if (!p2) r9 = add(r11,#0)
		r12 = memw(r3+#8)
	}
	{
		r5 += sfmpy(r15,r5):lib
		r6 = r13
		r15 = ##1065353216
	}
	{
		p2 = sfcmp.uo(r8,r2)
		r10,p0 = sfrecipa(r12,r7)
		memw(r3++#4) = r9
	}
	{
		r1 = sffixupd(r12,r7)
		r28 -= sfmpy(r4,r14):lib
	}
	{
		p3 = sfcmp.gt(r8,r2)
	}
	{
		r15 -= sfmpy(r1,r10):lib
		r13 = sffixupn(r12,r7)
	}
	{
		r14 += sfmpy(r28,r5):lib
		p2 = and(p3,!p2)
	}
	{
		r10 += sfmpy(r15,r10):lib
	}
	{
		r6 -= sfmpy(r14,r4):lib
		r9:8 = combine(r14,r12)
		r4 = r1
	}
	{
		r12 = r10
		nop
	} :endloop0
	.falign
.LBB16_74:
	{
		r9 += sfmpy(r6,r5,p1):scale
		p1 = or(p0,p0)
		r5 = r12
		r6 = r13
	}
	{
		if (!p2) r9 = add(r11,#0)
	}
	{
		memw(r3++#4) = r9
	}
	.falign
.LBB16_75:
	{
		r7 = r6
		r9 = ##1065353216
		r12 = r6
	}
	{
		r7 = insert(r2,#31,#0)
		p2 = sfcmp.uo(r8,r2)
	}
	{
		r9 -= sfmpy(r4,r5):lib
		r7 += sfmpy(r6,r5):lib
	}
	{
		p3 = sfcmp.gt(r8,r2)
	}
	{
		r5 += sfmpy(r9,r5):lib
		r12 -= sfmpy(r4,r7):lib
	}
	{
		r7 += sfmpy(r12,r5):lib
	}
	{
		r6 -= sfmpy(r7,r4):lib
	}
	{
		r7 += sfmpy(r6,r5,p1):scale
		p1 = and(p3,!p2)
	}
	{
		if (!p1) r7 = add(r11,#0)
	}
	{
		call free
		memw(r3++#4) = r7
	}
	.falign
// %bb.76:
	{
		call free
		r0 = memw(r29+#128)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.77:
	{
		call free
		r0 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.78:
	{
		call hexkl_kv_q_set_fixed_scales
		r3:2 = combine(r19,r17)
		r0 = r16
		r1 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.79:
	{
		r19 = r0
		p2 = cmp.eq(r0,#0)
		if (p2.new) jump:nt .LBB16_87
	}
// %bb.80:                              // %do.body283
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB16_91
	}
// %bb.81:                              // %if.else287
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #751
	}
	{
		r3 = add(pc,##.L.str.10@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r19
	}
	.falign
// %bb.82:                              // %if.else287
	{
		jump .LBB16_11
	}
	.falign
.LBB16_83:                              // %if.then69
	{
		call free
		r0 = r26
		r16 = r13
	}
	.falign
// %bb.84:                              // %if.then69
	{
		call free
		r0 = memw(r29+#128)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.85:                              // %if.then69
	{
		call free
		r0 = r16
	}
	.falign
// %bb.86:                              // %if.then69
	{
		r19 = add(r27,#1026)
		jump .LBB16_11
	}
	.falign
.LBB16_87:                              // %if.end291
	//# InlineAsm Start
	{
		r17:16 = c31:30
	}
	//# InlineAsm End
	{
		r5 = r18
		r0 = memw(r29+#180)
		memw(r29+#12) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#172)
		memw(r29+#24) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#192)
		memw(r29+#8) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#184)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#280)
		r1 = memw(r29+#176)
		memw(r29+#16) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#188)
		memw(r29+#36) = r2
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#100)
		memw(r29+#32) = r1
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#104)
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#196)
		memw(r29+#52) = r4
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#168)
		memw(r29+#40) = r20
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#88)
		memw(r29+#64) = r20
	}                                       // 4-byte Folded Reload
	{
		r20 = memw(r29+#160)
		memw(r29+#48) = r1
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#56) = r1
		memw(r29+#60) = r0
	}
	{
		r1:0 = memd(r29+#264)
		memw(r29+#4) = r18
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#92)
		memw(r29+#20) = r22
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#84)
		memw(r29+#68) = r20
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#164)
		memw(r29+#72) = r19.new
	}                                       // 4-byte Folded Reload
	{
		call attn_q2_step_impl
		memw(r29+#28) = #0
	}
	.falign
// %bb.88:                              // %if.end291
	{
		r19 = r0
		if (p0.new) r2 = #10
		p0 = cmp.gt(r19,#2); if (!p0.new) jump:nt .LBB16_11
	}
// %bb.89:                              // %if.end291
	{
		p3 = cmp.eq(r19,#0)
		if (!p3.new) jump:nt .LBB16_11
		if (p3.new) r7 = memw(r29+#204)
		if (p3.new) r6 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
// %bb.90:                              // %if.then302
	{
		r1:0 = mpyu(r16,r2)
	}
	{
		r1 += mpyi(r17,#10)
		r5:4 = mpyu(r0,r6)
	}
	{
		r3:2 = mpyu(r0,r7)
		r19:18 = combine(#0,r5)
	}
	{
		r5:4 = combine(r19,r18)
		r18 = r2
	}
	{
		r5:4 += mpyu(r1,r6)
	}
	{
		r5:4 = add(r5:4,r19:18)
	}
	{
		r18 = r5
	}
	{
		r5:4 = combine(r19,r18)
		r18 = r3
		r3:2 = memd(r29+#272)
	}                                       // 8-byte Folded Reload
	{
		r5:4 += mpyu(r1,r7)
	}
	{
		r1:0 = add(r5:4,r19:18)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	{
		r1:0 = sub(r1:0,r3:2)
	}
	{
		jump .LBB16_11
		memw(r20+#8) = r0
	}
	.falign
.LBB16_91:                              // %if.then286
	{
		r3 = add(pc,##.L.str.10@PCREL)
		r2 = #751
		memw(r29+#0) = r19
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.92:                              // %if.then286
	{
		jump .LBB16_11
	}
.Lfunc_end16:
	.size	nntr_hvx_attn_q2_step_fqc, .Lfunc_end16-nntr_hvx_attn_q2_step_fqc
                                        // -- End function
	.falign
	.type	q2c_worker,@function            // -- Begin function q2c_worker
q2c_worker:                             // @q2c_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#1152):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r4 = memw(r2+#40)
		deallocframe
	}
	{
		r24 = memw(r2+#16)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r2)
		memd(r30+#-8) = r17:16
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r26 = mpyi(r24,r1)
		r25 = memw(r2+#8)
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(#0,r0)
		r21 = memw(r2+#20)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r25,r1)
		r6 = memw(r16+#48)
		memw(r29+#108) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r5 = mpyi(r26,r21)
		r3:2 = combine(r19,r18)
		r27 = memw(r2+#44)
		r6 = memw(r16+#32)
	}
	{
		r20 = addasl(r4,r5,#1)
		r6 = memw(r16+#52)
		memw(r29+#116) = r6
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivdi3
		memd(r30+#-32) = r23:22
		memw(r29+#112) = r6
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r23:22 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r25,r2)
		call __hexagon_udivdi3
		r23 = r2
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.2:                               // %entry
	{
		r2 = mpyi(r24,r21)
		r25:24 = combine(r1,r0)
		r1:0 = combine(#0,r20)
	}
	{
		call memset
		r2 = asl(r2,#1)
	}
	.falign
// %bb.3:                               // %entry
	{
		v0 = vxor(v0,v0)
		r3 = memw(r16+#16)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB17_16
	}
// %bb.4:                               // %for.body.lr.ph
	{
		r2 = addasl(r27,r26,#1)
		r4 = #32767
		p0 = cmp.gtu(r24,r22)
		if (!p0.new) jump:t .LBB17_8
	}
// %bb.5:                               // %for.body.lr.ph.split.us
	{
		p1 = cmp.gtu(r21,#63)
		if (p1.new) jump:t .LBB17_10
	}
// %bb.6:
	{
		loop0(.LBB17_7,r3)
	}
	.falign
.LBB17_7:                               // Block address taken
                                        // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		vmem(r29+#1) = v0
	}
	{
		r3 = memuh(r29+#128)
		r7 = memuh(r29+#136)
	}
	{
		r4 = memuh(r29+#130)
		r6 = memuh(r29+#138)
	}
	{
		r3 = maxu(r4,r3)
		r1 = memuh(r29+#132)
		r0 = memuh(r29+#134)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#140)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#142)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#144)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#146)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#148)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#150)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#152)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#154)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#156)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#158)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#160)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#162)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#164)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#166)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#168)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#170)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#172)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#174)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#176)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#178)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#180)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#182)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#184)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#186)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#188)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#190)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#192)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#194)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#196)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#198)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#200)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#202)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#204)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#206)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#208)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#210)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#212)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#214)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#216)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#218)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#220)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#222)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#224)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#226)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#228)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#230)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#232)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#234)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#236)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#238)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#240)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#242)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#244)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#246)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#248)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#250)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#252)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#254)
	}
	{
		r3 = maxu(r7,r3)
	}
	{
		r3 = maxu(r6,r3)
	}
	{
		r3 = maxu(r1,r3)
	}
	{
		r3 = maxu(r0,r3)
		memh(r2++#2) = r3.new
	} :endloop0
	{
		jump .LBB17_16
	}
	.falign
.LBB17_8:
	{
		loop0(.LBB17_9,r3)
	}
	.falign
.LBB17_9:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		vmem(r29+#1) = v0
	}
	{
		r3 = memuh(r29+#128)
		r7 = memuh(r29+#136)
	}
	{
		r4 = memuh(r29+#130)
		r6 = memuh(r29+#138)
	}
	{
		r3 = maxu(r4,r3)
		r1 = memuh(r29+#132)
		r0 = memuh(r29+#134)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#140)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#142)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#144)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#146)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#148)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#150)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#152)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#154)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#156)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#158)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#160)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#162)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#164)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#166)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#168)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#170)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#172)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#174)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#176)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#178)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#180)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#182)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#184)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#186)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#188)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#190)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#192)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#194)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#196)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#198)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#200)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#202)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#204)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#206)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#208)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#210)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#212)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#214)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#216)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#218)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#220)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#222)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#224)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#226)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#228)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#230)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#232)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#234)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#236)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#238)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#240)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#242)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#244)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#246)
	}
	{
		r3 = maxu(r7,r3)
		r7 = memuh(r29+#248)
	}
	{
		r3 = maxu(r6,r3)
		r6 = memuh(r29+#250)
	}
	{
		r3 = maxu(r1,r3)
		r1 = memuh(r29+#252)
	}
	{
		r3 = maxu(r0,r3)
		r0 = memuh(r29+#254)
	}
	{
		r3 = maxu(r7,r3)
	}
	{
		r3 = maxu(r6,r3)
	}
	{
		r3 = maxu(r1,r3)
	}
	{
		r3 = maxu(r0,r3)
		memh(r2++#2) = r3.new
	} :endloop0
	{
		jump .LBB17_16
	}
	.falign
.LBB17_10:
	{
		r3 = lsr(r21,#6)
	}
	{
		v1.h = vsplat(r4)
		r4 = #0
		p1 = cmp.gtu(r3,#1)
	}
	.falign
.LBB17_11:                              // %for.body.us.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB17_12 Depth 2
                                        //       Child Loop BB17_13 Depth 3
	{
		r5 = sub(r24,r22)
		v4 = v0
	}
	{
		loop1(.LBB17_12,r5)
		r5 = r22
	}
	.falign
.LBB17_12:                              // Block address taken
                                        // %for.body37.us.us.us
                                        //   Parent Loop BB17_11 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB17_13 Depth 3
	{
		r7 = memw(r16+#20)
		r6 = memw(r16+#12)
	}
	{
		r8 = mpyi(r7,r4)
		r12 = mpyi(r6,r5)
		r7 = memw(r16+#0)
		r9 = memw(r16+#4)
	}
	{
		r7 = addasl(r7,r12,#1)
		r6 = addasl(r20,r8,#1)
	}
	{
		r9 = addasl(r9,r12,#1)
		r7 = addasl(r7,r8,#1)
	}
	{
		r8 = addasl(r9,r8,#1)
		r9 = add(r3,#-1)
		v10 = vmemu(r6+#0)
	}
	{
		loop0(.LBB17_13,r9)
		v13 = vmemu(r7++#1)
	}
	{
		v7 = vand(v13,v1)
		v9 = vmemu(r8++#1)
	}
	{
		v11 = vand(v9,v1)
	}
	{
		v12.uh = vmax(v10.uh,v11.uh)
	}
	{
		if (!p1) jump:nt .LBB17_14
		vmemu(r6++#1) = v12
	}
	.balign 32
.LBB17_13:                              // %for.body57.us.us.us
                                        //   Parent Loop BB17_11 Depth=1
                                        //     Parent Loop BB17_12 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v4.uh = vmax(v4.uh,v7.uh)
		v14 = vmemu(r8++#1)
	}
	{
		v15 = vand(v14,v1)
		v16 = vmemu(r6+#0)
	}
	{
		v17.uh = vmax(v16.uh,v15.uh)
		v18 = vmemu(r7++#1)
	}
	{
		v7 = vand(v18,v1)
	}
	{
		nop
		vmemu(r6++#1) = v17
	} :endloop0
	.falign
.LBB17_14:                              //   in Loop: Header=BB17_12 Depth=2
	{
		r5 = add(r5,#1)
		nop
		v4.uh = vmax(v4.uh,v7.uh)
	} :endloop1
// %bb.15:                              // %for.cond33.for.cond.cleanup36_crit_edge.split.us.us.us
                                        //   in Loop: Header=BB17_11 Depth=1
	{
		r4 = add(r4,#1)
		vmem(r29+#1) = v4
	}
	{
		r5 = memuh(r29+#128)
		r0 = memuh(r29+#136)
	}
	{
		r7 = memuh(r29+#130)
		r6 = memuh(r29+#132)
	}
	{
		r5 = maxu(r7,r5)
		r1 = memuh(r29+#134)
	}
	{
		r5 = maxu(r6,r5)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#138)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#140)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#142)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#144)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#146)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#148)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#150)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#152)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#154)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#156)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#158)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#160)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#162)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#164)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#166)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#168)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#170)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#172)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#174)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#176)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#178)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#180)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#182)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#184)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#186)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#188)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#190)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#192)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#194)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#196)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#198)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#200)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#202)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#204)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#206)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#208)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#210)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#212)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#214)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#216)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#218)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#220)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#222)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#224)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#226)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#228)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#230)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#232)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#234)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#236)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#238)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#240)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#242)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#244)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#246)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#248)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memuh(r29+#250)
	}
	{
		r5 = maxu(r0,r5)
		r0 = memuh(r29+#252)
	}
	{
		r5 = maxu(r1,r5)
		r1 = memw(r16+#16)
	}
	{
		r5 = maxu(r0,r5)
		p0 = cmp.gtu(r1,r4)
		r0 = memuh(r29+#254)
	}
	{
		r5 = maxu(r0,r5)
		if (p0) jump:nt .LBB17_11
		memh(r2++#2) = r5.new
	}
	.falign
.LBB17_16:                              // %for.cond.cleanup
	{
		r3:2 = combine(r19,r18)
		r22 = memw(r16+#28)
	}
	{
		r1:0 = mpyu(r22,r17)
		call __hexagon_udivdi3
	}
	.falign
// %bb.17:                              // %for.cond.cleanup
	{
		r1:0 = mpyu(r22,r23)
		call __hexagon_udivdi3
		r3:2 = combine(r19,r18)
		memd(r29+#120) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
// %bb.18:                              // %for.cond.cleanup
	{
		r2 = memw(r16+#32)
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB17_31
		if (!p1.new) r7:6 = memd(r29+#120)
		if (!p1.new) r2 = memw(r29+#116)
	}                                       // 8-byte Folded Reload
// %bb.19:                              // %for.body110.lr.ph
	{
		p0 = cmp.gtu(r0,r6)
		r5 = ##-246779191
		r4 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r5,#-32767)
	}
	{
		r3 = mpyi(r2,r17)
		v2 = vsplat(r5)
		r2 = ##1900704457
	}
	{
		r6 = add(r2,#-32767)
		if (p0) r20 = memw(r16+#20)
		r2 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r3,#2)
		r3 = addasl(r4,r3,#2)
	}
	{
		v3 = vsplat(r6)
		if (!p0) jump:nt .LBB17_23
	}
// %bb.20:                              // %for.body110.lr.ph.split.us
	{
		r8 = lsr(r20,#5)
		p0 = cmp.gtu(r20,#31); if (p0.new) jump:t .LBB17_25
		if (p0.new) r12 = memw(r16+#36)
	}
// %bb.21:                              // %for.body110.us.preheader
	{
		vmem(r29+#7) = v3
	}
	{
		r19 = memw(r29+#960)
		vmem(r29+#6) = v2
	}
	{
		r18 = memw(r29+#964)
		r17 = memw(r29+#968)
	}
	{
		r28 = memw(r29+#992)
		r16 = memw(r29+#972)
	}
	{
		r15 = memw(r29+#996)
		r14 = memw(r29+#1000)
	}
	{
		r21 = memw(r29+#896)
		r11 = memw(r29+#976)
	}
	{
		r6 = sfmin(r21,r6)
		r21 = memw(r29+#768)
		r13 = memw(r29+#1004)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#900)
		r10 = memw(r29+#980)
	}
	{
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#772)
		r22 = memw(r29+#904)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r20 = memw(r29+#956)
		r12 = memw(r29+#1008)
	}
	{
		r21 = memw(r29+#776)
		r1 = memw(r29+#984)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#908)
		r9 = memw(r29+#1012)
	}
	{
		r6 = sfmin(r22,r6)
		r0 = memw(r29+#988)
		r21 = memw(r29+#780)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#912)
		r8 = memw(r29+#1016)
	}
	{
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#784)
		r7 = memw(r29+#1020)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#916)
		r21 = memw(r29+#788)
	}
	{
		r6 = sfmin(r22,r6)
		r22 = memw(r29+#920)
		r23 = memw(r29+#824)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#792)
		r22 = memw(r29+#924)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#796)
		r22 = memw(r29+#928)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#800)
		r22 = memw(r29+#932)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#804)
		r22 = memw(r29+#936)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#808)
		r22 = memw(r29+#940)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#812)
		r22 = memw(r29+#944)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#816)
		r22 = memw(r29+#948)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r22 = memw(r29+#952)
		r21 = memw(r29+#820)
	}
	{
		r6 = sfmin(r22,r6)
		r5 = sfmax(r21,r5)
		r21 = memw(r29+#832)
		r22 = memw(r29+#828)
	}
	{
		r6 = sfmin(r20,r6)
		r5 = sfmax(r23,r5)
		r20 = memw(r29+#836)
		r27 = memw(r29+#864)
	}
	{
		r6 = sfmin(r19,r6)
		r5 = sfmax(r22,r5)
		r19 = memw(r29+#840)
		r4 = memw(r29+#104)
	}
	{
		r6 = sfmin(r18,r6)
		r5 = sfmax(r21,r5)
		r18 = memw(r29+#844)
	}
	{
		r5 = sfmax(r20,r5)
		r6 = sfmin(r17,r6)
	}
	{
		r5 = sfmax(r19,r5)
		r6 = sfmin(r16,r6)
	}
	{
		r6 = sfmin(r11,r6)
		r5 = sfmax(r18,r5)
		r11 = memw(r29+#848)
	}
	{
		r6 = sfmin(r10,r6)
		r5 = sfmax(r11,r5)
		r10 = memw(r29+#852)
		r11 = memw(r29+#872)
	}
	{
		r6 = sfmin(r1,r6)
		r5 = sfmax(r10,r5)
		r1 = memw(r29+#856)
		r10 = memw(r29+#868)
	}
	{
		r6 = sfmin(r0,r6)
		r5 = sfmax(r1,r5)
		r0 = memw(r29+#860)
		r1 = memw(r29+#888)
	}
	{
		r5 = sfmax(r0,r5)
		r6 = sfmin(r28,r6)
		r0 = memw(r29+#884)
	}
	{
		r6 = sfmin(r15,r6)
		r5 = sfmax(r27,r5)
		r15 = memw(r29+#880)
	}
	{
		r6 = sfmin(r14,r6)
		r5 = sfmax(r10,r5)
		r14 = memw(r29+#876)
	}
	{
		r5 = sfmax(r11,r5)
		r6 = sfmin(r13,r6)
	}
	{
		r5 = sfmax(r14,r5)
		r6 = sfmin(r12,r6)
	}
	{
		r5 = sfmax(r15,r5)
		r6 = sfmin(r9,r6)
	}
	{
		r5 = sfmax(r0,r5)
		r6 = sfmin(r8,r6)
	}
	{
		r8 = sfmax(r1,r5)
		r5 = sfmin(r7,r6)
		r6 = memw(r29+#892)
	}
	{
		loop0(.LBB17_22,r4)
		r6 = sfmax(r6,r8)
	}
	.falign
.LBB17_22:                              // Block address taken
                                        // %for.body110.us
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r2++#4) = r5
		memw(r3++#4) = r6
	} :endloop0
	{
		jump .LBB17_31
	}
	.falign
.LBB17_23:                              // %for.body110.preheader
	{
		vmem(r29+#3) = v3
	}
	{
		r19 = memw(r29+#448)
		vmem(r29+#2) = v2
	}
	{
		r18 = memw(r29+#452)
		r17 = memw(r29+#456)
	}
	{
		r28 = memw(r29+#480)
		r16 = memw(r29+#460)
	}
	{
		r15 = memw(r29+#484)
		r14 = memw(r29+#488)
	}
	{
		r21 = memw(r29+#384)
		r11 = memw(r29+#464)
	}
	{
		r6 = sfmin(r21,r6)
		r21 = memw(r29+#256)
		r13 = memw(r29+#492)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#388)
		r10 = memw(r29+#468)
	}
	{
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#260)
		r22 = memw(r29+#392)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r20 = memw(r29+#444)
		r12 = memw(r29+#496)
	}
	{
		r21 = memw(r29+#264)
		r1 = memw(r29+#472)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#396)
		r9 = memw(r29+#500)
	}
	{
		r6 = sfmin(r22,r6)
		r0 = memw(r29+#476)
		r21 = memw(r29+#268)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#400)
		r8 = memw(r29+#504)
	}
	{
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#272)
		r7 = memw(r29+#508)
	}
	{
		r5 = sfmax(r21,r5)
		r22 = memw(r29+#404)
		r21 = memw(r29+#276)
	}
	{
		r6 = sfmin(r22,r6)
		r22 = memw(r29+#408)
		r23 = memw(r29+#312)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#280)
		r22 = memw(r29+#412)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#284)
		r22 = memw(r29+#416)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#288)
		r22 = memw(r29+#420)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#292)
		r22 = memw(r29+#424)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#296)
		r22 = memw(r29+#428)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#300)
		r22 = memw(r29+#432)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r21 = memw(r29+#304)
		r22 = memw(r29+#436)
	}
	{
		r5 = sfmax(r21,r5)
		r6 = sfmin(r22,r6)
		r22 = memw(r29+#440)
		r21 = memw(r29+#308)
	}
	{
		r6 = sfmin(r22,r6)
		r5 = sfmax(r21,r5)
		r21 = memw(r29+#320)
		r22 = memw(r29+#316)
	}
	{
		r6 = sfmin(r20,r6)
		r5 = sfmax(r23,r5)
		r20 = memw(r29+#324)
		r27 = memw(r29+#352)
	}
	{
		r6 = sfmin(r19,r6)
		r5 = sfmax(r22,r5)
		r19 = memw(r29+#328)
		r4 = memw(r29+#104)
	}
	{
		r6 = sfmin(r18,r6)
		r5 = sfmax(r21,r5)
		r18 = memw(r29+#332)
	}
	{
		r5 = sfmax(r20,r5)
		r6 = sfmin(r17,r6)
	}
	{
		r5 = sfmax(r19,r5)
		r6 = sfmin(r16,r6)
	}
	{
		r6 = sfmin(r11,r6)
		r5 = sfmax(r18,r5)
		r11 = memw(r29+#336)
	}
	{
		r6 = sfmin(r10,r6)
		r5 = sfmax(r11,r5)
		r10 = memw(r29+#340)
		r11 = memw(r29+#360)
	}
	{
		r6 = sfmin(r1,r6)
		r5 = sfmax(r10,r5)
		r1 = memw(r29+#344)
		r10 = memw(r29+#356)
	}
	{
		r6 = sfmin(r0,r6)
		r5 = sfmax(r1,r5)
		r0 = memw(r29+#348)
		r1 = memw(r29+#376)
	}
	{
		r5 = sfmax(r0,r5)
		r6 = sfmin(r28,r6)
		r0 = memw(r29+#372)
	}
	{
		r6 = sfmin(r15,r6)
		r5 = sfmax(r27,r5)
		r15 = memw(r29+#368)
	}
	{
		r6 = sfmin(r14,r6)
		r5 = sfmax(r10,r5)
		r14 = memw(r29+#364)
	}
	{
		r5 = sfmax(r11,r5)
		r6 = sfmin(r13,r6)
	}
	{
		r5 = sfmax(r14,r5)
		r6 = sfmin(r12,r6)
	}
	{
		r5 = sfmax(r15,r5)
		r6 = sfmin(r9,r6)
	}
	{
		r5 = sfmax(r0,r5)
		r6 = sfmin(r8,r6)
	}
	{
		r8 = sfmax(r1,r5)
		r5 = sfmin(r7,r6)
		r6 = memw(r29+#380)
	}
	{
		loop0(.LBB17_24,r4)
		r6 = sfmax(r6,r8)
	}
	.falign
.LBB17_24:                              // Block address taken
                                        // %for.body110
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r2++#4) = r5
		memw(r3++#4) = r6
	} :endloop0
	{
		jump .LBB17_31
	}
	.falign
.LBB17_25:
	{
		p1 = cmp.gtu(r8,#1)
		r13 = #0
		r4 = memw(r16+#24)
	}
	{
		memw(r29+#108) = r5
		memw(r29+#112) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB17_26:                              // %for.body110.us.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB17_27 Depth 2
                                        //       Child Loop BB17_28 Depth 3
	{
		r15 = mpyi(r13,r20)
		v5 = v2
		v6 = v3
		r5:4 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r28 = sub(r0,r4)
		r14 = r4
		r4 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		loop1(.LBB17_27,r28)
		r15 = addasl(r4,r15,#2)
	}
	.falign
.LBB17_27:                              // Block address taken
                                        // %for.body117.us.us.us
                                        //   Parent Loop BB17_26 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB17_28 Depth 3
	{
		r28 = mpyi(r12,r14)
		r1 = add(r8,#-1)
	}
	{
		loop0(.LBB17_28,r1)
		r28 = addasl(r15,r28,#2)
	}
	{
		if (!p1) jump:nt .LBB17_29
		v8 = vmemu(r28++#1)
	}
	.falign
.LBB17_28:                              // %for.body128.us.us.us
                                        //   Parent Loop BB17_26 Depth=1
                                        //     Parent Loop BB17_27 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v5.sf = vmax(v5.sf,v8.sf)
		v6.sf = vmin(v6.sf,v8.sf)
		v8 = vmemu(r28++#1)
	} :endloop0
	.falign
.LBB17_29:                              //   in Loop: Header=BB17_27 Depth=2
	{
		r14 = add(r14,#1)
		v6.sf = vmin(v6.sf,v8.sf)
		v5.sf = vmax(v5.sf,v8.sf)
	} :endloop1
// %bb.30:                              // %for.cond113.for.cond.cleanup116_crit_edge.split.us.us.us
                                        //   in Loop: Header=BB17_26 Depth=1
	{
		r13 = add(r13,#1)
		r7 = r6
		r4 = memw(r29+#104)
		vmem(r29+#5) = v6
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r13,r4)
		r26 = memw(r29+#704)
		r24 = memw(r29+#712)
	}
	{
		r25 = memw(r29+#708)
		vmem(r29+#4) = v5
	}
	{
		r17 = memw(r29+#736)
		r23 = memw(r29+#716)
	}
	{
		r16 = memw(r29+#740)
		r11 = memw(r29+#744)
	}
	{
		r4 = memw(r29+#640)
		r10 = memw(r29+#748)
	}
	{
		r4 = sfmin(r4,r6)
		r5 = memw(r29+#512)
		r6 = memw(r29+#108)
	}
	{
		r5 = sfmax(r5,r6)
		r9 = memw(r29+#644)
		r22 = memw(r29+#720)
	}
	{
		r4 = sfmin(r9,r4)
		r6 = memw(r29+#516)
		r21 = memw(r29+#724)
	}
	{
		r5 = sfmax(r6,r5)
		r6 = memw(r29+#648)
		r27 = memw(r29+#700)
	}
	{
		r4 = sfmin(r6,r4)
		r1 = memw(r29+#752)
		r9 = memw(r29+#520)
	}
	{
		r5 = sfmax(r9,r5)
		r19 = memw(r29+#728)
		r6 = memw(r29+#652)
	}
	{
		r4 = sfmin(r6,r4)
		r28 = memw(r29+#756)
		r18 = memw(r29+#732)
	}
	{
		r9 = memw(r29+#524)
		r6 = memw(r29+#656)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r15 = memw(r29+#760)
		r9 = memw(r29+#528)
	}
	{
		r5 = sfmax(r9,r5)
		r6 = memw(r29+#660)
		r14 = memw(r29+#764)
	}
	{
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#532)
		r6 = memw(r29+#664)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#536)
		r6 = memw(r29+#668)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#540)
		r6 = memw(r29+#672)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#544)
		r6 = memw(r29+#676)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#548)
		r6 = memw(r29+#680)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#552)
		r6 = memw(r29+#684)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#556)
		r6 = memw(r29+#688)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#560)
		r6 = memw(r29+#692)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#564)
		r6 = memw(r29+#696)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r6,r4)
		r9 = memw(r29+#568)
	}
	{
		r5 = sfmax(r9,r5)
		r4 = sfmin(r27,r4)
		r6 = memw(r29+#572)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r26,r4)
		r6 = memw(r29+#576)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r25,r4)
		r6 = memw(r29+#580)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r24,r4)
		r6 = memw(r29+#584)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r23,r4)
		r6 = memw(r29+#588)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r22,r4)
		r6 = memw(r29+#592)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r21,r4)
		r6 = memw(r29+#596)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r19,r4)
		r6 = memw(r29+#600)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r18,r4)
		r6 = memw(r29+#604)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r17,r4)
		r6 = memw(r29+#608)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r16,r4)
		r6 = memw(r29+#612)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r11,r4)
		r6 = memw(r29+#616)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r10,r4)
		r6 = memw(r29+#620)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r1,r4)
		r6 = memw(r29+#624)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r28,r4)
		r6 = memw(r29+#628)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r15,r4)
		r6 = memw(r29+#632)
	}
	{
		r5 = sfmax(r6,r5)
		r4 = sfmin(r14,r4)
		r6 = memw(r29+#636)
		memw(r2++#4) = r4.new
	}
	{
		r5 = sfmax(r6,r5)
		r6 = r7
		if (!p0) jump:nt .LBB17_26
		memw(r3++#4) = r5.new
	}
	.falign
.LBB17_31:                              // %for.cond.cleanup109
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end17:
	.size	q2c_worker, .Lfunc_end17-q2c_worker
                                        // -- End function
	.globl	nntr_hvx_probe_wh_i8_pos        // -- Begin function nntr_hvx_probe_wh_i8_pos
	.falign
	.type	nntr_hvx_probe_wh_i8_pos,@function
nntr_hvx_probe_wh_i8_pos:               // @nntr_hvx_probe_wh_i8_pos
// %bb.0:                               // %entry
	{
		r5:4 = combine(r1,r0)
		r0 = ##-2147482610
		allocframe(#8)
	}
	{
		if (!p0.new) r16 = add(r2,#0)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB18_6
		memd(r29+#0) = r17:16
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r3,##1024)
		if (!p1.new) jump:nt .LBB18_6
		if (p1.new) r0 = memw(r4+#0)
	}
// %bb.2:                               // %if.end
	{
		call hexkl_kv_q_wh_i8_pos
	}
	.falign
// %bb.3:                               // %if.end
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB18_7
	}
// %bb.4:                               // %if.end4
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r2 = #2048
		r1 = r0
		r0 = r16
	}
	.falign
// %bb.5:                               // %if.end4
	{
		r0 = #0
	}
	.falign
.LBB18_6:                               // %cleanup5
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB18_7:
	{
		r0 = ##-2147482604
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end18:
	.size	nntr_hvx_probe_wh_i8_pos, .Lfunc_end18-nntr_hvx_probe_wh_i8_pos
                                        // -- End function
	.globl	nntr_hvx_probe_softmax_q        // -- Begin function nntr_hvx_probe_softmax_q
	.falign
	.type	nntr_hvx_probe_softmax_q,@function
nntr_hvx_probe_softmax_q:               // @nntr_hvx_probe_softmax_q
// %bb.0:                               // %entry
	{
		r6 = ##-2147449843
		memd(r29+#-16) = r17:16
		allocframe(#96)
	}                                       // 8-byte Folded Spill
	{
		r16 = add(r6,#-32767)
		r22 = memw(r29+#112)
		memd(r29+#64) = r23:22
	}
	{
		p0 = cmp.gtu(r22,##32767)
		memd(r29+#80) = r19:18
		memd(r29+#72) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB19_20
		memd(r29+#56) = r25:24
		memd(r29+#48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r6 = add(r2,#-129)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB19_20
	}
// %bb.2:                               // %entry
	{
		r7 = #-128
		if (cmp.gtu(r7.new,r6)) jump:nt .LBB19_20
	}
// %bb.3:                               // %entry
	{
		r6 = #-8
		r25 = memw(r29+#116)
	}
	{
		r7 = add(r25,#-9)
		if (cmp.gtu(r6,r7.new)) jump:nt .LBB19_20
	}
// %bb.4:                               // %if.end
	{
		r17 = memw(r29+#124)
	}
	{
		r6 = asl(r2,#11)
		if (!cmp.eq(r6.new,r17)) jump:t .LBB19_16
	}
// %bb.5:                               // %lor.lhs.false16
	{
		r6 = r2
		r21 = memw(r29+#132)
	}
	{
		r6 = add(#32,asl(r6,#5))
		if (!cmp.eq(r6.new,r21)) jump:t .LBB19_16
	}
// %bb.6:                               // %lor.lhs.false20
	{
		r6 = memw(r29+#140)
		if (!cmp.eq(r6.new,r17)) jump:nt .LBB19_16
	}
// %bb.7:                               // %lor.lhs.false20
	{
		r6 = #512
	}
	{
		r6 = memw(r29+#148)
		if (!cmp.eq(r6.new,r6)) jump:nt .LBB19_16
	}
// %bb.8:                               // %lor.lhs.false20
	{
		r26 = r4
		r18 = r5
		r6 = memw(r29+#156)
		if (!cmp.gt(r6.new,#0)) jump:nt .LBB19_16
	}
// %bb.9:                               // %if.end35
	{
		r1 = memw(r29+#144)
		memw(r29+#8) = r1.new
	}
	{
		r1 = asl(r17,#1)
		r23 = r3
		r16 = memw(r0+#0)
		r7 = memw(r29+#152)
	}
	{
		r2 = r1
		r1 = memw(r29+#136)
		memw(r29+#16) = r2
	}
	{
		r20 = add(r16,##131072)
		r27 = memw(r29+#108)
		memw(r29+#12) = r1
	}
	{
		r0 = r20
		r1 = memw(r29+#120)
		memw(r29+#4) = r7
	}
	{
		r19 = memw(r29+#128)
		memw(r29+#0) = r6
	}
	{
		call memcpy
		r24 = memw(r29+#104)
	}
	.falign
// %bb.10:                              // %if.end35
	{
		r2 = asl(r21,#1)
		r21 = add(r16,##917504)
	}
	{
		call memcpy
		r1:0 = combine(r19,r21)
	}
	.falign
// %bb.11:                              // %if.end35
	{
		r2 = memw(r29+#16)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#24) = r23
		memw(r29+#28) = r26
	}
	{
		memw(r29+#32) = r18
		memw(r29+#36) = r24
	}
	{
		memw(r29+#40) = r27
		memh(r29+#44) = r22
	}
	{
		memb(r29+#46) = r25
	}
	//# InlineAsm Start
	{
		r27:26 = c15:14
	}
	//# InlineAsm End
	{
		r19 = add(r16,##655360)
		r0 = add(r29,#20)
		r1 = r20
	}
	{
		r20 = add(r16,##933888)
		r3:2 = combine(r19,r21)
	}
	{
		call hvx_softmax_q
		r4 = r20
		r5 = add(r16,##937984)
	}
	//# InlineAsm Start
	{
		r23:22 = c15:14
	}
	//# InlineAsm End
	{
		call memcpy
		r2 = r17
		r1 = r19
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.12:                              // %if.end35
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r2 = #2048
		r1 = r20
		r0 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.13:                              // %if.end35
	{
		r1:0 = sub(r23:22,r27:26)
		r4 = memw(r29+#4)
		r2 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,#1)
	}
	{
		if (p0) r0 = add(r4,#4)
		if (!p0) jump:nt .LBB19_15
		memw(r4+#0) = r0
	}
// %bb.14:                              // %for.body.preheader
	{
		r3 = #3
		r2 = add(r2,#-2)
		r1 = #0
	}
	{
		r2 = minu(r2,r3)
	}
	{
		r2 = add(#4,asl(r2,#2))
		call memset
	}
	.falign
.LBB19_15:                              // %for.cond.cleanup
	{
		r16 = #0 ; jump .LBB19_20
	}
	.falign
.LBB19_16:                              // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_19
	}
// %bb.17:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #795
	}
	{
		r3 = add(pc,##.L.str.11@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.18:                              // %if.else
	{
		jump .LBB19_20
	}
	.falign
.LBB19_19:                              // %if.then33
	{
		r3 = add(pc,##.L.str.11@PCREL)
		call _HAP_debug_v2
		r2 = #795
	}
	.falign
.LBB19_20:                              // %cleanup
	{
		r0 = r16
		r17:16 = memd(r29+#88)
		r19:18 = memd(r29+#80)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#72)
		r23:22 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#56)
		r27:26 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end19:
	.size	nntr_hvx_probe_softmax_q, .Lfunc_end19-nntr_hvx_probe_softmax_q
                                        // -- End function
	.globl	nntr_hvx_probe_softmax_q16      // -- Begin function nntr_hvx_probe_softmax_q16
	.falign
	.type	nntr_hvx_probe_softmax_q16,@function
nntr_hvx_probe_softmax_q16:             // @nntr_hvx_probe_softmax_q16
// %bb.0:                               // %entry
	{
		r6 = ##-2147449843
		memd(r29+#-16) = r17:16
		allocframe(#112)
	}                                       // 8-byte Folded Spill
	{
		r17 = add(r6,#-32767)
		r23 = memw(r29+#128)
		memd(r29+#80) = r23:22
	}
	{
		p0 = cmp.gtu(r23,##32767)
		memd(r29+#96) = r19:18
		memd(r29+#88) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB20_22
		memd(r29+#72) = r25:24
		memd(r29+#64) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r6 = add(r2,#-129)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB20_22
	}
// %bb.2:                               // %entry
	{
		r7 = #-128
		if (cmp.gtu(r7.new,r6)) jump:nt .LBB20_22
	}
// %bb.3:                               // %entry
	{
		r6 = #-9
		r26 = memw(r29+#132)
	}
	{
		r7 = add(r26,#-10)
		if (cmp.gtu(r6,r7.new)) jump:nt .LBB20_22
	}
// %bb.4:                               // %if.end
	{
		r16 = memw(r29+#140)
	}
	{
		r6 = asl(r2,#11)
		if (!cmp.eq(r6.new,r16)) jump:t .LBB20_18
	}
// %bb.5:                               // %lor.lhs.false16
	{
		r6 = r2
		r22 = memw(r29+#148)
	}
	{
		r6 = add(#32,asl(r6,#5))
		if (!cmp.eq(r6.new,r22)) jump:nt .LBB20_18
	}
// %bb.6:                               // %lor.lhs.false16
	{
		r6 = memw(r29+#156)
		if (!cmp.eq(r6.new,r16)) jump:nt .LBB20_18
	}
// %bb.7:                               // %lor.lhs.false24
	{
		r6 = memw(r29+#164)
		if (!cmp.eq(r6.new,r16)) jump:nt .LBB20_18
	}
// %bb.8:                               // %lor.lhs.false24
	{
		r6 = #512
	}
	{
		r6 = memw(r29+#172)
		if (!cmp.eq(r6.new,r6)) jump:nt .LBB20_18
	}
// %bb.9:                               // %lor.lhs.false24
	{
		r27 = r4
		r19 = r5
		r6 = memw(r29+#180)
		if (!cmp.gt(r6.new,#0)) jump:nt .LBB20_18
	}
// %bb.10:                              // %if.end39
	{
		r24 = r3
		r1 = memw(r29+#168)
		memw(r29+#20) = r1.new
	}
	{
		r1 = asl(r16,#1)
		r17 = memw(r0+#0)
		memw(r29+#32) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = r1
		r1 = memw(r29+#160)
		memw(r29+#24) = r1.new
	}
	{
		r21 = add(r17,##131072)
		r1 = memw(r29+#152)
		memw(r29+#28) = r1.new
	}
	{
		r0 = r21
		r7 = memw(r29+#176)
		memw(r29+#16) = r7.new
	}
	{
		r1 = memw(r29+#136)
		memw(r29+#12) = r6
	}
	{
		r25 = memw(r29+#124)
		r20 = memw(r29+#144)
	}
	{
		call memcpy
		r18 = memw(r29+#120)
	}
	.falign
// %bb.11:                              // %if.end39
	{
		r2 = asl(r22,#1)
		r22 = add(r17,##917504)
	}
	{
		call memcpy
		r1:0 = combine(r20,r22)
	}
	.falign
// %bb.12:                              // %if.end39
	{
		r2 = memw(r29+#32)
		memw(r29+#36) = r2.new
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#40) = r24
		memw(r29+#44) = r27
	}
	{
		memw(r29+#48) = r19
		memw(r29+#52) = r18
	}
	{
		memw(r29+#56) = r25
		memh(r29+#60) = r23
	}
	{
		memb(r29+#62) = r26
	}
	//# InlineAsm Start
	{
		r27:26 = c15:14
	}
	//# InlineAsm End
	{
		r2 = add(r17,##937984)
		r20 = add(r17,##655360)
	}
	{
		r3:2 = combine(r20,r22)
		r0 = add(r29,#36)
		r1 = r21
		memw(r29+#0) = r2
	}
	{
		r21 = add(r17,##970752)
		r22 = add(r17,##933888)
	}
	{
		call hvx_softmax_q16
		r5:4 = combine(r22,r21)
	}
	//# InlineAsm Start
	{
		r19:18 = c15:14
	}
	//# InlineAsm End
	{
		call memcpy
		r2 = r16
		r1 = r20
		r0 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.13:                              // %if.end39
	{
		call memcpy
		r2 = r16
		r1 = r21
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.14:                              // %if.end39
	{
		call __hexagon_memcpy_likely_aligned_min32bytes_mult8bytes
		r2 = #2048
		r1 = r22
		r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.15:                              // %if.end39
	{
		r1:0 = sub(r19:18,r27:26)
		r2 = memw(r29+#12)
		r4 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,#1)
	}
	{
		if (p1) r0 = add(r4,#4)
		if (!p1) jump:nt .LBB20_17
		memw(r4+#0) = r0
	}
// %bb.16:                              // %for.body.preheader
	{
		r3 = #3
		r2 = add(r2,#-2)
		r1 = #0
	}
	{
		r2 = minu(r2,r3)
	}
	{
		r2 = add(#4,asl(r2,#2))
		call memset
	}
	.falign
.LBB20_17:                              // %for.cond.cleanup
	{
		r17 = #0 ; jump .LBB20_22
	}
	.falign
.LBB20_18:                              // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_21
	}
// %bb.19:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #842
	}
	{
		r3 = add(pc,##.L.str.12@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.20:                              // %if.else
	{
		jump .LBB20_22
	}
	.falign
.LBB20_21:                              // %if.then37
	{
		r3 = add(pc,##.L.str.12@PCREL)
		call _HAP_debug_v2
		r2 = #842
	}
	.falign
.LBB20_22:                              // %cleanup
	{
		r0 = r17
		r17:16 = memd(r29+#104)
		r19:18 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#88)
		r23:22 = memd(r29+#80)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#72)
		r27:26 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end20:
	.size	nntr_hvx_probe_softmax_q16, .Lfunc_end20-nntr_hvx_probe_softmax_q16
                                        // -- End function
	.globl	nntr_hvx_attn_q_prefill         // -- Begin function nntr_hvx_attn_q_prefill
	.falign
	.type	nntr_hvx_attn_q_prefill,@function
nntr_hvx_attn_q_prefill:                // @nntr_hvx_attn_q_prefill
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) r1 = add(r2,#0)
		memd(r29+#-16) = r17:16
		allocframe(#232)
	}                                       // 8-byte Folded Spill
	{
		r22 = ##-2147449843
		memd(r29+#200) = r23:22
		memd(r29+#216) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r16 = add(r22,#-32767)
		if (!p1) r17 = add(r3,#0)
		memd(r29+#208) = r21:20
		memd(r29+#192) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p1) r19:18 = combine(r4,r5)
		if (p1) jump:nt .LBB21_40
		memd(r29+#184) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r24 = r0
		r0 = add(r0,##409628)
	}
	{
		call hexkl_kv_q_get
	}
	.falign
// %bb.2:                               // %if.end
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB21_4
	}
// %bb.3:                               // %lor.lhs.false
	{
		r2 = memw(r0+#16)
		if (!cmp.gtu(r18,r2.new)) jump:t .LBB21_7
	}
	.falign
.LBB21_4:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_36
	}
// %bb.5:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #885
	}
	{
		r3 = add(pc,##.L.str.13@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.6:                               // %if.else
	{
		jump .LBB21_40
	}
	.falign
.LBB21_7:                               // %if.end8
	{
		r21 = memw(r29+#248)
		memw(r29+#12) = r21.new
	}
	{
		p1 = cmp.eq(r21,#0)
		r16 = memw(r29+#240)
		r20 = memw(r0+#20)
	}
	{
		r23 = memw(r0+#24)
		memw(r29+#56) = r17
	}
	{
		r25 = memw(r29+#252)
		memw(r29+#60) = r19
	}
	{
		r2 = memw(r29+#244)
		memw(r29+#80) = r2.new
	}
	{
		r2 = memw(r29+#256)
		memw(r29+#64) = r18
	}
	{
		memw(r29+#68) = r16
		memw(r29+#72) = r20
	}
	{
		memw(r29+#76) = r23
		memw(r29+#84) = r2
	}
	{
		if (p1) jump:nt .LBB21_9
		memw(r29+#16) = r25
	}
// %bb.8:                               // %if.end8
	{
		p0 = cmp.eq(r25,#0)
		if (!p0.new) jump:t .LBB21_14
	}
	.falign
.LBB21_9:                               // %if.then24
	{
		r2 = add(r20,#-1)
	}
	{
		if (p1.new) r25 = add(r0,#0)
		r2 = #64
		p1 = cmp.gtu(r16,r2); if (!p1.new) jump:t .LBB21_13
	}
// %bb.10:                              // %cond.end.thread.i
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r16)
	}
	.falign
// %bb.11:                              // %cond.end.thread.i
	{
		r21 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,#64)
	}
	.falign
// %bb.12:                              // %cond.end.thread.i
	{
		r2 = r0
		p0 = cmp.gtu(r21,#64)
		r0 = r25
	}
	{
		if (p0) r2 = #1
	}
	.falign
.LBB21_13:                              // %hexkl_attn_f16_choose_tiling.exit
	{
		r3 = ##-1431655765
		p0 = cmp.gtu(r18,#63)
		p1 = cmp.gtu(r18,#191)
	}
	{
		r3 = mpyu(r18,r3)
		r21 = minu(r2,r17)
		r5 = #256
		memw(r29+#12) = r21.new
	}
	{
		r3 = and(##2147483584,lsr(r3,#1))
		r4 = mux(p0,#64,#32)
	}
	{
		if (!p1) r3 = add(r4,#0)
	}
	{
		r25 = minu(r3,r5)
		memw(r29+#16) = r25.new
	}
	.falign
.LBB21_14:                              // %if.end25
	{
		p1 = cmp.eq(r17,#0); if (p1.new) jump:nt .LBB21_33
	}
// %bb.15:                              // %if.end25
	{
		if (!p0.new) r2 = #511
		p0 = cmp.eq(r16,#0); if (p0.new) jump:nt .LBB21_33
	}
// %bb.16:                              // %if.end25
	{
		p1 = cmp.eq(r20,#0); if (p1.new) jump:nt .LBB21_33
	}
// %bb.17:                              // %lor.lhs.false7.i.i
	{
		r2 = add(r23,#-1)
		if (cmp.gtu(r2.new,r2)) jump:nt .LBB21_33
	}
// %bb.18:                              // %lor.lhs.false7.i.i
	{
		r26 = r0
		r2 = and(r23,#31)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB21_33
	}
// %bb.19:                              // %lor.lhs.false15.i.i
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r16)
	}
	.falign
// %bb.20:                              // %lor.lhs.false15.i.i
	{
		r2 = add(r19,r17)
		if (cmp.gtu(r2.new,r18)) jump:nt .LBB21_33
	}
// %bb.21:                              // %lor.lhs.false15.i.i
	{
		r2 = r16
	}
	{
		r2 -= mpyi(r0,r20)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB21_33
	}
// %bb.22:                              // %lor.lhs.false15.i.i
	{
		p0 = cmp.eq(r21,#0); if (p0.new) jump:nt .LBB21_33
	}
// %bb.23:                              // %lor.lhs.false26.i.i
	{
		p1 = cmp.eq(r25,#0)
		if (p1.new) jump:nt .LBB21_33
	}
// %bb.24:                              // %lor.lhs.false26.i.i
	{
		r7 = add(#63,mpyi(r0,r21))
		r5:4 = mpyu(r16,r17)
		r2 = and(r25,#31)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB21_33
	}
// %bb.25:                              // %if.end33.i.i
	{
		r2 = memw(r29+#264)
		memw(r29+#20) = r0
	}
	{
		r3:2 = mpyu(r4,r23)
		r9:8 = sxtw(r2)
		r6 = and(r7,#-64)
		memw(r29+#24) = r6.new
	}
	{
		r3 += mpyi(r23,r5)
	}
	{
		p1 = cmp.eq(r3:2,r9:8)
		if (!p1.new) jump:t .LBB21_30
	}
// %bb.26:                              // %lor.lhs.false47
	{
		r4 = memw(r29+#288)
		if (!cmp.gt(r4.new,#11)) jump:nt .LBB21_30
	}
// %bb.27:                              // %lor.lhs.false47
	{
		r4 = memw(r29+#280)
	}
	{
		r1:0 = sxtw(r4)
	}
	{
		p0 = cmp.eq(r3:2,r1:0)
		if (p0.new) r6 = add(r26,#0)
		if (!p0.new) jump:nt .LBB21_30
	}
// %bb.28:                              // %lor.lhs.false54
	{
		r2 = memw(r29+#272)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB21_43
	}
// %bb.29:                              // %lor.lhs.false54
	{
		p1 = cmp.eq(r2,r16); if (p1.new) jump:nt .LBB21_43
	}
	.falign
.LBB21_30:                              // %do.body60
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_41
	}
// %bb.31:                              // %if.else64
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #902
	}
	{
		r3 = add(pc,##.L.str.15@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.32:                              // %if.else64
	{
		r16 = add(r22,#-32767)
		jump .LBB21_40
	}
	.falign
.LBB21_33:                              // %do.body30
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_38
	}
// %bb.34:                              // %if.else34
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #895
	}
	{
		r3 = add(pc,##.L.str.14@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.35:                              // %if.else34
	{
		r16 = add(r22,#-32767)
		jump .LBB21_40
	}
	.falign
.LBB21_36:                              // %if.then6
	{
		r3 = add(pc,##.L.str.13@PCREL)
		call _HAP_debug_v2
		r2 = #885
	}
	.falign
// %bb.37:                              // %if.then6
	{
		jump .LBB21_40
	}
	.falign
.LBB21_38:                              // %if.then33
	{
		r3 = add(pc,##.L.str.14@PCREL)
		call _HAP_debug_v2
		r2 = #895
	}
	.falign
// %bb.39:                              // %if.then33
	{
		r16 = add(r22,#-32767)
	}
	.falign
.LBB21_40:                              // %cleanup117
	{
		r0 = r16
		r17:16 = memd(r29+#224)
		r19:18 = memd(r29+#216)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#208)
		r23:22 = memd(r29+#200)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#192)
		r27:26 = memd(r29+#184)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB21_41:                              // %if.then63
	{
		r3 = add(pc,##.L.str.15@PCREL)
		call _HAP_debug_v2
		r2 = #902
	}
	.falign
// %bb.42:                              // %if.then63
	{
		r16 = add(r22,#-32767)
		jump .LBB21_40
	}
	.falign
.LBB21_43:                              // %if.end68
	{
		r7 = mpyi(r23,r16)
		r8 = add(r29,#88)
		r3 = memw(r29+#268)
		memw(r29+#52) = #0
	}
	{
		r4 = mux(p0,#0,r3)
		r2 = memw(r29+#276)
		memw(r29+#40) = r2.new
	}
	{
		r2 = add(r29,#56)
		r3 = memw(r29+#260)
		memw(r29+#28) = r3.new
	}
	{
		r3 = add(r29,#12)
		r4 = add(r29,#28)
		r0 = memw(r24+#0)
		memw(r29+#36) = r4
	}
	{
		r1 = memw(r24+#8)
		memw(r29+#32) = r7
	}
	{
		r5 = memw(r24+##421404)
		memw(r29+#0) = r8

	} :mem_noshuf
	{
		call hexkl_attn_q_prefill
		memw(r29+#44) = r7
		memw(r29+#48) = r6
	}
	.falign
// %bb.44:                              // %if.end68
	{
		r16 = r0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB21_48
		if (p1.new) r5:4 = memd(r29+#168)
	}
// %bb.45:                              // %do.body80
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_49
	}
// %bb.46:                              // %if.else84
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #917
	}
	{
		r3 = add(pc,##.L.str.16@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r16
	}
	.falign
// %bb.47:                              // %if.else84
	{
		jump .LBB21_40
	}
	.falign
.LBB21_48:                              // %if.end88
	{
		r7:6 = combine(r4,r5)
		r8 = ##-481036337
		r2 = memw(r29+#284)
	}
	{
		r7:6 = vlsrw(r7:6,#3)
		r3 = ##549755813
		r4 = memw(r29+#176)
	}
	{
		r7 = insert(r5,#3,#29)
		r1:0 = memd(r29+#96)
		r13:12 = memd(r29+#88)
	}
	{
		r15:14 = memd(r29+#112)
		memw(r2+#4) = r0
	}
	{
		r1:0 = mpyu(r7,r8)
		memw(r2+#0) = r12
		memw(r2+#12) = r14
	}
	{
		r1:0 = combine(#0,r1)
		r15:14 = memd(r29+#120)
		r11:10 = memd(r29+#104)
	}
	{
		r15:14 = mpyu(r7,r3)
		memw(r2+#16) = r14
		memw(r2+#36) = r4
	}
	{
		r13:12 = combine(r1,r0)
		r0 = r14
		r11:10 = memd(r29+#128)
		memw(r2+#8) = r10
	}
	{
		r13:12 += mpyu(r6,r8)
		r11:10 = memd(r29+#136)
		memw(r2+#20) = r10
	}
	{
		r13:12 = add(r13:12,r1:0)
		r11:10 = memd(r29+#144)
		memw(r2+#24) = r10
	}
	{
		r0 = r13
		memw(r2+#28) = r10
	}
	{
		r9:8 = combine(r1,r0)
		r0 = r15
	}
	{
		r9:8 += mpyu(r6,r3)
		r7:6 = memd(r29+#152)
	}
	{
		r1:0 = add(r9:8,r1:0)
		r7:6 = memd(r29+#160)
		memw(r2+#32) = r6
	}
	{
		r1:0 = lsr(r1:0,#4)
		memw(r2+#40) = r6
	}
	{
		jump .LBB21_40
		memw(r2+#44) = r0
	}
	.falign
.LBB21_49:                              // %if.then83
	{
		r3 = add(pc,##.L.str.16@PCREL)
		r2 = #917
		memw(r29+#0) = r16
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.50:                              // %if.then83
	{
		jump .LBB21_40
	}
.Lfunc_end21:
	.size	nntr_hvx_attn_q_prefill, .Lfunc_end21-nntr_hvx_attn_q_prefill
                                        // -- End function
	.falign
	.type	hexkl_attn_q_tiling_init,@function // -- Begin function hexkl_attn_q_tiling_init
hexkl_attn_q_tiling_init:               // @hexkl_attn_q_tiling_init
// %bb.0:                               // %entry
	{
		r16 = r0
		p0 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r0 = #-1
		if (p0) jump:nt .LBB22_10
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB22_10
	}
// %bb.2:                               // %lor.lhs.false2.i
	{
		r19 = memw(r16+#0)
		if (cmp.eq(r19.new,#0)) jump:nt .LBB22_10
	}
// %bb.3:                               // %lor.lhs.false3.i
	{
		r17 = memw(r16+#12)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB22_10
	}
// %bb.4:                               // %lor.lhs.false5.i
	{
		r3 = #511
		r18 = memw(r16+#16)
		if (cmp.eq(r18.new,#0)) jump:nt .LBB22_10
	}
// %bb.5:                               // %lor.lhs.false7.i
	{
		r2 = memw(r16+#20)
	}
	{
		r3 = add(r2,#-1)
		if (cmp.gtu(r3.new,r3)) jump:nt .LBB22_10
	}
// %bb.6:                               // %lor.lhs.false7.i
	{
		r20 = r1
		r2 = and(r2,#31)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB22_10
	}
// %bb.7:                               // %lor.lhs.false15.i
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.8:                               // %lor.lhs.false15.i
	{
		r17 -= mpyi(r0,r18)
		r3 = r0
		if (cmp.eq(r17.new,#0)) jump:nt .LBB22_11
	}
// %bb.9:
	{
		r0 = #-1
	}
	.falign
.LBB22_10:                              // %hexkl_attn_f16_tiling_init_aligned.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB22_11:                              // %lor.lhs.false20.i
	{
		r0 = #-1
		r2 = memw(r16+#4)
		r4 = memw(r16+#8)
	}
	{
		r2 = add(r2,r19)
		if (cmp.gtu(r2.new,r4)) jump:t .LBB22_10
	}
// %bb.12:                              // %if.end.i
	{
		r2 = r20
		r4 = memw(r20+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB22_10
	}
// %bb.13:                              // %lor.lhs.false26.i
	{
		r5 = memw(r20+#4)
	}
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB22_10
	}
// %bb.14:                              // %lor.lhs.false26.i
	{
		r4 = add(#63,mpyi(r3,r4))
		r5 = and(r5,#31)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB22_10
	}
// %bb.15:                              // %if.end33.i
	{
		r0 = #0
		memw(r2+#8) = r3
	}
	{
		r3 = and(r4,#-64)
		r17:16 = memd(r29+#16)
		memw(r2+#12) = r3.new
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#8)
		r21:20 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end22:
	.size	hexkl_attn_q_tiling_init, .Lfunc_end22-hexkl_attn_q_tiling_init
                                        // -- End function
	.globl	nntr_hvx_attn_q_decode          // -- Begin function nntr_hvx_attn_q_decode
	.falign
	.type	nntr_hvx_attn_q_decode,@function
nntr_hvx_attn_q_decode:                 // @nntr_hvx_attn_q_decode
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) r17 = add(r5,#0)
		memd(r29+#-16) = r17:16
		allocframe(#112)
	}                                       // 8-byte Folded Spill
	{
		r20 = ##-2147449843
		memd(r29+#88) = r21:20
		memd(r29+#96) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r16 = add(r20,#-32767)
		if (!p1) r19:18 = combine(r3,r4)
		if (p1) jump:nt .LBB23_19
		memd(r29+#80) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r0 = add(r0,##409628)
		r22 = r0
		r1 = r2
	}
	{
		call hexkl_kv_q_get
	}
	.falign
// %bb.2:                               // %if.end
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB23_4
	}
// %bb.3:                               // %lor.lhs.false
	{
		r2 = memw(r0+#16)
		if (!cmp.gtu(r17,r2.new)) jump:t .LBB23_7
	}
	.falign
.LBB23_4:                               // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_15
	}
// %bb.5:                               // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #947
	}
	{
		r3 = add(pc,##.L.str.17@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.6:                               // %if.else
	{
		jump .LBB23_19
	}
	.falign
.LBB23_7:                               // %if.end8
	{
		r2 = memw(r29+#120)
		memw(r29+#52) = r2.new
	}
	{
		r3 = memw(r0+#24)
		memw(r29+#60) = r3.new
	}
	{
		r7:6 = mpyu(r2,r19)
		r4 = memw(r29+#136)
		r5 = memw(r29+#124)
	}
	{
		r9:8 = sxtw(r4)
		r4 = memw(r0+#20)
		memw(r29+#64) = r5
	}
	{
		r5:4 = mpyu(r6,r3)
		r6 = memw(r29+#128)
		memw(r29+#56) = r4
	}
	{
		r5 += mpyi(r3,r7)
		memw(r29+#40) = r19
		memw(r29+#44) = r18
	}
	{
		p1 = cmp.eq(r5:4,r9:8)
		if (!p1.new) jump:t .LBB23_12
		memw(r29+#48) = r17
		memw(r29+#68) = r6
	}
// %bb.8:                               // %lor.lhs.false25
	{
		r6 = memw(r29+#160)
		if (!cmp.gt(r6.new,#1)) jump:nt .LBB23_12
	}
// %bb.9:                               // %lor.lhs.false25
	{
		r6 = memw(r29+#152)
	}
	{
		r7:6 = sxtw(r6)
	}
	{
		p1 = cmp.eq(r5:4,r7:6)
		if (!p1.new) jump:nt .LBB23_12
		if (p1.new) r4 = memw(r29+#144)
	}
// %bb.10:                              // %lor.lhs.false32
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB23_20
	}
// %bb.11:                              // %lor.lhs.false32
	{
		p1 = cmp.eq(r4,r2); if (p1.new) jump:nt .LBB23_20
	}
	.falign
.LBB23_12:                              // %do.body38
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_17
	}
// %bb.13:                              // %if.else42
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #955
	}
	{
		r3 = add(pc,##.L.str.18@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.14:                              // %if.else42
	{
		r16 = add(r20,#-32767)
		jump .LBB23_19
	}
	.falign
.LBB23_15:                              // %if.then6
	{
		r3 = add(pc,##.L.str.17@PCREL)
		call _HAP_debug_v2
		r2 = #947
	}
	.falign
// %bb.16:                              // %if.then6
	{
		jump .LBB23_19
	}
	.falign
.LBB23_17:                              // %if.then41
	{
		r3 = add(pc,##.L.str.18@PCREL)
		call _HAP_debug_v2
		r2 = #955
	}
	.falign
// %bb.18:                              // %if.then41
	{
		r16 = add(r20,#-32767)
	}
	.falign
.LBB23_19:                              // %cleanup78
	{
		r0 = r16
		r17:16 = memd(r29+#104)
		r19:18 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#88)
		r23:22 = memd(r29+#80)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB23_20:                              // %if.end46
	{
		r2 = mpyi(r3,r2)
		r7:6 = combine(#0,#0)
		r4 = memw(r29+#148)
		memw(r29+#24) = r4.new
	}
	{
		r4 = memw(r29+#140)
		memw(r29+#16) = r2
	}
	{
		r3 = mux(p0,#0,r4)
		r5 = memw(r29+#132)
		memw(r29+#12) = r5.new
	}
	{
		memw(r29+#36) = #0
		memw(r29+#20) = r3
	}
	{
		memw(r29+#28) = r2
		memw(r29+#32) = r0
	}
	{
		memd(r29+#72) = r7:6
	}
	//# InlineAsm Start
	{
		r19:18 = c15:14
	}
	//# InlineAsm End
	{
		r0 = add(r29,#40)
		r1 = add(r29,#12)
		r2 = memw(r22+##421404)
	}
	{
		call hvx_attn_decode_q
		r3 = add(r29,#72)
	}
	.falign
// %bb.21:                              // %if.end46
	{
		r16 = r0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB23_25
		if (p1.new) r2 = memw(r29+#156)
	}
// %bb.22:                              // %do.body59
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_26
	}
// %bb.23:                              // %if.else63
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #970
	}
	{
		r3 = add(pc,##.L.str.19@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r16
	}
	.falign
// %bb.24:                              // %if.else63
	{
		jump .LBB23_19
	}
	.falign
.LBB23_25:                              // %if.end67
	{
		r1:0 = memd(r29+#72)
	}
	{
		memw(r2+#0) = r0
	}
	//# InlineAsm Start
	{
		r1:0 = c15:14
	}
	//# InlineAsm End
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = ##-481036337
	}
	{
		r6 = ##549755813
		r5:4 = combine(r0,r1)
	}
	{
		r5:4 = vlsrw(r5:4,#3)
	}
	{
		r5 = insert(r1,#3,#29)
	}
	{
		r13:12 = mpyu(r5,r3)
		r1:0 = mpyu(r5,r6)
	}
	{
		r9:8 = combine(#0,r13)
	}
	{
		r13:12 = combine(r9,r8)
		r8 = r0
	}
	{
		r13:12 += mpyu(r4,r3)
	}
	{
		r13:12 = add(r13:12,r9:8)
	}
	{
		r8 = r13
	}
	{
		r13:12 = combine(r9,r8)
		r8 = r1
	}
	{
		r13:12 += mpyu(r4,r6)
	}
	{
		r1:0 = add(r13:12,r9:8)
	}
	{
		r1:0 = lsr(r1:0,#4)
	}
	{
		jump .LBB23_19
		memw(r2+#4) = r0
	}
	.falign
.LBB23_26:                              // %if.then62
	{
		r3 = add(pc,##.L.str.19@PCREL)
		r2 = #970
		memw(r29+#0) = r16
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.27:                              // %if.then62
	{
		jump .LBB23_19
	}
.Lfunc_end23:
	.size	nntr_hvx_attn_q_decode, .Lfunc_end23-nntr_hvx_attn_q_decode
                                        // -- End function
	.globl	nntr_hvx_attn_q_step            // -- Begin function nntr_hvx_attn_q_step
	.falign
	.type	nntr_hvx_attn_q_step,@function
nntr_hvx_attn_q_step:                   // @nntr_hvx_attn_q_step
// %bb.0:                               // %entry
	{
		r17 = ##-2147449843
		memd(r29+#-16) = r17:16
		allocframe(r29,#336):raw
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r0,#0)
		r25 = add(r17,#-32767)
		memd(r29+#296) = r25:24
		memd(r29+#320) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r21 = add(r0,##409628)
		memd(r29+#312) = r21:20
		memd(r29+#304) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r18 = add(r0,#0)
		if (!p0) r23:22 = combine(r3,r5)
		if (p0) jump:nt .LBB24_19
		memd(r29+#288) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		call hexkl_kv_q_get
		r26 = r4
		r1:0 = combine(r2,r21)
		r20 = r2
	}
	.falign
// %bb.2:                               // %if.end
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB24_12
	}
// %bb.3:                               // %lor.lhs.false
	{
		r27 = memw(r29+#404)
		if (!cmp.gt(r27.new,#7)) jump:nt .LBB24_12
	}
// %bb.4:                               // %lor.lhs.false
	{
		r19 = memw(r29+#360)
	}
	{
		r2 = memw(r0+#16)
		if (cmp.gtu(r19,r2.new)) jump:nt .LBB24_12
	}
// %bb.5:                               // %if.end11
	{
		r3:2 = combine(#0,#0)
		memw(r29+#176) = #0
	}
	{
		memd(r29+#168) = r3:2
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		p1 = cmp.gt(r22,#-1); if (!p1.new) jump:nt .LBB24_9
		memd(r29+#144) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.6:                               // %if.end11
	{
		r2 = memw(r29+#348)
		if (!cmp.eq(r2.new,r22)) jump:nt .LBB24_9
	}
// %bb.7:                               // %lor.lhs.false18
	{
		r16 = memw(r0+#20)
		memw(r29+#16) = r0
	}                                       // 4-byte Folded Spill
	{
		r25 = memw(r0+#24)
	}
	{
		r24 = mpyi(r25,r16)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r22)
	}
	.falign
// %bb.8:                               // %lor.lhs.false18
	{
		r3 = r22
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r3 -= mpyi(r0,r24)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_20
	}
	.falign
.LBB24_9:                               // %do.body22
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_17
	}
// %bb.10:                              // %if.else26
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #1001
	}
	{
		r3 = add(pc,##.L.str.21@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.11:                              // %if.else26
	{
		r25 = add(r17,#-32767)
		jump .LBB24_19
	}
	.falign
.LBB24_12:                              // %do.body
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_15
	}
// %bb.13:                              // %if.else
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #992
	}
	{
		r3 = add(pc,##.L.str.20@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.14:                              // %if.else
	{
		jump .LBB24_19
	}
	.falign
.LBB24_15:                              // %if.then9
	{
		r3 = add(pc,##.L.str.20@PCREL)
		call _HAP_debug_v2
		r2 = #992
	}
	.falign
// %bb.16:                              // %if.then9
	{
		jump .LBB24_19
	}
	.falign
.LBB24_17:                              // %if.then25
	{
		r3 = add(pc,##.L.str.21@PCREL)
		call _HAP_debug_v2
		r2 = #1001
	}
	.falign
// %bb.18:                              // %if.then25
	{
		r25 = add(r17,#-32767)
	}
	.falign
.LBB24_19:                              // %cleanup278
	{
		r0 = r25
		r19:18 = memd(r29+#320)
		r17:16 = memd(r29+#328)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#312)
		r23:22 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#296)
		r27:26 = memd(r29+#288)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB24_20:                              // %if.end30
	{
		r12 = memw(r29+#352)
		r13 = memw(r29+#364)
	}
	{
		r14 = memw(r29+#396)
		r28 = memw(r29+#380)
	}
	{
		r4 = mpyi(r13,r12)
		r3 = memw(r29+#392)
		memw(r29+#36) = r3.new
	}
	{
		r3 = add(r12,#-128)
		r9 = memw(r29+#376)
		r15 = memw(r29+#368)
	}
	{
		r6 = mpyi(r4,r25)
		r4 = #0
		p1 = cmp.gtu(r3,##3968)
	}
	{
		r8 = asl(r6,#2)
		if (p1) r3 = add(r23,#0)
		r1 = memw(r29+#356)
		r10 = memw(r29+#344)
	}
	{
		if (p1) r5:4 = combine(r26,r18)
		memw(r29+#40) = r4
		memw(r29+#48) = r8
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB24_39
		memw(r29+#44) = r9
	}                                       // 4-byte Folded Spill
// %bb.21:                              // %land.lhs.true40
	{
		r5 = and(r3,#127)
		r4 = r1
		r3 = r23
	}
	{
		r4 |= or(r5,r23)
	}
	{
		r5:4 = combine(r26,r18)
		p0 = cmp.eq(r4,#0); if (!p0.new) jump:t .LBB24_39
	}
// %bb.22:                              // %land.lhs.true50
	{
		p1 = cmp.eq(r19,r12)
		if (!p1.new) jump:nt .LBB24_39
	}
// %bb.23:                              // %land.lhs.true50
	{
		p0 = cmp.eq(r13,#32)
		if (!p0.new) jump:nt .LBB24_39
	}
// %bb.24:                              // %land.lhs.true50
	{
		p1 = cmp.eq(r16,#8); if (!p1.new) jump:nt .LBB24_39
	}
// %bb.25:                              // %land.lhs.true50
	{
		p0 = cmp.eq(r25,#64)
		if (!p0.new) jump:nt .LBB24_39
	}
// %bb.26:                              // %land.lhs.true64
	{
		r7 = memb(r2+#4)
		if (!cmp.eq(r7.new,#0)) jump:t .LBB24_39
	}
// %bb.27:                              // %land.lhs.true68
	{
		r7 = memw(r2+#72)
	}
	{
		r7 = or(r7,r15)
		if (!cmp.eq(r7.new,#0)) jump:nt .LBB24_39
	}
// %bb.28:                              // %land.lhs.true68
	{
		r7 = mpyi(r24,r19)
		if (!cmp.eq(r7.new,r22)) jump:nt .LBB24_39
	}
// %bb.29:                              // %land.lhs.true68
	{
		p0 = cmp.eq(r6,r28)
		if (!p0.new) jump:nt .LBB24_39
	}
// %bb.30:                              // %land.lhs.true80
	{
		p1 = cmp.eq(r10,#0)
		if (p1.new) jump:nt .LBB24_39
	}
// %bb.31:                              // %land.lhs.true80
	{
		p1 = cmp.eq(r14,r28)
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB24_39
	}
// %bb.32:                              // %land.lhs.true80
	{
		r6 = memw(r29+#36)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB24_39
	}                                       // 4-byte Folded Reload
// %bb.33:                              // %land.lhs.true80
	{
		p0 = cmp.eq(r9,#0)
		if (p0.new) jump:nt .LBB24_39
		if (!p0.new) memw(r29+#60) = r10
		if (!p0.new) memw(r29+#32) = r1
	}                                       // 4-byte Folded Spill
// %bb.34:                              // %land.lhs.true80
	{
		if (!p1) r5 = add(r26,#0)
		memw(r29+#52) = r15
		memw(r29+#24) = r13
	}                                       // 4-byte Folded Spill
	{
		if (p1) r0 = add(r4,##421792)
		memw(r29+#20) = r12
		memw(r29+#152) = r0
	}                                       // 4-byte Folded Spill
	{
		if (!p1) jump:nt .LBB24_88
		memw(r29+#28) = r14
		memw(r29+#56) = r28
	}                                       // 4-byte Folded Spill
// %bb.35:                              // %land.lhs.true91
	{
		r25 = asl(r22,#1)
	}
	{
		r2 = add(r8,r25)
	}
	{
		call hexkl_moe_scratch_reserve
		r1 = asl(r2,#1)
	}
	.falign
// %bb.36:                              // %land.lhs.true91
	{
		r3 = r23
		r5:4 = combine(r26,r18)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB24_83
	}
// %bb.37:
	{
		r0 = memw(r29+#152)
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r13 = memw(r29+#24)
		r12 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r14 = memw(r29+#28)
		r15 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r28 = memw(r29+#56)
		r1 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r10 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_39:                              // %if.end101
	{
		r26 = add(r4,##421404)
		p1 = cmp.eq(r22,#0); if (p1.new) jump:nt .LBB24_46
	}
// %bb.40:                              // %if.then104
	{
		r1:0 = combine(r24,r22)
		r23:22 = combine(r28,r3)
		memw(r29+#152) = r0
		memw(r29+#32) = r1
	}                                       // 4-byte Folded Spill
	{
		r25:24 = combine(r10,r5)
		r16 = r15
		memw(r29+#20) = r12
		memw(r29+#24) = r13
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#28) = r14
	}                                       // 4-byte Folded Spill
	.falign
// %bb.41:                              // %if.then104
	{
		r3 = r0
		r1:0 = combine(r20,r21)
		r2 = memw(r18+#0)
		r4 = memw(r26+#0)
	}
	{
		r2 = add(r29,#168)
		r5:4 = combine(r25,r24)
		memw(r29+#0) = r2
		memw(r29+#4) = r4
	}
	{
		call hexkl_kv_q_append_pool
		r2 = r22
		memw(r29+#8) = r2
	}
	.falign
// %bb.42:                              // %if.then104
	{
		r25 = r0
		r28 = r23
		r14 = memw(r29+#28)
		r12 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r15 = r16
		p0 = cmp.eq(r25,#0)
		r13 = memw(r29+#24)
		r1 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB24_46
		r2 = memw(r29+#16)
		r0 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
// %bb.43:                              // %do.body111
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_60
	}
// %bb.44:                              // %if.else115
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #1036
	}
	{
		r3 = add(pc,##.L.str.22@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r25
	}
	.falign
// %bb.45:                              // %if.else115
	{
		jump .LBB24_19
	}
	.falign
.LBB24_46:                              // %if.end120
	{
		r3 = memw(r29+#372)
	}
	//# InlineAsm Start
	{
		r11:10 = c31:30
	}
	//# InlineAsm End
	{
		r7:6 = mpyu(r13,r12)
		r9:8 = sxtw(r28)
		r16 = memw(r2+#24)
		r20 = memw(r2+#20)
	}
	{
		memw(r29+#132) = r16
		memw(r29+#116) = r1
	}
	{
		r5:4 = mpyu(r6,r16)
		memw(r29+#112) = r12
		memw(r29+#120) = r19
	}
	{
		r5 += mpyi(r16,r7)
		memw(r29+#124) = r13
		memw(r29+#128) = r20
	}
	{
		p0 = cmp.eq(r5:4,r9:8)
		if (!p0.new) jump:nt .LBB24_50
		memw(r29+#136) = r15
		memw(r29+#140) = r3
	}
// %bb.47:                              // %if.end120
	{
		r7:6 = sxtw(r14)
	}
	{
		p1 = cmp.eq(r5:4,r7:6)
		if (!p1.new) jump:nt .LBB24_50
		if (p1.new) r3 = memw(r29+##388)
	}
// %bb.48:                              // %lor.lhs.false145
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB24_55
	}
// %bb.49:                              // %lor.lhs.false145
	{
		p1 = cmp.eq(r3,r13)
		if (p1.new) jump:nt .LBB24_55
	}
	.falign
.LBB24_50:                              // %do.body152
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_53
	}
// %bb.51:                              // %if.else156
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #1047
	}
	{
		r3 = add(pc,##.L.str.23@PCREL)
		call HAP_debug_v2
	}
	.falign
// %bb.52:                              // %if.else156
	{
		r25 = add(r17,#-32767)
		jump .LBB24_19
	}
	.falign
.LBB24_53:                              // %if.then155
	{
		r3 = add(pc,##.L.str.23@PCREL)
		call _HAP_debug_v2
		r2 = #1047
	}
	.falign
// %bb.54:                              // %if.then155
	{
		r25 = add(r17,#-32767)
		jump .LBB24_19
	}
	.falign
.LBB24_55:                              // %if.end160
	{
		r25:24 = combine(r13,r0)
		r21 = r12
		r4 = memw(r29+#44)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r5 = mux(p0,#0,r3)
		r6 = memw(r29+#40)
		memw(r29+#92) = r5.new
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r6,#0)
		r23 = ##-1431622999
		r3 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r4 = mpyi(r16,r13)
		r2 = p1
		r5 = r2
		memw(r29+#84) = r4
	}
	{
		if (!p1) r3 = add(r6,#0)
		r1 = #0
		r0 = add(r29,#184)
		memw(r29+#16) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = #96
		r3 = !cmp.eq(r6,#0)
		memw(r29+#96) = r3
		memd(r29+#152) = r11:10
	}                                       // 8-byte Folded Spill
	{
		r22 = add(r23,#-32766)
		memw(r29+#88) = r4
		memw(r29+#100) = r4
	}
	{
		call memset
		memw(r29+#104) = r5
		memw(r29+#108) = r3
	}
	.falign
// %bb.56:                              // %if.end160
	{
		r6 = r21
		p1 = cmp.gtu(r21,#4); if (p1.new) jump:nt .LBB24_62
	}
// %bb.57:                              // %if.end160
	{
		p0 = cmp.gtu(r16,#128)
		if (p0.new) jump:nt .LBB24_62
		r1 = add(r29,#84)
		r0 = add(r29,#112)
	}
// %bb.58:                              // %if.then181
	{
		r3 = #0
		r2 = memw(r26+#0)
	}
	{
		call hvx_attn_decode_q
		r26 = #0
	}
	.falign
// %bb.59:                              // %if.then181
	{
		r25 = r0
		jump .LBB24_71
	}
	.falign
.LBB24_60:                              // %if.then114
	{
		r3 = add(pc,##.L.str.22@PCREL)
		r2 = #1036
		memw(r29+#0) = r25
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.61:                              // %if.then114
	{
		jump .LBB24_19
	}
	.falign
.LBB24_62:                              // %if.else184
	{
		r2 = add(r20,#-1)
		memw(r29+#80) = #0
		memw(r29+#76) = #0
	}
	{
		p1 = cmp.gtu(r25,r2)
		r2 = #64
		if (p1.new) r1:0 = combine(r20,r25)
		if (!p1.new) jump:t .LBB24_66
	}
// %bb.63:                              // %cond.end.thread.i
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.64:                              // %cond.end.thread.i
	{
		r16 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,#64)
	}
	.falign
// %bb.65:                              // %cond.end.thread.i
	{
		p0 = cmp.gtu(r16,#64)
		r2 = r0
		r6 = r21
	}
	{
		if (p0) r2 = #1
	}
	.falign
.LBB24_66:                              // %hexkl_attn_f16_choose_tiling.exit
	{
		r3 = mpyu(r19,r22)
		r2 = minu(r2,r6)
		p0 = cmp.gtu(r19,#63)
		p1 = cmp.gtu(r19,#191)
	}
	{
		r3 = and(##2147483584,lsr(r3,#1))
		r4 = #256
		r0 = add(r29,#112)
	}
	{
		r5 = mux(p0,#64,#32)
		r1 = add(r29,#68)
		memw(r29+#68) = r2
	}
	{
		if (!p1) r3 = add(r5,#0)
	}
	{
		r2 = minu(r3,r4)
		call hexkl_attn_q_tiling_init
		memw(r29+#72) = r2.new
	}
	.falign
// %bb.67:                              // %hexkl_attn_f16_choose_tiling.exit
	{
		r25 = add(r17,#-32767)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB24_19
		if (p1.new) r0 = memw(r18+#0)
	}
	.falign
// %bb.69:                              // %cleanup199.thread
	{
		r6 = add(r29,#184)
		p1 = cmp.gtu(r27,#19)
		r3 = add(r29,#68)
		r2 = add(r29,#112)
	}
	{
		r4 = add(r29,#84)
		r1 = memw(r18+#8)
		r5 = memw(r26+#0)
	}
	{
		if (!p1) r6 = #0
	}
	{
		call hexkl_attn_q_prefill
		memw(r29+#0) = r6
	}
	.falign
// %bb.70:                              // %cleanup199.thread
	{
		r25 = r0
		r26 = #1
	}
	.falign
.LBB24_71:                              // %if.end202
	{
		r3:2 = combine(#10,r24)
		r5:4 = combine(#0,#10)
		p0 = cmp.eq(r25,#0)
		if (p0.new) jump:nt .LBB24_75
	}
// %bb.72:                              // %do.body206
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##HAP_debug_v2@GOT)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_81
	}
// %bb.73:                              // %if.else210
	{
		r1 = add(pc,##.L.str@PCREL)
		r0 = #3
		r2 = #1077
	}
	{
		r3 = add(pc,##.L.str.24@PCREL)
		call HAP_debug_v2
		memw(r29+#0) = r25
	}
	.falign
// %bb.74:                              // %if.else210
	{
		jump .LBB24_19
	}
	.falign
.LBB24_75:                              // %if.end214
	{
		r17 = add(r23,#-32767)
		r7:6 = memd(r29+#152)
		r9:8 = memd(r29+#144)
	}                                       // 8-byte Folded Reload
	{
		r16 = memw(r29+#400)
	}
	{
		r11:10 = mpyu(r6,r4)
		r15:14 = mpyu(r8,r3)
		r3 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r11 += mpyi(r7,#10)
		r15 += mpyi(r9,#10)
	}
	{
		r7:6 = mpyu(r10,r22)
		r1:0 = mpyu(r14,r22)
	}
	{
		r7:6 = mpyu(r10,r17)
		p0 = r3
		r4 = r7
		r1:0 = combine(#0,r1)
	}
	{
		r13:12 = combine(r5,r4)
		r4 = r6
		r19:18 = combine(r1,r0)
	}
	{
		r13:12 += mpyu(r11,r22)
		r19:18 += mpyu(r15,r22)
	}
	{
		r13:12 = mpyu(r14,r17)
		r9:8 = add(r13:12,r5:4)
	}
	{
		r0 = r12
		r4 = r9
	}
	{
		r19:18 = add(r19:18,r1:0)
		r9:8 = combine(r5,r4)
		r4 = r7
	}
	{
		r9:8 += mpyu(r11,r17)
		r0 = r19
	}
	{
		r5:4 = add(r9:8,r5:4)
		r11:10 = combine(r1,r0)
		r0 = r13
	}
	{
		r11:10 += mpyu(r15,r17)
		r19:18 = lsr(r5:4,#7)
	}
	{
		r1:0 = add(r11:10,r1:0)
	}
	{
		r21:20 = lsr(r1:0,#7)
		if (p0) jump:nt .LBB24_79
	}
// %bb.76:                              // %if.then216
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.77:                              // %if.then216
	{
		r3 = #0
		r4 = #0
		r0 = memw(r29+#36)
		r1 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_moe_dma_copy
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.78:                              // %if.then216
	{
		r2 = r24
	}
	.falign
.LBB24_79:                              // %if.end217
	//# InlineAsm Start
	{
		r5:4 = c31:30
	}
	//# InlineAsm End
	{
		r1:0 = sub(r19:18,r21:20)
		p0 = cmp.gtu(r27,#19)
		r3 = #10
		memw(r16+#28) = r2
	}
	{
		r1:0 = mpyu(r4,r3)
		r3 = memw(r29+#176)
		memw(r16+#0) = r0
	}
	{
		r1 += mpyi(r5,#10)
		memw(r16+#24) = r3
		memw(r16+#8) = r26
	}
	{
		r7:6 = mpyu(r0,r22)
		r5:4 = mpyu(r0,r17)
		r0 = memw(r29+#168)
		memw(r16+#16) = r0.new
	}
	{
		r25:24 = combine(#0,r7)
		if (p0) r8 = ##-481036337
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r4
		r4 = memw(r29+#172)
		memw(r16+#20) = r4.new
	}
	{
		r7:6 += mpyu(r1,r22)
		if (p0) r11:10 = memd(r29+#200)
		if (p0) r15:14 = memd(r29+#216)
	}
	{
		r7:6 = add(r7:6,r25:24)
		if (p0) r13:12 = memd(r29+#208)
		if (p0) memw(r16+#40) = r10
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r5
		if (p0) r11:10 = memd(r29+#224)
		if (p0) memw(r16+#48) = r14
	}
	{
		r7:6 += mpyu(r1,r17)
		if (p0) r15:14 = memd(r29+#240)
		if (p0) memw(r16+#52) = r10
	}
	{
		r1:0 = add(r7:6,r25:24)
		if (p0) r7:6 = memd(r29+#184)
		if (p0) memw(r16+#60) = r14
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	{
		r3:2 = sub(r1:0,r19:18)
		r1:0 = sub(r1:0,r21:20)
	}
	{
		if (!p0) jump:nt .LBB24_19
		memw(r16+#4) = r2
		memw(r16+#12) = r0
	}
// %bb.80:                              // %if.then236
	{
		r3:2 = memd(r29+#264)
	}
	{
		r1:0 = combine(r2,r3)
		r7:6 = memd(r29+#192)
		memw(r16+#32) = r6
	}
	{
		r1:0 = vlsrw(r1:0,#3)
		r2 = ##549755813
		memw(r16+#36) = r6
	}
	{
		r1 = insert(r3,#3,#29)
		r4 = memw(r29+#272)
		memw(r16+#68) = r4.new
	}
	{
		r7:6 = mpyu(r1,r8)
		r5:4 = mpyu(r1,r2)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r4
		r13:12 = memd(r29+#232)
		memw(r16+#44) = r12
	}
	{
		r7:6 += mpyu(r0,r8)
		memw(r16+#56) = r12
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r5
	}
	{
		r7:6 += mpyu(r0,r2)
		r3:2 = memd(r29+#248)
	}
	{
		r1:0 = add(r7:6,r25:24)
		r3:2 = memd(r29+#256)
		memw(r16+#64) = r2
	}
	{
		r1:0 = lsr(r1:0,#4)
		memw(r16+#72) = r2
	}
	{
		jump .LBB24_19
		memw(r16+#76) = r0
	}
	.falign
.LBB24_81:                              // %if.then209
	{
		r3 = add(pc,##.L.str.24@PCREL)
		r2 = #1077
		memw(r29+#0) = r25
	}
	{
		call _HAP_debug_v2
	}
	.falign
// %bb.82:                              // %if.then209
	{
		jump .LBB24_19
	}
	.falign
.LBB24_83:                              // %if.then96
	{
		r0 = r18
		r16 = memw(r18+##421796)
		memw(r29+#64) = r16.new
	}                                       // 4-byte Folded Spill
	{
		call hexkl_dma_ring_reset
		memd(r29+#160) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
// %bb.84:                              // %if.then96
	{
		call hexkl_moe_dma_copy
		r1:0 = combine(r26,r16)
		r3:2 = combine(#0,r25)
		r4 = #0
	}
	.falign
// %bb.85:                              // %if.then96
	{
		r26 = add(r16,r25)
		r3:2 = combine(#0,r25)
		r4 = #0
		r1 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_moe_dma_copy
		r0 = r26
	}
	.falign
// %bb.86:                              // %if.then96
	{
		r25 = add(r26,r25)
		r4 = #0
		r16 = memw(r29+#48)
		r1 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_moe_dma_copy
		r0 = r25
		r3:2 = combine(#0,r16)
	}
	.falign
// %bb.87:                              // %if.then96
	{
		r2 = add(r25,r16)
		r10 = r26
		r0 = memw(r29+#152)
		memw(r29+#40) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r23
		r2 = memw(r29+#16)
		r5:4 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r13 = memw(r29+#24)
		memw(r29+#44) = r25
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#64)
		r12 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r14 = memw(r29+#28)
		r15 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB24_39
		r28 = memw(r29+#56)
		r1 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_88:
	{
		r3 = r23
		r0 = memw(r29+#152)
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r13 = memw(r29+#24)
		r12 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r14 = memw(r29+#28)
		r15 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r28 = memw(r29+#56)
		r1 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB24_39
		r10 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
.Lfunc_end24:
	.size	nntr_hvx_attn_q_step, .Lfunc_end24-nntr_hvx_attn_q_step
                                        // -- End function
	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.8,"aMS",@progbits,1
	.p2align	3, 0x0
.L.str:
	.string	"nntr_hvx_attn_q.c"
	.size	.L.str, 18

	.type	.L.str.1,@object                // @.str.1
	.p2align	3, 0x0
.L.str.1:
	.string	"kv_set_fixed_scales_q: bad lengths"
	.size	.L.str.1, 35

	.type	.L.str.2,@object                // @.str.2
	.p2align	3, 0x0
.L.str.2:
	.string	"kv_append_q: bad lengths"
	.size	.L.str.2, 25

	.type	.L.str.3,@object                // @.str.3
	.p2align	3, 0x0
.L.str.3:
	.string	"kv_dump_q: bad lengths"
	.size	.L.str.3, 23

	.type	.L.str.4,@object                // @.str.4
	.p2align	3, 0x0
.L.str.4:
	.string	"probe_kv_q_mm: bad lengths"
	.size	.L.str.4, 27

	.type	.L.str.5,@object                // @.str.5
	.p2align	3, 0x0
.L.str.5:
	.string	"probe_cvt: bad lengths"
	.size	.L.str.5, 23

	.type	.L.str.6,@object                // @.str.6
	.p2align	3, 0x0
.L.str.6:
	.string	"attn_q2_prefill: bad lengths"
	.size	.L.str.6, 29

	.type	.L.str.7,@object                // @.str.7
	.p2align	3, 0x0
.L.str.7:
	.string	"attn_q2_prefill: kernel failed: 0x%08x"
	.size	.L.str.7, 39

	.type	.L.str.8,@object                // @.str.8
	.p2align	3, 0x0
.L.str.8:
	.string	"attn_q2_step_fq: bad q_inv or lengths"
	.size	.L.str.8, 38

	.type	.L.str.9,@object                // @.str.9
	.p2align	3, 0x0
.L.str.9:
	.string	"attn_q2_step_fqc: bad handle or lengths"
	.size	.L.str.9, 40

	.type	.L.str.10,@object               // @.str.10
	.p2align	3, 0x0
.L.str.10:
	.string	"attn_q2_step_fqc: fixed scales: 0x%08x"
	.size	.L.str.10, 39

	.type	.L.str.11,@object               // @.str.11
	.p2align	3, 0x0
.L.str.11:
	.string	"probe_softmax_q: bad lengths"
	.size	.L.str.11, 29

	.type	.L.str.12,@object               // @.str.12
	.p2align	3, 0x0
.L.str.12:
	.string	"probe_softmax_q16: bad lengths"
	.size	.L.str.12, 31

	.type	.L.str.13,@object               // @.str.13
	.p2align	3, 0x0
.L.str.13:
	.string	"attn_q_prefill: bad handle or cache_to"
	.size	.L.str.13, 39

	.type	.L.str.14,@object               // @.str.14
	.p2align	3, 0x0
.L.str.14:
	.string	"attn_q_prefill: bad shape/tiling"
	.size	.L.str.14, 33

	.type	.L.str.15,@object               // @.str.15
	.p2align	3, 0x0
.L.str.15:
	.string	"attn_q_prefill: bad lengths"
	.size	.L.str.15, 28

	.type	.L.str.16,@object               // @.str.16
	.p2align	3, 0x0
.L.str.16:
	.string	"attn_q_prefill: kernel failed: 0x%08x"
	.size	.L.str.16, 38

	.type	.L.str.17,@object               // @.str.17
	.p2align	3, 0x0
.L.str.17:
	.string	"attn_q_decode: bad handle or cache_to"
	.size	.L.str.17, 38

	.type	.L.str.18,@object               // @.str.18
	.p2align	3, 0x0
.L.str.18:
	.string	"attn_q_decode: bad lengths"
	.size	.L.str.18, 27

	.type	.L.str.19,@object               // @.str.19
	.p2align	3, 0x0
.L.str.19:
	.string	"attn_q_decode: kernel failed: 0x%08x"
	.size	.L.str.19, 37

	.type	.L.str.20,@object               // @.str.20
	.p2align	3, 0x0
.L.str.20:
	.string	"attn_q_step: bad handle, cache_to or stats"
	.size	.L.str.20, 43

	.type	.L.str.21,@object               // @.str.21
	.p2align	3, 0x0
.L.str.21:
	.string	"attn_q_step: bad row lengths"
	.size	.L.str.21, 29

	.type	.L.str.22,@object               // @.str.22
	.p2align	3, 0x0
.L.str.22:
	.string	"attn_q_step: append failed: 0x%08x"
	.size	.L.str.22, 35

	.type	.L.str.23,@object               // @.str.23
	.p2align	3, 0x0
.L.str.23:
	.string	"attn_q_step: bad lengths"
	.size	.L.str.23, 25

	.type	.L.str.24,@object               // @.str.24
	.p2align	3, 0x0
.L.str.24:
	.string	"attn_q_step: kernel failed: 0x%08x"
	.size	.L.str.24, 35

	.type	.L.str.25,@object               // @.str.25
	.p2align	3, 0x0
.L.str.25:
	.string	"attn_q2_step: bad handle, cache_to, encodings or stats"
	.size	.L.str.25, 55

	.type	.L.str.26,@object               // @.str.26
	.p2align	3, 0x0
.L.str.26:
	.string	"attn_q2_step: bad row lengths"
	.size	.L.str.26, 30

	.type	.L.str.27,@object               // @.str.27
	.p2align	3, 0x0
.L.str.27:
	.string	"attn_q2_step: append failed: 0x%08x"
	.size	.L.str.27, 36

	.type	.L.str.28,@object               // @.str.28
	.p2align	3, 0x0
.L.str.28:
	.string	"attn_q2_step: bad lengths"
	.size	.L.str.28, 26

	.type	.L.str.29,@object               // @.str.29
	.p2align	3, 0x0
.L.str.29:
	.string	"attn_q2_step: kernel failed: 0x%08x"
	.size	.L.str.29, 36

	.weak	HAP_debug_v2
	.weak	HAP_debug
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym HAP_debug_v2
	.addrsig_sym q2c_worker
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#HAP_debug_v2#(void)#(i32, ptr, i32, ptr, ...)#1##"
	.ascii	"C#q2c_worker#(void)#(i32, i32, ptr)#1##"

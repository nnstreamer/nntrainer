	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hvx_quant_u8.c"
	.globl	hvx_quant_rows_u8_params_rm     // -- Begin function hvx_quant_rows_u8_params_rm
	.falign
	.type	hvx_quant_rows_u8_params_rm,@function
hvx_quant_rows_u8_params_rm:            // @hvx_quant_rows_u8_params_rm
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r2,#0)
		r3 = r1
		r6 = r3
		allocframe(#40)
	}
	{
		r15 = #0
		if (!p0) r28 = add(r5,#0)
		r8 = memw(r29+#60)
		r12 = memw(r29+#52)
	}
	{
		if (!p0) r14 = ##1065353216
		r7 = memw(r29+#64)
		r9 = memw(r29+#56)
	}
	{
		if (p0) jump:nt .LBB0_3
		r13 = memw(r29+#48)
	}
// %bb.1:
	{
		loop0(.LBB0_2,r2)
	}
	{
		r2 = r4
	}
	.falign
.LBB0_2:                                // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r2++#4) = r14
		memw(r28++#4) = r15
	} :endloop0
	.falign
.LBB0_3:                                // %for.cond.cleanup
	{
		r1 = add(pc,##quant_rows_worker@PCREL)
		memw(r29+#4) = r0
		memw(r29+#8) = r1
	}
	{
		r0 = r7
		r2 = add(r29,#4)
		memw(r29+#12) = r6
		memw(r29+#16) = r4
	}
	{
		memw(r29+#20) = r5
		memw(r29+#24) = r13
	}
	{
		memw(r29+#28) = r12
		memw(r29+#32) = r9
	}
	{
		call hvx_worker_pool_run
		memw(r29+#36) = r8
	}
	.falign
// %bb.4:                               // %for.cond.cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end0:
	.size	hvx_quant_rows_u8_params_rm, .Lfunc_end0-hvx_quant_rows_u8_params_rm
                                        // -- End function
	.falign
	.type	quant_rows_worker,@function     // -- Begin function quant_rows_worker
quant_rows_worker:                      // @quant_rows_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#1024):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = memw(r2+#4)
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(#0,r0)
		r17:16 = combine(r1,r2)
		memd(r30+#-16) = r19:18
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r22,r1)
		r3:2 = combine(r19,r18)
		memd(r30+#-24) = r21:20
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r21:20 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r22,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.2:                               // %entry
	{
		r23:22 = combine(r1,r0)
		r2 = memw(r16+#24)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB1_4
	}
// %bb.3:                               // %cond.true
	{
		r2 = memw(r16+#8)
		r3 = memw(r16+#32)
	}
	{
		r2 = mpyi(r2,r17)
	}
	{
		r19 = addasl(r3,r2,#2)
	}
	.falign
.LBB1_4:                                // %cond.end
	{
		r18 = #0
		r26 = #-32
		p1 = cmp.gtu(r22,r20); if (!p1.new) jump:t .LBB1_48
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r0 = ##1065385983
	}
	{
		r21 = ##1132396544
		r27 = add(r0,#-32767)
		r17 = #127
	}
	{
		r3 = ##1262485504
		p0 = cmp.eq(r19,#0)
	}
	{
		r2 = p0
		v24 = vsplat(r3)
		vmem(r29+#6) = v24.new
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#124) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB1_6:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB1_14 Depth 2
                                        //     Child Loop BB1_25 Depth 2
                                        //     Child Loop BB1_19 Depth 2
                                        //     Child Loop BB1_34 Depth 2
                                        //     Child Loop BB1_40 Depth 2
	{
		r3 = memw(r16+#8)
		r2 = memw(r16+#0)
	}
	{
		r4 = mpyi(r3,r20)
	}
	{
		r0 = addasl(r2,r4,#2)
		r2 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB1_10
		if (p1.new) r23 = memw(r16+#16)
		if (p1.new) r24 = memw(r16+#12)
	}
// %bb.7:                               // %if.then
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		call hvx_rmsnorm_row_f32
		r1 = r19
		r2 = memw(r16+#24)
		r4 = memw(r16+#28)
	}
	.falign
// %bb.8:                               // %if.then
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r2 = memw(r16+#8)
		r23 = memw(r16+#16)
	}
	{
		r3 = lsr(r2,#5)
		p0 = cmp.gtu(r2,#31); if (p0.new) jump:t .LBB1_12
		r24 = memw(r16+#12)
	}
// %bb.9:                               //   in Loop: Header=BB1_6 Depth=1
	{
		p0 = bitsset(r26,r2)
		r4 = memw(r19+#0)
	}
	{
		r5 = r4
		if (p0) jump:nt .LBB1_27
	}
	{
		jump .LBB1_24
	}
	.falign
.LBB1_10:                               // %if.else
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		p1 = cmp.gtu(r3,#31); if (p1.new) jump:t .LBB1_16
		if (!p1.new) r2 = memw(r0+#0)
	}
// %bb.11:                              //   in Loop: Header=BB1_6 Depth=1
	{
		p1 = !bitsset(r26,r3)
		r4 = r2
		if (!p1.new) jump:t .LBB1_36
	}
	{
		jump .LBB1_33
	}
	.falign
.LBB1_12:                               // %if.then.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		p1 = cmp.gtu(r2,#63)
		if (!p1.new) jump:t .LBB1_22
		v3 = vmemu(r19+#0)
	}
// %bb.13:                              // %for.body.i.preheader
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r4 = add(r19,#128)
		r5 = add(r3,#-1)
		v7 = v3
	}
	{
		p0 = cmp.gtu(r5,#1)
		r5 = add(r5,#-1)
		v6 = vmemu(r4++#1)
	}
	{
		loop0(.LBB1_14,r5)
		if (!p0) jump:nt .LBB1_15
	}
	.falign
.LBB1_14:                               // %for.body.i
                                        //   Parent Loop BB1_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v3.sf = vmin(v3.sf,v6.sf)
		v7.sf = vmax(v7.sf,v6.sf)
		v6 = vmemu(r4++#1)
	} :endloop0
	.falign
.LBB1_15:                               //   in Loop: Header=BB1_6 Depth=1
	{
		jump .LBB1_23
		v8.sf = vmin(v3.sf,v6.sf)
		v3.sf = vmax(v7.sf,v6.sf)
	}
	.falign
.LBB1_16:                               // %if.then.i76
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		p0 = cmp.gtu(r3,#63)
		if (!p0.new) jump:t .LBB1_31
		v2 = vmemu(r0+#0)
	}
// %bb.17:                              // %for.body.i115.preheader
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r4 = lsr(r3,#5)
		r2 = #1
		v4 = v2
	}
	{
		r4 = add(r4,#-1)
	}
	{
		r5 = lsr(r4,#1)
		r4 = and(r4,#1)
	}
	{
		if (p1.new) r7 = add(r5,#-1)
		if (p1.new) r6 = add(r2,#1)
		p1 = cmp.gtu(r5,#0); if (!p1.new) jump:t .LBB1_46
	}
// %bb.18:                              //   in Loop: Header=BB1_6 Depth=1
	{
		r5 = addasl(r0,r2,#7)
		p1 = cmp.gtu(r5,#1)
	}
	{
		loop0(.LBB1_19,r7)
		r6 = addasl(r0,r6,#7)
		r2 = add(r2,#2)
		v5 = v2
	}
	{
		if (!p1) jump:nt .LBB1_20
	}
	.balign 32
.LBB1_19:                               //   Parent Loop BB1_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r5 = addasl(r0,r2,#7)
		r7 = add(r2,#1)
		v30 = vmemu(r5+#0)
	}
	{
		v31.sf = vmin(v2.sf,v30.sf)
		v0.sf = vmax(v5.sf,v30.sf)
		v1 = vmemu(r6+#0)
	}
	{
		r6 = addasl(r0,r7,#7)
		r2 = add(r2,#2)
		v2.sf = vmin(v31.sf,v1.sf)
		v5.sf = vmax(v0.sf,v1.sf)
	} :endloop0
	.falign
.LBB1_20:                               //   in Loop: Header=BB1_6 Depth=1
	{
		p0 = cmp.gtu(r4,#0)
		v3 = vmemu(r5+#0)
	}
	{
		v4.sf = vmax(v5.sf,v3.sf)
		v2.sf = vmin(v2.sf,v3.sf)
		v5 = vmemu(r6+#0)
	}
	{
		if (p0) jump:nt .LBB1_47
		v4.sf = vmax(v4.sf,v5.sf)
		v2.sf = vmin(v2.sf,v5.sf)
	}
	.falign
.LBB1_21:                               //   in Loop: Header=BB1_6 Depth=1
	{
		jump .LBB1_32
		v9 = v2
		v2 = v4
	}
	.falign
.LBB1_22:                               //   in Loop: Header=BB1_6 Depth=1
	{
		v8 = v3
	}
	.falign
.LBB1_23:                               // %for.body10.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		p0 = bitsset(r26,r2)
		r4 = #64
	}
	{
		v10 = vror(v8,r4)
	}
	{
		r4 = #32
		v12 = vror(v3,r4)
		v11.sf = vmin(v8.sf,v10.sf)
	}
	{
		v13.sf = vmax(v3.sf,v12.sf)
	}
	{
		v14 = vror(v11,r4)
	}
	{
		r4 = #16
		v16 = vror(v13,r4)
		v15.sf = vmin(v11.sf,v14.sf)
	}
	{
		v17.sf = vmax(v13.sf,v16.sf)
	}
	{
		v18 = vror(v15,r4)
	}
	{
		r4 = #8
		v20 = vror(v17,r4)
		v19.sf = vmin(v15.sf,v18.sf)
	}
	{
		v21.sf = vmax(v17.sf,v20.sf)
	}
	{
		v22 = vror(v19,r4)
	}
	{
		v23 = vror(v21,r4)
		v24.sf = vmin(v19.sf,v22.sf)
	}
	{
		v25.sf = vmax(v21.sf,v23.sf)
	}
	{
		v26 = valign(v24,v24,#4)
	}
	{
		v27 = valign(v25,v25,#4)
		v28.sf = vmin(v24.sf,v26.sf)
		vmem(r29+#3) = v28.new
	}
	{
		v29.sf = vmax(v25.sf,v27.sf)
		r5 = memw(r29+#384)
		vmem(r29+#2) = v29.new
	}
	{
		if (p0) jump:nt .LBB1_27
		r4 = memw(r29+#256)
	}
	.falign
.LBB1_24:                               // %for.body21.i.preheader
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = extractu(r3,#25,#0)
		r6 = and(r2,#-32)
	}
	{
		r3 = addasl(r19,r3,#7)
		r2 = sub(r2,r6)
	}
	{
		r6 = add(r2,#-1)
		p0 = cmp.gtu(r2,#1)
	}
	{
		loop0(.LBB1_25,r6)
		if (!p0) jump:nt .LBB1_26
		r2 = memw(r3++#4)
	}
	.falign
.LBB1_25:                               // %for.body21.i
                                        //   Parent Loop BB1_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r5 = sfmin(r2,r5)
		r4 = sfmax(r2,r4)
		r2 = memw(r3++#4)
	} :endloop0
	.falign
.LBB1_26:                               //   in Loop: Header=BB1_6 Depth=1
	{
		r5 = sfmin(r2,r5)
		r4 = sfmax(r2,r4)
	}
	.falign
.LBB1_27:                               // %for.cond.cleanup20.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r2 = sfmin(r5,r18)
		r3 = sfmax(r4,r18)
		r0 = r19
	}
	{
		p1 = sfcmp.uo(r2,r3)
		p0 = sfcmp.eq(r2,r3)
	}
	{
		p1 = and(p0,!p1)
		if (!p1.new) r5:4 = combine(r27,r27)
		if (!p1.new) jump:nt .LBB1_29
	}
// %bb.28:                              //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = memw(r16+#20)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB1_38
	}
	{
		jump .LBB1_43
	}
	.falign
.LBB1_29:                               // %if.end43.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = sfsub(r3,r2)
		r2 = togglebit(r2,#31)
	}
	{
		r6 = sffixupn(r3,r21)
		r7,p0 = sfrecipa(r3,r21)
	}
	{
		r3 = sffixupd(r3,r21)
	}
	{
		r9:8 = combine(r6,r6)
	}
	{
		r8 = insert(r18,#31,#0)
		r4 -= sfmpy(r3,r7):lib
	}
	{
		r25 = r8
	}
	{
		r7 += sfmpy(r4,r7):lib
	}
	{
		r25 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r3,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r9 -= sfmpy(r3,r25):lib
		r5 = r27
	}
	{
		r25 += sfmpy(r9,r7):lib
	}
	{
		r6 -= sfmpy(r25,r3):lib
	}
	{
		r25 += sfmpy(r6,r7,p0):scale
		r6 = r27
	}
	{
		r3,p0 = sfrecipa(r2,r25)
		r4 = sffixupd(r2,r25)
	}
	{
		r2 = sffixupn(r2,r25)
	}
	{
		r6 -= sfmpy(r4,r3):lib
	}
	{
		r0 = r2
	}
	{
		r0 = insert(r8,#31,#0)
		r3 += sfmpy(r6,r3):lib
		r6 = r2
	}
	{
		r0 += sfmpy(r2,r3):lib
		r5 -= sfmpy(r4,r3):lib
	}
	{
		r6 -= sfmpy(r4,r0):lib
		r3 += sfmpy(r5,r3):lib
	}
	{
		r0 += sfmpy(r6,r3):lib
	}
	{
		r2 -= sfmpy(r0,r4):lib
	}
	{
		call nearbyintf
		r0 += sfmpy(r2,r3,p0):scale
	}
	.falign
// %bb.30:                              // %if.end43.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r2 = convert_sf2w(r0):chop
		r0 = r19
		memw(r24+r20<<#2) = r25
	}
	{
		r2 = satub(r2)
		memw(r23+r20<<#2) = r2.new
	}
	{
		r3 = memw(r16+#20)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB1_38
	}
	{
		jump .LBB1_43
	}
	.falign
.LBB1_31:                               //   in Loop: Header=BB1_6 Depth=1
	{
		v9 = v2
	}
	.falign
.LBB1_32:                               // %for.body10.i78
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		p1 = !bitsset(r26,r3)
		r2 = #64
	}
	{
		v7 = vror(v9,r2)
	}
	{
		r2 = #32
		v31 = vror(v2,r2)
		v8.sf = vmin(v9.sf,v7.sf)
	}
	{
		v10.sf = vmax(v2.sf,v31.sf)
	}
	{
		v11 = vror(v8,r2)
	}
	{
		r2 = #16
		v13 = vror(v10,r2)
		v12.sf = vmin(v8.sf,v11.sf)
	}
	{
		v14.sf = vmax(v10.sf,v13.sf)
	}
	{
		v15 = vror(v12,r2)
	}
	{
		r2 = #8
		v17 = vror(v14,r2)
		v16.sf = vmin(v12.sf,v15.sf)
	}
	{
		v18.sf = vmax(v14.sf,v17.sf)
	}
	{
		v19 = vror(v16,r2)
	}
	{
		v20 = vror(v18,r2)
		v21.sf = vmin(v16.sf,v19.sf)
	}
	{
		v22.sf = vmax(v18.sf,v20.sf)
	}
	{
		v23 = valign(v21,v21,#4)
	}
	{
		v24 = valign(v22,v22,#4)
		v25.sf = vmin(v21.sf,v23.sf)
		vmem(r29+#5) = v25.new
	}
	{
		v26.sf = vmax(v22.sf,v24.sf)
		r4 = memw(r29+#640)
		vmem(r29+#4) = v26.new
	}
	{
		if (!p1) jump:nt .LBB1_36
		r2 = memw(r29+#512)
	}
	.falign
.LBB1_33:                               //   in Loop: Header=BB1_6 Depth=1
	{
		r5 = and(r3,#-32)
	}
	{
		r3 = sub(r3,r5)
	}
	{
		r6 = add(r3,#-1)
		p1 = cmp.gtu(r3,#1)
		r5 = add(r5,#1)
		r3 = memw(r0+r5<<#2)
	}
	{
		loop0(.LBB1_34,r6)
		if (!p1) jump:nt .LBB1_35
	}
	.balign 32
.LBB1_34:                               // %for.body21.i88
                                        //   Parent Loop BB1_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r4 = sfmin(r3,r4)
		r2 = sfmax(r3,r2)
		r5 = add(r5,#1)
		r3 = memw(r0+r5<<#2)
	} :endloop0
	.falign
.LBB1_35:                               //   in Loop: Header=BB1_6 Depth=1
	{
		r4 = sfmin(r3,r4)
		r2 = sfmax(r3,r2)
	}
	.falign
.LBB1_36:                               // %for.cond.cleanup20.i99
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = sfmin(r4,r18)
		r2 = sfmax(r2,r18)
		r25 = r0
	}
	{
		p0 = sfcmp.uo(r3,r2)
		p1 = sfcmp.eq(r3,r2)
		r5:4 = combine(r27,r27)
	}
	{
		r2 = sfsub(r2,r3)
		p0 = and(p1,!p0)
		if (!p0.new) jump:nt .LBB1_44
	}
// %bb.37:                              // %if.end
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = memw(r16+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB1_43
	}
	.falign
.LBB1_38:                               // %if.then27
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r5:4 = combine(r27,r27)
		r2 = memw(r24+r20<<#2)
		v0 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		r6,p0 = sfrecipa(r27,r2)
		r7 = sffixupd(r27,r2)
	}
	{
		r8 = sffixupn(r27,r2)
	}
	{
		r4 -= sfmpy(r7,r6):lib
	}
	{
		r9 = and(r8,##-2147483648)
		r2 = r8
	}
	{
		r6 += sfmpy(r4,r6):lib
		r4 = memw(r23+r20<<#2)
	}
	{
		v26 = vsplat(r4)
		r4 = #0
	}
	{
		r9 += sfmpy(r8,r6):lib
		r5 -= sfmpy(r7,r6):lib
	}
	{
		r2 -= sfmpy(r7,r9):lib
		r6 += sfmpy(r5,r6):lib
	}
	{
		r9 += sfmpy(r2,r6):lib
		r2 = memw(r16+#8)
	}
	{
		r3 += mpyi(r2,r20)
		r8 -= sfmpy(r9,r7):lib
	}
	{
		r9 += sfmpy(r8,r6,p0):scale
		p0 = cmp.gtu(r2,#127)
		if (p0.new) r6 = #0
	}
	{
		v1 = vsplat(r9)
		if (p0) r5 = add(r0,##256)
		if (!p0) jump:nt .LBB1_41
	}
	.falign
.LBB1_40:                               // %for.body.i123
                                        //   Parent Loop BB1_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r7 = add(r5,#-256)
		r4 = add(r6,#256)
		r5 = add(r5,#512)
	}
	{
		p1 = !bitsclr(r7,r17)
		r8 = and(r7,#-128)
		p0 = cmp.gtu(r4,r2)
		r4 = add(r6,#128)
	}
	{
		v27 = vmem(r8+#1)
	}
	{
		v28 = vmem(r8+#2)
	}
	{
		v30 = valign(v28,v27,r7)
		v29 = vmem(r8+#3)
	}
	{
		v3 = valign(v29,v28,r7)
		v31 = vmem(r8+#0)
	}
	{
		v4.qf32 = vmpy(v30.sf,v1.sf)
		v5 = valign(v27,v31,r7)
		if (p1) v2 = vmem(r8+#4)
	}
	{
		v8.qf32 = vmpy(v3.sf,v1.sf)
	}
	{
		v7.qf32 = vmpy(v5.sf,v1.sf)
		r7 = add(r3,r6)
		v6 = valign(v2,v29,r7)
		v11.qf32 = vadd(v4.qf32,v0.sf)
	}
	{
		r6 = r4
		v12.qf32 = vadd(v8.qf32,v0.sf)
	}
	{
		v9.qf32 = vmpy(v6.sf,v1.sf)
		v10.qf32 = vadd(v7.qf32,v0.sf)
		v15.sf = v11.qf32
	}
	{
		v16.sf = v12.qf32
		v18.w = vsub(v15.w,v0.w)
	}
	{
		v13.qf32 = vadd(v9.qf32,v0.sf)
		v14.sf = v10.qf32
		v20.w = vsub(v16.w,v0.w)
		v22.w = vadd(v18.w,v26.w)
	}
	{
		v17.w = vsub(v14.w,v0.w)
		v24.w = vadd(v20.w,v26.w)
		v20 = v26
	}
	{
		v19.sf = v13.qf32
		v21.w = vadd(v17.w,v26.w)
	}
	{
		v23.w = vsub(v19.w,v0.w)
	}
	{
		v26.h = vpack(v22.w,v21.w):sat
		v25.w = vadd(v23.w,v26.w)
	}
	{
		v27.h = vpack(v25.w,v24.w):sat
	}
	{
		v23.ub = vpack(v27.h,v26.h):sat
		v26 = v20
	}
	{
		if (!p0) jump:nt .LBB1_40
		vmemu(r7+#0) = v23
	}
	.falign
.LBB1_41:                               // %for.end.i
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r8 = #3
		if (p1.new) r2 = sub(r2,r4)
		p1 = cmp.gtu(r2,r4); if (!p1.new) jump:t .LBB1_43
	}
// %bb.42:                              // %if.then.i128
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r5 = addasl(r0,r4,#2)
		r6 = r2
		r7 = #2
		r1 = add(r29,#128)
	}
	{
		r9 = #128
		r0 = add(r3,r4)
		v25 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		r6 = add(##-1,lsr(r6,#5))
		v29 = vmemu(r5+#0)
	}
	{
		r7 = minu(r6,r7)
		r6 = minu(r6,r8)
		p0 = cmp.eq(r6,#0)
	}
	{
		r7 = addasl(r5,r7,#7)
		r6 = addasl(r5,r6,#7)
		r8 = mux(p0,#0,r9)
	}
	{
		v30.qf32 = vmpy(v29.sf,v1.sf)
		r5 = add(r5,r8)
	}
	{
		v31 = vmemu(r7+#0)
	}
	{
		v8.qf32 = vadd(v30.qf32,v25.sf)
		v3 = vmemu(r5+#0)
	}
	{
		v4.qf32 = vmpy(v31.sf,v1.sf)
		v2 = vmemu(r6+#0)
	}
	{
		v5.qf32 = vmpy(v3.sf,v1.sf)
		v12.sf = v8.qf32
	}
	{
		v1.qf32 = vmpy(v2.sf,v1.sf)
		v6.qf32 = vadd(v4.qf32,v25.sf)
		v16.w = vsub(v12.w,v25.w)
	}
	{
		v9.qf32 = vadd(v5.qf32,v25.sf)
		v20.w = vadd(v16.w,v26.w)
	}
	{
		v7.qf32 = vadd(v1.qf32,v25.sf)
		v10.sf = v6.qf32
	}
	{
		v13.sf = v9.qf32
		v14.w = vsub(v10.w,v25.w)
	}
	{
		v11.sf = v7.qf32
		v17.w = vsub(v13.w,v25.w)
		v18.w = vadd(v14.w,v26.w)
	}
	{
		v15.w = vsub(v11.w,v25.w)
		v0.w = vadd(v17.w,v26.w)
	}
	{
		v19.w = vadd(v15.w,v26.w)
	}
	{
		v22.h = vpack(v0.w,v20.w):sat
	}
	{
		v21.h = vpack(v19.w,v18.w):sat
	}
	{
		call memcpy
		v23.ub = vpack(v21.h,v22.h):sat
		vmem(r29+#1) = v23.new
	}
	.falign
.LBB1_43:                               // %if.end36
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r20 = add(r20,#1)
		if (cmp.gtu(r22,r20.new)) jump:t ##.LBB1_6
	}
	{
		jump .LBB1_48
	}
	.falign
.LBB1_44:                               // %if.end43.i107
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r3 = togglebit(r3,#31)
		r6 = sffixupn(r2,r21)
	}
	{
		r7,p1 = sfrecipa(r2,r21)
	}
	{
		r2 = sffixupd(r2,r21)
		r9:8 = combine(r6,r6)
	}
	{
		r8 = insert(r18,#31,#0)
		r4 -= sfmpy(r2,r7):lib
	}
	{
		r7 += sfmpy(r4,r7):lib
		r26 = r8
	}
	{
		r26 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r2,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r9 -= sfmpy(r2,r26):lib
	}
	{
		r26 += sfmpy(r9,r7):lib
	}
	{
		r6 -= sfmpy(r26,r2):lib
	}
	{
		r26 += sfmpy(r6,r7,p1):scale
		r6 = r27
	}
	{
		r4,p1 = sfrecipa(r3,r26)
		r5 = sffixupd(r3,r26)
	}
	{
		r3 = sffixupn(r3,r26)
	}
	{
		r6 -= sfmpy(r5,r4):lib
		r2 = r3
		r7 = r3
	}
	{
		r2 = insert(r8,#31,#0)
		r4 += sfmpy(r6,r4):lib
		r6 = r27
	}
	{
		r2 += sfmpy(r3,r4):lib
		r6 -= sfmpy(r5,r4):lib
	}
	{
		r7 -= sfmpy(r5,r2):lib
		r4 += sfmpy(r6,r4):lib
	}
	{
		r2 += sfmpy(r7,r4):lib
	}
	{
		r3 -= sfmpy(r2,r5):lib
	}
	{
		r2 += sfmpy(r3,r4,p1):scale
	}
	{
		call nearbyintf
		r0 = r2
	}
	.falign
// %bb.45:                              // %if.end43.i107
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r2 = r0
		r0 = r25
		r26 = #-32
		memw(r24+r20<<#2) = r26
	}
	{
		r2 = convert_sf2w(r2):chop
	}
	{
		r2 = satub(r2)
		memw(r23+r20<<#2) = r2.new
	}
	{
		r3 = memw(r16+#20)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB1_38
	}
	{
		jump .LBB1_43
	}
	.falign
.LBB1_46:                               //   in Loop: Header=BB1_6 Depth=1
	{
		p0 = cmp.gtu(r4,#0); if (!p0.new) jump:t .LBB1_21
	}
	.falign
.LBB1_47:                               // Block address taken
                                        // %for.body.i115
                                        //   in Loop: Header=BB1_6 Depth=1
	{
		r4 = addasl(r0,r2,#7)
	}
	{
		v6 = vmemu(r4+#0)
	}
	{
		jump .LBB1_21
		v2.sf = vmin(v2.sf,v6.sf)
		v4.sf = vmax(v4.sf,v6.sf)
	}
	.falign
.LBB1_48:                               // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	quant_rows_worker, .Lfunc_end1-quant_rows_worker
                                        // -- End function
	.globl	hvx_quant_rows_u8_params        // -- Begin function hvx_quant_rows_u8_params
	.falign
	.type	hvx_quant_rows_u8_params,@function
hvx_quant_rows_u8_params:               // @hvx_quant_rows_u8_params
// %bb.0:                               // %entry
	{
		r7:6 = combine(r3,r0)
		r3 = r1
		p0 = cmp.eq(r2,#0)
		allocframe(#40)
	}
	{
		r9 = #0
		if (!p0) r12 = add(r5,#0)
		if (p0) jump:nt .LBB2_3
		r0 = memw(r29+#48)
	}
// %bb.1:
	{
		loop0(.LBB2_2,r2)
		r8 = ##1065353216
	}
	{
		r2 = r4
	}
	.falign
.LBB2_2:                                // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r2++#4) = r8
		memw(r12++#4) = r9
	} :endloop0
	.falign
.LBB2_3:                                // %hvx_quant_rows_u8_params_rm.exit
	{
		r1 = add(pc,##quant_rows_worker@PCREL)
		r2 = add(r29,#4)
		memw(r29+#8) = r1
	}
	{
		memw(r29+#4) = r6
		memw(r29+#12) = r7
	}
	{
		memw(r29+#16) = r4
		memw(r29+#20) = r5
	}
	{
		memw(r29+#24) = #0
		memw(r29+#28) = #0
	}
	{
		call hvx_worker_pool_run
		memw(r29+#32) = #0
		memw(r29+#36) = #0
	}
	.falign
// %bb.4:                               // %hvx_quant_rows_u8_params_rm.exit
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end2:
	.size	hvx_quant_rows_u8_params, .Lfunc_end2-hvx_quant_rows_u8_params
                                        // -- End function
	.globl	hvx_gather_u8_ah_rows           // -- Begin function hvx_gather_u8_ah_rows
	.falign
	.type	hvx_gather_u8_ah_rows,@function
hvx_gather_u8_ah_rows:                  // @hvx_gather_u8_ah_rows
// %bb.0:                               // %entry
	{
		p1 = cmp.gtu(r3,r2)
		if (p1.new) r9 = aslh(r4)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#16) = r19:18
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p1) jump:nt .LBB3_14
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %for.body.lr.ph
	{
		r8 = lsr(r4,#5)
		r15:14 = combine(#96,#64)
		p0 = cmp.gtu(r4,#31)
	}
	{
		r6 = extractu(r8,#16,#11)
		if (!p0) r5 = add(r2,#4)
		if (p0) r12 = sub(r3,r2)
		if (p0) r13 = #32
	}
	{
		r6 = setbit(r9,#0)
		r7 = or(r6,r4)
		if (p0) jump:nt .LBB3_5
	}
// %bb.2:                               // %for.body.preheader
	{
		r2 = asl(r2,#2)
		if (p1.new) r3 = sub(r3,r5)
		p1 = cmp.gtu(r3,r5); if (!p1.new) jump:t .LBB3_14
	}
// %bb.3:                               // %if.end.preheader
	{
		r2 = add(r2,add(r1,#24))
		r3 = add(r3,#3)
	}
	{
		r3 = lsr(r3,#2)
	}
	{
		loop0(.LBB3_4,r3)
	}
	.falign
.LBB3_4:                                // Block address taken
                                        // %if.end
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = r0
		r3 = memw(r2+#-8)
	}
	{
		r5 += mpyi(r3,r4)
	}
	{
		r5 = r0
		l2fetch(r5,r7:6)
	}
	{
		r3 = memw(r2+#-4)
	}
	{
		r5 += mpyi(r3,r4)
	}
	{
		r5 = r0
		l2fetch(r5,r7:6)
	}
	{
		r3 = memw(r2++#16)
	}
	{
		r5 += mpyi(r3,r4)
	}
	{
		nop
		l2fetch(r5,r7:6)
	} :endloop0
	{
		jump .LBB3_14
	}
	.falign
.LBB3_5:
	{
		r9 = insert(r8,#21,#11)
		r12 = add(r12,#3)
		r13 = add(r0,#-32)
		q0 = vsetq2(r13)
	}
	{
		r28 = lsr(r12,#2)
		r12 = lsr(r4,#6)
		r14 = add(r0,#-64)
		q1 = vsetq2(r14)
	}
	{
		loop1(.LBB3_6,r28)
		r15 = add(r0,#-96)
		q2 = vsetq2(r15)
	}
	.falign
.LBB3_6:                                // Block address taken
                                        // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB3_12 Depth 2
                                        //     Child Loop BB3_8 Depth 2
	{
		r18 = addasl(r1,r2,#2)
		r11 = lsr(r2,#6)
		r28 = #96
		r16 = memw(r1+r2<<#2)
	}
	{
		r28 = insert(r2,#6,#5)
		r17 = mpyi(r9,r11)
		r11:10 = combine(r13,r0)
		r2 = add(r2,#4)
	}
	{
		r10 += mpyi(r16,r4)
		r28 += add(r5,r17)
		r20 = memw(r18+#8)
		r19 = memw(r18+#4)
	}
	{
		r17:16 = combine(r15,r14)
		p0 = cmp.gtu(r3,r2)
		r22 = r0
		r21 = memw(r18+#12)
	}
	{
		r11 += mpyi(r19,r4)
		r16 += mpyi(r20,r4)
		r20 = r0
		if (p0) r19 = memw(r1+r2<<#2)
	}
	{
		r17 += mpyi(r21,r4)
		if (!p0) jump:nt .LBB3_11
	}
// %bb.7:                               // %for.body43.us124.preheader
                                        //   in Loop: Header=BB3_6 Depth=1
	{
		loop0(.LBB3_8,r8)
		r21 = addasl(r1,r2,#2)
	}
	{
		r20 += mpyi(r19,r4)
	}
	{
		l2fetch(r20,r7:6)
	}
	{
		r19 = memw(r21+#4)
	}
	{
		r22 += mpyi(r19,r4)
	}
	{
		r22 = r0
		l2fetch(r22,r7:6)
	}
	{
		r19 = memw(r21+#8)
	}
	{
		r22 += mpyi(r19,r4)
		r19 = r12
	}
	{
		l2fetch(r22,r7:6)
	}
	.falign
.LBB3_8:                                // Block address taken
                                        // %for.body43.us124
                                        //   Parent Loop BB3_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r21 = r0
		p0 = cmp.eq(r19,#0); if (!p0.new) jump:t .LBB3_10
		if (p0.new) r20 = memw(r18+#28)
	}
// %bb.9:                               // %if.then51.us
                                        //   in Loop: Header=BB3_8 Depth=2
	{
		r21 += mpyi(r20,r4)
	}
	{
		l2fetch(r21,r7:6)
	}
	.falign
.LBB3_10:                               // %if.end56.us
                                        //   in Loop: Header=BB3_8 Depth=2
	{
		r19 = add(r19,#-1)
		r16 = add(r16,#32)
		v0 = vmemu(r16+#0)
	}
	{
		r17 = add(r17,#32)
		v1 = vmemu(r17+#0)
	}
	{
		r11 = add(r11,#32)
		v3 = vmux(q2,v0,v1)
		v2 = vmemu(r11+#0)
	}
	{
		r10 = add(r10,#32)
		v5 = vmux(q1,v2,v3)
		v4 = vmemu(r10+#0)
	}
	{
		v6 = vmux(q0,v4,v5)
	}
	{
		r28 = add(r28,#2048)
		vmemu(r28+#0) = v6
	} :endloop0
	{
		jump .LBB3_13
	}
	.falign
.LBB3_11:                               //   in Loop: Header=BB3_6 Depth=1
	{
		loop0(.LBB3_12,r8)
	}
	.falign
.LBB3_12:                               // Block address taken
                                        // %for.body43.us.us
                                        //   Parent Loop BB3_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r16 = add(r16,#32)
		v7 = vmemu(r16+#0)
	}
	{
		r17 = add(r17,#32)
		v8 = vmemu(r17+#0)
	}
	{
		r11 = add(r11,#32)
		v10 = vmux(q2,v7,v8)
		v9 = vmemu(r11+#0)
	}
	{
		r10 = add(r10,#32)
		v12 = vmux(q1,v9,v10)
		v11 = vmemu(r10+#0)
	}
	{
		v13 = vmux(q0,v11,v12)
	}
	{
		r28 = add(r28,#2048)
		vmemu(r28+#0) = v13
	} :endloop0
	.falign
.LBB3_13:                               // %for.cond39.for.cond.loopexit_crit_edge.us
                                        //   in Loop: Header=BB3_6 Depth=1
	{
		nop
		nop
		nop
	} :endloop1
	.falign
.LBB3_14:                               // %for.cond.cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hvx_gather_u8_ah_rows, .Lfunc_end3-hvx_gather_u8_ah_rows
                                        // -- End function
	.globl	hvx_quant_pack_u8_ah_rows       // -- Begin function hvx_quant_pack_u8_ah_rows
	.falign
	.type	hvx_quant_pack_u8_ah_rows,@function
hvx_quant_pack_u8_ah_rows:              // @hvx_quant_pack_u8_ah_rows
// %bb.0:                               // %entry
	{
		p2 = cmp.gtu(r3,r2)
		memd(r29+#-16) = r17:16
		allocframe(#104)
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#88) = r19:18
		memd(r29+#80) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#72) = r23:22
		memd(r29+#64) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p2) r4 = ##1262485504
		memd(r29+#56) = r27:26
		memw(r29+#32) = r4
	}                                       // 8-byte Folded Spill
	{
		if (!p2) jump:nt .LBB4_9
		memw(r29+#28) = r1
		memw(r29+#36) = r0
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %for.body.lr.ph
	{
		r8 = memw(r29+#116)
		memw(r29+#44) = r8.new
	}
	{
		v0 = vsplat(r4)
		r3 = sub(r3,r2)
		r8 = memw(r29+#112)
		memw(r29+#48) = r8.new
	}
	{
		r3 = add(r3,#3)
		r8 = memw(r29+#28)
		r7 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r3 = lsr(r3,#2)
		p0 = cmp.eq(r8,#0)
		p1 = cmp.gtu(r7,#31)
	}
	{
		r6 = lsr(r7,#5)
		r8 = p0
		memw(r29+#40) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r4 = p1
		r8 = ##1065353216
		memw(r29+#20) = r8
	}                                       // 4-byte Folded Spill
	{
		r6 = extractu(r6,#21,#0)
		memw(r29+#24) = r4
	}                                       // 4-byte Folded Spill
	{
		loop1(.LBB4_2,r3)
		r4 = asl(r6,#11)
		memw(r29+#52) = r4.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_2:                                // Block address taken
                                        // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_7 Depth 2
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (!p3.new) r12 = add(r2,#1)
		if (p3.new) jump:nt .LBB4_4
		if (!p3.new) r4 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
// %bb.3:                               // %cond.true25
                                        //   in Loop: Header=BB4_2 Depth=1
	{
		r3 = addasl(r4,r2,#2)
		r13 = add(r2,#2)
		r15 = add(r2,#3)
	}
	{
		r4 = memw(r4+r2<<#2)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r3+#4)
		memw(r29+#12) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r3+#8)
		memw(r29+#16) = r4.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB4_5
		r11 = memw(r3+#12)
	}
	.falign
.LBB4_4:                                // %cond.false28
                                        //   in Loop: Header=BB4_2 Depth=1
	{
		r15 = add(r2,#3)
		r12 = add(r2,#1)
		r13 = add(r2,#2)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Spill
	{
		r11 = r15
		memw(r29+#16) = r13
		memw(r29+#12) = r12
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_5:                                // %cond.end30
                                        //   in Loop: Header=BB4_2 Depth=1
	{
		r26 = ##1065353216
		r3 = memw(r5+r2<<#2)
		r9 = memw(r5+r12<<#2)
	}
	{
		r27 = ##1065353216
		r14 = memw(r5+r13<<#2)
		r10 = memw(r5+r15<<#2)
	}
	{
		r28 = ##1065353216
		r22 = ##1065353216
	}
	{
		r16,p2 = sfrecipa(r8,r3)
		r19 = sffixupd(r8,r3)
		r21 = ##1065353216
	}
	{
		r23 = ##1065353216
		r20 = ##1065353216
	}
	{
		r18,p3 = sfrecipa(r8,r9)
		r24 = sffixupd(r8,r9)
	}
	{
		r25 = sffixupn(r8,r9)
		r26 -= sfmpy(r19,r16):lib
	}
	{
		r27 -= sfmpy(r24,r18):lib
		r9,p0 = sfrecipa(r8,r14)
		r7 = r25
	}
	{
		r1 = sffixupd(r8,r14)
		r17 = sffixupn(r8,r3)
		r3 = ##1065353216
	}
	{
		r0 = sffixupn(r8,r14)
		r14,p1 = sfrecipa(r8,r10)
	}
	{
		r4 = sffixupd(r8,r10)
		r28 -= sfmpy(r1,r9):lib
		r6 = and(r17,##-2147483648)
	}
	{
		r16 += sfmpy(r26,r16):lib
		r18 += sfmpy(r27,r18):lib
		r26 = r0
	}
	{
		r3 -= sfmpy(r4,r14):lib
		r10 = sffixupn(r8,r10)
	}
	{
		r7 = insert(r6,#31,#0)
		r9 += sfmpy(r28,r9):lib
		r28 = r17
	}
	{
		r22 -= sfmpy(r19,r16):lib
		r23 -= sfmpy(r24,r18):lib
	}
	{
		r26 = insert(r7,#31,#0)
		r14 += sfmpy(r3,r14):lib
		r3 = r10
	}
	{
		r3 = insert(r26,#31,#0)
		r6 += sfmpy(r17,r16):lib
	}
	{
		r7 += sfmpy(r25,r18):lib
		r16 += sfmpy(r22,r16):lib
	}
	{
		r18 += sfmpy(r23,r18):lib
		r20 -= sfmpy(r1,r9):lib
		r23:22 = combine(r25,r26)
		r26 = r10
	}
	{
		r22 += sfmpy(r0,r9):lib
		r3 += sfmpy(r10,r14):lib
	}
	{
		r21 -= sfmpy(r4,r14):lib
		r9 += sfmpy(r20,r9):lib
		r20 = r0
	}
	{
		r28 -= sfmpy(r19,r6):lib
		r23 -= sfmpy(r24,r7):lib
	}
	{
		r20 -= sfmpy(r1,r22):lib
		r14 += sfmpy(r21,r14):lib
	}
	{
		r26 -= sfmpy(r4,r3):lib
		r6 += sfmpy(r28,r16):lib
	}
	{
		r7 += sfmpy(r23,r18):lib
		r22 += sfmpy(r20,r9):lib
	}
	{
		r3 += sfmpy(r26,r14):lib
		r17 -= sfmpy(r6,r19):lib
	}
	{
		r25 -= sfmpy(r7,r24):lib
		r0 -= sfmpy(r22,r1):lib
	}
	{
		r10 -= sfmpy(r3,r4):lib
		r6 += sfmpy(r17,r16,p2):scale
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r7 += sfmpy(r25,r18,p3):scale
		r22 += sfmpy(r0,r9,p0):scale
	}
	{
		r3 += sfmpy(r10,r14,p1):scale
		p2 = r4
		if (!p2.new) jump:t .LBB4_8
		if (p2.new) r14 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
// %bb.6:                               // %for.body.lr.ph.i
                                        //   in Loop: Header=BB4_2 Depth=1
	{
		v1 = vsplat(r6)
		v2 = vsplat(r7)
		r0 = memw(r29+#32)
		r1 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		v3 = vsplat(r22)
		v4 = vsplat(r3)
		r28 = memw(r29+#12)
		r9 = memw(r14+r13<<#2)
	}                                       // 4-byte Folded Reload
	{
		r11 = mpyi(r11,r0)
		r12 = r2
		r6 = memw(r14+r12<<#2)
		r4 = memw(r14+r2<<#2)
	}
	{
		r15 = mpyi(r1,r0)
		v6 = vsplat(r6)
		r13 = memw(r14+r15<<#2)
	}
	{
		v5 = vsplat(r4)
		v7 = vsplat(r9)
		r1 = memw(r29+#8)
		r4 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r28 = mpyi(r28,r0)
		v8 = vsplat(r13)
	}
	{
		r0 = mpyi(r1,r0)
		r7 = lsr(r2,#6)
		r1 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r12 = and(##2016,asl(r12,#5))
		r3 = addasl(r4,r11,#2)
	}
	{
		r1 = mpyi(r1,r7)
		r6 = addasl(r4,r15,#2)
	}
	{
		r7 = addasl(r4,r28,#2)
		r9 = addasl(r4,r0,#2)
		r4 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r12 += add(r4,r1)
		r4 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB4_7,r4)
	}
	.falign
.LBB4_7:                                // Block address taken
                                        // %for.body.i
                                        //   Parent Loop BB4_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v9 = vmemu(r9++#1)
	}
	{
		v10 = vmemu(r7++#1)
	}
	{
		v12.qf32 = vmpy(v9.sf,v1.sf)
		v11 = vmemu(r6++#1)
	}
	{
		v14.qf32 = vmpy(v10.sf,v2.sf)
		v13 = vmemu(r3++#1)
	}
	{
		v15.qf32 = vmpy(v11.sf,v3.sf)
		v17.qf32 = vadd(v12.qf32,v0.sf)
	}
	{
		v16.qf32 = vmpy(v13.sf,v4.sf)
		v18.qf32 = vadd(v14.qf32,v0.sf)
	}
	{
		v19.qf32 = vadd(v15.qf32,v0.sf)
		v21.sf = v17.qf32
	}
	{
		v20.qf32 = vadd(v16.qf32,v0.sf)
		v22.sf = v18.qf32
		v25.w = vsub(v21.w,v0.w)
	}
	{
		v23.sf = v19.qf32
		v26.w = vsub(v22.w,v0.w)
		v29.w = vadd(v25.w,v5.w)
	}
	{
		v24.sf = v20.qf32
		v27.w = vsub(v23.w,v0.w)
		v30.w = vadd(v26.w,v6.w)
	}
	{
		v28.w = vsub(v24.w,v0.w)
		v31.w = vadd(v27.w,v7.w)
	}
	{
		v10.h = vpack(v30.w,v29.w):sat
		v9.w = vadd(v28.w,v8.w)
	}
	{
		v11.h = vpack(v9.w,v31.w):sat
	}
	{
		v31.ub = vpack(v11.h,v10.h):sat
	}
	{
		r12 = add(r12,#2048)
		vmemu(r12+#0) = v31
	} :endloop0
	.falign
.LBB4_8:                                // %pack_group_rows.exit
                                        //   in Loop: Header=BB4_2 Depth=1
	{
		r2 = add(r2,#4)
		nop
		nop
	} :endloop1
	.falign
.LBB4_9:                                // %for.cond.cleanup
	{
		r17:16 = memd(r29+#96)
		r19:18 = memd(r29+#88)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#80)
		r23:22 = memd(r29+#72)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#64)
		r27:26 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end4:
	.size	hvx_quant_pack_u8_ah_rows, .Lfunc_end4-hvx_quant_pack_u8_ah_rows
                                        // -- End function
	.globl	hvx_quant_pack_u8_ah_m1_repeat  // -- Begin function hvx_quant_pack_u8_ah_m1_repeat
	.falign
	.type	hvx_quant_pack_u8_ah_m1_repeat,@function
hvx_quant_pack_u8_ah_m1_repeat:         // @hvx_quant_pack_u8_ah_m1_repeat
// %bb.0:                               // %entry
	{
		r5 = ##1065353216
		r6 = ##1065353216
	}
	{
		r7,p0 = sfrecipa(r5,r2)
		r8 = sffixupd(r5,r2)
		p1 = cmp.gtu(r1,#31)
	}
	{
		r9 = sffixupn(r5,r2)
	}
	{
		r6 -= sfmpy(r8,r7):lib
	}
	{
		r2 = and(r9,##-2147483648)
	}
	{
		r7 += sfmpy(r6,r7):lib
		r6 = r9
	}
	{
		r2 += sfmpy(r9,r7):lib
		r5 -= sfmpy(r8,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r6 -= sfmpy(r8,r2):lib
	}
	{
		r2 += sfmpy(r6,r7):lib
	}
	{
		r9 -= sfmpy(r2,r8):lib
	}
	{
		r2 += sfmpy(r9,r7,p0):scale
		if (!p1) jump:nt .LBB5_3
	}
// %bb.1:                               // %for.body.lr.ph
	{
		v0 = vsplat(r2)
		v1 = vsplat(r3)
		r2 = ##1262485504
	}
	{
		r5 = lsr(r1,#5)
		v2 = vsplat(r2)
	}
	{
		loop0(.LBB5_2,r5)
	}
	.balign 32
.LBB5_2:                                // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r0 = add(r0,#128)
		v3 = vmemu(r0+#0)
	}
	{
		v4.qf32 = vmpy(v3.sf,v0.sf)
	}
	{
		v5.qf32 = vadd(v4.qf32,v2.sf)
	}
	{
		v6.sf = v5.qf32
	}
	{
		v7.w = vsub(v6.w,v2.w)
	}
	{
		v8.w = vadd(v7.w,v1.w)
	}
	{
		v9.h = vpack(v8.w,v8.w):sat
	}
	{
		v10.ub = vpack(v9.h,v9.h):sat
	}
	{
		r4 = add(r4,#2048)
		vmemu(r4+#0) = v10
	} :endloop0
	.falign
.LBB5_3:                                // %for.cond.cleanup
	{
		jumpr r31
	}
.Lfunc_end5:
	.size	hvx_quant_pack_u8_ah_m1_repeat, .Lfunc_end5-hvx_quant_pack_u8_ah_m1_repeat
                                        // -- End function
	.globl	hvx_quant_pack_u8_ah            // -- Begin function hvx_quant_pack_u8_ah
	.balign 32
	.type	hvx_quant_pack_u8_ah,@function
hvx_quant_pack_u8_ah:                   // @hvx_quant_pack_u8_ah
// %bb.0:                               // %entry
	{
		r4 = r3
		r3 = r2
		r6 = r4
		allocframe(#16)
	}
	{
		r2 = memw(r29+#28)
		memw(r29+#8) = r2.new
	}
	{
		r1 = #0
		r5 = r6
		r2 = r1
		memw(r29+#0) = r5
	}
	{
		call hvx_quant_pack_u8_ah_mapped
		r7 = memw(r29+#24)
		memw(r29+#4) = r7.new
	}
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	hvx_quant_pack_u8_ah, .Lfunc_end6-hvx_quant_pack_u8_ah
                                        // -- End function
	.globl	hvx_quant_pack_u8_ah_mapped     // -- Begin function hvx_quant_pack_u8_ah_mapped
	.falign
	.type	hvx_quant_pack_u8_ah_mapped,@function
hvx_quant_pack_u8_ah_mapped:            // @hvx_quant_pack_u8_ah_mapped
// %bb.0:                               // %entry
	{
		p2 = cmp.gtu(r3,r2)
		allocframe(r29,#384):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r4,r5)
		r19:18 = combine(r0,r1)
		memd(r30+#-8) = r17:16
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r21 = r2
		memd(r30+#-24) = r21:20
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r24 = memw(r30+#12)
		memd(r30+#-32) = r23:22
	}
	{
		if (!p2) jump:nt .LBB7_2
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r2 = and(r21,#-64)
		r1:0 = combine(#0,r24)
	}
	{
		r0 += mpyi(r2,r17)
		r3 = sub(r3,r2)
	}
	{
		r2 = mpyi(r3,r17)
		call memset
	}
	.falign
.LBB7_2:                                // %if.end
	{
		r20 = lsr(r17,#5)
		r2 = #-4
		r26 = and(r21,#-4)
		r25 = memw(r30+#8)
	}
	{
		r23 = asl(r26,#7)
		p1 = bitsclr(r21,r2)
		if (p1.new) jump:nt .LBB7_16
	}
// %bb.3:                               // %if.then7
	{
		call malloc
		r0 = r23
	}
	.falign
// %bb.4:                               // %if.then7
	{
		call malloc
		r22 = r0
		r0 = r23
	}
	.falign
// %bb.5:                               // %if.then7
	{
		r23 = r0
		p0 = cmp.eq(r22,#0); if (p0.new) jump:nt .LBB7_22
	}
// %bb.6:                               // %if.then7
	{
		r5:4 = combine(r25,r16)
		p2 = cmp.eq(r23,#0)
		if (!p2.new) r8 = add(r23,#0)
		if (p2.new) jump:nt .LBB7_22
	}
// %bb.7:
	{
		r2 = ##1065353216
		p1 = cmp.gtu(r26,#1)
		r0 = memw(r30+#16)
	}
	{
		r9 = ##1065353216
		r3 = memw(r4++#4)
	}
	{
		if (p1) r14 = ##1065353216
		r6 = memw(r5++#4)
	}
	{
		r15,p0 = sfrecipa(r2,r3)
		v6 = vsplat(r6)
		if (p1) r10 = ##1065353216
	}
	{
		r6 = sffixupd(r2,r3)
		r7 = sffixupn(r2,r3)
		r3 = r22
	}
	{
		vmemu(r8++#1) = v6
	}
	{
		r9 -= sfmpy(r6,r15):lib
		r13 = and(r7,##-2147483648)
		if (p1) r28 = add(r7,#0)
	}
	{
		r15 += sfmpy(r9,r15):lib
		if (!p1) jump:nt .LBB7_13
	}
// %bb.8:                               // %for.body
	{
		p2 = cmp.gtu(r26,#2)
		r9 = memw(r4++#4)
		r12 = memw(r5++#4)
	}
	{
		r13 += sfmpy(r7,r15):lib
		r14 -= sfmpy(r6,r15):lib
	}
	{
		r12,p1 = sfrecipa(r2,r9)
		v7 = vsplat(r12)
	}
	{
		r1 = sffixupd(r2,r9)
	}
	{
		r15 += sfmpy(r14,r15):lib
		r14 = sffixupn(r2,r9)
		vmemu(r8++#1) = v7
	}
	{
		r28 -= sfmpy(r6,r13):lib
		r10 -= sfmpy(r1,r12):lib
	}
	{
		r9 = and(r14,##-2147483648)
	}
	{
		r12 += sfmpy(r10,r12):lib
		r13 += sfmpy(r28,r15):lib
		if (!p2) jump:nt .LBB7_12
	}
// %bb.9:                               // %for.body
	{
		r7 -= sfmpy(r13,r6):lib
		r6 = ##1065353216
		r10 = memw(r4++#4)
	}
	{
		r9 += sfmpy(r14,r12):lib
		r6 -= sfmpy(r1,r12):lib
		memw(r29+#92) = r0
		memw(r29+#88) = r23
	}                                       // 4-byte Folded Spill
	{
		r11,p2 = sfrecipa(r2,r10)
		r28 = sffixupd(r2,r10)
		r23 = r14
	}
	{
		r13 += sfmpy(r7,r15,p0):scale
		r0 = ##1065353216
		r27 = memw(r5++#4)
	}
	{
		r0 -= sfmpy(r28,r11):lib
		v8 = vsplat(r27)
		p0 = cmp.gtu(r26,#3)
	}
	{
		r27 = sffixupn(r2,r10)
		r12 += sfmpy(r6,r12):lib
	}
	{
		r23 -= sfmpy(r1,r9):lib
		v5 = vsplat(r13)
		r7:6 = combine(r14,r1)
		r13 = add(r26,#-3)
	}
	{
		r11 += sfmpy(r0,r11):lib
		r10 = and(r27,##-2147483648)
	}
	{
		loop0(.LBB7_10,r13)
		r9 += sfmpy(r23,r12):lib
		vmemu(r8++#1) = v8
	}
	{
		if (!p0) jump:nt .LBB7_11
	}
	.falign
.LBB7_10:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r14 -= sfmpy(r9,r1):lib
		r15 = ##1065353216
		r13 = memw(r4++#4)
	}
	{
		r10 += sfmpy(r27,r11):lib
		r15 -= sfmpy(r28,r11):lib
		r7:6 = combine(r27,r28)
		r0 = r27
	}
	{
		r9 += sfmpy(r14,r12,p1):scale
		p1 = or(p2,p2)
		r12 = r11
		r1 = memw(r5++#4)
	}
	{
		r28 = sffixupd(r2,r13)
		r11,p2 = sfrecipa(r2,r13)
		r23 = ##1065353216
	}
	{
		r0 -= sfmpy(r6,r10):lib
		r12 += sfmpy(r15,r12):lib
		vmemu(r3++#1) = v5
	}
	{
		r27 = sffixupn(r2,r13)
		v9 = vsplat(r1)
		r14 = r7
		r1 = r6
	}
	{
		r23 -= sfmpy(r28,r11):lib
		r10 += sfmpy(r0,r12):lib
	}
	{
		v5 = vsplat(r9)
		r13 = and(r27,##-2147483648)
	}
	{
		r9 = r10
		r10 = r13
		vmemu(r8++#1) = v9
	}
	{
		r11 += sfmpy(r23,r11):lib
		nop
	} :endloop0
	.falign
.LBB7_11:
	{
		p0 = or(p1,p1)
		r15:14 = combine(r12,r27)
		r13:12 = combine(r9,r11)
		r23 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		p1 = or(p2,p2)
		r1 = r28
		r9 = r10
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		vmemu(r3++#1) = v5
	}
	.falign
.LBB7_12:
	{
		r7 -= sfmpy(r13,r6):lib
	}
	{
		r13 += sfmpy(r7,r15,p0):scale
		p0 = or(p1,p1)
		r15 = r12
		r7:6 = combine(r14,r1)
	}
	{
		v10 = vsplat(r13)
		r13 = r9
	}
	{
		vmemu(r3++#1) = v10
	}
	.falign
.LBB7_13:
	{
		r13 += sfmpy(r7,r15):lib
		r2 -= sfmpy(r6,r15):lib
		r4 = r7
		memw(r29+#96) = r19
	}
	{
		r1 = add(pc,##quant_pack_worker@PCREL)
		memw(r29+#100) = r18
		memw(r29+#104) = r26
	}
	{
		r15 += sfmpy(r2,r15):lib
		r4 -= sfmpy(r6,r13):lib
		r2 = add(r29,#96)
		memw(r29+#108) = r17
	}
	{
		memw(r29+#112) = r20
		memw(r29+#116) = r22
	}
	{
		r13 += sfmpy(r4,r15):lib
		memw(r29+#120) = r23
		memw(r29+#124) = r24
	}
	{
		r7 -= sfmpy(r13,r6):lib
	}
	{
		r13 += sfmpy(r7,r15,p0):scale
	}
	{
		v11 = vsplat(r13)
	}
	{
		vmemu(r3++#1) = v11
	}
	{
		call hvx_worker_pool_run
		r3 = r20
	}
	.falign
// %bb.14:
	{
		call free
		r0 = r22
	}
	.falign
// %bb.15:
	{
		call free
		r0 = r23
	}
	.falign
.LBB7_16:                               // %if.end29
	{
		p0 = cmp.eq(r26,r21)
		r0 = #0
		if (!p0.new) r2 = #255
		if (p0.new) jump:t .LBB7_25
	}
// %bb.17:                              // %for.body34.lr.ph
	{
		if (p1.new) r4 = sub(r21,r26)
		p1 = cmp.gtu(r17,#31); if (!p1.new) jump:t .LBB7_25
		v0 = vxor(v0,v0)
	}
// %bb.18:                              // %for.body34.lr.ph.split
	{
		r3 = extractu(r20,#21,#0)
		p0 = cmp.eq(r18,#0)
	}
	{
		r3 = asl(r3,#11)
		v1 = vsplat(r2)
		r2 = ##1262485504
	}
	{
		v2 = vsplat(r2)
		r2 = ##1065353216
	}
	{
		loop1(.LBB7_19,r4)
	}
	.falign
.LBB7_19:                               // Block address taken
                                        // %for.body34
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_20 Depth 2
	{
		r8 = lsr(r26,#6)
		r6 = ##1065353216
		r5 = memw(r16+r26<<#2)
	}
	{
		r7 = ##1065353216
		r4 = r26
	}
	{
		r9,p1 = sfrecipa(r2,r5)
		if (!p0) r4 = memw(r18+r26<<#2)
	}
	{
		r12 = sffixupd(r2,r5)
		r5 = sffixupn(r2,r5)
	}
	{
		r8 = mpyi(r3,r8)
	}
	{
		r6 -= sfmpy(r12,r9):lib
		r13 = r5
		r14 = r5
	}
	{
		r13 = insert(r0,#31,#0)
		r9 += sfmpy(r6,r9):lib
		r6 = memw(r25+r26<<#2)
	}
	{
		v3 = vsplat(r6)
	}
	{
		r13 += sfmpy(r5,r9):lib
		r7 -= sfmpy(r12,r9):lib
	}
	{
		r9 += sfmpy(r7,r9):lib
		r14 -= sfmpy(r12,r13):lib
	}
	{
		r7 = mpyi(r4,r17)
		r4 = #0
	}
	{
		r4 = insert(r26,#6,#5)
		r13 += sfmpy(r14,r9):lib
	}
	{
		r4 += add(r24,r8)
	}
	{
		r5 -= sfmpy(r13,r12):lib
	}
	{
		r5 = addasl(r19,r7,#2)
		r13 += sfmpy(r5,r9,p1):scale
	}
	{
		loop0(.LBB7_20,r20)
	}
	{
		v4 = vsplat(r13)
	}
	.falign
.LBB7_20:                               // Block address taken
                                        // %for.body.i
                                        //   Parent Loop BB7_19 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r6 = add(r29,#128)
		r5 = add(r5,#128)
		v12 = vmemu(r5+#0)
	}
	{
		v13.qf32 = vmpy(v12.sf,v4.sf)
	}
	{
		v14.qf32 = vadd(v13.qf32,v2.sf)
	}
	{
		v15.sf = v14.qf32
	}
	{
		v16.w = vsub(v15.w,v2.w)
	}
	{
		v17.w = vadd(v16.w,v3.w)
	}
	{
		v18.w = vmax(v17.w,v0.w)
	}
	{
		v19.w = vmin(v18.w,v1.w)
		vmem(r6+#0) = v19.new
	}
	{
		r7 = memw(r6+#0)
		memb(r4+#0) = r7.new
	}
	{
		r6 = memw(r6+#4)
		memb(r4+#1) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#8)
		memb(r4+#2) = r7.new
	}
	{
		r7 = memw(r6+#12)
		memb(r4+#3) = r7.new
	}
	{
		r6 = memw(r6+#16)
		memb(r4+#4) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#20)
		memb(r4+#5) = r7.new
	}
	{
		r7 = memw(r6+#24)
		memb(r4+#6) = r7.new
	}
	{
		r6 = memw(r6+#28)
		memb(r4+#7) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#32)
		memb(r4+#8) = r7.new
	}
	{
		r7 = memw(r6+#36)
		memb(r4+#9) = r7.new
	}
	{
		r6 = memw(r6+#40)
		memb(r4+#10) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#44)
		memb(r4+#11) = r7.new
	}
	{
		r7 = memw(r6+#48)
		memb(r4+#12) = r7.new
	}
	{
		r6 = memw(r6+#52)
		memb(r4+#13) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#56)
		memb(r4+#14) = r7.new
	}
	{
		r7 = memw(r6+#60)
		memb(r4+#15) = r7.new
	}
	{
		r6 = memw(r6+#64)
		memb(r4+#16) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#68)
		memb(r4+#17) = r7.new
	}
	{
		r7 = memw(r6+#72)
		memb(r4+#18) = r7.new
	}
	{
		r6 = memw(r6+#76)
		memb(r4+#19) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#80)
		memb(r4+#20) = r7.new
	}
	{
		r7 = memw(r6+#84)
		memb(r4+#21) = r7.new
	}
	{
		r6 = memw(r6+#88)
		memb(r4+#22) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#92)
		memb(r4+#23) = r7.new
	}
	{
		r7 = memw(r6+#96)
		memb(r4+#24) = r7.new
	}
	{
		r6 = memw(r6+#100)
		memb(r4+#25) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#104)
		memb(r4+#26) = r7.new
	}
	{
		r7 = memw(r6+#108)
		memb(r4+#27) = r7.new
	}
	{
		r6 = memw(r6+#112)
		memb(r4+#28) = r6.new
	}
	{
		r6 = add(r29,#128)
	}
	{
		r7 = memw(r6+#116)
		memb(r4+#29) = r7.new
	}
	{
		r7 = memw(r6+#120)
		memb(r4+#30) = r7.new
	}
	{
		r4 = add(r4,#2048)
		r6 = memw(r6+#124)
		memb(r4+#31) = r6.new
	} :endloop0
// %bb.21:                              // %quant_pack_row_scalar.exit.loopexit
                                        //   in Loop: Header=BB7_19 Depth=1
	{
		r26 = add(r26,#1)
		nop
		nop
	} :endloop1
	{
		jump .LBB7_25
	}
	.falign
.LBB7_22:                               // %cleanup
	{
		call free
		r0 = r22
	}
	.falign
// %bb.23:                              // %cleanup
	{
		call free
		r0 = r23
	}
	.falign
// %bb.24:                              // %cleanup
	{
		r0 = ##-2147482622
	}
	.falign
.LBB7_25:                               // %cleanup53
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	hvx_quant_pack_u8_ah_mapped, .Lfunc_end7-hvx_quant_pack_u8_ah_mapped
                                        // -- End function
	.falign
	.type	quant_pack_worker,@function     // -- Begin function quant_pack_worker
quant_pack_worker:                      // @quant_pack_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r22 = memw(r2+#16)
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		memd(r29+#8) = r21:20
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.1:                               // %entry
	{
		r4 = add(r17,#1)
		r19:18 = combine(r1,r0)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r22,r4)
		call __hexagon_udivdi3
	}
	.falign
// %bb.2:                               // %entry
	{
		p1 = cmp.gtu(r0,r18); if (!p1.new) jump:t .LBB8_13
		if (p1.new) r2 = memw(r16+#8)
	}
// %bb.3:                               // %for.cond12.preheader.lr.ph
	{
		if (!p0.new) r3 = sub(r0,r18)
		if (!p0.new) r7 = #1
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB8_13
	}
// %bb.4:
	{
		loop0(.LBB8_5,r3)
		r2 = ##1262485504
	}
	{
		v0 = vsplat(r2)
	}
	.falign
.LBB8_5:                                // Block address taken
                                        // %for.cond12.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB8_7 Depth 2
	{
		r2 = asl(r18,#5)
		r3 = #0
		p1 = cmp.eq(r7,#0); if (p1.new) jump:nt .LBB8_12
	}
// %bb.6:                               // %for.body16.lr.ph
                                        //   in Loop: Header=BB8_5 Depth=1
	{
		r6 = #0
		r5:4 = combine(#0,#0)
	}
	.falign
.LBB8_7:                                // %for.body16
                                        //   Parent Loop BB8_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r9 = setbit(r6,#0)
		r7 = memw(r16+#4)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB8_9
	}
// %bb.8:                               // %cond.true55
                                        //   in Loop: Header=BB8_7 Depth=2
	{
		r13 = add(r7,r4)
		r8 = memw(r7+r4<<#0)
		r12 = memw(r16+#12)
	}
	{
		r7 = setbit(r6,#1)
		r28 = memw(r13+#4)
		r0 = memw(r13+#8)
	}
	{
		r15 = mpyi(r12,r8)
		r8 = or(r6,#3)
		r14 = memw(r13+#12)
	}
	{
		r28 = mpyi(r28,r12)
		r13 = mpyi(r0,r12)
		jump .LBB8_10
	}
	.falign
.LBB8_9:                                // %cond.false58
                                        //   in Loop: Header=BB8_7 Depth=2
	{
		r9 = add(r6,#1)
		r7 = add(r6,#2)
		r8 = add(r6,#3)
		r12 = memw(r16+#12)
	}
	{
		r14 = r8
	}
	{
		r15 = mpyi(r12,r6)
		r28 = mpyi(r12,r9)
	}
	{
		r13 = mpyi(r12,r7)
	}
	.falign
.LBB8_10:                               // %cond.end60
                                        //   in Loop: Header=BB8_7 Depth=2
	{
		r14 = mpyi(r14,r12)
		r4 = add(r4,#16)
		r1 = memw(r16+#20)
		r0 = memw(r16+#0)
	}
	{
		r15 = addasl(r0,r15,#2)
		r28 = addasl(r0,r28,#2)
		r10 = add(r1,r5)
		r12 = memw(r16+#24)
	}
	{
		r10 = addasl(r1,r7,#7)
		r13 = addasl(r0,r13,#2)
		v2 = vmemu(r10+#0)
	}
	{
		r11 = addasl(r1,r9,#7)
		r15 = addasl(r15,r2,#2)
	}
	{
		r10 = addasl(r0,r2,#2)
		r28 = addasl(r28,r2,#2)
		v4 = vmemu(r10+#0)
	}
	{
		r1 = addasl(r1,r8,#7)
		r13 = addasl(r13,r2,#2)
		v5 = vmemu(r15+#0)
	}
	{
		r14 = addasl(r10,r14,#2)
		r7 = addasl(r12,r7,#7)
		v3 = vmemu(r11+#0)
	}
	{
		v9.qf32 = vmpy(v5.sf,v2.sf)
		r11 = add(r12,r5)
		v6 = vmemu(r28+#0)
	}
	{
		r1 = extractu(r3,#11,#0)
		r0 = r18
		v7 = vmemu(r1+#0)
	}
	{
		v11.qf32 = vmpy(v6.sf,v3.sf)
		v15.qf32 = vadd(v9.qf32,v0.sf)
		v10 = vmemu(r14+#0)
	}
	{
		r5 = add(r5,#512)
		r3 = add(r3,#128)
		v8 = vmemu(r13+#0)
	}
	{
		v14.qf32 = vmpy(v10.sf,v7.sf)
		v16.qf32 = vadd(v11.qf32,v0.sf)
		v1 = vmemu(r11+#0)
	}
	{
		r11 = addasl(r12,r9,#7)
		v12.qf32 = vmpy(v8.sf,v4.sf)
		v19 = vmemu(r7+#0)
	}
	{
		r7 = addasl(r12,r8,#7)
		v18.qf32 = vadd(v14.qf32,v0.sf)
		v20.sf = v15.qf32
		r15 = memw(r16+#16)
	}
	{
		v17.qf32 = vadd(v12.qf32,v0.sf)
		v21.sf = v16.qf32
		v24.w = vsub(v20.w,v0.w)
		r14 = memw(r16+#28)
	}
	{
		v23.sf = v18.qf32
		v25.w = vsub(v21.w,v0.w)
		v26 = vmemu(r7+#0)
	}
	{
		v22.sf = v17.qf32
		v28.w = vsub(v23.w,v0.w)
		v13 = vmemu(r11+#0)
	}
	{
		v27.w = vsub(v22.w,v0.w)
		v29.w = vadd(v24.w,v1.w)
		v30.w = vadd(v25.w,v13.w)
		v1.w = vadd(v28.w,v26.w)
	}
	{
		r7 = lsr(r6,#6)
		r6 = add(r6,#4)
		v31.w = vadd(v27.w,v19.w)
	}
	{
		r0 += mpyi(r15,r7)
		r7 = add(r14,r1)
		v2.h = vpack(v30.w,v29.w):sat
	}
	{
		r7 += asl(r0,#11)
		v3.h = vpack(v1.w,v31.w):sat
	}
	{
		v31.ub = vpack(v3.h,v2.h):sat
	}
	{
		vmemu(r7+#0) = v31
	}
	{
		r7 = memw(r16+#8)
		if (cmp.gtu(r7.new,r6)) jump:t .LBB8_7
	}
// %bb.11:                              // %for.cond.cleanup15
                                        //   in Loop: Header=BB8_5 Depth=1
	{
		r18 = add(r18,#1)
		nop
	} :endloop0
	{
		jump .LBB8_13
	}
	.falign
.LBB8_12:                               //   in Loop: Header=BB8_5 Depth=1
	{
		nop
		r7 = #0
		r18 = add(r18,#1)
	} :endloop0
	.falign
.LBB8_13:                               // %for.cond.cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	quant_pack_worker, .Lfunc_end8-quant_pack_worker
                                        // -- End function
	.globl	hvx_quant_params_pack_u8_ah     // -- Begin function hvx_quant_params_pack_u8_ah
	.falign
	.type	hvx_quant_params_pack_u8_ah,@function
hvx_quant_params_pack_u8_ah:            // @hvx_quant_params_pack_u8_ah
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r1,#0)
		allocframe(r29,#1024):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		memw(r29+#60) = r1
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Spill
	{
		r20 = r2
		r2 = memw(r30+#12)
		memd(r30+#-24) = r21:20
	}
	{
		r3 = p0
		r18 = r3
		memd(r30+#-16) = r19:18
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r24 = r4
		memd(r30+#-40) = r25:24
		memw(r29+#64) = r2
	}                                       // 8-byte Folded Spill
	{
		r2 = ##-2147483648
		r19 = memw(r30+#20)
		memd(r30+#-8) = r17:16
	}
	{
		if (!p0) r25 = add(r2,##1038)
		r23 = memw(r30+#8)
		memd(r30+#-48) = r27:26
	}
	{
		if (p0) jump:nt .LBB9_8
		memw(r29+#32) = r3
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %land.lhs.true
	{
		p0 = !bitsclr(r18,#63)
		if (p0.new) jump:nt .LBB9_50
	}
// %bb.2:                               // %land.lhs.true
	{
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB9_50
	}
// %bb.3:                               // %land.lhs.true
	{
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB9_50
	}
// %bb.4:                               // %land.lhs.true
	{
		r2 = memw(r29+#64)
		if (!cmp.eq(r2.new,#0)) jump:nt ##.LBB9_50
	}                                       // 4-byte Folded Reload
// %bb.5:                               // %land.lhs.true
	{
		r16 = r5
		if (!p0.new) r1:0 = combine(r18,r23)
		p0 = cmp.eq(r19,#0); if (p0.new) jump:nt .LBB9_50
	}
// %bb.6:                               // %lor.lhs.false8
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.7:                               // %lor.lhs.false8
	{
		r5 = r16
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB9_50
	}
	.falign
.LBB9_8:                                // %if.end
	{
		p0 = cmp.gtu(r5,r24)
		r26 = ##1065385983
		r1 = memw(r30+#28)
	}
	{
		if (p0) r4 = add(r26,##-32767)
		r2 = memw(r30+#32)
		r0 = memw(r30+#24)
	}
	{
		if (p0) r7 = sub(r5,r24)
		memw(r29+#40) = r2
		memw(r29+#24) = r1
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB9_13
		memw(r29+#28) = r0
	}                                       // 4-byte Folded Spill
// %bb.9:                               // %for.body.preheader
	{
		r6 = #0
		r2 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB9_10,r7)
		r2 = addasl(r2,r24,#2)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r24,#2)
	}
	.falign
.LBB9_10:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r3++#4) = r4
		memw(r2++#4) = r6
	} :endloop0
// %bb.11:                              // %for.cond.cleanup
	{
		if (p0) r1 = #0
		if (!p0) jump:nt .LBB9_13
		if (p0) r0 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
// %bb.12:                              // %if.then14
	{
		r2 = and(r24,#-64)
	}
	{
		r0 += mpyi(r2,r23)
		r3 = sub(r5,r2)
	}
	{
		r2 = mpyi(r3,r23)
		call memset
	}
	.falign
.LBB9_13:                               // %if.end18
	{
		r3 = lsr(r24,#2)
		r2 = #-4
		r16 = and(r24,#-4)
		r21 = memw(r30+#16)
	}
	{
		p0 = bitsclr(r24,r2)
		if (p0.new) jump:nt .LBB9_15
		if (!p0.new) r4 = memw(r29+#44)
		if (!p0.new) r6 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
// %bb.14:                              // %if.then22
	{
		r1 = add(pc,##quant_params_pack_worker@PCREL)
		r2 = add(r29,#80)
	}
	{
		r7 = memw(r29+#28)
		memw(r29+#84) = r6
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r30+#36)
		memw(r29+#104) = r7
	}
	{
		r6 = memw(r29+#24)
		memw(r29+#108) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#40)
		memw(r29+#96) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#64)
		memw(r29+#80) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#88) = r20
		memw(r29+#92) = r18
	}
	{
		memw(r29+#100) = r23
		memw(r29+#112) = r7
	}
	{
		memw(r29+#116) = r6
		memw(r29+#120) = r21
	}
	{
		call hvx_worker_pool_run
		memw(r29+#124) = r19
	}
	.falign
.LBB9_15:                               // %if.end33
	{
		p0 = cmp.eq(r19,#0)
		p1 = cmp.eq(r16,r24)
		r25 = #0
		if (p1.new) jump:t .LBB9_50
	}
// %bb.16:                              // %for.body38.lr.ph
	{
		r21 = and(r23,#-32)
		r27 = add(r26,#-32767)
		r6 = #0
		memw(r29+#76) = r21
	}                                       // 4-byte Folded Spill
	{
		r5 = lsr(r23,#5)
		r2 = p0
		p0 = cmp.gtu(r23,#31)
	}
	{
		r1 = p0
		r0 = #255
		r3 = ##1262485504
	}
	{
		r4 = extractu(r5,#25,#0)
		v1 = vsplat(r0)
		vmem(r29+#5) = v1.new
	}                                       // 128-byte Folded Spill
	{
		v10 = vsplat(r3)
		v0 = vxor(v0,v0)
		r1 = add(r5,#-1)
		memw(r29+#16) = r1
	}                                       // 4-byte Folded Spill
	{
		r6 = insert(r21,#26,#6)
		r0 = asl(r4,#7)
		memw(r29+#68) = r2
		vmem(r29+#6) = v10
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#48) = r5
		vmem(r29+#4) = v0
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#72) = r1
		memw(r29+#52) = r6
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#56) = r0
		memw(r29+#36) = r21
	}                                       // 4-byte Folded Spill
	.falign
.LBB9_17:                               // %for.body38
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB9_21 Depth 2
                                        //       Child Loop BB9_23 Depth 3
                                        //     Child Loop BB9_35 Depth 2
                                        //     Child Loop BB9_40 Depth 2
                                        //     Child Loop BB9_48 Depth 2
	{
		r17 = mpyi(r16,r23)
		r1:0 = combine(r18,r23)
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) r3 = add(r23,#0)
		if (p1.new) jump:nt .LBB9_28
		if (p1.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.18:                              // %if.then42
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		p1 = cmp.gtu(r18,r23)
	}
	{
		r2 = p1
	}
	{
		call __hexagon_udivsi3
		r22 = r2
	}
	.falign
// %bb.19:                              // %if.then42
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r26 = r19
		r4 = r20
		r2 = r22
	}
	{
		p0 = r2
		if (!p0.new) r3 = #0
		if (p0.new) jump:t .LBB9_31
		if (!p0.new) r2 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
// %bb.20:                              //   in Loop: Header=BB9_17 Depth=1
	{
		loop1(.LBB9_21,r0)
		r2 = addasl(r2,r17,#1)
	}
	.falign
.LBB9_21:                               // Block address taken
                                        // %for.body.i
                                        //   Parent Loop BB9_17 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB9_23 Depth 3
	{
		r6 = addasl(r20,r3,#3)
		r7 = mpyi(r3,r18)
		r5 = add(r18,#63)
		r8 = memw(r4+#0)
	}
	{
		r12 = lsr(r5,#6)
		v2 = vsplat(r8)
	}
	{
		r8 = addasl(r2,r7,#1)
		r9 = lsr(r12,#1)
		r6 = memw(r6+#4)
	}
	{
		r5 = addasl(r19,r7,#2)
		v3 = vsplat(r6)
		p0 = cmp.gtu(r9,#0)
		r7 = and(r12,#1)
	}
	{
		r6 = r8
		if (!p0) jump:nt .LBB9_24
	}
// %bb.22:                              //   in Loop: Header=BB9_21 Depth=2
	{
		loop0(.LBB9_23,r9)
	}
	.falign
.LBB9_23:                               //   Parent Loop BB9_17 Depth=1
                                        //     Parent Loop BB9_21 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v8 = vmemu(r6++#2)
	}
	{
		v1:0.uw = vunpack(v8.uh)
	}
	{
		v9.sf = v0.w
		v10.sf = v1.w
	}
	{
		v11.qf32 = vsub(v9.sf,v3.sf)
		v12.qf32 = vsub(v10.sf,v3.sf)
	}
	{
		v13.sf = v11.qf32
		v14.sf = v12.qf32
	}
	{
		v15.qf32 = vmpy(v13.sf,v2.sf)
	}
	{
		v16.qf32 = vmpy(v14.sf,v2.sf)
	}
	{
		v17.sf = v15.qf32
	}
	{
		v18.sf = v16.qf32
	}
	{
		vmemu(r5+#0) = v17
	}
	{
		vmemu(r5+#1) = v18
	}
	{
		r8 = r6
		v19 = vmemu(r8+#1)
	}
	{
		v5:4.uw = vunpack(v19.uh)
	}
	{
		v20.sf = v4.w
		v21.sf = v5.w
	}
	{
		v22.qf32 = vsub(v20.sf,v3.sf)
		v23.qf32 = vsub(v21.sf,v3.sf)
	}
	{
		v24.sf = v22.qf32
		v25.sf = v23.qf32
	}
	{
		v26.qf32 = vmpy(v24.sf,v2.sf)
	}
	{
		v27.qf32 = vmpy(v25.sf,v2.sf)
	}
	{
		v28.sf = v26.qf32
	}
	{
		v29.sf = v27.qf32
	}
	{
		vmemu(r5+#2) = v28
	}
	{
		r5 = add(r5,#512)
		vmemu(r5+#3) = v29
	} :endloop0
	.falign
.LBB9_24:                               //   in Loop: Header=BB9_21 Depth=2
	{
		p1 = cmp.gtu(r7,#0); if (!p1.new) jump:t .LBB9_26
	}
	.falign
.LBB9_25:                               // Block address taken
                                        // %for.body10.i
                                        //   in Loop: Header=BB9_21 Depth=2
	{
		v30 = vmemu(r6++#1)
	}
	{
		v7:6.uw = vunpack(v30.uh)
	}
	{
		v31.sf = v6.w
		v0.sf = v7.w
	}
	{
		v1.qf32 = vsub(v31.sf,v3.sf)
		v28.qf32 = vsub(v0.sf,v3.sf)
	}
	{
		v4.sf = v1.qf32
		v5.sf = v28.qf32
	}
	{
		v29.qf32 = vmpy(v4.sf,v2.sf)
	}
	{
		v30.qf32 = vmpy(v5.sf,v2.sf)
	}
	{
		v31.sf = v29.qf32
	}
	{
		v8.sf = v30.qf32
	}
	{
		vmemu(r5++#1) = v31
	}
	{
		vmemu(r5++#1) = v8
	}
	.falign
.LBB9_26:                               // %for.cond.cleanup9.i
                                        //   in Loop: Header=BB9_21 Depth=2
	{
		nop
		nop
		r4 = add(r4,#8)
		r3 = add(r3,#1)
	} :endloop1
// %bb.27:                              //   in Loop: Header=BB9_17 Depth=1
	{
		r26 = r19
		jump .LBB9_31
	}
	.falign
.LBB9_28:                               // %if.else
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r0 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		r26 = addasl(r2,r17,#2)
		p1 = r0
		if (p1.new) jump:nt .LBB9_31
		if (!p1.new) r2 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.29:                              // %if.then46
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		call hvx_rmsnorm_row_f32
		r1:0 = combine(r19,r26)
		r4 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.30:                              // %if.then46
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r26 = r19
	}
	.falign
.LBB9_31:                               // %if.end48
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB9_33
		if (!p1.new) r3 = memw(r26+#0)
	}
// %bb.32:                              //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = r3
		p0 = cmp.eq(r21,r23)
		v7 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v8 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		if (p0) jump:nt .LBB9_42
		v9 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		jump .LBB9_39
	}
	.falign
.LBB9_33:                               // %if.then.i
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		p0 = cmp.gtu(r23,#63)
		if (!p0.new) jump:t .LBB9_37
		v4 = vmemu(r26+#0)
	}
// %bb.34:                              // %for.body.i138.preheader
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = add(r26,#128)
		v6 = v4
		r3 = memw(r29+#72)
		v8 = vmem(r29+#5)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r3,#1)
		r3 = add(r3,#-1)
		v5 = vmemu(r2++#1)
	}
	{
		loop0(.LBB9_35,r3)
		if (!p1) jump:nt .LBB9_36
	}
	.falign
.LBB9_35:                               // %for.body.i138
                                        //   Parent Loop BB9_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v4.sf = vmin(v4.sf,v5.sf)
		v6.sf = vmax(v6.sf,v5.sf)
		v5 = vmemu(r2++#1)
	} :endloop0
	.falign
.LBB9_36:                               //   in Loop: Header=BB9_17 Depth=1
	{
		jump .LBB9_38
		v7.sf = vmin(v4.sf,v5.sf)
		v4.sf = vmax(v6.sf,v5.sf)
	}
	.falign
.LBB9_37:                               //   in Loop: Header=BB9_17 Depth=1
	{
		v7 = v4
		v8 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	.falign
.LBB9_38:                               // %for.body10.i137
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = #64
		p0 = cmp.eq(r21,r23)
	}
	{
		v9 = vror(v7,r2)
	}
	{
		r2 = #32
		v11 = vror(v4,r2)
		v10.sf = vmin(v7.sf,v9.sf)
		v7 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v12.sf = vmax(v4.sf,v11.sf)
		v9 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		v13 = vror(v10,r2)
	}
	{
		r2 = #16
		v15 = vror(v12,r2)
		v14.sf = vmin(v10.sf,v13.sf)
	}
	{
		v16.sf = vmax(v12.sf,v15.sf)
	}
	{
		v17 = vror(v14,r2)
	}
	{
		r2 = #8
		v19 = vror(v16,r2)
		v18.sf = vmin(v14.sf,v17.sf)
	}
	{
		v20.sf = vmax(v16.sf,v19.sf)
	}
	{
		v21 = vror(v18,r2)
	}
	{
		v22 = vror(v20,r2)
		v23.sf = vmin(v18.sf,v21.sf)
	}
	{
		v24.sf = vmax(v20.sf,v22.sf)
	}
	{
		v25 = valign(v23,v23,#4)
	}
	{
		v26 = valign(v24,v24,#4)
		v27.sf = vmin(v23.sf,v25.sf)
		vmem(r29+#2) = v27.new
	}
	{
		v28.sf = vmax(v24.sf,v26.sf)
		r2 = memw(r29+#256)
		vmem(r29+#1) = v28.new
	}
	{
		if (p0) jump:nt .LBB9_42
		r3 = memw(r29+#128)
	}
	.falign
.LBB9_39:                               // %for.body21.i.preheader
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r5 = sub(r23,r21)
		r4 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r26,r4)
		r6 = add(r5,#-1)
		p0 = cmp.gtu(r5,#1)
	}
	{
		loop0(.LBB9_40,r6)
		if (!p0) jump:nt .LBB9_41
		r5 = memw(r4++#4)
	}
	.falign
.LBB9_40:                               // %for.body21.i
                                        //   Parent Loop BB9_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = sfmin(r5,r2)
		r3 = sfmax(r5,r3)
		r5 = memw(r4++#4)
	} :endloop0
	.falign
.LBB9_41:                               //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = sfmin(r5,r2)
		r3 = sfmax(r5,r3)
	}
	.falign
.LBB9_42:                               // %for.cond.cleanup20.i
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = sfmin(r2,r25)
		r3 = sfmax(r3,r25)
		r4 = memw(r29+#28)
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		p1 = sfcmp.uo(r2,r3)
		p0 = sfcmp.eq(r2,r3)
	}
	{
		r21 = addasl(r4,r16,#2)
		p1 = and(p0,!p1)
		if (!p1.new) r8 = ##1132396544
	}
	{
		r22 = addasl(r0,r16,#2)
		r3 = sfsub(r3,r2)
		if (!p1) jump:nt .LBB9_44
		if (p1) r17 = memw(r21+#0)
	}
// %bb.43:                              // %for.cond.cleanup20.i.quant_row_params_one.exit_crit_edge
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		jump .LBB9_46
		r3 = memw(r22+#0)
	}
	.falign
.LBB9_44:                               // %if.end43.i
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r6 = sffixupn(r3,r8)
		r7,p1 = sfrecipa(r3,r8)
		r5:4 = combine(r27,r27)
	}
	{
		r2 = togglebit(r2,#31)
	}
	{
		r3 = sffixupd(r3,r8)
		r15:14 = combine(r6,r6)
	}
	{
		r14 = insert(r25,#31,#0)
		r4 -= sfmpy(r3,r7):lib
	}
	{
		r17 = r14
	}
	{
		r7 += sfmpy(r4,r7):lib
	}
	{
		r17 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r3,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r15 -= sfmpy(r3,r17):lib
		r5 = r27
	}
	{
		r17 += sfmpy(r15,r7):lib
	}
	{
		r6 -= sfmpy(r17,r3):lib
	}
	{
		r17 += sfmpy(r6,r7,p1):scale
		r6 = r27
	}
	{
		r3,p0 = sfrecipa(r2,r17)
		r4 = sffixupd(r2,r17)
	}
	{
		r2 = sffixupn(r2,r17)
	}
	{
		r6 -= sfmpy(r4,r3):lib
		r0 = r2
		r1 = r2
	}
	{
		r0 = insert(r14,#31,#0)
		r3 += sfmpy(r6,r3):lib
	}
	{
		r0 += sfmpy(r2,r3):lib
		r5 -= sfmpy(r4,r3):lib
	}
	{
		r1 -= sfmpy(r4,r0):lib
		r3 += sfmpy(r5,r3):lib
	}
	{
		r0 += sfmpy(r1,r3):lib
	}
	{
		r2 -= sfmpy(r0,r4):lib
	}
	{
		call nearbyintf
		r0 += sfmpy(r2,r3,p0):scale
	}
	.falign
// %bb.45:                              // %if.end43.i
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r2 = convert_sf2w(r0):chop
		v9 = vmem(r29+#6)
		memw(r21+#0) = r17
	}                                       // 128-byte Folded Reload
	{
		v8 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		r3 = satub(r2)
		v7 = vmem(r29+#4)
		memw(r22+#0) = r3.new
	}                                       // 128-byte Folded Reload
	.falign
.LBB9_46:                               // %quant_row_params_one.exit
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r4,p1 = sfrecipa(r27,r17)
		r5 = sffixupd(r27,r17)
		r7:6 = combine(r27,r27)
		r21 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r8 = sffixupn(r27,r17)
		r2 = ##-2147483648
		r0 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r6 -= sfmpy(r5,r4):lib
		p0 = r0
		r2 = and(r8,r2)
		if (p0.new) r0 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		v1 = vsplat(r3)
		r1 = r8
	}
	{
		r4 += sfmpy(r6,r4):lib
	}
	{
		r2 += sfmpy(r8,r4):lib
		r7 -= sfmpy(r5,r4):lib
	}
	{
		r4 += sfmpy(r7,r4):lib
		r1 -= sfmpy(r5,r2):lib
	}
	{
		r2 += sfmpy(r1,r4):lib
		if (p0) r1 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r8 -= sfmpy(r2,r5):lib
	}
	{
		r2 += sfmpy(r8,r4,p1):scale
		if (!p0) jump:nt .LBB9_49
	}
// %bb.47:                              // %for.body.lr.ph.i
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r3 = lsr(r16,#6)
		v0 = vsplat(r2)
		r2 = r16
		r4 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(##2016,asl(r2,#5))
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r2 += add(r0,r3)
	}
	{
		loop0(.LBB9_48,r1)
	}
	.falign
.LBB9_48:                               // Block address taken
                                        // %for.body.i140
                                        //   Parent Loop BB9_17 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = add(r29,#384)
		r26 = add(r26,#128)
		v29 = vmemu(r26+#0)
	}
	{
		v30.qf32 = vmpy(v29.sf,v0.sf)
	}
	{
		v31.qf32 = vadd(v30.qf32,v9.sf)
	}
	{
		v3.sf = v31.qf32
	}
	{
		v4.w = vsub(v3.w,v9.w)
	}
	{
		v5.w = vadd(v4.w,v1.w)
	}
	{
		v6.w = vmax(v5.w,v7.w)
	}
	{
		v2.w = vmin(v6.w,v8.w)
		vmem(r3+#0) = v2.new
	}
	{
		r4 = memw(r3+#0)
		memb(r2+#0) = r4.new
	}
	{
		r3 = memw(r3+#4)
		memb(r2+#1) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r1 = memw(r3+#8)
		memb(r2+#2) = r1.new
	}
	{
		r4 = memw(r3+#12)
		memb(r2+#3) = r4.new
	}
	{
		r3 = memw(r3+#16)
		memb(r2+#4) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r0 = memw(r3+#20)
		memb(r2+#5) = r0.new
	}
	{
		r4 = memw(r3+#24)
		memb(r2+#6) = r4.new
	}
	{
		r3 = memw(r3+#28)
		memb(r2+#7) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r7 = memw(r3+#32)
		memb(r2+#8) = r7.new
	}
	{
		r4 = memw(r3+#36)
		memb(r2+#9) = r4.new
	}
	{
		r3 = memw(r3+#40)
		memb(r2+#10) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r6 = memw(r3+#44)
		memb(r2+#11) = r6.new
	}
	{
		r4 = memw(r3+#48)
		memb(r2+#12) = r4.new
	}
	{
		r3 = memw(r3+#52)
		memb(r2+#13) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r1 = memw(r3+#56)
		memb(r2+#14) = r1.new
	}
	{
		r4 = memw(r3+#60)
		memb(r2+#15) = r4.new
	}
	{
		r3 = memw(r3+#64)
		memb(r2+#16) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r0 = memw(r3+#68)
		memb(r2+#17) = r0.new
	}
	{
		r4 = memw(r3+#72)
		memb(r2+#18) = r4.new
	}
	{
		r3 = memw(r3+#76)
		memb(r2+#19) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r7 = memw(r3+#80)
		memb(r2+#20) = r7.new
	}
	{
		r4 = memw(r3+#84)
		memb(r2+#21) = r4.new
	}
	{
		r3 = memw(r3+#88)
		memb(r2+#22) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r6 = memw(r3+#92)
		memb(r2+#23) = r6.new
	}
	{
		r4 = memw(r3+#96)
		memb(r2+#24) = r4.new
	}
	{
		r3 = memw(r3+#100)
		memb(r2+#25) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r1 = memw(r3+#104)
		memb(r2+#26) = r1.new
	}
	{
		r4 = memw(r3+#108)
		memb(r2+#27) = r4.new
	}
	{
		r3 = memw(r3+#112)
		memb(r2+#28) = r3.new
	}
	{
		r3 = add(r29,#384)
	}
	{
		r0 = memw(r3+#116)
		memb(r2+#29) = r0.new
	}
	{
		r4 = memw(r3+#120)
		memb(r2+#30) = r4.new
	}
	{
		r2 = add(r2,#2048)
		r3 = memw(r3+#124)
		memb(r2+#31) = r3.new
	} :endloop0
	.falign
.LBB9_49:                               // %quant_pack_row_scalar.exit
                                        //   in Loop: Header=BB9_17 Depth=1
	{
		r16 = add(r16,#1)
		if (cmp.gtu(r24,r16.new)) jump:t ##.LBB9_17
	}
	.falign
.LBB9_50:                               // %cleanup
	{
		r0 = r25
		r19:18 = memd(r30+#-16)
		r17:16 = memd(r30+#-8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end9:
	.size	hvx_quant_params_pack_u8_ah, .Lfunc_end9-hvx_quant_params_pack_u8_ah
                                        // -- End function
	.falign
	.type	quant_params_pack_worker,@function // -- Begin function quant_params_pack_worker
quant_params_pack_worker:               // @quant_params_pack_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#1024):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r18 = memw(r2+#16)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		r17:16 = combine(r1,r2)
		memd(r30+#-24) = r21:20
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r18,r1)
		r3:2 = combine(r21,r20)
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r27:26 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r18,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r25 = ##1065385983
		r4 = r0
		r2 = memw(r16+#44)
	}
	{
		p3 = cmp.eq(r2,#0)
		if (!p3.new) r24 = #0
		if (p3.new) jump:nt .LBB10_36
		memd(r29+#120) = r5:4
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %cond.end
	{
		p2 = cmp.gtu(r0,r26)
		if (p2.new) r4 = #128
		if (!p2.new) jump:t .LBB10_63
		if (p2.new) r3 = memw(r16+#20)
	}
// %bb.4:                               // %for.body.lr.ph
	{
		r5 = ##1262485504
	}
	{
		v20 = vsplat(r5)
		vmem(r29+#5) = v20.new
	}                                       // 128-byte Folded Spill
	{
		r6 = mpyi(r17,r3)
		r3 = mpyi(r3,r17)
	}
	{
		r22 = addasl(r2,r6,#4)
		r5 = asl(r6,#2)
	}
	{
		r6 = addasl(r2,r5,#2)
		r7 = asl(r3,#4)
		memw(r29+#108) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r3 = addasl(r4,r3,#4)
		r6 = add(r2,r7)
		memw(r29+#768) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r2,r3)
		memw(r29+#80) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB10_5:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB10_6 Depth 2
                                        //       Child Loop BB10_10 Depth 3
                                        //         Child Loop BB10_12 Depth 4
                                        //       Child Loop BB10_21 Depth 3
                                        //       Child Loop BB10_26 Depth 3
                                        //     Child Loop BB10_34 Depth 2
	{
		r23 = asl(r26,#2)
		r0 = r26
		r27:26 = combine(#0,#0)
	}
	{
		memd(r29+#112) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB10_6:                               // %for.body34
                                        //   Parent Loop BB10_5 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB10_10 Depth 3
                                        //         Child Loop BB10_12 Depth 4
                                        //       Child Loop BB10_21 Depth 3
                                        //       Child Loop BB10_26 Depth 3
	{
		r21 = add(r27,r23)
		r18 = memw(r16+#4)
		if (cmp.eq(r18.new,#0)) jump:nt .LBB10_16
	}
// %bb.7:                               // %if.then36
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r17 = memw(r16+#12)
		r19 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r17,r19)
		r20 = memw(r16+#8)
	}
	.falign
// %bb.8:                               // %if.then36
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r5 = mpyi(r19,r27)
		r3 = mpyi(r19,r21)
		p3 = cmp.gtu(r17,r19)
		if (p3.new) jump:t .LBB10_17
	}
// %bb.9:                               //   in Loop: Header=BB10_6 Depth=2
	{
		r2 = #0
		r4 = r20
	}
	{
		r3 = addasl(r18,r3,#1)
		r5 = addasl(r22,r5,#2)
	}
	{
		loop1(.LBB10_10,r0)
	}
	.falign
.LBB10_10:                              // Block address taken
                                        // %for.body.i155
                                        //   Parent Loop BB10_5 Depth=1
                                        //     Parent Loop BB10_6 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB10_12 Depth 4
	{
		r7 = addasl(r20,r2,#3)
		r8 = mpyi(r2,r17)
		r6 = add(r17,#63)
		r9 = memw(r4+#0)
	}
	{
		r13 = lsr(r6,#6)
		v0 = vsplat(r9)
	}
	{
		r9 = addasl(r3,r8,#1)
		r12 = lsr(r13,#1)
		r7 = memw(r7+#4)
	}
	{
		r6 = addasl(r5,r8,#2)
		v9 = vsplat(r7)
		p2 = cmp.gtu(r12,#0)
		r8 = and(r13,#1)
	}
	{
		r7 = r9
		if (!p2) jump:nt .LBB10_13
	}
// %bb.11:                              //   in Loop: Header=BB10_10 Depth=3
	{
		loop0(.LBB10_12,r12)
	}
	.falign
.LBB10_12:                              //   Parent Loop BB10_5 Depth=1
                                        //     Parent Loop BB10_6 Depth=2
                                        //       Parent Loop BB10_10 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		v2 = vmemu(r7++#2)
	}
	{
		v3:2.uw = vunpack(v2.uh)
	}
	{
		v8.sf = v2.w
		v3.sf = v3.w
	}
	{
		v12.qf32 = vsub(v8.sf,v9.sf)
		v14.qf32 = vsub(v3.sf,v9.sf)
	}
	{
		v16.sf = v12.qf32
		v17.sf = v14.qf32
	}
	{
		v18.qf32 = vmpy(v16.sf,v0.sf)
	}
	{
		v1.qf32 = vmpy(v17.sf,v0.sf)
	}
	{
		v4.sf = v18.qf32
	}
	{
		v5.sf = v1.qf32
	}
	{
		vmemu(r6+#0) = v4
	}
	{
		vmemu(r6+#1) = v5
	}
	{
		r9 = r7
		v6 = vmemu(r9+#1)
	}
	{
		v31:30.uw = vunpack(v6.uh)
	}
	{
		v7.sf = v30.w
		v11.sf = v31.w
	}
	{
		v13.qf32 = vsub(v7.sf,v9.sf)
		v15.qf32 = vsub(v11.sf,v9.sf)
	}
	{
		v29.sf = v13.qf32
		v30.sf = v15.qf32
	}
	{
		v31.qf32 = vmpy(v29.sf,v0.sf)
	}
	{
		v10.qf32 = vmpy(v30.sf,v0.sf)
	}
	{
		v19.sf = v31.qf32
	}
	{
		v20.sf = v10.qf32
	}
	{
		vmemu(r6+#2) = v19
	}
	{
		r6 = add(r6,#512)
		vmemu(r6+#3) = v20
	} :endloop0
	.falign
.LBB10_13:                              //   in Loop: Header=BB10_10 Depth=3
	{
		p0 = cmp.gtu(r8,#0)
		if (!p0.new) jump:t .LBB10_15
	}
	.falign
.LBB10_14:                              // Block address taken
                                        // %for.body10.i158
                                        //   in Loop: Header=BB10_10 Depth=3
	{
		v21 = vmemu(r7++#1)
	}
	{
		v7:6.uw = vunpack(v21.uh)
	}
	{
		v22.sf = v6.w
		v23.sf = v7.w
	}
	{
		v24.qf32 = vsub(v22.sf,v9.sf)
		v23.qf32 = vsub(v23.sf,v9.sf)
	}
	{
		v25.sf = v24.qf32
		v26.sf = v23.qf32
	}
	{
		v27.qf32 = vmpy(v25.sf,v0.sf)
	}
	{
		v26.qf32 = vmpy(v26.sf,v0.sf)
	}
	{
		v28.sf = v27.qf32
	}
	{
		v2.sf = v26.qf32
	}
	{
		vmemu(r6++#1) = v28
	}
	{
		vmemu(r6++#1) = v2
	}
	.falign
.LBB10_15:                              //   in Loop: Header=BB10_10 Depth=3
	{
		nop
		nop
		r4 = add(r4,#8)
		r2 = add(r2,#1)
	} :endloop1
	{
		jump .LBB10_17
	}
	.falign
.LBB10_16:                              // %if.else
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r3 = memw(r16+#20)
		r5 = memw(r16+#0)
	}
	{
		r2 = memw(r16+#36)
		r4 = memw(r16+#40)
	}
	{
		r6 = mpyi(r3,r21)
		r7 = mpyi(r3,r27)
	}
	{
		r1 = addasl(r22,r7,#2)
		r0 = addasl(r5,r6,#2)
	}
	{
		call hvx_rmsnorm_row_f32
	}
	.falign
.LBB10_17:                              // %if.end55
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r2 = memw(r16+#20)
		r20 = memw(r16+#24)
	}
	{
		p3 = cmp.gtu(r2,#63)
		p1 = cmp.gtu(r2,#31)
		r17 = memw(r16+#28)
	}
	{
		r3 = mpyi(r2,r27)
		if (p1) jump:nt .LBB10_19
	}
// %bb.18:                              //   in Loop: Header=BB10_6 Depth=2
	{
		r4 = memw(r22+r3<<#2)
		v20 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		r3 = r4
		r5 = #-32
	}
	{
		p0 = bitsset(r5,r2)
		if (p0.new) jump:t .LBB10_28
	}
	{
		jump .LBB10_25
	}
	.falign
.LBB10_19:                              // %if.then.i165
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r3 = addasl(r22,r3,#2)
	}
	{
		if (!p3) jump:nt .LBB10_23
		v19 = vmemu(r3+#0)
	}
// %bb.20:                              // %for.body.i206.preheader
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r4 = lsr(r2,#5)
		v23 = v19
		r3 = memw(r29+#80)
		v20 = vmem(r29+#5)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r2,r26)
		r4 = add(r4,#-1)
	}
	{
		p2 = cmp.gtu(r4,#1)
		r4 = add(r4,#-1)
	}
	{
		loop0(.LBB10_21,r4)
		if (!p2) jump:nt .LBB10_22
		v22 = vmemu(r3++#1)
	}
	.falign
.LBB10_21:                              // %for.body.i206
                                        //   Parent Loop BB10_5 Depth=1
                                        //     Parent Loop BB10_6 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v19.sf = vmin(v19.sf,v22.sf)
		v23.sf = vmax(v23.sf,v22.sf)
		v22 = vmemu(r3++#1)
	} :endloop0
	.falign
.LBB10_22:                              //   in Loop: Header=BB10_6 Depth=2
	{
		jump .LBB10_24
		v25.sf = vmin(v19.sf,v22.sf)
		v19.sf = vmax(v23.sf,v22.sf)
	}
	.falign
.LBB10_23:                              //   in Loop: Header=BB10_6 Depth=2
	{
		v25 = v19
		v20 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	.falign
.LBB10_24:                              // %for.body10.i167
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r3 = #64
		r5 = #-32
	}
	{
		p0 = bitsset(r5,r2)
		v8 = vror(v25,r3)
	}
	{
		r3 = #32
		v12 = vror(v19,r3)
		v3.sf = vmin(v25.sf,v8.sf)
	}
	{
		v14.sf = vmax(v19.sf,v12.sf)
	}
	{
		v16 = vror(v3,r3)
	}
	{
		r3 = #16
		v18 = vror(v14,r3)
		v17.sf = vmin(v3.sf,v16.sf)
	}
	{
		v1.sf = vmax(v14.sf,v18.sf)
	}
	{
		v4 = vror(v17,r3)
	}
	{
		r3 = #8
		v6 = vror(v1,r3)
		v5.sf = vmin(v17.sf,v4.sf)
	}
	{
		v7.sf = vmax(v1.sf,v6.sf)
	}
	{
		v11 = vror(v5,r3)
	}
	{
		v13 = vror(v7,r3)
		v15.sf = vmin(v5.sf,v11.sf)
	}
	{
		v29.sf = vmax(v7.sf,v13.sf)
	}
	{
		v30 = valign(v15,v15,#4)
	}
	{
		v31 = valign(v29,v29,#4)
		v10.sf = vmin(v15.sf,v30.sf)
		vmem(r29+#2) = v10.new
	}
	{
		v31.sf = vmax(v29.sf,v31.sf)
		r3 = memw(r29+#256)
		vmem(r29+#1) = v31.new
	}
	{
		r4 = memw(r29+#128)
	}
	{
		if (p0) jump:nt .LBB10_28
	}
	.falign
.LBB10_25:                              // %for.body21.i177.preheader
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r6 = mpyi(r2,r26)
		r7 = and(r2,#-32)
		r5 = memw(r29+#768)
	}                                       // 4-byte Folded Reload
	{
		r8 = r6
		r2 = sub(r2,r7)
	}
	{
		r8 = insert(r7,#30,#2)
		r0 = add(r2,#-1)
		p0 = cmp.gtu(r2,#1)
	}
	{
		loop0(.LBB10_26,r0)
		r5 += add(r6,r8)
	}
	{
		if (!p0) jump:nt .LBB10_27
		r2 = memw(r5++#4)
	}
	.falign
.LBB10_26:                              // %for.body21.i177
                                        //   Parent Loop BB10_5 Depth=1
                                        //     Parent Loop BB10_6 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r3 = sfmin(r2,r3)
		r4 = sfmax(r2,r4)
		r2 = memw(r5++#4)
	} :endloop0
	.falign
.LBB10_27:                              //   in Loop: Header=BB10_6 Depth=2
	{
		r3 = sfmin(r2,r3)
		r4 = sfmax(r2,r4)
	}
	.falign
.LBB10_28:                              // %for.cond.cleanup20.i188
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r2 = sfmin(r3,r24)
		r3 = sfmax(r4,r24)
	}
	{
		p1 = sfcmp.uo(r2,r3)
		p3 = sfcmp.eq(r2,r3)
		r4 = add(r25,#-32767)
	}
	{
		r21 = addasl(r20,r23,#2)
		p2 = and(p3,!p1)
		if (!p2.new) r12 = ##1132396544
	}
	{
		r19 = addasl(r17,r23,#2)
		r3 = sfsub(r3,r2)
		if (!p2) r5 = add(r4,#0)
		if (p2) jump:nt .LBB10_31
	}
// %bb.29:                              // %if.end43.i196
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r0 = togglebit(r2,#31)
		r8 = sffixupn(r3,r12)
		r7:6 = combine(r4,r4)
	}
	{
		r9,p1 = sfrecipa(r3,r12)
	}
	{
		r3 = sffixupd(r3,r12)
		r15:14 = combine(r8,r8)
	}
	{
		r14 = insert(r24,#31,#0)
		r5 -= sfmpy(r3,r9):lib
	}
	{
		r9 += sfmpy(r5,r9):lib
		r18 = r14
	}
	{
		r18 += sfmpy(r8,r9):lib
		r6 -= sfmpy(r3,r9):lib
	}
	{
		r9 += sfmpy(r6,r9):lib
		r15 -= sfmpy(r3,r18):lib
	}
	{
		r18 += sfmpy(r15,r9):lib
	}
	{
		r8 -= sfmpy(r18,r3):lib
	}
	{
		r18 += sfmpy(r8,r9,p1):scale
	}
	{
		r3,p0 = sfrecipa(r0,r18)
		r5 = sffixupd(r0,r18)
	}
	{
		r2 = sffixupn(r0,r18)
	}
	{
		r7 -= sfmpy(r5,r3):lib
		r0 = r2
		r1 = r2
	}
	{
		r0 = insert(r14,#31,#0)
		r3 += sfmpy(r7,r3):lib
	}
	{
		r0 += sfmpy(r2,r3):lib
		r4 -= sfmpy(r5,r3):lib
	}
	{
		r1 -= sfmpy(r5,r0):lib
		r3 += sfmpy(r4,r3):lib
	}
	{
		r0 += sfmpy(r1,r3):lib
	}
	{
		r2 -= sfmpy(r0,r5):lib
	}
	{
		call nearbyintf
		r0 += sfmpy(r2,r3,p0):scale
	}
	.falign
// %bb.30:                              // %if.end43.i196
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r2 = convert_sf2w(r0):chop
		v20 = vmem(r29+#5)
		memw(r21+r27<<#2) = r18
	}                                       // 128-byte Folded Reload
	{
		r2 = satub(r2)
		memw(r19+r27<<#2) = r2.new
	}
	.falign
.LBB10_31:                              // %quant_row_params_one.exit213
                                        //   in Loop: Header=BB10_6 Depth=2
	{
		r26 = add(r26,#4)
		r27 = add(r27,#1)
		if (!cmp.eq(r27.new,#4)) jump:t ##.LBB10_6
	}
// %bb.32:                              // %for.cond.cleanup33
                                        //   in Loop: Header=BB10_5 Depth=1
	{
		r5 = asl(r23,#2)
		r1 = add(r25,#-32767)
		r2 = memw(r16+#20)
		memw(r29+#88) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = setbit(r5,#2)
		r3 = or(r5,#12)
		r6 = memw(r21+#0)
		memw(r29+#96) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = setbit(r5,#3)
		r7 = r1
		r13 = memw(r20+r2<<#0)
		r15 = memw(r20+r3<<#0)
	}
	{
		r0,p3 = sfrecipa(r1,r6)
		r10 = sffixupd(r1,r6)
		r14 = memw(r20+r2<<#0)
		memw(r29+#100) = r2
	}                                       // 4-byte Folded Spill
	{
		r28,p2 = sfrecipa(r1,r13)
		r3 = sffixupd(r1,r13)
		r8 = r1
		memw(r29+#104) = r3
	}                                       // 4-byte Folded Spill
	{
		r9,p1 = sfrecipa(r1,r14)
		r5 = sffixupd(r1,r14)
		r23 = r1
		r4 = r1
	}
	{
		r7 -= sfmpy(r10,r0):lib
		r8 -= sfmpy(r3,r28):lib
		memw(r29+#92) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		r18 = ##-2147483648
		memw(r29+#84) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r12,p1 = sfrecipa(r1,r15)
		r2 = sffixupd(r1,r15)
		r21 = r1
	}
	{
		r11 = sffixupn(r1,r6)
		r23 -= sfmpy(r5,r9):lib
	}
	{
		r20 = sffixupn(r1,r13)
		r4 -= sfmpy(r2,r12):lib
		r6 = and(r11,r18)
	}
	{
		r25 = sffixupn(r1,r15)
		r14 = sffixupn(r1,r14)
		r13 = and(r20,r18)
		r27:26 = combine(r11,r1)
	}
	{
		r0 += sfmpy(r7,r0):lib
		r28 += sfmpy(r8,r28):lib
		r15 = r25
	}
	{
		r9 += sfmpy(r23,r9):lib
		r12 += sfmpy(r4,r12):lib
		r8 = and(r14,r18)
		r7 = and(r25,r18)
	}
	{
		r6 += sfmpy(r11,r0):lib
		r13 += sfmpy(r20,r28):lib
		r4 = r20
		r18 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r18 -= sfmpy(r10,r0):lib
		r8 += sfmpy(r14,r9):lib
		r23 = r14
	}
	{
		r21 -= sfmpy(r3,r28):lib
		r26 -= sfmpy(r5,r9):lib
	}
	{
		r7 += sfmpy(r25,r12):lib
		r1 -= sfmpy(r2,r12):lib
	}
	{
		r0 += sfmpy(r18,r0):lib
		r27 -= sfmpy(r10,r6):lib
	}
	{
		r28 += sfmpy(r21,r28):lib
		r4 -= sfmpy(r3,r13):lib
	}
	{
		r9 += sfmpy(r26,r9):lib
		r12 += sfmpy(r1,r12):lib
	}
	{
		r23 -= sfmpy(r5,r8):lib
		r15 -= sfmpy(r2,r7):lib
	}
	{
		r6 += sfmpy(r27,r0):lib
		r13 += sfmpy(r4,r28):lib
		r27:26 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r8 += sfmpy(r23,r9):lib
	}
	{
		r7 += sfmpy(r15,r12):lib
		r11 -= sfmpy(r6,r10):lib
		r15 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		r20 -= sfmpy(r13,r3):lib
		r14 -= sfmpy(r8,r5):lib
		p0 = cmp.gtu(r15,#31)
		if (p0.new) r3 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r25 -= sfmpy(r7,r2):lib
		r6 += sfmpy(r11,r0,p3):scale
		if (p0) r5 = memw(r19+#0)
		r2 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r13 += sfmpy(r20,r28,p2):scale
		if (p0) r4 = memw(r29+#100)
		if (p0) r11 = memw(r16+#32)
	}                                       // 4-byte Folded Reload
	{
		r8 += sfmpy(r14,r9,p3):scale
		r7 += sfmpy(r25,r12,p1):scale
		if (!p0) jump:nt .LBB10_35
	}
// %bb.33:                              // %for.body.lr.ph.i149
                                        //   in Loop: Header=BB10_5 Depth=1
	{
		v2 = vsplat(r6)
		v3 = vsplat(r13)
	}
	{
		v14 = vsplat(r5)
		v8 = vsplat(r8)
	}
	{
		r2 = asl(r26,#7)
		v12 = vsplat(r7)
		r3 = r22
		r6 = memw(r17+r3<<#0)
	}
	{
		r9 = lsr(r15,#5)
		v16 = vsplat(r6)
		r12 = memw(r17+r4<<#0)
		r4 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r15,#12)
		v17 = vsplat(r12)
		r14 = and(r2,##-2048)
	}
	{
		r4 = extractu(r2,#11,#0)
		r14 = mpyi(r14,r9)
		r6 = memw(r29+#108)
		r10 = memw(r17+r4<<#0)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r22,r15,#3)
		v18 = vsplat(r10)
	}
	{
		r2 = addasl(r22,r15,#2)
		r4 += add(r11,r14)
	}
	{
		loop0(.LBB10_34,r9)
	}
	.falign
.LBB10_34:                              // Block address taken
                                        // %for.body.i152
                                        //   Parent Loop BB10_5 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v26 = vmemu(r6++#1)
	}
	{
		v27 = vmemu(r2++#1)
	}
	{
		v1.qf32 = vmpy(v26.sf,v2.sf)
		v28 = vmemu(r5++#1)
	}
	{
		v5.qf32 = vmpy(v27.sf,v3.sf)
		v4 = vmemu(r3++#1)
	}
	{
		v6.qf32 = vmpy(v28.sf,v8.sf)
		v11.qf32 = vadd(v1.qf32,v20.sf)
		v21 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		v7.qf32 = vmpy(v4.sf,v12.sf)
		v13.qf32 = vadd(v5.qf32,v20.sf)
	}
	{
		v15.qf32 = vadd(v6.qf32,v20.sf)
		v30.sf = v11.qf32
	}
	{
		v29.qf32 = vadd(v7.qf32,v20.sf)
		v31.sf = v13.qf32
		v10.w = vsub(v30.w,v20.w)
	}
	{
		v0.sf = v15.qf32
		v19.w = vsub(v31.w,v20.w)
		v22.w = vadd(v10.w,v14.w)
	}
	{
		v9.sf = v29.qf32
		v20.w = vsub(v0.w,v20.w)
		v23.w = vadd(v19.w,v16.w)
	}
	{
		v21.w = vsub(v9.w,v21.w)
		v24.w = vadd(v20.w,v17.w)
		v20 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		v6.h = vpack(v23.w,v22.w):sat
		v25.w = vadd(v21.w,v18.w)
	}
	{
		v7.h = vpack(v25.w,v24.w):sat
	}
	{
		v27.ub = vpack(v7.h,v6.h):sat
	}
	{
		r4 = add(r4,#2048)
		vmemu(r4+#0) = v27
	} :endloop0
	.falign
.LBB10_35:                              // %cleanup
                                        //   in Loop: Header=BB10_5 Depth=1
	{
		r25 = ##1065385983
		r1:0 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r26 = add(r26,#1)
		if (cmp.gtu(r0,r26.new)) jump:t ##.LBB10_5
	}
	{
		jump .LBB10_63
	}
	.falign
.LBB10_36:                              // %cond.end.thread
	{
		r18 = #0
		r24 = #-32
		p0 = cmp.gtu(r0,r26)
		if (!p0.new) jump:t .LBB10_63
	}
// %bb.37:                              // %for.body.lr.ph.thread
	{
		r2 = ##1262485504
		r20 = ##1132396544
	}
	{
		v26 = vsplat(r2)
		r19 = add(r25,#-32767)
		vmem(r29+#5) = v26.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB10_38:                              // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB10_39 Depth 2
                                        //       Child Loop BB10_44 Depth 3
                                        //       Child Loop BB10_50 Depth 3
                                        //     Child Loop BB10_61 Depth 2
	{
		r26 = asl(r26,#2)
		r0 = r26
		r17 = memw(r16+#24)
		r25 = memw(r16+#0)
	}
	{
		r21 = #0
		r27 = memw(r16+#28)
		memd(r29+#112) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB10_39:                              // %for.body21.us
                                        //   Parent Loop BB10_38 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB10_44 Depth 3
                                        //       Child Loop BB10_50 Depth 3
	{
		r22 = or(r21,r26)
		r3 = memw(r16+#20)
	}
	{
		p2 = cmp.gtu(r3,#31)
	}
	{
		r4 = mpyi(r3,r22)
	}
	{
		r2 = addasl(r25,r4,#2)
		if (p2) jump:nt .LBB10_41
		if (!p2) r5 = memw(r25+r4<<#2)
	}
// %bb.40:                              //   in Loop: Header=BB10_39 Depth=2
	{
		p2 = bitsset(r24,r3)
		r4 = r5
		if (p2.new) jump:t .LBB10_52
	}
	{
		jump .LBB10_49
	}
	.falign
.LBB10_41:                              // %if.then.i.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		p0 = cmp.gtu(r3,#63)
		if (!p0.new) jump:t .LBB10_47
		v10 = vmemu(r2+#0)
	}
// %bb.42:                              // %for.body.i148.us.preheader
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r5 = lsr(r3,#5)
		r4 = #1
		v20 = v10
	}
	{
		r5 = add(r5,#-1)
	}
	{
		r6 = lsr(r5,#1)
		r5 = and(r5,#1)
	}
	{
		if (p1.new) r8 = add(r6,#-1)
		if (p1.new) r7 = add(r4,#1)
		p1 = cmp.gtu(r6,#0); if (!p1.new) jump:t .LBB10_56
	}
// %bb.43:                              //   in Loop: Header=BB10_39 Depth=2
	{
		r6 = addasl(r2,r4,#7)
		p1 = cmp.gtu(r6,#1)
	}
	{
		loop0(.LBB10_44,r8)
		r7 = addasl(r2,r7,#7)
		r4 = add(r4,#2)
		v21 = v10
	}
	{
		if (!p1) jump:nt .LBB10_45
	}
	.balign 32
.LBB10_44:                              //   Parent Loop BB10_38 Depth=1
                                        //     Parent Loop BB10_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r6 = addasl(r2,r4,#7)
		r8 = add(r4,#1)
		v1 = vmemu(r6+#0)
	}
	{
		v4.sf = vmin(v10.sf,v1.sf)
		v5.sf = vmax(v21.sf,v1.sf)
		v6 = vmemu(r7+#0)
	}
	{
		r7 = addasl(r2,r8,#7)
		r4 = add(r4,#2)
		v10.sf = vmin(v4.sf,v6.sf)
		v21.sf = vmax(v5.sf,v6.sf)
	} :endloop0
	.falign
.LBB10_45:                              //   in Loop: Header=BB10_39 Depth=2
	{
		p3 = cmp.gtu(r5,#0)
		v7 = vmemu(r6+#0)
	}
	{
		v11.sf = vmin(v10.sf,v7.sf)
		v13.sf = vmax(v21.sf,v7.sf)
		v15 = vmemu(r7+#0)
	}
	{
		if (p3) jump:nt .LBB10_57
		v20.sf = vmax(v13.sf,v15.sf)
		v10.sf = vmin(v11.sf,v15.sf)
	}
	.falign
.LBB10_46:                              //   in Loop: Header=BB10_39 Depth=2
	{
		jump .LBB10_48
		v24 = v10
		v10 = v20
	}
	.falign
.LBB10_47:                              //   in Loop: Header=BB10_39 Depth=2
	{
		v24 = v10
	}
	.falign
.LBB10_48:                              // %for.body10.i.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		p2 = bitsset(r24,r3)
		r4 = #64
	}
	{
		v30 = vror(v24,r4)
	}
	{
		r4 = #32
		v0 = vror(v10,r4)
		v31.sf = vmin(v24.sf,v30.sf)
	}
	{
		v2.sf = vmax(v10.sf,v0.sf)
	}
	{
		v3 = vror(v31,r4)
	}
	{
		r4 = #16
		v9 = vror(v2,r4)
		v8.sf = vmin(v31.sf,v3.sf)
	}
	{
		v10.sf = vmax(v2.sf,v9.sf)
	}
	{
		v12 = vror(v8,r4)
	}
	{
		r4 = #8
		v16 = vror(v10,r4)
		v14.sf = vmin(v8.sf,v12.sf)
	}
	{
		v17.sf = vmax(v10.sf,v16.sf)
	}
	{
		v18 = vror(v14,r4)
	}
	{
		v19 = vror(v17,r4)
		v20.sf = vmin(v14.sf,v18.sf)
	}
	{
		v21.sf = vmax(v17.sf,v19.sf)
	}
	{
		v22 = valign(v20,v20,#4)
	}
	{
		v23 = valign(v21,v21,#4)
		v24.sf = vmin(v20.sf,v22.sf)
		vmem(r29+#4) = v24.new
	}
	{
		v25.sf = vmax(v21.sf,v23.sf)
		r4 = memw(r29+#512)
		vmem(r29+#3) = v25.new
	}
	{
		if (p2) jump:nt .LBB10_52
		r5 = memw(r29+#384)
	}
	.falign
.LBB10_49:                              //   in Loop: Header=BB10_39 Depth=2
	{
		r6 = and(r3,#-32)
	}
	{
		r3 = sub(r3,r6)
	}
	{
		r7 = add(r3,#-1)
		p0 = cmp.gtu(r3,#1)
		r6 = add(r6,#1)
		r3 = memw(r2+r6<<#2)
	}
	{
		loop0(.LBB10_50,r7)
		if (!p0) jump:nt .LBB10_51
	}
	.balign 32
.LBB10_50:                              // %for.body21.i.us
                                        //   Parent Loop BB10_38 Depth=1
                                        //     Parent Loop BB10_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r4 = sfmin(r3,r4)
		r5 = sfmax(r3,r5)
		r6 = add(r6,#1)
		r3 = memw(r2+r6<<#2)
	} :endloop0
	.falign
.LBB10_51:                              //   in Loop: Header=BB10_39 Depth=2
	{
		r4 = sfmin(r3,r4)
		r5 = sfmax(r3,r5)
	}
	.falign
.LBB10_52:                              // %for.cond.cleanup20.i.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r2 = sfmin(r4,r18)
		r3 = sfmax(r5,r18)
	}
	{
		p1 = sfcmp.uo(r2,r3)
		p3 = sfcmp.eq(r2,r3)
		r5:4 = combine(r19,r19)
	}
	{
		r3 = sfsub(r3,r2)
		p2 = and(p3,!p1)
		if (!p2.new) jump:nt .LBB10_54
	}
// %bb.53:                              // %quant_row_params_one.exit.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r21 = add(r21,#1)
		if (!cmp.eq(r21.new,#4)) jump:t .LBB10_39
	}
	{
		jump .LBB10_58
	}
	.falign
.LBB10_54:                              // %if.end43.i.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r2 = togglebit(r2,#31)
		r6 = sffixupn(r3,r20)
	}
	{
		r7,p3 = sfrecipa(r3,r20)
	}
	{
		r3 = sffixupd(r3,r20)
		r9:8 = combine(r6,r6)
	}
	{
		r8 = insert(r18,#31,#0)
		r4 -= sfmpy(r3,r7):lib
	}
	{
		r7 += sfmpy(r4,r7):lib
		r23 = r8
	}
	{
		r23 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r3,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r9 -= sfmpy(r3,r23):lib
		r5 = r19
	}
	{
		r23 += sfmpy(r9,r7):lib
	}
	{
		r6 -= sfmpy(r23,r3):lib
	}
	{
		r23 += sfmpy(r6,r7,p3):scale
		r6 = r19
	}
	{
		r3,p2 = sfrecipa(r2,r23)
		r4 = sffixupd(r2,r23)
	}
	{
		r2 = sffixupn(r2,r23)
		r6 -= sfmpy(r4,r3):lib
	}
	{
		r0 = r2
	}
	{
		r0 = insert(r8,#31,#0)
		r3 += sfmpy(r6,r3):lib
		r6 = r2
	}
	{
		r0 += sfmpy(r2,r3):lib
		r5 -= sfmpy(r4,r3):lib
	}
	{
		r6 -= sfmpy(r4,r0):lib
		r3 += sfmpy(r5,r3):lib
	}
	{
		r0 += sfmpy(r6,r3):lib
	}
	{
		r2 -= sfmpy(r0,r4):lib
	}
	{
		call nearbyintf
		r0 += sfmpy(r2,r3,p2):scale
	}
	.falign
// %bb.55:                              // %if.end43.i.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r2 = convert_sf2w(r0):chop
		v26 = vmem(r29+#5)
		memw(r17+r22<<#2) = r23
	}                                       // 128-byte Folded Reload
	{
		r2 = satub(r2)
		memw(r27+r22<<#2) = r2.new
	}
	{
		r21 = add(r21,#1)
		if (!cmp.eq(r21.new,#4)) jump:t .LBB10_39
	}
	{
		jump .LBB10_58
	}
	.falign
.LBB10_56:                              //   in Loop: Header=BB10_39 Depth=2
	{
		p3 = cmp.gtu(r5,#0)
		if (!p3.new) jump:t .LBB10_46
	}
	.falign
.LBB10_57:                              // Block address taken
                                        // %for.body.i148.us
                                        //   in Loop: Header=BB10_39 Depth=2
	{
		r5 = addasl(r2,r4,#7)
	}
	{
		v29 = vmemu(r5+#0)
	}
	{
		jump .LBB10_46
		v10.sf = vmin(v10.sf,v29.sf)
		v20.sf = vmax(v20.sf,v29.sf)
	}
	.falign
.LBB10_58:                              // %for.cond.cleanup20.us
                                        //   in Loop: Header=BB10_38 Depth=1
	{
		r3 = setbit(r26,#0)
		p1 = cmp.eq(r26,#-4)
		if (p1.new) jump:t .LBB10_62
		v1 = v26
	}
// %bb.59:                              // %for.body.lr.ph.i.us
                                        //   in Loop: Header=BB10_38 Depth=1
	{
		r4 = setbit(r26,#1)
		r5 = or(r26,#3)
		r2 = memw(r16+#20)
		r6 = memw(r17+r26<<#2)
	}
	{
		p2 = cmp.gtu(r2,#31)
		r21 = r19
		r11 = memw(r17+r5<<#2)
		memw(r29+#96) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		r23 = sffixupn(r19,r6)
		r9 = r19
		memw(r29+#768) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r5,p2 = sfrecipa(r19,r6)
		r2 = sffixupd(r19,r6)
		r8 = memw(r17+r3<<#2)
		memw(r29+#108) = r5
	}                                       // 4-byte Folded Spill
	{
		r6 = sffixupd(r19,r11)
		r1 = ##-2147483648
		memw(r29+#88) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r12,p1 = sfrecipa(r19,r8)
		r7:6 = combine(r19,r23)
		r15 = and(r23,r1)
		r0 = memw(r17+r4<<#2)
	}
	{
		r7 -= sfmpy(r2,r5):lib
		r24 = sffixupd(r19,r8)
		memw(r29+#104) = r4
		memw(r29+#100) = r3
	}                                       // 4-byte Folded Spill
	{
		r4 = sffixupd(r19,r0)
		r13,p0 = sfrecipa(r19,r0)
	}
	{
		r5 += sfmpy(r7,r5):lib
		r14 = sffixupn(r19,r8)
		r3 = r19
		memw(r29+#92) = r4
	}                                       // 4-byte Folded Spill
	{
		r9 -= sfmpy(r24,r12):lib
		r10 = sffixupn(r19,r11)
		memw(r29+#84) = r19
		memw(r29+#80) = r19
	}                                       // 4-byte Folded Spill
	{
		r3 -= sfmpy(r4,r13):lib
		r4 = sffixupn(r19,r0)
		r22 = r19
		r17 = r19
	}
	{
		r15 += sfmpy(r23,r5):lib
		r21 -= sfmpy(r2,r5):lib
		r7 = and(r14,r1)
		r28 = r14
	}
	{
		r8 = and(r4,r1)
		r0 = r4
	}
	{
		r5 += sfmpy(r21,r5):lib
		r6 -= sfmpy(r2,r15):lib
	}
	{
		r12 += sfmpy(r9,r12):lib
		r21,p3 = sfrecipa(r19,r11)
		r9 = and(r10,r1)
		r1 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r15 += sfmpy(r6,r5):lib
		r13 += sfmpy(r3,r13):lib
		r3 = r10
		r6 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		r7 += sfmpy(r14,r12):lib
		r22 -= sfmpy(r24,r12):lib
	}
	{
		r23 -= sfmpy(r15,r2):lib
		r8 += sfmpy(r4,r13):lib
		r2 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 -= sfmpy(r6,r21):lib
		r17 -= sfmpy(r1,r13):lib
	}
	{
		r12 += sfmpy(r22,r12):lib
		r28 -= sfmpy(r24,r7):lib
	}
	{
		r21 += sfmpy(r2,r21):lib
		r13 += sfmpy(r17,r13):lib
		r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r0 -= sfmpy(r1,r8):lib
		r7 += sfmpy(r28,r12):lib
	}
	{
		r9 += sfmpy(r10,r21):lib
		r2 -= sfmpy(r6,r21):lib
	}
	{
		r8 += sfmpy(r0,r13):lib
		r14 -= sfmpy(r7,r24):lib
		r24 = #-32
	}
	{
		r21 += sfmpy(r2,r21):lib
		r3 -= sfmpy(r6,r9):lib
		r2 = memw(r29+#768)
	}                                       // 4-byte Folded Reload
	{
		r4 -= sfmpy(r8,r1):lib
		r15 += sfmpy(r23,r5,p2):scale
	}
	{
		r9 += sfmpy(r3,r21):lib
		r7 += sfmpy(r14,r12,p1):scale
	}
	{
		r8 += sfmpy(r4,r13,p0):scale
		p0 = r2
		if (p0.new) r1:0 = memd(r29+#112)
		if (p0.new) r28 = memw(r29+#108)
	}                                       // 8-byte Folded Reload
	{
		r10 -= sfmpy(r9,r6):lib
		if (p0) r12 = add(r0,#0)
		if (p0) r3 = memw(r27+r26<<#2)
	}
	{
		r9 += sfmpy(r10,r21,p3):scale
		if (!p0) jump:nt .LBB10_62
		if (p0) r10 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
// %bb.60:                              // %for.body.lr.ph.i.i.us
                                        //   in Loop: Header=BB10_38 Depth=1
	{
		v4 = vsplat(r15)
		v5 = vsplat(r7)
	}
	{
		r6 = lsr(r10,#5)
		r2 = lsr(r26,#6)
		r0 = memw(r29+#104)
		r1 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		v6 = vsplat(r8)
		v7 = vsplat(r9)
	}
	{
		r3 = extractu(r6,#21,#0)
		v22 = vsplat(r3)
		r4 = memw(r27+r1<<#2)
		vmem(r29+#6) = v22.new
	}                                       // 128-byte Folded Spill
	{
		r0 = mpyi(r0,r10)
		v11 = vsplat(r4)
		r5 = memw(r27+r0<<#2)
		r14 = memw(r27+r28<<#2)
	}
	{
		v13 = vsplat(r5)
		v15 = vsplat(r14)
		r13 = memw(r16+#32)
	}
	{
		r2 = mpyi(r3,r2)
		r1 = mpyi(r1,r10)
	}
	{
		r28 = mpyi(r28,r10)
		r11 = asl(r2,#11)
	}
	{
		r10 = mpyi(r26,r10)
		r2 = addasl(r25,r28,#2)
	}
	{
		r12 = and(##1920,asl(r12,#7))
	}
	{
		r3 = addasl(r25,r0,#2)
		r4 = addasl(r25,r1,#2)
	}
	{
		r5 = addasl(r25,r10,#2)
		r12 += add(r13,r11)
	}
	{
		loop0(.LBB10_61,r6)
	}
	.falign
.LBB10_61:                              // Block address taken
                                        // %for.body.i.i.us
                                        //   Parent Loop BB10_38 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v26 = vmemu(r5++#1)
	}
	{
		v27 = vmemu(r4++#1)
	}
	{
		v29.qf32 = vmpy(v26.sf,v4.sf)
		v28 = vmemu(r3++#1)
	}
	{
		v31.qf32 = vmpy(v27.sf,v5.sf)
		v30 = vmemu(r2++#1)
	}
	{
		v0.qf32 = vmpy(v28.sf,v6.sf)
		v3.qf32 = vadd(v29.qf32,v1.sf)
		v23 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		v2.qf32 = vmpy(v30.sf,v7.sf)
		v8.qf32 = vadd(v31.qf32,v1.sf)
	}
	{
		v9.qf32 = vadd(v0.qf32,v1.sf)
		v12.sf = v3.qf32
	}
	{
		v10.qf32 = vadd(v2.qf32,v1.sf)
		v14.sf = v8.qf32
		v18.w = vsub(v12.w,v1.w)
	}
	{
		v16.sf = v9.qf32
		v19.w = vsub(v14.w,v1.w)
		v22.w = vadd(v18.w,v23.w)
	}
	{
		v17.sf = v10.qf32
		v20.w = vsub(v16.w,v1.w)
		v19.w = vadd(v19.w,v11.w)
	}
	{
		v21.w = vsub(v17.w,v1.w)
		v24.w = vadd(v20.w,v13.w)
	}
	{
		v22.h = vpack(v19.w,v22.w):sat
		v25.w = vadd(v21.w,v15.w)
	}
	{
		v23.h = vpack(v25.w,v24.w):sat
	}
	{
		v27.ub = vpack(v23.h,v22.h):sat
	}
	{
		r12 = add(r12,#2048)
		vmemu(r12+#0) = v27
	} :endloop0
	.falign
.LBB10_62:                              // %cleanup.us
                                        //   in Loop: Header=BB10_38 Depth=1
	{
		v26 = v1
		r27:26 = memd(r29+#112)
		r1:0 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r26 = add(r26,#1)
		if (cmp.gtu(r0,r26.new)) jump:t ##.LBB10_38
	}
	.falign
.LBB10_63:                              // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end10:
	.size	quant_params_pack_worker, .Lfunc_end10-quant_params_pack_worker
                                        // -- End function
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym quant_rows_worker
	.addrsig_sym quant_pack_worker
	.addrsig_sym quant_params_pack_worker
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#quant_rows_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#quant_pack_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#quant_params_pack_worker#(void)#(i32, i32, ptr)#1##"

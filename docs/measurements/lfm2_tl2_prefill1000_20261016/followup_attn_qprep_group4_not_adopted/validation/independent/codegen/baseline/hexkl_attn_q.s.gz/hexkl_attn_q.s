	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hexkl_attn_q.c"
	.section	.rodata,"a",@progbits
	.p2align	7, 0x0                          // -- Begin function hexkl_attn_q_prefill
.LCPI0_0:
	.word	0                               // 0x0
	.word	65537                           // 0x10001
	.word	131074                          // 0x20002
	.word	196611                          // 0x30003
	.word	262148                          // 0x40004
	.word	327685                          // 0x50005
	.word	393222                          // 0x60006
	.word	458759                          // 0x70007
	.word	524296                          // 0x80008
	.word	589833                          // 0x90009
	.word	655370                          // 0xa000a
	.word	720907                          // 0xb000b
	.word	786444                          // 0xc000c
	.word	851981                          // 0xd000d
	.word	917518                          // 0xe000e
	.word	983055                          // 0xf000f
	.word	1048592                         // 0x100010
	.word	1114129                         // 0x110011
	.word	1179666                         // 0x120012
	.word	1245203                         // 0x130013
	.word	1310740                         // 0x140014
	.word	1376277                         // 0x150015
	.word	1441814                         // 0x160016
	.word	1507351                         // 0x170017
	.word	1572888                         // 0x180018
	.word	1638425                         // 0x190019
	.word	1703962                         // 0x1a001a
	.word	1769499                         // 0x1b001b
	.word	1835036                         // 0x1c001c
	.word	1900573                         // 0x1d001d
	.word	1966110                         // 0x1e001e
	.word	2031647                         // 0x1f001f
	.text
	.globl	hexkl_attn_q_prefill
	.falign
	.type	hexkl_attn_q_prefill,@function
hexkl_attn_q_prefill:                   // @hexkl_attn_q_prefill
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		allocframe(r29,#1536):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r27 = ##-2147482622
		memd(r30+#-48) = r27:26
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r21 = add(r27,#12)
		memd(r30+#-8) = r17:16
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB0_29
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB0_29
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB0_29
	}
// %bb.3:                               // %entry
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB0_29
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r6 = memw(r4+#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB0_29
	}
// %bb.5:                               // %lor.lhs.false8
	{
		r6 = memw(r4+#12)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB0_29
	}
// %bb.6:                               // %lor.lhs.false10
	{
		r16 = memw(r4+#20)
		if (cmp.eq(r16.new,#0)) jump:nt .LBB0_29
	}
// %bb.7:                               // %if.end
	{
		r6 = memw(r16+#20)
	}
	{
		r7 = memw(r2+#16)
		if (!cmp.eq(r7.new,r6)) jump:t .LBB0_29
	}
// %bb.8:                               // %lor.lhs.false15
	{
		r17 = memw(r16+#24)
	}
	{
		r6 = memw(r2+#20)
		if (!cmp.eq(r6.new,r17)) jump:t .LBB0_29
	}
// %bb.9:                               // %lor.lhs.false18
	{
		r7 = memw(r16+#16)
	}
	{
		r6 = memw(r2+#8)
		if (cmp.gtu(r6.new,r7)) jump:nt .LBB0_29
	}
// %bb.10:                              // %lor.lhs.false18
	{
		p0 = cmp.gtu(r6,##65535)
		if (!p0.new) r6 = #512
		if (p0.new) jump:nt .LBB0_29
	}
// %bb.11:                              // %lor.lhs.false24
	{
		r19:18 = combine(r0,r5)
		r20 = add(r29,#368)
		r6 = memw(r3+#12)
		if (cmp.gtu(r6.new,r6)) jump:t .LBB0_29
	}
// %bb.12:                              // %lor.lhs.false26
	{
		r7 = #0
		r6 = memw(r2+#28)
	}
	{
		p0 = sfcmp.uo(r7,r6)
		p1 = sfcmp.gt(r7,r6)
	}
	{
		p0 = and(p1,!p0)
		if (!p0.new) r26 = add(r4,#0)
		if (!p0.new) r25:24 = combine(r2,r1)
		if (p0.new) jump:t .LBB0_29
	}
// %bb.13:                              // %if.end29
	{
		r6 = memw(r3+#12)
		memw(r29+#380) = r6.new
	}
	{
		r0 = memw(r3+#8)
		memw(r29+#376) = r0.new
	}
	{
		r1:0 = combine(r3,r2)
		r22 = r3
		r2 = memw(r16+#12)
		r5 = memw(r3+#4)
	}
	{
		r3:2 = combine(r2,r24)
		r4 = r20
		r5 = memw(r22+#0)
		memw(r29+#372) = r5
	}
	{
		call hexkl_attn_q_widen_prefill
		memw(r29+#368) = r5
	}
	.falign
// %bb.14:                              // %if.end29
	{
		p1 = cmp.eq(r0,#0)
		r0 = add(r29,#640)
		r1 = #0
		r2 = #768
	}
	{
		r3 = p1
		r23 = mux(p1,r22,r20)
		memw(r29+#384) = r22
	}                                       // 4-byte Folded Spill
	{
		call memset
		memw(r29+#236) = r3
	}                                       // 4-byte Folded Spill
	.falign
// %bb.15:                              // %if.end29
	{
		r22 = r19
		r19 = memw(r23+#0)
		memw(r29+#640) = r19
	}
	{
		r1 = r19
		r2 = memw(r25+#0)
		memw(r29+#644) = r24
	}
	{
		r0 = add(r2,add(r19,#-1))
		memw(r29+#656) = r26
		memw(r29+#664) = r18
	}
	{
		memw(r29+#392) = r0
		memw(r29+#648) = r25
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#652) = r23
		memw(r29+#660) = r16
	}
	.falign
// %bb.16:                              // %if.end29
	{
		r0 = ##1572864
		r18 = r0
		r2 = memw(r23+#12)
	}
	{
		r3 = mpyi(r17,r2)
		r17 = and(##-2048,asl(r17,#6))
	}
	{
		r2 = lsr(r2,#6)
	}
	{
		r2 = mpyi(r17,r2)
	}
	{
		r17 = addasl(r2,r3,#2)
	}
	{
		call __hexagon_udivsi3
		r1 = r17
	}
	.falign
// %bb.17:                              // %if.end29
	{
		p1 = cmp.gtu(r17,##1572864)
		r26 = add(r29,#668)
		r3 = memw(r16+#12)
	}
	{
		r2 = r24
		if (p1) r0 = #1
		memw(r29+#240) = r25
	}                                       // 4-byte Folded Spill
	{
		r17 = minu(r0,r18)
		r1:0 = combine(r23,r25)
	}
	{
		call hexkl_attn_q_plan
		r5:4 = combine(r26,r17)
	}
	.falign
// %bb.18:                              // %if.end29
	{
		p0 = cmp.eq(r0,#-2)
		if (p0.new) r2 = add(r24,#0)
		if (p0.new) r1 = add(r23,#0)
		if (!p0.new) jump:nt .LBB0_23
	}
// %bb.19:                              // %if.end29
	{
		p1 = cmp.gtu(r17,#1); if (!p1.new) jump:nt .LBB0_23
		if (p1.new) r0 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.20:                              // %if.then59
	{
		r5:4 = combine(r26,#1)
		r17 = #1
		r3 = memw(r16+#12)
	}
	{
		call hexkl_attn_q_plan
	}
	.falign
// %bb.21:                              // %if.then59
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB0_25
	}
// %bb.22:
	{
		p1 = cmp.eq(r0,#-2)
		if (p1.new) r21 = add(r27,#0)
		if (!p1.new) r21 = add(r27,#12)
		jump .LBB0_29
	}
	.falign
.LBB0_23:                               // %if.end64
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB0_25
	}
// %bb.24:
	{
		if (p0) r21 = add(r27,#0)
		if (!p0) r21 = add(r27,#12)
		jump .LBB0_29
	}
	.falign
.LBB0_25:                               // %if.end67
	{
		r23 = add(r29,#640)
		r21 = add(r27,#12)
		r3 = memw(r29+#672)
		r4 = memw(r29+#668)
	}
	{
		r5 = add(r29,#680)
		r2 = r22
		r3 = add(r22,r3)
		r4 = add(r22,r4)
	}
	{
		r3 = and(r3,#127)
	}
	{
		r4 = or(r3,and(r4,##2047))
		if (!cmp.eq(r4.new,#0)) jump:t .LBB0_29
	}
// %bb.26:                              // %lor.lhs.false73
	{
		r3 = memw(r29+#680)
		r4 = memw(r29+#700)
	}
	{
		r3 = add(r22,r3)
		r4 = add(r22,r4)
	}
	{
		r3 = and(r3,#127)
	}
	{
		r4 = or(r3,and(r4,##2047))
		if (!cmp.eq(r4.new,#0)) jump:t .LBB0_29
	}
// %bb.27:                              // %lor.lhs.false81
	{
		r3 = #127
		r4 = memw(r29+#676)
	}
	{
		r4 = add(r2,r4)
	}
	{
		p0 = !bitsclr(r4,r3)
		if (p0.new) jump:t .LBB0_29
		if (!p0.new) r4 = memw(r29+##684)
	}
// %bb.28:                              // %lor.lhs.false91
	{
		memw(r29+#304) = r5
		memw(r29+#328) = r17
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r2,r4)
		memw(r29+#332) = r18
	}                                       // 4-byte Folded Spill
	{
		p1 = !bitsclr(r2,r3)
		if (!p1.new) jump:nt .LBB0_30
		if (!p1.new) r1 = memw(r29+##688)
	}
	.falign
.LBB0_29:                               // %return
	{
		r0 = r21
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB0_30:                               // %if.end102
	{
		call hexkl_acc_layout_get
		r0 = r22
	}
	.falign
// %bb.31:                              // %if.end102
	{
		r21 = add(r27,#18)
		memw(r29+#736) = r0
	}
	{
		r2 = memw(r0+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB0_29
	}
// %bb.32:                              // %lor.lhs.false107
	{
		r2 = memub(r0+#12)
	}
	{
		p1 = !bitsclr(r2,#31)
		if (p1.new) jump:t .LBB0_29
		if (!p1.new) r2 = memub(r0+#8)
	}
// %bb.33:                              // %lor.lhs.false110
	{
		p0 = !bitsclr(r2,#31)
		if (p0.new) jump:t .LBB0_29
		if (!p0.new) r4 = memw(r29+#236)
		if (!p0.new) r2 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.34:                              // %if.end115
	{
		p2 = r4
		r3 = memw(r2+#20)
		r2 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r16 = add(r2,#12)
	}
	{
		call sqrtf
		r0 = convert_uw2sf(r3)
		if (!p2) r16 = add(r20,#12)
	}
	.falign
// %bb.35:                              // %if.end115
	{
		r2 = ##1069099578
		r4 = ##1065385983
	}
	{
		r3 = #140
		r6 = add(r2,#-32767)
		r7 = add(r4,#-32767)
		r17 = memw(r16+#0)
	}
	{
		r2 = sffixupn(r6,r0)
		r4,p1 = sfrecipa(r6,r0)
		memw(r29+#336) = r6
		memw(r29+#340) = r7
	}                                       // 4-byte Folded Spill
	{
		r6 = sffixupd(r6,r0)
		r5 = r7
		r1 = r7
		r0 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r0,#3)
		r7 = and(r2,##-2147483648)
		r8 = r2
	}
	{
		r5 -= sfmpy(r6,r4):lib
	}
	{
		r0 = add(##128,mpyi(r17,r3))
	}
	{
		r4 += sfmpy(r5,r4):lib
	}
	{
		r7 += sfmpy(r2,r4):lib
		r1 -= sfmpy(r6,r4):lib
	}
	{
		r4 += sfmpy(r1,r4):lib
		r8 -= sfmpy(r6,r7):lib
	}
	{
		r7 += sfmpy(r8,r4):lib
	}
	{
		r2 -= sfmpy(r7,r6):lib
	}
	{
		call malloc
		r7 += sfmpy(r2,r4,p1):scale
		memw(r29+#740) = r7.new
	}
	.falign
// %bb.36:                              // %if.end115
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB0_48
		if (!p1.new) r2 = memw(r29+#240)
		memw(r29+#348) = r0
	}                                       // 4-byte Folded Reload
// %bb.37:                              // %if.end127
	{
		r7 = add(pc,##.LCPI0_0@PCREL)
		r21 = #0
		r8 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		r1 = +mpyi(r17,#12)
		r3 = r8
		r6 = memw(r29+#328)
		r16 = memw(r30+#8)
	}                                       // 4-byte Folded Reload
	{
		r4 = asl(r6,#3)
		r2 = memw(r2+#28)
		memw(r29+#744) = r8
	}
	{
		r3 += mpyi(r17,r4)
		p0 = sfcmp.uo(r2,r21)
	}
	{
		p1 = sfcmp.gt(r2,r21)
		r5 = r3
		v1 = vmem(r7+#0)
		memw(r29+#752) = r3
	}
	{
		r6 = mpyi(r6,r17)
		p0 = and(p1,!p0)
		vmem(r29+#7) = v1
	}
	{
		r0 = addasl(r3,r17,#2)
		r4 = add(r3,add(r1,##127))
		memw(r29+#756) = r0.new
	}
	{
		r3 = addasl(r3,r17,#3)
		r6 = addasl(r8,r6,#2)
		memw(r29+#760) = r3.new
	}
	{
		r5 += mpyi(r17,#10)
		r3 = and(r4,#-128)
		memw(r29+#748) = r6
	}
	{
		if (!p0) jump:nt .LBB0_41
		memw(r29+#764) = r5
		memw(r29+#768) = r3
	}
// %bb.38:                              // %if.then147
	{
		r3 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r17 = sfmpy(r2,r3)
	}
	{
		call __truncsfhf2
		r0 = r17
	}
	.falign
// %bb.39:                              // %if.then147
	{
		r2 = ##1077455419
		r3 = ##1065385983
	}
	{
		r4,p0 = sfrecipa(r2,r17)
		r5 = sffixupd(r2,r17)
		r3 = add(r3,#-32767)
	}
	{
		r7 = sffixupn(r2,r17)
		r6 = r3
	}
	{
		r6 -= sfmpy(r5,r4):lib
	}
	{
		r2 = r7
		r1 = r7
	}
	{
		r2 = insert(r21,#31,#0)
		r4 += sfmpy(r6,r4):lib
	}
	{
		r2 += sfmpy(r7,r4):lib
		r3 -= sfmpy(r5,r4):lib
	}
	{
		r4 += sfmpy(r3,r4):lib
		r1 -= sfmpy(r5,r2):lib
		r3 = zxth(r0)
	}
	{
		v2.h = vsplat(r3)
	}
	{
		r2 += sfmpy(r1,r4):lib
		r1 = add(r29,#2048)
	}
	{
		vmem(r1+#-8) = v2
	}
	{
		r7 -= sfmpy(r2,r5):lib
	}
	{
		r2 += sfmpy(r7,r4,p0):scale
	}
	{
		call __truncsfhf2
		r0 = r2
	}
	.falign
// %bb.40:                              // %if.then147
	{
		r2 = zxth(r0)
		r1 = add(r29,#2048)
		r0 = #1
		memw(r29+#1280) = r0.new
	}
	{
		v3.h = vsplat(r2)
		vmem(r1+#-7) = v3.new
	}
	.falign
.LBB0_41:                               // %if.end155
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.42:                              // %if.end155
	{
		r17 = add(r29,#416)
		r2 = #96
	}
	{
		call memset
		r1:0 = combine(#0,r17)
	}
	.falign
// %bb.43:                              // %if.end155
	{
		p0 = cmp.eq(r16,#0)
		r2 = #96
		if (!p0.new) r17 = add(r16,#0)
	}
	{
		call memset
		r1:0 = combine(#0,r17)
		memw(r29+#1312) = r17
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = ##-1431622999
		r3 = #10
	}
	{
		r5:4 = mpyu(r0,r3)
		r7 = add(r2,#-32766)
		r6 = add(r2,#-32767)
		memw(r29+#268) = r7.new
	}                                       // 4-byte Folded Spill
	{
		r5 += mpyi(r1,#10)
		memw(r29+#244) = r6
	}                                       // 4-byte Folded Spill
	{
		r3:2 = mpyu(r4,r7)
		r1:0 = mpyu(r4,r6)
	}
	{
		r20 = r3
	}
	{
		r3:2 = combine(r21,r20)
		r20 = r0
	}
	{
		r3:2 += mpyu(r5,r7)
	}
	{
		r3:2 = add(r3:2,r21:20)
	}
	{
		r20 = r3
	}
	{
		r3:2 = combine(r21,r20)
		r20 = r1
	}
	{
		r3:2 += mpyu(r5,r6)
	}
	{
		r1:0 = add(r3:2,r21:20)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	{
		memd(r29+#408) = r1:0
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c15:14
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#240)
		memd(r29+#400) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#16)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB0_46
	}
// %bb.44:                              // %for.cond166.preheader.lr.ph
	{
		r0 = #0
		r27 = #0
		r2 = memw(r29+#392)
		memw(r29+#288) = r0.new
	}                                       // 4-byte Folded Reload
	{
		if (p0.new) r21 = #0
		p0 = cmp.gtu(r19,r2); if (!p0.new) jump:t .LBB0_49
	}
	.falign
.LBB0_46:                               // %for.cond.cleanup
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = #10
		r9 = memw(r29+#268)
		r8 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = mpyu(r0,r2)
	}
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r9)
		r1:0 = mpyu(r2,r8)
		r2 = memw(r29+#1312)
	}
	{
		r5:4 = combine(#0,r7)
	}
	{
		r7:6 = combine(r5,r4)
		r4 = r0
	}
	{
		r7:6 += mpyu(r3,r9)
	}
	{
		r7:6 = add(r7:6,r5:4)
	}
	{
		r4 = r7
	}
	{
		r7:6 = combine(r5,r4)
		r4 = r1
	}
	{
		r7:6 += mpyu(r3,r8)
	}
	{
		r1:0 = add(r7:6,r5:4)
		r7:6 = memd(r29+#408)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = lsr(r1:0,#7)
	}
	{
		r1:0 = sub(r1:0,r7:6)
	}
	{
		memd(r2+#72) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c15:14
	}
	//# InlineAsm End
	{
		r5:4 = memd(r29+#400)
		r2 = memw(r29+#1312)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = sub(r1:0,r5:4)
		r0 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		call free
		memd(r2+#80) = r5:4
	}
	.falign
// %bb.47:                              // %for.cond.cleanup
	{
		jump .LBB0_29
	}
	.falign
.LBB0_48:
	{
		r21 = ##-2147482622
		jump .LBB0_29
	}
	.falign
.LBB0_49:
	{
		r2 = setbit(r23,#5)
		v25 = vxor(v25,v25)
		vmem(r29+#4) = v25.new
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#320) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_50:                               // %for.cond166.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB0_51 Depth 2
                                        //       Child Loop BB0_54 Depth 3
                                        //         Child Loop BB0_60 Depth 4
                                        //         Child Loop BB0_68 Depth 4
                                        //         Child Loop BB0_81 Depth 4
                                        //         Child Loop BB0_85 Depth 4
                                        //           Child Loop BB0_95 Depth 5
                                        //           Child Loop BB0_100 Depth 5
                                        //           Child Loop BB0_107 Depth 5
                                        //             Child Loop BB0_109 Depth 6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
                                        //         Child Loop BB0_143 Depth 4
                                        //           Child Loop BB0_148 Depth 5
	{
		memw(r29+#324) = r27
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_51:                               // %for.body174.us
                                        //   Parent Loop BB0_50 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB0_54 Depth 3
                                        //         Child Loop BB0_60 Depth 4
                                        //         Child Loop BB0_68 Depth 4
                                        //         Child Loop BB0_81 Depth 4
                                        //         Child Loop BB0_85 Depth 4
                                        //           Child Loop BB0_95 Depth 5
                                        //           Child Loop BB0_100 Depth 5
                                        //           Child Loop BB0_107 Depth 5
                                        //             Child Loop BB0_109 Depth 6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
                                        //         Child Loop BB0_143 Depth 4
                                        //           Child Loop BB0_148 Depth 5
	{
		r2 = memw(r29+#332)
		r8 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r8)
		r3 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		r24 = minu(r2,r3)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r20 = #10
		r19 = memw(r29+#268)
		r18 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = mpyu(r0,r20)
		r0 = add(r29,#640)
	}
	{
		r3 += mpyi(r1,#10)
		r1 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = mpyu(r2,r19)
		r5:4 = mpyu(r2,r18)
	}
	{
		r23:22 = combine(r27,r7)
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r4
	}
	{
		r7:6 += mpyu(r3,r19)
	}
	{
		r7:6 = add(r7:6,r23:22)
	}
	{
		r22 = r7
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r5
	}
	{
		r7:6 += mpyu(r3,r18)
		r3:2 = combine(r24,r8)
	}
	{
		call phase_qprep
		r17:16 = add(r7:6,r23:22)
	}
	.falign
// %bb.52:                              // %for.body174.us
                                        //   in Loop: Header=BB0_51 Depth=2
	{
		r21 = r0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r20)
		p1 = cmp.eq(r24,#0)
		r4 = memw(r29+#1312)
		memw(r29+#344) = r24
	}                                       // 4-byte Folded Spill
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r19)
		r9:8 = mpyu(r2,r18)
		r1:0 = memd(r4+#0)
	}
	{
		r22 = r7
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r8
	}
	{
		r7:6 += mpyu(r3,r19)
	}
	{
		r7:6 = add(r7:6,r23:22)
	}
	{
		r22 = r7
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r9
	}
	{
		r7:6 += mpyu(r3,r18)
	}
	{
		r3:2 = add(r7:6,r23:22)
	}
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r3:2 -= lsr(r17:16,#7)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		if (p1) jump:nt .LBB0_175
		memd(r4+#0) = r1:0
	}
// %bb.53:                              // %for.body174.us
                                        //   in Loop: Header=BB0_51 Depth=2
	{
		r2 = #0
		p0 = cmp.eq(r21,#0); if (!p0.new) jump:nt .LBB0_175
		memw(r29+#316) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_54:                               // %for.body196.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB0_60 Depth 4
                                        //         Child Loop BB0_68 Depth 4
                                        //         Child Loop BB0_81 Depth 4
                                        //         Child Loop BB0_85 Depth 4
                                        //           Child Loop BB0_95 Depth 5
                                        //           Child Loop BB0_100 Depth 5
                                        //           Child Loop BB0_107 Depth 5
                                        //             Child Loop BB0_109 Depth 6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
                                        //         Child Loop BB0_143 Depth 4
                                        //           Child Loop BB0_148 Depth 5
	{
		r20 = memw(r29+#652)
		r3 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#324)
		memw(r29+#1284) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r3,r2)
		r24 = memw(r20+#0)
		r17 = memw(r29+#648)
	}
	{
		r19 = memw(r20+#4)
		memw(r29+#296) = r4
	}                                       // 4-byte Folded Spill
	{
		r18 = mpyi(r24,r4)
		r1 = r19
		r2 = memw(r17+#4)
		r3 = memw(r17+#8)
	}
	{
		r5 = add(r18,add(r2,#1))
		r6 = add(r18,r24)
		r4 = memw(r17+#24)
		r22 = memw(r17+#0)
	}
	{
		r5 = minu(r5,r3)
		r7 = minu(r6,r22)
		p1 = cmp.eq(r4,#0)
		r6 = memw(r29+#1312)
	}
	{
		p0 = cmp.gtu(r5,r4)
		r2 = add(r7,r2)
		if (p0.new) r0 = sub(r5,r4)
		memw(r29+#280) = r6
	}                                       // 4-byte Folded Spill
	{
		r16 = minu(r2,r3)
		if (!p0) r0 = #0
	}
	{
		call __hexagon_udivsi3
		if (p1) r0 = #0
	}
	.falign
// %bb.55:                              // %for.body196.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r0 = add(r16,add(r19,#-1))
		call __hexagon_udivsi3
		r21 = r0
		r1 = r19
	}
	.falign
// %bb.56:                              // %for.body196.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		p1 = cmp.gtu(r0,r21); if (!p1.new) jump:t .LBB0_151
		memw(r29+#292) = r21
		memw(r29+#300) = r0
	}                                       // 4-byte Folded Spill
// %bb.57:                              // %if.end.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r16 = memw(r20+#12)
		if (cmp.eq(r16.new,#0)) jump:nt .LBB0_69
	}
// %bb.58:                              // %for.body.lr.ph.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r29+#656)
	}
	{
		r2 = memw(r2+#8)
	}
	{
		if (!p1.new) r21 = #0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB0_67
		if (!p1.new) r19 = memw(r20+#8)
	}
// %bb.59:                              // %for.body.lr.ph.split.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r29+#288)
		r20 = memw(r29+#760)
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#752)
	}
	{
		r3 = mpyi(r19,r3)
		r24 = mpyi(r19,r24)
	}
	{
		r26 = addasl(r2,r3,#2)
	}
	.falign
.LBB0_60:                               // %for.body.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.gtu(r24,r21)
		if (p0.new) r1:0 = combine(r19,r21)
		if (!p0.new) jump:t .LBB0_65
	}
// %bb.61:                              // %lor.lhs.false.i.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.62:                              // %lor.lhs.false.i.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		r2 = add(r0,r18)
		if (!cmp.gtu(r22,r2.new)) jump:t .LBB0_65
	}
// %bb.63:                              // %if.end.i.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		r2 = r21
		r3 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r2 -= mpyi(r0,r19)
	}
	{
		r2 = memw(r26+r2<<#2)
	}
	{
		call __truncsfhf2
		r0 = sfmpy(r2,r3)
	}
	.falign
// %bb.64:                              // %if.end.i.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		jump .LBB0_66
		r2 = memw(r29+#340)
		memh(r20+#0) = r0
	}                                       // 4-byte Folded Reload
	.falign
.LBB0_65:                               // %if.else.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		r2 = #0
		memh(r20+#0) = ##-1024
	}
	.falign
.LBB0_66:                               // %if.end.i.i.us
                                        //   in Loop: Header=BB0_60 Depth=4
	{
		r21 = add(r21,#1)
		r20 = add(r20,#2)
		memw(r25++#4) = r2
	}
	{
		p0 = cmp.eq(r16,r21); if (!p0.new) jump:t .LBB0_60
	}
	{
		jump .LBB0_69
	}
	.falign
.LBB0_67:                               // %for.body.lr.ph.split.us.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = ##64512
		r2 = memw(r29+#760)
		r3 = memw(r29+#752)
	}
	{
		loop0(.LBB0_68,r16)
	}
	.falign
.LBB0_68:                               // Block address taken
                                        // %for.body.us.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		memh(r2++#2) = r4
		memw(r3++#4) = r27
	} :endloop0
	.falign
.LBB0_69:                               // %softmax_state_init.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r0 = memw(r29+#664)
		r18 = memw(r29+#716)
	}
	{
		r19 = memw(r29+#720)
		r20 = memw(r29+#728)
	}
	{
		call hvx_worker_pool_workers
		r17 = memw(r17+#20)
	}
	.falign
// %bb.70:                              // %softmax_state_init.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = #0
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB0_73
		memw(r29+#312) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.71:                              // %land.lhs.true.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r29+#660)
	}
	{
		r3 = memb(r2+#4)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB0_73
	}
// %bb.72:                              // %land.lhs.true15.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #2047
		r2 = memw(r2+#72)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB0_152
	}
	.falign
.LBB0_73:                               // %qx_dequant_available.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	//# InlineAsm Start
	{
		r17:16 = c31:30
	}
	//# InlineAsm End
	{
		r3 = memw(r29+#660)
		r2 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#720)
	}
	{
		r5 = memw(r3+#28)
	}
	{
		r2 = mpyi(r4,r2)
		if (!cmp.gtu(r5,r2.new)) jump:nt .LBB0_77
	}
// %bb.74:                              // %qx_dequant_available.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r6 = sub(r5,r2)
	}
	{
		r4 = minu(r6,r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB0_77
	}
// %bb.75:                              // %if.end.i208.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r18 = memw(r29+#292)
		r1 = memw(r29+#724)
	}                                       // 4-byte Folded Reload
	{
		r18 = and(#4,asl(r18,#2))
		r7 = memw(r29+#288)
		r6 = memw(r3+#32)
	}                                       // 4-byte Folded Reload
	{
		r4 = mpyi(r1,r4)
		r9 = memw(r29+#640)
		r8 = memw(r3+#12)
	}
	{
		r2 += mpyi(r5,r7)
		r0 = memw(r29+#320)
		r7 = memw(r29+#732)
	}                                       // 4-byte Folded Reload
	{
		r12 = memw(r3+#56)
		memw(r29+#4) = #1

	} :mem_noshuf
	{
		r1 = mpyi(r6,r2)
		r19 = mpyi(r4,r7)
		r0 = memw(r0+r18<<#0)
		memw(r29+#0) = #0
	}
	{
		r3:2 = combine(r19,r19)
		r0 = add(r9,r0)
		r5:4 = combine(#1,r19)
	}
	{
		r20 = mpyi(r1,r8)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = add(r12,r20)
	}
	.falign
// %bb.76:                              // %if.end.i208.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r29+#660)
		r3 = memw(r29+#640)
	}
	{
		r4 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#60)
		memw(r29+#4) = #1

	} :mem_noshuf
	{
		r1 = add(r2,r20)
		r4 = memw(r4+r18<<#0)
		memw(r29+#0) = #0
	}
	{
		call hexkl_dma_ring_push2d
		r0 = add(r3,r4)
		r3:2 = combine(r19,r19)
		r5:4 = combine(#1,r19)
	}
	.falign
.LBB0_77:                               // %dma_issue.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r18 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_drain
		r19 = and(r18,#1)
	}
	.falign
// %bb.78:                              // %dma_issue.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r29+#720)
		v23 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		r3 = memw(r29+#660)
	}
	{
		r4 = mpyi(r2,r18)
	}
	{
		r3 = memw(r3+#28)
	}
	{
		r5 = sub(r3,r4)
		p1 = cmp.gtu(r3,r4)
	}
	{
		r3 = minu(r5,r2)
	}
	{
		if (!p1) r3 = #0
	}
	{
		if (p0.new) r2 = sub(r2,r3)
		p0 = cmp.gtu(r2,r3); if (!p0.new) jump:t .LBB0_82
	}
// %bb.79:                              // %if.then.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r29+#724)
		r5 = memw(r29+#732)
	}
	{
		r4 = mpyi(r5,r4)
	}
	{
		r5 = mpyi(r4,r2)
	}
	{
		r2 = mpyi(r4,r3)
		r1 = lsr(r5,#7)
		p1 = cmp.gtu(r5,#127)
		if (!p1.new) jump:t .LBB0_82
	}
// %bb.80:                              // %for.body.lr.ph.i224.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r29+#304)
		r0 = memw(r29+#640)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB0_81,r1)
	}
	{
		r6 = memw(r3+r19<<#2)
		r3 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r3 = r2
		r7 = memw(r3+r19<<#2)
	}
	{
		r2 += add(r0,r7)
		r3 += add(r0,r6)
	}
	.falign
.LBB0_81:                               // Block address taken
                                        // %for.body.i230.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		vmem(r2++#1) = v23
	}
	{
		nop
		vmem(r3++#1) = v23
	} :endloop0
	.falign
.LBB0_82:                               // %dma_land.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r6 = #10
		r13 = memw(r29+#268)
		r12 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = mpyu(r16,r6)
	}
	{
		r1 += mpyi(r17,#10)
	}
	{
		r9:8 = mpyu(r0,r13)
		r3:2 = mpyu(r0,r12)
	}
	{
		r5:4 = combine(r27,r9)
	}
	{
		r9:8 = combine(r5,r4)
		r4 = r2
	}
	{
		r9:8 += mpyu(r1,r13)
	}
	{
		r9:8 = add(r9:8,r5:4)
	}
	{
		r4 = r9
	}
	{
		r9:8 = combine(r5,r4)
		r4 = r3
	}
	{
		r9:8 += mpyu(r1,r12)
	}
	{
		r1:0 = add(r9:8,r5:4)
	}
	{
		r15:14 = lsr(r1:0,#7)
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r1:0 = mpyu(r2,r6)
		r28 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r1 += mpyi(r3,#10)
	}
	{
		r9:8 = mpyu(r0,r13)
		r3:2 = mpyu(r0,r12)
		r0 = add(r29,#640)
		r7:6 = memd(r28+#8)
	}
	{
		r7:6 = sub(r7:6,r15:14)
		r4 = r9
	}
	{
		r9:8 = combine(r5,r4)
		r4 = r2
		r2 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r9:8 += mpyu(r1,r13)
	}
	{
		r9:8 = add(r9:8,r5:4)
	}
	{
		r4 = r9
	}
	{
		r9:8 = combine(r5,r4)
		r4 = r3
		r3 = r19
	}
	{
		r9:8 += mpyu(r1,r12)
		r1 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r9:8 = add(r9:8,r5:4)
		r4 = r27
	}
	{
		r7:6 += lsr(r9:8,#7)
	}
	{
		call phase_qk
		memd(r28+#8) = r7:6
	}
	.falign
// %bb.83:                              // %dma_land.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r25 = r27
		r22 = #10
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB0_182
	}
// %bb.84:                              // %for.body.lr.ph.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r17 = memw(r29+#292)
		r23 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#288)
		r2 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
	}
	{
		r2 = p2
		p2 = and(p2,!p2)
		memw(r29+#308) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p2
		memw(r29+#252) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_85:                               // %for.body.i362.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        // =>      This Loop Header: Depth=4
                                        //           Child Loop BB0_95 Depth 5
                                        //           Child Loop BB0_100 Depth 5
                                        //           Child Loop BB0_107 Depth 5
                                        //             Child Loop BB0_109 Depth 6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
	{
		r3 = add(r17,#1)
		r24 = and(r17,#1)
		r2 = memw(r29+#300)
		memw(r29+#272) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r3)
	}
	//# InlineAsm Start
	{
		r19:18 = c31:30
	}
	//# InlineAsm End
	{
		r2 = p0
		if (!p0) jump:nt .LBB0_90
		memw(r29+#276) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.86:                              // %if.then17.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r2 = memw(r29+#660)
		r4 = memw(r29+#720)
	}
	{
		r3 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r2+#28)
	}
	{
		r3 = mpyi(r4,r3)
		if (!cmp.gtu(r5,r3.new)) jump:nt .LBB0_90
	}
// %bb.87:                              // %if.then17.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r6 = sub(r5,r3)
	}
	{
		r3 += mpyi(r5,r16)
		r4 = minu(r6,r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB0_90
	}
// %bb.88:                              // %if.end.i246.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r20 = togglebit(r24,#0)
		r6 = memw(r2+#32)
		r1 = memw(r29+#724)
	}
	{
		r9 = memw(r29+#640)
		r7 = memw(r29+#732)
	}
	{
		r3 = mpyi(r6,r3)
		r2 = mpyi(r1,r4)
		r8 = memw(r2+#12)
		r12 = memw(r2+#56)
	}
	{
		r0 = memw(r29+#320)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r22 = mpyi(r3,r8)
		r21 = mpyi(r2,r7)
		memw(r29+#0) = #0
	}
	{
		r3:2 = combine(r21,r21)
		r1 = add(r12,r22)
		r4 = memw(r0+r20<<#2)
	}
	{
		call hexkl_dma_ring_push2d
		r0 = add(r9,r4)
		r5:4 = combine(#1,r21)
	}
	.falign
// %bb.89:                              // %if.end.i246.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r2 = memw(r29+#660)
		r3 = memw(r29+#640)
	}
	{
		r4 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#60)
		memw(r29+#4) = #1

	} :mem_noshuf
	{
		r1 = add(r2,r22)
		r22 = #10
		r4 = memw(r4+r20<<#2)
		memw(r29+#0) = #0
	}
	{
		call hexkl_dma_ring_push2d
		r0 = add(r3,r4)
		r3:2 = combine(r21,r21)
		r5:4 = combine(#1,r21)
	}
	.falign
.LBB0_90:                               // %if.end19.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r1:0 = mpyu(r18,r22)
		r2 = memw(r29+#292)
		r5 = memw(r29+#648)
	}                                       // 4-byte Folded Reload
	{
		r1 += mpyi(r19,#10)
		r4 = sub(r17,r2)
		r2 = memw(r29+#652)
		memw(r29+#236) = r24
	}                                       // 4-byte Folded Spill
	{
		r20 = memw(r29+#244)
		r13 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = mpyu(r0,r23)
		r6 = memw(r2+#0)
		r7 = memw(r2+#4)
	}
	{
		r3:2 = mpyu(r0,r20)
		r24 = r3
		r0 = memw(r5+#0)
	}
	{
		r12 = mpyi(r6,r13)
		r15 = mpyi(r7,r17)
		r9:8 = combine(r25,r24)
		r24 = r2
	}
	{
		r9:8 += mpyu(r1,r23)
		r2 = add(r12,r6)
		r6 = memw(r5+#4)
	}
	{
		r2 = minu(r2,r0)
		r9:8 = add(r9:8,r25:24)
	}
	{
		r6 = add(r12,add(r6,#1))
		r2 = add(r2,r6)
		r24 = r9
	}
	{
		r9:8 = combine(r25,r24)
		r24 = r3
		r3 = memw(r5+#8)
		r5 = memw(r5+#24)
	}
	{
		r2 = minu(r2,r3)
		r3 = minu(r6,r3)
		p1 = cmp.eq(r5,#0)
		memw(r29+#1296) = r17
	}
	{
		r9:8 += mpyu(r1,r20)
		r14 = sub(r2,r5)
		p0 = cmp.gtu(r2,r5)
		r2 = add(r15,r7)
	}
	{
		p1 = not(p1)
		r1:0 = add(r9:8,r25:24)
		p2 = cmp.gtu(r14,r15)
		r17 = and(r4,#1)
	}
	{
		p0 = and(p0,p2)
		r19:18 = lsr(r1:0,#7)
		p2 = cmp.gtu(r2,r3)
		r2 = memw(r29+#716)
	}
	{
		p1 = or(p2,and(p0,p1))
		r3 = asl(r2,#5)
		r2 = add(r29,#640)
		r0 = memw(r29+#664)
	}
	{
		r1 = add(pc,##softmax_worker@PCREL)
		memw(r29+#1288) = r16
		memw(r29+#1292) = r13
	}
	{
		r5 = mux(p1,#1,#0)
		memw(r29+#1304) = r17
	}
	{
		call hvx_worker_pool_submit
		memw(r29+#1308) = r5
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r6 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
	}
	{
		r1:0 = mpyu(r2,r23)
		r5:4 = mpyu(r2,r20)
	}
	{
		r24 = r1
	}
	{
		r1:0 = combine(r25,r24)
		r24 = r4
	}
	{
		r1:0 += mpyu(r3,r23)
	}
	{
		r1:0 = add(r1:0,r25:24)
	}
	{
		r24 = r1
	}
	{
		r1:0 = combine(r25,r24)
		r24 = r5
	}
	{
		r1:0 += mpyu(r3,r20)
		r3:2 = memd(r6+#32)
	}
	{
		r1:0 = add(r1:0,r25:24)
		r3:2 = sub(r3:2,r19:18)
		r18 = r20
	}
	{
		r27:26 = lsr(r1:0,#7)
		r19 = togglebit(r17,#0)
	}
	{
		r1:0 = add(r3:2,r27:26)
	}
	{
		r0 = memw(r29+#276)
		memd(r6+#32) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		if (!p1.new) jump:t .LBB0_98
		if (p1.new) r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.91:                              // %if.then28.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		call hexkl_dma_ring_drain
		r21 = togglebit(r2,#0)
	}
	.falign
// %bb.92:                              // %if.then28.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r2 = memw(r29+#720)
		v24 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		r3 = memw(r29+#660)
		r4 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r4 = mpyi(r2,r4)
		r3 = memw(r3+#28)
	}
	{
		r5 = sub(r3,r4)
		p1 = cmp.gtu(r3,r4)
	}
	{
		r3 = minu(r5,r2)
	}
	{
		if (!p1) r3 = #0
	}
	{
		if (p0.new) r2 = sub(r2,r3)
		p0 = cmp.gtu(r2,r3); if (!p0.new) jump:t .LBB0_96
	}
// %bb.93:                              // %if.then.i293.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r4 = memw(r29+#724)
		r5 = memw(r29+#732)
	}
	{
		r4 = mpyi(r5,r4)
	}
	{
		r5 = mpyi(r4,r2)
	}
	{
		r2 = mpyi(r4,r3)
		r1 = lsr(r5,#7)
		p2 = cmp.gtu(r5,#127)
		if (!p2.new) jump:t .LBB0_96
	}
// %bb.94:                              // %for.body.lr.ph.i300.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r3 = memw(r29+#304)
		r0 = memw(r29+#640)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB0_95,r1)
	}
	{
		r6 = memw(r3+r21<<#2)
		r3 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r3 = r2
		r7 = memw(r3+r21<<#2)
	}
	{
		r2 += add(r0,r7)
		r3 += add(r0,r6)
	}
	.falign
.LBB0_95:                               // Block address taken
                                        // %for.body.i311.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		vmem(r2++#1) = v24
	}
	{
		nop
		vmem(r3++#1) = v24
	} :endloop0
	.falign
.LBB0_96:                               // %dma_land.exit319.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r1:0 = mpyu(r2,r22)
		r12 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r1 += mpyi(r3,#10)
	}
	{
		r7:6 = mpyu(r0,r23)
		r3:2 = mpyu(r0,r20)
		r0 = add(r29,#640)
		r5:4 = memd(r12+#8)
	}
	{
		r9:8 = sub(r5:4,r27:26)
		r24 = r7
		r4 = r19
		r5 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r25,r24)
		r24 = r2
		r2 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r7:6 += mpyu(r1,r23)
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r3
		r3 = r21
	}
	{
		r7:6 += mpyu(r1,r20)
		r1 = r16
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r9:8 += lsr(r7:6,#7)
	}
	{
		call phase_qk
		memd(r12+#8) = r9:8
	}
	.falign
// %bb.97:                              // %dma_land.exit319.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		if (!p1.new) r27 = add(r25,#0)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB0_178
	}
	.falign
.LBB0_98:                               // %if.end43.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r0 = memw(r29+#664)
	}
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r23)
		r5:4 = mpyu(r2,r20)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r4
	}
	{
		r7:6 += mpyu(r3,r23)
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r5
	}
	{
		r7:6 += mpyu(r3,r20)
	}
	{
		call hvx_worker_pool_wait
		r21:20 = add(r7:6,r25:24)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r27 = r25
		r4 = memw(r29+#1312)
		r5 = memw(r29+#652)
	}
	{
		r3 += mpyi(r1,#10)
	}
	{
		r9:8 = mpyu(r2,r23)
		r7:6 = mpyu(r2,r18)
		r1:0 = memd(r4+#32)
	}
	{
		r24 = r9
	}
	{
		r9:8 = combine(r25,r24)
		r24 = r6
	}
	{
		r9:8 += mpyu(r3,r23)
	}
	{
		r9:8 = add(r9:8,r25:24)
	}
	{
		r24 = r9
	}
	{
		r9:8 = combine(r25,r24)
		r24 = r7
	}
	{
		r9:8 += mpyu(r3,r18)
	}
	{
		r3:2 = add(r9:8,r25:24)
	}
	{
		r25:24 = lsr(r3:2,#7)
	}
	{
		r3:2 = combine(r25,r24)
	}
	{
		r3:2 -= lsr(r21:20,#7)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#32) = r1:0
	}
	{
		r17 = memw(r5+#12)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB0_102
	}
// %bb.99:                              // %for.body.lr.ph.i327.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r18 = memw(r29+#764)
		r20 = memw(r29+#756)
	}
	.falign
.LBB0_100:                              // %for.body.i328.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		call __extendhfsf2
		r0 = memuh(r18++#2)
	}
	.falign
// %bb.101:                             // %for.body.i328.i.us
                                        //   in Loop: Header=BB0_100 Depth=5
	{
		r17 = add(r17,#-1)
		memw(r20++#4) = r0
	}
	{
		p2 = cmp.eq(r17,#0)
		if (!p2.new) jump:t .LBB0_100
	}
	.falign
.LBB0_102:                              // %softmax_finish_pquant.exit.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r21 = add(r29,#640)
		r2 = memw(r29+#716)
		r0 = memw(r29+#664)
	}
	{
		r1 = add(pc,##pquant_worker@PCREL)
		r3 = asl(r2,#1)
		r2 = r21
	}
	{
		call hvx_worker_pool_run
		r17 = memw(r29+#236)
		memw(r29+#1300) = r17.new
	}                                       // 4-byte Folded Reload
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r5 = memw(r29+#308)
		memw(r29+#352) = r21
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
		p1 = r5
		r0 = memw(r29+#276)
		r4 = memw(r29+#1312)
	}                                       // 4-byte Folded Reload
	{
		r9:8 = mpyu(r2,r23)
		p2 = r0
		r18 = memw(r29+#244)
		memw(r29+#356) = r16
	}                                       // 4-byte Folded Reload
	{
		p2 = and(p2,!p1)
		r13:12 = combine(r27,r9)
		r1:0 = memd(r4+#40)
		memw(r29+#364) = r19
	}
	{
		r7:6 = mpyu(r2,r18)
		r9:8 = combine(r13,r12)
	}
	{
		r9:8 += mpyu(r3,r23)
		r12 = r6
	}
	{
		r9:8 = add(r9:8,r13:12)
	}
	{
		r12 = r9
	}
	{
		r9:8 = combine(r13,r12)
		r12 = r7
	}
	{
		r9:8 += mpyu(r3,r18)
		r3 = r27
	}
	{
		r3:2 = add(r9:8,r13:12)
		memd(r29+#384) = r3:2
	}                                       // 8-byte Folded Spill
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r3:2 = sub(r3:2,r25:24)
	}
	{
		r1:0 = add(r3:2,r1:0)
		r2 = memw(r29+#272)
		memw(r29+#360) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = p2
		memd(r4+#40) = r1:0
	}
	{
		if (!p2) jump:nt .LBB0_104
		memw(r29+#284) = r0
	}                                       // 4-byte Folded Spill
// %bb.103:                             // %if.then52.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = mpyu(r0,r22)
		r21:20 = memd(r29+#384)
		r2 = memw(r29+#716)
	}                                       // 8-byte Folded Reload
	{
		r1 = add(pc,##dequant_worker@PCREL)
		r5 += mpyi(r1,#10)
		r3 = memw(r29+#720)
	}
	{
		r7:6 = mpyu(r4,r23)
		r9:8 = mpyu(r4,r18)
		r0 = memw(r29+#664)
	}
	{
		r3 = mpyi(r3,r2)
		r20 = r7
		r2 = add(r29,#352)
	}
	{
		r7:6 = combine(r21,r20)
		r20 = r8
	}
	{
		r7:6 += mpyu(r5,r23)
	}
	{
		r7:6 = add(r7:6,r21:20)
	}
	{
		r20 = r7
	}
	{
		r7:6 = combine(r21,r20)
		r20 = r9
	}
	{
		r7:6 += mpyu(r5,r18)
	}
	{
		call hvx_worker_pool_submit
		r19:18 = add(r7:6,r21:20)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r8 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r23)
		r5:4 = memd(r8+#24)
	}
	{
		r5:4 -= lsr(r19:18,#7)
		r20 = r7
		r18 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r2,r18)
		r7:6 += mpyu(r3,r23)
	}
	{
		r20 = r0
	}
	{
		r7:6 = add(r7:6,r21:20)
	}
	{
		r20 = r7
	}
	{
		r7:6 = combine(r21,r20)
		r20 = r1
		r1 = r21
	}
	{
		r7:6 += mpyu(r3,r18)
		memd(r29+#384) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r3:2 = add(r7:6,r21:20)
	}
	{
		r5:4 += lsr(r3:2,#7)
	}
	{
		memd(r8+#24) = r5:4
	}
	.falign
.LBB0_104:                              // %if.end59.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r2 = memw(r29+#716)
	}
	{
		if (p1.new) r21 = #0
		if (!p1.new) r5 = #0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB0_128
	}
// %bb.105:                             // %for.cond4.preheader.lr.ph.i.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r3 = memw(r29+#724)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB0_127
	}
// %bb.106:                             //   in Loop: Header=BB0_85 Depth=4
	{
		r27 = #0
		r4 = memw(r29+#660)
		r13:12 = memd(r29+#384)
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#304)
		memw(r29+#248) = r5
	}                                       // 4-byte Folded Reload
	{
		r16 = addasl(r3,r17,#2)
		r3 = #1
		r4 = memub(r4+#4)
		memw(r29+#256) = r4.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#264) = r16
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_107:                              // %for.cond4.preheader.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        // =>        This Loop Header: Depth=5
                                        //             Child Loop BB0_109 Depth 6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
	{
		p2 = cmp.eq(r3,#0)
		if (!p2.new) r19 = #0
		r3 = #0
		if (p2.new) jump:nt .LBB0_124
	}
// %bb.108:                             // %for.body9.lr.ph.i.i.us
                                        //   in Loop: Header=BB0_107 Depth=5
	{
		r2 = asl(r27,#6)
		r17 = #0
		memw(r29+#260) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_109:                              // %for.body9.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        //           Parent Loop BB0_107 Depth=5
                                        // =>          This Loop Header: Depth=6
                                        //               Child Loop BB0_114 Depth 7
                                        //               Child Loop BB0_112 Depth 7
                                        //               Child Loop BB0_121 Depth 7
                                        //               Child Loop BB0_119 Depth 7
	{
		r2 = memw(r29+#256)
		memd(r29+#384) = r13:12
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#1)
	}
	{
		r2 = p0
	}
	{
		r20 = r2
		memw(r29+#236) = r20.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r25:24 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.110:                             // %for.body9.i.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r2 = r20
	}
	{
		p1 = r2
		if (!p1.new) r13 = #31
		if (!p1.new) r2 = #0
		if (!p1.new) jump:t .LBB0_113
	}
// %bb.111:                             // %for.cond10.preheader.i.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r2 = #0
		r13 = #31
		r14 = #384
	}
	{
		r3 = memw(r29+#720)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB0_115
	}
	.falign
.LBB0_112:                              // %for.body15.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        //           Parent Loop BB0_107 Depth=5
                                        //             Parent Loop BB0_109 Depth=6
                                        // =>            This Inner Loop Header: Depth=7
	{
		r6 = r17
		r4 = r2
		r5 = memw(r29+#724)
		r8 = memw(r29+#700)
	}
	{
		r4 += mpyi(r27,r3)
		r7 = memw(r29+#640)
		r9 = memw(r29+#732)
	}
	{
		r6 += mpyi(r5,r2)
		r5 = add(r7,r8)
		r12 = memw(r16+#0)
	}
	{
		r5 += asl(r4,#11)
		r7 = add(r7,r12)
	}
	{
		r7 += mpyi(r6,r9)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r13):cm
		weight.n = mxmem(r7,r14)
	}

	//# InlineAsm End
	{
		r2 = add(r2,#1)
	}
	{
		r3 = memw(r29+#720)
		if (cmp.gtu(r3.new,r2)) jump:t .LBB0_112
	}
	{
		jump .LBB0_115
	}
	.falign
.LBB0_113:                              // %for.cond19.preheader.i.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r14 = #896
		r3 = memw(r29+#720)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB0_115
	}
	.falign
.LBB0_114:                              // %for.body25.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        //           Parent Loop BB0_107 Depth=5
                                        //             Parent Loop BB0_109 Depth=6
                                        // =>            This Inner Loop Header: Depth=7
	{
		r6 = r17
		r4 = r2
		r5 = memw(r29+#724)
		r8 = memw(r29+#700)
	}
	{
		r4 += mpyi(r27,r3)
		r7 = memw(r29+#640)
		r9 = memw(r29+#732)
	}
	{
		r6 += mpyi(r5,r2)
		r5 = add(r7,r8)
		r12 = memw(r16+#0)
	}
	{
		r5 += asl(r4,#11)
		r7 = add(r7,r12)
	}
	{
		r7 += mpyi(r6,r9)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r13):cm
		weight.b = mxmem(r7,r14)
	}

	//# InlineAsm End
	{
		r2 = add(r2,#1)
	}
	{
		r3 = memw(r29+#720)
		if (cmp.gtu(r3.new,r2)) jump:t .LBB0_114
	}
	.falign
.LBB0_115:                              // %if.end.i349.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r0 = memw(r29+#640)
		r2 = memw(r29+#688)
	}
	{
		call hexkl_micro_hmx_acc_read_int32
		r1 = memw(r29+#644)
	}
	.falign
// %bb.116:                             // %if.end.i349.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r21 = r0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB0_128
		if (p0.new) r9:8 = memd(r29+#384)
	}                                       // 8-byte Folded Reload
// %bb.117:                             // %for.inc43.i.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	{
		r1:0 = mpyu(r24,r22)
	}
	{
		r1 += mpyi(r25,#10)
		r3:2 = mpyu(r0,r23)
	}
	{
		r5:4 = mpyu(r0,r18)
	}
	{
		r8 = r3
	}
	{
		r3:2 = combine(r9,r8)
		r8 = r4
	}
	{
		r3:2 += mpyu(r1,r23)
	}
	{
		r3:2 = add(r3:2,r9:8)
	}
	{
		r8 = r3
	}
	{
		r3:2 = combine(r9,r8)
		r8 = r5
	}
	{
		r3:2 += mpyu(r1,r18)
	}
	{
		r1:0 = add(r3:2,r9:8)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = mpyu(r2,r22)
		r13 = memw(r29+#1312)
		memw(r29+#236) = r19
	}                                       // 4-byte Folded Spill
	{
		r5 += mpyi(r3,#10)
		r2 = memw(r29+#640)
		r11 = memw(r29+#688)
	}
	{
		r7:6 = mpyu(r4,r23)
		r25:24 = mpyu(r4,r18)
		r15 = r11
		r14 = memw(r29+#736)
	}
	{
		r8 = r7
		r28 = r11
		r16 = memw(r29+#768)
		r26 = memw(r29+#756)
	}
	{
		r7:6 = combine(r9,r8)
		r8 = r24
		r10 = r11
		r4 = memw(r29+#704)
	}
	{
		r7:6 += mpyu(r5,r23)
		r24 = add(r4,r19)
		r19 = r9
		r23:22 = memd(r13+#48)
	}
	{
		r7:6 = add(r7:6,r9:8)
		r21 = r11
		r20 = memw(r29+#648)
		memd(r29+#384) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r8 = r7
		r12 = r2
		r3 = r2
	}
	{
		r7:6 = combine(r9,r8)
		r8 = r25
	}
	{
		r7:6 += mpyu(r5,r18)
		r5:4 = combine(r2,r2)
	}
	{
		r19:18 = add(r7:6,r9:8)
		r7:6 = combine(r2,r2)
		r9:8 = combine(r2,r2)
	}
	{
		r19:18 = lsr(r19:18,#7)
	}
	{
		r1:0 = sub(r19:18,r1:0)
		memd(r29+#392) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r1:0,r23:22)
	}
	{
		memd(r13+#48) = r1:0
		r13 = memw(r14+#8)

	} :mem_noshuf
	{
		r0 = extractu(r13,#25,#5)
		r14 = memw(r14+#12)
	}
	{
		r25 = lsr(r14,#5)
		r22 = asl(r0,#7)
		r14 = memw(r20+#20)
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r15 += mpyi(r25,##896)
		r20 = lsr(r14,#5)
	}
	{
		r18 = extractu(r20,#22,#0)
		r24 += mpyi(r0,r14)
	}
	{
		r1 = +mpyi(r20,##896)
		r0 = extractu(r25,#23,#0)
	}
	{
		r28 += asl(r0,#9)
		r14 = asl(r18,#10)
	}
	{
		r13 = +mpyi(r20,##768)
		r4 += add(r24,r1)
		r0 = r14
	}
	{
		r1 = +mpyi(r20,##640)
		r5 += add(r15,r22)
		r15 = r22
	}
	{
		r10 += mpyi(r25,##640)
		r0 = insert(r20,#23,#9)
	}
	{
		r15 += add(r2,r11)
		r7 += add(r24,r1)
		r1 = r13
	}
	{
		r9 += add(r28,r22)
		r11 += mpyi(r25,##384)
		r28 = r2
	}
	{
		r21 += mpyi(r25,##768)
		r12 += add(r24,r0)
	}
	{
		r18 = +mpyi(r20,##384)
		r1 = insert(r20,#24,#8)
	}
	{
		r8 += add(r10,r22)
		r28 += add(r11,r22)
		r11:10 = combine(r14,r2)
	}
	{
		r0 = extractu(r25,#25,#0)
		r6 += add(r21,r22)
		r22 = r18
		r21 = add(r2,r24)
	}
	{
		r3 += add(r24,r13)
		r10 += add(r24,r18)
		r18 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r2 += add(r24,r1)
		r24 = asl(r0,#7)
		r0 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r11 = insert(r25,#22,#10)
		r13 = insert(r25,#24,#8)
	}
	{
		r22 = insert(r20,#25,#7)
		r16 = addasl(r16,r0,#7)
	}
	{
		p1 = r18
		if (!p1.new) jump:t .LBB0_120
	}
// %bb.118:                             //   in Loop: Header=BB0_109 Depth=6
	{
		loop0(.LBB0_119,#8)
		r26 = addasl(r26,r0,#2)
	}
	.falign
.LBB0_119:                              // Block address taken
                                        // %for.body.us.i.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        //           Parent Loop BB0_107 Depth=5
                                        //             Parent Loop BB0_109 Depth=6
                                        // =>            This Inner Loop Header: Depth=7
	{
		r0 = add(r15,r24)
		v13.sf = v12.w
		r18 = memw(r26+#0)
		v12.cur = vmem(r15+#0)
	}
	{
		v14 = vsplat(r18)
		r1 = add(r15,r13)
		r19 = memw(r26+#4)
		r20 = memw(r26+#8)
	}
	{
		v15 = vsplat(r19)
		v22.sf = v21.w
		r18 = memw(r26+#12)
		v21.cur = vmem(r0+#0)
	}
	{
		v16 = vsplat(r20)
		v17 = vsplat(r18)
		r0 = add(r21,r22)
		v18 = vmem(r16+#0)
	}
	{
		v23.qf32 = vmpy(v13.sf,v18.sf)
		r15 = add(r15,r11)
		v29.sf = v28.w
		v28.cur = vmem(r1+#0)
	}
	{
		v31.qf32 = vmpy(v30.sf,v14.sf)
		v30.cur = vmem(r21+#0)
	}
	{
		r28 = add(r28,r11)
		v20.sf = v19.w
		v19.cur = vmem(r28+#0)
	}
	{
		v27.qf32 = vmpy(v22.sf,v26.sf)
		v6.qf32 = vadd(v23.qf32,v31.qf32)
		v26.cur = vmem(r16+#1)
	}
	{
		v1.qf32 = vmpy(v0.sf,v15.sf)
		v0.cur = vmem(r0+#0)
	}
	{
		v3.qf32 = vmpy(v29.sf,v2.sf)
		v11.sf = v6.qf32
		v2.cur = vmem(r16+#2)
	}
	{
		v5.qf32 = vmpy(v4.sf,v16.sf)
		v9.qf32 = vadd(v27.qf32,v1.qf32)
		v4.cur = vmem(r2+#0)
	}
	{
		v25.qf32 = vmpy(v20.sf,v24.sf)
		v24.cur = vmem(r16+#3)
	}
	{
		v8.qf32 = vmpy(v7.sf,v17.sf)
		v10.qf32 = vadd(v3.qf32,v5.qf32)
		v7.cur = vmem(r10+#0)
	}
	{
		r21 = add(r21,r14)
		v3.sf = v9.qf32
		vmem(r21+#0) = v11
	}
	{
		v2.qf32 = vadd(v25.qf32,v8.qf32)
		v4.sf = v10.qf32
		vmem(r0+#0) = v3
	}
	{
		r2 = add(r2,r14)
		vmem(r2+#0) = v4
	}
	{
		r10 = add(r10,r14)
		v5.sf = v2.qf32
		vmem(r10+#0) = v5.new
	}
	{
		r9 = add(r9,r11)
		v8.sf = v7.w
		r0 = memw(r26+#16)
		v7.cur = vmem(r9+#0)
	}
	{
		v24 = vsplat(r0)
		v10.sf = v9.w
		r0 = memw(r26+#20)
		v9.cur = vmem(r8+#0)
	}
	{
		v14 = vsplat(r0)
		v18.sf = v17.w
		r0 = memw(r26+#24)
		v17.cur = vmem(r5+#0)
	}
	{
		v17 = vsplat(r0)
		v12.sf = v11.w
		r1 = memw(r26+#28)
		v11.cur = vmem(r6+#0)
	}
	{
		v13.qf32 = vmpy(v8.sf,v6.sf)
		r5 = add(r5,r11)
		r6 = add(r6,r11)
		v6.cur = vmem(r16+#4)
	}
	{
		v27.qf32 = vmpy(v10.sf,v19.sf)
		r8 = add(r8,r11)
		r26 = add(r26,#32)
		v19.cur = vmem(r16+#5)
	}
	{
		v16.qf32 = vmpy(v15.sf,v24.sf)
		v15.cur = vmem(r12+#0)
	}
	{
		v29.qf32 = vmpy(v12.sf,v21.sf)
		v21.cur = vmem(r16+#6)
	}
	{
		v31.qf32 = vmpy(v18.sf,v26.sf)
		r16 = add(r16,#1024)
		v23.qf32 = vadd(v13.qf32,v16.qf32)
		v26.cur = vmem(r16+#7)
	}
	{
		v20.qf32 = vmpy(v19.sf,v14.sf)
		v19.cur = vmem(r7+#0)
	}
	{
		v18 = vsplat(r1)
		v28.sf = v23.qf32
		v21 = vmem(r3+#0)
	}
	{
		v22.qf32 = vmpy(v21.sf,v17.sf)
		v25.qf32 = vadd(v27.qf32,v20.qf32)
		v11 = vmem(r4+#0)
	}
	{
		v24.qf32 = vmpy(v11.sf,v18.sf)
		r12 = add(r12,r14)
		vmem(r12+#0) = v28
	}
	{
		r7 = add(r7,r14)
		v26.qf32 = vadd(v29.qf32,v22.qf32)
		v29.sf = v25.qf32
		vmem(r7+#0) = v29.new
	}
	{
		v27.qf32 = vadd(v31.qf32,v24.qf32)
	}
	{
		r3 = add(r3,r14)
		v31.sf = v26.qf32
		vmem(r3+#0) = v31.new
	}
	{
		r4 = add(r4,r14)
		v30.sf = v27.qf32
		vmem(r4+#0) = v30.new
	} :endloop0
	{
		jump .LBB0_122
	}
	.falign
.LBB0_120:                              //   in Loop: Header=BB0_109 Depth=6
	{
		loop0(.LBB0_121,#8)
	}
	.falign
.LBB0_121:                              // Block address taken
                                        // %for.body.i.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_85 Depth=4
                                        //           Parent Loop BB0_107 Depth=5
                                        //             Parent Loop BB0_109 Depth=6
                                        // =>            This Inner Loop Header: Depth=7
	{
		r0 = add(r15,r24)
		r1 = add(r15,r13)
		v5.sf = v4.w
		v4.cur = vmem(r15+#0)
	}
	{
		r0 = add(r21,r22)
		r15 = add(r15,r11)
		v8.sf = v7.w
		v7.cur = vmem(r0+#0)
	}
	{
		v11.qf32 = vmpy(v5.sf,v6.sf)
		v6.cur = vmem(r16+#0)
	}
	{
		v10.sf = v9.w
		v9.cur = vmem(r1+#0)
	}
	{
		r28 = add(r28,r11)
		v15.sf = v14.w
		v19.sf = v11.qf32
		v14.cur = vmem(r28+#0)
	}
	{
		v13.qf32 = vmpy(v8.sf,v12.sf)
		v12.cur = vmem(r16+#1)
	}
	{
		v17.qf32 = vmpy(v10.sf,v16.sf)
		v16.cur = vmem(r16+#2)
	}
	{
		v20.qf32 = vmpy(v15.sf,v18.sf)
		r21 = add(r21,r14)
		v18.cur = vmem(r16+#3)
		vmem(r21+#0) = v19
	}
	{
		v21.sf = v13.qf32
		v22.sf = v17.qf32
		vmem(r0+#0) = v21.new
	}
	{
		r2 = add(r2,r14)
		v23.sf = v20.qf32
		vmem(r2+#0) = v22
	}
	{
		r10 = add(r10,r14)
		vmem(r10+#0) = v23
	}
	{
		r9 = add(r9,r11)
		v27.sf = v26.w
		v26.cur = vmem(r9+#0)
	}
	{
		r8 = add(r8,r11)
		v29.sf = v28.w
		v28.cur = vmem(r8+#0)
	}
	{
		r6 = add(r6,r11)
		v31.sf = v30.w
		v30.cur = vmem(r6+#0)
	}
	{
		v0.qf32 = vmpy(v27.sf,v24.sf)
		v24.cur = vmem(r16+#4)
	}
	{
		r5 = add(r5,r11)
		v2.sf = v1.w
		v1.cur = vmem(r5+#0)
	}
	{
		v3.qf32 = vmpy(v29.sf,v25.sf)
		v28.sf = v0.qf32
		v25.cur = vmem(r16+#5)
	}
	{
		v25.qf32 = vmpy(v31.sf,v24.sf)
		v24.cur = vmem(r16+#6)
	}
	{
		v27.qf32 = vmpy(v2.sf,v26.sf)
		r12 = add(r12,r14)
		v26.cur = vmem(r16+#7)
		vmem(r12+#0) = v28
	}
	{
		r7 = add(r7,r14)
		v29.sf = v3.qf32
		v30.sf = v25.qf32
		vmem(r7+#0) = v29.new
	}
	{
		r3 = add(r3,r14)
		r16 = add(r16,#1024)
		v31.sf = v27.qf32
		vmem(r3+#0) = v30
	}
	{
		r4 = add(r4,r14)
		vmem(r4+#0) = v31
	} :endloop0
	.falign
.LBB0_122:                              // %o_update.exit.i.i.us
                                        //   in Loop: Header=BB0_109 Depth=6
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r22 = #10
		r17 = add(r17,#1)
		r23 = memw(r29+#268)
		r4 = memw(r29+#1312)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = mpyu(r0,r22)
		r18 = memw(r29+#244)
		r13:12 = memd(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
		r1:0 = memd(r4+#56)
		r19 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = mpyu(r2,r23)
		r9:8 = mpyu(r2,r18)
		r19 = add(r19,#128)
		r16 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r12 = r7
	}
	{
		r7:6 = combine(r13,r12)
		r12 = r8
	}
	{
		r7:6 += mpyu(r3,r23)
	}
	{
		r7:6 = add(r7:6,r13:12)
	}
	{
		r12 = r7
	}
	{
		r7:6 = combine(r13,r12)
		r12 = r9
	}
	{
		r7:6 += mpyu(r3,r18)
	}
	{
		r3:2 = add(r7:6,r13:12)
		r7:6 = memd(r29+#392)
	}                                       // 8-byte Folded Reload
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r3:2 = sub(r3:2,r7:6)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	{
		r3 = memw(r29+#724)
		if (cmp.gtu(r3.new,r17)) jump:t ##.LBB0_109
	}
// %bb.123:                             // %for.inc48.loopexit.i.i.us
                                        //   in Loop: Header=BB0_107 Depth=5
	{
		r2 = memw(r29+#716)
	}
	.falign
.LBB0_124:                              // %for.inc48.i.i.us
                                        //   in Loop: Header=BB0_107 Depth=5
	{
		r27 = add(r27,#1)
		r4 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,r27)
		r4 = add(r4,#256)
		if (p1.new) jump:t .LBB0_107
		memw(r29+#248) = r4.new
	}                                       // 4-byte Folded Spill
// %bb.125:                             //   in Loop: Header=BB0_85 Depth=4
	{
		r21 = #0 ; jump .LBB0_128
		memd(r29+#384) = r13:12
	}                                       // 8-byte Folded Spill
	.falign
.LBB0_127:                              //   in Loop: Header=BB0_85 Depth=4
	{
		r21 = #0
	}
	.falign
.LBB0_128:                              // %phase_pv.exit.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		r2 = memw(r29+#284)
		r25:24 = memd(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB0_130
	}
// %bb.129:                             // %if.then64.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r0 = memw(r29+#664)
	}
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r23)
		r5:4 = mpyu(r2,r18)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r4
	}
	{
		r7:6 += mpyu(r3,r23)
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r5
	}
	{
		r7:6 += mpyu(r3,r18)
	}
	{
		call hvx_worker_pool_wait
		r17:16 = add(r7:6,r25:24)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = mpyu(r0,r22)
		r8 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
	}
	{
		r7:6 = mpyu(r2,r23)
		r1:0 = mpyu(r2,r18)
		r5:4 = memd(r8+#24)
	}
	{
		r5:4 -= lsr(r17:16,#7)
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r0
	}
	{
		r7:6 += mpyu(r3,r23)
	}
	{
		r7:6 = add(r7:6,r25:24)
	}
	{
		r24 = r7
	}
	{
		r7:6 = combine(r25,r24)
		r24 = r1
	}
	{
		r7:6 += mpyu(r3,r18)
	}
	{
		r1:0 = add(r7:6,r25:24)
	}
	{
		r5:4 += lsr(r1:0,#7)
	}
	{
		memd(r8+#24) = r5:4
	}
	.falign
.LBB0_130:                              // %if.end71.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		if (!p0.new) r27 = add(r25,#0)
		p0 = cmp.eq(r21,#0); if (!p0.new) jump:nt .LBB0_177
		r16 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
// %bb.131:                             // %for.inc.i.us
                                        //   in Loop: Header=BB0_85 Depth=4
	{
		p0 = or(p0,!p0)
		r17 = memw(r29+#272)
		r2 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r1 = p0
		r0 = memw(r29+#276)
		memw(r29+#252) = r1.new
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (p0.new) jump:t .LBB0_85
		memw(r2+#88) += #1
	}
// %bb.132:                             // %for.end.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	//# InlineAsm Start
	{
		r17:16 = c31:30
	}
	//# InlineAsm End
	{
		r3 = #127
		r0 = memw(r29+#664)
		r2 = memw(r29+#648)
	}
	{
		p2 = cmp.eq(r0,#0)
		if (p2.new) jump:nt .LBB0_141
	}
// %bb.133:                             // %land.lhs.true.i369.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#0)
		if (!cmp.gtu(r3.new,r3)) jump:nt .LBB0_141
	}
// %bb.134:                             // %land.lhs.true.i369.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = and(r3,#127)
		if (!cmp.eq(r4.new,#0)) jump:nt .LBB0_141
	}
// %bb.135:                             // %land.lhs.true5.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r2+#4)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB0_141
	}
// %bb.136:                             // %land.lhs.true8.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r2+#8)
		if (!cmp.eq(r4.new,r3)) jump:t .LBB0_141
	}
// %bb.137:                             // %land.lhs.true13.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #32
	}
	{
		r3 = memw(r2+#12)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB0_141
	}
// %bb.138:                             // %land.lhs.true16.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#16)
		if (!cmp.eq(r3.new,#8)) jump:t .LBB0_141
	}
// %bb.139:                             // %land.lhs.true19.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #64
	}
	{
		r3 = memw(r2+#20)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB0_141
	}
// %bb.140:                             // %land.lhs.true22.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#24)
		if (cmp.eq(r3.new,#0)) jump:nt ##.LBB0_169
	}
	.falign
.LBB0_141:                              // %if.else.i373.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r29+#652)
	}
	{
		r18 = memw(r3+#12)
		if (cmp.eq(r18.new,#0)) jump:nt .LBB0_150
	}
// %bb.142:                             //   in Loop: Header=BB0_54 Depth=3
	{
		r19 = #0
		r22 = memw(r2+#20)
	}
	.falign
.LBB0_143:                              // %for.body.i.i377.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        // =>      This Loop Header: Depth=4
                                        //           Child Loop BB0_148 Depth 5
	{
		r2 = memw(r29+#652)
	}
	{
		r21 = memw(r2+#8)
		r20 = memw(r2+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r19)
	}
	.falign
// %bb.144:                             // %for.body.i.i377.i.us
                                        //   in Loop: Header=BB0_143 Depth=4
	{
		r2 = mpyi(r21,r20)
		if (!cmp.gtu(r2.new,r19)) jump:t .LBB0_149
	}
// %bb.145:                             // %lor.lhs.false.i.i.i.i.us
                                        //   in Loop: Header=BB0_143 Depth=4
	{
		r2 = r0
		r3 = memw(r29+#648)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
	}
	{
		r2 += mpyi(r20,r4)
		if (!cmp.gtu(r6,r2.new)) jump:t .LBB0_149
	}
// %bb.146:                             // %if.end.i.i.i.i.us
                                        //   in Loop: Header=BB0_143 Depth=4
	{
		r5 = ##1065385983
		r4 = memw(r29+#752)
	}
	{
		r5 = add(r5,#-32767)
	}
	{
		r6 = r5
		r4 = memw(r4+r19<<#2)
	}
	{
		r7,p0 = sfrecipa(r5,r4)
		r8 = sffixupd(r5,r4)
	}
	{
		r9 = sffixupn(r5,r4)
	}
	{
		r6 -= sfmpy(r8,r7):lib
	}
	{
		r4 = and(r9,##-2147483648)
	}
	{
		r7 += sfmpy(r6,r7):lib
		r6 = r9
	}
	{
		r4 += sfmpy(r9,r7):lib
		r5 -= sfmpy(r8,r7):lib
	}
	{
		r7 += sfmpy(r5,r7):lib
		r6 -= sfmpy(r8,r4):lib
	}
	{
		r4 += sfmpy(r6,r7):lib
	}
	{
		r9 -= sfmpy(r4,r8):lib
	}
	{
		r4 += sfmpy(r9,r7,p0):scale
		r5 = memw(r29+#724)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB0_149
	}
// %bb.147:                             // %for.body13.preheader.i.i.i.us
                                        //   in Loop: Header=BB0_143 Depth=4
	{
		v0 = vsplat(r4)
		r6 = r19
		r5 = memw(r29+#656)
		r4 = memw(r29+#640)
	}
	{
		r6 -= mpyi(r0,r21)
		r8 = memw(r29+#288)
		r3 = memw(r3+#20)
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r5+#16)
		r15 = memw(r29+#704)
	}
	{
		r6 += mpyi(r21,r8)
		r3 = mpyi(r3,r19)
		r4 = add(r4,r15)
		r5 = memw(r5+#12)
	}
	{
		r2 = mpyi(r7,r2)
		r3 = addasl(r4,r3,#2)
	}
	{
		r5 = addasl(r5,r2,#2)
		r6 = mpyi(r6,r22)
		r2 = #0
	}
	{
		r4 = addasl(r5,r6,#2)
	}
	.balign 32
.LBB0_148:                              // %for.body13.i.i.i.us
                                        //   Parent Loop BB0_50 Depth=1
                                        //     Parent Loop BB0_51 Depth=2
                                        //       Parent Loop BB0_54 Depth=3
                                        //         Parent Loop BB0_143 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		v21.qf32 = vmpy(v20.sf,v0.sf)
		r2 = add(r2,#1)
		v20.cur = vmem(r3++#1)
	}
	{
		v22.sf = v21.qf32
	}
	{
		vmemu(r4++#1) = v22
	}
	{
		r5 = memw(r29+#724)
		if (cmp.gtu(r5.new,r2)) jump:t .LBB0_148
	}
	.falign
.LBB0_149:                              // %cleanup.i.i.i.us
                                        //   in Loop: Header=BB0_143 Depth=4
	{
		r19 = add(r19,#1)
		if (!cmp.eq(r19.new,r18)) jump:t .LBB0_143
	}
	.falign
.LBB0_150:                              // %phase_store.exit.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r6 = #10
		r9 = memw(r29+#268)
		r8 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = mpyu(r16,r6)
	}
	{
		r1 += mpyi(r17,#10)
	}
	{
		r5:4 = mpyu(r0,r9)
		r3:2 = mpyu(r0,r8)
	}
	{
		r13:12 = combine(r25,r5)
	}
	{
		r5:4 = combine(r13,r12)
		r12 = r2
	}
	{
		r5:4 += mpyu(r1,r9)
	}
	{
		r5:4 = add(r5:4,r13:12)
	}
	{
		r12 = r5
	}
	{
		r5:4 = combine(r13,r12)
		r12 = r3
	}
	{
		r5:4 += mpyu(r1,r8)
	}
	{
		r1:0 = add(r5:4,r13:12)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = mpyu(r2,r6)
		r27 = r25
		r14 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r5 += mpyi(r3,#10)
	}
	{
		r3:2 = mpyu(r4,r8)
		r7:6 = memd(r14+#64)
	}
	{
		r7:6 = mpyu(r4,r9)
		r1:0 = sub(r7:6,r1:0)
	}
	{
		r12 = r7
	}
	{
		r7:6 = combine(r13,r12)
		r12 = r2
	}
	{
		r7:6 += mpyu(r5,r9)
	}
	{
		r7:6 = add(r7:6,r13:12)
	}
	{
		r12 = r7
	}
	{
		r7:6 = combine(r13,r12)
		r12 = r3
	}
	{
		r7:6 += mpyu(r5,r8)
	}
	{
		r3:2 = add(r7:6,r13:12)
	}
	{
		r1:0 += lsr(r3:2,#7)
	}
	{
		memd(r14+#64) = r1:0
	}
	.falign
.LBB0_151:                              // %run_q_block.exit.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r29+#316)
		r2 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		memw(r29+#316) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p2 = cmp.gtu(r2,r3)
		if (p2.new) jump:t .LBB0_54
	}
	{
		jump .LBB0_174
	}
	.falign
.LBB0_152:                              // %land.lhs.true17.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r29+#648)
	}
	{
		r3 = memw(r2+#0)
		if (!cmp.gtu(r3.new,r3)) jump:nt ##.LBB0_73
	}
// %bb.153:                             // %land.lhs.true17.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = and(r3,#127)
		if (!cmp.eq(r4.new,#0)) jump:nt ##.LBB0_73
	}
// %bb.154:                             // %land.lhs.true26.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r2+#4)
		if (!cmp.eq(r4.new,#0)) jump:t ##.LBB0_73
	}
// %bb.155:                             // %land.lhs.true30.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r2+#8)
		if (!cmp.eq(r4.new,r3)) jump:t ##.LBB0_73
	}
// %bb.156:                             // %land.lhs.true36.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #32
	}
	{
		r3 = memw(r2+#12)
		if (!cmp.eq(r3.new,r3)) jump:t ##.LBB0_73
	}
// %bb.157:                             // %land.lhs.true40.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#16)
		if (!cmp.eq(r3.new,#8)) jump:t ##.LBB0_73
	}
// %bb.158:                             // %land.lhs.true44.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #64
	}
	{
		r3 = memw(r2+#20)
		if (!cmp.eq(r3.new,r3)) jump:t ##.LBB0_73
	}
// %bb.159:                             // %land.lhs.true49.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#24)
		if (!cmp.eq(r3.new,#0)) jump:t ##.LBB0_73
	}
// %bb.160:                             // %land.lhs.true53.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r2+#28)
	}
	{
		p0 = sfcmp.uo(r2,r27)
		p1 = sfcmp.eq(r2,r27)
	}
	{
		p0 = and(p1,!p0)
		if (!p0.new) jump:nt .LBB0_73
		if (p0.new) r2 = memw(r29+##656)
	}
// %bb.161:                             // %land.lhs.true57.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r2+#8)
		if (!cmp.eq(r2.new,#0)) jump:t ##.LBB0_73
	}
// %bb.162:                             // %land.lhs.true59.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #128
		r2 = memw(r29+#652)
	}
	{
		r3 = memw(r2+#0)
		if (!cmp.eq(r3.new,r3)) jump:t ##.LBB0_73
	}
// %bb.163:                             // %land.lhs.true63.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = #256
	}
	{
		r3 = memw(r2+#4)
		if (!cmp.eq(r3.new,r3)) jump:t ##.LBB0_73
	}
// %bb.164:                             // %land.lhs.true67.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = memw(r2+#12)
	}
	{
		p0 = cmp.eq(r2,##512)
		if (!p0.new) jump:nt .LBB0_73
	}
// %bb.165:                             // %land.lhs.true67.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3:2 = mpyu(r16,r20)
		r1:0 = mpyu(r18,r19)
	}
	{
		r1:0 = asl(r1:0,#13)
	}
	{
		r5:4 = mpyu(r2,r17)
	}
	{
		r5 += mpyi(r17,r3)
	}
	{
		r3:2 = asl(r5:4,#2)
		r5 = r27
	}
	{
		p1 = cmp.gtu(r1:0,r3:2)
		if (p1.new) jump:nt .LBB0_73
		if (!p1.new) r2 = memw(r29+##708)
	}
// %bb.166:                             // %land.lhs.true75.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memw(r29+#712)
	}
	{
		r27:26 = combine(r5,r4)
		p0 = cmp.gtu(r2,r4); if (p0.new) jump:nt .LBB0_73
	}
// %bb.167:                             // %land.lhs.true75.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r5:4 = combine(r27,r26)
		r3 = memw(r29+#644)
		if (cmp.gtu(r26,r3.new)) jump:nt ##.LBB0_73
	}
// %bb.168:                             // %land.rhs.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = r5
	}
	{
		r3:2 = sub(r27:26,r3:2)
	}
	{
		p0 = cmp.gtu(r1:0,r3:2)
		r2 = #0
	}
	{
		r2 = mux(p0,#0,#1)
		jump .LBB0_73
		memw(r29+#312) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB0_169:                              // %land.lhs.true25.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r2+#28)
	}
	{
		p2 = sfcmp.uo(r3,r25)
		p1 = sfcmp.eq(r3,r25)
	}
	{
		p0 = and(p1,!p2)
		if (!p0.new) jump:nt .LBB0_141
		if (p0.new) r3 = memw(r29+##660)
	}
// %bb.170:                             // %land.lhs.true28.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r4 = memb(r3+#4)
		if (!cmp.eq(r4.new,#0)) jump:t ##.LBB0_141
	}
// %bb.171:                             // %land.lhs.true31.i.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r3 = memw(r3+#72)
		if (!cmp.eq(r3.new,#0)) jump:t ##.LBB0_141
	}
// %bb.172:                             // %if.then.i401.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		r2 = add(r29,#640)
		r3 = memw(r29+#652)
		memw(r29+#352) = r2.new
	}
	{
		r1 = add(pc,##store_worker@PCREL)
		r2 = add(r29,#352)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+#12)
		memw(r29+#360) = r4
	}
	{
		call hvx_worker_pool_run
		r6 = memw(r29+#288)
		memw(r29+#356) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.173:                             // %if.then.i401.i.us
                                        //   in Loop: Header=BB0_54 Depth=3
	{
		jump .LBB0_150
	}
	.falign
.LBB0_174:                              //   in Loop: Header=BB0_51 Depth=2
	{
		r21 = #0
	}
	.falign
.LBB0_175:                              // %for.cond.cleanup195.us
                                        //   in Loop: Header=BB0_51 Depth=2
	{
		p1 = cmp.eq(r21,#0)
		r2 = memw(r29+#328)
		r3 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r2)
		r0 = memw(r29+#332)
		memw(r29+#324) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r0,r3); if (!p0.new) jump:nt .LBB0_180
	}
// %bb.176:                             // %for.cond.cleanup195.us
                                        //   in Loop: Header=BB0_51 Depth=2
	{
		p0 = cmp.eq(r21,#0); if (p0.new) jump:t .LBB0_51
	}
	{
		jump .LBB0_180
	}
	.falign
.LBB0_177:                              // %cleanup77.i.us
                                        //   in Loop: Header=BB0_50 Depth=1
	{
		p1 = and(p1,!p1)
		jump .LBB0_180
	}
	.falign
.LBB0_178:                              // %cleanup77.thread.i.us
                                        //   in Loop: Header=BB0_50 Depth=1
	{
		call hvx_worker_pool_wait
		r21 = r0
		r0 = memw(r29+#664)
	}
	.falign
// %bb.179:                             // %cleanup77.thread.i.us
                                        //   in Loop: Header=BB0_50 Depth=1
	{
		p1 = and(p1,!p1)
	}
	.falign
.LBB0_180:                              // %for.cond166.for.cond.cleanup173_crit_edge.us
                                        //   in Loop: Header=BB0_50 Depth=1
	{
		r2 = memw(r29+#240)
		r3 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		memw(r29+#288) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+#16)
		if (!cmp.gtu(r2.new,r3)) jump:nt ##.LBB0_46
	}
// %bb.181:                             // %for.cond166.for.cond.cleanup173_crit_edge.us
                                        //   in Loop: Header=BB0_50 Depth=1
	{
		if (p1) jump:nt .LBB0_50
	}
	{
		jump .LBB0_46
	}
	.falign
.LBB0_182:                              //   in Loop: Header=BB0_50 Depth=1
	{
		p1 = and(p1,!p1)
		r21 = r0 ; jump .LBB0_180
	}
.Lfunc_end0:
	.size	hexkl_attn_q_prefill, .Lfunc_end0-hexkl_attn_q_prefill
                                        // -- End function
	.falign
	.type	hexkl_attn_q_widen_prefill,@function // -- Begin function hexkl_attn_q_widen_prefill
hexkl_attn_q_widen_prefill:             // @hexkl_attn_q_widen_prefill
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r3,##1024)
		r3 = r0
		allocframe(#112)
	}
	{
		r0 = #0
		if (p0) r19 = #127
		memd(r29+#104) = r17:16
		memd(r29+#96) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (!p0) jump:nt .LBB1_5
		memd(r29+#88) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB1_5
	}
// %bb.2:                               // %lor.lhs.false5
	{
		r19 = memw(r3+#0)
		if (!cmp.gtu(r19.new,r19)) jump:nt .LBB1_5
	}
// %bb.3:                               // %lor.lhs.false5
	{
		r5 = and(r19,#127)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB1_5
	}
// %bb.4:                               // %lor.lhs.false10
	{
		r5 = memw(r3+#4)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB1_6
	}
	.falign
.LBB1_5:                                // %return
	{
		r17:16 = memd(r29+#104)
		r19:18 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#88)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB1_6:                                // %lor.lhs.false12
	{
		r5 = memw(r3+#8)
		if (!cmp.eq(r5.new,r19)) jump:t .LBB1_5
	}
// %bb.7:                               // %lor.lhs.false15
	{
		r5 = #32
	}
	{
		r5 = memw(r3+#12)
		if (!cmp.eq(r5.new,r5)) jump:t .LBB1_5
	}
// %bb.8:                               // %lor.lhs.false17
	{
		r5 = memw(r3+#16)
		if (!cmp.eq(r5.new,#8)) jump:t .LBB1_5
	}
// %bb.9:                               // %lor.lhs.false19
	{
		r5 = #64
	}
	{
		r5 = memw(r3+#20)
		if (!cmp.eq(r5.new,r5)) jump:t .LBB1_5
	}
// %bb.10:                              // %lor.lhs.false21
	{
		r5 = memw(r3+#24)
		if (!cmp.eq(r5.new,#0)) jump:t .LBB1_5
	}
// %bb.11:                              // %lor.lhs.false23
	{
		r5 = memw(r3+#28)
	}
	{
		p0 = sfcmp.uo(r5,r0)
		p1 = sfcmp.eq(r5,r0)
	}
	{
		p0 = and(p1,!p0)
		if (p0.new) r6 = #-128
		if (!p0.new) jump:t .LBB1_5
		if (p0.new) r5 = memw(r1+#0)
	}
// %bb.12:                              // %lor.lhs.false25
	{
		r5 = add(r5,#-129)
		if (cmp.gtu(r6,r5.new)) jump:t .LBB1_5
	}
// %bb.13:                              // %lor.lhs.false30
	{
		r5 = #256
	}
	{
		r5 = memw(r1+#4)
		if (cmp.eq(r5.new,r5)) jump:nt .LBB1_15
	}
// %bb.14:                              // %lor.lhs.false30
	{
		p1 = cmp.eq(r5,#128)
		if (!p1.new) jump:nt .LBB1_5
	}
	.falign
.LBB1_15:                               // %if.end
	{
		r6 = r1
		r17:16 = combine(r3,r2)
		r0 = memw(r1+#12)
		memw(r29+#16) = r0.new
	}
	{
		r0 = add(r29,#4)
		r20 = r4
		r2 = memw(r6+#8)
		memw(r29+#12) = r2.new
	}
	{
		r1:0 = combine(r0,r3)
		r2 = memw(r6+#4)
		memw(r29+#8) = r2.new
	}
	{
		call hexkl_attn_q_tiling_init
		memw(r29+#4) = ##128
	}
	.falign
// %bb.16:                              // %if.end
	{
		r0 = #0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:t .LBB1_5
		if (p0.new) r2 = memw(r29+#16)
	}
// %bb.17:                              // %if.end37
	{
		r0 = ##1572864
		r1 = r2
	}
	{
		r1 = and(##-4096,asl(r1,#6))
	}
	{
		r1 += asl(r2,#8)
		call __hexagon_udivsi3
	}
	.falign
// %bb.18:                              // %if.end37
	{
		r18 = r0
		r1 = memw(r29+#4)
	}
	{
		r0 = add(r19,add(r1,#-1))
		call __hexagon_udivsi3
	}
	.falign
// %bb.19:                              // %if.end37
	{
		r3 = minu(r18,r0)
		r1 = add(r29,#4)
		r2 = #1
		r5 = add(r29,#20)
	}
	{
		r4 = maxu(r3,r2)
		r3 = #1024
		r0 = r17
		r2 = r16
	}
	{
		call hexkl_attn_q_plan
	}
	.falign
// %bb.20:                              // %if.end37
	{
		r0 = #0
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB1_5
	}
// %bb.21:                              // %if.end56
	{
		r0 = #1
		r2 = memw(r29+#16)
		memw(r20+#12) = r2.new
	}
	{
		r2 = memw(r29+#12)
		memw(r20+#8) = r2.new
	}
	{
		r2 = memw(r29+#8)
		memw(r20+#4) = r2.new
	}
	{
		r2 = memw(r29+#4)
		memw(r20+#0) = r2.new
	}
	{
		r17:16 = memd(r29+#104)
		r19:18 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#88)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end1:
	.size	hexkl_attn_q_widen_prefill, .Lfunc_end1-hexkl_attn_q_widen_prefill
                                        // -- End function
	.falign
	.type	hexkl_attn_q_plan,@function     // -- Begin function hexkl_attn_q_plan
hexkl_attn_q_plan:                      // @hexkl_attn_q_plan
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB2_7
		r6 = r0
		r0 = #-1
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r5,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB2_2:                                // %lor.lhs.false4
	{
		r12 = memw(r1+#12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB2_7
	}
// %bb.3:                               // %lor.lhs.false4
	{
		r9:8 = bitsplit(r12,#6)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (!p1.new) jumpr:nt r31
	}
.LBB2_4:                                // %lor.lhs.false8
	{
		p0 = cmp.eq(r3,##512)
		p1 = cmp.eq(r3,##1024)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = and(p0,!p1)
		if (p1.new) jumpr:nt r31
	}
.LBB2_5:                                // %lor.lhs.false8
	{
		r14 = mpyi(r4,r9)
		r7 = #2047
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB2_7
	}
// %bb.6:                               // %if.end
	{
		r8 = memw(r1+#4)
		r13 = memw(r6+#20)
	}
	{
		r15 = lsr(r8,#5)
		r8 = lsr(r13,#5)
		r13 = #2047
		memw(r5+#52) = r15.new
	}
	{
		r28 = mpyi(r15,r3)
		r14 = mpyi(r14,r8)
		memw(r5+#48) = r9
		memw(r5+#56) = r8
	}
	{
		r12 = mpyi(r12,r15)
		r14 = asl(r14,#11)
		memw(r5+#4) = r14.new
	}
	{
		r28 = add(r7,mpyi(r28,r8))
		memw(r5+#60) = r4
		memw(r5+#64) = r3
	}
	{
		r28 = insert(r14,#11,#0)
		memw(r5+#0) = #0
	}
	{
		r14 = add(r14,r28)
		memw(r5+#8) = r14.new
	}
	{
		r14 = add(r14,r28)
		memw(r5+#12) = r14.new
	}
	{
		r14 = add(r14,r28)
		memw(r5+#16) = r14.new
	}
	{
		r14 = add(r14,r28)
		memw(r5+#20) = r14.new
	}
	{
		r28 = add(r14,#8192)
		memw(r5+#24) = r28.new
	}
	{
		r10 = addasl(r28,r12,#6)
		memw(r5+#28) = r10.new
	}
	{
		r1 = memw(r1+#12)
		r6 = memw(r6+#20)
	}
	{
		r11 = mpyi(r4,r1)
		r1 = mpyi(r6,r1)
	}
	{
		r13 += asl(r1,#2)
	}
	{
		r6 = mpyi(r11,r6)
		r11 = addasl(r10,r12,#6)
		memw(r5+#32) = r11.new
	}
	{
		r7 += asl(r6,#2)
		r13 = insert(r28,#11,#0)
	}
	{
		r6 = addasl(r11,r12,#5)
		r7 = insert(r13,#11,#0)
		memw(r5+#36) = r6.new
	}
	{
		r15 = add(r13,r6)
		memw(r5+#40) = r15.new
	}
	{
		r7 = add(r15,r7)
		memw(r5+#44) = r7.new
	}
	{
		p1 = cmp.gtu(r7,r2)
	}
	{
		r0 = mux(p1,#-2,#0)
	}
	.falign
.LBB2_7:                                // %return
	{
		jumpr r31
	}
.Lfunc_end2:
	.size	hexkl_attn_q_plan, .Lfunc_end2-hexkl_attn_q_plan
                                        // -- End function
	.falign
	.type	phase_qprep,@function           // -- Begin function phase_qprep
phase_qprep:                            // @phase_qprep
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r3,#0)
		allocframe(r29,#512):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
		r5:4 = memd(r0+#8)
	}
	{
		if (!p0) r3 = #0
		memw(r29+#252) = r2
		memw(r29+#248) = r3
	}                                       // 4-byte Folded Spill
	{
		r16 = r0
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r23 = memw(r5+#12)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r4+#20)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-40) = r25:24
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB3_15
		memw(r29+#240) = r1
		memw(r29+#236) = r2
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %for.cond2.preheader.lr.ph
	{
		p1 = cmp.eq(r23,#0); if (p1.new) jump:nt .LBB3_15
		if (!p1.new) r24 = memw(r16+#84)
	}
// %bb.2:
	{
		p0 = cmp.eq(r24,#0)
		v2 = vxor(v2,v2)
		vmem(r29+#2) = v2.new
	}                                       // 128-byte Folded Spill
	{
		r2 = p0
		memw(r29+#232) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB3_3:                                // %for.cond2.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB3_4 Depth 2
                                        //       Child Loop BB3_12 Depth 3
                                        //       Child Loop BB3_9 Depth 3
	{
		r26 = mpyi(r3,r23)
		r21 = #0
		r2 = memw(r29+#252)
		memw(r29+#244) = r3
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r3,r2)
	}
	.falign
.LBB3_4:                                // %for.body5.us
                                        //   Parent Loop BB3_3 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB3_12 Depth 3
                                        //       Child Loop BB3_9 Depth 3
	{
		r2 = add(r21,r26)
		r19:18 = memd(r16+#8)
		r17 = memw(r16+#0)
	}
	{
		r20 = memw(r16+#68)
	}
	{
		r22 = memw(r19+#8)
		r3 = memw(r18+#20)
	}
	{
		r1:0 = combine(r22,r21)
		r19 = memw(r19+#0)
	}
	{
		r25 = mpyi(r3,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.5:                               // %for.body5.us
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		r2 = mpyi(r22,r19)
		r3 = add(r17,r20)
	}
	{
		r2 = addasl(r3,r25,#2)
		if (p0.new) r3 = add(r0,#0)
		p0 = cmp.gtu(r2,r21); if (!p0.new) jump:t .LBB3_10
	}
// %bb.6:                               // %lor.lhs.false.i.us
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		r4 = memw(r18+#0)
	}
	{
		r3 += mpyi(r19,r27)
		if (!cmp.gtu(r4,r3.new)) jump:t .LBB3_10
	}
// %bb.7:                               // %if.end.i.us
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		r4 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p1 = r4
		if (!p1.new) r5 = add(r21,#0)
		if (p1.new) jump:nt .LBB3_13
		if (!p1.new) r4 = memw(r16+#16)
	}
// %bb.8:                               // %for.body23.us.preheader
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		loop0(.LBB3_9,r24)
		r7 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r5 -= mpyi(r0,r22)
	}
	{
		r5 += mpyi(r22,r7)
		r6 = memw(r4+#4)
		r4 = memw(r4+#0)
	}
	{
		r3 = mpyi(r6,r3)
		r6 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r4,r3,#2)
	}
	{
		r5 = mpyi(r5,r6)
	}
	{
		r3 = addasl(r3,r5,#2)
	}
	.falign
.LBB3_9:                                // Block address taken
                                        // %for.body23.us
                                        //   Parent Loop BB3_3 Depth=1
                                        //     Parent Loop BB3_4 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0 = vmemu(r3++#1)
	}
	{
		nop
		vmem(r2++#1) = v0
	} :endloop0
	{
		jump .LBB3_13
	}
	.falign
.LBB3_10:                               // %hexkl_attn_f16_tile_row_to_qg.exit.us
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		loop0(.LBB3_12,r24)
		r3 = memw(r29+#232)
		v2 = vmem(r29+#2)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB3_13
	}
	.falign
.LBB3_12:                               // Block address taken
                                        // %for.body31.us
                                        //   Parent Loop BB3_3 Depth=1
                                        //     Parent Loop BB3_4 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		nop
		vmem(r2++#1) = v2
	} :endloop0
	.falign
.LBB3_13:                               // %if.end.us
                                        //   in Loop: Header=BB3_4 Depth=2
	{
		r21 = add(r21,#1)
		if (!cmp.eq(r21.new,r23)) jump:t .LBB3_4
	}
// %bb.14:                              // %for.cond2.for.cond.cleanup4_crit_edge.us
                                        //   in Loop: Header=BB3_3 Depth=1
	{
		r3 = memw(r29+#244)
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		if (!cmp.eq(r3.new,r2)) jump:t .LBB3_3
	}
	.falign
.LBB3_15:                               // %for.cond.cleanup
	{
		r2 = memw(r16+#20)
	}
	{
		r3 = memb(r2+#4)
	}
	{
		p0 = cmp.eq(r3,#0)
		r3 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r18 = mpyi(r23,r3)
		if (p0) r3 = #32
		if (!p0) jump:nt .LBB3_25
	}
// %bb.16:                              // %land.lhs.true
	{
		r2 = memw(r2+#72)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB3_25
	}
// %bb.17:                              // %land.lhs.true46
	{
		r2 = memw(r16+#8)
	}
	{
		r3 = memw(r2+#12)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB3_25
	}
// %bb.18:                              // %land.lhs.true50
	{
		r3 = memw(r2+#16)
		if (!cmp.eq(r3.new,#8)) jump:nt .LBB3_25
	}
// %bb.19:                              // %land.lhs.true50
	{
		r3 = #64
	}
	{
		r3 = memw(r29+#236)
		if (!cmp.eq(r3.new,r3)) jump:nt .LBB3_25
	}                                       // 4-byte Folded Reload
// %bb.20:                              // %land.lhs.true57
	{
		r3 = #127
	}
	{
		r3 = memw(r2+#0)
		if (!cmp.gtu(r3.new,r3)) jump:nt .LBB3_25
	}
// %bb.21:                              // %land.lhs.true57
	{
		r4 = and(r3,#127)
		if (!cmp.eq(r4.new,#0)) jump:nt .LBB3_25
	}
// %bb.22:                              // %land.lhs.true66
	{
		r4 = memw(r2+#4)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB3_25
	}
// %bb.23:                              // %land.lhs.true70
	{
		r4 = memw(r2+#8)
		if (!cmp.eq(r4.new,r3)) jump:t .LBB3_25
	}
// %bb.24:                              // %land.lhs.true76
	{
		r3 = memw(r2+#24)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB3_29
	}
	.falign
.LBB3_25:                               // %if.else101
	{
		r1 = r18
		r2 = memw(r16+#0)
		r17 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r16+#68)
		r5:4 = memd(r16+#104)
	}
	{
		r0 = add(r2,r3)
		r2 = memw(r16+#24)
		memw(r29+#0) = r2.new
	}
	{
		call hvx_quant_rows_u8_params
		r3:2 = combine(r17,r18)
	}
	.falign
// %bb.26:                              // %if.else101
	{
		r1 = r18
		r2 = memw(r16+#0)
		r7:6 = memd(r16+#24)
	}
	{
		r3 = memw(r16+#68)
		r5:4 = memd(r16+#104)
	}
	{
		r0 = add(r2,r3)
		r2 = add(r2,r7)
		memw(r29+#0) = r2.new
	}
	{
		call hvx_quant_pack_u8_ah
		r3:2 = combine(r17,r18)
		memw(r29+#4) = r6
	}
	.falign
// %bb.27:                              // %if.else101
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB3_35
	}
	.falign
.LBB3_28:                               // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB3_29:                               // %land.lhs.true80
	{
		r3 = #0
		r2 = memw(r2+#28)
	}
	{
		p0 = sfcmp.uo(r2,r3)
		p1 = sfcmp.eq(r2,r3)
	}
	{
		p0 = and(p1,!p0)
		if (!p0.new) jump:nt .LBB3_25
		if (p0.new) r1:0 = memd(r16+#104)
	}
// %bb.30:                              // %for.cond86.preheader
	{
		if (!p1.new) r2 = ##1065353216
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB3_33
	}
// %bb.31:
	{
		loop0(.LBB3_32,r18)
		r5:4 = combine(r1,r0)
	}
	.falign
.LBB3_32:                               // Block address taken
                                        // %for.body90
                                        // =>This Inner Loop Header: Depth=1
	{
		memw(r4++#4) = r2
		memw(r5++#4) = r3
	} :endloop0
	.falign
.LBB3_33:                               // %for.cond.cleanup89
	{
		r2 = memw(r16+#0)
		r5:4 = memd(r16+#24)
	}
	{
		r3 = memw(r16+#68)
		memw(r29+#16) = r0

	} :mem_noshuf
	{
		r0 = add(r2,r3)
		r2 = add(r2,r5)
		memw(r29+#20) = r1
		memw(r29+#28) = r4
	}
	{
		r3:2 = combine(#0,#0)
		r5:4 = combine(r18,r18)
		r1 = #0
		memw(r29+#24) = r2
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_params_pack_u8_ah
		memw(r29+#4) = #0
		memw(r29+#0) = #64
	}
	.falign
// %bb.34:                              // %for.cond.cleanup89
	{
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:t .LBB3_28
	}
	.falign
.LBB3_35:                               // %for.cond118.preheader
	{
		r5 = lsr(r18,#1)
		r0 = #0
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB3_28
	}
// %bb.36:                              // %for.body122.lr.ph
	{
		loop0(.LBB3_38,r5)
		r3 = and(r18,#1)
		p0 = cmp.gtu(r5,#0)
		r4 = memw(r16+#104)
	}
	{
		r2 = r4
		if (!p0) jump:nt .LBB3_39
	}
	.falign
.LBB3_38:                               // =>This Inner Loop Header: Depth=1
	{
		r6 = memw(r4+#0)
		r5 = memw(r16+#100)
	}
	{
		r7 = memw(r4+#4)
	}
	{
		r5 = sfmpy(r5,r6)
		memw(r2++#8) = r5.new
	}
	{
		r5 = memw(r16+#100)
	}
	{
		r5 = sfmpy(r5,r7)
		r4 = r2
		memw(r4+#4) = r5.new
	} :endloop0
	.falign
.LBB3_39:
	{
		p1 = cmp.gtu(r3,#0); if (!p1.new) jump:t .LBB3_28
		if (p1.new) r4 = memw(r16+#100)
		if (p1.new) r3 = memw(r2+#0)
	}
	.falign
.LBB3_40:                               // Block address taken
                                        // %for.body122
	{
		r3 = sfmpy(r4,r3)
		jump .LBB3_28
		memw(r2++#4) = r3.new
	}
.Lfunc_end3:
	.size	phase_qprep, .Lfunc_end3-phase_qprep
                                        // -- End function
	.falign
	.type	hexkl_attn_q_tiling_init,@function // -- Begin function hexkl_attn_q_tiling_init
hexkl_attn_q_tiling_init:               // @hexkl_attn_q_tiling_init
// %bb.0:                               // %entry
	{
		r16 = r0
		p0 = cmp.eq(r1,#0)
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r0 = #-1
		if (p0) jump:nt .LBB4_9
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %lor.lhs.false2.i
	{
		r3 = #511
		r19 = memw(r16+#0)
		if (cmp.eq(r19.new,#0)) jump:nt .LBB4_9
	}
// %bb.2:                               // %lor.lhs.false3.i
	{
		r17 = memw(r16+#12)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB4_9
	}
// %bb.3:                               // %lor.lhs.false5.i
	{
		r18 = memw(r16+#16)
		if (cmp.eq(r18.new,#0)) jump:nt .LBB4_9
	}
// %bb.4:                               // %lor.lhs.false7.i
	{
		r2 = memw(r16+#20)
	}
	{
		r3 = add(r2,#-1)
		if (cmp.gtu(r3.new,r3)) jump:nt .LBB4_9
	}
// %bb.5:                               // %lor.lhs.false7.i
	{
		r20 = r1
		r2 = and(r2,#31)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB4_9
	}
// %bb.6:                               // %lor.lhs.false15.i
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.7:                               // %lor.lhs.false15.i
	{
		r17 -= mpyi(r0,r18)
		r3 = r0
		if (cmp.eq(r17.new,#0)) jump:nt .LBB4_10
	}
// %bb.8:
	{
		r0 = #-1
	}
	.falign
.LBB4_9:                                // %hexkl_attn_f16_tiling_init_aligned.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB4_10:                               // %lor.lhs.false20.i
	{
		r0 = #-1
		r2 = memw(r16+#4)
		r4 = memw(r16+#8)
	}
	{
		r2 = add(r2,r19)
		if (cmp.gtu(r2.new,r4)) jump:t .LBB4_9
	}
// %bb.11:                              // %if.end.i
	{
		r2 = r20
		r4 = memw(r20+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB4_9
	}
// %bb.12:                              // %lor.lhs.false26.i
	{
		r5 = memw(r20+#4)
	}
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB4_9
	}
// %bb.13:                              // %lor.lhs.false26.i
	{
		r4 = add(#63,mpyi(r3,r4))
		r5 = and(r5,#31)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB4_9
	}
// %bb.14:                              // %if.end33.i
	{
		r0 = #0
		memw(r2+#8) = r3
	}
	{
		r3 = and(r4,#-64)
		r17:16 = memd(r29+#16)
		memw(r2+#12) = r3.new
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#8)
		r21:20 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end4:
	.size	hexkl_attn_q_tiling_init, .Lfunc_end4-hexkl_attn_q_tiling_init
                                        // -- End function
	.falign
	.type	phase_qk,@function              // -- Begin function phase_qk
phase_qk:                               // @phase_qk
// %bb.0:                               // %entry
	{
		allocframe(r29,#512):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
		r6 = memw(r0+#76)
	}
	{
		p1 = cmp.eq(r6,#0)
		memw(r29+#208) = r2
		memw(r29+#228) = r1
	}                                       // 4-byte Folded Spill
	{
		if (!p1) r16 = add(r0,#0)
		if (p1) r0 = #0
		memd(r30+#-8) = r17:16
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB5_31
		memd(r30+#-40) = r25:24
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %for.cond4.preheader.lr.ph
	{
		r2 = memw(r0+#80)
	}
	{
		r2 = #0
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB5_30
		memw(r29+#144) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.2:
	{
		r3 = asl(r3,#2)
		p1 = cmp.eq(r5,#0)
		r2 = #1
		r7 = memw(r16+#20)
	}
	{
		r21 = add(r16,add(r3,##32))
		r3 = p1
		r17 = #10
	}
	{
		r24 = #31
		r20 = ##-1431622999
		r23 = #0
	}
	{
		r25 = #384
		r26 = #896
		r27 = #0
		memw(r29+#104) = r3
	}                                       // 4-byte Folded Spill
	{
		r13 = #20
		r12 = #24
		r0 = #8
		r3 = memub(r7+#4)
	}
	{
		r14 = #16
		r15 = #12
		r1 = #4
		p0 = cmp.eq(r3,#1)
	}
	{
		r8 = #28
		r10 = #156
		memw(r29+#152) = r12
		memw(r29+#156) = r13
	}                                       // 4-byte Folded Spill
	{
		r11 = #152
		r12 = #148
		memw(r29+#160) = r14
		memw(r29+#164) = r15
	}                                       // 4-byte Folded Spill
	{
		r13 = #144
		r14 = #140
		memw(r29+#168) = r0
		memw(r29+#172) = r1
	}                                       // 4-byte Folded Spill
	{
		r15 = #136
		r0 = #132
		r1 = #128
	}
	{
		r4 = addasl(r16,r4,#2)
		v0 = vxor(v0,v0)
		vmem(r29+#2) = v0.new
	}                                       // 128-byte Folded Spill
	{
		r3 = p0
		memw(r29+#148) = r8
		memw(r29+#176) = r10
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#180) = r11
		memw(r29+#184) = r12
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#188) = r13
		memw(r29+#192) = r14
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#196) = r15
		memw(r29+#200) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#204) = r1
		memw(r29+#116) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#112) = r3
		memw(r29+#224) = r21
	}                                       // 4-byte Folded Spill
	.falign
.LBB5_3:                                // %for.cond4.preheader
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_5 Depth 2
                                        //       Child Loop BB5_10 Depth 3
                                        //       Child Loop BB5_8 Depth 3
                                        //       Child Loop BB5_21 Depth 3
                                        //       Child Loop BB5_23 Depth 3
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB5_27
		r22 = #0
		r2 = r23
	}
// %bb.4:                               // %for.body9.lr.ph
                                        //   in Loop: Header=BB5_3 Depth=1
	{
		r2 = asl(r27,#1)
		memw(r29+#216) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = setbit(r2,#0)
		memw(r29+#212) = r27
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#220) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB5_5:                                // %for.body9
                                        //   Parent Loop BB5_3 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB5_10 Depth 3
                                        //       Child Loop BB5_8 Depth 3
                                        //       Child Loop BB5_21 Depth 3
                                        //       Child Loop BB5_23 Depth 3
	//# InlineAsm Start
	{
		r19:18 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.6:                               // %for.body9
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r2 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r2 = #0
		if (!p1.new) jump:t .LBB5_9
	}
// %bb.7:                               // %for.cond10.preheader
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r2 = #0
		r3 = memw(r16+#84)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB5_11
	}
	.falign
.LBB5_8:                                // %for.body15
                                        //   Parent Loop BB5_3 Depth=1
                                        //     Parent Loop BB5_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = r27
		r4 = r2
		r5 = memw(r16+#644)
		r6 = memw(r16+#76)
	}
	{
		r4 += mpyi(r22,r3)
		r8 = r2
		r12 = memw(r16+#28)
		r9 = memw(r16+#0)
	}
	{
		r7 += mpyi(r6,r5)
		r1 = memw(r21+#0)
		r0 = memw(r16+#92)
	}
	{
		r5 = add(r9,r1)
	}
	{
		r8 += mpyi(r3,r7)
		r5 += mpyi(r0,r4)
		r3 = add(r9,r12)
	}
	{
		r3 += asl(r8,#11)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r24):cm
		weight.n = mxmem(r5,r25)
	}

	//# InlineAsm End
	{
		r2 = add(r2,#1)
	}
	{
		r3 = memw(r16+#84)
		if (cmp.gtu(r3.new,r2)) jump:t .LBB5_8
	}
	{
		jump .LBB5_11
	}
	.falign
.LBB5_9:                                // %for.cond19.preheader
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r3 = memw(r16+#84)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB5_11
	}
	.falign
.LBB5_10:                               // %for.body25
                                        //   Parent Loop BB5_3 Depth=1
                                        //     Parent Loop BB5_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = r27
		r4 = r2
		r5 = memw(r16+#644)
		r6 = memw(r16+#76)
	}
	{
		r4 += mpyi(r22,r3)
		r8 = r2
		r12 = memw(r16+#28)
		r9 = memw(r16+#0)
	}
	{
		r7 += mpyi(r6,r5)
		r1 = memw(r21+#0)
		r0 = memw(r16+#92)
	}
	{
		r5 = add(r9,r1)
	}
	{
		r8 += mpyi(r3,r7)
		r5 += mpyi(r0,r4)
		r3 = add(r9,r12)
	}
	{
		r3 += asl(r8,#11)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r24):cm
		weight.b = mxmem(r5,r26)
	}

	//# InlineAsm End
	{
		r2 = add(r2,#1)
	}
	{
		r3 = memw(r16+#84)
		if (cmp.gtu(r3.new,r2)) jump:t .LBB5_10
	}
	.falign
.LBB5_11:                               // %if.end
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = add(r22,#0)
		if (p1.new) jump:nt .LBB5_14
		if (!p1.new) r3 = memw(r16+#80)
	}
// %bb.12:                              // %cond.true
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r4 += mpyi(r3,r27)
		r2 = memw(r16+#68)
		r1:0 = memd(r16+#0)
	}
	{
		r2 += asl(r4,#13)
		call hexkl_micro_hmx_acc_read_int32
	}
	.falign
// %bb.13:                              // %cond.true
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:t .LBB5_16
	}
	{
		jump .LBB5_31
	}
	.falign
.LBB5_14:                               // %cond.false
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		call hexkl_micro_hmx_acc_read_int32
		r2 = memw(r16+#48)
		r1:0 = memd(r16+#0)
	}
	.falign
// %bb.15:                              // %cond.false
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB5_31
	}
	.falign
.LBB5_16:                               // %if.end43
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r1:0 = mpyu(r18,r17)
		r15 = add(r20,#-32766)
		r14 = add(r20,#-32767)
		memw(r29+#100) = r22
	}                                       // 4-byte Folded Spill
	{
		r1 += mpyi(r19,#10)
	}
	{
		r5:4 = mpyu(r0,r15)
		r3:2 = mpyu(r0,r14)
	}
	{
		r22 = r5
	}
	{
		r5:4 = combine(r23,r22)
		r22 = r2
	}
	{
		r5:4 += mpyu(r1,r15)
	}
	{
		r5:4 = add(r5:4,r23:22)
	}
	{
		r22 = r5
	}
	{
		r5:4 = combine(r23,r22)
		r22 = r3
	}
	{
		r5:4 += mpyu(r1,r14)
	}
	{
		r1:0 = add(r5:4,r23:22)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = mpyu(r2,r17)
		r2 = memw(r16+#672)
	}
	{
		r5 += mpyi(r3,#10)
	}
	{
		r9:8 = mpyu(r4,r15)
		r13:12 = mpyu(r4,r14)
		r7:6 = memd(r2+#16)
	}
	{
		r22 = r9
	}
	{
		r9:8 = combine(r23,r22)
		r22 = r12
	}
	{
		r9:8 += mpyu(r5,r15)
	}
	{
		r9:8 = add(r9:8,r23:22)
	}
	{
		r22 = r9
	}
	{
		r9:8 = combine(r23,r22)
		r22 = r13
	}
	{
		r9:8 += mpyu(r5,r14)
	}
	{
		r5:4 = add(r9:8,r23:22)
	}
	{
		r5:4 = lsr(r5:4,#7)
	}
	{
		r1:0 = sub(r5:4,r1:0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		r0 = memw(r29+#104)
		memd(r2+#16) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (!p0.new) jump:t .LBB5_25
		r2 = memw(r16+#12)
		if (p0.new) r8 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
// %bb.17:                              // %if.then47
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		memd(r29+#248) = r5:4
		memd(r29+#240) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r5 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#4)
		memw(r29+#120) = r14
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r16+#20)
		memw(r29+#124) = r15
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r3,r5)
	}
	{
		r3 = addasl(r3,r8,#5)
		r5 = memw(r4+#16)
	}
	{
		r6 = add(r3,#32)
		if (!cmp.gtu(r6.new,r5)) jump:t .LBB5_19
	}
// %bb.18:                              // %if.else.i
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		jump .LBB5_20
		v0 = v1
		v1.cur = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB5_19:                               // %if.then.i
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r7 = memw(r29+#228)
		r6 = memw(r4+#48)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r3,#2)
		r0 = memw(r4+#44)
	}
	{
		r5 = mpyi(r5,r7)
		r3 = addasl(r0,r3,#2)
	}
	{
		r6 = addasl(r6,r5,#2)
		r3 = addasl(r3,r5,#2)
	}
	{
		v6 = vmemu(r6+#0)
	}
	{
		v1 = vmemu(r3+#0)
	}
	{
		v0.sf = v6.w
	}
	.falign
.LBB5_20:                               // %if.end.i
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r4 = r8
		r3 = memw(r16+#0)
		r2 = memw(r2+#12)
	}
	{
		loop0(##.LBB5_21,#4)
		r10 = r3
		r5 = memw(r16+#96)
	}
	{
		r11 = r3
		r14 = memw(r16+#48)
		r6 = memw(r16+#644)
	}
	{
		r18 = r14
		r17 = r14
		r12 = memw(r29+#116)
		r8 = memw(r5+#8)
	}                                       // 4-byte Folded Reload
	{
		r8 = lsr(r8,#5)
		r5 = memw(r5+#12)
		memw(r29+#128) = r14
	}                                       // 4-byte Folded Spill
	{
		r5 = mpyi(r2,r6)
		r13 = lsr(r5,#5)
		r7 = memw(r16+#80)
		r2 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r9 = extractu(r13,#23,#0)
		r6 = extractu(r8,#25,#0)
		r27:26 = memd(r16+#104)
		memw(r29+#140) = r3
	}                                       // 4-byte Folded Spill
	{
		r4 += mpyi(r7,r2)
		r2 = r14
		r7 = r14
		r15 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r18 += asl(r9,#9)
		r14 = add(r3,r14)
		r9 = add(r26,r15)
		r12 = memw(r12+#52)
	}
	{
		r12 = addasl(r14,r8,#7)
		r21 = asl(r6,#7)
		r6 = add(r3,r12)
		r8 = add(r27,r15)
	}
	{
		r15 = addasl(r9,r5,#2)
		r28 = addasl(r8,r5,#2)
		r9 = memw(r29+#152)
		memw(r29+#132) = r21
	}                                       // 4-byte Folded Reload
	{
		r7 += mpyi(r13,##768)
		r8 = add(r26,r9)
		r9 = add(r27,r9)
	}
	{
		r6 += asl(r4,#11)
		r2 += mpyi(r13,##896)
		r4 = r3
	}
	{
		r1 = addasl(r8,r5,#2)
		r17 += mpyi(r13,##640)
		r8 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r2,r21)
		r10 += add(r7,r21)
		r2 = add(r26,r8)
		memd(r29+#232) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r0 = addasl(r9,r5,#2)
		r11 += add(r17,r21)
		r7 = add(r27,r8)
		r8 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r19 = addasl(r7,r5,#2)
		r7 = add(r26,r8)
		r17 = r3
		r9 = memw(r29+#164)
	}                                       // 4-byte Folded Reload
	{
		r14 = addasl(r7,r5,#2)
		r8 = add(r27,r8)
		r7 = add(r26,r9)
		r9 = add(r27,r9)
	}
	{
		r17 += add(r18,r21)
		r20 = addasl(r8,r5,#2)
		r18 = memw(r29+#168)
		r23 = memw(r29+#172)
	}                                       // 4-byte Folded Reload
	{
		r8 = addasl(r7,r5,#2)
		r21 = addasl(r9,r5,#2)
		r7 = add(r27,r18)
		r22 = add(r26,r23)
	}
	{
		r18 = addasl(r7,r5,#2)
		r22 = addasl(r22,r5,#2)
		r24 = add(r26,r18)
		memw(r29+#108) = r13
	}                                       // 4-byte Folded Spill
	{
		r7 = add(r27,r23)
		r23 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		r9 = addasl(r24,r5,#2)
		r24 = addasl(r7,r5,#2)
		r25 = add(r26,r23)
		r7 = add(r27,r23)
	}
	{
		r2 = addasl(r2,r5,#2)
		r25 = addasl(r25,r5,#2)
	}
	{
		r26 = addasl(r7,r5,#2)
		r27 = extractu(r13,#24,#0)
	}
	{
		r5 = extractu(r13,#22,#0)
		r3 = asl(r5,#2)
	}
	{
		r23 = extractu(r13,#25,#0)
		r7 = asl(r5,#10)
	}
	{
		r5 = asl(r27,#8)
		memw(r29+#88) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = asl(r23,#7)
		memw(r29+#92) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r5,#52)
		memw(r29+#136) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = +mpyi(r13,##384)
		memw(r29+#96) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = r12
	}
	.falign
.LBB5_21:                               // Block address taken
                                        // %for.body35.i
                                        //   Parent Loop BB5_3 Depth=1
                                        //     Parent Loop BB5_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r26 = add(r26,#32)
		r13 = memw(r26+#0)
		r23 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		v9 = vsplat(r13)
		r23 = add(r5,r23)
		r13 = memw(r24+#0)
		v8 = vmem(r5+#0)
	}
	{
		v10 = vsplat(r13)
		r18 = add(r18,#32)
		v5.sf = v8.w
		r13 = memw(r18+#0)
	}
	{
		v11 = vsplat(r13)
		r21 = add(r21,#32)
		v12.sf = v9.w
		r13 = memw(r21+#0)
	}
	{
		v13 = vsplat(r13)
		r24 = add(r24,#32)
		v14.sf = v10.w
		r13 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		v16.qf32 = vmpy(v12.sf,v0.sf)
		r13 = add(r5,r13)
		v15.sf = v11.w
		v19 = vmem(r23+#0)
	}
	{
		v18.qf32 = vmpy(v14.sf,v0.sf)
		v17.sf = v13.w
		r13 = memw(r29+#96)
		v22 = vmem(r13+#0)
	}                                       // 4-byte Folded Reload
	{
		v21.qf32 = vmpy(v15.sf,v0.sf)
		r13 = add(r5,r13)
		v24.sf = v16.qf32
		v20.sf = v19.w
	}
	{
		v25.qf32 = vmpy(v17.sf,v0.sf)
		v28.sf = v18.qf32
		r13 = memw(r25+#0)
		v4 = vmem(r13+#0)
	}
	{
		v30 = vsplat(r13)
		v23.sf = v22.w
		v26.sf = v21.qf32
		r23 = memw(r22+#0)
	}
	{
		v25 = vsplat(r23)
		v31.sf = v25.qf32
		v27.sf = v4.w
		r13 = memw(r9+#0)
	}
	{
		v2 = vsplat(r13)
		v29.qf32 = vsub(v5.sf,v24.sf)
		v3.qf32 = vsub(v23.sf,v26.sf)
		r23 = memw(r8+#0)
	}
	{
		v28 = vsplat(r23)
		r8 = add(r8,#32)
		v26.qf32 = vsub(v27.sf,v31.sf)
		v6.qf32 = vsub(v20.sf,v28.sf)
	}
	{
		r5 = add(r5,r7)
		r9 = add(r9,#32)
		v7.sf = v29.qf32
		v27.sf = v3.qf32
	}
	{
		r22 = add(r22,#32)
		r25 = add(r25,#32)
		v29.sf = v6.qf32
		v13.sf = v26.qf32
	}
	{
		v12.qf32 = vmpy(v7.sf,v30.sf)
	}
	{
		v14.qf32 = vmpy(v27.sf,v2.sf)
	}
	{
		v15.qf32 = vmpy(v29.sf,v25.sf)
		v16.sf = v12.qf32
	}
	{
		v17.qf32 = vmpy(v13.sf,v28.sf)
		v30.sf = v14.qf32
	}
	{
		v6.qf32 = vmpy(v16.sf,v1.sf)
		v31.sf = v15.qf32
	}
	{
		v12.qf32 = vmpy(v30.sf,v1.sf)
		v8.sf = v17.qf32
	}
	{
		v7.qf32 = vmpy(v31.sf,v1.sf)
	}
	{
		v13.qf32 = vmpy(v8.sf,v1.sf)
	}
	{
		v9.hf = v7:6.qf32
		vmem(r6+#0) = v9.new
	}
	{
		v10.hf = v13:12.qf32
		vmem(r6+#1) = v10.new
	}
	{
		r14 = add(r14,#32)
		r20 = add(r20,#32)
		r23 = memw(r14+#0)
		r13 = memw(r20+#0)
	}
	{
		v3 = vsplat(r23)
		v11 = vsplat(r13)
		r0 = add(r0,#32)
		r23 = memw(r0+#0)
	}
	{
		v13 = vsplat(r23)
		r19 = add(r19,#32)
		r13 = memw(r19+#0)
		r23 = memw(r28+#0)
	}
	{
		v12 = vsplat(r13)
		v23 = vsplat(r23)
		v18.sf = v11.w
		v19 = vmem(r17+#0)
	}
	{
		v24.sf = v13.w
		v20.sf = v19.w
		r13 = memw(r2+#0)
		v21 = vmem(r11+#0)
	}
	{
		v25.qf32 = vmpy(v18.sf,v0.sf)
		v22.sf = v12.w
		v2.sf = v23.w
		r23 = memw(r15+#0)
	}
	{
		v28.qf32 = vmpy(v24.sf,v0.sf)
		r15 = add(r15,#32)
		v29.sf = v21.w
		v30 = vmem(r10+#0)
	}
	{
		v26.qf32 = vmpy(v22.sf,v0.sf)
		r28 = add(r28,#32)
		v4.sf = v25.qf32
		v5 = vmem(r4+#0)
	}
	{
		v14.qf32 = vmpy(v2.sf,v0.sf)
		r4 = add(r4,r7)
		v31.sf = v30.w
		v15.sf = v28.qf32
	}
	{
		v10 = vsplat(r13)
		v16.sf = v26.qf32
		v6.sf = v5.w
		r13 = memw(r1+#0)
	}
	{
		v9 = vsplat(r13)
		v11 = vsplat(r23)
		v7.sf = v14.qf32
		v17.qf32 = vsub(v20.sf,v4.sf)
	}
	{
		r1 = add(r1,#32)
		r10 = add(r10,r7)
		v8.qf32 = vsub(v31.sf,v15.sf)
		v12.qf32 = vsub(v29.sf,v16.sf)
	}
	{
		r2 = add(r2,#32)
		r11 = add(r11,r7)
		v18.qf32 = vsub(v6.sf,v7.sf)
		v13.sf = v17.qf32
	}
	{
		r17 = add(r17,r7)
		v19.sf = v8.qf32
		v20.sf = v12.qf32
	}
	{
		v3.qf32 = vmpy(v13.sf,v3.sf)
		v23.sf = v18.qf32
	}
	{
		v24.qf32 = vmpy(v19.sf,v9.sf)
	}
	{
		v25.qf32 = vmpy(v20.sf,v10.sf)
		v27.sf = v3.qf32
	}
	{
		v26.qf32 = vmpy(v23.sf,v11.sf)
		v28.sf = v24.qf32
	}
	{
		v14.qf32 = vmpy(v27.sf,v1.sf)
		v29.sf = v25.qf32
	}
	{
		v16.qf32 = vmpy(v28.sf,v1.sf)
		v30.sf = v26.qf32
	}
	{
		v15.qf32 = vmpy(v29.sf,v1.sf)
	}
	{
		v17.qf32 = vmpy(v30.sf,v1.sf)
	}
	{
		v2.hf = v15:14.qf32
		vmem(r6+#2) = v2.new
	}
	{
		r6 = add(r6,#512)
		v31.hf = v17:16.qf32
		vmem(r6+#3) = v31.new
	} :endloop0
// %bb.22:                              // %for.cond.cleanup34.i
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r28 = r3
		r19 = r3
		r2 = memw(r29+#136)
		r4 = memw(r16+#0)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r3,r3)
		r6 = memw(r16+#80)
		r8 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		loop0(##.LBB5_23,#4)
		r2 = memw(r2+#0)
		r13 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		r15 = add(r4,r2)
		r2 = memw(r29+#220)
		r18 = memw(r29+#128)
	}                                       // 4-byte Folded Reload
	{
		r9 = r18
		r14 = r18
		r17 = r18
		r5 = r18
	}
	{
		r8 += mpyi(r6,r2)
		r9 += mpyi(r13,##4992)
		r2 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r26 = r2
		r11:10 = combine(r2,r3)
		r6 = r3
		r23:22 = memd(r29+#232)
	}                                       // 8-byte Folded Reload
	{
		r2 = +mpyi(r13,##4352)
		r25:24 = combine(r26,r3)
		memw(r29+#88) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r15 += asl(r8,#11)
		r21:20 = combine(r3,r26)
		r2 = memw(r29+#176)
		r8 = memw(r29+#184)
	}                                       // 4-byte Folded Reload
	{
		r17 += mpyi(r13,##4864)
		r14 += mpyi(r13,##4736)
	}
	{
		r5 += mpyi(r13,##4608)
		r4 = r26
	}
	{
		r18 += mpyi(r13,##4480)
		r13 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		r28 += add(r22,r2)
		r10 += add(r23,r2)
		r2 = memw(r29+#180)
	}                                       // 4-byte Folded Reload
	{
		r25 += add(r14,r13)
		r20 += add(r5,r13)
		r14 = r3
		r5 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r22,r2)
		r19 += add(r23,r2)
		r2 = r3
	}
	{
		r24 += add(r22,r8)
		r1 += add(r23,r8)
		r8 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r17,r13)
		r11 += add(r9,r13)
		r17 = r3
	}
	{
		r0 += add(r22,r8)
		r21 += add(r23,r8)
		r9:8 = combine(r3,r3)
	}
	{
		r2 += add(r22,r5)
		r14 += add(r23,r5)
		r5 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r26 += add(r18,r13)
		r17 += add(r22,r5)
		r18 = r3
	}
	{
		r8 += add(r23,r5)
		r13 = r26
		r5 = memw(r29+#200)
		r27:26 = memd(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r9 += add(r22,r5)
		r18 += add(r23,r5)
		r22 = r3
		r5 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		r22 += add(r26,r5)
		r27:26 = memd(r29+#232)
	}                                       // 8-byte Folded Reload
	{
		r3 += add(r27,r5)
		r27 = r13
		r5 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		r13 = extractu(r5,#20,#0)
	}
	{
		r5 = +mpyi(r5,##4224)
		r13 = asl(r13,#12)
		memw(r29+#92) = r5.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB5_23:                               // Block address taken
                                        // %for.body35.1.i
                                        //   Parent Loop BB5_3 Depth=1
                                        //     Parent Loop BB5_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r23 = add(r12,r13)
		r8 = add(r8,#32)
		r26 = memw(r3+#0)
		r5 = memw(r8+#0)
	}
	{
		v8 = vsplat(r26)
		v9 = vsplat(r5)
		r18 = add(r18,#32)
		r26 = memw(r18+#0)
	}
	{
		v10 = vsplat(r26)
		r14 = add(r14,#32)
		r5 = memw(r14+#0)
		v13 = vmem(r23+#0)
	}
	{
		v11 = vsplat(r5)
		v12.sf = v8.w
		v15.sf = v9.w
		r5 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r12,r5)
		v16.sf = v10.w
		r23 = memw(r29+#88)
		v7 = vmem(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		v17.qf32 = vmpy(v12.sf,v0.sf)
		r23 = add(r12,r23)
		v18.sf = v11.w
		v20 = vmem(r5+#0)
	}
	{
		v19.qf32 = vmpy(v15.sf,v0.sf)
		v2.sf = v7.w
		r5 = memw(r22+#0)
		v24 = vmem(r23+#0)
	}
	{
		v22.qf32 = vmpy(v16.sf,v0.sf)
		v14.sf = v13.w
		v23.sf = v17.qf32
		r23 = memw(r9+#0)
	}
	{
		v26.qf32 = vmpy(v18.sf,v0.sf)
		r27 = add(r27,r7)
		v21.sf = v20.w
		v25.sf = v24.w
	}
	{
		v30 = vsplat(r5)
		v4 = vsplat(r23)
		v27.sf = v19.qf32
		v28.sf = v22.qf32
	}
	{
		v31.sf = v26.qf32
		v29.qf32 = vsub(v14.sf,v23.sf)
		r17 = add(r17,#32)
		r5 = memw(r17+#0)
	}
	{
		v23 = vsplat(r5)
		v3.qf32 = vsub(v25.sf,v27.sf)
		v5.qf32 = vsub(v21.sf,v28.sf)
		r23 = memw(r2+#0)
	}
	{
		v9 = vsplat(r23)
		r2 = add(r2,#32)
		v2.qf32 = vsub(v2.sf,v31.sf)
		v6.sf = v29.qf32
	}
	{
		r12 = add(r12,r7)
		r9 = add(r9,#32)
		v8.sf = v3.qf32
		v10.sf = v5.qf32
	}
	{
		v11.qf32 = vmpy(v6.sf,v30.sf)
		v24.sf = v2.qf32
		r22 = add(r22,#32)
		r3 = add(r3,#32)
	}
	{
		v25.qf32 = vmpy(v8.sf,v23.sf)
	}
	{
		v26.qf32 = vmpy(v10.sf,v4.sf)
		v27.sf = v11.qf32
	}
	{
		v28.qf32 = vmpy(v24.sf,v9.sf)
		v29.sf = v25.qf32
	}
	{
		v2.qf32 = vmpy(v27.sf,v1.sf)
		v30.sf = v26.qf32
	}
	{
		v4.qf32 = vmpy(v29.sf,v1.sf)
		v31.sf = v28.qf32
	}
	{
		v3.qf32 = vmpy(v30.sf,v1.sf)
	}
	{
		v5.qf32 = vmpy(v31.sf,v1.sf)
	}
	{
		v12.hf = v3:2.qf32
		vmem(r15+#0) = v12.new
	}
	{
		v13.hf = v5:4.qf32
		vmem(r15+#1) = v13.new
	}
	{
		r0 = add(r0,#32)
		r21 = add(r21,#32)
		r23 = memw(r0+#0)
		r5 = memw(r21+#0)
	}
	{
		v4 = vsplat(r23)
		v14 = vsplat(r5)
		r19 = add(r19,#32)
		r23 = memw(r19+#0)
	}
	{
		v16 = vsplat(r23)
		r1 = add(r1,#32)
		r5 = memw(r1+#0)
		r23 = memw(r10+#0)
	}
	{
		v15 = vsplat(r5)
		v22 = vsplat(r23)
		v17.sf = v14.w
		v18 = vmem(r20+#0)
	}
	{
		v3.sf = v16.w
		v19.sf = v18.w
		r5 = memw(r24+#0)
		v20 = vmem(r25+#0)
	}
	{
		v23.qf32 = vmpy(v17.sf,v0.sf)
		v21.sf = v15.w
		v25.sf = v22.w
		r23 = memw(r28+#0)
	}
	{
		v2.qf32 = vmpy(v3.sf,v0.sf)
		r28 = add(r28,#32)
		v29.sf = v20.w
		v8 = vmem(r4+#0)
	}
	{
		v24.qf32 = vmpy(v21.sf,v0.sf)
		r10 = add(r10,#32)
		v11.sf = v23.qf32
		v26 = vmem(r11+#0)
	}
	{
		v28.qf32 = vmpy(v25.sf,v0.sf)
		r11 = add(r11,r7)
		v10.sf = v8.w
		v30.sf = v2.qf32
	}
	{
		v9 = vsplat(r5)
		v31.sf = v24.qf32
		v6.sf = v26.w
		r5 = memw(r6+#0)
	}
	{
		v13 = vsplat(r5)
		v14 = vsplat(r23)
		v7.sf = v28.qf32
		v5.qf32 = vsub(v19.sf,v11.sf)
	}
	{
		v12.qf32 = vsub(v10.sf,v30.sf)
		v15.qf32 = vsub(v29.sf,v31.sf)
		r6 = add(r6,#32)
		r4 = add(r4,r7)
	}
	{
		r24 = add(r24,#32)
		r25 = add(r25,r7)
		v18.qf32 = vsub(v6.sf,v7.sf)
		v16.sf = v5.qf32
	}
	{
		r20 = add(r20,r7)
		v19.sf = v12.qf32
		v22.sf = v15.qf32
	}
	{
		v4.qf32 = vmpy(v16.sf,v4.sf)
		v23.sf = v18.qf32
	}
	{
		v24.qf32 = vmpy(v19.sf,v13.sf)
	}
	{
		v25.qf32 = vmpy(v22.sf,v9.sf)
		v27.sf = v4.qf32
	}
	{
		v26.qf32 = vmpy(v23.sf,v14.sf)
		v3.sf = v24.qf32
	}
	{
		v8.qf32 = vmpy(v27.sf,v1.sf)
		v29.sf = v25.qf32
	}
	{
		v10.qf32 = vmpy(v3.sf,v1.sf)
		v30.sf = v26.qf32
	}
	{
		v9.qf32 = vmpy(v29.sf,v1.sf)
	}
	{
		v11.qf32 = vmpy(v30.sf,v1.sf)
	}
	{
		v31.hf = v9:8.qf32
		vmem(r15+#2) = v31.new
	}
	{
		r15 = add(r15,#512)
		v2.hf = v11:10.qf32
		vmem(r15+#3) = v2.new
	} :endloop0
// %bb.24:                              // %dequant_s_at.exit
                                        //   in Loop: Header=BB5_5 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r17 = #10
		r20 = ##-1431622999
		r12 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = mpyu(r0,r17)
		r24 = #31
		r5 = memw(r29+#120)
		r23:22 = memd(r29+#240)
	}                                       // 8-byte Folded Reload
	{
		r3 += mpyi(r1,#10)
		r25 = #384
		r4 = memw(r16+#672)
		r21 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = mpyu(r2,r12)
		r9:8 = mpyu(r2,r5)
		r26 = #896
		r27 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r22 = r7
		r1:0 = memd(r4+#24)
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r8
	}
	{
		r7:6 += mpyu(r3,r12)
	}
	{
		r7:6 = add(r7:6,r23:22)
	}
	{
		r22 = r7
	}
	{
		r7:6 = combine(r23,r22)
		r22 = r9
	}
	{
		r7:6 += mpyu(r3,r5)
	}
	{
		r3:2 = add(r7:6,r23:22)
		r7:6 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r3:2 = sub(r3:2,r7:6)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#24) = r1:0
	}
	.falign
.LBB5_25:                               // %for.inc55
                                        //   in Loop: Header=BB5_5 Depth=2
	{
		r22 = memw(r29+#100)
		r2 = memw(r16+#80)
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r22,#1)
		if (cmp.gtu(r2,r22.new)) jump:t ##.LBB5_5
	}
// %bb.26:                              // %for.inc60.loopexit
                                        //   in Loop: Header=BB5_3 Depth=1
	{
		r6 = memw(r16+#76)
	}
	.falign
.LBB5_27:                               // %for.inc60
                                        //   in Loop: Header=BB5_3 Depth=1
	{
		r27 = add(r27,#1)
		r3 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		p0 = cmp.gtu(r6,r27)
		if (!p0.new) r0 = #0
		memw(r29+#148) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#152) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#156) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#160) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#164)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#164) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#168)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#168) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#172)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#172) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#144) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#176)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#176) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#180)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#180) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#184)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#184) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#188)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#188) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#192) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#196) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#256)
		memw(r29+#200) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB5_3
		jump .LBB5_31
		r3 = add(r3,#256)
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.28:
	.falign
.LBB5_30:
	{
		r0 = #0
	}
	.falign
.LBB5_31:                               // %cleanup65
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end5:
	.size	phase_qk, .Lfunc_end5-phase_qk
                                        // -- End function
	.falign
	.type	dequant_worker,@function        // -- Begin function dequant_worker
dequant_worker:                         // @dequant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#384):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = memw(r2+#0)
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r2)
		r21:20 = combine(#0,r0)
		memd(r30+#-8) = r17:16
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r22+#76)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r22+#80)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r23 = mpyi(r3,r2)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r23,r1)
		call __hexagon_udivdi3
	}
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r23,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r18)
		if (p0.new) r23 = #33
	}
	{
		if (p0) r2 = add(r22,#52)
		if (!p0) jump:nt .LBB6_13
		memd(r29+#120) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %for.body.lr.ph
	{
		r21:20 = combine(#32,#39)
		r25:24 = combine(#35,#34)
		r27:26 = combine(#38,#37)
		memw(r29+#116) = r2
	}                                       // 4-byte Folded Spill
	{
		v0 = vxor(v0,v0)
		vmem(r29+#1) = v0.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB6_4:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_9 Depth 2
                                        //     Child Loop BB6_11 Depth 2
	{
		r17 = memw(r22+#80)
		r19 = memw(r16+#8)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r17,r18)
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		r6 = r18
		r2 = memw(r22+#12)
		r3 = memw(r22+#20)
	}
	{
		r6 -= mpyi(r0,r17)
	}
	{
		r4 = memw(r2+#4)
		r5 = memw(r3+#16)
	}
	{
		r4 = mpyi(r4,r19)
	}
	{
		r4 = addasl(r4,r6,#5)
	}
	{
		r7 = add(r4,#32)
		if (!cmp.gtu(r7.new,r5)) jump:t .LBB6_7
	}
// %bb.6:                               // %if.else.i
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		jump .LBB6_8
		v0 = v1
		v1.cur = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	.falign
.LBB6_7:                                // %if.then.i
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		r7 = memw(r16+#4)
		r8 = memw(r3+#48)
	}
	{
		r8 = addasl(r8,r4,#2)
		r3 = memw(r3+#44)
	}
	{
		r5 = mpyi(r7,r5)
		r3 = addasl(r3,r4,#2)
	}
	{
		r7 = addasl(r8,r5,#2)
		r3 = addasl(r3,r5,#2)
	}
	{
		v2 = vmemu(r7+#0)
	}
	{
		v1 = vmemu(r3+#0)
	}
	{
		v0.sf = v2.w
	}
	.falign
.LBB6_8:                                // %if.end.i
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		r5 = asl(r18,#13)
		r12 = asl(r0,#6)
		r4 = memw(r22+#96)
		r3 = memw(r16+#12)
	}
	{
		r8 = asl(r0,#1)
		r13 = r6
		r9 = memw(r22+#644)
		r2 = memw(r2+#12)
	}
	{
		loop0(.LBB6_9,#4)
		r13 += mpyi(r8,r17)
		r10 = memw(r29+#116)
		r15 = memw(r22+#0)
	}                                       // 4-byte Folded Reload
	{
		r7 = addasl(r10,r3,#2)
		r2 = mpyi(r2,r9)
		r14 = memw(r4+#8)
		r1:0 = memd(r22+#104)
	}
	{
		r28 = addasl(r0,r2,#2)
		r0 = addasl(r1,r2,#2)
		r9 = memw(r22+#68)
		r3 = memw(r10+r3<<#2)
	}
	{
		r5 += add(r15,r9)
		r14 = lsr(r14,#5)
		r9 = add(r15,r3)
		r4 = memw(r4+#12)
	}
	{
		r3 = addasl(r28,r12,#2)
		r2 = lsr(r4,#5)
	}
	{
		r4 = addasl(r0,r12,#2)
		r5 = addasl(r5,r14,#7)
		r12 = #0
	}
	{
		r9 += asl(r13,#11)
	}
	.falign
.LBB6_9:                                // Block address taken
                                        // %for.body35.i
                                        //   Parent Loop BB6_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r0 = asl(r12,#1)
		r13 = setbit(r12,#1)
		r14 = memw(r4+r12<<#3)
		r15 = memw(r3+r12<<#3)
	}
	{
		r1 = mpyi(r0,r2)
		v5 = vsplat(r14)
		r14 = or(r0,#3)
		r12 = add(r12,#4)
	}
	{
		r28 = setbit(r0,#0)
		r0 = setbit(r0,#1)
	}
	{
		r10 = mpyi(r28,r2)
		r1 = addasl(r5,r1,#7)
		r17 = memw(r4+r0<<#2)
		r11 = memw(r4+r28<<#2)
	}
	{
		v7 = vsplat(r17)
		v6 = vsplat(r11)
		v8.sf = v5.w
		r17 = memw(r4+r14<<#2)
	}
	{
		r10 = addasl(r5,r10,#7)
		v9 = vsplat(r17)
		v12.sf = v11.w
		v11.cur = vmem(r1+#0)
	}
	{
		r11 = mpyi(r0,r2)
		v14.qf32 = vmpy(v8.sf,v0.sf)
		v10.sf = v6.w
		v13.sf = v7.w
	}
	{
		r1 = addasl(r5,r11,#7)
		r11 = mpyi(r14,r2)
		v15.sf = v9.w
		v17 = vmem(r10+#0)
	}
	{
		r10 = addasl(r5,r11,#7)
		v16.qf32 = vmpy(v10.sf,v0.sf)
		v22.sf = v14.qf32
		v18.sf = v17.w
	}
	{
		v19.qf32 = vmpy(v13.sf,v0.sf)
		v21.sf = v20.w
		r28 = memw(r3+r28<<#2)
		v20.cur = vmem(r1+#0)
	}
	{
		v23.qf32 = vmpy(v15.sf,v0.sf)
		v27.sf = v16.qf32
		r11 = memw(r3+r0<<#2)
		v25 = vmem(r10+#0)
	}
	{
		v29 = vsplat(r15)
		v24.sf = v19.qf32
		v26.sf = v25.w
		r14 = memw(r3+r14<<#2)
	}
	{
		v2 = vsplat(r28)
		v5 = vsplat(r11)
		v30.sf = v23.qf32
		v28.qf32 = vsub(v12.sf,v22.sf)
	}
	{
		r15 = asl(r13,#1)
		v25 = vsplat(r14)
		v31.qf32 = vsub(v21.sf,v24.sf)
		v4.qf32 = vsub(v18.sf,v27.sf)
	}
	{
		r0 = mpyi(r15,r2)
		r14 = setbit(r15,#0)
		v23.qf32 = vsub(v26.sf,v30.sf)
		v3.sf = v28.qf32
	}
	{
		r28 = addasl(r5,r0,#7)
		r0 = setbit(r15,#1)
		v26.sf = v4.qf32
		v24.sf = v31.qf32
	}
	{
		r1 = mpyi(r14,r2)
		v27.qf32 = vmpy(v3.sf,v29.sf)
		r15 = or(r15,#3)
		v28.sf = v23.qf32
	}
	{
		r1 = addasl(r5,r1,#7)
		v29.qf32 = vmpy(v24.sf,v5.sf)
	}
	{
		r10 = mpyi(r0,r2)
		v14.qf32 = vmpy(v26.sf,v2.sf)
		v30.sf = v27.qf32
	}
	{
		r10 = addasl(r5,r10,#7)
		v15.qf32 = vmpy(v28.sf,v25.sf)
		v16.sf = v29.qf32
	}
	{
		v2.qf32 = vmpy(v30.sf,v1.sf)
		v17.sf = v14.qf32
	}
	{
		v4.qf32 = vmpy(v16.sf,v1.sf)
		v31.sf = v15.qf32
	}
	{
		v3.qf32 = vmpy(v17.sf,v1.sf)
	}
	{
		v5.qf32 = vmpy(v31.sf,v1.sf)
	}
	{
		v8.hf = v3:2.qf32
		vmem(r9+#0) = v8.new
	}
	{
		v9.hf = v5:4.qf32
		vmem(r9+#1) = v9.new
	}
	{
		r11 = memw(r4+r13<<#3)
		r17 = memw(r4+r14<<#2)
	}
	{
		v10 = vsplat(r11)
		v11 = vsplat(r17)
		r11 = memw(r4+r0<<#2)
		v19 = vmem(r1+#0)
	}
	{
		r1 = mpyi(r15,r2)
		v13 = vsplat(r11)
		r11 = memw(r4+r15<<#2)
		v12 = vmem(r28+#0)
	}
	{
		r11 = addasl(r5,r1,#7)
		v21 = vsplat(r11)
		v18.sf = v10.w
		v22.sf = v11.w
	}
	{
		v3.sf = v13.w
		v24.sf = v12.w
		r13 = memw(r3+r13<<#3)
		v23 = vmem(r10+#0)
	}
	{
		v25.qf32 = vmpy(v18.sf,v0.sf)
		v26.sf = v21.w
		r14 = memw(r3+r14<<#2)
		v30 = vmem(r11+#0)
	}
	{
		v27.qf32 = vmpy(v22.sf,v0.sf)
		v20.sf = v19.w
		v2.sf = v23.w
		r1 = memw(r3+r15<<#2)
	}
	{
		v29.qf32 = vmpy(v3.sf,v0.sf)
		v4.sf = v25.qf32
		v5.sf = v30.w
	}
	{
		v31.qf32 = vmpy(v26.sf,v0.sf)
		v6.sf = v27.qf32
	}
	{
		v14 = vsplat(r13)
		v7.sf = v29.qf32
		v16.qf32 = vsub(v24.sf,v4.sf)
		r13 = memw(r3+r0<<#2)
	}
	{
		v17 = vsplat(r14)
		v12 = vsplat(r13)
		v15.sf = v31.qf32
		v8.qf32 = vsub(v20.sf,v6.sf)
	}
	{
		v18 = vsplat(r1)
		v9.qf32 = vsub(v2.sf,v7.sf)
		v11.sf = v16.qf32
	}
	{
		v10.qf32 = vsub(v5.sf,v15.sf)
		v13.sf = v8.qf32
	}
	{
		v21.qf32 = vmpy(v11.sf,v14.sf)
		v19.sf = v9.qf32
	}
	{
		v23.qf32 = vmpy(v13.sf,v17.sf)
		v20.sf = v10.qf32
	}
	{
		v25.qf32 = vmpy(v19.sf,v12.sf)
		v27.sf = v21.qf32
	}
	{
		v26.qf32 = vmpy(v20.sf,v18.sf)
		v3.sf = v23.qf32
	}
	{
		v14.qf32 = vmpy(v27.sf,v1.sf)
		v2.sf = v25.qf32
	}
	{
		v15.qf32 = vmpy(v3.sf,v1.sf)
		v29.sf = v26.qf32
	}
	{
		v16.qf32 = vmpy(v2.sf,v1.sf)
	}
	{
		v17.qf32 = vmpy(v29.sf,v1.sf)
		v30.hf = v15:14.qf32
		vmem(r9+#2) = v30.new
	}
	{
		r9 = add(r9,#512)
		v31.hf = v17:16.qf32
		vmem(r9+#3) = v31.new
	} :endloop0
// %bb.10:                              // %for.cond.cleanup34.i
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		loop0(.LBB6_11,#4)
		r8 = setbit(r8,#0)
		r9 = memw(r22+#80)
		r12 = memw(r22+#0)
	}
	{
		r7 = memw(r7+#0)
	}
	{
		r6 += mpyi(r9,r8)
		r7 = add(r12,r7)
		r8 = #0
	}
	{
		r7 += asl(r6,#11)
	}
	.falign
.LBB6_11:                               // Block address taken
                                        // %for.body35.1.i
                                        //   Parent Loop BB6_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r9 = addasl(r21,r8,#1)
		r12 = addasl(r23,r8,#1)
		r6 = r8
	}
	{
		r13 = addasl(r24,r8,#1)
		r14 = addasl(r25,r8,#1)
	}
	{
		r28 = mpyi(r9,r2)
		r0 = mpyi(r12,r2)
		r15 = memw(r4+r9<<#2)
		r1 = memw(r4+r12<<#2)
	}
	{
		v3 = vsplat(r15)
		v4 = vsplat(r1)
		r11 = memw(r4+r13<<#2)
		r10 = memw(r4+r14<<#2)
	}
	{
		v5 = vsplat(r11)
		v7 = vsplat(r10)
		r9 = memw(r3+r9<<#2)
		r12 = memw(r3+r12<<#2)
	}
	{
		r28 = addasl(r5,r28,#7)
		r1 = mpyi(r13,r2)
		v6.sf = v3.w
		v8.sf = v4.w
	}
	{
		r11 = addasl(r5,r1,#7)
		r1 = mpyi(r14,r2)
		v11.sf = v5.w
		v13.sf = v7.w
	}
	{
		r0 = addasl(r5,r0,#7)
		v12.qf32 = vmpy(v6.sf,v0.sf)
		v10.sf = v9.w
		v9.cur = vmem(r28+#0)
	}
	{
		r28 = addasl(r5,r1,#7)
		v14.qf32 = vmpy(v8.sf,v0.sf)
		v19.sf = v18.w
		v18.cur = vmem(r11+#0)
	}
	{
		v17.qf32 = vmpy(v11.sf,v0.sf)
		v20.sf = v12.qf32
		r14 = memw(r3+r14<<#2)
		v15 = vmem(r0+#0)
	}
	{
		r6 = add(#36,asl(r6,#1))
		v21.qf32 = vmpy(v13.sf,v0.sf)
		v16.sf = v15.w
		v23 = vmem(r28+#0)
	}
	{
		v27 = vsplat(r9)
		v22.sf = v17.qf32
		v25.sf = v14.qf32
		r9 = memw(r3+r13<<#2)
	}
	{
		v30 = vsplat(r12)
		v3 = vsplat(r9)
		v26.qf32 = vsub(v10.sf,v20.sf)
		v24.sf = v23.w
	}
	{
		r9 = addasl(r26,r8,#1)
		v6 = vsplat(r14)
		v28.sf = v21.qf32
		v31.qf32 = vsub(v16.sf,v25.sf)
	}
	{
		r12 = addasl(r27,r8,#1)
		r15 = mpyi(r6,r2)
		v2.sf = v26.qf32
		v29.qf32 = vsub(v19.sf,v22.sf)
	}
	{
		r0 = mpyi(r9,r2)
		r13 = addasl(r5,r15,#7)
		v26.qf32 = vsub(v24.sf,v28.sf)
		v7.sf = v31.qf32
	}
	{
		r14 = addasl(r5,r0,#7)
		v8.qf32 = vmpy(v2.sf,v27.sf)
		v28.sf = v29.qf32
	}
	{
		r0 = addasl(r20,r8,#1)
		v11.qf32 = vmpy(v7.sf,v30.sf)
		r8 = add(r8,#4)
		v9.sf = v26.qf32
	}
	{
		r1 = mpyi(r12,r2)
		v10.qf32 = vmpy(v28.sf,v3.sf)
		v12.sf = v8.qf32
	}
	{
		r15 = addasl(r5,r1,#7)
		v13.qf32 = vmpy(v9.sf,v6.sf)
		v30.sf = v11.qf32
	}
	{
		v6.qf32 = vmpy(v12.sf,v1.sf)
		v29.sf = v10.qf32
	}
	{
		v7.qf32 = vmpy(v30.sf,v1.sf)
		v31.sf = v13.qf32
	}
	{
		v8.qf32 = vmpy(v29.sf,v1.sf)
	}
	{
		v9.qf32 = vmpy(v31.sf,v1.sf)
		v4.hf = v7:6.qf32
		vmem(r7+#0) = v4.new
	}
	{
		v5.hf = v9:8.qf32
		vmem(r7+#1) = v5.new
	}
	{
		r10 = memw(r4+r6<<#2)
		r1 = memw(r4+r9<<#2)
	}
	{
		v6 = vsplat(r10)
		v7 = vsplat(r1)
		r11 = memw(r4+r12<<#2)
		r10 = memw(r4+r0<<#2)
	}
	{
		v9 = vsplat(r11)
		v17 = vsplat(r10)
		v22.sf = v8.w
		v8.cur = vmem(r13+#0)
	}
	{
		r11 = mpyi(r0,r2)
		v14.sf = v6.w
		v18.sf = v7.w
		v15 = vmem(r14+#0)
	}
	{
		r1 = addasl(r5,r11,#7)
		v20.sf = v9.w
		v3.sf = v17.w
		v19 = vmem(r15+#0)
	}
	{
		v2.qf32 = vmpy(v14.sf,v0.sf)
		v16.sf = v15.w
		v30.sf = v19.w
		r6 = memw(r3+r6<<#2)
	}
	{
		v21.qf32 = vmpy(v18.sf,v0.sf)
		v28.sf = v24.w
		r9 = memw(r3+r9<<#2)
		v24.cur = vmem(r1+#0)
	}
	{
		v23.qf32 = vmpy(v20.sf,v0.sf)
		v27.sf = v2.qf32
	}
	{
		v25.qf32 = vmpy(v3.sf,v0.sf)
		v10.sf = v21.qf32
	}
	{
		v12 = vsplat(r6)
		v31 = vsplat(r9)
		v11.sf = v23.qf32
		v29.qf32 = vsub(v22.sf,v27.sf)
	}
	{
		v13.sf = v25.qf32
		v4.qf32 = vsub(v16.sf,v10.sf)
		r6 = memw(r3+r12<<#2)
		r9 = memw(r3+r0<<#2)
	}
	{
		v8 = vsplat(r6)
		v14 = vsplat(r9)
		v5.qf32 = vsub(v30.sf,v11.sf)
		v7.sf = v29.qf32
	}
	{
		v6.qf32 = vsub(v28.sf,v13.sf)
		v9.sf = v4.qf32
	}
	{
		v18.qf32 = vmpy(v7.sf,v12.sf)
		v16.sf = v5.qf32
	}
	{
		v19.qf32 = vmpy(v9.sf,v31.sf)
		v17.sf = v6.qf32
	}
	{
		v21.qf32 = vmpy(v16.sf,v8.sf)
		v24.sf = v18.qf32
	}
	{
		v23.qf32 = vmpy(v17.sf,v14.sf)
		v27.sf = v19.qf32
	}
	{
		v10.qf32 = vmpy(v24.sf,v1.sf)
		v25.sf = v21.qf32
	}
	{
		v11.qf32 = vmpy(v27.sf,v1.sf)
		v2.sf = v23.qf32
	}
	{
		v12.qf32 = vmpy(v25.sf,v1.sf)
	}
	{
		v13.qf32 = vmpy(v2.sf,v1.sf)
		v3.hf = v11:10.qf32
		vmem(r7+#2) = v3.new
	}
	{
		r7 = add(r7,#512)
		v31.hf = v13:12.qf32
		vmem(r7+#3) = v31.new
	} :endloop0
// %bb.12:                              // %dequant_s_at.exit
                                        //   in Loop: Header=BB6_4 Depth=1
	{
		r1:0 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r18 = add(r18,#1)
		if (cmp.gtu(r0,r18.new)) jump:t ##.LBB6_4
	}
	.falign
.LBB6_13:                               // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	dequant_worker, .Lfunc_end6-dequant_worker
                                        // -- End function
	.falign
	.type	softmax_worker,@function        // -- Begin function softmax_worker
softmax_worker:                         // @softmax_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#1920):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r2 = memw(r2+#76)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r18 = asl(r2,#5)
		r23:22 = combine(#0,r0)
		memd(r30+#-16) = r19:18
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r18,r1)
		r3:2 = combine(r23,r22)
		memd(r30+#-24) = r21:20
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r21:20 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r18,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r23,r22)
	}
	.falign
// %bb.2:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r20)
		if (p0.new) r4 = ##2316
	}
	{
		if (p0) r2 = ##15360
		if (!p0) jump:nt .LBB7_47
		memd(r29+#112) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %for.body.lr.ph
	{
		r8 = ##65535
		r6 = #8429
		v1 = vxor(v1,v1)
	}
	{
		v20.h = vsplat(r4)
		r4 = add(r29,#2048)
		r24 = #16
		vmem(r29+#7) = v1
	}                                       // 128-byte Folded Spill
	{
		r4 = add(r16,#52)
		r21 = #1
		vmem(r4+#-8) = v20
	}                                       // 128-byte Folded Spill
	{
		v16.h = vsplat(r2)
		r4 = add(r8,#-1023)
		r2 = add(r29,#2048)
		memw(r29+#108) = r4
	}                                       // 4-byte Folded Spill
	{
		v30.h = vsplat(r6)
		v9.h = vsplat(r4)
		r6 = add(r8,#-12799)
		vmem(r29+#2) = v30.new
	}                                       // 128-byte Folded Spill
	{
		r3 = #14336
		r22 = #8
		r2 = add(r29,#2048)
		vmem(r2+#-7) = v16
	}                                       // 128-byte Folded Spill
	{
		v3.h = vsplat(r3)
		r8 = #10
		r3 = #14732
	}
	{
		r2 = #13232
		vmem(r2+#-6) = v3
	}                                       // 128-byte Folded Spill
	{
		v23.h = vsplat(r2)
		r5 = #5501
		r7 = #11035
		vmem(r29+#4) = v23.new
	}                                       // 128-byte Folded Spill
	{
		v5.h = vsplat(r5)
		r2 = add(r29,#2048)
		vmem(r29+#1) = v5.new
	}                                       // 128-byte Folded Spill
	{
		v7.h = vsplat(r7)
		v21.h = vsplat(r3)
		vmem(r29+#3) = v7.new
	}                                       // 128-byte Folded Spill
	{
		v31.h = vsplat(r6)
		memd(r29+#120) = r23:22
	}                                       // 8-byte Folded Spill
	{
		vmem(r29+#6) = v31
	}                                       // 128-byte Folded Spill
	{
		vmem(r29+#5) = v21
	}                                       // 128-byte Folded Spill
	{
		vmem(r2+#-5) = v9
	}                                       // 128-byte Folded Spill
	.falign
.LBB7_4:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB7_20 Depth 2
                                        //     Child Loop BB7_26 Depth 2
                                        //     Child Loop BB7_29 Depth 2
                                        //     Child Loop BB7_38 Depth 2
	{
		r17 = #14732
		v6 = v1
		r2 = memw(r16+#12)
		r7 = memw(r16+#80)
	}
	{
		r17 = insert(r20,#31,#1)
		r3 = memw(r16+#668)
		r25 = memw(r16+#656)
	}
	{
		p2 = cmp.eq(r3,#0)
		if (p2.new) jump:nt .LBB7_17
		r26 = memw(r2+#4)
		memw(r29+#1664) = r7
	}                                       // 4-byte Folded Spill
// %bb.5:                               // %if.then.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r3 = p2
		r18 = memw(r2+#8)
		memw(r29+#1536) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(r18,r17)
		r2 = memw(r2+#0)
		r3 = memw(r16+#652)
	}
	{
		r19 = mpyi(r2,r3)
		r22 = mpyi(r18,r2)
	}
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.6:                               // %if.then.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		if (!p1.new) r23 = #0
		r27 = #0
		p1 = cmp.gtu(r22,r17); if (!p1.new) jump:t .LBB7_9
	}
// %bb.7:                               // %lor.lhs.false.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r3 = add(r0,r19)
		r2 = memw(r16+#8)
	}
	{
		r4 = memw(r2+#0)
		if (!cmp.gtu(r4.new,r3)) jump:t .LBB7_10
	}
// %bb.8:                               // %if.end.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r4 = memw(r2+#4)
		r5 = memw(r2+#8)
	}
	{
		r3 = add(r3,add(r4,#1))
		r0 = memw(r2+#24)
	}
	{
		r3 = minu(r3,r5)
		p0 = cmp.eq(r0,#0)
	}
	{
		p1 = cmp.gtu(r3,r0)
		r4 = sub(r3,r0)
		r24 = zxth(r3)
	}
	{
		if (p1) r23 = zxth(r4)
		if (!p1) r23 = #0
	}
	{
		if (p0) r23 = #0
		jump .LBB7_11
	}
	.falign
.LBB7_9:                                //   in Loop: Header=BB7_4 Depth=1
	{
		r24 = ##65535
		jump .LBB7_11
	}
	.falign
.LBB7_10:                               //   in Loop: Header=BB7_4 Depth=1
	{
		r23 = #0
		r24 = ##65535
	}
	.falign
.LBB7_11:                               // %if.end.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r21 = setbit(r17,#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r21)
	}
	.falign
// %bb.12:                              // %if.end.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = ##-65536
		p1 = cmp.gtu(r22,r21); if (!p1.new) jump:t .LBB7_15
	}
// %bb.13:                              // %lor.lhs.false.i.1.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r4 = add(r0,r19)
		r21 = #1
		r3 = memw(r16+#8)
		r7 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r8 = #10
	}
	{
		r5 = memw(r3+#0)
	}
	{
		p0 = cmp.gtu(r5,r4)
		r5 = add(r29,#2048)
	}
	{
		r5 = memw(r29+#1536)
		v9 = vmem(r5+#-5)
	}                                       // 128-byte Folded Reload
	{
		p2 = r5
		if (!p0) jump:nt .LBB7_16
		if (p0) r2 = memw(r3+#4)
		if (p0) r5 = memw(r3+#8)
	}
// %bb.14:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = add(r4,add(r2,#1))
		r3 = memw(r3+#24)
	}
	{
		r2 = minu(r2,r5)
		p0 = cmp.eq(r3,#0)
	}
	{
		r27 = sub(r2.l,r3.l):<<16
		p1 = cmp.gtu(r2,r3)
		r2 = aslh(r2)
	}
	{
		if (!p1) r27 = #0
	}
	{
		if (p0) r27 = #0
		jump .LBB7_16
	}
	.falign
.LBB7_15:                               //   in Loop: Header=BB7_4 Depth=1
	{
		r3 = add(r29,#2048)
		r21 = #1
		r8 = #10
		r7 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#1536)
		v9 = vmem(r3+#-5)
	}                                       // 128-byte Folded Reload
	{
		p2 = r3
	}
	.falign
.LBB7_16:                               // %if.end.1.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r3 = or(r27,r23)
		r2 = combine(r2.h,r24.l)
		r24 = #16
		r23:22 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		v6 = vsplat(r3)
		v1 = vsplat(r2)
		r22 = #8
	}
	.falign
.LBB7_17:                               // %if.end19.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r3 = extractu(r17,#21,#5)
		r2 = add(r29,#2048)
		r0 = memw(r16+#664)
		r6 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		r5 = and(r20,#15)
		p0 = cmp.eq(r7,#0)
		r4 = memw(r16+#0)
		vmem(r2+#-4) = v1
	}                                       // 128-byte Folded Spill
	{
		r3 = mpyi(r3,r7)
		r6 = #11
		r2 = memw(r6+r0<<#2)
		r1:0 = memd(r16+#120)
	}
	{
		r2 = add(r4,r2)
	}
	{
		r2 += asl(r3,#11)
		r3 = memw(r16+#112)
		memw(r29+#100) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r27 = addasl(r2,r5,#7)
		r2 = p0
		if (p0) jump:nt .LBB7_32
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.18:                              // %for.body.i.preheader.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = memw(r16+#640)
		v3 = vmem(r16+#2)
	}
	{
		r2 = mpyi(r26,r25)
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB7_23
	}
// %bb.19:                              // %for.body.i.preheader.split.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r4 = ##1065353216
		r3 = ##65535
	}
	{
		loop0(.LBB7_20,r7)
		v11 = vsplat(r4)
		r4 = #32767
		v10 = vmem(r16+#3)
	}
	{
		v12.h = vsplat(r4)
		r3 = add(r3,#-32767)
		v16 = vmem(r16+#4)
	}
	{
		v15.h = vsplat(r3)
		r4 = ##1073741824
		r3 = r27
	}
	{
		v13 = vsplat(r4)
		r4 = ##2129587123
	}
	{
		v14 = vsplat(r4)
		r4 = add(r29,#2048)
	}
	{
		v9 = vmem(r4+#-5)
	}                                       // 128-byte Folded Reload
	.falign
.LBB7_20:                               // Block address taken
                                        // %for.body.i.i
                                        //   Parent Loop BB7_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r4 = add(r29,#2048)
		v18 = vand(v17,v15)
		v19 = vand(v17,v12)
		v17.cur = vmem(r3+#0)
	}
	{
		v24 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		v5:4.qf32 = vmpy(v19.hf,v16.hf)
		r4 = add(r29,#2048)
		v17 = vmem(r4+#-6)
	}                                       // 128-byte Folded Reload
	{
		r4 = add(r29,#2048)
		v0 = vmem(r4+#-8)
	}                                       // 128-byte Folded Reload
	{
		v20.hf = v5:4.qf32
		v29 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		v21 = vxor(v20,v15)
		v31 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	{
		v22.hf = vmax(v24.hf,v21.hf)
		v2 = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		v19 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v23.qf16 = vsub(v22.hf,v17.hf)
		v1 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		v21.hf = v23.qf16
	}
	{
		v25.h = v21.hf
		v21 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v26.hf = v25.h
	}
	{
		v27.qf16 = vsub(v22.hf,v26.hf)
	}
	{
		v28.qf16 = vmpy(v27.qf16,v0.hf)
	}
	{
		v29.qf16 = vadd(v28.qf16,v29.hf)
	}
	{
		v30.qf16 = vmpy(v29.qf16,v27.qf16)
	}
	{
		v31.qf16 = vadd(v30.qf16,v31.hf)
	}
	{
		v0.qf16 = vmpy(v31.qf16,v27.qf16)
	}
	{
		v2.qf16 = vadd(v0.qf16,v2.hf)
	}
	{
		v4.qf16 = vmpy(v2.qf16,v27.qf16)
	}
	{
		v5.qf16 = vadd(v4.qf16,v19.hf)
	}
	{
		v7.qf16 = vmpy(v5.qf16,v27.qf16)
	}
	{
		if (!p2) r4 = add(r29,##2048)
		v8.qf16 = vadd(v7.qf16,v1.hf)
		v1 = vmem(r4+#-7)
	}                                       // 128-byte Folded Reload
	{
		v17.qf16 = vmpy(v8.qf16,v27.qf16)
	}
	{
		v19.qf16 = vadd(v17.qf16,v1.hf)
	}
	{
		v20.hf = v19.qf16
	}
	{
		v27.h = vasl(v20.h,r21)
		v20.h += vasl(v25.h,r8)
	}
	{
		v22.uh = vlsr(v27.uh,r6)
	}
	{
		v23.h = vadd(v25.h,v22.h)
	}
	{
		q0 = vcmp.gt(v21.h,v23.h)
	}
	{
		v24 = vmux(q0,v21,v20)
	}
	{
		v21.qf16 = vadd(v1.hf,v24.hf)
		v24.qf16 = vsub(v1.hf,v24.hf)
	}
	{
		v21:20.qf32 = vmpy(v21.qf16,v1.hf)
	}
	{
		v26.sf = v21.qf32
		v27.sf = v20.qf32
	}
	{
		v28.w = vsub(v14.w,v26.w)
		v29.w = vsub(v14.w,v27.w)
	}
	{
		v30.qf32 = vmpy(v28.sf,v26.sf)
	}
	{
		v31.qf32 = vmpy(v29.sf,v27.sf)
	}
	{
		v0.sf = v30.qf32
	}
	{
		v2.sf = v31.qf32
	}
	{
		v4.qf32 = vsub(v13.sf,v0.sf)
	}
	{
		v5.qf32 = vsub(v13.sf,v2.sf)
	}
	{
		v7.sf = v4.qf32
	}
	{
		v8.sf = v5.qf32
	}
	{
		v17.qf32 = vmpy(v28.sf,v7.sf)
	}
	{
		v19.qf32 = vmpy(v29.sf,v8.sf)
	}
	{
		v20.sf = v17.qf32
	}
	{
		v25.sf = v19.qf32
	}
	{
		v22.qf32 = vmpy(v20.sf,v26.sf)
	}
	{
		v23.qf32 = vmpy(v25.sf,v27.sf)
	}
	{
		v21.sf = v22.qf32
	}
	{
		v20.sf = v23.qf32
	}
	{
		v21.qf32 = vsub(v13.sf,v21.sf)
	}
	{
		v28.qf32 = vsub(v13.sf,v20.sf)
	}
	{
		v29.qf32 = vmpy(v17.qf32,v21.qf32)
	}
	{
		v30.qf32 = vmpy(v19.qf32,v28.qf32)
	}
	{
		v31.sf = v29.qf32
	}
	{
		v0.sf = v30.qf32
	}
	{
		v23.qf32 = vmpy(v31.sf,v11.sf)
	}
	{
		v22.qf32 = vmpy(v0.sf,v11.sf)
	}
	{
		v2.hf = v23:22.qf32
	}
	{
		v25:24.qf32 = vmpy(v24.qf16,v2.hf)
	}
	{
		v4.hf = v25:24.qf32
	}
	{
		v23:22.qf32 = vmpy(v4.hf,v10.hf)
	}
	{
		v5.hf = v23:22.qf32
	}
	{
		if (p2) jump:nt .LBB7_22
		v29 = vor(v5,v18)
	}
// %bb.21:                              // %if.end5.thread.i.i
                                        //   in Loop: Header=BB7_20 Depth=2
	{
		v18.h = vsplat(r2)
	}
	{
		r4 = add(r29,#2048)
		v7.h = vadd(v3.h,v18.h)
		v22 = vmem(r4+#-4)
	}                                       // 128-byte Folded Reload
	{
		q1 = vcmp.gt(v6.uh,v7.uh)
		q2 = vcmp.gt(v22.uh,v7.uh)
		v17 = vmem(r4+#-5)
	}                                       // 128-byte Folded Reload
	{
		q3 = not(q1)
	}
	{
		q0 = and(q2,q3)
	}
	{
		v29 = vmux(q0,v29,v17)
	}
	.falign
.LBB7_22:                               // %if.then7.i.i
                                        //   in Loop: Header=BB7_20 Depth=2
	{
		r2 = add(r2,#32)
		r3 = add(r3,#2048)
		v9.hf = vmax(v9.hf,v29.hf)
		vmem(r3+#0) = v29
	} :endloop0
	{
		jump .LBB7_32
	}
	.falign
.LBB7_23:                               // %for.body.i.preheader.split.us.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		if (p2) r2 = add(r27,#0)
		r3 = add(r29,#2048)
	}
	{
		if (p2) jump:nt .LBB7_28
		v9 = vmem(r3+#-5)
	}                                       // 128-byte Folded Reload
// %bb.24:                              // %for.body.i.us.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		v31.h = vsplat(r2)
		r3 = add(r2,#32)
		r2 = add(r29,#2048)
		p0 = cmp.gtu(r7,#1)
	}
	{
		if (p0) r4 = add(r7,#-2)
		v28 = v9
		v20.h = vadd(v3.h,v31.h)
		v10 = vmem(r2+#-4)
	}                                       // 128-byte Folded Reload
	{
		r2 = r27
		if (!p0) jump:nt .LBB7_31
		q0 = vcmp.gt(v6.uh,v20.uh)
	}
// %bb.25:                              // %for.body.i.us.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		v2.h = vsplat(r3)
		q3 = vcmp.gt(v10.uh,v20.uh)
		q0 = not(q0)
		v0 = vmem(r27+#0)
	}
	{
		r2 = add(r27,#2048)
		p1 = cmp.gtu(r7,#2)
		q1 = and(q3,q0)
		v20.h = vadd(v3.h,v2.h)
	}
	{
		r3 = add(r3,#32)
		v26 = vmux(q1,v0,v9)
		vmem(r27+#0) = v26.new
	}
	{
		loop0(.LBB7_26,r4)
		if (!p1) jump:nt .LBB7_27
		v21 = v9
		q0 = vcmp.gt(v6.uh,v20.uh)
	}
	.balign 32
.LBB7_26:                               // %for.body.i.us.i
                                        //   Parent Loop BB7_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v4.h = vsplat(r3)
		q2 = vcmp.gt(v10.uh,v20.uh)
		q1 = not(q0)
		v5 = vmem(r2+#0)
	}
	{
		r3 = add(r3,#32)
		q2 = and(q2,q1)
		v20.h = vadd(v3.h,v4.h)
		v21.hf = vmax(v21.hf,v26.hf)
	}
	{
		r2 = add(r2,#2048)
		v26 = vmux(q2,v5,v9)
		q0 = vcmp.gt(v6.uh,v20.uh)
		vmem(r2+#0) = v26.new
	} :endloop0
	.falign
.LBB7_27:                               //   in Loop: Header=BB7_4 Depth=1
	{
		jump .LBB7_31
		v28.hf = vmax(v21.hf,v26.hf)
	}
	.falign
.LBB7_28:                               //   in Loop: Header=BB7_4 Depth=1
	{
		loop0(.LBB7_29,r7)
	}
	.falign
.LBB7_29:                               // Block address taken
                                        // %for.body.i.us.us.i
                                        //   Parent Loop BB7_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = add(r2,#2048)
		v9.hf = vmax(v9.hf,v30.hf)
		v30.cur = vmem(r2+#0)
	} :endloop0
	{
		jump .LBB7_32
	}
	.falign
.LBB7_31:                               //   in Loop: Header=BB7_4 Depth=1
	{
		q3 = vcmp.gt(v10.uh,v20.uh)
		q0 = not(q0)
		v3 = vmem(r2+#0)
	}
	{
		q1 = and(q3,q0)
	}
	{
		v1 = vmux(q1,v3,v9)
		vmem(r2+#0) = v1.new
	}
	{
		v9.hf = vmax(v28.hf,v1.hf)
	}
	.falign
.LBB7_32:                               // %for.cond.cleanup.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = addasl(r0,r17,#1)
		r26 = #32
		v6 = valign(v9,v9,#4)
		r3 = memuh(r0+r17<<#1)
	}
	{
		r19 = addasl(r1,r17,#1)
		r5 = #64
		v7.hf = vmax(v9.hf,v6.hf)
		v3 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		r4 = memuh(r2+#2)
		v27 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		r3 = combine(r4.l,r3.l)
		v8 = vror(v7,r22)
		v4 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	{
		v16 = vsplat(r3)
		r3 = add(r29,#2048)
		v9.hf = vmax(v7.hf,v8.hf)
	}
	{
		r3 = add(r29,#2048)
		v6 = vmem(r3+#-5)
	}                                       // 128-byte Folded Reload
	{
		v10 = vror(v9,r24)
	}
	{
		v11.hf = vmax(v9.hf,v10.hf)
	}
	{
		v12 = vror(v11,r26)
	}
	{
		v13.hf = vmax(v11.hf,v12.hf)
	}
	{
		v14 = vror(v13,r5)
	}
	{
		v15.hf = vmax(v13.hf,v14.hf)
		v13 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v17.hf = vmax(v16.hf,v15.hf)
		v14 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		q2 = vcmp.eq(v17.h,v6.h)
		v15 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		r3 = add(r29,#2048)
		v0 = vmux(q2,v13,v17)
		vmem(r3+#-4) = v0.new
	}                                       // 128-byte Folded Spill
	{
		r3 = add(r29,#2048)
		v23 = vmem(r3+#-6)
	}                                       // 128-byte Folded Reload
	{
		v18.qf16 = vsub(v16.hf,v0.hf)
	}
	{
		v19.hf = v18.qf16
	}
	{
		v20.hf = vmax(v3.hf,v19.hf)
	}
	{
		v21.qf16 = vsub(v20.hf,v23.hf)
	}
	{
		v22.hf = v21.qf16
	}
	{
		v23.h = v22.hf
	}
	{
		v24.hf = v23.h
	}
	{
		r3 = add(r29,#2048)
		v25.qf16 = vsub(v20.hf,v24.hf)
		v24 = vmem(r3+#-8)
	}                                       // 128-byte Folded Reload
	{
		v6 = vmem(r3+#-7)
	}                                       // 128-byte Folded Reload
	{
		v26.qf16 = vmpy(v25.qf16,v24.hf)
	}
	{
		v27.qf16 = vadd(v26.qf16,v27.hf)
		v26 = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		r3 = vextract(v17,r23)
	}
	{
		memh(r0+r17<<#1) = r3
		memh(r2+#2) = r3.h
	}
	{
		v28.qf16 = vmpy(v27.qf16,v25.qf16)
	}
	{
		v29.qf16 = vadd(v28.qf16,v4.hf)
	}
	{
		v30.qf16 = vmpy(v29.qf16,v25.qf16)
	}
	{
		v31.qf16 = vadd(v30.qf16,v26.hf)
	}
	{
		v27.qf16 = vmpy(v31.qf16,v25.qf16)
	}
	{
		v2.qf16 = vadd(v27.qf16,v14.hf)
	}
	{
		v4.qf16 = vmpy(v2.qf16,v25.qf16)
	}
	{
		v5.qf16 = vadd(v4.qf16,v15.hf)
	}
	{
		v28.qf16 = vmpy(v5.qf16,v25.qf16)
	}
	{
		v1.qf16 = vadd(v28.qf16,v6.hf)
	}
	{
		v6.hf = v1.qf16
	}
	{
		v7.h = vasl(v6.h,r21)
		v6.h += vasl(v23.h,r8)
	}
	{
		v29.uh = vlsr(v7.uh,r6)
	}
	{
		v30.h = vadd(v23.h,v29.h)
	}
	{
		q3 = vcmp.gt(v13.h,v30.h)
	}
	{
		v31 = vmux(q3,v13,v6)
	}
	{
		r0 = vextract(v31,r23)
	}
	{
		call __extendhfsf2
		r21 = lsr(r0,#16)
		memh(r1+r17<<#1) = r0
		memh(r19+#2) = r0.h
	}
	.falign
// %bb.33:                              // %for.cond.cleanup.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		call __extendhfsf2
		r0 = r21
		r21 = #1
		r18 = r0
	}
	.falign
// %bb.34:                              // %for.cond.cleanup.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r7:6 = combine(#10,#11)
		v5 = v12
		r2 = memw(r29+#104)
		v12.cur = vmem(r29+#7)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r3 = add(r29,##2048)
		if (p1.new) jump:nt .LBB7_46
	}
// %bb.35:                              // %for.body32.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = add(r29,#2048)
		r4 = memw(r29+#1664)
		v11 = vmem(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#2048)
		p1 = cmp.gtu(r4,#1)
		v12.qf16 = vsub(v11.hf,v25.hf)
		v25.cur = vmem(r2+#-4)
	}                                       // 128-byte Folded Reload
	{
		if (p1) r5 = add(r29,##2048)
		v7 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		r2 = add(r27,#2048)
		v13.hf = v12.qf16
		v11 = vmem(r2+#-6)
	}                                       // 128-byte Folded Reload
	{
		if (!p1) r2 = add(r29,##2048)
		v0.hf = vmax(v7.hf,v13.hf)
		v28 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	{
		v14.qf16 = vsub(v0.hf,v11.hf)
	}
	{
		v15.hf = v14.qf16
	}
	{
		if (!p1) jump:nt .LBB7_40
		v2.h = v15.hf
	}
// %bb.36:                              // %for.body32.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		p0 = cmp.gtu(r4,#2)
		v1.hf = v2.h
		v3.qf16 = vsub(v16.hf,v25.hf)
		v16.cur = vmem(r2+#0)
	}
	{
		r3 = add(r2,#2048)
		v26 = vmem(r3+#-8)
	}                                       // 128-byte Folded Reload
	{
		v5.qf16 = vsub(v0.hf,v1.hf)
		v6.hf = v3.qf16
		v13 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		if (!p0) r3 = add(r29,##2048)
		v0.hf = vmax(v7.hf,v6.hf)
		v12 = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		v9.qf16 = vmpy(v5.qf16,v26.hf)
	}
	{
		v10.qf16 = vsub(v0.hf,v11.hf)
	}
	{
		v8.qf16 = vadd(v9.qf16,v13.hf)
	}
	{
		v19.hf = v10.qf16
	}
	{
		v17.qf16 = vmpy(v8.qf16,v5.qf16)
	}
	{
		v4.h = v19.hf
	}
	{
		v20.qf16 = vadd(v17.qf16,v28.hf)
	}
	{
		v17.qf16 = vmpy(v20.qf16,v5.qf16)
		if (!p0) jump:nt .LBB7_41
	}
// %bb.37:                              // %for.body32.i.i
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		p0 = cmp.gtu(r4,#3)
		v21.qf16 = vadd(v17.qf16,v12.hf)
		v30 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v23.qf16 = vsub(v22.hf,v25.hf)
		v25.hf = v4.h
		v22.cur = vmem(r3+#0)
	}
	{
		v26.qf16 = vmpy(v21.qf16,v5.qf16)
		v8 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		r5 = add(r29,#2048)
		v27.hf = v23.qf16
		v10 = vmem(r5+#-8)
	}                                       // 128-byte Folded Reload
	{
		v28.qf16 = vadd(v26.qf16,v30.hf)
		v23 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v29.qf16 = vmpy(v28.qf16,v5.qf16)
		v28 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	{
		v30.qf16 = vadd(v29.qf16,v8.hf)
		v8.qf32 = v23.sf
	}
	{
		v31.qf16 = vmpy(v30.qf16,v5.qf16)
		v5.qf16 = vsub(v0.hf,v25.hf)
		v0.hf = vmax(v7.hf,v27.hf)
	}
	{
		v24.qf16 = vmpy(v5.qf16,v10.hf)
		v7.qf16 = vsub(v0.hf,v11.hf)
	}
	{
		r5 = add(r4,#-3)
		v18.qf16 = vadd(v24.qf16,v13.hf)
		v12.hf = v7.qf16
		v24 = vmem(r5+#-8)
	}                                       // 128-byte Folded Reload
	{
		loop0(.LBB7_38,r5)
		r5 = add(r29,#2048)
		r4 = add(r3,#2048)
		v7.qf32 = v23.sf
	}
	{
		v11.qf16 = vmpy(v18.qf16,v5.qf16)
		r5 = add(r29,#2048)
		v19.h = v12.hf
		v18 = vmem(r5+#-7)
	}                                       // 128-byte Folded Reload
	{
		v27.qf16 = vadd(v31.qf16,v18.hf)
		v12 = vmem(r5+#-6)
	}                                       // 128-byte Folded Reload
	{
		v13.qf16 = vadd(v11.qf16,v28.hf)
	}
	{
		v17.qf16 = vmpy(v13.qf16,v5.qf16)
		if (!p0) jump:nt .LBB7_39
		v13 = v23
	}
	.falign
.LBB7_38:                               // %for.body32.i.i
                                        //   Parent Loop BB7_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = add(r29,#2048)
		v15.hf = v27.qf16
		v14.qf16 = vadd(v17.qf16,v26.hf)
		v26.cur = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		r5 = r2
		r2 = r3
		r3 = r4
		v28 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v1.qf16 = vmpy(v14.qf16,v5.qf16)
		v6.h = vasl(v15.h,r21)
		v15.h += vasl(v2.h,r7)
	}
	{
		r4 = add(r4,#2048)
		v16 = vmem(r4+#0)
	}
	{
		v17.uh = vlsr(v6.uh,r6)
		v10.qf16 = vadd(v1.qf16,v28.hf)
		v31 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		v19.hf = v19.h
		v20.h = vadd(v2.h,v17.h)
		v2 = v4
		v4 = v19
	}
	{
		v21.qf16 = vmpy(v10.qf16,v5.qf16)
		v3.qf16 = vsub(v16.hf,v27.hf)
		v27.cur = vmem(r8+#-4)
	}                                       // 128-byte Folded Reload
	{
		v26.qf16 = vsub(v0.hf,v19.hf)
		q1 = vcmp.gt(v13.h,v20.h)
		v29 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		v23.qf16 = vadd(v21.qf16,v31.hf)
		v9.hf = v3.qf16
		v22 = vmux(q1,v13,v15)
		vmem(r27+#0) = v22.new
	}
	{
		r27 = r5
		v26.hf = v26.qf16
	}
	{
		v25.qf16 = vmpy(v23.qf16,v5.qf16)
		v23 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		v5.qf16 = vmpy(v26.hf,v24.hf)
		v0.hf = vmax(v23.hf,v9.hf)
	}
	{
		v11:10.qf32 = vmpy(v22.hf,v18.hf)
		v28.qf16 = vsub(v0.hf,v12.hf)
		v27.qf16 = vadd(v5.qf16,v29.hf)
	}
	{
		v5.qf16 = v26.hf
	}
	{
		v30.hf = v28.qf16
		v7.qf32 = vadd(v7.qf32,v10.qf32)
		v28 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	{
		v29.qf16 = vmpy(v27.qf16,v26.hf)
		v8.qf32 = vadd(v8.qf32,v11.qf32)
		v27.qf16 = vadd(v25.qf16,v18.hf)
	}
	{
		v19.h = v30.hf
	}
	{
		v31.qf16 = vadd(v29.qf16,v28.hf)
	}
	{
		v17.qf16 = vmpy(v31.qf16,v26.hf)
		nop
	} :endloop0
	.falign
.LBB7_39:                               //   in Loop: Header=BB7_4 Depth=1
	{
		r4 = add(r29,#2048)
		v24.hf = v27.qf16
		v14 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v21 = vmem(r4+#-7)
	}                                       // 128-byte Folded Reload
	{
		v18.h = vasl(v24.h,r21)
		v24.h += vasl(v2.h,r7)
	}
	{
		v11.uh = vlsr(v18.uh,r6)
	}
	{
		v12.h = vadd(v2.h,v11.h)
		v2 = v4
		v4 = v19
		v19 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		q2 = vcmp.gt(v13.h,v12.h)
		v12 = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		r27 = r2
		r2 = r3
		v13 = vmux(q2,v14,v24)
		vmem(r27+#0) = v13.new
	}
	{
		v15:14.qf32 = vmpy(v13.hf,v21.hf)
		v13 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		jump .LBB7_42
		v22.qf32 = vadd(v7.qf32,v14.qf32)
		v25.qf32 = vadd(v8.qf32,v15.qf32)
	}
	.falign
.LBB7_40:                               //   in Loop: Header=BB7_4 Depth=1
	{
		v23.qf32 = v7.sf
		v7.cur = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v15 = vmem(r2+#-7)
	}                                       // 128-byte Folded Reload
	{
		v24.qf32 = v7.sf
		v13 = vmem(r29+#1)
	}                                       // 128-byte Folded Reload
	{
		v12 = vmem(r29+#3)
	}                                       // 128-byte Folded Reload
	{
		v18 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		jump .LBB7_43
		v11 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	.falign
.LBB7_41:                               //   in Loop: Header=BB7_4 Depth=1
	{
		v22.qf32 = v19.sf
		v19.cur = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v21 = vmem(r3+#-7)
	}                                       // 128-byte Folded Reload
	{
		v25.qf32 = v19.sf
	}
	.falign
.LBB7_42:                               //   in Loop: Header=BB7_4 Depth=1
	{
		v8.qf16 = vadd(v17.qf16,v12.hf)
		v18 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v11 = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		v7.qf16 = vmpy(v8.qf16,v5.qf16)
	}
	{
		v14.qf16 = vadd(v7.qf16,v18.hf)
	}
	{
		v15.qf16 = vmpy(v14.qf16,v5.qf16)
	}
	{
		v16.qf16 = vadd(v15.qf16,v11.hf)
		v15 = v21
	}
	{
		v3.qf16 = vmpy(v16.qf16,v5.qf16)
	}
	{
		v1.qf16 = vadd(v3.qf16,v21.hf)
	}
	{
		v6.hf = v1.qf16
	}
	{
		v9.h = vasl(v6.h,r21)
		v6.h += vasl(v2.h,r7)
	}
	{
		v10.uh = vlsr(v9.uh,r6)
	}
	{
		v17.h = vadd(v2.h,v10.h)
		v2 = v4
	}
	{
		q3 = vcmp.gt(v19.h,v17.h)
	}
	{
		r27 = r2
		v20 = vmux(q3,v19,v6)
		vmem(r27+#0) = v20.new
	}
	{
		v7:6.qf32 = vmpy(v20.hf,v21.hf)
	}
	{
		v24.qf32 = vadd(v25.qf32,v7.qf32)
		v23.qf32 = vadd(v22.qf32,v6.qf32)
		v7 = v19
	}
	.falign
.LBB7_43:                               //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = add(r29,#2048)
		v19.hf = v2.h
	}
	{
		r2 = add(r29,#2048)
		v25 = vmem(r2+#-8)
	}                                       // 128-byte Folded Reload
	{
		v0.qf16 = vsub(v0.hf,v19.hf)
	}
	{
		v21.qf16 = vmpy(v0.qf16,v25.hf)
	}
	{
		v22.qf16 = vadd(v21.qf16,v13.hf)
	}
	{
		v22.qf16 = vmpy(v22.qf16,v0.qf16)
	}
	{
		v26.qf16 = vadd(v22.qf16,v28.hf)
	}
	{
		v5.qf16 = vmpy(v26.qf16,v0.qf16)
	}
	{
		v27.qf16 = vadd(v5.qf16,v12.hf)
	}
	{
		v27.qf16 = vmpy(v27.qf16,v0.qf16)
	}
	{
		v29.qf16 = vadd(v27.qf16,v18.hf)
	}
	{
		v30.qf16 = vmpy(v29.qf16,v0.qf16)
	}
	{
		v31.qf16 = vadd(v30.qf16,v11.hf)
	}
	{
		v28.qf16 = vmpy(v31.qf16,v0.qf16)
	}
	{
		v29.qf16 = vadd(v28.qf16,v15.hf)
	}
	{
		v12.hf = v29.qf16
	}
	{
		v13.h = vasl(v12.h,r21)
		v12.h += vasl(v2.h,r7)
	}
	{
		v4.uh = vlsr(v13.uh,r6)
	}
	{
		v30.h = vadd(v2.h,v4.h)
	}
	{
		q0 = vcmp.gt(v7.h,v30.h)
	}
	{
		v8 = vmux(q0,v7,v12)
		vmem(r27+#0) = v8.new
	}
	{
		r0 = memuh(r19+#0)
	}
	{
		v29:28.qf32 = vmpy(v8.hf,v15.hf)
	}
	{
		v31.qf32 = vadd(v23.qf32,v28.qf32)
		v4.qf32 = vadd(v24.qf32,v29.qf32)
	}
	{
		r2 = add(r29,#2048)
		v2.sf = v31.qf32
		v4.sf = v4.qf32
		vmem(r2+#-3) = v2.new
	}                                       // 128-byte Folded Spill
	{
		call __extendhfsf2
		vmem(r2+#-4) = v4
	}                                       // 128-byte Folded Spill
	.falign
// %bb.44:                              //   in Loop: Header=BB7_4 Depth=1
	{
		call __extendhfsf2
		r18 = r0
		r0 = memuh(r19+#2)
	}
	.falign
// %bb.45:                              //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = add(r29,#2048)
	}
	{
		r2 = add(r29,#2048)
		v5 = vmem(r2+#-4)
	}                                       // 128-byte Folded Reload
	{
		v12 = vmem(r2+#-3)
	}                                       // 128-byte Folded Reload
	.falign
.LBB7_46:                               // %softmax_row_pair.exit
                                        //   in Loop: Header=BB7_4 Depth=1
	{
		r2 = #64
		v12.qf32 = v12.sf
		v5.qf32 = v5.sf
		r7 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r20,#1)
	}
	{
		v23.sf = v12.qf32
		v24.sf = v5.qf32
	}
	{
		v12.sf = v12.qf32
		v5.sf = v5.qf32
	}
	{
		v7 = valign(v23,v23,#4)
	}
	{
		v14 = valign(v24,v24,#4)
	}
	{
		v15.qf32 = vadd(v12.sf,v7.sf)
	}
	{
		v16.qf32 = vadd(v5.sf,v14.sf)
	}
	{
		v3.sf = v15.qf32
	}
	{
		v1.sf = v16.qf32
	}
	{
		v6 = vror(v3,r22)
	}
	{
		v9 = vror(v1,r22)
	}
	{
		v10.qf32 = vadd(v15.qf32,v6.sf)
	}
	{
		v17.qf32 = vadd(v16.qf32,v9.sf)
	}
	{
		v20.sf = v10.qf32
	}
	{
		v19.sf = v17.qf32
	}
	{
		v0 = vror(v20,r24)
	}
	{
		v21 = vror(v19,r24)
	}
	{
		v22.qf32 = vadd(v10.qf32,v0.sf)
	}
	{
		v25.qf32 = vadd(v17.qf32,v21.sf)
	}
	{
		v26.sf = v22.qf32
	}
	{
		v30.sf = v25.qf32
	}
	{
		v27 = vror(v26,r26)
	}
	{
		v28 = vror(v30,r26)
	}
	{
		v29.qf32 = vadd(v22.qf32,v27.sf)
	}
	{
		v30.qf32 = vadd(v25.qf32,v28.sf)
	}
	{
		v31.sf = v29.qf32
	}
	{
		v18.sf = v30.qf32
	}
	{
		v11 = vror(v31,r2)
	}
	{
		r2 = addasl(r7,r17,#2)
		v31 = vror(v18,r2)
	}
	{
		v13.qf32 = vadd(v29.qf32,v11.sf)
	}
	{
		v4.qf32 = vadd(v30.qf32,v31.sf)
	}
	{
		v2.sf = v13.qf32
	}
	{
		v8.sf = v4.qf32
	}
	{
		r3 = vextract(v2,r23)
	}
	{
		r4 = vextract(v8,r23)
	}
	{
		r6 = memw(r2+#4)
		r5 = memw(r7+r17<<#2)
	}
	{
		r9:8 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r4 += sfmpy(r6,r0)
		r2 = add(r29,#2048)
		p1 = cmp.gtu(r8,r20)
		memw(r2+#4) = r4.new
	}
	{
		r3 += sfmpy(r5,r18)
		r8 = #10
		v1 = vmem(r29+#7)
		memw(r7+r17<<#2) = r3.new
	}                                       // 128-byte Folded Reload
	{
		if (p1) jump:nt .LBB7_4
		v9 = vmem(r2+#-5)
	}                                       // 128-byte Folded Reload
	.falign
.LBB7_47:                               // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	softmax_worker, .Lfunc_end7-softmax_worker
                                        // -- End function
	.falign
	.type	pquant_worker,@function         // -- Begin function pquant_worker
pquant_worker:                          // @pquant_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		r2 = memw(r2+#76)
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r22 = asl(r2,#1)
		r3:2 = combine(r21,r20)
		memd(r29+#0) = r23:22
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
	}
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r22,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r2 = #15360
		if (p0.new) r8 = sub(r0,r18)
		p0 = cmp.gtu(r0,r18); if (!p0.new) jump:t .LBB8_14
	}
// %bb.3:                               // %for.body.lr.ph
	{
		r4 = ##998277249
		r7 = ##2129859015
	}
	{
		r5 = ##1065353216
		r6 = ##1073741824
	}
	{
		v1.h = vsplat(r2)
		v4 = vsplat(r6)
	}
	{
		v5 = vsplat(r7)
		v2 = vsplat(r4)
		r2 = add(r16,#52)
		v0 = vxor(v0,v0)
	}
	{
		v3 = vsplat(r5)
		r3 = #8
		r5:4 = combine(#32,#16)
		r6 = #64
	}
	{
		r7 = ##1262485504
	}
	{
		loop1(.LBB8_4,r8)
	}
	.falign
.LBB8_4:                                // Block address taken
                                        // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB8_5 Depth 2
                                        //       Child Loop BB8_7 Depth 3
                                        //       Child Loop BB8_11 Depth 3
	{
		r12 = extractu(r18,#21,#1)
		r14 = r18
		r15 = memw(r16+#20)
		r13 = memw(r16+#12)
	}
	{
		r0 = extractu(r12,#19,#0)
		r14 = and(#32,asl(r14,#5))
		r8 = memw(r16+#80)
		r1 = memw(r16+#128)
	}
	{
		r1 += asl(r0,#13)
		r9 = #0
		r28 = memw(r16+#664)
		r10 = memw(r16+#648)
	}
	{
		r11 = mpyi(r12,r8)
		r12 = addasl(r1,r14,#7)
		r17 = memw(r15+#16)
		r22 = memw(r13+#4)
	}
	{
		r0 = mpyi(r18,r8)
		r14 = asl(r14,#5)
		r20 = memw(r16+#656)
		r13 = memw(r2+r28<<#2)
	}
	{
		r1 = mpyi(r17,r10)
		r11 = asl(r11,#11)
		r19 = memw(r16+#0)
		r21 = memw(r16+#60)
	}
	{
		r10 = mpyi(r22,r20)
		r13 = add(r19,r13)
		r21 = add(r19,r21)
		r28 = memw(r15+#52)
	}
	{
		r17 = addasl(r28,r1,#2)
		r13 += asl(r0,#11)
		p0 = cmp.eq(r8,#0)
		r15 = add(r12,#128)
	}
	{
		r10 = addasl(r17,r10,#2)
		r14 += add(r21,r11)
		r28 = add(r12,#256)
		r0 = add(r12,#384)
	}
	{
		r1 = add(r13,#128)
	}
	.falign
.LBB8_5:                                // %for.body.i
                                        //   Parent Loop BB8_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB8_7 Depth 3
                                        //       Child Loop BB8_11 Depth 3
	{
		r11 = addasl(r1,r9,#7)
		v28 = v0
		v27 = v0
		v21 = v0
	}
	{
		r21 = addasl(r13,r9,#7)
		r20 = add(r8,#-1)
		if (p0) jump:nt .LBB8_9
		v20 = v0
	}
// %bb.6:                               // %for.body15.i
                                        //   in Loop: Header=BB8_5 Depth=2
	{
		v13:12.qf32 = vmpy(v25.hf,v1.hf)
		r19 = add(r11,#2048)
		r17 = add(r13,#2048)
		v25.cur = vmem(r11+#0)
	}
	{
		loop0(.LBB8_7,r20)
		p1 = cmp.gtu(r8,#1)
		v15 = vmemu(r10+#0)
	}
	{
		v17:16.qf32 = vmpy(v26.hf,v1.hf)
		r20 = r10
		v26.cur = vmem(r21+#0)
	}
	{
		v7 = v0
		v8 = v0
		v9 = v0
		v10 = v0
	}
	{
		if (!p1) jump:nt .LBB8_8
		v26.sf = v13.qf32
	}
	.falign
.LBB8_7:                                // %for.body15.i
                                        //   Parent Loop BB8_4 Depth=1
                                        //     Parent Loop BB8_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r21 = addasl(r17,r9,#7)
		v31.qf32 = vmpy(v26.sf,v15.sf)
		v27.sf = v12.qf32
		v28.sf = v17.qf32
	}
	{
		v13:12.qf32 = vmpy(v29.hf,v1.hf)
		r20 = add(r20,#128)
		v30.sf = v16.qf32
		v29.cur = vmem(r19+#0)
	}
	{
		v6.qf32 = vmpy(v27.sf,v15.sf)
		r19 = add(r19,#2048)
		r17 = add(r17,#2048)
		v18.sf = v31.qf32
	}
	{
		v11.qf32 = vmpy(v30.sf,v15.sf)
		v26.sf = v13.qf32
		v10.sf = vmax(v10.sf,v18.sf)
	}
	{
		v14.qf32 = vmpy(v28.sf,v15.sf)
		v19.sf = v6.qf32
		v15 = vmem(r21+#0)
	}
	{
		v17:16.qf32 = vmpy(v15.hf,v1.hf)
		v20.sf = v11.qf32
		v15 = vmemu(r20+#0)
	}
	{
		v21.sf = v14.qf32
		v9.sf = vmax(v9.sf,v19.sf)
		v7.sf = vmax(v7.sf,v20.sf)
	}
	{
		nop
		v8.sf = vmax(v8.sf,v21.sf)
	} :endloop0
	.falign
.LBB8_8:                                //   in Loop: Header=BB8_5 Depth=2
	{
		v11.qf32 = vmpy(v26.sf,v15.sf)
		v13.sf = v16.qf32
		v16.sf = v17.qf32
	}
	{
		v12.sf = v12.qf32
	}
	{
		v22.qf32 = vmpy(v13.sf,v15.sf)
		v23.sf = v11.qf32
	}
	{
		v24.qf32 = vmpy(v16.sf,v15.sf)
		v20.sf = vmax(v10.sf,v23.sf)
	}
	{
		v25.qf32 = vmpy(v12.sf,v15.sf)
		v26.sf = v22.qf32
	}
	{
		v27.sf = v24.qf32
		v28.sf = vmax(v7.sf,v26.sf)
	}
	{
		v29.sf = v25.qf32
		v27.sf = vmax(v8.sf,v27.sf)
	}
	{
		v21.sf = vmax(v9.sf,v29.sf)
	}
	.falign
.LBB8_9:                                // %for.cond.cleanup14.i
                                        //   in Loop: Header=BB8_5 Depth=2
	{
		r17 = asl(r9,#8)
		v29 = valign(v28,v28,#4)
	}
	{
		r19 = add(r12,r17)
		r20 = add(r15,r17)
		v30 = valign(v27,v27,#4)
		v31.sf = vmax(v28.sf,v29.sf)
	}
	{
		r21 = add(r28,r17)
		r17 = add(r0,r17)
		v6 = valign(v21,v21,#4)
		v7.sf = vmax(v27.sf,v30.sf)
	}
	{
		v8 = valign(v20,v20,#4)
		v9.sf = vmax(v21.sf,v6.sf)
	}
	{
		v10 = vror(v31,r3)
		v11.sf = vmax(v20.sf,v8.sf)
	}
	{
		v12 = vror(v7,r3)
		v13.sf = vmax(v31.sf,v10.sf)
	}
	{
		v14 = vror(v9,r3)
		v15.sf = vmax(v7.sf,v12.sf)
	}
	{
		v16 = vror(v11,r3)
		v17.sf = vmax(v9.sf,v14.sf)
	}
	{
		v18 = vror(v13,r4)
		v19.sf = vmax(v11.sf,v16.sf)
	}
	{
		v31 = vror(v15,r4)
		v21.sf = vmax(v13.sf,v18.sf)
	}
	{
		v22 = vror(v17,r4)
		v23.sf = vmax(v15.sf,v31.sf)
	}
	{
		v24 = vror(v19,r4)
		v25.sf = vmax(v17.sf,v22.sf)
	}
	{
		v26 = vror(v21,r5)
		v27.sf = vmax(v19.sf,v24.sf)
	}
	{
		v24 = vror(v25,r5)
		v22.sf = vmax(v21.sf,v26.sf)
	}
	{
		v20 = vror(v23,r5)
		v7.sf = vmax(v25.sf,v24.sf)
	}
	{
		v6 = vror(v27,r5)
		v26.sf = vmax(v23.sf,v20.sf)
	}
	{
		v8 = vror(v22,r6)
		v9.sf = vmax(v27.sf,v6.sf)
	}
	{
		v10 = vror(v26,r6)
		v11.sf = vmax(v22.sf,v8.sf)
	}
	{
		v12 = vror(v7,r6)
		v13.sf = vmax(v26.sf,v10.sf)
		q2 = vcmp.gt(v11.w,v0.w)
	}
	{
		v16.qf32 = vmpy(v11.sf,v2.sf)
		v14 = vror(v9,r6)
		v15.sf = vmax(v7.sf,v12.sf)
	}
	{
		v18.qf32 = vmpy(v13.sf,v2.sf)
		v17.sf = vmax(v9.sf,v14.sf)
		q1 = vcmp.gt(v13.w,v0.w)
	}
	{
		v19.qf32 = vmpy(v15.sf,v2.sf)
		v28.sf = v16.qf32
		q0 = vcmp.gt(v15.w,v0.w)
	}
	{
		v27.qf32 = vmpy(v17.sf,v2.sf)
		v29.sf = v18.qf32
		q3 = vcmp.gt(v17.w,v0.w)
	}
	{
		v30.sf = v19.qf32
		v11 = vmux(q2,v28,v3)
		v12 = vmux(q1,v29,v3)
		vmem(r19+#0) = v11.new
	}
	{
		if (!p0) r19 = add(r10,#0)
		v31.sf = v27.qf32
		v13 = vmux(q0,v30,v3)
		vmem(r21+#0) = v13.new
	}
	{
		v14 = vmux(q3,v31,v3)
		vmem(r17+#0) = v14.new
	}
	{
		if (!p0) r20 = add(r13,#0)
		if (p0) jump:nt .LBB8_12
		vmem(r20+#0) = v12
	}
// %bb.10:                              // %for.body57.lr.ph.i
                                        //   in Loop: Header=BB8_5 Depth=2
	{
		v25.w = vsub(v5.w,v11.w)
		v23.w = vsub(v5.w,v12.w)
		v24.w = vsub(v5.w,v13.w)
		v22.w = vsub(v5.w,v14.w)
	}
	{
		r17 = addasl(r14,r9,#6)
		v6 = vsplat(r7)
	}
	{
		loop0(##.LBB8_11,r8)
		v7.qf32 = vmpy(v25.sf,v11.sf)
	}
	{
		v8.qf32 = vmpy(v23.sf,v12.sf)
	}
	{
		v9.qf32 = vmpy(v24.sf,v13.sf)
		v10.sf = v7.qf32
	}
	{
		v28.qf32 = vmpy(v22.sf,v14.sf)
		v30.sf = v8.qf32
	}
	{
		v31.sf = v9.qf32
		v18.qf32 = vsub(v4.sf,v10.sf)
	}
	{
		v15.sf = v28.qf32
		v19.qf32 = vsub(v4.sf,v30.sf)
	}
	{
		v20.qf32 = vsub(v4.sf,v31.sf)
		v21.sf = v18.qf32
	}
	{
		v16.qf32 = vsub(v4.sf,v15.sf)
		v17.sf = v19.qf32
	}
	{
		v25.qf32 = vmpy(v25.sf,v21.sf)
		v26.sf = v20.qf32
	}
	{
		v23.qf32 = vmpy(v23.sf,v17.sf)
		v27.sf = v16.qf32
	}
	{
		v24.qf32 = vmpy(v24.sf,v26.sf)
		v29.sf = v25.qf32
	}
	{
		v22.qf32 = vmpy(v22.sf,v27.sf)
		v7.sf = v23.qf32
	}
	{
		v15.qf32 = vmpy(v29.sf,v11.sf)
		v27.sf = v24.qf32
	}
	{
		v21.qf32 = vmpy(v7.sf,v12.sf)
		v20.sf = v22.qf32
	}
	{
		v26.qf32 = vmpy(v27.sf,v13.sf)
		v27.sf = v15.qf32
	}
	{
		v18.qf32 = vmpy(v20.sf,v14.sf)
		v29.sf = v21.qf32
	}
	{
		v19.sf = v26.qf32
		v31.qf32 = vsub(v4.sf,v27.sf)
	}
	{
		v8.sf = v18.qf32
		v16.qf32 = vsub(v4.sf,v29.sf)
	}
	{
		v17.qf32 = vmpy(v25.qf32,v31.qf32)
		v9.qf32 = vsub(v4.sf,v19.sf)
	}
	{
		v25.qf32 = vmpy(v23.qf32,v16.qf32)
		v10.qf32 = vsub(v4.sf,v8.sf)
	}
	{
		v23.qf32 = vmpy(v24.qf32,v9.qf32)
		v15.sf = v17.qf32
	}
	{
		v29.qf32 = vmpy(v22.qf32,v10.qf32)
		v26.sf = v25.qf32
	}
	{
		v27.qf32 = vmpy(v15.sf,v11.sf)
		v7.sf = v23.qf32
	}
	{
		v28.qf32 = vmpy(v26.sf,v12.sf)
		v30.sf = v29.qf32
	}
	{
		v31.qf32 = vmpy(v7.sf,v13.sf)
		v20.sf = v27.qf32
	}
	{
		v21.qf32 = vmpy(v30.sf,v14.sf)
		v22.sf = v28.qf32
	}
	{
		v24.sf = v31.qf32
		v26.qf32 = vsub(v4.sf,v20.sf)
	}
	{
		v27.sf = v21.qf32
		v18.qf32 = vsub(v4.sf,v22.sf)
	}
	{
		v16.qf32 = vmpy(v17.qf32,v26.qf32)
		v30.qf32 = vsub(v4.sf,v24.sf)
	}
	{
		v17.qf32 = vmpy(v25.qf32,v18.qf32)
		v19.qf32 = vsub(v4.sf,v27.sf)
	}
	{
		v18.qf32 = vmpy(v23.qf32,v30.qf32)
	}
	{
		v19.qf32 = vmpy(v29.qf32,v19.qf32)
	}
	.falign
.LBB8_11:                               // Block address taken
                                        // %for.body57.i
                                        //   Parent Loop BB8_4 Depth=1
                                        //     Parent Loop BB8_5 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r21 = addasl(r20,r9,#7)
		v9:8.qf32 = vmpy(v20.hf,v1.hf)
		r20 = add(r20,#2048)
		v20.cur = vmem(r11+#0)
	}
	{
		r19 = add(r19,#128)
		r11 = add(r11,#2048)
		v21 = vmemu(r19+#0)
	}
	{
		v11:10.qf32 = vmpy(v26.hf,v1.hf)
		v25.sf = v8.qf32
		v26.cur = vmem(r21+#0)
	}
	{
		v27.sf = v9.qf32
	}
	{
		v29.qf32 = vmpy(v25.sf,v21.sf)
		v23.sf = v10.qf32
		v24.sf = v11.qf32
	}
	{
		v22.qf32 = vmpy(v27.sf,v21.sf)
	}
	{
		v23.qf32 = vmpy(v23.sf,v21.sf)
	}
	{
		v7.qf32 = vmpy(v24.sf,v21.sf)
	}
	{
		v12.qf32 = vmpy(v29.qf32,v18.qf32)
	}
	{
		v25.qf32 = vmpy(v22.qf32,v19.qf32)
	}
	{
		v13.qf32 = vmpy(v23.qf32,v16.qf32)
		v14.qf32 = vadd(v12.qf32,v6.sf)
	}
	{
		v26.qf32 = vmpy(v7.qf32,v17.qf32)
		v27.qf32 = vadd(v25.qf32,v6.sf)
	}
	{
		v28.qf32 = vadd(v13.qf32,v6.sf)
		v31.sf = v14.qf32
	}
	{
		v30.qf32 = vadd(v26.qf32,v6.sf)
		v15.sf = v27.qf32
		v29.w = vsub(v31.w,v6.w)
	}
	{
		v8.sf = v28.qf32
		v31.w = vsub(v15.w,v6.w)
	}
	{
		v9.sf = v30.qf32
		v10.w = vsub(v8.w,v6.w)
	}
	{
		v22.h = vpack(v31.w,v29.w):sat
		v11.w = vsub(v9.w,v6.w)
	}
	{
		v27.h = vpack(v11.w,v10.w):sat
	}
	{
		r17 = add(r17,#2048)
		v31.ub = vpack(v22.h,v27.h):sat
		vmem(r17+#0) = v31.new
	} :endloop0
	.falign
.LBB8_12:                               // %for.cond.cleanup56.i
                                        //   in Loop: Header=BB8_5 Depth=2
	{
		p1 = cmp.gtu(r9,#13)
		r9 = add(r9,#2)
		if (!p1.new) jump:t .LBB8_5
	}
// %bb.13:                              // %pquant_unit.exit
                                        //   in Loop: Header=BB8_4 Depth=1
	{
		r18 = add(r18,#1)
		nop
		nop
	} :endloop1
	.falign
.LBB8_14:                               // %for.cond.cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	pquant_worker, .Lfunc_end8-pquant_worker
                                        // -- End function
	.falign
	.type	store_worker,@function          // -- Begin function store_worker
store_worker:                           // @store_worker
// %bb.0:                               // %entry
	{
		r16 = r1
		memd(r29+#-16) = r17:16
		allocframe(#40)
	}                                       // 8-byte Folded Spill
	{
		r20 = r2
		r21 = memw(r2+#0)
		memd(r29+#16) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(#0,r0)
		memd(r29+#8) = r23:22
		memd(r29+#24) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r21+#12)
		memd(r29+#0) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r3:2 = combine(r19,r18)
		r22 = memw(r2+#12)
	}
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
	}
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r16,#1)
		r17:16 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r22,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.2:                               // %entry
	{
		r19:18 = combine(r1,r0)
	}
	{
		p1 = cmp.gtu(r18,r16); if (!p1.new) jump:t .LBB9_11
		if (p1.new) r19 = memw(r20+#4)
		if (p1.new) r2 = memw(r21+#8)
	}
// %bb.3:                               // %for.body.lr.ph.i
	{
		r22 = ##1065353216
		r20 = memw(r20+#8)
		r23 = memw(r2+#20)
	}
	.falign
.LBB9_4:                                // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB9_9 Depth 2
	{
		r2 = memw(r21+#12)
	}
	{
		r17 = memw(r2+#8)
		r24 = memw(r2+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.5:                               // %for.body.i
                                        //   in Loop: Header=BB9_4 Depth=1
	{
		r2 = mpyi(r17,r24)
		if (!cmp.gtu(r2.new,r16)) jump:t .LBB9_10
	}
// %bb.6:                               // %lor.lhs.false.i.i
                                        //   in Loop: Header=BB9_4 Depth=1
	{
		r2 = r0
		r3 = memw(r21+#8)
	}
	{
		r2 += mpyi(r24,r20)
	}
	{
		r4 = memw(r3+#0)
		if (!cmp.gtu(r4.new,r2)) jump:t .LBB9_10
	}
// %bb.7:                               // %if.end.i.i
                                        //   in Loop: Header=BB9_4 Depth=1
	{
		r5 = ##1065353216
		r4 = memw(r21+#112)
	}
	{
		r6 = ##1065353216
	}
	{
		r4 = memw(r4+r16<<#2)
	}
	{
		r7,p0 = sfrecipa(r22,r4)
		r8 = sffixupd(r22,r4)
	}
	{
		r9 = sffixupn(r22,r4)
	}
	{
		r5 -= sfmpy(r8,r7):lib
	}
	{
		r4 = and(r9,##-2147483648)
	}
	{
		r7 += sfmpy(r5,r7):lib
		r5 = r9
	}
	{
		r4 += sfmpy(r9,r7):lib
		r6 -= sfmpy(r8,r7):lib
	}
	{
		r7 += sfmpy(r6,r7):lib
		r5 -= sfmpy(r8,r4):lib
	}
	{
		r4 += sfmpy(r5,r7):lib
	}
	{
		r9 -= sfmpy(r4,r8):lib
	}
	{
		r4 += sfmpy(r9,r7,p0):scale
		r5 = memw(r21+#84)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB9_10
	}
// %bb.8:                               // %for.body13.preheader.i
                                        //   in Loop: Header=BB9_4 Depth=1
	{
		v0 = vsplat(r4)
		r6 = r16
		r5 = memw(r21+#16)
		r3 = memw(r3+#20)
	}
	{
		r6 -= mpyi(r0,r17)
		r4 = memw(r21+#0)
		r8 = memw(r21+#64)
	}
	{
		r6 += mpyi(r17,r19)
		r3 = mpyi(r3,r16)
		r7 = memw(r5+#16)
		r5 = memw(r5+#12)
	}
	{
		r4 = add(r4,r8)
	}
	{
		r2 = mpyi(r7,r2)
		r6 = mpyi(r6,r23)
	}
	{
		r5 = addasl(r5,r2,#2)
		r3 = addasl(r4,r3,#2)
		r2 = #0
	}
	{
		r4 = addasl(r5,r6,#2)
	}
	.balign 32
.LBB9_9:                                // %for.body13.i
                                        //   Parent Loop BB9_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v2.qf32 = vmpy(v1.sf,v0.sf)
		r2 = add(r2,#1)
		v1.cur = vmem(r3++#1)
	}
	{
		v3.sf = v2.qf32
	}
	{
		vmemu(r4++#1) = v3
	}
	{
		r5 = memw(r21+#84)
		if (cmp.gtu(r5.new,r2)) jump:t .LBB9_9
	}
	.falign
.LBB9_10:                               // %cleanup.i
                                        //   in Loop: Header=BB9_4 Depth=1
	{
		r16 = add(r16,#1)
		if (!cmp.eq(r16.new,r18)) jump:t .LBB9_4
	}
	.falign
.LBB9_11:                               // %phase_store_rows.exit
	{
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#0)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end9:
	.size	store_worker, .Lfunc_end9-store_worker
                                        // -- End function
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym dequant_worker
	.addrsig_sym softmax_worker
	.addrsig_sym pquant_worker
	.addrsig_sym store_worker
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#dequant_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#softmax_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#pquant_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#store_worker#(void)#(i32, i32, ptr)#1##"

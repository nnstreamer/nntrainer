	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hvx_attn_decode_q.c"
	.section	.rodata,"a",@progbits
	.p2align	7, 0x0                          // -- Begin function hvx_attn_decode_q
.LCPI0_0:
	.word	0                               // 0x0
	.word	1                               // 0x1
	.word	2                               // 0x2
	.word	3                               // 0x3
	.word	4                               // 0x4
	.word	5                               // 0x5
	.word	6                               // 0x6
	.word	7                               // 0x7
	.word	8                               // 0x8
	.word	9                               // 0x9
	.word	10                              // 0xa
	.word	11                              // 0xb
	.word	12                              // 0xc
	.word	13                              // 0xd
	.word	14                              // 0xe
	.word	15                              // 0xf
	.word	16                              // 0x10
	.word	17                              // 0x11
	.word	18                              // 0x12
	.word	19                              // 0x13
	.word	20                              // 0x14
	.word	21                              // 0x15
	.word	22                              // 0x16
	.word	23                              // 0x17
	.word	24                              // 0x18
	.word	25                              // 0x19
	.word	26                              // 0x1a
	.word	27                              // 0x1b
	.word	28                              // 0x1c
	.word	29                              // 0x1d
	.word	30                              // 0x1e
	.word	31                              // 0x1f
	.text
	.globl	hvx_attn_decode_q
	.falign
	.type	hvx_attn_decode_q,@function
hvx_attn_decode_q:                      // @hvx_attn_decode_q
// %bb.0:                               // %entry
	{
		r5 = ##-2147449843
		r4 = r0
		allocframe(r29,#896):raw
	}
	{
		p1 = cmp.eq(r1,#0)
		r29 = and(r29,#-128)
		r0 = add(r5,#-32767)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		memd(r30+#-8) = r17:16
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB0_13
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %land.lhs.true
	{
		p1 = cmp.eq(r4,#0)
		r19 = memw(r1+#20)
	}
	{
		p0 = cmp.eq(r19,#0); if (p0.new) jump:nt .LBB0_4
		if (p1) jump:nt .LBB0_13
	}
// %bb.3:                               // %land.lhs.true2
	{
		r5 = memw(r19+#76)
		if (cmp.eq(r5.new,#0)) jump:t .LBB0_5
	}
	{
		jump .LBB0_13
	}
	.falign
.LBB0_4:                                // %if.end
	{
		if (p1) jump:nt .LBB0_13
	}
	.falign
.LBB0_5:                                // %lor.lhs.false7
	{
		r5 = memw(r1+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB0_13
	}
// %bb.6:                               // %lor.lhs.false9
	{
		if (p0) jump:nt .LBB0_13
	}
// %bb.7:                               // %lor.lhs.false9
	{
		r5 = memw(r1+#12)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB0_13
	}
// %bb.8:                               // %if.end15
	{
		r20 = memw(r4+#0)
		if (cmp.eq(r20.new,#0)) jump:nt .LBB0_13
	}
// %bb.9:                               // %lor.lhs.false18
	{
		r21 = r0
		r23:22 = combine(r1,r4)
		r17 = memw(r4+#16)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB0_13
	}
// %bb.10:                              // %lor.lhs.false20
	{
		r1 = r17
		r18 = r3
		r16 = r2
		r0 = memw(r4+#12)
	}
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.11:                              // %lor.lhs.false20
	{
		r3 = #127
		if (!p1.new) r0 = add(r21,#0)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB0_14
	}
	.falign
.LBB0_13:                               // %return
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB0_14:                               // %lor.lhs.false23
	{
		r0 = r21
		r2 = memw(r22+#20)
	}
	{
		r3 = add(r2,#-1)
		if (cmp.gtu(r3.new,r3)) jump:nt .LBB0_13
	}
// %bb.15:                              // %lor.lhs.false23
	{
		r4 = r22
		r3 = and(r2,#31)
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB0_13
	}
// %bb.16:                              // %lor.lhs.false32
	{
		r5 = memw(r22+#4)
		r3 = memw(r22+#8)
	}
	{
		r5 = add(r5,r20)
		if (cmp.gtu(r5.new,r3)) jump:t .LBB0_13
	}
// %bb.17:                              // %lor.lhs.false35
	{
		r5 = #0
		r4 = memw(r4+#28)
	}
	{
		p1 = sfcmp.uo(r5,r4)
		p0 = sfcmp.gt(r5,r4)
	}
	{
		p1 = and(p0,!p1)
		if (p1.new) jump:t .LBB0_13
	}
// %bb.18:                              // %lor.lhs.false37
	{
		r4 = memw(r19+#20)
		if (!cmp.eq(r4.new,r17)) jump:t .LBB0_13
	}
// %bb.19:                              // %lor.lhs.false41
	{
		r4 = memw(r19+#24)
		if (!cmp.eq(r4.new,r2)) jump:t .LBB0_13
	}
// %bb.20:                              // %lor.lhs.false45
	{
		r2 = memw(r19+#16)
		if (cmp.gtu(r3,r2.new)) jump:t .LBB0_13
	}
// %bb.21:                              // %if.end49
	//# InlineAsm Start
	{
		r21:20 = c31:30
	}
	//# InlineAsm End
	{
		r1 = #0
		r2 = #512
		r17 = #0
		r0 = add(r29,#128)
	}
	{
		call memset
	}
	.falign
// %bb.22:                              // %if.end49
	{
		r2 = memw(r22+#20)
		memw(r29+#132) = r23
	}
	{
		memw(r29+#128) = r22
		memw(r29+#136) = r19
	}
	{
		call sqrtf
		r0 = convert_uw2sf(r2)
	}
	.falign
// %bb.23:                              // %if.end49
	{
		r2 = ##1069066811
		r4 = ##1065353216
	}
	{
		r6,p0 = sfrecipa(r2,r0)
		r5 = ##1065353216
		r3 = r22
	}
	{
		r7 = sffixupd(r2,r0)
		r8 = sffixupn(r2,r0)
	}
	{
		r4 -= sfmpy(r7,r6):lib
		r9 = r8
		r12 = r8
	}
	{
		r9 = insert(r17,#31,#0)
		r6 += sfmpy(r4,r6):lib
	}
	{
		r4 = add(pc,##.LCPI0_0@PCREL)
	}
	{
		r9 += sfmpy(r8,r6):lib
		r5 -= sfmpy(r7,r6):lib
	}
	{
		r4 = ##1065353216
		v0.cur = vmem(r4+#0)
		vmem(r29+#5) = v0
	}
	{
		r6 += sfmpy(r5,r6):lib
		r12 -= sfmpy(r7,r9):lib
		r5 = memw(r22+#28)
	}
	{
		p1 = sfcmp.uo(r5,r17)
		p2 = sfcmp.gt(r5,r17)
	}
	{
		r9 += sfmpy(r12,r6):lib
		p1 = and(p2,!p1)
		if (p1.new) r1 = ##1077455419
	}
	{
		r8 -= sfmpy(r9,r7):lib
	}
	{
		r9 += sfmpy(r8,r6,p0):scale
		if (!p1) jump:nt .LBB0_25
		memw(r29+#140) = r9.new
	}
// %bb.24:                              // %if.then61
	{
		r2 = sfmpy(r5,r2)
	}
	{
		r6 = ##1065353216
		r7 = #1
		memw(r29+#512) = r7.new
	}
	{
		r0,p1 = sfrecipa(r1,r2)
		r8 = sffixupd(r1,r2)
	}
	{
		r5 = sffixupn(r1,r2)
		v1 = vsplat(r2)
		vmem(r29+#2) = v1.new
	}
	{
		r6 -= sfmpy(r8,r0):lib
	}
	{
		r9 = r5
		r12 = r5
	}
	{
		r9 = insert(r17,#31,#0)
		r0 += sfmpy(r6,r0):lib
	}
	{
		r9 += sfmpy(r5,r0):lib
		r4 -= sfmpy(r8,r0):lib
	}
	{
		r0 += sfmpy(r4,r0):lib
		r12 -= sfmpy(r8,r9):lib
	}
	{
		r9 += sfmpy(r12,r0):lib
	}
	{
		r5 -= sfmpy(r9,r8):lib
	}
	{
		r9 += sfmpy(r5,r0,p1):scale
	}
	{
		v2 = vsplat(r9)
		vmem(r29+#3) = v2.new
	}
	.falign
.LBB0_25:                               // %if.end66
	{
		r2 = add(r29,#128)
		r0 = r16
		r4 = memw(r3+#0)
		r3 = memw(r3+#12)
	}
	{
		r1 = add(pc,##decode_worker@PCREL)
	}
	{
		r3 = mpyi(r3,r4)
		call hvx_worker_pool_run
	}
	.falign
// %bb.26:                              // %if.end66
	{
		r3 = #10
		p0 = cmp.eq(r18,#0); if (p0.new) jump:nt .LBB0_28
	}
// %bb.27:                              // %if.then71
	{
		r2 = ##-1431622999
	}
	{
		r1:0 = mpyu(r20,r3)
		r3 = add(r2,#-32766)
		r2 = add(r2,#-32767)
	}
	{
		r1 += mpyi(r21,#10)
	}
	{
		r5:4 = mpyu(r0,r3)
		r7:6 = mpyu(r0,r2)
	}
	{
		r16 = r5
	}
	{
		r5:4 = combine(r17,r16)
		r16 = r6
	}
	{
		r5:4 += mpyu(r1,r3)
	}
	{
		r5:4 = add(r5:4,r17:16)
	}
	{
		r16 = r5
	}
	{
		r5:4 = combine(r17,r16)
		r16 = r7
	}
	{
		r5:4 += mpyu(r1,r2)
	}
	{
		r1:0 = add(r5:4,r17:16)
	}
	{
		r1:0 = lsr(r1:0,#7)
	}
	//# InlineAsm Start
	{
		r5:4 = c31:30
	}
	//# InlineAsm End
	{
		r7:6 = combine(#0,#10)
	}
	{
		r9:8 = mpyu(r4,r6)
	}
	{
		r9 += mpyi(r5,#10)
	}
	{
		r13:12 = mpyu(r8,r3)
		r5:4 = mpyu(r8,r2)
	}
	{
		r6 = r13
	}
	{
		r13:12 = combine(r7,r6)
		r6 = r4
	}
	{
		r13:12 += mpyu(r9,r3)
	}
	{
		r13:12 = add(r13:12,r7:6)
	}
	{
		r6 = r13
	}
	{
		r13:12 = combine(r7,r6)
		r6 = r5
	}
	{
		r13:12 += mpyu(r9,r2)
	}
	{
		r3:2 = add(r13:12,r7:6)
	}
	{
		r3:2 = lsr(r3:2,#7)
	}
	{
		r1:0 = sub(r3:2,r1:0)
	}
	{
		memd(r18+#0) = r1:0
	}
	.falign
.LBB0_28:                               // %if.end73
	{
		r0 = #0 ; jump .LBB0_13
	}
.Lfunc_end0:
	.size	hvx_attn_decode_q, .Lfunc_end0-hvx_attn_decode_q
                                        // -- End function
	.falign
	.type	decode_worker,@function         // -- Begin function decode_worker
decode_worker:                          // @decode_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		memd(r29+#8) = r21:20
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r2+#0)
		r2 = memw(r2+#12)
	}
	{
		r22 = mpyi(r2,r3)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
	}
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r22,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.2:                               // %entry
	{
		r21:20 = combine(r1,r0)
	}
	{
		p0 = cmp.gtu(r20,r18); if (!p0.new) jump:t .LBB1_6
	}
	.falign
.LBB1_3:                                // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+#0)
	}
	{
		r17 = memw(r2+#12)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r17,r18)
	}
	.falign
// %bb.4:                               // %for.body
                                        //   in Loop: Header=BB1_3 Depth=1
	{
		r2 = r18
		r1 = r0
	}
	{
		r2 -= mpyi(r0,r17)
		call decode_unit
		r0 = r16
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB1_3 Depth=1
	{
		r18 = add(r18,#1)
		if (cmp.gtu(r20,r18.new)) jump:t .LBB1_3
	}
	.falign
.LBB1_6:                                // %for.cond.cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	decode_worker, .Lfunc_end1-decode_worker
                                        // -- End function
	.falign
	.type	decode_unit,@function           // -- Begin function decode_unit
decode_unit:                            // @decode_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2432):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r19:18 = memd(r0+#0)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r20 = r1
		r17 = r0
		memd(r30+#-8) = r17:16
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r24 = r2
		r16 = memw(r0+#8)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r0 = memw(r18+#12)
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r1 = memw(r18+#16)
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r22 = memw(r18+#20)
	}
	.falign
// %bb.1:                               // %entry
	{
		call __hexagon_udivsi3
		r1 = r0
		r0 = r24
	}
	.falign
// %bb.2:                               // %entry
	{
		r7 = mpyi(r22,r24)
		r2 = ##1065385983
		p2 = cmp.eq(r22,#0)
	}
	{
		r23 = r0
		r21 = add(r2,#-32767)
		memd(r29+#120) = r19:18
		memw(r29+#112) = r20
	}                                       // 8-byte Folded Spill
	{
		if (p2) jump:nt .LBB2_6
		memw(r29+#116) = r7
	}                                       // 4-byte Folded Spill
// %bb.3:
	{
		p0 = cmp.gtu(r22,#1)
		r5:4 = combine(#0,#0)
		r6 = add(r22,#-1)
		r2 = memw(r19+#4)
	}
	{
		loop0(.LBB2_4,r6)
		r3 = memw(r19+#0)
	}
	{
		r2 = mpyi(r2,r20)
	}
	{
		r3 = addasl(r3,r2,#2)
	}
	{
		r25 = addasl(r3,r7,#2)
	}
	{
		r3:2 = combine(r25,#0)
	}
	{
		if (!p0) jump:nt .LBB2_5
		r6 = memw(r3++#4)
	}
	.falign
.LBB2_4:                                // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = sfmin(r6,r4)
		r5 = sfmax(r6,r5)
		r6 = memw(r3++#4)
	} :endloop0
	.falign
.LBB2_5:
	{
		r3 = sfmin(r6,r4)
		r4 = sfmax(r6,r5)
		r8 = r21
	}
	{
		p1 = sfcmp.uo(r3,r4)
		p3 = sfcmp.eq(r3,r4)
	}
	{
		r4 = sfsub(r4,r3)
		p0 = and(p3,!p1)
		if (!p0.new) r0 = add(r21,#0)
		if (!p0.new) jump:nt .LBB2_8
	}
	.falign
.LBB2_6:                                // %if.then.i
	{
		r1 = #0
		r25 = #0
		r0 = add(r29,#128)
		r2 = r22
	}
	{
		call memset
	}
	.falign
// %bb.7:                               // %if.then.i
	{
		r27:26 = combine(#0,r21)
		jump .LBB2_13
	}
	.falign
.LBB2_8:                                // %for.body30.preheader.i
	{
		r5 = ##1132396544
		memw(r29+#768) = r24
		memw(r29+#640) = r23
	}                                       // 4-byte Folded Spill
	{
		r6,p1 = sfrecipa(r4,r5)
		r7 = sffixupd(r4,r5)
	}
	{
		r4 = sffixupn(r4,r5)
	}
	{
		r8 -= sfmpy(r7,r6):lib
		r5 = r4
		r1 = r4
	}
	{
		r5 = insert(r2,#31,#0)
		r6 += sfmpy(r8,r6):lib
	}
	{
		r26 = r5
	}
	{
		r26 += sfmpy(r4,r6):lib
		r0 -= sfmpy(r7,r6):lib
	}
	{
		r6 += sfmpy(r0,r6):lib
		r1 -= sfmpy(r7,r26):lib
	}
	{
		r0 = togglebit(r3,#31)
		r26 += sfmpy(r1,r6):lib
	}
	{
		r4 -= sfmpy(r26,r7):lib
	}
	{
		r26 += sfmpy(r4,r6,p1):scale
		r6 = r21
	}
	{
		r3,p2 = sfrecipa(r0,r26)
		r4 = sffixupd(r0,r26)
	}
	{
		r2 = sffixupn(r0,r26)
	}
	{
		r6 -= sfmpy(r4,r3):lib
		r0 = r2
		r1 = r2
	}
	{
		r0 = insert(r5,#31,#0)
		r3 += sfmpy(r6,r3):lib
		r6 = r21
	}
	{
		r0 += sfmpy(r2,r3):lib
		r6 -= sfmpy(r4,r3):lib
	}
	{
		r1 -= sfmpy(r4,r0):lib
		r3 += sfmpy(r6,r3):lib
	}
	{
		r0 += sfmpy(r1,r3):lib
	}
	{
		r2 -= sfmpy(r0,r4):lib
	}
	{
		call rintf
		r0 += sfmpy(r2,r3,p2):scale
	}
	.falign
// %bb.9:                               // %for.body30.preheader.i
	{
		r2,p0 = sfrecipa(r21,r26)
		r3 = sffixupd(r21,r26)
		r4 = r21
		r27 = #0
	}
	{
		r1 = sffixupn(r21,r26)
		r0 = convert_sf2w(r0):chop
		r5 = r21
		r18 = r22
	}
	{
		r4 -= sfmpy(r3,r2):lib
		r22 = #255
		r20 = #0
		r19 = add(r29,#128)
	}
	{
		r24 = r1
		r6 = r1
		memw(r29+#512) = r18
	}                                       // 4-byte Folded Spill
	{
		r24 = insert(r27,#31,#0)
		r2 += sfmpy(r4,r2):lib
	}
	{
		r24 += sfmpy(r1,r2):lib
		r5 -= sfmpy(r3,r2):lib
	}
	{
		r2 += sfmpy(r5,r2):lib
		r6 -= sfmpy(r3,r24):lib
	}
	{
		r5 = min(r0,r22)
	}
	{
		r23 = max(r5,r27)
		r24 += sfmpy(r6,r2):lib
	}
	{
		r1 -= sfmpy(r24,r3):lib
	}
	{
		r24 += sfmpy(r1,r2,p0):scale
	}
	.falign
.LBB2_10:                               // %for.body30.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r25++#4)
	}
	{
		call rintf
		r0 = sfmpy(r24,r2)
	}
	.falign
// %bb.11:                              // %for.body30.i
                                        //   in Loop: Header=BB2_10 Depth=1
	{
		r2 = convert_sf2w(r0):chop
		r18 = add(r18,#-1)
	}
	{
		p0 = cmp.eq(r18,#0)
	}
	{
		r2 = add(r23,r2)
	}
	{
		r2 = min(r2,r22)
	}
	{
		r2 = max(r2,r27)
		memb(r19++#1) = r2.new
	}
	{
		r20 = add(r2,r20)
		if (!p0) jump:nt .LBB2_10
		if (p0) r24 = memw(r29+##768)
	}                                       // 4-byte Folded Reload
// %bb.12:                              // %quant_q_u8.exit.loopexit
	{
		r27 = convert_uw2sf(r23)
		r25 = asl(r20,#7)
		r22 = memw(r29+#512)
		r19:18 = memd(r29+#120)
	}                                       // 4-byte Folded Reload
	{
		r23 = memw(r29+#640)
		r20 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	.falign
.LBB2_13:                               // %quant_q_u8.exit
	{
		v8 = vsplat(r21)
		r2 = ##-8388608
		r3 = add(r29,#2048)
	}
	{
		v7 = vsplat(r2)
		r0 = add(r29,#256)
		r1 = add(r29,#128)
		vmem(r29+#4) = v7.new
	}                                       // 128-byte Folded Spill
	{
		r2 = r22
		r3 = add(r29,#2048)
		v9 = vxor(v9,v9)
		vmem(r3+#-8) = v8
	}                                       // 128-byte Folded Spill
	{
		call memcpy
		vmem(r3+#-7) = v9
	}                                       // 128-byte Folded Spill
	.falign
// %bb.14:                              // %quant_q_u8.exit
	{
		r2 = add(r29,#2048)
		r4 = memw(r18+#8)
		r3 = memw(r18+#24)
	}
	{
		r2 = add(r29,#2048)
		p2 = cmp.eq(r3,#0)
		r5 = memw(r17+#12)
		v2 = vmem(r2+#-7)
	}                                       // 128-byte Folded Reload
	{
		v0 = v2
		r2 = memw(r18+#4)
		v3 = vmem(r2+#-8)
	}                                       // 128-byte Folded Reload
	{
		r2 = add(r20,add(r2,#1))
		r8 = sfmpy(r26,r5)
		v19 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		r7 = minu(r2,r4)
	}
	{
		p1 = cmp.gtu(r7,r3)
		if (p1.new) r6 = sub(r7,r3)
		if (!p1.new) r6 = #0
	}
	{
		r2 = memw(r19+#8)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB2_16
	}
// %bb.15:                              // %if.then
	{
		r3 = ##1069066811
		v0 = v3
		r2 = memw(r2+r24<<#2)
	}
	{
		r2 = sfmpy(r2,r3)
	}
	{
		v19 = vsplat(r2)
	}
	.falign
.LBB2_16:                               // %if.end
	{
		r0 = add(r29,#2048)
		r3 = add(r29,#2048)
		r1 = add(r29,#2048)
		r2 = memw(r16+#76)
	}
	{
		r0 = add(r29,#2048)
		if (p2) r6 = #0
		p1 = cmp.eq(r2,#0)
		vmem(r0+#-5) = v2
	}
	{
		if (!p1) r12 = memw(r16+#16)
		vmem(r3+#-6) = v2
	}
	{
		if (!p1) r9 = memw(r16+#24)
		vmem(r1+#-4) = v2
	}
	{
		if (p1) jump:nt .LBB2_18
		if (p1) r9 = memw(r16+#24)
		vmem(r0+#-3) = v2
	}
// %bb.17:                              // %if.then.i248
	{
		r2 = mpyi(r12,r23)
	}
	{
		r20 = mpyi(r2,r9)
		jump .LBB2_19
	}
	.falign
.LBB2_18:                               // %if.end.i
	{
		r2 = lsr(r9,#2)
		r12 = memw(r16+#16)
	}
	{
		r2 = mpyi(r23,r2)
	}
	{
		r2 = mpyi(r2,r12)
	}
	{
		r20 = asl(r2,#2)
	}
	.falign
.LBB2_19:                               // %hexkl_kv_q_kt4_index.exit
	{
		r2 = lsr(r22,#5)
		v6 = vsplat(r8)
		r3 = and(r6,#-32)
		p0 = cmp.gtu(r22,#31)
	}
	{
		p2 = cmp.gtu(r7,r3)
		if (p2.new) r8 = ##-1023672320
		if (!p2.new) jump:t .LBB2_54
	}
// %bb.20:                              // %for.body34.lr.ph
	{
		v4 = vsplat(r25)
		r13 = ##998277249
		vmem(r29+#5) = v4.new
	}                                       // 128-byte Folded Spill
	{
		r6 = lsr(r12,#2)
		v4 = vsplat(r6)
		r21 = ##2147483647
	}
	{
		r6 = mpyi(r23,r6)
		r11 = mpyi(r12,r23)
		vmem(r29+#7) = v6
	}                                       // 128-byte Folded Spill
	{
		r14 = asl(r6,#2)
		v7 = vsplat(r8)
		r8 = #1
		v20 = vmem(r17+#4)
	}
	{
		r15 = +mpyi(r22,#24)
		r25:24 = combine(#23,#64)
		if (!p1) r14 = add(r11,#0)
		r10 = memw(r16+#48)
	}
	{
		r28 = +mpyi(r22,#28)
		v9 = vsplat(r8)
		r8 = ##985088974
	}
	{
		r9 = mpyi(r14,r9)
		v6 = vsplat(r13)
		r13 = ##1262485504
	}
	{
		v12 = vsplat(r8)
		r8 = ##1026206145
		memw(r29+#100) = r9
	}                                       // 4-byte Folded Spill
	{
		r14 = +mpyi(r22,#20)
		r6 = asl(r12,#2)
	}
	{
		r4 = lsr(r22,#2)
		r12 = ##1060205080
	}
	{
		v14 = vsplat(r8)
		r9 = ##1007192328
	}
	{
		v5 = vsplat(r27)
		r8 = ##1056964608
		vmem(r29+#6) = v5.new
	}                                       // 128-byte Folded Spill
	{
		v8 = vsplat(r13)
		v10 = vsplat(r12)
		r13 = ##961571175
	}
	{
		v13 = vsplat(r9)
		p1 = cmp.gtu(r22,#3)
		r12 = ##1042983594
	}
	{
		v16 = vsplat(r8)
		r9 = ##1073741824
		r5 = memw(r16+#36)
	}
	{
		v5 = vsplat(r7)
		v11 = vsplat(r13)
		r8 = ##2129859015
	}
	{
		v15 = vsplat(r12)
		v17 = vsplat(r9)
		r7 = sub(r7,r3)
		r19 = memw(r16+#52)
	}
	{
		r0 = extractu(r3,#25,#5)
		v18 = vsplat(r8)
		r9 = r22
		r1 = memw(r16+#44)
	}
	{
		r18 = asl(r0,#7)
		r8 = asl(r22,#2)
	}
	{
		r0 = addasl(r1,r11,#2)
		r27 = ##-2147483648
		memw(r29+#104) = r8
	}                                       // 4-byte Folded Spill
	{
		r1 = addasl(r10,r11,#2)
		r5 += add(r20,r18)
		r10 = memw(r16+#40)
	}
	{
		r11 = addasl(r19,r11,#2)
		r19 = #8
		r16 = memw(r17+#384)
	}
	{
		r12 = +mpyi(r22,#12)
		p2 = cmp.eq(r16,#0)
		r20 = #16
	}
	{
		r16 = ##2129587123
	}
	{
		r8 = asl(r22,#3)
		r7 = add(r7,#31)
		memw(r29+#108) = r8.new
	}                                       // 4-byte Folded Spill
	{
		r13 = asl(r22,#4)
		r7 = lsr(r7,#5)
		r22 = #32
	}
	{
		loop1(.LBB2_21,r7)
	}
	.falign
.LBB2_21:                               // Block address taken
                                        // %for.body34
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB2_23 Depth 2
                                        //     Child Loop BB2_29 Depth 2
                                        //     Child Loop BB2_32 Depth 2
                                        //     Child Loop BB2_34 Depth 2
                                        //     Child Loop BB2_36 Depth 2
                                        //     Child Loop BB2_38 Depth 2
                                        //     Child Loop BB2_40 Depth 2
                                        //     Child Loop BB2_42 Depth 2
                                        //     Child Loop BB2_44 Depth 2
                                        //     Child Loop BB2_46 Depth 2
                                        //     Child Loop BB2_50 Depth 2
	{
		r7 = add(r29,#256)
		if (!p1) jump:nt .LBB2_25
		v25 = v19
		v19 = v2
	}
// %bb.22:                              // %for.body42
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		r26 = add(r4,#-1)
		p3 = cmp.gtu(r4,#1)
		v21 = vmemu(r5+#0)
	}
	{
		loop0(.LBB2_23,r26)
		r23 = add(r5,r6)
		v19 = v2
		r18 = memw(r7++#4)
	}
	{
		if (!p3) jump:nt .LBB2_24
	}
	.balign 32
.LBB2_23:                               // %for.body42
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v19.uw += vrmpy(v21.ub,r18.ub)
		r23 = add(r23,r6)
		v21 = vmemu(r23+#0)
	}
	{
		nop
		r18 = memw(r7++#4)
	} :endloop0
	.falign
.LBB2_24:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v19.uw += vrmpy(v21.ub,r18.ub)
	}
	.falign
.LBB2_25:                               // %for.cond.cleanup41
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		r7 = addasl(r1,r3,#2)
		v22.w = vsub(v19.w,v21.w)
		v21.cur = vmem(r29+#5)
	}                                       // 128-byte Folded Reload
	{
		r7 = addasl(r0,r3,#2)
		v19.sf = v22.w
		v23 = vmemu(r7+#0)
	}
	{
		v21.sf = v23.w
		v23 = vmem(r29+#6)
	}                                       // 128-byte Folded Reload
	{
		v27 = vmemu(r7+#0)
	}
	{
		v28.qf32 = vmpy(v23.sf,v21.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v30.qf32 = vsub(v19.sf,v29.sf)
		v19 = vmem(r29+#7)
	}                                       // 128-byte Folded Reload
	{
		v31.sf = v30.qf32
	}
	{
		v26.qf32 = vmpy(v31.sf,v19.sf)
	}
	{
		v24.sf = v26.qf32
	}
	{
		v22.qf32 = vmpy(v24.sf,v27.sf)
	}
	{
		if (p2) jump:nt .LBB2_27
		v27.sf = v22.qf32
	}
// %bb.26:                              // %if.then55
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		v19 = vsplat(r21)
		v30 = vsplat(r27)
		v28 = vmem(r17+#2)
	}
	{
		v21 = vand(v27,v19)
		v27 = vand(v27,v30)
		v23 = vmem(r17+#1)
	}
	{
		v29.qf32 = vmpy(v21.sf,v28.sf)
	}
	{
		v31.sf = v29.qf32
	}
	{
		v26 = vxor(v31,v30)
	}
	{
		v24.sf = vmax(v26.sf,v7.sf)
	}
	{
		v22.qf32 = vadd(v24.sf,v8.sf)
	}
	{
		v19.sf = v22.qf32
	}
	{
		v21.w = vsub(v19.w,v8.w)
	}
	{
		v28.sf = v21.w
	}
	{
		q1 = vcmp.gt(v28.sf,v24.sf)
	}
	{
		v29 = vmux(q1,v9,v2)
	}
	{
		v31.w = vsub(v21.w,v29.w)
	}
	{
		v26.sf = v31.w
		v31.w = vasl(v31.w,r25)
	}
	{
		v24.qf32 = vsub(v24.sf,v26.sf)
	}
	{
		v22.sf = v24.qf32
	}
	{
		v19.qf32 = vmpy(v22.sf,v10.sf)
	}
	{
		v21.sf = v19.qf32
	}
	{
		v28.qf32 = vmpy(v21.sf,v11.sf)
	}
	{
		v29.qf32 = vadd(v28.qf32,v12.sf)
	}
	{
		v26.qf32 = vmpy(v29.qf32,v19.qf32)
	}
	{
		v24.qf32 = vadd(v26.qf32,v13.sf)
	}
	{
		v22.qf32 = vmpy(v24.qf32,v19.qf32)
	}
	{
		v24.qf32 = vmpy(v19.qf32,v19.qf32)
	}
	{
		v21.qf32 = vadd(v22.qf32,v14.sf)
	}
	{
		v28.qf32 = vmpy(v21.qf32,v19.qf32)
	}
	{
		v29.qf32 = vadd(v28.qf32,v15.sf)
	}
	{
		v26.qf32 = vmpy(v29.qf32,v19.qf32)
	}
	{
		v22.qf32 = vadd(v26.qf32,v16.sf)
	}
	{
		v21.qf32 = vmpy(v22.qf32,v24.qf32)
	}
	{
		v21 = vsplat(r16)
		v19.qf32 = vadd(v21.qf32,v19.qf32)
	}
	{
		v28.qf32 = vadd(v19.qf32,v3.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v26.w = vadd(v29.w,v31.w)
	}
	{
		v24.qf32 = vadd(v3.sf,v26.sf)
		v26.qf32 = vsub(v3.sf,v26.sf)
	}
	{
		v22.sf = v24.qf32
	}
	{
		v19.w = vsub(v21.w,v22.w)
	}
	{
		v28.qf32 = vmpy(v19.sf,v22.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v31.qf32 = vsub(v17.sf,v29.sf)
	}
	{
		v22.sf = v31.qf32
	}
	{
		v21.qf32 = vmpy(v19.sf,v22.sf)
	}
	{
		v24.qf32 = vmpy(v21.qf32,v24.qf32)
	}
	{
		v19.sf = v24.qf32
	}
	{
		v28.qf32 = vsub(v17.sf,v19.sf)
	}
	{
		v29.qf32 = vmpy(v21.qf32,v28.qf32)
	}
	{
		v31.qf32 = vmpy(v26.qf32,v29.qf32)
	}
	{
		v22.sf = v31.qf32
	}
	{
		v23.qf32 = vmpy(v22.sf,v23.sf)
	}
	{
		v30.sf = v23.qf32
	}
	{
		v27 = vor(v30,v27)
	}
	.falign
.LBB2_27:                               // %if.end57
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		r7 = addasl(r11,r3,#2)
		v21 = vsplat(r3)
		v1 = vmem(r29+#4)
	}                                       // 128-byte Folded Reload
	{
		v24.w = vadd(v20.w,v21.w)
	}
	{
		q2 = vcmp.gt(v4.w,v24.w)
		q3 = vcmp.gt(v5.w,v24.w)
	}
	{
		q0 = not(q2)
	}
	{
		q0 = and(q3,q0)
	}
	{
		v28 = vmux(q0,v27,v1)
	}
	{
		v19 = valign(v28,v28,#4)
	}
	{
		v26.sf = vmax(v28.sf,v19.sf)
	}
	{
		v29 = vror(v26,r19)
	}
	{
		v31.sf = vmax(v26.sf,v29.sf)
	}
	{
		v22 = vror(v31,r20)
	}
	{
		v23.sf = vmax(v31.sf,v22.sf)
	}
	{
		v27 = vror(v23,r22)
	}
	{
		v30.sf = vmax(v23.sf,v27.sf)
	}
	{
		v21 = vror(v30,r24)
	}
	{
		v24.sf = vmax(v30.sf,v21.sf)
	}
	{
		v19.sf = vmax(v25.sf,v24.sf)
	}
	{
		q1 = vcmp.eq(v19.w,v1.w)
	}
	{
		v26 = vmux(q1,v2,v19)
	}
	{
		v28.qf32 = vsub(v28.sf,v26.sf)
		v25.qf32 = vsub(v25.sf,v26.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v31.sf = vmax(v29.sf,v7.sf)
	}
	{
		v22.qf32 = vadd(v31.sf,v8.sf)
	}
	{
		v23.sf = v22.qf32
	}
	{
		v27.w = vsub(v23.w,v8.w)
	}
	{
		v30.sf = v27.w
	}
	{
		q1 = vcmp.gt(v30.sf,v31.sf)
	}
	{
		v21 = vmux(q1,v9,v2)
	}
	{
		v24.w = vsub(v27.w,v21.w)
	}
	{
		v28.sf = v24.w
		v24.w = vasl(v24.w,r25)
	}
	{
		v29.qf32 = vsub(v31.sf,v28.sf)
	}
	{
		v31.sf = v29.qf32
	}
	{
		v22.qf32 = vmpy(v31.sf,v10.sf)
	}
	{
		v23.sf = v22.qf32
	}
	{
		v27.qf32 = vmpy(v23.sf,v11.sf)
	}
	{
		v30.qf32 = vadd(v27.qf32,v12.sf)
	}
	{
		v21.qf32 = vmpy(v30.qf32,v22.qf32)
	}
	{
		v21.qf32 = vmpy(v22.qf32,v22.qf32)
		v28.qf32 = vadd(v21.qf32,v13.sf)
	}
	{
		v29.qf32 = vmpy(v28.qf32,v22.qf32)
	}
	{
		v31.qf32 = vadd(v29.qf32,v14.sf)
	}
	{
		v23.qf32 = vmpy(v31.qf32,v22.qf32)
	}
	{
		v27.qf32 = vadd(v23.qf32,v15.sf)
	}
	{
		v30.qf32 = vmpy(v27.qf32,v22.qf32)
	}
	{
		r7 = add(r29,#384)
		v28.qf32 = vadd(v30.qf32,v16.sf)
		v30 = vmemu(r7+#0)
	}
	{
		v29.qf32 = vmpy(v28.qf32,v21.qf32)
	}
	{
		v22.qf32 = vadd(v29.qf32,v22.qf32)
	}
	{
		v31.qf32 = vadd(v22.qf32,v3.sf)
	}
	{
		v23.sf = v31.qf32
	}
	{
		v27.w = vadd(v23.w,v24.w)
	}
	{
		v21 = vmux(q0,v27,v2)
	}
	{
		v28.qf32 = vmpy(v21.sf,v30.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v22 = valign(v29,v29,#4)
	}
	{
		v22.sf = v25.qf32
		v31.sf = vmax(v29.sf,v22.sf)
	}
	{
		v24 = vror(v31,r19)
	}
	{
		v23.sf = vmax(v31.sf,v24.sf)
		v31.sf = vmax(v22.sf,v7.sf)
	}
	{
		v27 = vror(v23,r20)
	}
	{
		v27.qf32 = vadd(v31.sf,v8.sf)
		v30.sf = vmax(v23.sf,v27.sf)
	}
	{
		v26 = vror(v30,r22)
		v25.sf = v27.qf32
	}
	{
		v29.sf = vmax(v30.sf,v26.sf)
		v26.w = vsub(v25.w,v8.w)
	}
	{
		v24 = vror(v29,r24)
	}
	{
		v24.sf = v26.w
		v23.sf = vmax(v29.sf,v24.sf)
	}
	{
		q3 = vcmp.gt(v23.w,v2.w)
	}
	{
		v30.qf32 = vmpy(v23.sf,v6.sf)
	}
	{
		v29.sf = v30.qf32
	}
	{
		v22 = vmux(q3,v29,v3)
		q3 = vcmp.gt(v24.sf,v31.sf)
	}
	{
		v23.w = vsub(v18.w,v22.w)
		v27 = vmux(q3,v9,v2)
	}
	{
		v25.w = vsub(v26.w,v27.w)
	}
	{
		v30.qf32 = vmpy(v23.sf,v22.sf)
	}
	{
		v29.sf = v25.w
		v25.w = vasl(v25.w,r25)
	}
	{
		v26.sf = v30.qf32
	}
	{
		v31.qf32 = vsub(v31.sf,v29.sf)
	}
	{
		v24.qf32 = vsub(v17.sf,v26.sf)
	}
	{
		v30.sf = v31.qf32
	}
	{
		v27.sf = v24.qf32
	}
	{
		v26.qf32 = vmpy(v30.sf,v10.sf)
	}
	{
		v23.qf32 = vmpy(v23.sf,v27.sf)
	}
	{
		v24.sf = v26.qf32
	}
	{
		v29.sf = v23.qf32
	}
	{
		v27.qf32 = vmpy(v24.sf,v11.sf)
	}
	{
		v31.qf32 = vmpy(v29.sf,v22.sf)
	}
	{
		v29.qf32 = vadd(v27.qf32,v12.sf)
	}
	{
		v30.sf = v31.qf32
	}
	{
		v31.qf32 = vmpy(v29.qf32,v26.qf32)
	}
	{
		v24.qf32 = vsub(v17.sf,v30.sf)
	}
	{
		v27.qf32 = vadd(v31.qf32,v13.sf)
	}
	{
		v23.qf32 = vmpy(v23.qf32,v24.qf32)
	}
	{
		v29.qf32 = vmpy(v27.qf32,v26.qf32)
	}
	{
		v30.sf = v23.qf32
	}
	{
		v31.qf32 = vadd(v29.qf32,v14.sf)
	}
	{
		v24.qf32 = vmpy(v30.sf,v22.sf)
	}
	{
		v30.qf32 = vmpy(v31.qf32,v26.qf32)
	}
	{
		v27.sf = v24.qf32
	}
	{
		v24.qf32 = vadd(v30.qf32,v15.sf)
	}
	{
		v27.qf32 = vmpy(v26.qf32,v26.qf32)
		v29.qf32 = vsub(v17.sf,v27.sf)
	}
	{
		v31.qf32 = vmpy(v24.qf32,v26.qf32)
	}
	{
		v23.qf32 = vmpy(v23.qf32,v29.qf32)
	}
	{
		v30.qf32 = vadd(v31.qf32,v16.sf)
	}
	{
		v28.qf32 = vmpy(v28.qf32,v23.qf32)
	}
	{
		v29.qf32 = vmpy(v30.qf32,v27.qf32)
	}
	{
		v24.qf32 = vadd(v28.qf32,v8.sf)
	}
	{
		v26.qf32 = vadd(v29.qf32,v26.qf32)
	}
	{
		v23.sf = v24.qf32
	}
	{
		v31.qf32 = vadd(v26.qf32,v3.sf)
		v24.w = vsub(v23.w,v8.w)
	}
	{
		v28.h = vpack(v24.w,v24.w):sat
		v27.sf = v31.qf32
	}
	{
		v23.w = vadd(v27.w,v25.w)
	}
	{
		r7 = add(r29,#1792)
		if (!p0) jump:nt .LBB2_53
		v30.ub = vpack(v28.h,v28.h):sat
		vmem(r7+#0) = v30.new
	}
// %bb.28:                              //   in Loop: Header=BB2_21 Depth=1
	{
		loop0(.LBB2_29,r2)
		r8 = #7
		v29 = valign(v24,v24,#4)
	}
	{
		v24.w = vadd(v24.w,v29.w)
	}
	{
		v26 = vror(v24,r19)
	}
	{
		v31.w = vadd(v24.w,v26.w)
	}
	{
		v28 = vror(v31,r20)
	}
	{
		v27.w = vadd(v31.w,v28.w)
	}
	{
		v25 = vror(v27,r22)
	}
	{
		v30.w = vadd(v27.w,v25.w)
	}
	{
		v29 = vror(v30,r24)
	}
	{
		v24.w = vadd(v30.w,v29.w)
	}
	{
		v24.w = vasl(v24.w,r8)
	}
	.falign
.LBB2_29:                               // Block address taken
                                        // %for.body75
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		nop
		vmem(r7++#1) = v2
	} :endloop0
// %bb.30:                              // %for.cond.cleanup74
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		if (p0) r23 = add(r29,##1792)
		if (p0) r18 = add(r29,##384)
	}
	{
		if (!p0) jump:nt .LBB2_53
	}
// %bb.31:                              // %for.body86.us
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		r7 = mpyi(r3,r9)
		p3 = cmp.gtu(r2,#1)
	}
	{
		r26 = memw(r18+#0)
		r8 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r7 += add(r10,r8)
		r8 = add(r2,#-1)
		v27 = vmem(r23+#0)
	}
	{
		loop0(.LBB2_32,r8)
		r18 = r7
	}
	{
		if (!p3) jump:nt .LBB2_33
		v26 = vmemu(r18++#1)
	}
	.balign 32
.LBB2_32:                               // %for.body98.us
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v27.uw += vrmpy(v26.ub,r26.ub)
		v31 = vmem(r23+#1)
		vmem(r23++#1) = v27.new
	}
	{
		v27 = v31
		v26 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_33:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v27.uw += vrmpy(v26.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = memw(r29+#104)
		vmem(r23++#1) = v27.new
	}                                       // 4-byte Folded Reload
	{
		r18 = add(r7,r18)
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		r26 = memw(r8+#4)
	}
	{
		loop0(.LBB2_34,r8)
		p3 = cmp.gtu(r2,#1)
		v26 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_35
		v28 = vmem(r23+#0)
	}
	.balign 32
.LBB2_34:                               // %for.body98.us.1
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v28.uw += vrmpy(v26.ub,r26.ub)
		v27 = vmem(r23+#1)
		vmem(r23++#1) = v28.new
	}
	{
		v28 = v27
		v26 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_35:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v28.uw += vrmpy(v26.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = memw(r29+#108)
		vmem(r23++#1) = v28.new
	}                                       // 4-byte Folded Reload
	{
		r18 = add(r7,r18)
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		r26 = memw(r8+#8)
	}
	{
		loop0(.LBB2_36,r8)
		p3 = cmp.gtu(r2,#1)
		v27 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_37
		v29 = vmem(r23+#0)
	}
	.balign 32
.LBB2_36:                               // %for.body98.us.2
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v29.uw += vrmpy(v27.ub,r26.ub)
		v26 = vmem(r23+#1)
		vmem(r23++#1) = v29.new
	}
	{
		v29 = v26
		v27 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_37:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v29.uw += vrmpy(v27.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = add(r7,r12)
		vmem(r23++#1) = v29.new
	}
	{
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		p3 = cmp.gtu(r2,#1)
		r26 = memw(r8+#12)
	}
	{
		loop0(.LBB2_38,r8)
		v28 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_39
		v30 = vmem(r23+#0)
	}
	.balign 32
.LBB2_38:                               // %for.body98.us.3
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v30.uw += vrmpy(v28.ub,r26.ub)
		v25 = vmem(r23+#1)
		vmem(r23++#1) = v30.new
	}
	{
		v30 = v25
		v28 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_39:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v30.uw += vrmpy(v28.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = add(r7,r13)
		vmem(r23++#1) = v30.new
	}
	{
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		p3 = cmp.gtu(r2,#1)
		r26 = memw(r8+#16)
	}
	{
		loop0(.LBB2_40,r8)
		v29 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_41
		v31 = vmem(r23+#0)
	}
	.balign 32
.LBB2_40:                               // %for.body98.us.4
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v31.uw += vrmpy(v29.ub,r26.ub)
		v28 = vmem(r23+#1)
		vmem(r23++#1) = v31.new
	}
	{
		v31 = v28
		v29 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_41:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v31.uw += vrmpy(v29.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = add(r7,r14)
		vmem(r23++#1) = v31.new
	}
	{
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		p3 = cmp.gtu(r2,#1)
		r26 = memw(r8+#20)
	}
	{
		loop0(.LBB2_42,r8)
		v30 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_43
		v25 = vmem(r23+#0)
	}
	.balign 32
.LBB2_42:                               // %for.body98.us.5
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v25.uw += vrmpy(v30.ub,r26.ub)
		v29 = vmem(r23+#1)
		vmem(r23++#1) = v25.new
	}
	{
		v25 = v29
		v30 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_43:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v25.uw += vrmpy(v30.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = add(r7,r15)
		vmem(r23++#1) = v25.new
	}
	{
		r23 = add(r29,#1792)
		r8 = add(r2,#-1)
		p3 = cmp.gtu(r2,#1)
		r26 = memw(r8+#24)
	}
	{
		loop0(.LBB2_44,r8)
		v31 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_45
		v26 = vmem(r23+#0)
	}
	.balign 32
.LBB2_44:                               // %for.body98.us.6
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v26.uw += vrmpy(v31.ub,r26.ub)
		v30 = vmem(r23+#1)
		vmem(r23++#1) = v26.new
	}
	{
		v26 = v30
		v31 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_45:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v26.uw += vrmpy(v31.ub,r26.ub)
		r8 = add(r29,#384)
		r18 = add(r7,r28)
		vmem(r23++#1) = v26.new
	}
	{
		r7 = add(r29,#1792)
		r8 = add(r2,#-1)
		p3 = cmp.gtu(r2,#1)
		r23 = memw(r8+#28)
	}
	{
		loop0(.LBB2_46,r8)
		v25 = vmemu(r18++#1)
	}
	{
		if (!p3) jump:nt .LBB2_47
		v27 = vmem(r7+#0)
	}
	.balign 32
.LBB2_46:                               // %for.body98.us.7
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v27.uw += vrmpy(v25.ub,r23.ub)
		v31 = vmem(r7+#1)
		vmem(r7++#1) = v27.new
	}
	{
		v27 = v31
		v25 = vmemu(r18++#1)
	} :endloop0
	.falign
.LBB2_47:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v27.uw += vrmpy(v25.ub,r23.ub)
		r26 = add(r29,#1792)
		p3 = cmp.gtu(r2,#1)
		vmem(r7++#1) = v27.new
	}
	{
		r7 = add(r29,#1280)
		if (p0) r8 = add(r2,#-2)
		if (!p0) jump:nt .LBB2_53
	}
// %bb.48:                              // %for.body115
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		v26.w = vsub(v27.w,v24.w)
		v27.cur = vmem(r26++#1)
	}
	{
		v28.qf32 = vmpy(v25.sf,v23.sf)
		v25.cur = vmem(r7+#0)
	}
	{
		if (!p3) jump:nt .LBB2_52
		v29.sf = v26.w
	}
// %bb.49:                              // %for.body115
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		v29.qf32 = vmpy(v29.sf,v22.sf)
		p3 = cmp.gtu(r2,#2)
		v31.w = vsub(v30.w,v24.w)
		v30.cur = vmem(r26++#1)
	}
	{
		loop0(.LBB2_50,r8)
	}
	{
		v25.qf32 = vadd(v28.qf32,v29.qf32)
		v29.sf = v31.w
		v28 = vmem(r7+#1)
	}
	{
		v28.qf32 = vmpy(v28.sf,v23.sf)
		if (!p3) jump:nt .LBB2_51
	}
	.balign 32
.LBB2_50:                               // %for.body115
                                        //   Parent Loop BB2_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v30.qf32 = vmpy(v29.sf,v22.sf)
		v26.w = vsub(v27.w,v24.w)
		v27.cur = vmem(r26++#1)
	}
	{
		v25.sf = v25.qf32
		vmem(r7++#1) = v25.new
	}
	{
		v25.qf32 = vadd(v28.qf32,v30.qf32)
		v29.sf = v26.w
		v31 = vmem(r7+#1)
	}
	{
		v28.qf32 = vmpy(v31.sf,v23.sf)
		nop
	} :endloop0
	.falign
.LBB2_51:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v24.sf = v25.qf32
		vmem(r7++#1) = v24.new
	}
	.falign
.LBB2_52:                               //   in Loop: Header=BB2_21 Depth=1
	{
		v22.qf32 = vmpy(v29.sf,v22.sf)
	}
	{
		v29.qf32 = vadd(v28.qf32,v22.qf32)
	}
	{
		v28.sf = v29.qf32
		vmem(r7++#1) = v28.new
	}
	.falign
.LBB2_53:                               // %for.cond.cleanup114
                                        //   in Loop: Header=BB2_21 Depth=1
	{
		v0.qf32 = vmpy(v0.sf,v23.sf)
		r3 = add(r3,#32)
		r5 = add(r5,#128)
		v22 = valign(v21,v21,#4)
	}
	{
		v21.qf32 = vadd(v21.sf,v22.sf)
	}
	{
		v23.sf = v21.qf32
	}
	{
		v24 = vror(v23,r19)
	}
	{
		v27.qf32 = vadd(v21.qf32,v24.sf)
	}
	{
		v26.sf = v27.qf32
	}
	{
		v25 = vror(v26,r20)
	}
	{
		v28.qf32 = vadd(v27.qf32,v25.sf)
	}
	{
		v29.sf = v28.qf32
	}
	{
		v30 = vror(v29,r22)
	}
	{
		v31.qf32 = vadd(v28.qf32,v30.sf)
	}
	{
		v22.sf = v31.qf32
	}
	{
		v21 = vror(v22,r24)
	}
	{
		v23.qf32 = vadd(v31.qf32,v21.sf)
	}
	{
		v0.qf32 = vadd(v0.qf32,v23.qf32)
	}
	{
		nop
		nop
		v0.sf = v0.qf32
	} :endloop1
	.falign
.LBB2_54:                               // %for.cond.cleanup33
	{
		if (p0) r4 = ##1073741824
		if (p0) r1:0 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		if (p0) r3 = ##2129859015
		if (!p0) jump:nt .LBB2_60
	}
// %bb.55:                              // %for.body134.preheader
	{
		v1 = vsplat(r3)
		v2 = vsplat(r4)
		p1 = cmp.gtu(r2,#2)
		p0 = cmp.gtu(r2,#1)
	}
	{
		v3.w = vsub(v1.w,v0.w)
		r2 = add(r2,#-2)
		r4 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r1+#16)
		r3 = memw(r1+#12)
	}
	{
		r4 = mpyi(r5,r4)
		v4.qf32 = vmpy(v3.sf,v0.sf)
		r5 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r4,#2)
		r4 = add(r29,#1280)
		v5.sf = v4.qf32
	}
	{
		r3 = addasl(r3,r5,#2)
		v20 = vmem(r4++#1)
	}
	{
		v6.qf32 = vsub(v2.sf,v5.sf)
	}
	{
		v7.sf = v6.qf32
	}
	{
		v8.qf32 = vmpy(v3.sf,v7.sf)
	}
	{
		v9.sf = v8.qf32
	}
	{
		v10.qf32 = vmpy(v9.sf,v0.sf)
	}
	{
		v11.sf = v10.qf32
	}
	{
		v12.qf32 = vsub(v2.sf,v11.sf)
	}
	{
		v13.qf32 = vmpy(v8.qf32,v12.qf32)
	}
	{
		v14.sf = v13.qf32
	}
	{
		v15.qf32 = vmpy(v14.sf,v0.sf)
	}
	{
		v16.sf = v15.qf32
	}
	{
		v17.qf32 = vsub(v2.sf,v16.sf)
	}
	{
		v18.qf32 = vmpy(v13.qf32,v17.qf32)
	}
	{
		v31.sf = v18.qf32
	}
	{
		v30.qf32 = vmpy(v20.sf,v31.sf)
		if (!p0) jump:nt .LBB2_59
	}
// %bb.56:                              // %for.body134
	{
		loop0(.LBB2_57,r2)
		v0.sf = v30.qf32
		v1 = vmem(r4++#1)
	}
	{
		v30.qf32 = vmpy(v1.sf,v31.sf)
		if (!p1) jump:nt .LBB2_58
	}
	.balign 32
.LBB2_57:                               // %for.body134
                                        // =>This Inner Loop Header: Depth=1
	{
		v0.sf = v30.qf32
		vmemu(r3++#1) = v0
	}
	{
		v30.qf32 = vmpy(v2.sf,v31.sf)
		v2.cur = vmem(r4++#1)
	} :endloop0
	.falign
.LBB2_58:
	{
		vmemu(r3++#1) = v0
	}
	.falign
.LBB2_59:
	{
		v3.sf = v30.qf32
	}
	{
		vmemu(r3++#1) = v3
	}
	.falign
.LBB2_60:                               // %for.cond.cleanup133
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end2:
	.size	decode_unit, .Lfunc_end2-decode_unit
                                        // -- End function
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym decode_worker
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#decode_worker#(void)#(i32, i32, ptr)#1##"

/tmp/nntr-lfm2-attn-strided-qprep-20261017/codegen/candidate/hvx_quant_u8.o: \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_quant_u8.c \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_convert.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_quant_u8.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_worker_pool.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_quant_u8_group4.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/candidate/nntrainer/tensor/htp_backend/hvx/hvx_rmsnorm_rows_f32.h

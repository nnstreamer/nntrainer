#include <stddef.h>
#include "hexkl_attn_q.h"
const unsigned qprep_io_layout[]={sizeof(hexkl_attn_q_io),offsetof(hexkl_attn_q_io,q),offsetof(hexkl_attn_q_io,q_stride),offsetof(hexkl_attn_q_io,sinks),offsetof(hexkl_attn_q_io,out),offsetof(hexkl_attn_q_io,out_stride),offsetof(hexkl_attn_q_io,kv)};

/tmp/nntr-lfm2-attn-strided-qprep-20261017/codegen/baseline/hvx_attn_decode_q.o: \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_attn_decode_q.c \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_attn_decode_q.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hmx/hexkl_attn_q.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hmx/hexkl_attn_q_plan.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hmx/hexkl_attn_f16_plan.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hmx/hexkl_kv_q.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_worker_pool.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_attn_math_f32.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_attn_softmax_f16.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_convert.h \
  /tmp/nntr-lfm2-attn-strided-qprep-20261017/baseline/nntrainer/tensor/htp_backend/hvx/hvx_tile_f16.h

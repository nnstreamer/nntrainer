#include <hexagon_types.h>
#include <hvx_hexagon_protos.h>
#include <AEEStdErr.h>
#include "hexkl_attn_q.h"
#include "hexkl_acc_tile.h"
#include "hvx_convert.h"
#define TB HEXKL_ATTN_TILE_BYTES
#define TILE_VECS (TB / sizeof(HVX_Vector))
typedef struct {
  uint8_t *vb;
  uint32_t cfg;
  const hexkl_attn_f16_shape *s;
  const hexkl_attn_f16_tiling *t;
  const hexkl_attn_q_io *io;
  const hexkl_kv_q *kv;
  hvx_worker_pool *pool;
  hexkl_attn_q_layout L;
  const hexkl_acc_layout *acc_layout;
  float scale;         /**< log2e / sqrt(hd), folded into the S dequant */
  float *q_scale;      /**< [chunk*g_br] uint8 Q scale times c->scale */
  int32_t *q_zp;       /**< [chunk*g_br] */
  float *l_f32;        /**< [g_br] running sum */
  float *a_f32;        /**< [g_br] this block's rescale, f32 */
  uint16_t *m_hf;      /**< [g_br] running max, fp16 bits */
  uint16_t *a_hf;      /**< [g_br] this block's rescale, fp16 bits */
  HVX_Vector *p_scale; /**< [g_br] uint8 P' scale, each a splat vector so
                            the O update loads it as is. One per row, not
                            per V group: the registry's V scale covers the
                            whole row, so P' is the same for every group */
  HVX_Vector col_idx;
  HVX_Vector cap_hf, inv_cap_hf;
  int softcap_on;
  uint32_t qi; /**< q block index within the current chunk */
  /** per-block parameters handed to the pool workers; frozen while a job
      is in flight */
  uint32_t w_n, w_qb, w_kb, w_buf, w_sbuf;
  int w_masked;
  hexkl_attn_q_stats *st;
} attn_ctx;
typedef struct {
  attn_ctx *c;
  uint32_t n, kb, sbuf;
} dequant_job;
static inline HVX_Vector hvx_tile_load_u(const void *p) {
  HVX_Vector v;
  memcpy(&v, p, sizeof(v));
  return v;
}
static inline uint8_t *q_tile(const attn_ctx *c, uint32_t qi, uint32_t i,
                              uint32_t d) {
  return c->vb + c->L.q_ah +
         ((qi * c->L.n_row_tiles + i) * c->L.n_dot_tiles + d) * TB;
}
static inline uint8_t *kt_tile(const attn_ctx *c, uint32_t buf, uint32_t col,
                               uint32_t d) {
  return c->vb + c->L.kt_wh[buf] +
         (col * c->L.n_dot_tiles + d) * c->L.tile_bytes;
}
static inline HVX_Vector *s_tile(const attn_ctx *c, uint32_t sbuf, uint32_t i32,
                                 uint32_t col) {
  return (HVX_Vector *)(c->vb + c->L.s_hf[sbuf] +
                        (i32 * c->L.n_col_tiles + col) * TB);
}
static inline const HVX_Vector *acc_rows(const attn_ctx *c) {
  return (const HVX_Vector *)(c->vb + c->L.acc) +
         c->acc_layout->base / (sizeof(HVX_Vector) / sizeof(int32_t));
}
static inline void unit_range(uint32_t n, uint32_t n_threads, uint32_t i,
                              uint32_t *lo, uint32_t *hi) {
  *lo = (uint32_t)((uint64_t)n * i / n_threads);
  *hi = (uint32_t)((uint64_t)n * (i + 1) / n_threads);
}
static void dequant_s_at(attn_ctx *c, uint32_t n, uint32_t kb, uint32_t i,
                         uint32_t col, uint32_t sbuf, uint32_t acc_off) {
  const HVX_Vector *restrict acc =
    (const HVX_Vector *)(c->vb + acc_off) + c->acc_layout->base / 32u;
  const uint32_t rs = c->acc_layout->row_stride / 32u; /* vectors per row */
  const uint32_t k0 = kb * c->t->bc + 32u * col;
  const float *restrict qs =
    c->q_scale + (size_t)c->qi * c->t->g_br + HEXKL_ATTN_Q_ROWS * i;
  const int32_t *restrict qz =
    c->q_zp + (size_t)c->qi * c->t->g_br + HEXKL_ATTN_Q_ROWS * i;
  HVX_Vector sk, cs;
  if (k0 + 32u <= c->kv->max_rows) {
    sk = hvx_tile_load_u(c->kv->s_k + hexkl_kv_q_sk_index(c->kv, n, k0));
    cs = Q6_Vsf_equals_Vw(
      hvx_tile_load_u(c->kv->colsum_k + hexkl_kv_q_sk_index(c->kv, n, k0)));
  } else {
    // Past the registry: the tiles were zeroed, the lanes will be masked;
    // keep the arithmetic finite.
    sk = Q6_V_vzero();
    cs = Q6_V_vzero();
  }
  for (uint32_t h = 0; h < 2u; ++h) {
    HVX_Vector *restrict dst = s_tile(c, sbuf, 2u * i + h, col);
    const uint32_t r0 = 32u * h;
    for (uint32_t v = 0; v < TILE_VECS; v += 2u) {
      const uint32_t r = r0 + 2u * v;
      HVX_Vector q[4];
      for (uint32_t p = 0; p < 4u; ++p) {
        const HVX_Vector a = Q6_Vsf_equals_Vw(acc[(r + p) * rs]);
        const HVX_Vector zc =
          Q6_Vsf_vmpy_VsfVsf(Q6_Vsf_equals_Vw(Q6_V_vsplat_R(qz[r + p])), cs);
        const HVX_Vector corr = Q6_Vsf_vsub_VsfVsf(a, zc);
        const HVX_Vector scaled =
          Q6_Vsf_vmpy_VsfVsf(corr, hvx_splat_sf(qs[r + p]));
        q[p] = Q6_Vqf32_vmpy_VsfVsf(scaled, sk);
      }
      dst[v] = Q6_Vhf_equals_Wqf32(Q6_W_vcombine_VV(q[1], q[0]));
      dst[v + 1u] = Q6_Vhf_equals_Wqf32(Q6_W_vcombine_VV(q[3], q[2]));
    }
  }
}
static void dequant_s(attn_ctx *c, uint32_t n, uint32_t kb, uint32_t i,
                      uint32_t col, uint32_t sbuf) {
  dequant_s_at(c, n, kb, i, col, sbuf, c->L.acc);
}
static int qx_dequant_available(const attn_ctx *c) {
  const uint64_t raw_bytes =
    (uint64_t)c->L.n_row_tiles * c->L.n_col_tiles * HEXKL_ATTN_Q_ACC_BYTES;
  const uint64_t qx_bytes =
    (uint64_t)c->L.n_qb_chunk * c->t->g_br * c->s->head_dim * sizeof(float);
  return hvx_worker_pool_workers(c->pool) > 0u && c->kv->kind == HEXKL_KV_Q8 &&
         !c->kv->fixed && c->s->n_q >= 2048u && c->s->n_q % 128u == 0u &&
         c->s->cache_from == 0u && c->s->cache_to == c->s->n_q &&
         c->s->n_head_q == 32u && c->s->n_head_kv == 8u &&
         c->s->head_dim == 64u && c->s->window == 0u && c->s->softcap == 0.0f &&
         !c->io->sinks && c->t->br == 128u && c->t->bc == 256u &&
         c->t->g_br == 512u && raw_bytes <= qx_bytes &&
         c->L.qx_f32 <= c->L.total && c->L.total <= c->cfg &&
         raw_bytes <= (uint64_t)c->L.total - c->L.qx_f32;
}
static void dequant_worker(uint32_t threads, uint32_t id, void *ctx_) {
  const dequant_job *job = (const dequant_job *)ctx_;
  attn_ctx *c = job->c;
  uint32_t lo, hi;
  unit_range(c->L.n_row_tiles * c->L.n_col_tiles, threads, id, &lo, &hi);
  for (uint32_t u = lo; u < hi; ++u) {
    dequant_s_at(c, job->n, job->kb, u / c->L.n_col_tiles, u % c->L.n_col_tiles,
                 job->sbuf, c->L.qx_f32 + u * HEXKL_ATTN_Q_ACC_BYTES);
  }
}

static uint64_t now_us(void);
static void softmax_state_init(attn_ctx *, uint32_t, uint32_t);
static void dma_issue(attn_ctx *, uint32_t, uint32_t, uint32_t);
static void dma_land(attn_ctx *, uint32_t, uint32_t);
static void softmax_start(attn_ctx *, uint32_t, uint32_t, uint32_t, uint32_t, int);
static void softmax_finish_pquant(attn_ctx *, uint32_t);
static int phase_pv(attn_ctx *, uint32_t, int);
static void phase_store(attn_ctx *, uint32_t, uint32_t);
static void hexkl_micro_hmx_acc_clear_int32(void);
static void hexkl_hmx_mm_u8i8(const uint8_t *, const uint8_t *);
static void hexkl_hmx_mm_u8i4(const uint8_t *, const uint8_t *);
static int hexkl_micro_hmx_acc_read_int32(uint8_t *, uint32_t, uint32_t);
static void checked_submit(hvx_worker_pool *, hvx_worker_pool_func, void *, uint32_t);
static void checked_wait(hvx_worker_pool *);
static int phase_qk(attn_ctx *c, uint32_t n, uint32_t kb, uint32_t buf,
                    uint32_t sbuf, int deferred) {
  const int q4 = c->kv->kind == HEXKL_KV_Q4;
  for (uint32_t i = 0; i < c->L.n_row_tiles; ++i) {
    for (uint32_t col = 0; col < c->L.n_col_tiles; ++col) {
      uint64_t t0 = now_us();
      hexkl_micro_hmx_acc_clear_int32();
      if (q4) {
        for (uint32_t d = 0; d < c->L.n_dot_tiles; ++d) {
          hexkl_hmx_mm_u8i4(q_tile(c, c->qi, i, d), kt_tile(c, buf, col, d));
        }
      } else {
        for (uint32_t d = 0; d < c->L.n_dot_tiles; ++d) {
          hexkl_hmx_mm_u8i8(q_tile(c, c->qi, i, d), kt_tile(c, buf, col, d));
        }
      }
      const uint32_t acc_off =
        deferred
          ? c->L.qx_f32 + (i * c->L.n_col_tiles + col) * HEXKL_ATTN_Q_ACC_BYTES
          : c->L.acc;
      int rc = hexkl_micro_hmx_acc_read_int32(c->vb, c->cfg, acc_off);
      if (rc != AEE_SUCCESS) {
        return rc;
      }
      uint64_t t1 = now_us();
      c->st->us_qk += t1 - t0;
      if (!deferred) {
        dequant_s(c, n, kb, i, col, sbuf);
        c->st->us_dequant += now_us() - t1;
      }
    }
  }
  return AEE_SUCCESS;
}
#define hvx_worker_pool_submit checked_submit
#define hvx_worker_pool_wait checked_wait
static int run_q_block(attn_ctx *c, uint32_t n, uint32_t qb) {
  hexkl_attn_q_stats *st = c->st;
  uint32_t kb_lo, kb_hi;
  hexkl_attn_f16_kv_block_range(c->s, c->t, qb, &kb_lo, &kb_hi);
  if (kb_lo >= kb_hi) {
    return AEE_SUCCESS;
  }
  softmax_state_init(c, n, qb);
  const int deferred = qx_dequant_available(c);

  uint64_t t0 = now_us();
  dma_issue(c, n, kb_lo, kb_lo & 1u);
  dma_land(c, kb_lo, kb_lo & 1u);
  st->us_dma += now_us() - t0;
  int rc = phase_qk(c, n, kb_lo, kb_lo & 1u, 0, 0);
  if (rc != AEE_SUCCESS) {
    return rc;
  }

  int first = 1;
  for (uint32_t kb = kb_lo; kb < kb_hi; ++kb) {
    const uint32_t buf = kb & 1u;
    const uint32_t sbuf = (kb - kb_lo) & 1u;
    const int has_next = (kb + 1u < kb_hi);

    t0 = now_us();
    if (has_next) {
      dma_issue(c, n, kb + 1u, buf ^ 1u);
    }
    const int masked = !hexkl_attn_f16_kv_block_unmasked(c->s, c->t, qb, kb);
    softmax_start(c, n, qb, kb, sbuf, masked);
    uint64_t t1 = now_us();
    st->us_softmax += t1 - t0;

    if (has_next) {
      dma_land(c, kb + 1u, buf ^ 1u);
      uint64_t t2 = now_us();
      st->us_dma += t2 - t1;
      rc = phase_qk(c, n, kb + 1u, buf ^ 1u, sbuf ^ 1u, deferred);
      if (rc != AEE_SUCCESS) {
        hvx_worker_pool_wait(c->pool);
        return rc;
      }
    }

    // The softmax of this block has to finish writing P before pquant
    // reads it; both happen here, workers joined in between.
    softmax_finish_pquant(c, buf);

    dequant_job job = {c, n, kb + 1u, sbuf ^ 1u};
    if (deferred && has_next) {
      // Softmax and P quantization have joined. While PV uses L.acc,
      // workers read the next QK block from Qx and write the other S bank.
      t0 = now_us();
      hvx_worker_pool_submit(c->pool, dequant_worker, &job,
                             c->L.n_row_tiles * c->L.n_col_tiles);
      st->us_dequant += now_us() - t0;
    }
    rc = phase_pv(c, buf, first);
    if (deferred && has_next) {
      // Also drain on a PV error before returning stack/metadata storage.
      // Joining here makes the next softmax and Qx reuse safe.
      t0 = now_us();
      hvx_worker_pool_wait(c->pool);
      st->us_dequant += now_us() - t0;
    }
    if (rc != AEE_SUCCESS) {
      return rc;
    }
    first = 0;
    st->n_blocks++;
  }

  t0 = now_us();
  phase_store(c, n, qb);
  st->us_store += now_us() - t0;
  return AEE_SUCCESS;
}
#undef hvx_worker_pool_submit
#undef hvx_worker_pool_wait

// SPDX-License-Identifier: Apache-2.0
/**
 * @file hvx_quant_u8_group4.h
 * @brief Strided four-head packing for cached LFM attention queries.
 */
#ifndef __NNTRAINER_HVX_QUANT_U8_GROUP4_H__
#define __NNTRAINER_HVX_QUANT_U8_GROUP4_H__

#include "hvx_worker_pool.h"
#include <stdint.h>

/**
 * @brief The same parameter/pack arithmetic for groups of four contiguous
 *        FP32 rows, with group_stride floats between groups. The LFM Q8
 *        attention caller uses four hd64 heads per query, avoiding a gather.
 *
 * No padded rows: groups*4 rows are packed. Valid scale/zp entries must already
 * be initialized to 1/0, as for hvx_quant_params_pack_u8_ah. Input and output
 * must be disjoint and stable until the synchronous pool run returns.
 * This narrow helper accepts k=64, group_stride=2048 and 128..2048 groups in
 * multiples of 128 only. It allocates nothing; out_ah has groups*4*k bytes.
 */
int hvx_quant_params_pack_u8_ah_group4(const float *x, uint32_t groups,
                                       uint32_t k, uint32_t group_stride,
                                       float *scale, int32_t *zp,
                                       uint8_t *out_ah, hvx_worker_pool *pool);

#endif

/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/21-hexkl_conv_block.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_conv_block.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_conv_block.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_mm_u8i4_dma.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_mm_opts.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_worker_pool.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_mm_u8i4_moe.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/../htp_router_handoff.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_dma_trace.h \
  /home/jungone-lee/workspace/nntrainer/Qualcomm/hexkl-1.0-beta.2/hexkl_addon/include/hexkl_micro.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_probe.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_acc_tile.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_dma_ring.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_conv_gate_f32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_dequant_i32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_quant_u8.h

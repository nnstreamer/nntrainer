/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/25-hexkl_kv_quant.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_kv_quant.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_kv_quant.h

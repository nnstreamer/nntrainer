/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/45-hvx_gemm_u8i4_wh.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_gemm_u8i4_wh.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_gemm_u8i4_wh.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_expand_i2i4.h

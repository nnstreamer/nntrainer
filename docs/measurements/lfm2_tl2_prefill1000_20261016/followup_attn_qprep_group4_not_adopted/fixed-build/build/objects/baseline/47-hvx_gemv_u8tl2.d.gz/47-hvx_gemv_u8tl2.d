/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/47-hvx_gemv_u8tl2.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_gemv_u8tl2.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_gemv_u8tl2.h

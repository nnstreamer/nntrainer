/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/12-nntr_hvx_skel.o: \
  generated/nntr_hvx_skel.c generated/nntr_hvx.h

/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/38-hvx_router_rows_f32.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_router_rows_f32.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_router_rows_f32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_worker_pool.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_convert.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_rmsnorm_rows_f32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_softmax_f32.h

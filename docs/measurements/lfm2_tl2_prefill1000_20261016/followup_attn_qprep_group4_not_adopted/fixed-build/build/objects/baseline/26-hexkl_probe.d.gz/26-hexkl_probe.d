/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/26-hexkl_probe.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_probe.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_probe.h

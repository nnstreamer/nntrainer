/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/43-hvx_softmax_blocked_f32.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_softmax_blocked_f32.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_convert.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_exp_f32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_softmax_blocked_f32.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_softmax_util.h

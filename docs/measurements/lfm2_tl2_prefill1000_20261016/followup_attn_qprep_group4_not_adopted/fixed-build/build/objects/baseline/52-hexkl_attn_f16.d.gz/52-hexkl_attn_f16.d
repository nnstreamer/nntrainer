/tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/objects/baseline/52-hexkl_attn_f16.o: \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_attn_f16.c \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_attn_f16.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_attn_f16_plan.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_worker_pool.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hmx/hexkl_dma_ring.h \
  /home/jungone-lee/workspace/nntrainer/Qualcomm/hexkl-1.0-beta.2/hexkl_addon/include/hexkl_micro.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_attn_softmax_f16.h \
  /tmp/nntr-lfm2-attn-qprep-fixed-objects-20261017/build/source/nntrainer/tensor/htp_backend/hvx/hvx_tile_f16.h

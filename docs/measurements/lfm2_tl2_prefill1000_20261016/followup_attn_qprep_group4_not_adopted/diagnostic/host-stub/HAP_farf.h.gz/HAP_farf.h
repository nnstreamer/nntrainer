#ifndef QPREP_TEST_FARF_H
#define QPREP_TEST_FARF_H
#include <stdio.h>
#define FARF(level, fmt, ...) do { printf(fmt "\n", ##__VA_ARGS__); } while (0)
#endif

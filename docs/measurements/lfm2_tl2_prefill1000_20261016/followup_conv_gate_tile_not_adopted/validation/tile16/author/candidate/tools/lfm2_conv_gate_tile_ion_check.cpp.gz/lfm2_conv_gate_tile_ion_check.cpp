// SPDX-License-Identifier: Apache-2.0
/** Actual app helpers, cached ION and the existing ThreadManager.
 * No expert I/O or DSP projection work is timed by this CPU-region fixture.
 */
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <stdexcept>
#include <vector>

#include "../Applications/CausalLM/layers/conv_block_layer.cpp"
#include <htp_backend.h>

namespace {
constexpr unsigned C = 2048, N = 6144;
void check(bool ok, const char *message) {
  if (!ok)
    throw std::runtime_error(message);
}
void fill(float *data, size_t n, uint32_t seed, bool special) {
  const uint32_t edge[] = {0u,          0x80000000u, 1u,          0x80000001u,
                           0x00800000u, 0x80800000u, 0x3f800000u, 0xbf800000u,
                           0x7f800000u, 0xff800000u, 0x7fc00021u, 0xffc00042u,
                           0x7f800021u, 0xff800042u, 0x3f800001u, 0xbf800001u};
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    uint32_t bits = (seed & 0x807fffffu) | ((120u + unsigned(i % 12)) << 23);
    if (special)
      bits = edge[(i + seed) % 16];
    std::memcpy(data + i, &bits, sizeof(bits));
  }
}
struct Ion {
  float *data;
  size_t bytes;
  explicit Ion(unsigned rows) :
    data(rows
           ? static_cast<float *>(nntrainer::HtpBackend::global().alloc_shared(
               size_t(rows) * N * 4 + 4096))
           : nullptr),
    bytes(size_t(rows) * N * 4) {
    if (!rows)
      return;
    check(data != nullptr, "ION allocation failed");
    auto to_fd =
      reinterpret_cast<int (*)(void *)>(dlsym(RTLD_DEFAULT, "rpcmem_to_fd"));
    check(to_fd && to_fd(data) >= 0, "allocation is not cached ION");
    std::printf("TILE_ION_ALLOC rows=%u requested=%zu capacity=%zu fd=%d\n",
                rows, bytes, bytes + 4096, to_fd(data));
  }
  ~Ion() {
    if (data)
      nntrainer::HtpBackend::global().free_shared(data);
  }
  Ion(const Ion &) = delete;
  Ion &operator=(const Ion &) = delete;
};
void sampleCopy(float *dst_, const float *src_, size_t bytes) {
  auto *dst = reinterpret_cast<uint8_t *>(dst_);
  const auto *src = reinterpret_cast<const uint8_t *>(src_);
  std::memcpy(dst + bytes - 64, src + bytes - 64, 64);
  for (size_t i = 0; i < 32; ++i) {
    const size_t offset = (bytes - 64) / 32 * i;
    std::memcpy(dst + offset, src + offset, 64);
  }
  check(std::memcmp(dst + bytes - 64, src + bytes - 64, 64) == 0,
        "tail sample differs");
  for (size_t i = 0; i < 32; ++i) {
    const size_t offset = (bytes - 64) / 32 * i;
    check(std::memcmp(dst + offset, src + offset, 64) == 0, "sample differs");
  }
}
struct Fixture {
  unsigned rows;
  Ion first, tail;
  std::vector<float> host, gated, weights, output, state;
  explicit Fixture(unsigned m) :
    rows(m),
    first(m == 2048 ? 1920 : m),
    tail(m == 2048 ? 128 : 0),
    host(size_t(m) * N),
    gated(size_t(m) * C),
    weights(3u * C),
    output(size_t(m) * C),
    state(2u * C) {}
  void prepare(bool special) {
    fill(first.data, first.bytes / 4, 0x192013u, special);
    if (tail.data)
      fill(tail.data, tail.bytes / 4, 0x128013u, special);
    fill(weights.data(), weights.size(), 0x294188u, special);
    std::fill(gated.begin(), gated.end(), -9876.0f);
    std::fill(output.begin(), output.end(), -9876.0f);
    std::fill(state.begin(), state.end(), -77.0f);
  }
  void run(bool tile, bool samples, bool poison_first) {
    for (unsigned start = 0; start < rows; start += 1920) {
      const unsigned count = std::min(1920u, rows - start), end = start + count;
      const float *p = start ? tail.data : first.data;
      if (samples)
        sampleCopy(host.data() + size_t(start) * N, p, size_t(count) * N * 4);
      if (tile) {
        check(causallm::lfmConvGateTilePrefill(p, weights.data(), gated.data(),
                                               output.data(), rows, C, start,
                                               end),
              "valid tile declined");
      } else {
        nntrainer::ThreadManager::Global().parallel_for(
          size_t(start), size_t(end), [&](size_t r) {
            const float *a = p + (r - start) * N, *c = a + 2u * C;
            float *g = gated.data() + r * C;
            for (unsigned j = 0; j < C; ++j)
              g[j] = a[j] * c[j];
          });
        const bool ok =
          rows == 1024
            ? causallm::lfmConvPostGatePrefill(gated.data(), weights.data(), p,
                                               output.data(), rows, C)
            : causallm::lfmConvPostGatePrefillRange(
                gated.data(), weights.data(), p, output.data(), rows, C, start,
                end);
        check(ok, "valid baseline declined");
      }
      if (poison_first && rows == 2048 && start == 0)
        std::memset(first.data, 0xff, first.bytes);
    }
    std::memcpy(state.data(), gated.data() + size_t(rows - 2) * C, 2u * C * 4);
  }
  void exact(bool special, bool poison_first) {
    prepare(special);
    run(false, false, poison_first);
    // Reuse the existing projection host tensor for the reference snapshot.
    std::memcpy(host.data(), output.data(), output.size() * 4);
    std::memcpy(host.data() + output.size(), state.data(), state.size() * 4);
    prepare(special);
    run(true, false, poison_first);
    check(std::memcmp(host.data(), output.data(), output.size() * 4) == 0,
          "ION tile output differs");
    check(std::memcmp(host.data() + output.size(), state.data(),
                      state.size() * 4) == 0,
          "ION tile state differs");
    std::printf("TILE_ION_EXACT rows=%u special=%u old_view_poison=%u PASS\n",
                rows, special, poison_first);
  }
  void sweep_host() {
    // No extra eviction buffer: touch only the existing host projection.
    volatile float *p = host.data();
    for (size_t i = 0; i < host.size(); i += 16)
      p[i] = 1.0f;
  }
  void bench(unsigned repeat, bool sweep) {
    prepare(false);
    for (unsigned warm = 0; warm < 3; ++warm) {
      run(false, true, false);
      run(true, true, false);
    }
    std::array<std::vector<double>, 2> us;
    for (unsigned r = 0; r < repeat; ++r)
      for (unsigned pos = 0; pos < 2; ++pos) {
        const unsigned path = (r + pos) & 1u;
        if (sweep)
          sweep_host();
        const auto begin = std::chrono::steady_clock::now();
        run(path != 0, true, false);
        us[path].push_back(std::chrono::duration<double, std::micro>(
                             std::chrono::steady_clock::now() - begin)
                             .count());
      }
    for (unsigned path = 0; path < 2; ++path) {
      auto &v = us[path];
      std::sort(v.begin(), v.end());
      std::printf("TILE_ION_BENCH rows=%u n=%u host_sweep=%u tile=%u us=%.3f "
                  "min=%.3f max=%.3f\n",
                  rows, repeat, sweep, path, v[repeat / 2], v.front(),
                  v.back());
    }
    std::printf("TILE_ION_RATIO rows=%u host_sweep=%u ratio=%.6f\n", rows,
                sweep, us[1][repeat / 2] / us[0][repeat / 2]);
  }
};
} // namespace
int main(int argc, char **argv) {
  try {
    check(argc <= 2, "usage: lfm2_conv_gate_tile_ion_check [repetitions]");
    const unsigned repeat = argc == 2 ? std::stoul(argv[1]) : 31u;
    check(repeat <= 1000, "too many repetitions");
    check(nntrainer::HtpBackend::global().enabled(), "HTP session unavailable");
    std::printf("TILE_ION_THREADS %u\n",
                nntrainer::ThreadManager::Global().getComputeThreadCount());
    for (unsigned rows : {1024u, 2048u}) {
      Fixture f(rows);
      for (bool special : {false, true}) {
        f.exact(special, false);
        if (rows == 2048)
          f.exact(special, true);
      }
      if (repeat)
        for (bool sweep : {false, true})
          f.bench(repeat, sweep);
    }
    std::puts("TILE_ION_PASS cases=6");
    return 0;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "TILE_ION_FAIL: %s\n", e.what());
    return 1;
  }
}

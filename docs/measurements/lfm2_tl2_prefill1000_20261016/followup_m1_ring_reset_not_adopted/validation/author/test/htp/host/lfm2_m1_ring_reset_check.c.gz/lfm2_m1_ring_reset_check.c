// SPDX-License-Identifier: Apache-2.0
/**
 * @file lfm2_m1_ring_reset_check.c
 * @brief Actual DMA ring lifecycle and descriptor initialization checks.
 * @bug Host DMA is a delayed, ordered emulator; device coherency is not tested.
 */
#include <assert.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hexkl_dma_ring.h"

#if defined(__SANITIZE_ADDRESS__)
#include <sanitizer/asan_interface.h>
#define POISON(p, n) __asan_poison_memory_region((p), (n))
#define UNPOISON(p, n) __asan_unpoison_memory_region((p), (n))
#else
#define POISON(p, n) ((void)0)
#define UNPOISON(p, n) ((void)0)
#endif

typedef struct {
  hexkl_dma_desc2d *desc;
  unsigned char *src, *dst;
  uint32_t row, rows, ss, ds, src_bypass, dst_bypass;
  size_t src_bytes, dst_bytes;
  unsigned delay;
  int started, finished;
} transfer;

static transfer jobs[4096];
static uint32_t n_jobs, submitted, completed, expected;
static uint64_t polls, clean_calls;
static int freeze_engine;
static unsigned cases;

/* These replace only the hardware primitives. The included production TU
 * supplies the ring, fill, reset, push, wait, drain and lane helper bodies. */
static void fixture_clean(void *p) {
  hexkl_dma_desc2d *d = p;
  transfer *t = &jobs[expected];
  assert(d->next == NULL && d->desc_size == 1u && d->desc_type == 9u);
  assert(d->src_comp == 0u && d->dst_comp == 0u && d->order == 0u);
  assert(d->done == 0u && d->reserved0 == 0u && d->reserved1 == 0u);
  assert(d->offset == 0u && d->src == t->src && d->dst == t->dst);
  assert(d->src_stride == t->ss && d->dst_stride == t->ds);
  assert(d->row_size == t->row);
  assert((((uint32_t)d->nrows_hi << 8u) | d->nrows_lo) == t->rows);
  assert(d->src_bypass == t->src_bypass && d->dst_bypass == t->dst_bypass);
  for (uint32_t i = completed; i < submitted; ++i)
    assert(jobs[i].desc != d); /* no reuse before hardware completion */
  ++clean_calls;
}

static void fixture_submit(void *p) {
  assert(expected == submitted && submitted < n_jobs);
  transfer *t = &jobs[submitted++];
  assert(!t->started);
  t->started = 1;
  t->desc = p;
}

static void hexkl_dma_start(void *p) {
  assert(completed == submitted);
  fixture_submit(p);
}

static void hexkl_dma_link(void *cur, void *next) {
  assert(submitted > 0u && jobs[submitted - 1u].desc == cur);
  ((hexkl_dma_desc2d *)cur)->next = next;
  fixture_submit(next);
}

static void hexkl_dma_poll(void) {
  ++polls;
  if (freeze_engine || completed == submitted)
    return;
  transfer *t = &jobs[completed];
  if (t->delay) {
    --t->delay;
    return;
  }
  hexkl_dma_desc2d *d = t->desc;
  /* A reset must not destroy a descriptor still owned by this engine. */
  assert(d->desc_size == 1u && d->desc_type == 9u && !d->done);
  assert(d->src == t->src && d->dst == t->dst);
  assert(d->src_stride == t->ss && d->dst_stride == t->ds);
  assert(d->row_size == t->row &&
         (((uint32_t)d->nrows_hi << 8u) | d->nrows_lo) == t->rows);
  assert(!d->reserved0 && !d->reserved1 && !d->offset);
  for (uint32_t r = 0; r < t->rows; ++r)
    memcpy(t->dst + (size_t)r * t->ds, t->src + (size_t)r * t->ss, t->row);
  d->done = 1u;
  t->finished = 1;
  ++completed;
}

#define Q6_dccleaninva_A(p) fixture_clean(p)
#include "ring-under-test.c"

static void empty_jobs(void) {
  assert(completed == submitted && submitted == n_jobs);
  for (uint32_t i = 0; i < n_jobs; ++i) {
    transfer *t = &jobs[i];
    assert(t->finished);
    for (uint32_t r = 0; r < t->rows; ++r) {
      assert(memcmp(t->dst + (size_t)r * t->ds, t->src + (size_t)r * t->ss,
                    t->row) == 0);
      for (uint32_t j = t->row; j < t->ds; ++j)
        assert(t->dst[(size_t)r * t->ds + j] == 0xcd);
    }
    free(t->src);
    free(t->dst);
  }
  memset(jobs, 0, sizeof(jobs));
  n_jobs = submitted = completed = expected = 0u;
}

static uint32_t add_transfer(uint32_t row, uint32_t rows, unsigned delay,
                             unsigned flags) {
  assert(n_jobs < sizeof(jobs) / sizeof(jobs[0]));
  const uint32_t i = n_jobs++;
  transfer *t = &jobs[i];
  t->row = row;
  t->rows = rows;
  t->ss = row + 7u;
  t->ds = row + 13u;
  t->src_bytes = (size_t)t->ss * rows;
  t->dst_bytes = (size_t)t->ds * rows;
  t->src = malloc(t->src_bytes);
  t->dst = malloc(t->dst_bytes);
  assert(t->src && t->dst);
  for (size_t k = 0; k < t->src_bytes; ++k)
    t->src[k] = (unsigned char)(i * 67u + k * 11u + 3u);
  memset(t->dst, 0xcd, t->dst_bytes);
  t->src_bypass = flags & 1u;
  t->dst_bypass = (flags >> 1u) & 1u;
  t->delay = delay;
  expected = i;
  const uint32_t idx = hexkl_dma_ring_next_idx();
  hexkl_dma_ring_push2d(t->dst, t->src, t->ds, t->ss, row, rows, t->src_bypass,
                        t->dst_bypass);
  assert(t->desc == &g_ring[idx]);
  return idx;
}

static void assert_try_unchanged(int wanted) {
  unsigned char before[sizeof(g_ring)];
  memcpy(before, g_ring, sizeof(before));
  const uint32_t push = g_push, pop = g_pop;
  hexkl_dma_desc2d *tail = g_tail;
  const int started = g_started;
  const uint64_t before_polls = polls;
  assert(hexkl_dma_ring_try_reset() == wanted);
  assert(memcmp(before, g_ring, sizeof(before)) == 0);
  assert(polls == before_polls); /* eligibility check never waits */
  if (wanted) {
    assert(!g_push && !g_pop && !g_started && g_tail == NULL);
  } else {
    assert(g_push == push && g_pop == pop && g_started == started &&
           g_tail == tail);
  }
  ++cases;
}

static void check_unknown(void) {
  hexkl_dma_ring_reset();
  assert_try_unchanged(0); /* type-zero sentinel */
  add_transfer(32u, 2u, 0u, 0u);
  hexkl_dma_ring_drain();
  hexkl_dma_desc2d *tail = g_tail;
  tail->desc_type = 7u;
  assert_try_unchanged(0);
  tail->desc_type = 9u;
  tail->desc_size = 0u;
  assert_try_unchanged(0);
  tail->desc_size = 1u;
  g_ring[17] = *tail; /* valid-looking fields, wrong current-tail identity */
  g_tail = &g_ring[17];
  assert_try_unchanged(0);
  g_tail = tail;
  assert_try_unchanged(1);
  assert_try_unchanged(0); /* an empty successful reset has no proven tail */
  empty_jobs();
}

static void check_delayed_and_stale(void) {
  for (unsigned repeat = 0; repeat < 32u; ++repeat) {
    hexkl_dma_ring_reset();
    add_transfer(31u + repeat, 1u + repeat, 0u, repeat);
    hexkl_dma_ring_drain();
    assert_try_unchanged(1);
    empty_jobs();
    /* Reuse the same descriptor, whose done was 1. Fill must clear it
     * before submit; checking before completion must not see stale done. */
    add_transfer(17u, 3u, 2u, repeat ^ 3u);
    assert_try_unchanged(0);
    hexkl_dma_poll();
    assert_try_unchanged(0);
    hexkl_dma_ring_wait(0u);
    assert_try_unchanged(1); /* individually waited, not drained */
    empty_jobs();
  }
}

static void check_wrap(void) {
  static const unsigned counts[] = {1, 2, 254, 255, 256, 257, 511, 512, 769};
  for (unsigned mode = 0; mode < 2u; ++mode)
    for (unsigned c = 0; c < sizeof(counts) / sizeof(counts[0]); ++c) {
      hexkl_dma_ring_reset();
      for (unsigned i = 0; i < counts[c]; ++i)
        add_transfer(1u + i % 31u, 1u + i % 3u, i % 3u, i);
      assert_try_unchanged(0);
      if (mode)
        hexkl_dma_ring_wait((g_push - 1u) & (HEXKL_DMA_RING_N - 1u));
      else
        hexkl_dma_ring_drain();
      assert(completed == submitted);
      assert_try_unchanged(1);
      empty_jobs();
    }
}

static void check_prior_timeout(void) {
  /* Use the unmodified production 50,000,000-poll limit. Last index 255
   * exposes the wrap-to-zero case: equal software indices are not proof
   * that hardware completed after the old void drain timed out. */
  hexkl_dma_ring_reset();
  for (unsigned i = 0; i < 256u; ++i)
    add_transfer(1u, 1u, 0u, i);
  while (completed < 255u)
    hexkl_dma_poll();
  freeze_engine = 1;
  const uint64_t before = polls;
  hexkl_dma_ring_drain();
  assert(polls - before == 50000000u);
  assert(g_push == 0u && g_pop == 0u && g_started == 0);
  assert(g_tail == &g_ring[255] && !g_tail->done);
  assert_try_unchanged(0);
  /* The test owns the simulated engine and retires it before ordinary
   * cleanup. Production's unchanged fallback does not repair this case. */
  freeze_engine = 0;
  hexkl_dma_poll();
  assert_try_unchanged(1);
  empty_jobs();
}

static void check_poison_and_fields(void) {
  hexkl_dma_ring_reset();
  add_transfer(37u, 257u, 0u, 3u);
  hexkl_dma_ring_drain();
  assert_try_unchanged(1);
  empty_jobs();
  /* Preserve arbitrary old bytes. Fill must define each semantic field,
   * including reserved bits, without depending on a whole-slab clear. */
  memset(g_ring, 0xa5, sizeof(g_ring));
  add_transfer(13u, 256u, 0u, 0u);
  hexkl_dma_ring_drain();
  unsigned char before[sizeof(g_ring)];
  memcpy(before, g_ring, sizeof(before));
  /* In a 64-bit host descriptor the last semantic word ends at byte 48.
   * On v81 the hardware fields are the first 32 bytes; its layout is
   * checked separately by the actual target compile. */
  const size_t fields = sizeof(void *) == 8u ? 48u : 32u;
  POISON((unsigned char *)&g_ring[0] + fields, sizeof(g_ring[0]) - fields);
  POISON(&g_ring[1], sizeof(g_ring) - sizeof(g_ring[0]));
  assert(hexkl_dma_ring_try_reset() == 1);
  UNPOISON(g_ring, sizeof(g_ring));
  assert(memcmp(before, g_ring, sizeof(before)) == 0);
  assert(!g_push && !g_pop && !g_started && !g_tail);
  ++cases;
  empty_jobs();
  hexkl_dma_ring_reset(); /* ordinary reset still clears the entire slab */
  for (size_t i = 0; i < sizeof(g_ring); ++i)
    assert(((unsigned char *)g_ring)[i] == 0u);
}

int main(void) {
  setvbuf(stdout, NULL, _IONBF, 0);
  assert(sizeof(hexkl_dma_desc2d) == 128u);
  assert(g_tail == NULL && !g_push && !g_pop && !g_started);
  assert_try_unchanged(0); /* initial BSS is not a completed descriptor */
  check_unknown();
  check_delayed_and_stale();
  check_wrap();
  check_poison_and_fields();
  check_prior_timeout();
  printf(
    "actual ring: %u lifecycle/reset checks, %llu fills, %llu polls PASS\n",
    cases, (unsigned long long)clean_calls, (unsigned long long)polls);
  return 0;
}

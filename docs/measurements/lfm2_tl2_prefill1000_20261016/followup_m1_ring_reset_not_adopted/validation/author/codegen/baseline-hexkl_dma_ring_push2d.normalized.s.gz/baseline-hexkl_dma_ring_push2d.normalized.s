hexkl_dma_ring_push2d:
{
r6 = add(pc,##g_push@PCREL)
r13 = memw(r29+#0)
}
{
r7 = add(pc,##g_pop@PCREL)
}
{
r12 = memw(r6+#0)
}
{
r8 = add(r12,#1)
r9 = memw(r7+#0)
}
{
r8 = add(pc,##g_ring@PCREL)
r14 = and(r8,#255)
}
{
p1 = cmp.eq(r14,r9)
if (!p1.new) jump:t .LBB_7
r9 = memw(r29+#4)
}
{
r15 = addasl(r8,r14,#7)
}
{
r28 = memw(r15+#4)
if (!cmp.gt(r28.new,#-1)) jump:nt .LBB_6
}
{
r12 = #0
}
.LBB_3:
{
r14 = dmpoll
}
{
r14 = memw(r15+#4)
if (!cmp.gt(r14.new,#-1)) jump:nt .LBB_5
}
{
p0 = cmp.gtu(r12,##49999998)
r12 = add(r12,#1)
if (!p0.new) jump:t .LBB_3
}
.LBB_5:
{
r14 = memw(r7+#0)
r12 = memw(r6+#0)
}
.LBB_6:
{
r14 = add(r14,#1)
}
{
r14 = and(r14,#255)
memw(r7+#0) = r14.new
}
.LBB_7:
{
r7 = extractu(r2,#24,#0)
r4 = extractu(r4,#24,#0)
p1 = cmp.eq(r13,#0)
p0 = cmp.eq(r9,#0)
}
{
r2 = addasl(r8,r12,#7)
r13 = setbit(r7,#29)
r1:0 = combine(r0,r1)
r14 = #0
}
{
r11 = extractu(r5,#8,#8)
r4 |= asl(r5,#24)
if (!p1) r7 = add(r13,#0)
}
{
r5 = setbit(r7,#28)
r15 = asl(r12,#7)
memw(r2+#20) = r4
memw(r2+#16) = #9
}
{
r11 |= asl(r3,#8)
if (!p0) r7 = add(r5,#0)
memw(r8+r15<<#0) = r14
memw(r2+#28) = #0
}
{
r4 = add(pc,##g_started@PCREL)
r3 = setbit(r7,#24)
memd(r2+#8) = r1:0
}
{
memw(r2+#24) = r11
memw(r2+#4) = r3
}
{
dccleaninva(r2)
}
{
r3 = memub(r4+#0)
}
{
r3 = add(pc,##g_tail@PCREL)
p0 = r3
if (!p0.new) jump:t .LBB_9
}
{
r4 = memw(r3+#0)
}
{
release(r2):at
}
{
dmlink(r4,r2)
}
{
jump .LBB_10
}
.LBB_9:
{
release(r2):at
}
{
dmstart(r2)
}
{
memb(r4+#0) = #1
}
.LBB_10:
{
r4 = memw(r6+#0)
memw(r3+#0) = r2
}
{
r4 = add(r4,#1)
}
{
r0 = and(r4,#255)
jumpr r31
memw(r6+#0) = r0.new
}

moe_push_gate_up_chunks:
{
memd(r29+#-16) = r17:16
allocframe(#168)
}
{
r23 = memw(r29+#176)
memd(r29+#136) = r23:22
}
{
p1 = cmp.eq(r23,#0)
memd(r29+#152) = r19:18
memd(r29+#144) = r21:20
}
{
memd(r29+#128) = r25:24
memd(r29+#120) = r27:26
}
{
memw(r29+#28) = r4
memw(r29+#40) = r2
}
{
if (p1) jump:nt .LBB_59
if (!p1) r27 = memw(r29+#188)
memw(r29+#36) = r1
}
{
r3 = asl(r5,#9)
r17:16 = combine(r3,#0)
r25:24 = combine(#0,#0)
r22 = memw(r29+#180)
}
{
r3 = lsr(r3,#1)
r21:20 = combine(#0,r23)
r18 = r0
memw(r29+#48) = r3
}
{
r2 = memw(r29+#36)
memw(r29+#68) = r3
}
{
r3 = add(pc,##g_moe_src_bypass@PCREL)
r1:0 = vaslw(r23:22,#9)
r4 = add(r0,r2)
}
{
r3 = #0
memw(r29+#16) = r3
}
{
r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
r6 = memw(r29+#184)
memd(r29+#96) = r3:2
}
{
r2 = add(r2,r1)
memw(r29+#44) = r4
memw(r29+#24) = r6
}
{
memd(r29+#88) = r1:0
memw(r29+#72) = r2
}
{
memw(r29+#56) = r18
memw(r29+#20) = r3
}
.LBB_2:
{
r4 = minu(r22,r20)
r5 = add(r23,r16)
r3 = #0
r2 = memw(r17+#44)
}
{
r26 = minu(r5,r22)
r3 = insert(r4,#23,#8)
p0 = cmp.eq(r2,#0)
r0 = memw(r29+#44)
}
{
r2 = add(r0,r3)
if (!p0) r5:4 = combine(r26,r25)
if (p0) jump:nt .LBB_8
memw(r29+#32) = r2.new
}
{
r2 = add(r29,#76)
r0 = r18
r1 = memw(r29+#16)
memw(r29+#4) = r2.new
}
{
r3 = r17
r6 = memw(r29+#24)
memw(r29+#76) = #1
}
{
r2 = memw(r1+#0)
memw(r29+#0) = r2.new
}
{
r1 = memw(r29+#36)
memw(r29+#80) = r6
}
{
call moe_push_native_chunk
r2 = memw(r29+#40)
memw(r29+#84) = r24
}
.LBB_4:
{
r4 = add(r23,r25)
r2 = memw(r17+#44)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_13
}
{
r2 = add(r29,#76)
r5 = r26
r1 = memw(r29+#16)
memw(r29+#4) = r2.new
}
{
r3 = r17
r0 = r18
r6 = memw(r29+#24)
}
{
r2 = memw(r1+#0)
memw(r29+#0) = r2.new
}
{
r1 = memw(r29+#36)
memw(r29+#76) = #2
}
{
r2 = memw(r29+#40)
memw(r29+#80) = r6
}
{
call moe_push_native_chunk
memw(r29+#84) = r24
}
{
r26 = r0
}
.LBB_7:
{
r25 = add(r25,r22)
r24 = add(r24,#1)
r1:0 = memd(r29+#88)
memw(r27++#4) = r26
}
{
p0 = cmp.gtu(r23,r25)
r21 = add(r21,r0)
r20 = sub(r20,r22)
r16 = sub(r16,r22)
}
{
if (p0) jump:nt .LBB_2
}
{
jump .LBB_59
}
.LBB_8:
{
r3 = memw(r29+#16)
r2 = memw(r17+#84)
}
{
r2 = asl(r26,#9)
p1 = cmp.eq(r2,#2)
memw(r29+#52) = r2.new
}
{
r3 = memw(r3+#0)
}
{
p0 = cmp.eq(r3,#0)
}
{
r3 = p0
if (!p1) jump:nt .LBB_18
memw(r29+#60) = r3.new
}
{
call hexkl_dma_ring_next_idx
r19 = lsr(r2,#1)
}
{
r18 = #0
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
memw(r29+#64) = r0
} :mem_noshuf
{
r1:0 = combine(#0,#0)
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_26
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r3 = memw(r29+#28)
}
{
r1:0 = memd(r29+#96)
}
{
r3 = mpyi(r19,r3)
r5 = r1
r1:0 = memd(r2+#56)
}
{
r4 = lsr(r3,#10)
r3 = r5
}
{
r1:0 = add(r1:0,r5:4)
memd(r29+#96) = r3:2
}
{
memd(r2+#56) = r1:0
}
{
r1:0 = c31:30
}
{
call HAP_perf_qtimer_count_to_us
}
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p1 = r2
if (!p1.new) jump:t .LBB_27
r5 = memw(r17+#4)
}
{
jump .LBB_29
}
.LBB_13:
{
r3 = memw(r29+#16)
r2 = memw(r17+#84)
}
{
r2 = asl(r26,#9)
p0 = cmp.eq(r2,#2)
memw(r29+#52) = r2.new
}
{
r3 = memw(r3+#0)
}
{
p1 = cmp.eq(r3,#0)
}
{
r3 = p1
if (!p0) jump:nt .LBB_22
memw(r29+#60) = r3.new
}
{
call hexkl_dma_ring_next_idx
r19 = lsr(r2,#1)
}
{
r26 = r0
r18 = #0
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
memw(r29+#64) = r19
} :mem_noshuf
{
r1:0 = combine(#0,#0)
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_32
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r3 = memw(r29+#28)
}
{
r1:0 = memd(r29+#96)
}
{
r3 = mpyi(r19,r3)
r5 = r1
r1:0 = memd(r2+#56)
}
{
r4 = lsr(r3,#10)
r3 = r5
}
{
r1:0 = add(r1:0,r5:4)
memd(r29+#96) = r3:2
}
{
memd(r2+#56) = r1:0
}
{
r1:0 = c31:30
}
{
call HAP_perf_qtimer_count_to_us
}
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p1 = r2
if (!p1.new) jump:t .LBB_33
r3 = memw(r17+#4)
}
{
jump .LBB_35
}
.LBB_18:
{
call hexkl_dma_ring_next_idx
}
{
r18 = #0
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
memw(r29+#64) = r0
} :mem_noshuf
{
r1:0 = combine(#0,#0)
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_38
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r3 = memw(r29+#28)
}
{
r4 = memw(r29+#52)
r1:0 = memd(r29+#96)
}
{
r5 = r1
r1:0 = memd(r2+#56)
}
{
r3 = mpyi(r4,r3)
}
{
r4 = lsr(r3,#10)
r3 = r5
}
{
r1:0 = add(r1:0,r5:4)
memd(r29+#96) = r3:2
}
{
memd(r2+#56) = r1:0
}
{
r1:0 = c31:30
}
{
call HAP_perf_qtimer_count_to_us
}
{
r3 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p0 = r3
if (!p0.new) jump:t .LBB_39
r2 = memw(r17+#4)
}
{
jump .LBB_41
}
.LBB_22:
{
call hexkl_dma_ring_next_idx
}
{
r26 = r0
r18 = #0
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_48
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r3 = memw(r29+#28)
}
{
r4 = memw(r29+#52)
r1:0 = memd(r29+#96)
}
{
r5 = r1
r1:0 = memd(r2+#56)
}
{
r3 = mpyi(r4,r3)
}
{
r4 = lsr(r3,#10)
r3 = r5
}
{
r1:0 = add(r1:0,r5:4)
memd(r29+#96) = r3:2
}
{
memd(r2+#56) = r1:0
}
{
r1:0 = c31:30
}
{
call HAP_perf_qtimer_count_to_us
}
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p0 = r2
if (!p0.new) jump:t .LBB_49
r5 = memw(r17+#4)
}
{
jump .LBB_51
}
.LBB_26:
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p1 = r2
if (p1.new) jump:nt .LBB_29
r5 = memw(r17+#4)
}
.LBB_27:
{
r18 = #1
r2 = memw(r17+#36)
if (!cmp.eq(r2.new,#0)) jump:t .LBB_29
}
{
r2 = memw(r17+#40)
}
{
r18 = !cmp.eq(r2,#0)
}
.LBB_29:
{
r6 = lsr(r21,#1)
r4 = r19
r2 = memw(r29+#32)
memw(r29+#0) = r18
}
{
r0 = add(r2,r21)
r1 = add(r5,r6)
r2 = memw(r29+#48)
memw(r29+#4) = #1
}
{
call hexkl_dma_ring_push2d
r3 = memw(r29+#68)
r5 = memw(r29+#28)
}
{
r2 = memw(r29+#20)
}
{
r2 = memw(r2+##hexkl_probe_on@GOT)
r18 = memw(r29+#56)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt ##.LBB_4
}
{
r1:0 = c31:30
}
{
jump .LBB_44
}
.LBB_32:
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p1 = r2
if (p1.new) jump:nt .LBB_35
r3 = memw(r17+#4)
}
.LBB_33:
{
r18 = #1
r2 = memw(r17+#36)
if (!cmp.eq(r2.new,#0)) jump:t .LBB_35
}
{
r2 = memw(r17+#40)
}
{
r18 = !cmp.eq(r2,#0)
}
.LBB_35:
{
r0 = r21
r5:4 = memd(r29+#88)
memw(r29+#0) = r18
}
{
r2 = add(r5,r21)
r6 = memw(r29+#32)
memw(r29+#4) = #1
}
{
r4 = lsr(r2,#1)
r2 = memw(r29+#48)
}
{
r1 = add(r3,r4)
r3 = memw(r29+#68)
r4 = memw(r29+#64)
}
{
r0 += add(r6,r5)
call hexkl_dma_ring_push2d
r5 = memw(r29+#28)
}
{
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_58
}
{
r1:0 = c31:30
}
{
jump .LBB_54
r18 = memw(r29+#56)
}
.LBB_38:
{
r3 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p0 = r3
if (p0.new) jump:nt .LBB_41
r2 = memw(r17+#4)
}
.LBB_39:
{
r18 = #1
r3 = memw(r17+#36)
if (!cmp.eq(r3.new,#0)) jump:t .LBB_41
}
{
r3 = memw(r17+#40)
}
{
r18 = !cmp.eq(r3,#0)
}
.LBB_41:
{
r1 = add(r2,r21)
r2 = memw(r29+#44)
memw(r29+#0) = r18
}
{
r0 = add(r2,r21)
r2 = memw(r29+#48)
memw(r29+#4) = #1
}
{
call hexkl_dma_ring_push2d
r3 = r2
r4 = memw(r29+#52)
r5 = memw(r29+#28)
}
{
r2 = memw(r29+#20)
}
{
r2 = memw(r2+##hexkl_probe_on@GOT)
r18 = memw(r29+#56)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt ##.LBB_4
}
{
r1:0 = c31:30
}
.LBB_44:
{
call HAP_perf_qtimer_count_to_us
}
{
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r5:4 = memd(r29+#104)
}
{
r1:0 = sub(r1:0,r5:4)
}
{
r7:6 = memd(r2+#96)
}
{
r1:0 = add(r1:0,r7:6)
}
{
memd(r2+#96) = r1:0
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt ##.LBB_4
}
{
r1:0 = c31:30
}
{
r3 = #1
r5 = r24
r2 = memw(r29+#52)
memw(r29+#0) = r2.new
}
{
r2 = memw(r29+#28)
memw(r29+#4) = r2.new
}
{
r4 = memw(r29+#48)
memw(r29+#8) = r4.new
}
{
call hexkl_dma_trace_push
r2 = memw(r29+#64)
r4 = memw(r29+#24)
}
{
jump .LBB_4
}
.LBB_48:
{
r1:0 = combine(#0,#0)
}
{
r2 = memw(r29+#60)
memd(r29+#104) = r1:0
}
{
p0 = r2
if (p0.new) jump:nt .LBB_51
r5 = memw(r17+#4)
}
.LBB_49:
{
r18 = #1
r2 = memw(r17+#36)
if (!cmp.eq(r2.new,#0)) jump:t .LBB_51
}
{
r2 = memw(r17+#40)
}
{
r18 = !cmp.eq(r2,#0)
}
.LBB_51:
{
r1:0 = combine(r21,r21)
r2 = memw(r29+#48)
r7:6 = memd(r29+#88)
}
{
r1 += add(r5,r7)
r3 = r2
r5 = memw(r29+#28)
memw(r29+#0) = r18
}
{
r18 = memw(r29+#56)
memw(r29+#4) = #1
}
{
r6 = memw(r29+#72)
r4 = memw(r29+#52)
}
{
r0 += add(r18,r6)
call hexkl_dma_ring_push2d
}
{
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt ##.LBB_7
}
{
r1:0 = c31:30
}
.LBB_54:
{
call HAP_perf_qtimer_count_to_us
}
{
r3 = memw(r29+#20)
}
{
r2 = memw(r3+##hexkl_probe_us@GOT)
r5:4 = memd(r29+#104)
}
{
r1:0 = sub(r1:0,r5:4)
}
{
r7:6 = memd(r2+#96)
}
{
r1:0 = add(r1:0,r7:6)
}
{
memd(r2+#96) = r1:0
}
{
r2 = memw(r3+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt ##.LBB_7
}
{
r1:0 = c31:30
}
{
r5 = r24
r2 = memw(r29+#52)
memw(r29+#0) = r2.new
}
{
r2 = memw(r29+#28)
memw(r29+#4) = r2.new
}
{
r3:2 = combine(#2,r26)
r4 = memw(r29+#48)
memw(r29+#8) = r4.new
}
{
call hexkl_dma_trace_push
r4 = memw(r29+#24)
}
{
jump .LBB_7
}
.LBB_58:
{
jump .LBB_7
r18 = memw(r29+#56)
}
.LBB_59:
{
r17:16 = memd(r29+#160)
r19:18 = memd(r29+#152)
}
{
r21:20 = memd(r29+#144)
r23:22 = memd(r29+#136)
}
{
r25:24 = memd(r29+#128)
r27:26 = memd(r29+#120)
}
{
r31:30 = dealloc_return(r30):raw
}

hexkl_dma_ring_drain:
{
r2 = add(pc,##g_pop@PCREL)
}
{
r3 = add(pc,##g_push@PCREL)
r5 = memw(r2+#0)
}
{
r6 = memw(r3+#0)
if (cmp.eq(r6.new,r5)) jump:t .LBB_7
}
{
r4 = add(pc,##g_ring@PCREL)
}
.LBB_2:
{
r7 = addasl(r4,r5,#7)
}
{
r8 = memw(r7+#4)
}
{
p1 = cmp.gt(r8,#-1)
r8 = #0
if (!p1.new) jump:nt .LBB_6
}
.LBB_3:
{
r5 = dmpoll
}
{
r5 = memw(r7+#4)
if (!cmp.gt(r5.new,#-1)) jump:nt .LBB_5
}
{
p1 = cmp.gtu(r8,##49999998)
r8 = add(r8,#1)
if (!p1.new) jump:t .LBB_3
}
.LBB_5:
{
r5 = memw(r2+#0)
r6 = memw(r3+#0)
}
.LBB_6:
{
r5 = add(r5,#1)
}
{
r5 = and(r5,#255)
memw(r2+#0) = r5.new
}
{
p0 = cmp.eq(r5,r6); if (!p0.new) jump:t .LBB_2
}
.LBB_7:
{
r2 = add(pc,##g_started@PCREL)
}
{
jumpr r31
memb(r2+#0) = #0
}

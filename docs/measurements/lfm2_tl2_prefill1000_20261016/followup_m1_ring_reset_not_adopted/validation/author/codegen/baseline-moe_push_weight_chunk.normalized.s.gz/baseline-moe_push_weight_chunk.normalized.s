moe_push_weight_chunk:
{
memd(r29+#-16) = r17:16
allocframe(#56)
}
{
r18 = r5
r6 = memw(r3+#44)
memd(r29+#40) = r19:18
}
{
p0 = cmp.eq(r6,#0)
r5 = memw(r29+#64)
memd(r29+#32) = r21:20
}
{
if (p0) r2 = add(r3,#0)
r21 = r4
r17 = memw(r29+#76)
r16 = memw(r29+#80)
}
{
if (p0) jump:nt .LBB_3
r20 = memw(r29+#72)
r19 = memw(r29+#68)
}
{
r6 = add(pc,##g_moe_src_bypass@PCREL)
r4 = add(r29,#20)
memw(r29+#4) = r4.new
}
{
r4 = r5
r5 = r19
memw(r29+#20) = r20
memw(r29+#24) = r17
}
{
r6 = memw(r6+#0)
memw(r29+#28) = r16
}
{
call moe_push_native_chunk
memw(r29+#0) = r6
}
.LBB_2:
{
r17:16 = memd(r29+#48)
r19:18 = memd(r29+#40)
}
{
r21:20 = memd(r29+#32)
dealloc_return
}
.LBB_3:
{
r6 = add(pc,##g_moe_src_bypass@PCREL)
}
{
r4 = r18
r3 = r4
memw(r29+#0) = r19
}
{
call hexkl_moe_push_weight_chunk
r6 = memw(r6+#0)
memw(r29+#4) = r6.new
}
{
r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
}
{
r2 = memw(r2+##hexkl_probe_on@GOT)
}
{
r2 = memw(r2+#0)
if (cmp.eq(r2.new,#0)) jump:nt .LBB_2
}
{
r3:2 = c31:30
}
{
r7:6 = vaslw(r19:18,#9)
r18 = r0
r1:0 = combine(r3,r2)
r5:4 = combine(r16,r17)
}
{
r3:2 = combine(r20,r18)
memw(r29+#0) = r7
memw(r29+#4) = r21
}
{
call hexkl_dma_trace_push
memw(r29+#8) = r6
}
{
r0 = r18
r17:16 = memd(r29+#48)
r19:18 = memd(r29+#40)
}
{
r21:20 = memd(r29+#32)
dealloc_return
}

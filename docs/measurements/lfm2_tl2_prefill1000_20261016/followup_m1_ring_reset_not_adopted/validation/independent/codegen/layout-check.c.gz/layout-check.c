#include <stddef.h>
#include "hexkl_dma_ring.h"
_Static_assert(sizeof(hexkl_dma_desc2d) == 128u, "descriptor array stride");
_Static_assert(_Alignof(hexkl_dma_desc2d) == 128u, "descriptor alignment");
_Static_assert(sizeof(void *) == 4u, "target pointers");
_Static_assert(offsetof(hexkl_dma_desc2d, src) == 8u, "source word");
_Static_assert(offsetof(hexkl_dma_desc2d, dst) == 12u, "destination word");
int ring_layout_check(void) { return sizeof(hexkl_dma_desc2d); }

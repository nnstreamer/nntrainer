	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hexkl_dma_ring.c"
	.globl	hexkl_dma_ring_reset            // -- Begin function hexkl_dma_ring_reset
	.balign 32
	.type	hexkl_dma_ring_reset,@function
hexkl_dma_ring_reset:                   // @hexkl_dma_ring_reset
// %bb.0:                               // %entry
	{
		r16 = add(pc,##g_ring@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		call memset
		r2 = ##32768
		r1:0 = combine(#0,r16)
	}
	{
		r2 = add(pc,##g_push@PCREL)
		r0 = add(r16,#32640)
		r17:16 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r3 = add(pc,##g_pop@PCREL)
	}
	{
		r4 = add(pc,##g_tail@PCREL)
		memw(r2+#0) = #0
	}
	{
		r5 = add(pc,##g_started@PCREL)
		memw(r3+#0) = #0
	}
	{
		memw(r4+#0) = r0
	}
	{
		memb(r5+#0) = #0
	}
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end0:
	.size	hexkl_dma_ring_reset, .Lfunc_end0-hexkl_dma_ring_reset
                                        // -- End function
	.globl	hexkl_dma_ring_try_reset        // -- Begin function hexkl_dma_ring_try_reset
	.falign
	.type	hexkl_dma_ring_try_reset,@function
hexkl_dma_ring_try_reset:               // @hexkl_dma_ring_try_reset
// %bb.0:                               // %entry
	{
		r2 = add(pc,##g_tail@PCREL)
		r0 = #0
	}
	{
		r4 = memw(r2+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB1_5
	}
// %bb.1:                               // %entry
	{
		r3 = add(pc,##g_push@PCREL)
	}
	{
		r5 = add(pc,##g_ring@PCREL)
		r6 = memw(r3+#0)
	}
	{
		r6 = add(r6,#-1)
	}
	{
		r6 = and(r6,#255)
	}
	{
		r5 = addasl(r5,r6,#7)
		if (!cmp.eq(r5.new,r4)) jump:nt .LBB1_5
	}
// %bb.2:                               // %lor.lhs.false2
	{
		r6 = memw(r4+#4)
	}
	{
		r6 = and(r6,##50331648)
	}
	{
		p0 = cmp.eq(r6,##16777216)
		if (!p0.new) jumpr:nt r31
	}
.LBB1_3:                                // %lor.lhs.false4
	{
		r4 = memub(r4+#16)
		if (!cmp.eq(r4.new,#9)) jump:t .LBB1_5
	}
// %bb.4:                               // %lor.lhs.false8
	{
		r4 = memw(r5+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB1_6
	}
	.falign
.LBB1_5:                                // %cleanup
	{
		jumpr r31
	}
	.falign
.LBB1_6:                                // %if.end
	{
		r3 = add(pc,##g_pop@PCREL)
		r0 = #1
		memw(r3+#0) = #0
	}
	{
		r4 = add(pc,##g_started@PCREL)
		memw(r2+#0) = #0
	}
	{
		memw(r3+#0) = #0
	}
	{
		jumpr r31
		memb(r4+#0) = #0
	}
.Lfunc_end1:
	.size	hexkl_dma_ring_try_reset, .Lfunc_end1-hexkl_dma_ring_try_reset
                                        // -- End function
	.globl	hexkl_dma_ring_is_done          // -- Begin function hexkl_dma_ring_is_done
	.balign 32
	.type	hexkl_dma_ring_is_done,@function
hexkl_dma_ring_is_done:                 // @hexkl_dma_ring_is_done
// %bb.0:                               // %entry
	{
		r3 = add(pc,##g_ring@PCREL)
		r2 = and(r0,#255)
	}
	{
		r2 = addasl(r3,r2,#7)
	}
	{
		r2 = memw(r2+#4)
	}
	{
		r0 = lsr(r2,#31)
		jumpr r31
	}
.Lfunc_end2:
	.size	hexkl_dma_ring_is_done, .Lfunc_end2-hexkl_dma_ring_is_done
                                        // -- End function
	.globl	hexkl_dma_ring_push2d           // -- Begin function hexkl_dma_ring_push2d
	.falign
	.type	hexkl_dma_ring_push2d,@function
hexkl_dma_ring_push2d:                  // @hexkl_dma_ring_push2d
// %bb.0:                               // %entry
	{
		r6 = add(pc,##g_push@PCREL)
		r13 = memw(r29+#0)
	}
	{
		r7 = add(pc,##g_pop@PCREL)
	}
	{
		r12 = memw(r6+#0)
	}
	{
		r8 = add(r12,#1)
		r9 = memw(r7+#0)
	}
	{
		r8 = add(pc,##g_ring@PCREL)
		r14 = and(r8,#255)
	}
	{
		p1 = cmp.eq(r14,r9)
		if (!p1.new) jump:t .LBB3_7
		r9 = memw(r29+#4)
	}
// %bb.1:                               // %if.then
	{
		r15 = addasl(r8,r14,#7)
	}
	{
		r28 = memw(r15+#4)
		if (!cmp.gt(r28.new,#-1)) jump:nt .LBB3_6
	}
// %bb.2:
	{
		r12 = #0
	}
	.falign
.LBB3_3:                                // %while.body.i
                                        // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		r14 = dmpoll
	}
	//# InlineAsm End
	{
		r14 = memw(r15+#4)
		if (!cmp.gt(r14.new,#-1)) jump:nt .LBB3_5
	}
// %bb.4:                               // %while.body.i
                                        //   in Loop: Header=BB3_3 Depth=1
	{
		p0 = cmp.gtu(r12,##49999998)
		r12 = add(r12,#1)
		if (!p0.new) jump:t .LBB3_3
	}
	.falign
.LBB3_5:                                // %hexkl_dma_ring_wait_idx_.exit.loopexit
	{
		r14 = memw(r7+#0)
		r12 = memw(r6+#0)
	}
	.falign
.LBB3_6:                                // %hexkl_dma_ring_wait_idx_.exit
	{
		r14 = add(r14,#1)
	}
	{
		r14 = and(r14,#255)
		memw(r7+#0) = r14.new
	}
	.falign
.LBB3_7:                                // %if.end
	{
		r7 = extractu(r2,#24,#0)
		r4 = extractu(r4,#24,#0)
		p1 = cmp.eq(r13,#0)
		p0 = cmp.eq(r9,#0)
	}
	{
		r2 = addasl(r8,r12,#7)
		r13 = setbit(r7,#29)
		r1:0 = combine(r0,r1)
		r14 = #0
	}
	{
		r11 = extractu(r5,#8,#8)
		r4 |= asl(r5,#24)
		if (!p1) r7 = add(r13,#0)
	}
	{
		r5 = setbit(r7,#28)
		r15 = asl(r12,#7)
		memw(r2+#20) = r4
		memw(r2+#16) = #9
	}
	{
		r11 |= asl(r3,#8)
		if (!p0) r7 = add(r5,#0)
		memw(r8+r15<<#0) = r14
		memw(r2+#28) = #0
	}
	{
		r4 = add(pc,##g_started@PCREL)
		r3 = setbit(r7,#24)
		memd(r2+#8) = r1:0
	}
	{
		memw(r2+#24) = r11
		memw(r2+#4) = r3
	}
	{
		dccleaninva(r2)
	}
	{
		r3 = memub(r4+#0)
	}
	{
		r3 = add(pc,##g_tail@PCREL)
		p0 = r3
		if (!p0.new) jump:t .LBB3_9
	}
// %bb.8:                               // %if.else
	{
		r4 = memw(r3+#0)
	}
	//# InlineAsm Start
	{
		release(r2):at
	}
	//# InlineAsm End
	//# InlineAsm Start
	{
		dmlink(r4,r2)
	}
	//# InlineAsm End
	{
		jump .LBB3_10
	}
	.falign
.LBB3_9:                                // %if.then3
	//# InlineAsm Start
	{
		release(r2):at
	}
	//# InlineAsm End
	//# InlineAsm Start
	{
		dmstart(r2)
	}
	//# InlineAsm End
	{
		memb(r4+#0) = #1
	}
	.falign
.LBB3_10:                               // %if.end4
	{
		r4 = memw(r6+#0)
		memw(r3+#0) = r2
	}
	{
		r4 = add(r4,#1)
	}
	{
		r0 = and(r4,#255)
		jumpr r31
		memw(r6+#0) = r0.new
	}
.Lfunc_end3:
	.size	hexkl_dma_ring_push2d, .Lfunc_end3-hexkl_dma_ring_push2d
                                        // -- End function
	.globl	hexkl_dma_ring_next_idx         // -- Begin function hexkl_dma_ring_next_idx
	.balign 32
	.type	hexkl_dma_ring_next_idx,@function
hexkl_dma_ring_next_idx:                // @hexkl_dma_ring_next_idx
// %bb.0:                               // %entry
	{
		r2 = add(pc,##g_push@PCREL)
	}
	{
		r0 = memw(r2+#0)
		jumpr r31
	}
.Lfunc_end4:
	.size	hexkl_dma_ring_next_idx, .Lfunc_end4-hexkl_dma_ring_next_idx
                                        // -- End function
	.globl	hexkl_dma_ring_wait             // -- Begin function hexkl_dma_ring_wait
	.falign
	.type	hexkl_dma_ring_wait,@function
hexkl_dma_ring_wait:                    // @hexkl_dma_ring_wait
// %bb.0:                               // %entry
	{
		r2 = add(pc,##g_ring@PCREL)
	}
	{
		r2 = addasl(r2,r0,#7)
	}
	{
		r3 = memw(r2+#4)
		if (!cmp.gt(r3.new,#-1)) jump:nt .LBB5_4
	}
// %bb.1:
	{
		r3 = #0
	}
	.falign
.LBB5_2:                                // %while.body.i
                                        // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB5_4
	}
// %bb.3:                               // %while.body.i
                                        //   in Loop: Header=BB5_2 Depth=1
	{
		p0 = cmp.gtu(r3,##49999998)
		r3 = add(r3,#1)
		if (!p0.new) jump:t .LBB5_2
	}
	.falign
.LBB5_4:                                // %hexkl_dma_ring_wait_idx_.exit
	{
		jumpr r31
	}
.Lfunc_end5:
	.size	hexkl_dma_ring_wait, .Lfunc_end5-hexkl_dma_ring_wait
                                        // -- End function
	.globl	hexkl_dma_ring_drain            // -- Begin function hexkl_dma_ring_drain
	.falign
	.type	hexkl_dma_ring_drain,@function
hexkl_dma_ring_drain:                   // @hexkl_dma_ring_drain
// %bb.0:                               // %entry
	{
		r2 = add(pc,##g_pop@PCREL)
	}
	{
		r3 = add(pc,##g_push@PCREL)
		r5 = memw(r2+#0)
	}
	{
		r6 = memw(r3+#0)
		if (cmp.eq(r6.new,r5)) jump:t .LBB6_7
	}
// %bb.1:
	{
		r4 = add(pc,##g_ring@PCREL)
	}
	.falign
.LBB6_2:                                // %while.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_3 Depth 2
	{
		r7 = addasl(r4,r5,#7)
	}
	{
		r8 = memw(r7+#4)
	}
	{
		p1 = cmp.gt(r8,#-1)
		r8 = #0
		if (!p1.new) jump:nt .LBB6_6
	}
	.falign
.LBB6_3:                                // %while.body.i
                                        //   Parent Loop BB6_2 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	//# InlineAsm Start
	{
		r5 = dmpoll
	}
	//# InlineAsm End
	{
		r5 = memw(r7+#4)
		if (!cmp.gt(r5.new,#-1)) jump:nt .LBB6_5
	}
// %bb.4:                               // %while.body.i
                                        //   in Loop: Header=BB6_3 Depth=2
	{
		p1 = cmp.gtu(r8,##49999998)
		r8 = add(r8,#1)
		if (!p1.new) jump:t .LBB6_3
	}
	.falign
.LBB6_5:                                // %hexkl_dma_ring_wait_idx_.exit.loopexit
                                        //   in Loop: Header=BB6_2 Depth=1
	{
		r5 = memw(r2+#0)
		r6 = memw(r3+#0)
	}
	.falign
.LBB6_6:                                // %hexkl_dma_ring_wait_idx_.exit
                                        //   in Loop: Header=BB6_2 Depth=1
	{
		r5 = add(r5,#1)
	}
	{
		r5 = and(r5,#255)
		memw(r2+#0) = r5.new
	}
	{
		p0 = cmp.eq(r5,r6); if (!p0.new) jump:t .LBB6_2
	}
	.falign
.LBB6_7:                                // %while.end
	{
		r2 = add(pc,##g_started@PCREL)
	}
	{
		jumpr r31
		memb(r2+#0) = #0
	}
.Lfunc_end6:
	.size	hexkl_dma_ring_drain, .Lfunc_end6-hexkl_dma_ring_drain
                                        // -- End function
	.globl	hexkl_dcache_inva               // -- Begin function hexkl_dcache_inva
	.falign
	.type	hexkl_dcache_inva,@function
hexkl_dcache_inva:                      // @hexkl_dcache_inva
// %bb.0:                               // %entry
	{
		r2 = and(r0,#-32)
		r3 = add(r0,r1)
	}
	{
		if (p0.new) r3 = sub(r3,r2)
		p0 = cmp.gtu(r3,r2); if (!p0.new) jump:t .LBB7_3
	}
// %bb.1:
	{
		r3 = add(r3,#31)
	}
	{
		r3 = lsr(r3,#5)
	}
	{
		loop0(.LBB7_2,r3)
	}
	.falign
.LBB7_2:                                // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = add(r2,#32)
		dcinva(r2)
	} :endloop0
	.falign
.LBB7_3:                                // %for.end
	//# InlineAsm Start
	//# InlineAsm End
	{
		jumpr r31
	}
.Lfunc_end7:
	.size	hexkl_dcache_inva, .Lfunc_end7-hexkl_dcache_inva
                                        // -- End function
	.globl	hexkl_dma_lane_push2d           // -- Begin function hexkl_dma_lane_push2d
	.falign
	.type	hexkl_dma_lane_push2d,@function
hexkl_dma_lane_push2d:                  // @hexkl_dma_lane_push2d
// %bb.0:                               // %entry
	{
		r4 = extractu(r4,#24,#0)
		r3:2 = combine(r2,r3)
		r6 = memw(r29+#8)
		memw(r0+#0) = #0
	}
	{
		r8 = setbit(r4,#29)
		p1 = cmp.eq(r6,#0)
		r7 = memw(r29+#12)
		memd(r0+#8) = r3:2
	}
	{
		if (!p1) r4 = add(r8,#0)
		p0 = cmp.eq(r7,#0)
		r6 = memw(r29+#4)
		memw(r0+#16) = #9
	}
	{
		r3 = extractu(r6,#8,#8)
		r2 = setbit(r4,#28)
		r15 = memw(r29+#0)
		memw(r0+#28) = #0
	}
	{
		r15 = insert(r6,#8,#24)
		r3 |= asl(r5,#8)
		if (!p0) r4 = add(r2,#0)
		memw(r0+#20) = r15.new
	}
	{
		r2 = setbit(r4,#24)
		memw(r0+#24) = r3
	}
	{
		p0 = cmp.eq(r1,#0)
		memw(r0+#4) = r2
	}
	{
		dccleaninva(r0)
	}
	//# InlineAsm Start
	{
		release(r0):at
	}
	//# InlineAsm End
	{
		if (p0) jump:nt .LBB8_2
	}
// %bb.1:                               // %if.else
	//# InlineAsm Start
	{
		dmlink(r1,r0)
	}
	//# InlineAsm End
	{
		jumpr r31
	}
	.falign
.LBB8_2:                                // %if.then
	//# InlineAsm Start
	{
		dmstart(r0)
	}
	//# InlineAsm End
	{
		jumpr r31
	}
.Lfunc_end8:
	.size	hexkl_dma_lane_push2d, .Lfunc_end8-hexkl_dma_lane_push2d
                                        // -- End function
	.globl	hexkl_dma_lane_wait             // -- Begin function hexkl_dma_lane_wait
	.falign
	.type	hexkl_dma_lane_wait,@function
hexkl_dma_lane_wait:                    // @hexkl_dma_lane_wait
// %bb.0:                               // %entry
	{
		r0 = #0
		r2 = r0
		r3 = memw(r0+#4)
	}
	{
		p0 = cmp.gt(r3,#-1)
		if (!p0.new) jumpr:nt r31
	}
.LBB9_1:
	{
		r3 = ##50000001
	}
	.falign
.LBB9_2:                                // %while.body
                                        // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.3:                               // %if.end.1
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.4:                               // %if.end.2
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.5:                               // %if.end.3
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.6:                               // %if.end.4
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.7:                               // %if.end.5
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.8:                               // %if.end.6
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.9:                               // %if.end.7
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.10:                              // %if.end.8
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.11:                              // %if.end.9
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.12:                              // %if.end.10
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.13:                              // %if.end.11
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.14:                              // %if.end.12
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.15:                              // %if.end.13
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.16:                              // %if.end.14
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.17:                              // %if.end.15
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.18:                              // %if.end.16
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.19:                              // %if.end.17
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (!cmp.gt(r4.new,#-1)) jump:nt .LBB9_22
	}
// %bb.20:                              // %while.body.18
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r3 = add(r3,#-19)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB9_23
	}
// %bb.21:                              // %if.end.18
                                        //   in Loop: Header=BB9_2 Depth=1
	//# InlineAsm Start
	{
		r4 = dmpoll
	}
	//# InlineAsm End
	{
		r4 = memw(r2+#4)
		if (cmp.gt(r4.new,#-1)) jump:t .LBB9_2
	}
	.falign
.LBB9_22:                               // %cleanup
	{
		jumpr r31
	}
	.falign
.LBB9_23:
	{
		r0 = #-1
		jumpr r31
	}
.Lfunc_end9:
	.size	hexkl_dma_lane_wait, .Lfunc_end9-hexkl_dma_lane_wait
                                        // -- End function
	.type	g_ring,@object                  // @g_ring
	.lcomm	g_ring,32768,128
	.type	g_push,@object                  // @g_push
	.lcomm	g_push,4,4
	.type	g_pop,@object                   // @g_pop
	.lcomm	g_pop,4,4
	.type	g_tail,@object                  // @g_tail
	.lcomm	g_tail,4,4
	.type	g_started,@object               // @g_started
	.lcomm	g_started,1,4
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym g_ring

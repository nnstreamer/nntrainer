#include <stdio.h>
#include <stdint.h>
#include <limits.h>
int main(void){char b[512];int n=snprintf(b,sizeof b,"[LFM-RAW4] q=%u m=%u on=%u raw=%u,%u sdk=%u b=%u rc=%d END",UINT32_MAX,UINT32_MAX,1u,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,INT32_MIN);if(n<0||n>=224)return 1;printf("%d\n",n);return 0;}

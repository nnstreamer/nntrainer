#!/usr/bin/env python3
"""Run the prepared matched matrix after checking every deployed runtime file."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

D = Path(__file__).resolve().parent
R = Path('/home/jungone-lee/workspace/nntrainer-lfm2-tl2-prefill1000')
E = R / 'docs/measurements/lfm2_tl2_prefill1000_20261016'
F = Path('/tmp/nntr-lfm2-attn-planes-kv-fixed-objects-20261017/build')
ADB = ['adb', '-s', 'R3CY70LV96T']
PHONE = '/data/local/tmp/nntr_lfm2_prefill1000_20261016'
fixed = json.loads((F / 'validation.json').read_text())
accepted = json.loads((D / 'root-baseline.json').read_text())['local_runtime']
records = []
for job in json.loads((D / 'root-confirmation-fixed-jobs.json').read_text()):
    name, tag = job['variant'], job['tag']
    assert not (E / (tag + '.json')).exists(), 'Never overwrite a completed run'
    arm = 'control' if name.endswith('-control') else 'candidate'
    expected = dict(accepted)
    expected['libnntr_hvx_skel.so'] = fixed[arm]['sha256']
    manifest_path = E / (name + '-artifacts.json')
    manifest = json.loads(manifest_path.read_text())
    assert manifest['binaries'] == expected
    busy = subprocess.check_output(ADB + ['shell',
        'pidof nntr_causallm nntrainer_causallm attention_raw_planes_device_check || true'],
        text=True).strip()
    assert not busy, ('Device busy; no run started', busy)
    paths = [f'{PHONE}/{name}/{file}' for file in expected]
    output = subprocess.check_output(ADB + ['shell', shlex.join(['sha256sum', *paths])], text=True)
    actual = {Path(line.split()[1]).name: line.split()[0] for line in output.splitlines()}
    assert actual == expected, (tag, 'Deployed runtime identity mismatch')
    cmd = ['python3', str(E / 'bench.py'), name, tag, '--model', job['model'], '--memory']
    for key, value in job['env'].items():
        cmd += ['--env', key + '=' + str(value)]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (D / (tag + '.runner.log')).write_text(proc.stdout)
    records.append({'tag': tag, 'runtime_sha256_before': actual,
        'runtime_manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        'command': cmd, 'returncode': proc.returncode})
    (D / 'root-confirmation-fixed-executions.json').write_text(json.dumps(records, indent=2) + '\n')
    assert proc.returncode == 0, (tag, proc.stdout)
    result = json.loads((E / (tag + '.json')).read_text())
    assert result['valid'] and result['ids_match_reference'], tag
    print({k: result[k] for k in ['tag', 'prefill_tps', 'decode_tps',
        'full_run_sampled_peak_kib', 'ids_match_reference']}, flush=True)

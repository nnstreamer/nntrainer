#!/usr/bin/env python3
"""Prove actual full-model raw-QK dispatch; these runs are not TPS evidence."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import threading
import time

D = Path(__file__).resolve().parent
R = Path('/home/jungone-lee/workspace/nntrainer-lfm2-tl2-prefill1000')
E = R / 'docs/measurements/lfm2_tl2_prefill1000_20261016'
A = Path('/tmp/nntr-lfm2-attn-raw-planes-20261017')
F = Path('/tmp/nntr-lfm2-attn-planes-kv-fixed-objects-20261017/build')
ADB = ['adb', '-s', 'R3CY70LV96T']
PHONE = '/data/local/tmp/nntr_lfm2_prefill1000_20261016'
variant = 'lfm-attn-raw-planes-fixed-diagnostic'
jobs = json.loads((D / 'root-normal-fixed-jobs.json').read_text())
expected_runtime = json.loads((D / 'root-baseline.json').read_text())['local_runtime']
expected_runtime['libnntr_hvx_skel.so'] = json.loads((F / 'validation.json').read_text())['diagnostic']['sha256']
records = []

for rows, model in [(1024, 'model'), (2048, 'model2048')]:
    tag = f'continue-attn-raw-planes-fixed-diagnostic{rows}'
    assert not (E / (tag + '.json')).exists()
    busy = subprocess.check_output(ADB + ['shell',
        'pidof nntr_causallm nntrainer_causallm attention_raw_planes_device_check || true'], text=True).strip()
    assert not busy, ('Device busy; no model launched', busy)
    manifest_path = E / (variant + '-artifacts.json')
    assert json.loads(manifest_path.read_text())['binaries'] == expected_runtime
    raw = subprocess.check_output(ADB + ['shell', shlex.join(['sha256sum',
        *[f'{PHONE}/{variant}/{name}' for name in expected_runtime]])], text=True)
    actual = {Path(line.split()[1]).name: line.split()[0] for line in raw.splitlines()}
    assert actual == expected_runtime
    counts = (10240, 0, 160) if rows == 1024 else (8192, 28672, 576)
    expected = [dict(m=rows, on=1, raw_s=counts[0], raw_d=counts[1], sdk=0,
                     b=counts[2], rc=0) for _ in range(10)]
    expected_path = D / (tag + '.expected.json')
    expected_path.write_text(json.dumps(expected, indent=2) + '\n')
    stamp = subprocess.check_output(ADB + ['shell', "date '+%m-%d %H:%M:%S.000'"], text=True).strip()
    live_path = D / (tag + '.live.logcat.txt')
    live = live_path.open('w')
    collector = subprocess.Popen(ADB + ['logcat', '-v', 'threadtime', '-T', stamp],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def consume():
        for line in collector.stdout:
            if '[LFM-RAW' in line:
                live.write(line)
        live.flush()

    thread = threading.Thread(target=consume)
    thread.start()
    command = ['python3', str(E / 'bench.py'), variant, tag,
               '--model', model, '--memory', '--profile']
    for key, value in next(j for j in jobs if j['model'] == model)['env'].items():
        command += ['--env', key + '=' + str(value)]
    try:
        proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, timeout=200)
        (D / (tag + '.runner.log')).write_text(proc.stdout)
        assert proc.returncode == 0, 'Model failed; preserve raw records'
        time.sleep(2)
    finally:
        collector.terminate()
        collector.wait(timeout=10)
        thread.join(timeout=10)
        assert not thread.is_alive()
        live.close()
        (D / (tag + '.collector.stderr')).write_text(collector.stderr.read())
    meta = json.loads((E / (tag + '.json')).read_text())
    memory = json.loads((E / (tag + '.memory.json')).read_text())
    assert meta['valid'] and meta['ids_match_reference'] and meta['decode_tokens'] == 64
    assert meta['instrumented'] and not meta['performance_comparison_eligible']
    assert memory['child_waited'] and memory['child_exit_code'] == 0
    parsed_path = D / (tag + '.parsed.json')
    parse = ['python3', str(A / 'diagnostic/parse.py'), '--log', str(live_path),
             '--expected', str(expected_path), '--pid', str(memory['pid']),
             '--output', str(parsed_path)]
    subprocess.run(parse, check=True)
    records.append(dict(tag=tag, pid=memory['pid'], runtime_sha256=actual,
        manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        model_command=command, parser_command=parse, parser_result=json.loads(parsed_path.read_text()),
        live_log_sha256=hashlib.sha256(live_path.read_bytes()).hexdigest(),
        performance_comparison_eligible=False))
    (D / 'root-model-diagnostic-fixed-summary.json').write_text(json.dumps(records, indent=2) + '\n')
    print({'tag': tag, 'pid': memory['pid'], 'actual_dispatch': 'PASS'}, flush=True)

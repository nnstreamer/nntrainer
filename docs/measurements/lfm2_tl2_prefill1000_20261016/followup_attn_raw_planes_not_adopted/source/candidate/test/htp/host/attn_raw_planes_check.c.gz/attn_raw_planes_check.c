// SPDX-License-Identifier: Apache-2.0
/** Actual production qualification/readout/reconstruction under SDK libnative.
 * HMX convert is a byte-plane stand-in; hardware extraction needs the device
 * fixture. All 32 signed accumulator bits, config words and fallback status
 * are checked here with strict sanitizers.
 */
#include <assert.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "attn_raw_planes_under_test.h"

static uint32_t config_bytes = 16384u;
static attn_ctx *active;
static int32_t dot[2048];
static unsigned converted, sdk_reads;
static uint32_t target;
static uint32_t hexkl_micro_hmx_config_size(void) { return config_bytes; }
static int hexkl_micro_hmx_acc_read_int32(uint8_t *base, uint32_t cfg,
                                          uint32_t dst) {
  assert(base == active->vb && cfg == active->cfg && dst == target);
  ++sdk_reads;
  return AEE_EFAILED;
}
static void hexkl_cvt_issue(const void *config, void *dst) {
  assert(config == active->vb + active->cfg + converted * 1024u);
  assert(dst == active->vb + target + converted * 2048u);
  assert(converted < 4u);
  uint8_t *p = dst;
  for (unsigned x = 0; x < 2048u; ++x) {
    uint32_t bits;
    memcpy(&bits, dot + x, 4u);
    p[x] = (uint8_t)(bits >> (8u * converted));
  }
  ++converted;
}
static void *alloc_aligned(size_t n) {
  void *p = NULL;
  assert(posix_memalign(&p, 2048u, n) == 0);
  return p;
}
static void set_config(attn_ctx *c) {
  static const uint32_t scale[4] = {0x6000u, 0x4000u, 0x2000u, 0u};
  uint32_t *w = (uint32_t *)(c->vb + c->cfg);
  memset(w, 0, 4096u);
  for (unsigned p = 0; p < 4u; ++p)
    for (unsigned i = 0; i < 64u; ++i)
      w[p * 256u + i] = scale[p];
  memset((uint8_t *)w + 4096u, 0xcd, 12288u);
}
static unsigned check_guards(attn_ctx *c) {
  assert(qk_planes_available(c));
  assert(!guard_v79(c) && !guard_host(c));
  uint32_t *w = (uint32_t *)(c->vb + c->cfg);
  for (unsigned i = 0; i < 1024u; ++i) {
    for (unsigned bit = 0u; bit < 32u; bit += 8u) {
      w[i] ^= 1u << bit;
      assert(!qk_planes_available(c));
      w[i] ^= 1u << bit;
    }
  }
  // Mutable SDK scratch is deliberately not part of the immutable signature.
  memset(c->vb + c->cfg + 4096u, 0x12, 12288u);
  assert(qk_planes_available(c));
  const hexkl_attn_f16_shape original_s = *c->s;
  const hexkl_attn_f16_tiling original_t = *c->t;
  const hexkl_kv_q original_k = *c->kv;
  const hexkl_attn_q_io original_io = *c->io;
  const hexkl_acc_layout original_acc = *c->acc_layout;
  for (unsigned i = 0; i < 33u; ++i) {
    attn_ctx a = *c;
    hexkl_attn_f16_shape s = original_s;
    hexkl_attn_f16_tiling t = original_t;
    hexkl_kv_q k = original_k;
    hexkl_attn_q_io io = original_io;
    hexkl_acc_layout acc = original_acc;
    a.s = &s;
    a.t = &t;
    a.kv = &k;
    a.io = &io;
    a.acc_layout = &acc;
    switch (i) {
    case 0:
      k.kind = HEXKL_KV_Q4;
      break;
    case 1:
      k.fixed = 1;
      break;
    case 2:
      s.n_q = 1920u;
      break;
    case 3:
      s.cache_from = 1u;
      break;
    case 4:
      s.cache_to -= 1u;
      break;
    case 5:
      s.n_head_q = 16u;
      break;
    case 6:
      s.n_head_kv = 4u;
      break;
    case 7:
      s.head_dim = 256u;
      break;
    case 8:
      s.window = 128u;
      break;
    case 9:
      s.softcap = 1.0f;
      break;
    case 10:
      io.sinks = (const float *)&s;
      break;
    case 11:
      t.g = 2u;
      break;
    case 12:
      t.br = 64u;
      break;
    case 13:
      t.bc = 128u;
      break;
    case 14:
      t.g_br = 256u;
      break;
    case 15:
      a.L.n_row_tiles = 4u;
      break;
    case 16:
      a.L.n_col_tiles = 4u;
      break;
    case 17:
      a.L.n_dot_tiles = 4u;
      break;
    case 18:
      a.L.tile_bytes = 512u;
      break;
    case 19:
      acc.base = 32u;
      break;
    case 20:
      acc.row_stride = 64u;
      break;
    case 21:
      config_bytes = 4096u;
      break;
    case 22:
      a.cfg += 128u;
      break;
    case 23:
      a.L.acc += 128u;
      break;
    case 24:
      a.L.qx_f32 += 128u;
      break;
    case 25:
      a.L.acc = a.L.qx_f32;
      break;
    case 26:
      a.L.qx_f32 = a.L.total + 2048u;
      break;
    case 27:
      a.L.total = a.cfg + 1u;
      break;
    case 28:
      a.L.n_qb_chunk = 1u;
      break;
    case 29:
      a.L.total = a.L.qx_f32 + 8192u;
      break;
    case 30:
      a.vb += 128u;
      break;
    case 31:
      s.n_q = 2049u;
      s.cache_to = 2049u;
      break;
    case 32:
      s.n_head_q = 8u;
      s.n_head_kv = 4u;
      s.head_dim = 256u;
      break;
    }
    assert(!qk_planes_available(&a));
    config_bytes = 16384u;
  }
  return 33u + 4096u;
}
int main(void) {
  hexkl_attn_f16_shape s = {2048u, 0u, 2048u, 32u, 8u, 64u, 0u, 0.0f};
  hexkl_attn_f16_tiling t = {128u, 256u, 0u, 0u};
  assert(hexkl_attn_q_tiling_init(&s, &t) == HEXKL_ATTN_OK);
  hexkl_kv_q kv = {0};
  kv.kind = HEXKL_KV_Q8;
  hexkl_attn_q_io io = {0};
  hexkl_acc_layout acc = {1, 1, 0u, 32u};
  attn_ctx c = {0};
  c.s = &s;
  c.t = &t;
  c.kv = &kv;
  c.io = &io;
  c.acc_layout = &acc;
  c.cfg = (8u << 20) - 16384u;
  c.vb = alloc_aligned(8u << 20);
  memset(c.vb, 0xa5, 8u << 20);
  assert(hexkl_attn_q_plan(&s, &t, c.cfg, 1024u, 9u, &c.L) == HEXKL_ATTN_OK);
  set_config(&c);
  const unsigned guards = check_guards(&c);
  s.n_q = s.cache_to = 1024u;
  assert(qk_planes_available(&c));
  s.n_q = s.cache_to = 2048u;
  c.qk_planes = qk_planes_available(&c);
  active = &c;
  HVX_Vector rows[4];
  unsigned blocks = 0u;
  uint32_t seed = 0x12345678u;
  static const uint32_t edges[] = {0u,          1u,          0xffffffffu,
                                   0x80000000u, 0x7fffffffu, 0x00800000u,
                                   0xff800000u, 0x00ffffffu, 0xff000001u,
                                   0x01000000u, 2088960u,    (uint32_t)-2088960,
                                   0x00008000u, 0xffff8000u};
  for (unsigned trial = 0; trial < 129u; ++trial) {
    for (unsigned x = 0; x < 2048u; ++x) {
      seed = seed * 1664525u + 1013904223u;
      uint32_t u = trial ? seed : edges[x % (sizeof(edges) / sizeof(edges[0]))];
      memcpy(dot + x, &u, 4u);
    }
    target = trial & 1u ? c.L.acc : c.L.qx_f32 + 63u * 8192u;
    memset(c.vb + target, 0xe7, 8192u);
    converted = 0u;
    assert(qk_read_acc(&c, target) == AEE_SUCCESS);
    assert(converted == 4u && sdk_reads == 0u);
    for (unsigned row = 0; row < 64u; row += 4u) {
      qk_acc_four_rows((const HVX_Vector *)(c.vb + target), row, rows);
      assert(memcmp(rows, dot + row * 32u, sizeof(rows)) == 0);
      ++blocks;
    }
  }
  c.qk_planes = 0;
  assert(qk_read_acc(&c, target) == AEE_EFAILED && sdk_reads == 1u);
  assert(qk_planes_available(&c));
  for (unsigned p = 0; p < c.L.acc; ++p)
    assert(c.vb[p] == 0xa5);
  free(c.vb);
  printf("Raw4plane actual helpers: %u signed four-row blocks, %u guard/config "
         "negatives, read/fallback order PASS\n",
         blocks, guards);
  return 0;
}

// SPDX-License-Identifier: Apache-2.0
/** Device correctness only: existing public Q8 APIs, no timing benchmark.
 * Reuses attention_pipeline_device_check's shared input and direct-step path.
 * A/B/A replaces all cache rows on one handle and verifies fresh full outputs.
 * probe_cvt separately checks hardware byte planes against the SDK readout
 * and an int64 dot product over kv_dump_q's dynamic quantized masters.
 */
#include <cinttypes>
#include <cstdio>
#include <cstring>
#include <htp_backend.h>
#include <nntr_hvx.h>
#include <stdexcept>
#include <vector>

static void require(bool ok, const char *why) {
  if (!ok)
    throw std::runtime_error(why);
}
static void rpc(int rc, const char *name) {
  if (rc) {
    std::fprintf(stderr, "RPC_ERROR %s rc=%d\n", name, rc);
    throw std::runtime_error(name);
  }
}
static uint64_t fnv(const void *data, size_t size,
                    uint64_t h = UINT64_C(14695981039346656037)) {
  const uint8_t *p = static_cast<const uint8_t *>(data);
  for (size_t i = 0; i < size; ++i) {
    h ^= p[i];
    h *= UINT64_C(1099511628211);
  }
  return h;
}
template <typename T> struct Shared {
  T *p;
  size_t n;
  explicit Shared(size_t count) : n(count) {
    p = static_cast<T *>(
      nntrainer::HtpBackend::global().alloc_shared(n * sizeof(T)));
    require(p != nullptr, "shared allocation failed");
  }
  ~Shared() { nntrainer::HtpBackend::global().free_shared(p); }
  Shared(const Shared &) = delete;
  Shared &operator=(const Shared &) = delete;
};
struct Cache {
  remote_handle64 session;
  uint32_t id = 0;
  Cache(unsigned kind, unsigned rows, unsigned heads, unsigned hd) :
    session(nntrainer::HtpBackend::global().handle()) {
    rpc(nntr_hvx_kv_register_q(session, kind, rows, heads, hd, &id),
        "kv_register_q");
  }
  ~Cache() {
    if (id)
      nntr_hvx_kv_release_q(session, id);
  }
  void release() {
    rpc(nntr_hvx_kv_release_q(session, id), "kv_release_q");
    id = 0;
  }
};
struct Case {
  unsigned id, rows, prefix, qh, kvh, hd, kind;
  bool fixed;
  unsigned window;
  float softcap;
  bool sinks;
  unsigned seed;
};
#include "caseplan.inc"

static void fill(Shared<float> &q, Shared<uint16_t> &k, Shared<uint16_t> &v,
                 unsigned hd, unsigned seed) {
  auto sample = [&]() {
    seed = seed * 1664525u + 1013904223u;
    return (float(seed >> 8) / 16777215.f - 0.5f) * 4.f;
  };
  for (size_t i = 0; i < q.n; ++i)
    q.p[i] = (i / hd) % 17u ? sample() : 0.f;
  for (size_t i = 0; i < k.n; ++i) {
    const __fp16 a = (i / hd) % 19u ? sample() : 0.f;
    const __fp16 b = (i / hd) % 23u ? sample() : 0.f;
    std::memcpy(k.p + i, &a, sizeof(a));
    std::memcpy(v.p + i, &b, sizeof(b));
  }
}
static void run_case(const Case &c, FILE *dump, uint64_t &offset) {
  const unsigned cache_rows = c.rows + c.prefix;
  Shared<float> q(size_t(c.rows) * c.qh * c.hd), out(q.n);
  Shared<uint16_t> k(size_t(cache_rows) * c.kvh * c.hd), v(k.n);
  Cache cache(c.kind, cache_rows, c.kvh, c.hd);
  if (c.fixed) {
    std::vector<float> sk(c.kvh, 1.f / 64.f);
    std::vector<float> sv(c.kvh * c.hd, 1.f / 64.f);
    rpc(nntr_hvx_kv_set_fixed_scales_q(cache.session, cache.id, sk.data(),
                                       int(sk.size()), sv.data(),
                                       int(sv.size())),
        "kv_set_fixed_scales_q");
  }
  std::vector<float> sinks(c.qh), first;
  for (unsigned h = 0; h < c.qh; ++h)
    sinks[h] = (int(h % 7u) - 3) / 4.f;
  for (unsigned repetition = 0; repetition < 3u; ++repetition) {
    const unsigned seed = c.seed + (repetition == 1u ? 1u : 0u);
    fill(q, k, v, c.hd, seed);
    uint64_t input_hash = fnv(q.p, q.n * sizeof(float));
    input_hash = fnv(k.p, k.n * sizeof(uint16_t), input_hash);
    input_hash = fnv(v.p, v.n * sizeof(uint16_t), input_hash);
    const uint32_t poison = 0x7fc00001u;
    for (size_t i = 0; i < out.n; ++i)
      std::memcpy(out.p + i, &poison, sizeof(poison));
    uint32_t stats[20] = {};
    rpc(nntr_hvx_attn_q_step(
          cache.session, cache.id, 0u, k.p, int(k.n), v.p, int(v.n), c.rows,
          c.prefix, cache_rows, c.qh, c.window, c.softcap, q.p, int(q.n),
          c.sinks ? sinks.data() : nullptr, c.sinks ? int(c.qh) : 0, out.p,
          int(out.n), stats, 20),
        "attn_q_step");
    for (size_t i = 0; i < out.n; ++i) {
      uint32_t bits;
      std::memcpy(&bits, out.p + i, 4u);
      require((bits & 0x7f800000u) != 0x7f800000u,
              "nonfinite or unwritten output");
    }
    if (repetition == 0u)
      first.assign(out.p, out.p + out.n);
    else {
      const bool equal =
        std::memcmp(first.data(), out.p, out.n * sizeof(float)) == 0;
      require(equal == (repetition == 2u), "A/B/A output reuse mismatch");
    }
    require(std::fwrite(out.p, sizeof(float), out.n, dump) == out.n,
            "dump write failed");
    std::fprintf(
      stderr,
      "{\"schema\":\"attn-raw4plane-v1\",\"record\":\"CASE\","
      "\"case_id\":%u,\"repetition\":%u,\"seed\":%u,\"kind\":%u,"
      "\"fixed\":%s,\"n_q\":%u,\"cache_from\":%u,\"cache_to\":%u,"
      "\"qh\":%u,\"kvh\":%u,\"hd\":%u,\"window\":%u,\"softcap\":%.1f,"
      "\"sinks\":%s,\"count\":%zu,\"offset\":%" PRIu64 ",\"mode\":%u,"
      "\"blocks\":%u,\"rc\":0,\"finite\":true,\"same_repeat\":%s,"
      "\"input_fnv64\":\"%016" PRIx64 "\"}\n",
      c.id, repetition, seed, c.kind, c.fixed ? "true" : "false", c.rows,
      c.prefix, cache_rows, c.qh, c.kvh, c.hd, c.window, double(c.softcap),
      c.sinks ? "true" : "false", out.n, offset, stats[2], stats[17],
      repetition == 2u ? "true" : "null", input_hash);
    offset += out.n * sizeof(float);
  }
  cache.release();
}

static void run_probe(unsigned probe_id, unsigned pattern, unsigned col) {
  constexpr unsigned rows = 64u, hd = 64u;
  Shared<uint16_t> k(rows * hd), v(rows * hd);
  Shared<uint8_t> activation(rows * hd);
  for (unsigned r = 0; r < rows; ++r) {
    for (unsigned d = 0; d < hd; ++d) {
      float value;
      switch (r % 8u) {
      case 0:
        value = 1.f;
        break;
      case 1:
        value = -1.f;
        break;
      case 2:
        value = d % 2u ? -1.f : 1.f;
        break;
      case 3:
        value = (int(d % 7u) - 3) / 4.f;
        break;
      case 4:
        value = 1.f / 128.f;
        break;
      case 5:
        value = -1.f / 128.f;
        break;
      case 6:
        value = (int(d % 11u) - 5) / 8.f;
        break;
      default:
        value = 0.f;
        break;
      }
      if (pattern)
        value = -value;
      const __fp16 half = value;
      std::memcpy(k.p + r * hd + d, &half, 2u);
      std::memcpy(v.p + r * hd + d, &half, 2u);
      const unsigned which = (r + pattern) % 8u;
      const unsigned a = which == 0u   ? 0u
                         : which == 1u ? 255u
                         : which == 2u ? 1u
                         : which == 3u ? 128u
                         : which == 4u ? (d % 2u ? 0u : 255u)
                         : which == 5u ? d + 1u
                         : which == 6u ? 254u
                                       : (d * 17u + r * 31u) % 256u;
      activation.p[r * hd + d] = uint8_t(a);
    }
  }
  Cache cache(0u, rows, 1u, hd);
  rpc(nntr_hvx_kv_append_q(cache.session, cache.id, 0u, k.p, int(k.n), v.p,
                           int(v.n)),
      "probe kv_append_q");
  std::vector<int8_t> kq(rows * hd), vq(rows * hd);
  std::vector<float> sk(rows), sv(rows);
  std::vector<int32_t> colsum(rows);
  rpc(nntr_hvx_kv_dump_q(cache.session, cache.id, 0u, rows, kq.data(),
                         int(kq.size()), vq.data(), int(vq.size()), sk.data(),
                         int(sk.size()), colsum.data(), int(colsum.size()),
                         sv.data(), int(sv.size())),
      "probe kv_dump_q");
  uint32_t layout[3] = {};
  rpc(nntr_hvx_probe_acc_i32_layout(cache.session, layout, 3), "probe layout");
  require(layout[0] == 1u && layout[1] == 0u && layout[2] == 32u,
          "unexpected accumulator layout");
  std::vector<uint8_t> plane[4];
  for (auto &p : plane)
    p.resize(2048u);
  std::vector<int16_t> zip(2048u);
  std::vector<int32_t> acc0(2048u), acc1(2048u);
  uint32_t stats[3] = {};
  rpc(nntr_hvx_probe_cvt(cache.session, cache.id, 0u, col, activation.p,
                         int(activation.n), 0x6000u, 0x4000u, 0u, 1u,
                         plane[0].data(), 2048, plane[1].data(), 2048,
                         zip.data(), 2048, acc0.data(), 2048, stats, 3),
      "probe lower planes");
  rpc(nntr_hvx_probe_cvt(cache.session, cache.id, 0u, col, activation.p,
                         int(activation.n), 0x2000u, 0u, 0u, 1u,
                         plane[2].data(), 2048, plane[3].data(), 2048,
                         zip.data(), 2048, acc1.data(), 2048, stats, 3),
      "probe upper planes");
  require(std::memcmp(acc0.data(), acc1.data(), 8192u) == 0,
          "SDK repeated accumulators differ");
  unsigned negative = 0u, positive = 0u, zero = 0u;
  for (unsigned r = 0; r < 64u; ++r) {
    for (unsigned c = 0; c < 32u; ++c) {
      const unsigned x = r * 32u + c;
      const uint32_t bits =
        uint32_t(plane[0][x]) | uint32_t(plane[1][x]) << 8u |
        uint32_t(plane[2][x]) << 16u | uint32_t(plane[3][x]) << 24u;
      int32_t reconstructed;
      std::memcpy(&reconstructed, &bits, 4u);
      int64_t reference = 0;
      for (unsigned d = 0; d < hd; ++d)
        reference +=
          int64_t(activation.p[r * hd + d]) * kq[(col * 32u + c) * hd + d];
      require(reference == acc0[x],
              "hardware SDK dot differs from dumped masters");
      require(reconstructed == acc0[x],
              "four planes differ from SDK signed int32");
      negative += reconstructed < 0;
      positive += reconstructed > 0;
      zero += reconstructed == 0;
    }
  }
  require(negative && positive && zero, "signed/zero probe coverage missing");
  uint64_t hash = fnv(activation.p, activation.n);
  hash = fnv(kq.data(), kq.size(), hash);
  std::fprintf(
    stderr,
    "{\"schema\":\"attn-raw4plane-v1\",\"record\":\"PROBE\",\"probe_id\":%u,"
    "\"pattern\":%u,\"col\":%u,\"hd\":64,\"rows\":64,\"kvh\":1,\"count\":2048,"
    "\"layout\":[1,0,32],\"sdk_equal\":true,\"host_dot_equal\":true,"
    "\"planes_equal\":true,\"rc\":0,\"negative_count\":%u,\"positive_count\":%"
    "u,"
    "\"zero_count\":%u,\"input_fnv64\":\"%016" PRIx64 "\"}\n",
    probe_id, pattern, col, negative, positive, zero, hash);
  cache.release();
}
int main(int argc, char **argv) {
  try {
    require(argc == 3 && std::strcmp(argv[1], "--dump") == 0,
            "use --dump output.bin");
    require(nntrainer::HtpBackend::global().enabled(), "HTP unavailable");
    FILE *dump = std::fopen(argv[2], "wb");
    require(dump != nullptr, "cannot open dump");
    uint64_t offset = 0u;
    for (const Case &c : cases)
      run_case(c, dump, offset);
    for (unsigned p = 0; p < 4u; ++p)
      run_probe(p, p / 2u, p % 2u);
    require(std::fclose(dump) == 0, "dump close failed");
    std::fprintf(
      stderr,
      "{\"schema\":\"attn-raw4plane-v1\",\"record\":\"SUMMARY\","
      "\"cases\":36,\"case_groups\":12,\"probes\":4,\"bytes\":%" PRIu64
      ",\"rc\":0}\n",
      offset);
    return 0;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FAIL: %s\n", e.what());
    return 1;
  }
}

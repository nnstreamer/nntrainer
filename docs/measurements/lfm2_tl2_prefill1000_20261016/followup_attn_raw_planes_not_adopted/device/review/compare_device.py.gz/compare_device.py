#!/usr/bin/env python3
"""Strict raw4plane fixture readback; no SDK, phone, or kernel execution."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

SCHEMA = 'attn-raw4plane-v1'
META = ('case_id', 'kind', 'fixed', 'n_q', 'cache_from', 'cache_to',
        'qh', 'kvh', 'hd', 'window', 'softcap', 'sinks')
CASE_KEYS = set(META) | {'schema', 'record', 'repetition', 'seed', 'count', 'offset',
                         'blocks', 'mode', 'rc', 'same_repeat', 'finite', 'input_fnv64'}
PROBE_KEYS = {'schema', 'record', 'probe_id', 'pattern', 'col', 'hd', 'rows', 'kvh',
              'count', 'layout', 'sdk_equal', 'host_dot_equal', 'planes_equal', 'rc',
              'negative_count', 'positive_count', 'zero_count', 'input_fnv64'}
SUMMARY_KEYS = {'schema', 'record', 'cases', 'case_groups', 'probes', 'bytes', 'rc'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        need(key not in obj, 'Duplicate JSON key: ' + key)
        obj[key] = value
    return obj


def reject_constant(value):
    raise ValueError('Non-finite JSON constant: ' + value)


def loads(text):
    return json.loads(text, object_pairs_hook=unique_object, parse_constant=reject_constant)


def integer(value, lo=0, hi=0xffffffff):
    return type(value) is int and lo <= value <= hi


def hex64(value):
    return type(value) is str and len(value) == 16 and all(c in '0123456789abcdef' for c in value)


def geometry(case):
    """Existing choose_tiling/widen/range arithmetic for the frozen 12 cases.

    Wide-path capacity must be demonstrated by the measured block count and
    separate actual branch diagnostic. This helper does not assume SDK config
    bytes or prove selection merely from shape.
    """
    n, qh, kvh, hd = (case[k] for k in ('n_q', 'qh', 'kvh', 'hd'))
    if n < 5 and hd <= 128:
        return {'mode': 0, 'blocks': 0, 'readouts': 0, 'br': 0, 'bc': 0}
    g = qh // kvh
    br = min(n, max(1, 64 // g))
    bc = (case['cache_to'] // 3) & ~63
    if bc < 64:
        bc = 64 if case['cache_to'] >= 64 else 32
    bc = min(bc, 256)
    wide = (case['kind'] == 0 and n >= 128 and n % 128 == 0 and
            case['cache_from'] == 0 and case['cache_to'] == n and
            (qh, kvh, hd) == (32, 8, 64) and case['window'] == 0 and
            case['softcap'] == 0 and bc in (128, 256))
    if wide:
        br = 128
    blocks = 0
    for q0 in range(0, n, br):
        q1 = min(q0 + br, n) - 1
        high0 = min(case['cache_from'] + q0 + 1, case['cache_to'])
        high1 = min(case['cache_from'] + q1 + 1, case['cache_to'])
        low0 = max(0, high0 - case['window']) if case['window'] else 0
        blocks += (high1 + bc - 1) // bc - low0 // bc
    blocks *= kvh
    row_tiles = ((g * br + 63) // 64)
    return {'mode': 1, 'blocks': blocks, 'readouts': blocks * row_tiles * (bc // 32),
            'br': br, 'bc': bc}


def read_plan(path):
    plan = loads(path.read_text())
    need(plan['schema'] == SCHEMA and plan['offset_unit'] == 'bytes' and
         plan['count_unit'] == 'float32_elements', 'Plan units/schema')
    need(len(plan['cases']) == 12 and [c['case_id'] for c in plan['cases']] == list(range(12)), 'Frozen 12-case order')
    need([c['name'] for c in plan['cases']] == [
        'full1024', 'full2048', 'q4', 'fixed_q8', 'shifted_prefix', 'window',
        'softcap', 'sinks', 'tail65', 'gemma_local_fixed', 'generic_g4_hd96', 'decode1'], 'Case names/coverage')
    for case in plan['cases']:
        need(len(case['seeds']) == 3 and case['seeds'][0] == case['seeds'][2] and
             case['seeds'][1] == case['seeds'][0] + 1, 'A/B/A seed plan')
        need(case['replay_of'] == [None, None, 0], 'Replay plan')
        for key in ('fixed', 'sinks', 'expected_raw'):
            need(type(case[key]) is bool, 'Plan boolean: ' + key)
        need(case['expected_raw'] == (case['case_id'] in (0, 1)), 'Only two target groups')
        for key in ('kind', 'n_q', 'cache_from', 'cache_to', 'qh', 'kvh', 'hd', 'window'):
            need(integer(case[key]), 'Plan integer: ' + key)
        need(case['qh'] > 0 and case['kvh'] > 0 and case['qh'] % case['kvh'] == 0 and
             case['hd'] % 32 == 0 and case['cache_from'] + case['n_q'] == case['cache_to'], 'Plan geometry')
    need(geometry(plan['cases'][0])['blocks'] == 160 and geometry(plan['cases'][1])['blocks'] == 576, 'Target geometry')
    probe = plan['probe_plan']
    need(probe == {'count': 4, 'ids': [0, 1, 2, 3], 'hd': 64, 'rows': 64,
                   'kvh': 1, 'columns': [0, 1, 0, 1], 'patterns': [0, 0, 1, 1], 'length': 2048}, 'Four probe plan')
    return plan


def parse_log(text, plan):
    cases, probes, summaries = [], [], []
    done = False
    for lineno, line in enumerate(text.splitlines(), 1):
        if SCHEMA not in line:
            continue  # Existing FastRPC/HTP diagnostics are not fixture records.
        need(not done, 'Record after SUMMARY')
        try:
            row = loads(line)
        except (ValueError, json.JSONDecodeError) as e:
            raise ValueError(f'Malformed/interleaved fixture JSON at line {lineno}: {e}') from e
        need(type(row) is dict and row.get('schema') == SCHEMA, 'Fixture schema')
        kind = row.get('record')
        keys = {'CASE': CASE_KEYS, 'PROBE': PROBE_KEYS, 'SUMMARY': SUMMARY_KEYS}.get(kind)
        need(keys is not None and set(row) == keys, 'Unknown/missing fixture fields')
        need(integer(row['rc']) and row['rc'] == 0, 'RPC/summary failure')
        if kind == 'CASE':
            need(not probes, 'CASE after PROBE')
            index = len(cases)
            need(index < 36, 'Excess CASE record')
            case = plan['cases'][index // 3]
            repeat = index % 3
            need(all(row[k] == case[k] and (type(row[k]) in (int, float) if k == 'softcap' else type(row[k]) is type(case[k])) for k in META), 'Case identity/order/metadata')
            need(integer(row['repetition']) and row['repetition'] == repeat and
                 integer(row['seed']) and row['seed'] == case['seeds'][repeat], 'Repetition/seed')
            count = case['n_q'] * case['qh'] * case['hd']
            need(integer(row['count']) and row['count'] == count, 'Output count')
            need(integer(row['offset'], hi=2**63-1) and row['offset'] == sum(c['count'] * 4 for c in cases), 'Byte offset/gap')
            expected = geometry(case)
            need(integer(row['blocks']) and row['blocks'] == expected['blocks'] and
                 integer(row['mode']) and row['mode'] == expected['mode'], 'Actual block count/mode')
            need(row['finite'] is True and row['same_repeat'] is (True if repeat == 2 else None), 'Finite/replay self-check')
            need(hex64(row['input_fnv64']), 'Input digest format')
            cases.append(row)
        elif kind == 'PROBE':
            need(len(cases) == 36, 'PROBE before all CASE records')
            index = len(probes)
            need(index < 4, 'Excess PROBE record')
            p = plan['probe_plan']
            expected = {'probe_id': p['ids'][index], 'pattern': p['patterns'][index],
                        'col': p['columns'][index], 'hd': p['hd'], 'rows': p['rows'],
                        'kvh': p['kvh'], 'count': p['length']}
            need(all(integer(row[k]) and row[k] == v for k, v in expected.items()), 'Probe identity/order')
            need(row['layout'] == [1, 0, 32] and all(type(x) is int for x in row['layout']), 'Actual accumulator layout')
            need(all(row[k] is True for k in ('sdk_equal', 'host_dot_equal', 'planes_equal')), 'Probe parity failure')
            need(all(integer(row[k], lo=1, hi=p['length']) for k in ('negative_count', 'positive_count', 'zero_count')) and
                 sum(row[k] for k in ('negative_count', 'positive_count', 'zero_count')) == p['length'], 'Probe signed cohort counts')
            need(hex64(row['input_fnv64']), 'Probe input digest')
            probes.append(row)
        else:
            expected = {'cases': 36, 'case_groups': 12, 'probes': 4,
                        'bytes': sum(c['count'] * 4 for c in cases)}
            need(len(cases) == 36 and len(probes) == 4 and
                 all(integer(row[k], hi=2**63-1) and row[k] == v for k, v in expected.items()), 'Incomplete summary')
            summaries.append(row)
            done = True
    need(len(summaries) == 1 and done, 'Missing successful SUMMARY')
    for i in range(0, 36, 3):
        a, b, replay = cases[i:i+3]
        need(a['input_fnv64'] == replay['input_fnv64'] and a['input_fnv64'] != b['input_fnv64'], 'A/B/A input fingerprint')
    need(all(sum(p[k] for p in probes) > 0 for k in ('negative_count', 'positive_count', 'zero_count')), 'Probe requires negative/positive/zero accumulators')
    return {'cases': cases, 'probes': probes, 'summary': summaries[0]}


def check_dumps(control, candidate, logs):
    size = logs[0]['summary']['bytes']
    need(control.stat().st_size == candidate.stat().st_size == size, 'Dump size/truncation/trailer')
    outputs = []
    with control.open('rb') as lhs, candidate.open('rb') as rhs:
        replay = {}
        for a, b in zip(logs[0]['cases'], logs[1]['cases']):
            need(a == b, 'Control/candidate CASE/input metadata differs')
            count = a['count'] * 4
            x, y = lhs.read(count), rhs.read(count)
            need(x == y, f'Output bit mismatch case={a["case_id"]} repeat={a["repetition"]}')
            need(all((word[0] & 0x7f800000) != 0x7f800000 for word in struct.iter_unpack('<I', x)), 'Non-finite or poisoned output')
            key, repeat = a['case_id'], a['repetition']
            if repeat == 0:
                replay[key] = x
            elif repeat == 1:
                need(x != replay[key], 'A/B output did not change')
            else:
                need(x == replay.pop(key), 'A/B/A output replay differs')
            outputs.append({'case_id': key, 'repetition': repeat, 'count': a['count'],
                            'offset': a['offset'], 'output_sha256': sha(x),
                            'input_fnv64': a['input_fnv64'], 'blocks': a['blocks'], 'mode': a['mode']})
        need(not lhs.read(1) and not rhs.read(1), 'Unparsed output bytes')
    need(logs[0]['probes'] == logs[1]['probes'], 'Control/candidate probe records differ')
    return outputs


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('plan', 'control-log', 'candidate-log', 'control-dump', 'candidate-dump', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--trace-fixture-log', type=Path,
                   help='Optional third fixture run JSONL; requires identical inputs/metadata/probe results but no third dump.')
    a = p.parse_args()
    plan = read_plan(a.plan)
    logs = [parse_log(path.read_text(), plan) for path in (a.control_log, a.candidate_log)]
    outputs = check_dumps(a.control_dump, a.candidate_dump, logs)
    trace = None
    if a.trace_fixture_log:
        trace = parse_log(a.trace_fixture_log.read_text(), plan)
        need(trace == logs[0], 'Trace/control fixture inputs, results or geometry differ')
    result = {'status': 'PASS', 'schema': SCHEMA, 'case_groups': 12, 'attention_rpc_calls_per_arm': 36,
              'signed_plane_probes_per_arm': 4, 'output_bytes_per_arm': logs[0]['summary']['bytes'],
              'full1024_blocks_per_call': 160, 'full2048_blocks_per_call': 576,
              'all_outputs_bit_exact_finite': True, 'all_aba_replays_exact_and_b_changed': True,
              'input_fnv64_identical_across_arms': True, 'probes': logs[0]['probes'], 'outputs': outputs,
              'input_sha256': {name: file_sha(getattr(a, name)) for name in
                               ('plan', 'control_log', 'candidate_log', 'control_dump', 'candidate_dump')},
              'actual_raw_selection_verified': False,
              'trace_fixture_metadata_equal': trace is not None,
              'limits': ['Exact mode selection/config compatibility requires separate diagnostic records; geometry alone is not a hit.',
                         'Root must verify successful child exit and identical fixture/host runtime identities; this parser reads transferred records.',
                         'Input FNV64 is a reproducibility fingerprint, not a cryptographic equality proof; generator/binary identity is reviewed separately.',
                         'No benchmark result or historical removed-toggle coverage is claimed.']}
    if a.trace_fixture_log:
        result['input_sha256']['trace_fixture_log'] = file_sha(a.trace_fixture_log)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(f'RAW4PLANE DEVICE READBACK PASS: 12 groups, 36 RPCs/arm, 4 signed-plane probes/arm, {result["output_bytes_per_arm"]} exact output bytes/arm; actual mode proof remains separate')


if __name__ == '__main__':
    main()

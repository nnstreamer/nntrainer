QK raw four-plane candidate, version 2 — device validation pending

Base: 73a4ab7baf30aa96fcdf7dbca3d7c86f899bca3a.
Only production file: nntrainer/tensor/htp_backend/hmx/hexkl_attn_q.c.
Patch SHA256 d8d1827242aab3e698e7c69eefb73711305d37b843ba3798ba2b2e251e75fbb3.
Candidate SHA256 8c54a3c86509c17b0c5cda01c0a2de6abf3de335fca6e268cb74b7dfed26d4e5.
Baseline SHA256 4b71749ac993c1ae165550f0d182ea748fa6106543e1904ce498a19ac59e478a.
clang-format 14 second pass was byte-identical. No root tree, phone or runtime
was changed by the author. No commit or deployment is included.

Change and scope
The inspected SDK uses four HMX convert passes to write four 2 KiB byte planes
into its private config scratch, then shuffles them into an 8 KiB int32 tile.
The selected QK path writes those four planes directly into the existing L.acc
or deferred Qx slot and reconstructs four signed rows in HVX registers when
converting scores. The same 32-bit bit patterns feed the original FP32/qf32/
fp16 arithmetic. PV still uses the SDK int32 readout. No MAC, causal mask,
softmax, P quantizer, output update, allocation, layout or worker schedule is
changed. source-proof.json records byte-identical retained functions and an
identical raw/generic FP body after the accumulator load.

Qualification is per call and explicitly Hexagon v81 only. It requires dynamic
Q8, full 1024 or 2048 rows, 32 Q / 8 KV heads, head dimension 64, G=4,
Br=128/Bc=256/GBr=512, no window/softcap/sinks, exact row-major accumulator
layout, 2 KiB destination alignment and bounded nonoverlapping L.acc/Qx slots.
The SDK config size must be 16 KiB and its first 4 KiB must exactly match all
1024 immutable uint32 words: each 1 KiB block starts with 64 scale words
{0x6000,0x4000,0x2000,0}, and every remaining word is zero. A 32-vector OR
reduction checks every byte without a temporary 1 KiB stack buffer. The final
12 KiB SDK scratch is not checked and remains available to PV. Unsupported
shape, fixed Q8, Q4, Gemma geometry, config, layout or extent uses the existing
SDK path for the entire call; raw and int32 representations cannot mix in a
call. No config result is cached across calls.

The original generic dequant_s_at body is retained byte for byte. Raw-specific
score conversion is selected once per immediate tile or once per worker job,
not once per four-row group. The duplicate raw score body is deliberately
small and checked against the original real-HVX reference. Fallback math and
error statuses remain unchanged, but this source/codegen proof is not a
measurement of unchanged Gemma TPS.

Ordering and error contract
The four convert operations use the same biases and ordering as the SDK.
A volatile vector load of the final 128 bytes provides the existing i24/old
raw-plane VTCM pending-write dependency before any subsequent accumulator
clear or deferred-worker dispatch. This is supported by inspected codegen and
previous device use, not a general hardware-fence proof. New actual device
parity is still required. The qualified geometry excludes the SDK precheck
alignment errors; HMX convert itself returns no status. Unsupported calls keep
the SDK return value. We do not claim to add hardware timeout/error reporting.
All original softmax/Pquant/dequant joins and error drains are retained. A
worker only sees fully written immutable Qx slots and joins before reuse.

Memory and code generation
No extra heap, VTCM, persistent cache, reader, staging slot or buffer capacity.
The new call-local flag occupies existing attn_ctx padding: the independent
v81 layout check reports 768 B / alignment 128 before and after. The qualifier
has a 32 B frame. Existing v81 frames are unchanged: entry 1536 B, phase_qprep
512 B, phase_qk 512 B, dequant_worker 384 B, softmax_worker 1920 B, pquant_worker
32 B and store_worker 40 B. Both dequant bodies inline; four reconstructed rows
are not a stack buffer. commands/asm/stack outputs are in codegen/. The first
unvalidated version caused a generic dequant call and inner mode checks; it
is retained under history/v1 and superseded by this version.

Each selected tile removes the SDK's 8 KiB materialized int32 store and its
8 KiB reread. Four convert writes, raw-plane loads and 64 HVX shuffles remain.
These are logical VTCM operations, not measured physical traffic or a speedup
bound. Full1024 has 10240 QK readouts per attention call; full2048 has 36864.
No TPS gain is claimed. The 4 KiB qualification scan happens before the
existing kernel call_t0/us_total timer, so those phase statistics exclude it;
wrapper/end-to-end measurement includes it.

Host validation (executed, strict ASan + UBSan, halt on first error)
Run candidate/tools/lfm2_attn_raw_planes_check.py with --repo R,
--source candidate/nntrainer/tensor/htp_backend/hmx/hexkl_attn_q.c,
--hexagon-tools EXTERNAL_HEXAGON_TOOLS_ROOT, --output OWN_OUTPUT --sanitize.
The source and fixture hashes are in source-hashes.json and test-hashes.json.
checks/host-san-v2/results.json:
- 2064 actual four-row HVX reconstructions, including INT32_MIN/MAX, byte
  carries, both signs, zero and random full 32-bit values.
- 4129 config/geometry negatives: every one of 1024 config words with each
  of four byte positions modified, plus 33 shape/layout/extent guards.
  v79 and non-Hexagon copies of the exact guard reject the candidate.
- 568 actual readout-address/dequant/worker/pipeline cases with workers 0..8,
  both score banks, final Qx slot, qb=9/qi=0 in the second chunk, fixed/Q4/
  invalid-config fallbacks, original SDK read errors and PV error drains.
  Raw scores are compared byte for byte with the unchanged original real-HVX
  dequant reference. PV overwrites and ASan-poisons L.acc before releasing
  the real pthread worker pool, detecting stale accumulator use.
- Three production-source mutants are rejected by intended runtime checks:
  wrong byte order, omitted reserved config words, wrong deferred address.
  Results and commands are in checks/mutants/; check_mutations.py reproduces.

HMX, DMA, softmax and PV arithmetic are stand-ins in the scheduling fixture.
The actual HVX primitive and worker pool are exercised; this is not real DMA,
DSP cache visibility, fence timing or whole-attention-output evidence. The
explicit v81 macro in host extraction is an architecture stand-in. The
existing aligned(4) HVX_UVector host shim is retained, with no sanitizer
suppression. Do not call host tests hardware conversion tests.

Device correctness fixture (built; root-only execution pending)
device/attention_raw_planes_device_check.cpp uses the current IDL APIs only.
The old attention_pipeline_device_check is the starting pattern, but its
removed attn_q8_npu_step is replaced by attn_q_step. The old 81-case output
hashes do not prove parity of this pipeline. The old 300-case public test used
removed CPU/NPU environment toggles; unchanged reuse would compare the same
path twice, so it is not counted as new coverage.

New frozen caseplan.json: 12 groups / 36 successful attention RPCs, each A/B/A
on the same cache handle; all cache rows are overwritten each repetition.
It covers full1024/full2048, Q4, fixed Q8, true shifted query prefix37, window,
softcap, sinks, tail65, Gemma local fixed16/8/256, generic G4/HD96 and decode1.
Each output is NaN-poisoned before RPC, checked by exponent bits for complete
finite output, written in full to the dump, and checked A0==A2 and A0!=B1.
Inputs are deterministically fingerprinted (FNV64, not cryptographic proof).
Each arm dumps exactly 231908352 bytes. No benchmark mode exists.

Four separate probe cases call the existing probe_cvt twice, with scales
6000/4000 and 2000/0, to collect the four hardware planes. They first require
both SDK int32 results to agree, then compare every reconstructed signed
int32 with SDK and an independent int64 dot over dynamic kv_dump_q masters.
Positive, negative and zero accumulators are required, and the actual layout
must be usable/base0/stride32. The zero-scale high plane is measured, not
predicted using a host floating-point scale model. These probes verify SDK
plane semantics; the candidate's direct destinations, fence and deferred
reuse require the full attention A/B/A and actual-selection trace as well.

Build with device/build.py --repo R --ndk EXTERNAL_NDK --sdk EXTERNAL_SDK
--output OWN_OUTPUT. It uses existing generated headers and libnntrainer;
no IDL or runtime rebuild is required. The frozen executable SHA is
351ca73b417e7b908790e9e041389aee662e9ba719a19e765e4d6a09aaadef2c.
Root can run it beside the same seven runtime files using
  ./attention_raw_planes_device_check --dump output.bin
and capture stderr JSONL. Run exactly the same executable with control and
candidate DSPs and compare full dumps using the independent review parser.
No author phone access occurred. Fixed/normal/diagnostic runtime hashes are
owned and verified by root; the author does not alter those artifacts.

Separate diagnostic (not production performance evidence)
diagnostic/diagnostic.patch SHA
0028568503122041a908d448404da84cbcae775bb9ba25f2c0bc6be867cad311
adds NNTR_LFM2_ATTN_RAW_PLANES_TRACE only. Macro OFF full-TU object is byte
identical to normal (d5e298850eae1815ba3575ab91e23fc59efc6deb2c5edb9f8ff30645c5174c73).
Macro ON counts actual successful QK readouts by serial raw/deferred raw/SDK
and emits one FARF(ERROR) record after all joins; 4 B static sequence exists
only in this diagnostic. It excludes PV SDK reads. Entry frame stays1536 B;
FARF's diagnostic-only helper adds its own280 B frame. Counters run inside
phase timing and therefore diagnostic TPS/phase values are not normal
performance measurements. diagnostic/check.py reuses568 actual pipeline
cases to check counter placement through success/errors. Parser validation
has3 valid /65 rejected inputs and exact C formatter max114B payload.

Use diagnostic/parse.py --log RAW --expected device-trace-expected.json
--pid ACTUAL_CHILD_PID --output result.json. It rejects missing, truncated,
conflicting, reordered, mixed-PID, overflow and failed records; exact
transport duplicates are counted. Independent expected device scope is33
prefill calls (decode3 omitted), selected6, raw serial55296/deferred86016,
SDK QK170472. Full1024 selected call:10240/0; full2048:8192/28672, requiring
nonzero worker pool and the existing plan fit. Complete expected counts come
from the independent actual choose/widen/causal-range derivation, not observed
trace maxima. Native fixture outputs and model IDs still require root's
actual validation before any adoption.

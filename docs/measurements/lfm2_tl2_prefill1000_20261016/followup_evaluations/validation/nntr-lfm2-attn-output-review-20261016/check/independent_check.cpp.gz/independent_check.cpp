// SPDX-License-Identifier: Apache-2.0
/**
 * @file lfm2_attn_output_reuse_check.cpp
 * @brief Validate the production attention buffer selection and FC handoff.
 * @author NNTrainer contributors
 * @bug RPC is mocked; device attention arithmetic is unchanged by this patch.
 */
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <vector>

#define ml_logw(...) ((void)0)
static void check(bool ok, const char *message) {
  if (!ok)
    throw std::runtime_error(message);
}
static unsigned allocations;
static size_t copied_bytes;
static void stagedMemcpy(void *dst, const void *src, size_t bytes, int = 0) {
  copied_bytes += bytes;
  std::memcpy(dst, src, bytes);
}
struct HtpRpcBuffer {
  std::vector<uint8_t> memory;
  bool ion = true;
  explicit HtpRpcBuffer(size_t bytes) : memory(bytes, 0) { ++allocations; }
  uint8_t *data() { return memory.data(); }
  size_t size() const { return memory.size(); }
  bool isIon() const { return ion; }
};
struct HtpProfile {
  static HtpProfile &global() {
    static HtpProfile p;
    return p;
  }
  int level() const { return 0; }
};

struct Backend {
  struct IonAlias {
    const void *ion = nullptr;
  };
  std::array<IonAlias, 16> ion_alias_{};
  std::mutex invoke_mutex_;
  const void *trueSource(const void *p, size_t) { return p; }
  void throwIfLost(const void *, size_t, int) {}
  void noteLost(const void *, size_t) {
    throw std::runtime_error("unexpected kept input overwrite");
  }
  static void sampledCopy(void *, const void *, size_t) {
    throw std::runtime_error("attention output must be fully materialized");
  }
  // Structs, stage, sampledSame, stageInput and copyOutOf are verbatim from
  // production. Allocation/RPC and unused kept-window/profile helpers are
  // stand-ins; the tested full-host handoff never enters those helpers.
// clang-format off
#include "pool.inc"
#include "copy_out.inc"
  // clang-format on
  StagingPool out_pool_, act_pool_, x2_pool_;

  bool run(unsigned n_q, unsigned n_head_q, unsigned n_head_kv,
           unsigned head_dim, unsigned append_rows, unsigned kv_stride,
           float softcap, const float *sinks, const float *q,
           const uint16_t *k_rows, const uint16_t *v_rows, float *out,
           bool fail_rpc = false) {
    const int q_len = int(n_q * n_head_q * head_dim);
#include "reuse.inc"
    const bool reused = rpc_out != out;
    // Deterministic RPC output with no heap staging in this stand-in.
    const int err = fail_rpc ? 1 : 0;
    constexpr int AEE_SUCCESS = 0;
    // An RPC may write its ION output before reporting failure.
    for (int i = 0; i < (err ? 64 : q_len); ++i)
      rpc_out[i] = float((i % 257) - 128) * 0.25f;
#include "publish.inc"
    return reused;
  }
};

struct Fixture {
  unsigned rows;
  size_t bytes, cls;
  Backend b;
  std::vector<float> q, out;
  std::vector<uint16_t> k, v;
  uint8_t *slot;
  explicit Fixture(unsigned m = 1024, unsigned heads = 32, unsigned dim = 64) :
    rows(m),
    bytes(size_t(m) * heads * dim * sizeof(float)),
    cls(Backend::stageClass(bytes)),
    q(bytes / 4, 1.25f),
    out(bytes / 4, -999.f),
    k(size_t(m) * 512u, 1),
    v(k.size(), 2) {
    b.out_pool_.by_class[cls] = std::make_unique<HtpRpcBuffer>(bytes + 4096);
    b.act_pool_.by_class[cls] = std::make_unique<HtpRpcBuffer>(bytes + 4096);
    slot = b.out_pool_.by_class[cls]->data();
    allocations = 0;
    copied_bytes = 0;
  }
  bool run(const float *query = nullptr, const uint16_t *key = nullptr,
           const uint16_t *value = nullptr, float *output = nullptr,
           unsigned heads = 32, unsigned kv_heads = 8, unsigned dim = 64,
           float softcap = 0, const float *sinks = nullptr, bool fail = false,
           bool append = true) {
    return b.run(rows, heads, kv_heads, dim, append ? rows : 0, 512, softcap,
                 sinks, query ? query : q.data(), key ? key : k.data(),
                 value ? value : v.data(), output ? output : out.data(), fail);
  }
  void verifyOutput() const {
    for (size_t i = 0; i < out.size(); ++i)
      check(out[i] == float(int(i % 257u) - 128) * 0.25f,
            "output is not fully materialized");
  }
};

int main() {
  unsigned cases = 0;
  for (unsigned rows : {2u, 16u, 64u, 512u, 1024u}) {
    Fixture f(rows);
    check(f.run(), "valid buffer not reused");
    check(allocations == 0 && copied_bytes == f.bytes,
          "attention allocated or copied Q");
    f.verifyOutput();
    const auto &record = f.b.out_pool_.copied_out.at(f.cls);
    check(record.first == f.out.data() && record.second == f.bytes &&
            !record.kept,
          "output ownership record");
    auto &input =
      f.b.stageInput(f.b.act_pool_, f.out.data(), f.bytes, &f.b.out_pool_);
    check(input.data() == f.slot && copied_bytes == f.bytes && allocations == 0,
          "FC failed to swap attention output without another copy");
    auto &output = f.b.stage(f.b.out_pool_, f.bytes);
    check(output.data() != input.data() && allocations == 0,
          "FC output would overwrite its input");
    ++cases;
  }
  for (unsigned reason = 0; reason < 13; ++reason) {
    Fixture f;
    const float *q = nullptr;
    const uint16_t *k = nullptr, *v = nullptr;
    float *out = nullptr;
    if (reason == 0)
      f.b.out_pool_.by_class.erase(f.cls);
    if (reason == 1)
      f.b.out_pool_.by_class[f.cls].reset();
    if (reason == 2) {
      f.b.out_pool_.by_class[f.cls] = std::make_unique<HtpRpcBuffer>(4096);
      allocations = 0;
    }
    if (reason == 3)
      f.b.out_pool_.by_class[f.cls]->ion = false;
    if (reason == 4)
      f.b.out_pool_.holds[f.cls] = {f.q.data(), f.bytes, true};
    if (reason == 5)
      f.b.out_pool_.copied_out[f.cls] = {f.q.data(), f.bytes, true};
    if (reason == 6)
      q = reinterpret_cast<const float *>(f.slot);
    if (reason == 7)
      k = reinterpret_cast<const uint16_t *>(f.slot);
    if (reason == 8)
      v = reinterpret_cast<const uint16_t *>(f.slot + 128);
    if (reason == 9)
      out = reinterpret_cast<float *>(f.slot + 4);
    // Even a disjoint output prefix cannot share a DMA buffer with live Q.
    if (reason == 10)
      q = reinterpret_cast<const float *>(f.slot + f.bytes);
    const float sink = 0;
    check(!f.run(q, k, v, out, 32, 8, 64, reason == 11 ? 1.0f : 0.0f,
                 reason == 12 ? &sink : nullptr),
          "unsafe/unsupported buffer was reused");
    check(!allocations && !copied_bytes, "fallback changed staging");
    ++cases;
  }
  for (unsigned rows : {1u, 1025u, 1920u, 2048u}) {
    Fixture f(rows);
    check(!f.run() && !allocations && !copied_bytes,
          "decode or larger prefill changed");
    ++cases;
  }
  for (auto shape : {std::array<unsigned, 3>{24, 8, 64},
                     {32, 4, 64},
                     {32, 8, 128},
                     {8, 2, 256}}) {
    Fixture f(1024, shape[0], shape[2]);
    check(!f.run(nullptr, nullptr, nullptr, nullptr, shape[0], shape[1],
                 shape[2]) &&
            !allocations && !copied_bytes,
          "other/Gemma geometry changed");
    ++cases;
  }
  {
    Fixture f;
    check(f.run(nullptr, reinterpret_cast<uint16_t *>(f.slot),
                reinterpret_cast<uint16_t *>(f.slot), nullptr, 32, 8, 64, 0,
                nullptr, false, false),
          "zero-length append may ignore K/V pointers");
    f.verifyOutput();
    ++cases;
  }
  {
    Fixture f;
    check(
      f.run(nullptr, nullptr, nullptr, nullptr, 32, 8, 64, 0, nullptr, true) &&
        !f.b.out_pool_.copied_out.count(f.cls),
      "failed RPC published an output");
    check(!allocations && !copied_bytes && f.out[0] == -999.f,
          "failed RPC materialized stale output");
    ++cases;
  }
  {
    Fixture f;
    check(f.run(), "mutation setup");
    f.out[0] += 1.0f;
    auto &input =
      f.b.stageInput(f.b.act_pool_, f.out.data(), f.bytes, &f.b.out_pool_);
    check(input.data() != f.slot && copied_bytes == 2u * f.bytes &&
            !allocations &&
            std::memcmp(input.data(), f.out.data(), f.bytes) == 0,
          "host mutation was ignored by FC input staging");
    ++cases;
  }

  {
    Fixture f;
    std::vector<float> prior(f.out.size(), 42.0f);
    std::memcpy(f.slot, prior.data(), f.bytes);
    f.b.out_pool_.holds[f.cls] = {prior.data(), f.bytes, false};
    f.b.out_pool_.copied_out[f.cls] = {prior.data(), f.bytes, false};
    check(f.run(nullptr, nullptr, nullptr, nullptr, 32, 8, 64, 0,
                nullptr, true), "partial failure did not select reusable slot");
    check(!f.b.out_pool_.copied_out.count(f.cls) &&
          !f.b.out_pool_.holds.count(f.cls) && copied_bytes == 0 &&
          allocations == 0, "partial failure published stale ownership");
    for (float x : prior)
      check(x == 42.0f, "partial failure destroyed materialized prior tensor");
    for (float x : f.out)
      check(x == -999.0f, "partial failure modified public output");
    check(f.run(), "retry failed to reuse slot");
    f.verifyOutput();
    auto &input = f.b.stageInput(f.b.act_pool_, f.out.data(), f.bytes,
                                &f.b.out_pool_);
    check(input.data() == f.slot && copied_bytes == f.bytes &&
          allocations == 0, "retry did not hand off complete result");
    auto &output = f.b.stage(f.b.out_pool_, f.bytes);
    check(input.data() != output.data(), "retry FC output clobbers input");
    ++cases;
  }
  {
    Fixture f;
    for (unsigned iteration = 0; iteration < 8; ++iteration) {
      const auto before_copies = copied_bytes;
      check(f.run(), "repeat did not select existing output slot");
      f.verifyOutput();
      auto &input = f.b.stageInput(f.b.act_pool_, f.out.data(), f.bytes,
                                  &f.b.out_pool_);
      auto &output = f.b.stage(f.b.out_pool_, f.bytes);
      check(input.data() != output.data() && allocations == 0 &&
            copied_bytes == before_copies + f.bytes,
            "repeat pool ownership/copy accounting mismatch");
      // Model an FC overwriting its own separate output before another call.
      std::memset(output.data(), 0x5a, f.bytes);
    }
    ++cases;
  }
  std::printf("ATTN_OUTPUT_REUSE %u cases PASS\n", cases);
}

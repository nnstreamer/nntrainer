// SPDX-License-Identifier: Apache-2.0
// Arithmetic prescreen only: actual DSP router versus the separately compiled
// strict ARM production kernel. No candidate app dispatch is installed.
#include "lfm2_router_arm.h"
#include <compute_ops.h>
#include <htp_backend.h>
#include <thread_manager.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>

static uint32_t bits(float x) {
  uint32_t v;
  std::memcpy(&v, &x, 4);
  return v;
}
static void put(float *p, uint32_t v) { std::memcpy(p, &v, 4); }
static void fill(float *p, size_t n, unsigned mode, bool weight) {
  const uint32_t special[] = {0, 0x80000000, 1, 0x80000001, 0x00800000,
                             0x80800000, 0x7f800000, 0xff800000,
                             0x7fc00021, 0xffc00042, 0x7f800063, 0xff800084};
  uint32_t seed = weight ? 0x783abc : 0x237abc;
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    uint32_t v = (seed & 0x807fffff) | ((120u + unsigned(i % 12)) << 23);
    if (((mode == 1 && !weight) || (mode == 2 && weight) || mode == 3) &&
        i % 257 == 0)
      v = special[(i / 257) % 12];
    if (mode == 4)
      v = special[i % 6];
    if (mode == 5)
      v = (seed & 0x807fffff) | (250u << 23);
    if (mode == 6)
      v = (seed & 0x807fffff) | ((126u + unsigned(i % 3)) << 23);
    if (mode == 7)
      v = (i & 1) ? 0x80000000 : 0;
    put(p + i, v);
  }
  // Every staged input differs in the sampled prefix even if a vector address
  // is reused. Retained weight vectors below never change after registration.
  if (!weight)
    put(p, 0x3f800000 + mode);
}
int main(int argc, char **argv) {
  try {
    nntrainer::ThreadManagerConfig config;
    config.compute_threads = argc == 2 ? std::stoul(argv[1]) : 8;
    nntrainer::ThreadManager::setConfig(config);
    if (!nntrainer::HtpBackend::global().enabled())
      throw std::runtime_error("HTP unavailable");
    auto *ops = nntrainer::get_htp_ops();
    std::vector<std::unique_ptr<std::vector<float>>> weight_owner;
    unsigned cases = 0, failures = 0;
    for (unsigned rows : {128u, 1024u, 2048u}) {
      for (unsigned mode = 0; mode < 8; ++mode) {
        if (rows != 128 && mode != 0 && mode != 3 && mode != 4)
          continue;
        weight_owner.emplace_back(new std::vector<float>(2048 * 64));
        auto &w = *weight_owner.back();
        std::vector<float> x(size_t(rows) * 2048), ref(size_t(rows) * 64);
        std::vector<float> got(ref.size());
        fill(x.data(), x.size(), mode, false);
        fill(w.data(), w.size(), mode, true);
        ops->router_logits_fp32(rows, 2048, 64, x.data(), nullptr, 1e-5f,
                               w.data(), ref.data(), 0, 0, nullptr, nullptr,
                               nullptr);
        nntrainer::ThreadManager::Global().parallel_for(
          0, rows / 4, [&](size_t row) {
            causallm::lfm2RouterArmBlock(x.data() + row * 4 * 2048, w.data(),
                                       got.data() + row * 4 * 64);
          });
        size_t different = 0;
        for (size_t i = 0; i < ref.size(); ++i) {
          if (bits(ref[i]) != bits(got[i])) {
            if (different < 4)
              std::printf("DIFF M=%u mode=%u i=%zu dsp=%08x arm=%08x\n", rows,
                          mode, i, bits(ref[i]), bits(got[i]));
            ++different;
          }
        }
        std::printf("ROUTER_NUMERIC M=%u mode=%u elements=%zu differing=%zu %s\n",
                    rows, mode, ref.size(), different,
                    different ? "FAIL" : "PASS");
        ++cases;
        failures += different != 0;
      }
    }
    std::printf("ROUTER_NUMERIC %u cases %u failures threads=%u\n", cases,
                failures, config.compute_threads);
    return failures ? 1 : 0;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "ROUTER_NUMERIC FAIL %s\n", e.what());
    return 1;
  }
}

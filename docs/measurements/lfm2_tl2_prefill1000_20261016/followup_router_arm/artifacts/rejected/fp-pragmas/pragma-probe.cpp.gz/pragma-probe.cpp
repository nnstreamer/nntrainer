// SPDX-License-Identifier: Apache-2.0
// Feasibility probe only. No production dispatch change.
#pragma float_control(precise, on, push)
#pragma clang fp contract(off)
#include <arm_neon.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <vector>
#include <compute_ops.h>
#include <htp_backend.h>
#include <thread_manager.h>

constexpr unsigned K = 2048, E = 64;
static void block(const float *x, const float *w, float *out) {
#pragma clang fp contract(off)
  for (unsigned col = 0; col < E; col += 16) {
    float32x4_t acc[4][4];
#pragma unroll
    for (unsigned r = 0; r < 4; ++r)
#pragma unroll
      for (unsigned e = 0; e < 4; ++e)
        acc[r][e] = vdupq_n_f32(0.0f);
    for (unsigned k = 0; k < K; ++k) {
      float32x4_t weight[4];
#pragma unroll
      for (unsigned e = 0; e < 4; ++e)
        weight[e] = vld1q_f32(w + k * E + col + e * 4);
#pragma unroll
      for (unsigned r = 0; r < 4; ++r) {
        float32x4_t input = vdupq_n_f32(x[r * K + k]);
#pragma unroll
        for (unsigned e = 0; e < 4; ++e)
          acc[r][e] = vaddq_f32(acc[r][e], vmulq_f32(input, weight[e]));
      }
    }
#pragma unroll
    for (unsigned r = 0; r < 4; ++r)
#pragma unroll
      for (unsigned e = 0; e < 4; ++e)
        vst1q_f32(out + r * E + col + e * 4, acc[r][e]);
  }
}
static void armRouter(const float *x, const float *w, float *out, unsigned m) {
  nntrainer::ThreadManager::Global().parallel_for(0, m / 4, [&](size_t row) {
    block(x + row * 4 * K, w, out + row * 4 * E);
  });
}
static void fill(float *data, size_t n, uint32_t seed) {
  for (size_t i = 0; i < n; ++i) {
    seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
    uint32_t bits = (seed & 0x807fffffu) | ((121u + unsigned(i % 7)) << 23);
    std::memcpy(data + i, &bits, sizeof bits);
  }
}
int main() {
  try {
    if (!nntrainer::HtpBackend::global().enabled()) throw std::runtime_error("HTP unavailable");
    auto *ops = nntrainer::get_htp_ops();
    std::printf("THREADS %u\n",nntrainer::ThreadManager::Global().getComputeThreadCount());
    std::vector<float> weights(K * E);fill(weights.data(),weights.size(),0x12542u);
    for (unsigned rows : {128u,1024u,2048u}) {
      std::vector<float> x(size_t(rows)*K), ref(size_t(rows)*E), got(ref.size());
      fill(x.data(),x.size(),0x54921u);
      auto run=[&](unsigned arm) {
        if(arm) armRouter(x.data(),weights.data(),got.data(),rows);
        else ops->router_logits_fp32(rows,K,E,x.data(),nullptr,1e-5f,weights.data(),ref.data(),0,0,nullptr,nullptr,nullptr);
      };
      run(0);run(1);
      size_t different=0;double max_diff=0;
      for(size_t i=0;i<ref.size();++i){
        if(std::memcmp(ref.data()+i,got.data()+i,4))++different;
        max_diff=std::max(max_diff,double(std::abs(ref[i]-got[i])));
      }
      std::printf("PARITY rows=%u bytes_differ_elements=%zu max_abs=%.9g\n",rows,different,max_diff);
      for(unsigned i=0;i<3;++i){run(0);run(1);}
      std::vector<double> times[2];
      for(unsigned i=0;i<15;++i)for(unsigned j=0;j<2;++j){
        unsigned arm=(i+j)%2;auto start=std::chrono::steady_clock::now();run(arm);
        double us=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count();
        times[arm].push_back(us);std::printf("SAMPLE rows=%u rep=%u arm=%u us=%.3f\n",rows,i,arm,us);
      }
      for(unsigned arm=0;arm<2;++arm){std::sort(times[arm].begin(),times[arm].end());std::printf("MEDIAN rows=%u arm=%u us=%.3f\n",rows,arm,times[arm][7]);}
    }
    std::puts("DONE");
  }catch(const std::exception&e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}
}
#pragma float_control(pop)

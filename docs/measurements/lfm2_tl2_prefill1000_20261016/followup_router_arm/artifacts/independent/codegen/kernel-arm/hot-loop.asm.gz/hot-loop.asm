      d4: 8b0c000f     	add	x15, x0, x12
      d8: ad7f71db     	ldp	q27, q28, [x14, #-0x20]
      dc: bd4001fa     	ldr	s26, [x15]
      e0: bd6001e9     	ldr	s9, [x15, #0x2000]
      e4: 9100118c     	add	x12, x12, #0x4
      e8: acc879dd     	ldp	q29, q30, [x14], #0x100
      ec: 4f9a937f     	fmul	v31.4s, v27.4s, v26.s[0]
      f0: 4f9a9388     	fmul	v8.4s, v28.4s, v26.s[0]
      f4: bc6a69ed     	ldr	s13, [x15, x10]
      f8: 4f89936b     	fmul	v11.4s, v27.4s, v9.s[0]
      fc: 4f89938c     	fmul	v12.4s, v28.4s, v9.s[0]
     100: f140099f     	cmp	x12, #0x2, lsl #12      // =0x2000
     104: 4f9a93aa     	fmul	v10.4s, v29.4s, v26.s[0]
     108: 4f9a93da     	fmul	v26.4s, v30.4s, v26.s[0]
     10c: 4f8993ae     	fmul	v14.4s, v29.4s, v9.s[0]
     110: 4f8993c9     	fmul	v9.4s, v30.4s, v9.s[0]
     114: 4e3fd442     	fadd	v2.4s, v2.4s, v31.4s
     118: bc6b69ff     	ldr	s31, [x15, x11]
     11c: 4e28d463     	fadd	v3.4s, v3.4s, v8.4s
     120: 4f8d9368     	fmul	v8.4s, v27.4s, v13.s[0]
     124: 4e2bd4c6     	fadd	v6.4s, v6.4s, v11.4s
     128: 4e2cd4e7     	fadd	v7.4s, v7.4s, v12.4s
     12c: 4e2ad484     	fadd	v4.4s, v4.4s, v10.4s
     130: 4f8d938a     	fmul	v10.4s, v28.4s, v13.s[0]
     134: 4e3ad4a5     	fadd	v5.4s, v5.4s, v26.4s
     138: 4f8d93ba     	fmul	v26.4s, v29.4s, v13.s[0]
     13c: 4f8d93cd     	fmul	v13.4s, v30.4s, v13.s[0]
     140: 4f9f937b     	fmul	v27.4s, v27.4s, v31.s[0]
     144: 4f9f939c     	fmul	v28.4s, v28.4s, v31.s[0]
     148: 4f9f93bd     	fmul	v29.4s, v29.4s, v31.s[0]
     14c: 4f9f93de     	fmul	v30.4s, v30.4s, v31.s[0]
     150: 4e2ed610     	fadd	v16.4s, v16.4s, v14.4s
     154: 4e29d631     	fadd	v17.4s, v17.4s, v9.4s
     158: 4e28d652     	fadd	v18.4s, v18.4s, v8.4s
     15c: 4e2ad673     	fadd	v19.4s, v19.4s, v10.4s
     160: 4e3ad694     	fadd	v20.4s, v20.4s, v26.4s
     164: 4e2dd6b5     	fadd	v21.4s, v21.4s, v13.4s
     168: 4e3bd6d6     	fadd	v22.4s, v22.4s, v27.4s
     16c: 4e3cd6f7     	fadd	v23.4s, v23.4s, v28.4s
     170: 4e3dd718     	fadd	v24.4s, v24.4s, v29.4s
     174: 4e3ed739     	fadd	v25.4s, v25.4s, v30.4s
     178: 54fffae1     	b.ne	0xd4 <causallm::lfm2RouterArmBlock(float const*, float const*, float*)+0xd4>

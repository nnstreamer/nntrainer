; ModuleID = '/tmp/nntr-lfm2-router-arm-20261017/candidate/Applications/CausalLM/models/lfm2_moe/lfm2_router_arm.cpp'
source_filename = "/tmp/nntr-lfm2-router-arm-20261017/candidate/Applications/CausalLM/models/lfm2_moe/lfm2_router_arm.cpp"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-android29"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define noundef i1 @_ZN8causallm28lfm2RouterArmWeightSupportedEPKf(ptr noundef readonly captures(none) %0) local_unnamed_addr #0 !dbg !9 {
  br label %2, !dbg !13

2:                                                ; preds = %2, %1
  %3 = phi i64 [ 0, %1 ], [ %11, %2 ]
  %4 = phi <4 x i32> [ zeroinitializer, %1 ], [ %10, %2 ]
  %5 = getelementptr inbounds nuw float, ptr %0, i64 %3, !dbg !16
  %6 = load <4 x i32>, ptr %5, align 4, !dbg !16
  %7 = and <4 x i32> %6, splat (i32 2147483647), !dbg !17
  %8 = add nsw <4 x i32> %7, splat (i32 -1), !dbg !18
  %9 = icmp ult <4 x i32> %8, splat (i32 8388607), !dbg !19
  %10 = select <4 x i1> %9, <4 x i32> splat (i32 -1), <4 x i32> %4, !dbg !20
  %11 = add nuw nsw i64 %3, 4, !dbg !21
  %12 = icmp samesign ult i64 %3, 131068, !dbg !22
  br i1 %12, label %2, label %13, !dbg !13, !llvm.loop !23

13:                                               ; preds = %2
  %14 = tail call noundef i32 @llvm.aarch64.neon.umaxv.i32.v4i32(<4 x i32> %10), !dbg !26
  %15 = icmp eq i32 %14, 0, !dbg !27
  ret i1 %15, !dbg !28
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.neon.umaxv.i32.v4i32(<4 x i32>) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind memory(argmem: readwrite) uwtable
define noundef i1 @_ZN8causallm18lfm2RouterArmBlockEPKfS1_Pf(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1, ptr noundef writeonly captures(none) %2) local_unnamed_addr #2 !dbg !29 {
  br label %4, !dbg !30

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %13, %4 ]
  %6 = phi <4 x i32> [ zeroinitializer, %3 ], [ %12, %4 ]
  %7 = getelementptr inbounds nuw float, ptr %0, i64 %5, !dbg !32
  %8 = load <4 x i32>, ptr %7, align 4, !dbg !32
  %9 = and <4 x i32> %8, splat (i32 2147483647), !dbg !33
  %10 = add nsw <4 x i32> %9, splat (i32 -1), !dbg !34
  %11 = icmp ult <4 x i32> %10, splat (i32 8388607), !dbg !35
  %12 = select <4 x i1> %11, <4 x i32> splat (i32 -1), <4 x i32> %6, !dbg !36
  %13 = add nuw nsw i64 %5, 4, !dbg !37
  %14 = icmp samesign ult i64 %5, 8188, !dbg !38
  br i1 %14, label %4, label %15, !dbg !30, !llvm.loop !39

15:                                               ; preds = %4
  %16 = tail call noundef i32 @llvm.aarch64.neon.umaxv.i32.v4i32(<4 x i32> %12), !dbg !41
  %17 = icmp eq i32 %16, 0, !dbg !42
  br i1 %17, label %18, label %177, !dbg !43

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %0, i64 8192
  %20 = getelementptr inbounds nuw i8, ptr %0, i64 16384
  %21 = getelementptr inbounds nuw i8, ptr %0, i64 24576
  br label %25, !dbg !44

22:                                               ; preds = %30
  %23 = tail call noundef i32 @llvm.aarch64.neon.umaxv.i32.v4i32(<4 x i32> %97), !dbg !45
  %24 = icmp eq i32 %23, 0, !dbg !46
  br label %177

25:                                               ; preds = %18, %30
  %26 = phi i64 [ 0, %18 ], [ %98, %30 ]
  %27 = phi <4 x i32> [ zeroinitializer, %18 ], [ %97, %30 ]
  %28 = shl nuw nsw i64 %26, 6, !dbg !47
  %29 = getelementptr nuw i8, ptr %1, i64 %28
  br label %100, !dbg !48

30:                                               ; preds = %100
  %31 = getelementptr nuw i8, ptr %2, i64 %28
  store <4 x float> %132, ptr %31, align 4, !dbg !49
  %32 = getelementptr inbounds nuw i8, ptr %31, i64 16, !dbg !49
  store <4 x float> %134, ptr %32, align 4, !dbg !49
  %33 = getelementptr inbounds nuw i8, ptr %31, i64 32, !dbg !49
  store <4 x float> %136, ptr %33, align 4, !dbg !49
  %34 = getelementptr inbounds nuw i8, ptr %31, i64 48, !dbg !49
  store <4 x float> %138, ptr %34, align 4, !dbg !49
  %35 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %132), !dbg !50
  %36 = fcmp ueq <4 x float> %35, splat (float 0x7FF0000000000000), !dbg !50
  %37 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %134), !dbg !50
  %38 = fcmp ueq <4 x float> %37, splat (float 0x7FF0000000000000), !dbg !50
  %39 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %136), !dbg !50
  %40 = fcmp ueq <4 x float> %39, splat (float 0x7FF0000000000000), !dbg !50
  %41 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %138), !dbg !50
  %42 = fcmp ueq <4 x float> %41, splat (float 0x7FF0000000000000), !dbg !50
  %43 = getelementptr nuw i8, ptr %2, i64 %28
  %44 = getelementptr nuw i8, ptr %43, i64 256
  store <4 x float> %144, ptr %44, align 4, !dbg !49
  %45 = getelementptr nuw i8, ptr %43, i64 272, !dbg !49
  store <4 x float> %146, ptr %45, align 4, !dbg !49
  %46 = getelementptr nuw i8, ptr %43, i64 288, !dbg !49
  store <4 x float> %148, ptr %46, align 4, !dbg !49
  %47 = getelementptr nuw i8, ptr %43, i64 304, !dbg !49
  store <4 x float> %150, ptr %47, align 4, !dbg !49
  %48 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %144), !dbg !50
  %49 = fcmp ueq <4 x float> %48, splat (float 0x7FF0000000000000), !dbg !50
  %50 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %146), !dbg !50
  %51 = fcmp ueq <4 x float> %50, splat (float 0x7FF0000000000000), !dbg !50
  %52 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %148), !dbg !50
  %53 = fcmp ueq <4 x float> %52, splat (float 0x7FF0000000000000), !dbg !50
  %54 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %150), !dbg !50
  %55 = fcmp ueq <4 x float> %54, splat (float 0x7FF0000000000000), !dbg !50
  %56 = getelementptr nuw i8, ptr %2, i64 %28
  %57 = getelementptr nuw i8, ptr %56, i64 512
  store <4 x float> %156, ptr %57, align 4, !dbg !49
  %58 = getelementptr nuw i8, ptr %56, i64 528, !dbg !49
  store <4 x float> %158, ptr %58, align 4, !dbg !49
  %59 = getelementptr nuw i8, ptr %56, i64 544, !dbg !49
  store <4 x float> %160, ptr %59, align 4, !dbg !49
  %60 = getelementptr nuw i8, ptr %56, i64 560, !dbg !49
  store <4 x float> %162, ptr %60, align 4, !dbg !49
  %61 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %156), !dbg !50
  %62 = fcmp ueq <4 x float> %61, splat (float 0x7FF0000000000000), !dbg !50
  %63 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %158), !dbg !50
  %64 = fcmp ueq <4 x float> %63, splat (float 0x7FF0000000000000), !dbg !50
  %65 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %160), !dbg !50
  %66 = fcmp ueq <4 x float> %65, splat (float 0x7FF0000000000000), !dbg !50
  %67 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %162), !dbg !50
  %68 = fcmp ueq <4 x float> %67, splat (float 0x7FF0000000000000), !dbg !50
  %69 = getelementptr nuw i8, ptr %2, i64 %28
  %70 = getelementptr nuw i8, ptr %69, i64 768
  store <4 x float> %168, ptr %70, align 4, !dbg !49
  %71 = getelementptr nuw i8, ptr %69, i64 784, !dbg !49
  store <4 x float> %170, ptr %71, align 4, !dbg !49
  %72 = getelementptr nuw i8, ptr %69, i64 800, !dbg !49
  store <4 x float> %172, ptr %72, align 4, !dbg !49
  %73 = getelementptr nuw i8, ptr %69, i64 816, !dbg !49
  store <4 x float> %174, ptr %73, align 4, !dbg !49
  %74 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %168), !dbg !50
  %75 = fcmp ueq <4 x float> %74, splat (float 0x7FF0000000000000), !dbg !50
  %76 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %170), !dbg !50
  %77 = fcmp ueq <4 x float> %76, splat (float 0x7FF0000000000000), !dbg !50
  %78 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %172), !dbg !50
  %79 = fcmp ueq <4 x float> %78, splat (float 0x7FF0000000000000), !dbg !50
  %80 = tail call <4 x float> @llvm.fabs.v4f32(<4 x float> %174), !dbg !50
  %81 = fcmp ueq <4 x float> %80, splat (float 0x7FF0000000000000), !dbg !50
  %82 = select <4 x i1> %81, <4 x i1> splat (i1 true), <4 x i1> %79, !dbg !51
  %83 = select <4 x i1> %82, <4 x i1> splat (i1 true), <4 x i1> %77, !dbg !51
  %84 = select <4 x i1> %83, <4 x i1> splat (i1 true), <4 x i1> %75, !dbg !51
  %85 = select <4 x i1> %84, <4 x i1> splat (i1 true), <4 x i1> %68, !dbg !51
  %86 = select <4 x i1> %85, <4 x i1> splat (i1 true), <4 x i1> %66, !dbg !51
  %87 = select <4 x i1> %86, <4 x i1> splat (i1 true), <4 x i1> %64, !dbg !51
  %88 = select <4 x i1> %87, <4 x i1> splat (i1 true), <4 x i1> %62, !dbg !51
  %89 = select <4 x i1> %88, <4 x i1> splat (i1 true), <4 x i1> %55, !dbg !51
  %90 = select <4 x i1> %89, <4 x i1> splat (i1 true), <4 x i1> %53, !dbg !51
  %91 = select <4 x i1> %90, <4 x i1> splat (i1 true), <4 x i1> %51, !dbg !51
  %92 = select <4 x i1> %91, <4 x i1> splat (i1 true), <4 x i1> %49, !dbg !51
  %93 = select <4 x i1> %92, <4 x i1> splat (i1 true), <4 x i1> %42, !dbg !51
  %94 = select <4 x i1> %93, <4 x i1> splat (i1 true), <4 x i1> %40, !dbg !51
  %95 = select <4 x i1> %94, <4 x i1> splat (i1 true), <4 x i1> %38, !dbg !51
  %96 = select <4 x i1> %95, <4 x i1> splat (i1 true), <4 x i1> %36, !dbg !51
  %97 = select <4 x i1> %96, <4 x i32> splat (i32 -1), <4 x i32> %27, !dbg !51
  %98 = add nuw nsw i64 %26, 1, !dbg !44
  %99 = icmp eq i64 %98, 4, !dbg !52
  br i1 %99, label %22, label %25, !dbg !44, !llvm.loop !53

100:                                              ; preds = %25, %100
  %101 = phi <4 x float> [ zeroinitializer, %25 ], [ %162, %100 ], !dbg !55
  %102 = phi <4 x float> [ zeroinitializer, %25 ], [ %160, %100 ], !dbg !55
  %103 = phi <4 x float> [ zeroinitializer, %25 ], [ %158, %100 ], !dbg !55
  %104 = phi <4 x float> [ zeroinitializer, %25 ], [ %156, %100 ], !dbg !55
  %105 = phi <4 x float> [ zeroinitializer, %25 ], [ %150, %100 ], !dbg !55
  %106 = phi <4 x float> [ zeroinitializer, %25 ], [ %148, %100 ], !dbg !55
  %107 = phi <4 x float> [ zeroinitializer, %25 ], [ %146, %100 ], !dbg !55
  %108 = phi <4 x float> [ zeroinitializer, %25 ], [ %144, %100 ], !dbg !55
  %109 = phi <4 x float> [ zeroinitializer, %25 ], [ %138, %100 ], !dbg !55
  %110 = phi <4 x float> [ zeroinitializer, %25 ], [ %136, %100 ], !dbg !55
  %111 = phi <4 x float> [ zeroinitializer, %25 ], [ %134, %100 ], !dbg !55
  %112 = phi <4 x float> [ zeroinitializer, %25 ], [ %132, %100 ], !dbg !55
  %113 = phi <4 x float> [ zeroinitializer, %25 ], [ %168, %100 ], !dbg !55
  %114 = phi <4 x float> [ zeroinitializer, %25 ], [ %170, %100 ], !dbg !55
  %115 = phi <4 x float> [ zeroinitializer, %25 ], [ %172, %100 ], !dbg !55
  %116 = phi <4 x float> [ zeroinitializer, %25 ], [ %174, %100 ], !dbg !55
  %117 = phi i64 [ 0, %25 ], [ %175, %100 ]
  %118 = shl nuw nsw i64 %117, 8, !dbg !56
  %119 = getelementptr nuw i8, ptr %29, i64 %118, !dbg !56
  %120 = load <4 x float>, ptr %119, align 4, !dbg !57
  %121 = getelementptr inbounds nuw i8, ptr %119, i64 16, !dbg !57
  %122 = load <4 x float>, ptr %121, align 4, !dbg !57
  %123 = getelementptr inbounds nuw i8, ptr %119, i64 32, !dbg !57
  %124 = load <4 x float>, ptr %123, align 4, !dbg !57
  %125 = getelementptr inbounds nuw i8, ptr %119, i64 48, !dbg !57
  %126 = load <4 x float>, ptr %125, align 4, !dbg !57
  %127 = getelementptr inbounds nuw float, ptr %0, i64 %117, !dbg !58
  %128 = load float, ptr %127, align 4, !dbg !58, !tbaa !59
  %129 = insertelement <4 x float> poison, float %128, i64 0, !dbg !63
  %130 = shufflevector <4 x float> %129, <4 x float> poison, <4 x i32> zeroinitializer, !dbg !63
  %131 = fmul <4 x float> %130, %120, !dbg !64
  %132 = fadd <4 x float> %112, %131, !dbg !65
  %133 = fmul <4 x float> %130, %122, !dbg !64
  %134 = fadd <4 x float> %111, %133, !dbg !65
  %135 = fmul <4 x float> %130, %124, !dbg !64
  %136 = fadd <4 x float> %110, %135, !dbg !65
  %137 = fmul <4 x float> %130, %126, !dbg !64
  %138 = fadd <4 x float> %109, %137, !dbg !65
  %139 = getelementptr inbounds nuw float, ptr %19, i64 %117, !dbg !58
  %140 = load float, ptr %139, align 4, !dbg !58, !tbaa !59
  %141 = insertelement <4 x float> poison, float %140, i64 0, !dbg !63
  %142 = shufflevector <4 x float> %141, <4 x float> poison, <4 x i32> zeroinitializer, !dbg !63
  %143 = fmul <4 x float> %142, %120, !dbg !64
  %144 = fadd <4 x float> %108, %143, !dbg !65
  %145 = fmul <4 x float> %142, %122, !dbg !64
  %146 = fadd <4 x float> %107, %145, !dbg !65
  %147 = fmul <4 x float> %142, %124, !dbg !64
  %148 = fadd <4 x float> %106, %147, !dbg !65
  %149 = fmul <4 x float> %142, %126, !dbg !64
  %150 = fadd <4 x float> %105, %149, !dbg !65
  %151 = getelementptr inbounds nuw float, ptr %20, i64 %117, !dbg !58
  %152 = load float, ptr %151, align 4, !dbg !58, !tbaa !59
  %153 = insertelement <4 x float> poison, float %152, i64 0, !dbg !63
  %154 = shufflevector <4 x float> %153, <4 x float> poison, <4 x i32> zeroinitializer, !dbg !63
  %155 = fmul <4 x float> %154, %120, !dbg !64
  %156 = fadd <4 x float> %104, %155, !dbg !65
  %157 = fmul <4 x float> %154, %122, !dbg !64
  %158 = fadd <4 x float> %103, %157, !dbg !65
  %159 = fmul <4 x float> %154, %124, !dbg !64
  %160 = fadd <4 x float> %102, %159, !dbg !65
  %161 = fmul <4 x float> %154, %126, !dbg !64
  %162 = fadd <4 x float> %101, %161, !dbg !65
  %163 = getelementptr inbounds nuw float, ptr %21, i64 %117, !dbg !58
  %164 = load float, ptr %163, align 4, !dbg !58, !tbaa !59
  %165 = insertelement <4 x float> poison, float %164, i64 0, !dbg !63
  %166 = shufflevector <4 x float> %165, <4 x float> poison, <4 x i32> zeroinitializer, !dbg !63
  %167 = fmul <4 x float> %166, %120, !dbg !64
  %168 = fadd <4 x float> %113, %167, !dbg !65
  %169 = fmul <4 x float> %166, %122, !dbg !64
  %170 = fadd <4 x float> %114, %169, !dbg !65
  %171 = fmul <4 x float> %166, %124, !dbg !64
  %172 = fadd <4 x float> %115, %171, !dbg !65
  %173 = fmul <4 x float> %166, %126, !dbg !64
  %174 = fadd <4 x float> %116, %173, !dbg !65
  %175 = add nuw nsw i64 %117, 1, !dbg !66
  %176 = icmp eq i64 %175, 2048, !dbg !67
  br i1 %176, label %30, label %100, !dbg !48, !llvm.loop !68

177:                                              ; preds = %15, %22
  %178 = phi i1 [ %24, %22 ], [ false, %15 ], !dbg !55
  ret i1 %178, !dbg !70
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x float> @llvm.fabs.v4f32(<4 x float>) #3

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+crc,+dotprod,+fix-cortex-a53-835769,+fp-armv8,+fullfp16,+i8mm,+lse,+neon,+outline-atomics,+ras,+rdm,+v8.1a,+v8.2a,+v8a" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(none) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+crc,+dotprod,+fix-cortex-a53-835769,+fp-armv8,+fullfp16,+i8mm,+lse,+neon,+outline-atomics,+ras,+rdm,+v8.1a,+v8.2a,+v8a" }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2, !3, !4, !5, !6, !7}
!llvm.ident = !{!8}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_14, file: !1, producer: "Android (16134705, +pgo, +bolt, +lto, +mlgo, based on r574158c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 9f872551d3c681d06fd303b36f16ed5c274735eb)", isOptimized: true, runtimeVersion: 0, emissionKind: NoDebug, splitDebugInlining: false, nameTableKind: None)
!1 = !DIFile(filename: "/tmp/nntr-lfm2-router-arm-20261017/candidate/Applications/CausalLM/models/lfm2_moe/lfm2_router_arm.cpp", directory: "/home/jungone-lee/workspace/nntrainer")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = !{i32 1, !"wchar_size", i32 4}
!4 = !{i32 7, !"openmp", i32 51}
!5 = !{i32 8, !"PIC Level", i32 2}
!6 = !{i32 7, !"uwtable", i32 2}
!7 = !{i32 7, !"frame-pointer", i32 1}
!8 = !{!"Android (16134705, +pgo, +bolt, +lto, +mlgo, based on r574158c) clang version 21.0.0 (https://android.googlesource.com/toolchain/llvm-project 9f872551d3c681d06fd303b36f16ed5c274735eb)"}
!9 = distinct !DISubprogram(name: "lfm2RouterArmWeightSupported", scope: !10, file: !10, line: 41, type: !11, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0)
!10 = !DIFile(filename: "/tmp/nntr-lfm2-router-arm-20261017/candidate/Applications/CausalLM/models/lfm2_moe/lfm2_router_arm.cpp", directory: "")
!11 = !DISubroutineType(types: !12)
!12 = !{}
!13 = !DILocation(line: 32, column: 3, scope: !14, inlinedAt: !15)
!14 = distinct !DISubprogram(name: "hasSubnormal", scope: !10, file: !10, line: 27, type: !11, scopeLine: 27, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !0)
!15 = distinct !DILocation(line: 42, column: 11, scope: !9)
!16 = !DILocation(line: 34, column: 39, scope: !14, inlinedAt: !15)
!17 = !DILocation(line: 34, column: 7, scope: !14, inlinedAt: !15)
!18 = !DILocation(line: 35, column: 40, scope: !14, inlinedAt: !15)
!19 = !DILocation(line: 35, column: 30, scope: !14, inlinedAt: !15)
!20 = !DILocation(line: 35, column: 13, scope: !14, inlinedAt: !15)
!21 = !DILocation(line: 32, column: 41, scope: !14, inlinedAt: !15)
!22 = !DILocation(line: 32, column: 30, scope: !14, inlinedAt: !15)
!23 = distinct !{!23, !13, !24, !25}
!24 = !DILocation(line: 36, column: 3, scope: !14, inlinedAt: !15)
!25 = !{!"llvm.loop.mustprogress"}
!26 = !DILocation(line: 37, column: 10, scope: !14, inlinedAt: !15)
!27 = !DILocation(line: 37, column: 28, scope: !14, inlinedAt: !15)
!28 = !DILocation(line: 42, column: 3, scope: !9)
!29 = distinct !DISubprogram(name: "lfm2RouterArmBlock", scope: !10, file: !10, line: 50, type: !11, scopeLine: 50, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !0)
!30 = !DILocation(line: 32, column: 3, scope: !14, inlinedAt: !31)
!31 = distinct !DILocation(line: 52, column: 7, scope: !29)
!32 = !DILocation(line: 34, column: 39, scope: !14, inlinedAt: !31)
!33 = !DILocation(line: 34, column: 7, scope: !14, inlinedAt: !31)
!34 = !DILocation(line: 35, column: 40, scope: !14, inlinedAt: !31)
!35 = !DILocation(line: 35, column: 30, scope: !14, inlinedAt: !31)
!36 = !DILocation(line: 35, column: 13, scope: !14, inlinedAt: !31)
!37 = !DILocation(line: 32, column: 41, scope: !14, inlinedAt: !31)
!38 = !DILocation(line: 32, column: 30, scope: !14, inlinedAt: !31)
!39 = distinct !{!39, !30, !40, !25}
!40 = !DILocation(line: 36, column: 3, scope: !14, inlinedAt: !31)
!41 = !DILocation(line: 37, column: 10, scope: !14, inlinedAt: !31)
!42 = !DILocation(line: 37, column: 28, scope: !14, inlinedAt: !31)
!43 = !DILocation(line: 52, column: 7, scope: !29)
!44 = !DILocation(line: 56, column: 3, scope: !29)
!45 = !DILocation(line: 87, column: 10, scope: !29)
!46 = !DILocation(line: 87, column: 32, scope: !29)
!47 = !DILocation(line: 57, column: 5, scope: !29)
!48 = !DILocation(line: 63, column: 5, scope: !29)
!49 = !DILocation(line: 84, column: 7, scope: !29)
!50 = !DILocation(line: 82, column: 9, scope: !29)
!51 = !DILocation(line: 80, column: 19, scope: !29)
!52 = !DILocation(line: 56, column: 34, scope: !29)
!53 = distinct !{!53, !44, !54, !25}
!54 = !DILocation(line: 86, column: 3, scope: !29)
!55 = !DILocation(line: 0, scope: !29)
!56 = !DILocation(line: 64, column: 7, scope: !29)
!57 = !DILocation(line: 67, column: 19, scope: !29)
!58 = !DILocation(line: 70, column: 47, scope: !29)
!59 = !{!60, !60, i64 0}
!60 = !{!"float", !61, i64 0}
!61 = !{!"omnipotent char", !62, i64 0}
!62 = !{!"Simple C++ TBAA"}
!63 = !DILocation(line: 70, column: 35, scope: !29)
!64 = !DILocation(line: 73, column: 44, scope: !29)
!65 = !DILocation(line: 73, column: 23, scope: !29)
!66 = !DILocation(line: 63, column: 42, scope: !29)
!67 = !DILocation(line: 63, column: 32, scope: !29)
!68 = distinct !{!68, !48, !69, !25}
!69 = !DILocation(line: 75, column: 5, scope: !29)
!70 = !DILocation(line: 88, column: 1, scope: !29)

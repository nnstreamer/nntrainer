
/tmp/nntr-lfm2-router-arm-review-20261017/codegen/kernel-arm/output.o:	file format elf64-littleaarch64

Disassembly of section .text._ZN8causallm28lfm2RouterArmWeightSupportedEPKf:

0000000000000000 <causallm::lfm2RouterArmWeightSupported(float const*)>:
       0: 6f00e400     	movi	v0.2d, #0000000000000000
       4: 6f07e7e1     	movi	v1.2d, #0xffffffffffffffff
       8: 92800068     	mov	x8, #-0x4               // =-4
       c: 4f03d7e2     	movi	v2.4s, #0x7f, msl #16
      10: 321e3be9     	mov	w9, #0x1fffc            // =131068
      14: 3cc10403     	ldr	q3, [x0], #0x10
      18: 91001108     	add	x8, x8, #0x4
      1c: eb09011f     	cmp	x8, x9
      20: 6f047403     	bic	v3.4s, #0x80, lsl #24
      24: 4ea18463     	add	v3.4s, v3.4s, v1.4s
      28: 6ea33443     	cmhi	v3.4s, v2.4s, v3.4s
      2c: 4ea31c00     	orr	v0.16b, v0.16b, v3.16b
      30: 54ffff23     	b.lo	0x14 <causallm::lfm2RouterArmWeightSupported(float const*)+0x14>
      34: 6eb0a800     	umaxv	s0, v0.4s
      38: 1e260008     	fmov	w8, s0
      3c: 7100011f     	cmp	w8, #0x0
      40: 1a9f17e0     	cset	w0, eq
      44: d65f03c0     	ret

Disassembly of section .text._ZN8causallm18lfm2RouterArmBlockEPKfS1_Pf:

0000000000000000 <causallm::lfm2RouterArmBlock(float const*, float const*, float*)>:
       0: fc1c0fee     	str	d14, [sp, #-0x40]!
       4: 6d0133ed     	stp	d13, d12, [sp, #0x10]
       8: 6d022beb     	stp	d11, d10, [sp, #0x20]
       c: 6d0323e9     	stp	d9, d8, [sp, #0x30]
      10: 6f00e400     	movi	v0.2d, #0000000000000000
      14: 6f07e7e1     	movi	v1.2d, #0xffffffffffffffff
      18: 92800068     	mov	x8, #-0x4               // =-4
      1c: 4f03d7e2     	movi	v2.4s, #0x7f, msl #16
      20: aa0003e9     	mov	x9, x0
      24: 3cc10523     	ldr	q3, [x9], #0x10
      28: 91001108     	add	x8, x8, #0x4
      2c: d342fd0a     	lsr	x10, x8, #2
      30: 6f047403     	bic	v3.4s, #0x80, lsl #24
      34: f11ffd5f     	cmp	x10, #0x7ff
      38: 4ea18463     	add	v3.4s, v3.4s, v1.4s
      3c: 6ea33443     	cmhi	v3.4s, v2.4s, v3.4s
      40: 4ea31c00     	orr	v0.16b, v0.16b, v3.16b
      44: 54ffff03     	b.lo	0x24 <causallm::lfm2RouterArmBlock(float const*, float const*, float*)+0x24>
      48: 6eb0a800     	umaxv	s0, v0.4s
      4c: 1e260008     	fmov	w8, s0
      50: 340000e8     	cbz	w8, 0x6c <causallm::lfm2RouterArmBlock(float const*, float const*, float*)+0x6c>
      54: 2a1f03e0     	mov	w0, wzr
      58: 6d4323e9     	ldp	d9, d8, [sp, #0x30]
      5c: 6d422beb     	ldp	d11, d10, [sp, #0x20]
      60: 6d4133ed     	ldp	d13, d12, [sp, #0x10]
      64: fc4407ee     	ldr	d14, [sp], #0x40
      68: d65f03c0     	ret
      6c: 6f03d7e1     	mvni	v1.4s, #0x7f, msl #16
      70: 6f00e400     	movi	v0.2d, #0000000000000000
      74: aa1f03e8     	mov	x8, xzr
      78: 91008029     	add	x9, x1, #0x20
      7c: 5288000a     	mov	w10, #0x4000            // =16384
      80: 528c000b     	mov	w11, #0x6000            // =24576
      84: 6ea0f821     	fneg	v1.4s, v1.4s
      88: 6f00e415     	movi	v21.2d, #0000000000000000
      8c: 6f00e414     	movi	v20.2d, #0000000000000000
      90: d37ae50d     	lsl	x13, x8, #6
      94: 6f00e413     	movi	v19.2d, #0000000000000000
      98: 6f00e412     	movi	v18.2d, #0000000000000000
      9c: aa1f03ec     	mov	x12, xzr
      a0: 6f00e411     	movi	v17.2d, #0000000000000000
      a4: 6f00e410     	movi	v16.2d, #0000000000000000
      a8: aa0903ee     	mov	x14, x9
      ac: 6f00e407     	movi	v7.2d, #0000000000000000
      b0: 6f00e406     	movi	v6.2d, #0000000000000000
      b4: 6f00e405     	movi	v5.2d, #0000000000000000
      b8: 6f00e404     	movi	v4.2d, #0000000000000000
      bc: 6f00e403     	movi	v3.2d, #0000000000000000
      c0: 6f00e402     	movi	v2.2d, #0000000000000000
      c4: 6f00e416     	movi	v22.2d, #0000000000000000
      c8: 6f00e417     	movi	v23.2d, #0000000000000000
      cc: 6f00e418     	movi	v24.2d, #0000000000000000
      d0: 6f00e419     	movi	v25.2d, #0000000000000000
      d4: 8b0c000f     	add	x15, x0, x12
      d8: ad7f71db     	ldp	q27, q28, [x14, #-0x20]
      dc: bd4001fa     	ldr	s26, [x15]
      e0: bd6001e9     	ldr	s9, [x15, #0x2000]
      e4: 9100118c     	add	x12, x12, #0x4
      e8: acc879dd     	ldp	q29, q30, [x14], #0x100
      ec: 4f9a937f     	fmul	v31.4s, v27.4s, v26.s[0]
      f0: 4f9a9388     	fmul	v8.4s, v28.4s, v26.s[0]
      f4: bc6a69ed     	ldr	s13, [x15, x10]
      f8: 4f89936b     	fmul	v11.4s, v27.4s, v9.s[0]
      fc: 4f89938c     	fmul	v12.4s, v28.4s, v9.s[0]
     100: f140099f     	cmp	x12, #0x2, lsl #12      // =0x2000
     104: 4f9a93aa     	fmul	v10.4s, v29.4s, v26.s[0]
     108: 4f9a93da     	fmul	v26.4s, v30.4s, v26.s[0]
     10c: 4f8993ae     	fmul	v14.4s, v29.4s, v9.s[0]
     110: 4f8993c9     	fmul	v9.4s, v30.4s, v9.s[0]
     114: 4e3fd442     	fadd	v2.4s, v2.4s, v31.4s
     118: bc6b69ff     	ldr	s31, [x15, x11]
     11c: 4e28d463     	fadd	v3.4s, v3.4s, v8.4s
     120: 4f8d9368     	fmul	v8.4s, v27.4s, v13.s[0]
     124: 4e2bd4c6     	fadd	v6.4s, v6.4s, v11.4s
     128: 4e2cd4e7     	fadd	v7.4s, v7.4s, v12.4s
     12c: 4e2ad484     	fadd	v4.4s, v4.4s, v10.4s
     130: 4f8d938a     	fmul	v10.4s, v28.4s, v13.s[0]
     134: 4e3ad4a5     	fadd	v5.4s, v5.4s, v26.4s
     138: 4f8d93ba     	fmul	v26.4s, v29.4s, v13.s[0]
     13c: 4f8d93cd     	fmul	v13.4s, v30.4s, v13.s[0]
     140: 4f9f937b     	fmul	v27.4s, v27.4s, v31.s[0]
     144: 4f9f939c     	fmul	v28.4s, v28.4s, v31.s[0]
     148: 4f9f93bd     	fmul	v29.4s, v29.4s, v31.s[0]
     14c: 4f9f93de     	fmul	v30.4s, v30.4s, v31.s[0]
     150: 4e2ed610     	fadd	v16.4s, v16.4s, v14.4s
     154: 4e29d631     	fadd	v17.4s, v17.4s, v9.4s
     158: 4e28d652     	fadd	v18.4s, v18.4s, v8.4s
     15c: 4e2ad673     	fadd	v19.4s, v19.4s, v10.4s
     160: 4e3ad694     	fadd	v20.4s, v20.4s, v26.4s
     164: 4e2dd6b5     	fadd	v21.4s, v21.4s, v13.4s
     168: 4e3bd6d6     	fadd	v22.4s, v22.4s, v27.4s
     16c: 4e3cd6f7     	fadd	v23.4s, v23.4s, v28.4s
     170: 4e3dd718     	fadd	v24.4s, v24.4s, v29.4s
     174: 4e3ed739     	fadd	v25.4s, v25.4s, v30.4s
     178: 54fffae1     	b.ne	0xd4 <causallm::lfm2RouterArmBlock(float const*, float const*, float*)+0xd4>
     17c: 8b0d004c     	add	x12, x2, x13
     180: 91000508     	add	x8, x8, #0x1
     184: 91010129     	add	x9, x9, #0x40
     188: ad000d82     	stp	q2, q3, [x12]
     18c: 6f047403     	bic	v3.4s, #0x80, lsl #24
     190: 6f047402     	bic	v2.4s, #0x80, lsl #24
     194: ad011584     	stp	q4, q5, [x12, #0x20]
     198: 6f047405     	bic	v5.4s, #0x80, lsl #24
     19c: 6f047404     	bic	v4.4s, #0x80, lsl #24
     1a0: ad081d86     	stp	q6, q7, [x12, #0x100]
     1a4: 6f047407     	bic	v7.4s, #0x80, lsl #24
     1a8: 6f047406     	bic	v6.4s, #0x80, lsl #24
     1ac: ad094590     	stp	q16, q17, [x12, #0x120]
     1b0: 6f047411     	bic	v17.4s, #0x80, lsl #24
     1b4: 6f047410     	bic	v16.4s, #0x80, lsl #24
     1b8: ad104d92     	stp	q18, q19, [x12, #0x200]
     1bc: 6f047413     	bic	v19.4s, #0x80, lsl #24
     1c0: 6f047412     	bic	v18.4s, #0x80, lsl #24
     1c4: ad115594     	stp	q20, q21, [x12, #0x220]
     1c8: 6f047415     	bic	v21.4s, #0x80, lsl #24
     1cc: 6f047414     	bic	v20.4s, #0x80, lsl #24
     1d0: ad185d96     	stp	q22, q23, [x12, #0x300]
     1d4: 6f047417     	bic	v23.4s, #0x80, lsl #24
     1d8: 6f047416     	bic	v22.4s, #0x80, lsl #24
     1dc: ad196598     	stp	q24, q25, [x12, #0x320]
     1e0: 6f047418     	bic	v24.4s, #0x80, lsl #24
     1e4: 6f047419     	bic	v25.4s, #0x80, lsl #24
     1e8: f100111f     	cmp	x8, #0x4
     1ec: 4eb86738     	smax	v24.4s, v25.4s, v24.4s
     1f0: 4eb76717     	smax	v23.4s, v24.4s, v23.4s
     1f4: 4eb666f6     	smax	v22.4s, v23.4s, v22.4s
     1f8: 4eb566d5     	smax	v21.4s, v22.4s, v21.4s
     1fc: 4eb466b4     	smax	v20.4s, v21.4s, v20.4s
     200: 4eb36693     	smax	v19.4s, v20.4s, v19.4s
     204: 4eb26672     	smax	v18.4s, v19.4s, v18.4s
     208: 4eb16651     	smax	v17.4s, v18.4s, v17.4s
     20c: 4eb06630     	smax	v16.4s, v17.4s, v16.4s
     210: 4ea76607     	smax	v7.4s, v16.4s, v7.4s
     214: 4ea664e6     	smax	v6.4s, v7.4s, v6.4s
     218: 4ea564c5     	smax	v5.4s, v6.4s, v5.4s
     21c: 4ea464a4     	smax	v4.4s, v5.4s, v4.4s
     220: 4ea36483     	smax	v3.4s, v4.4s, v3.4s
     224: 4ea26462     	smax	v2.4s, v3.4s, v2.4s
     228: 4ea13c42     	cmge	v2.4s, v2.4s, v1.4s
     22c: 4ea21c00     	orr	v0.16b, v0.16b, v2.16b
     230: 54fff2c1     	b.ne	0x88 <causallm::lfm2RouterArmBlock(float const*, float const*, float*)+0x88>
     234: 6eb0a800     	umaxv	s0, v0.4s
     238: 1e260008     	fmov	w8, s0
     23c: 7100011f     	cmp	w8, #0x0
     240: 1a9f17e0     	cset	w0, eq
     244: 6d4323e9     	ldp	d9, d8, [sp, #0x30]
     248: 6d422beb     	ldp	d11, d10, [sp, #0x20]
     24c: 6d4133ed     	ldp	d13, d12, [sp, #0x10]
     250: fc4407ee     	ldr	d14, [sp], #0x40
     254: d65f03c0     	ret

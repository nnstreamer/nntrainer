/**
 * Copyright (C) 2025 Samsung Electronics Co., Ltd. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *   http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 *
 * @file	main.cpp
 * @date	23 July 2025
 * @brief	This is a main file for CausalLM application
 * @see		https://github.com/nnstreamer/
 * @author	Eunju Yang <ej.yang@samsung.com>
 * @bug		No known bugs except for NYI items
 *
 */
#include <algorithm>
#include <fstream>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

#include "json.hpp"
#include <app_context.h>
#include <factory.h>

#include "causal_lm.h"
#include "chat_template.h"
#include "model_registry.h"
#include <models/gemma3/function.h>
#if !defined(_WIN32)
#include <sys/resource.h>
#endif

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <thread>

using json = nlohmann::json;

std::atomic<size_t> peak_rss_kb{0};
std::atomic<bool> tracking_enabled{true};

namespace {

void resolveNntrConfigPath(json &nntr_cfg, const std::string &key,
                           const std::string &model_path) {
  if (!nntr_cfg.contains(key) || !nntr_cfg[key].is_string())
    return;

  std::filesystem::path path = nntr_cfg[key].get<std::string>();
  if (path.empty() || path.is_absolute())
    return;

  nntr_cfg[key] = (std::filesystem::path(model_path) / path).string();
}

} // namespace

/**
 * @brief Print the maximum resident set size for the current process.
 */
void printMemoryUsage() {
#if defined(_WIN32)
  std::cout << "Max Resident Set Size: unavailable on Windows" << std::endl;
#else
  struct rusage usage;
  getrusage(RUSAGE_SELF, &usage);
  std::cout << "Max Resident Set Size: " << usage.ru_maxrss << " KB"
            << std::endl;
#endif
}

/**
 * @brief Read the current process resident set size on Linux.
 */
size_t read_vm_rss_kb() {
#if defined(_WIN32)
  return 0;
#else
  std::ifstream status("/proc/self/status");
  std::string line;
  while (std::getline(status, line)) {
    if (line.find("VmRSS:") == 0) {
      size_t kb = 0;
      sscanf(line.c_str(), "VmRSS: %zu kB", &kb);
      return kb;
    }
  }
  return 0;
#endif
}

/**
 * @brief Read private resident memory from smaps_rollup on Linux.
 */
size_t read_private_rss_kb() {
#if defined(_WIN32)
  return 0;
#else
  std::ifstream smaps("/proc/self/smaps_rollup");
  std::string line;
  size_t total = 0;
  while (std::getline(smaps, line)) {
    if (line.find("Private_Clean:") == 0 || line.find("Private_Dirty:") == 0) {
      size_t kb;
      sscanf(line.c_str(), "%*s %zu", &kb);
      total += kb;
    }
  }
  return total;
#endif
}

/**
 * @brief Start a background sampler for peak private RSS.
 */
void start_peak_tracker() {
  std::thread([] {
    while (tracking_enabled.load()) {
      size_t current = read_private_rss_kb();
      size_t prev = peak_rss_kb.load();
      if (current > prev) {
        peak_rss_kb.store(current);
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
  }).detach();
}

/**
 * @brief Stop the memory sampler and print the observed peak.
 */
void stop_and_print_peak() {
  tracking_enabled.store(false);
  std::this_thread::sleep_for(std::chrono::milliseconds(20));
  std::cout << "Peak memory usage (VmRSS): " << peak_rss_kb.load() << " KB"
            << std::endl;
}

/**
 * @brief Resolve config architecture names to registered model factory names.
 */
std::string resolve_architecture(std::string model_type,
                                 const std::string &architecture) {
  std::transform(model_type.begin(), model_type.end(), model_type.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  if (model_type == "embedding") {
    if (architecture == "Qwen3ForCausalLM") {
      return "Qwen3Embedding";
    } else if (architecture == "Gemma3ForCausalLM" ||
               architecture == "Gemma3TextModel") {
      return "EmbeddingGemma";
    } else if (architecture == "Qwen2Model") {
      return "Qwen2Embedding";
    } else if (architecture == "BertForMaskedLM") {
      return "MultilingualTinyBert";
    } else if (architecture == "XLMRobertaForMaskedLM" ||
               architecture == "XLMRobertaModel") {
      return "XLMRobertaForMaskedLM";
    } else if (architecture == "TimmViT" ||
               architecture == "vit_base_patch16_siglip_224") {
      return "TimmViT";
    } else if (architecture == "deberta-v2" ||
               architecture == "DebertaV2Model" ||
               architecture == "DebertaV2ForMaskedLM") {
      return "DebertaV2";
    } else {
      throw std::invalid_argument(
        "Unsupported architecture for embedding model: " + architecture);
    }
  }

  if (architecture == "TimmViT" ||
      architecture == "vit_base_patch16_siglip_224") {
    return "TimmViT";
  }

  if (architecture == "Gemma4ForConditionalGeneration") {
    return "Gemma4ForCausalLM";
  }

  return architecture;
}

/**
 * @brief Entry point for loading, initializing, and running a CausalLM model.
 */
int main(int argc, char *argv[]) {

  auto start_time = std::chrono::high_resolution_clock::now();

#if defined(__ANDROID__)
  // OpenCL kernel binary cache. On Android the library resolves its cache path
  // against the working directory (there is no per-user cache directory to
  // put it under), so every new run directory recompiled every kernel: +1.6 s
  // init and +1.7 s TTFT on the first run in a fresh directory, measured on
  // an Adreno 840. Pin the cache to one directory next to this executable
  // unless the caller named one; NNTR_KERNEL_CACHE_DIR=off still disables
  // it. The binary key already folds in the source, the per-kernel build
  // options (every -D define included) and the device + driver, so one
  // directory shared by all runs cannot hand out a mismatched binary.
  if (std::getenv("NNTR_KERNEL_CACHE_DIR") == nullptr) {
    std::error_code ec;
    const std::filesystem::path exe =
      std::filesystem::read_symlink("/proc/self/exe", ec);
    if (!ec && exe.has_parent_path())
      setenv("NNTR_KERNEL_CACHE_DIR",
             (exe.parent_path() / "nntr_kernel_cache").string().c_str(), 0);
  }
#endif

  /* INITBISECT_MARKS: env-gated init-phase trace (NNTR_INIT_TRACE). */
  static const bool _itrace = std::getenv("NNTR_INIT_TRACE") != nullptr;
  auto _ilap = [&](const char *what) {
    if (!_itrace)
      return;
    std::fprintf(stderr, "[init-trace] %8.1f ms  rss=%zu kB  %s\n",
                 std::chrono::duration<double, std::milli>(
                   std::chrono::high_resolution_clock::now() - start_time)
                   .count(),
                 read_vm_rss_kb(), what);
    std::fflush(stderr);
  };

  /** Register all runnable causallm models to factory */
  causallm::registerAllModels();

  // Validate arguments
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " <model_path> [input_prompt]\n"
              << "  <model_path>   : Path to model directory\n"
              << "  [input_prompt] : Optional input text (uses sample_input or "
                 "chat_input if omitted)\n";
    return EXIT_FAILURE;
  }

  const std::string model_path = argv[1];
  std::string input_text;
  std::string system_head_prompt = "";
  std::string system_tail_prompt = "";

  std::cout << model_path << std::endl;

  try {
    // Load configuration files
    json cfg = causallm::LoadJsonFile(model_path + "/config.json");
    json generation_cfg = json::object();
    std::string generation_config_path = model_path + "/generation_config.json";
    if (std::filesystem::exists(generation_config_path)) {
      generation_cfg = causallm::LoadJsonFile(generation_config_path);
    }
    json nntr_cfg = causallm::LoadJsonFile(model_path + "/nntr_config.json");
    resolveNntrConfigPath(nntr_cfg, "tokenizer_file", model_path);
    resolveNntrConfigPath(nntr_cfg, "embedding_file_name", model_path);
    resolveNntrConfigPath(nntr_cfg, "ple_file_name", model_path);
    resolveNntrConfigPath(nntr_cfg, "model_file_name", model_path);
    resolveNntrConfigPath(nntr_cfg, "binary_config_path", model_path);
    resolveNntrConfigPath(nntr_cfg, "image_newline_path", model_path);
    resolveNntrConfigPath(nntr_cfg, "kv_quant_file", model_path);

    if (nntr_cfg.contains("system_prompt")) {
      system_head_prompt =
        nntr_cfg["system_prompt"]["head_prompt"].get<std::string>();
      system_tail_prompt =
        nntr_cfg["system_prompt"]["tail_prompt"].get<std::string>();
    }

    // Construct weight file path (already rebased onto model_path above)
    const std::string weight_file =
      nntr_cfg["model_file_name"].get<std::string>();

    std::cout << weight_file << std::endl;
    _ilap("config json parsed");

    // Initialize and run model
    std::string architecture;
    if (cfg.contains("architectures") && cfg["architectures"].is_array() &&
        !cfg["architectures"].empty()) {
      architecture = cfg["architectures"].get<std::vector<std::string>>()[0];
    } else if (cfg.contains("architecture") &&
               cfg["architecture"].is_string()) {
      architecture = cfg["architecture"].get<std::string>();
    } else if (cfg.contains("model_type") && cfg["model_type"].is_string()) {
      architecture = cfg["model_type"].get<std::string>();
    } else {
      throw std::invalid_argument(
        "config.json must contain 'architectures', 'architecture', or "
        "'model_type'.");
    }

    if (nntr_cfg.contains("model_type")) {
      std::string model_type = nntr_cfg["model_type"].get<std::string>();
      architecture = resolve_architecture(model_type, architecture);
    }

    // Load chat template from tokenizer_config.json or jinja (if available)
    std::optional<causallm::ChatTemplate> chat_template;
    if (causallm::ChatTemplate::Exists(model_path)) {
      chat_template.emplace(causallm::ChatTemplate::Load(model_path));
    }

    // Determine input text
    if (argc >= 3) {
      input_text = argv[2];
    } else {
      if (nntr_cfg.contains("chat_input")) {
        if (chat_template.has_value()) {
          input_text = chat_template->apply(nntr_cfg["chat_input"]);
          system_head_prompt.clear();
          system_tail_prompt.clear();
        } else {
          std::cerr << "[Warning] 'chat_input' is set but support for model "
                       "architecture '"
                    << architecture
                    << "' is not implemented. Falling back to 'sample_input'."
                    << std::endl;
          input_text = nntr_cfg["sample_input"].get<std::string>();
        }
      } else {
        input_text = nntr_cfg["sample_input"].get<std::string>();
      }
    }

    _ilap("chat template + prompt");
    auto model = causallm::Factory::Instance().create(architecture, cfg,
                                                      generation_cfg, nntr_cfg);
    if (!model) {
      std::cerr << "Unknown architecture: " << architecture << std::endl;
      std::cerr << "Registered architectures:";
      causallm::Factory::Instance().printRegistered(std::cerr);
      std::cerr << std::endl;
      return EXIT_FAILURE;
    }
    _ilap("Factory::create");
    model->initialize();
    _ilap("model->initialize");
    model->load_weight(weight_file);
    _ilap("model->load_weight");
    model->repack_weight();
    _ilap("model->repack_weight");

    bool do_sample = generation_cfg.value("do_sample", false);

#ifdef PROFILE
    start_peak_tracker();
#endif

    // Test-only wrapper: one factory object, one weight load, two complete
    // runs.
    if (do_sample)
      throw std::runtime_error("repeat check requires do_sample=false");
    if (nntr_cfg.value("num_to_generate", 0u) != 64u)
      throw std::runtime_error("repeat check requires num_to_generate=64");
    if (nntr_cfg.value("skip_prefill", false))
      throw std::runtime_error("repeat check requires skip_prefill=false");
    if (nntr_cfg.value("batch_size", 0u) != 1u ||
        nntr_cfg.value("init_seq_len", 0u) != 2048u ||
        model->prefillPlaneFor(2048u) != 2048u)
      throw std::runtime_error("repeat check requires batch1/2048-row plane");
    const char *prefix_env = std::getenv("NNTR_REPEAT_PREFIX");
    const std::string prefix = prefix_env ? prefix_env : "repeat-prompt";
    std::vector<unsigned int> expected_ids, expected_input;
    json summary;
    summary["skip_prefill"] = false;
    summary["configured_decode_tokens"] = 64;
    summary["expected_dumped_ids"] = 65;
    summary["expected_token_trace_output_ids"] = 64;
    summary["token_trace_skips_prefill_generated_id"] = true;
    summary["runs"] = json::array();
    for (unsigned pass = 1; pass <= 2; ++pass) {
      const std::string stem = prefix + "-run" + std::to_string(pass);
      const std::string ids_path = stem + ".ids";
      const std::string trace_path = stem + ".trace.json";
#ifdef _WIN32
      if (_putenv_s("NNTR_GENERATED_IDS", ids_path.c_str()) ||
          _putenv_s("NNTR_HTP_TOKEN_TRACE", trace_path.c_str()))
#else
      if (setenv("NNTR_GENERATED_IDS", ids_path.c_str(), 1) ||
          setenv("NNTR_HTP_TOKEN_TRACE", trace_path.c_str(), 1))
#endif
        throw std::runtime_error("could not set per-run trace paths");
      std::fprintf(stderr, "[REPEAT-CHECK] begin run=%u model=%p\n", pass,
                   static_cast<const void *>(model.get()));
#if defined(_WIN32)
      model->run(input_text.c_str(), do_sample, system_head_prompt.c_str(),
                 system_tail_prompt.c_str());
#else
      model->run(input_text, do_sample, system_head_prompt, system_tail_prompt);
#endif
      const auto metrics = model->getPerformanceMetrics();
      if (metrics.prefill_tokens != 2048u || metrics.generation_tokens != 64u ||
          model->prefillPlaneFor(2048u) != 2048u)
        throw std::runtime_error("expected 2048 prefill rows/64 decode steps");
      std::ifstream ids_file(ids_path);
      if (!ids_file)
        throw std::runtime_error("missing generated-ID file: " + ids_path);
      std::vector<unsigned int> ids;
      unsigned int id;
      while (ids_file >> id)
        ids.push_back(id);
      if (!ids_file.eof())
        throw std::runtime_error("invalid generated-ID file: " + ids_path);
      std::ifstream trace_file(trace_path);
      if (!trace_file)
        throw std::runtime_error("missing token trace: " + trace_path);
      json trace;
      trace_file >> trace;
      const auto input_ids =
        trace.at("input_ids").get<std::vector<unsigned int>>();
      const auto trace_ids =
        trace.at("output_ids").get<std::vector<unsigned int>>();
      // CausalLM always dumps prefill's id_list before the decode loop. With
      // skip_prefill=false this is one generated token, followed by64 decode
      // tokens. Its legacy token trace includes prefill's token only when
      // init_len < INIT_SEQ_LEN; our2048-row prompt fills the2048-row plane.
      if (input_ids.size() != 2048 || ids.size() != 65 ||
          trace_ids.size() != 64)
        throw std::runtime_error(
          "expected 2048 input IDs, 65 dumped IDs (prefill1+decode64), "
          "and64 token-trace IDs");
      const std::vector<unsigned int> decode_ids(ids.begin() + 1, ids.end());
      if (trace_ids != decode_ids)
        throw std::runtime_error(
          "token trace differs from dumped decode suffix");
      if (pass == 1) {
        expected_ids = ids;
        expected_input = input_ids;
      } else if (expected_ids != ids || expected_input != input_ids) {
        throw std::runtime_error("repeated prompt input/output IDs differ");
      }
      summary["runs"].push_back({{"run", pass},
                                 {"input_tokens", input_ids.size()},
                                 {"prefill_generated_tokens", 1},
                                 {"decode_tokens", metrics.generation_tokens},
                                 {"dumped_generated_ids", ids.size()},
                                 {"token_trace_output_ids", trace_ids.size()},
                                 {"ids", ids_path},
                                 {"token_trace", trace_path}});
      std::fprintf(stderr,
                   "[REPEAT-CHECK] complete run=%u input=%zu prefill_out=1 "
                   "decode=%u dumped_ids=%zu trace_ids=%zu\n",
                   pass, input_ids.size(), metrics.generation_tokens,
                   ids.size(), trace_ids.size());
    }
    summary["input_ids_equal"] = true;
    summary["output_ids_equal"] = true;
    std::ofstream summary_file(prefix + ".summary.json");
    summary_file << summary.dump(2) << '\n';
    if (!summary_file)
      throw std::runtime_error("could not write repeat summary");
    std::fprintf(stderr,
                 "[REPEAT-CHECK] PASS same model, 2x2048 input, "
                 "each prefill1+decode64=65 dumped IDs, "
                 "identical input/output IDs and matching64-ID trace suffix\n");

#ifdef PROFILE
    stop_and_print_peak();
#endif
    auto finish_time = std::chrono::high_resolution_clock::now();
    auto e2e_duration = std::chrono::duration_cast<std::chrono::milliseconds>(
      finish_time - start_time);
    std::cout << "[e2e time]: " << e2e_duration.count() << " ms \n";
    printMemoryUsage();

  } catch (const std::exception &e) {
    std::cerr << "\n[!] FATAL ERROR: " << e.what() << "\n";
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

#ifndef REVIEW_HAP_FARF_H
#define REVIEW_HAP_FARF_H
void review_log(const char *, ...);
#define FARF(level, ...) review_log(__VA_ARGS__)
#endif

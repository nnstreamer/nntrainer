#define _POSIX_C_SOURCE 200112L
#include "hexkl_mm_opts.h"
#include "hexkl_mm_u8i4_dma.h"
#include "hexkl_probe.h"
#include "hvx_quant_u8.h"
#include "hvx_scalar_stubs.h"
#include "hvx_worker_pool.h"
#include <AEEStdErr.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
uint64_t review_align_queries;
static uint64_t packets, hash;
static uint32_t gm, gk, gn[3], gnh, gbanks[2], gspan, galloc;
static uint8_t *gb;
static uint32_t read_calls, clears, joins, drains, submitted, failed_read,
  failed_quant;
static unsigned case_count;
static void mix(uint64_t x) { hash = (hash ^ x) * UINT64_C(1099511628211); }
void review_packet(const uint8_t *a, const uint8_t *w) {
  assert(((uintptr_t)a & 2047u) == 0 && ((uintptr_t)w & 127u) == 0);
  uint64_t idx = packets;
  unsigned h = 0, ktn = gk / 32, rbn = (gm + 63) / 64;
  while (h < gnh) {
    uint64_t n = (uint64_t)rbn * (gn[h] / 32) * ktn;
    if (idx < n)
      break;
    idx -= n;
    ++h;
  }
  assert(h < gnh);
  unsigned kt = idx % ktn, tile = idx / ktn, nt = tile % (gn[h] / 32),
           rb = tile / (gn[h] / 32);
  size_t ao = (size_t)(rb * ktn + kt) * 2048,
         wo = gbanks[h & 1] + (size_t)(kt * (gn[h] / 32) + nt) * 512;
  assert(a == gb + ao && w == gb + wo);
  assert(ao + 2048 <= (size_t)rbn * 64 * gk && wo >= gbanks[h & 1] &&
         wo + 512 <= (size_t)gbanks[h & 1] + gspan && wo + 512 <= galloc);
  mix(ao);
  mix(wo);
  ++packets;
}
int __wrap_hexkl_micro_hmx_acc_clear_int32(void) {
  ++clears;
  mix(0x1111);
  return 0;
}
int __wrap_hexkl_micro_hmx_mm_u8i4(uint8_t *b, uint32_t a, uint32_t w) {
  if (((uintptr_t)(b + a) & 2047u) || ((uintptr_t)(b + w) & 127u))
    return AEE_EBADPARM;
  review_packet(b + a, b + w);
  return 0;
}
int __wrap_hexkl_micro_hmx_acc_read_int32(uint8_t *b, uint32_t cfg,
                                          uint32_t off) {
  assert(b == gb && off + 8192u <= galloc);
  (void)cfg;
  ++read_calls;
  mix(off);
  return read_calls == failed_read ? 99 : 0;
}
void __wrap_hexkl_dma_ring_push2d(void *d, const void *s, uint32_t ds,
                                  uint32_t ss, uint32_t rs, uint32_t n, int sv,
                                  int dv) {
  (void)s;
  (void)ss;
  (void)sv;
  (void)dv;
  assert((uint8_t *)d >= gb);
  assert((uint8_t *)d + (size_t)(n - 1) * ds + rs <= gb + galloc);
  mix((uint8_t *)d - gb);
  mix((size_t)n * rs);
}
void __wrap_hexkl_dma_ring_drain(void) {
  ++drains;
  mix(0x2222);
}
void __wrap_hvx_worker_pool_run(hvx_worker_pool *p, hvx_worker_pool_func f,
                                void *c, uint32_t n) {
  (void)p;
  (void)f;
  (void)c;
  (void)n;
  mix(0x3333);
}
void __wrap_hvx_worker_pool_submit(hvx_worker_pool *p, hvx_worker_pool_func f,
                                   void *c, uint32_t n) {
  (void)p;
  (void)f;
  (void)c;
  (void)n;
  ++submitted;
  mix(0x4444);
}
void __wrap_hvx_worker_pool_wait(hvx_worker_pool *p) {
  (void)p;
  ++joins;
  mix(0x5555);
}
int __wrap_hvx_quant_params_pack_u8_ah(const float *x, const uint16_t *x16,
                                       const float *enc, uint32_t hd,
                                       uint32_t M, uint32_t mp, uint32_t K,
                                       const float *g, float eps,
                                       float *scratch, float *sc, int32_t *zp,
                                       uint8_t *out, hvx_worker_pool *p) {
  (void)x;
  (void)x16;
  (void)enc;
  (void)hd;
  (void)M;
  (void)K;
  (void)g;
  (void)eps;
  (void)scratch;
  (void)out;
  (void)p;
  memset(sc, 0, 4u * mp);
  memset(zp, 0, 4u * mp);
  mix(0x6666);
  return failed_quant ? 98 : 0;
}
int __wrap_hvx_quant_pack_u8_ah(const float *x, uint32_t M, uint32_t mp,
                                uint32_t K, const float *sc, const int32_t *zp,
                                uint8_t *out, hvx_worker_pool *p) {
  (void)x;
  (void)M;
  (void)mp;
  (void)K;
  (void)sc;
  (void)zp;
  (void)out;
  (void)p;
  mix(0x6666);
  return failed_quant ? 98 : 0;
}
#ifdef REVIEW_CANDIDATE
int review_direct_guard(const hexkl_weight_u8i4_table *, const uint8_t *,
                        uint32_t, uint32_t, const uint32_t *, uint32_t,
                        const hexkl_mm_opts *, uint32_t, const uint32_t *,
                        uint32_t, uint32_t);
#endif
static void run(unsigned M, unsigned K, const unsigned *N, unsigned nh,
                unsigned kind, unsigned tight, unsigned err) {
  unsigned maxn = 0, total = 0;
  for (unsigned i = 0; i < nh; i++) {
    if (N[i] > maxn)
      maxn = N[i];
    total += N[i];
  }
  const unsigned ab = ((M + 63) / 64) * 64 * K, wb = K * maxn / 2,
                 wbuf[2] = {ab, ab + wb};
  unsigned arena = tight ? ab + 2 * wb + 16384 : (8u << 20);
  void *mem = NULL;
  assert(!posix_memalign(&mem, 2048, arena + (kind == 5 ? 1 : 0)));
  gb = (uint8_t *)mem + (kind == 5 ? 1 : 0);
  galloc = arena;
  gm = M;
  gk = K;
  gnh = nh;
  gspan = wb;
  gbanks[0] = wbuf[0];
  gbanks[1] = wbuf[1];
  memcpy(gn, N, 4u * nh);
  hexkl_weight_u8i4_table *t = calloc(1, sizeof *t);
  unsigned handles[3] = {0, 1, 2};
  int32_t *offsets = calloc(maxn, 4);
  float *col = calloc(maxn, 4);
  for (unsigned i = 0; i < nh; i++) {
    hexkl_weight_u8i4 *h = &t->slots[i];
    h->K = K;
    h->N = N[i];
    h->in_use = 1;
    h->bits = kind == 2 ? 2 : 4;
    h->w_offset = kind == 1 ? NULL : offsets;
    h->tl2_bytes = kind == 3 ? (uint8_t *)1 : NULL;
    h->colsum_w = offsets;
    h->w_scale = col;
    h->bias = col;
    h->wh_bytes = (uint8_t *)mem;
  }
  float *x = calloc((size_t)M * K, 4), *out = calloc((size_t)M * total, 4);
  hexkl_mm_opts o = {0};
  float *scale = calloc(M + 64, 4);
  int32_t *zp = calloc(M + 64, 4);
  float *scratch = calloc(4u * K, 4);
  float enc[2] = {0};
  if (kind == 4) {
    o.act_ah_prepacked = (uint8_t *)x;
    o.act_scale = scale;
    o.act_zp = zp;
  }
  if (kind == 6) {
    o.act_u16 = (uint16_t *)x;
    o.pre_scratch = scratch;
    o.act16_enc = enc;
    o.act16_hd = K;
  }
  review_align_queries = packets = read_calls = clears = joins = drains =
    submitted = 0;
  hash = UINT64_C(1469598103934665603);
  failed_read = err == 2 ? 33 : 0;
  failed_quant = err == 1;
  hexkl_probe_on = 0;
  int rc =
    hexkl_mm_u8i4_layer_run(t, gb, arena, arena, M, K, handles, nh, x, out, &o);
  if (kind == 5)
    assert(rc == AEE_EBADPARM && packets == 0 && clears == 1 && joins == 1);
  else if (err == 1)
    assert(rc == 98 && packets == 0 && clears == 0 && joins == 0);
  else if (err == 2)
    assert(rc == 99 && read_calls == 33 && packets == 33u * (K / 32) &&
           joins >= 1);
  else {
    assert(rc == 0);
    assert(packets == (uint64_t)((M + 63) / 64) * (total / 32) * (K / 32));
    assert(read_calls == ((M + 63) / 64) * (total / 32));
    assert(clears == read_calls);
    assert(joins == submitted + 1);
  }
#ifdef REVIEW_CANDIDATE
  const int shape = K == 2048 && M > 1 && kind == 0;
  if (shape)
    assert(review_align_queries == 1);
  else if (kind != 5 && !err)
    assert(review_align_queries >= packets &&
           review_align_queries <= packets + 1);
#else
  if (kind != 5)
    assert(review_align_queries == packets);
#endif
  printf("CASE %u M%u K%u N%u nh%u kind%u tight%u err%u rc%d packets%llu "
         "clears%u reads%u joins%u drains%u hash%016llx PASS\n",
         case_count, M, K, total, nh, kind, tight, err, rc,
         (unsigned long long)packets, clears, read_calls, joins, drains,
         (unsigned long long)hash);
  ++case_count;
#ifdef REVIEW_CANDIDATE
  if (shape && !err && !tight) {
    assert(
      review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb, arena));
    /* Leave a gap so this fails solely for bank zero alignment. */
    unsigned bad[2] = {wbuf[0] + 1, wbuf[1] + 128};
    assert(
      !review_direct_guard(t, gb, M, K, handles, nh, &o, ab, bad, wb, arena));
    bad[0] = wbuf[0];
    bad[1] = wbuf[1] + 1;
    assert(
      !review_direct_guard(t, gb, M, K, handles, nh, &o, ab, bad, wb, arena));
    assert(!review_direct_guard(t, gb, M, K, handles, nh, &o, ab + 1, wbuf, wb,
                                arena));
    assert(!review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb,
                                wbuf[1] + wb - 1));
    assert(!review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb - 1,
                                arena));
    o.accumulate = 1;
    assert(
      !review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb, arena));
    o.accumulate = 0;
    t->slots[0].in_use = 0;
    assert(
      !review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb, arena));
    t->slots[0].in_use = 1;
    handles[0] = HEXKL_MM_U8I4_MAX_WEIGHTS;
    assert(
      !review_direct_guard(t, gb, M, K, handles, nh, &o, ab, wbuf, wb, arena));
    handles[0] = 0;
  }
#endif
  free(mem);
  free(t);
  free(offsets);
  free(col);
  free(x);
  free(out);
  free(scale);
  free(zp);
  free(scratch);
}
int main(void) {
  const unsigned shapes[4][3] = {
    {512, 0, 0}, {2048, 0, 0}, {2048, 512, 512}, {2048, 2048, 2048}};
  const unsigned ms[] = {2, 64, 65, 512, 1024, 1920};
  for (unsigned m = 0; m < 6; m++)
    for (unsigned s = 0; s < 4; s++)
      run(ms[m], 2048, shapes[s], s < 2 ? 1 : 3, 0, 0, 0);
  for (unsigned s = 0; s < 4; s++) {
    run(1, 2048, shapes[s], s < 2 ? 1 : 3, 0, 0, 0);
    run(65, 2048, shapes[s], s < 2 ? 1 : 3, 0, 1, 0);
  }
  run(65, 1024, shapes[1], 1, 0, 0, 0);
  const unsigned gg[] = {1408, 0, 0}, gd[] = {2816, 0, 0};
  run(64, 2816, gg, 1, 0, 0, 0);
  run(64, 704, gd, 1, 0, 0, 0);
  for (unsigned k = 1; k <= 6; k++)
    run(65, 2048, shapes[2], 3, k, 0, 0);
  const unsigned badwidth[] = {1024, 0, 0}, badorder[] = {512, 2048, 512},
                 two[] = {2048, 2048, 0};
  run(65, 2048, badwidth, 1, 7, 0, 0);
  run(65, 2048, badorder, 3, 7, 0, 0);
  run(65, 2048, two, 2, 7, 0, 0);
  run(65, 2048, shapes[1], 1, 0, 0, 1);
  run(65, 2048, shapes[1], 1, 0, 0, 2);
  printf("FC_ISSUE_ACTUAL_CALLER %u cases PASS; scalar primitive semantics "
         "mocked\n",
         case_count);
}

	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hexkl_mm_u8i4_dma.c"
	.globl	hexkl_weight_u8i4_set_offsets   // -- Begin function hexkl_weight_u8i4_set_offsets
	.falign
	.type	hexkl_weight_u8i4_set_offsets,@function
hexkl_weight_u8i4_set_offsets:          // @hexkl_weight_u8i4_set_offsets
// %bb.0:                               // %entry
	{
		r2 = r0
		r3 = ##-2147449843
		p0 = cmp.eq(r0,#0)
	}
	{
		r0 = add(r3,#-32767)
		if (p0) jump:nt .LBB0_5
	}
// %bb.1:                               // %lor.lhs.false
	{
		p1 = cmp.eq(r1,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB0_2:                                // %lor.lhs.false
	{
		r3 = memw(r2+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB0_5
	}
// %bb.3:                               // %lor.lhs.false4
	{
		r3 = memw(r2+#24)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB0_5
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r3 = memw(r2+#84)
		if (!cmp.eq(r3.new,#2)) jump:t .LBB0_6
	}
	.falign
.LBB0_5:                                // %return
	{
		jumpr r31
	}
	.falign
.LBB0_6:                                // %for.cond.preheader
	{
		r6 = r1
		r3 = memw(r2+#32)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB0_13
	}
// %bb.7:
	{
		r4 = ##1097859072
		r5 = r3
	}
	.falign
.LBB0_8:                                // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r7 = memw(r6+#0)
	}
	{
		r8 = extractu(r7,#31,#0)
	}
	{
		p1 = sfcmp.uo(r4,r8)
		p0 = sfcmp.ge(r4,r8)
	}
	{
		r8 = convert_sf2w(r7):chop
		p1 = and(p0,!p1)
		if (!p1.new) jump:nt .LBB0_5
	}
// %bb.9:                               // %lor.lhs.false11
                                        //   in Loop: Header=BB0_8 Depth=1
	{
		r8 = convert_w2sf(r8)
	}
	{
		p0 = sfcmp.uo(r7,r8)
		p1 = sfcmp.eq(r7,r8)
	}
	{
		p0 = and(p1,!p0)
		if (p0.new) r6 = add(r6,#4)
		if (!p0.new) jump:nt .LBB0_5
	}
// %bb.10:                              // %for.cond
                                        //   in Loop: Header=BB0_8 Depth=1
	{
		r5 = add(r5,#-1)
		if (!cmp.eq(r5.new,#0)) jump:t .LBB0_8
	}
// %bb.11:                              // %for.body26.preheader
	{
		r5 = #0
		r0 = #0
		r4 = memw(r2+#8)
	}
	{
		r4 += mpyi(r3,#12)
		memw(r2+#20) = r4.new
	}
	.balign 32
.LBB0_12:                               // %for.body26
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = add(r5,#1)
		r3 = memw(r1++#4)
	}
	{
		r3 = convert_sf2w(r3):chop
		memw(r4++#4) = r3.new
	}
	{
		r3 = memw(r2+#32)
		if (cmp.gtu(r3.new,r5)) jump:t .LBB0_12
	}
	{
		jump .LBB0_5
	}
	.falign
.LBB0_13:                               // %for.end.thread
	{
		r0 = #0
		jumpr r31
		r3 = memw(r2+#8)
		memw(r2+#20) = r3.new
	}
.Lfunc_end0:
	.size	hexkl_weight_u8i4_set_offsets, .Lfunc_end0-hexkl_weight_u8i4_set_offsets
                                        // -- End function
	.globl	hexkl_weight_tl2_set_generation // -- Begin function hexkl_weight_tl2_set_generation
	.falign
	.type	hexkl_weight_tl2_set_generation,@function
hexkl_weight_tl2_set_generation:        // @hexkl_weight_tl2_set_generation
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r1,#0)
		r16 = r0
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB1_3
		memw(r0+#76) = r1
	}
// %bb.1:                               // %if.then
	{
		call hexkl_dcache_inva
		r1 = #128
		r0 = r1
		r17 = r1
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = memw(r17+#0)
		memw(r16+#80) = r2.new
	}
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB1_3:
	{
		r2 = #0
		r17:16 = memd(r29+#0)
		memw(r16+#80) = r2.new
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	hexkl_weight_tl2_set_generation, .Lfunc_end1-hexkl_weight_tl2_set_generation
                                        // -- End function
	.globl	hexkl_weight_tl2_refresh_pair   // -- Begin function hexkl_weight_tl2_refresh_pair
	.falign
	.type	hexkl_weight_tl2_refresh_pair,@function
hexkl_weight_tl2_refresh_pair:          // @hexkl_weight_tl2_refresh_pair
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r23 = #0
		r2 = memw(r0+#76)
		memd(r29+#32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		memd(r29+#48) = r19:18
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB2_21
		memd(r29+#24) = r25:24
		memd(r29+#16) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.end
	{
		r4 = ##-2147449843
	}
	{
		r23 = add(r4,#-32767)
		r3 = memw(r0+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.2:                               // %lor.lhs.false
	{
		r3 = memw(r1+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.3:                               // %lor.lhs.false4
	{
		r3 = memw(r0+#36)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r3 = memw(r1+#36)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.5:                               // %lor.lhs.false9
	{
		r3 = memw(r0+#48)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.6:                               // %lor.lhs.false11
	{
		r3 = memw(r1+#48)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_21
	}
// %bb.7:                               // %lor.lhs.false14
	{
		r3 = #2048
	}
	{
		r3 = memw(r0+#28)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB2_21
	}
// %bb.8:                               // %lor.lhs.false15
	{
		r3 = #3072
	}
	{
		r3 = memw(r0+#32)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB2_21
	}
// %bb.9:                               // %lor.lhs.false17
	{
		r3 = #1536
	}
	{
		r3 = memw(r1+#28)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB2_21
	}
// %bb.10:                              // %lor.lhs.false20
	{
		r3 = #2048
	}
	{
		r3 = memw(r1+#32)
		if (!cmp.eq(r3.new,r3)) jump:t .LBB2_21
	}
// %bb.11:                              // %if.end24
	{
		call hexkl_dcache_inva
		r17:16 = combine(r1,r0)
		r0 = r2
		r1 = #128
	}
	.falign
// %bb.12:                              // %if.end24
	{
		r7:6 = combine(#0,#23)
		r23 = #0
		r22 = memw(r16+#28)
		r4 = memw(r16+#76)
	}
	{
		r5 = memw(r4+#0)
	}
	{
		r4 = memw(r16+#80)
		if (cmp.eq(r4.new,r5)) jump:t .LBB2_21
	}
// %bb.13:                              // %if.then28
	{
		r13:12 = add(r23:22,r7:6)
		r4 = ##-1431655765
		r1 = #0
	}
	{
		r9:8 = mpyu(r12,r4)
		r3 = ##178956970
		r0 = memw(r16+#32)
	}
	{
		r15:14 = mpyu(r12,r3)
		r24 = asl(r0,#2)
		r25 = r17
		r26 = memw(r17+#32)
	}
	{
		r27 = #0
		r22 = r9
		r2 = r17
		memw(r29+#12) = r5
	}                                       // 4-byte Folded Spill
	{
		r21 = asl(r26,#2)
		r9:8 = combine(r23,r22)
		r22 = r14
		r20 = memw(r2+#4)
	}
	{
		r9:8 += mpyu(r13,r4)
	}
	{
		r9:8 = add(r9:8,r23:22)
	}
	{
		r22 = r9
		r9:8 = combine(#0,#127)
	}
	{
		r11:10 = combine(r23,r22)
		r22 = r15
	}
	{
		r11:10 += mpyu(r13,r3)
		r13:12 = add(r1:0,r9:8)
	}
	{
		r15:14 = add(r11:10,r23:22)
		r12 = lsr(r12,#7)
		r22 = memw(r17+#28)
	}
	{
		r12 = insert(r13,#7,#25)
		r7:6 = add(r23:22,r7:6)
	}
	{
		r11:10 = mpyu(r6,r4)
		r19:18 = mpyu(r6,r3)
	}
	{
		r13:12 = mpyu(r12,r14)
		r22 = r11
	}
	{
		r11:10 = combine(r23,r22)
		r22 = r18
		r18 = memw(r16+#4)
	}
	{
		r11:10 += mpyu(r7,r4)
		r5:4 = add(r27:26,r9:8)
	}
	{
		r11:10 = add(r11:10,r23:22)
		r4 = lsr(r4,#7)
	}
	{
		r4 = insert(r5,#7,#25)
		r18 += mpyi(r12,##640)
		r22 = r11
	}
	{
		r19 = asl(r0,#3)
		r11:10 = combine(r23,r22)
		r22 = r19
	}
	{
		r11:10 += mpyu(r7,r3)
		r1:0 = combine(r19,r18)
	}
	{
		r7:6 = add(r11:10,r23:22)
		r22 = r16
	}
	{
		r17:16 = mpyu(r4,r6)
		call hexkl_dcache_inva
	}
	.falign
// %bb.14:                              // %if.then28
	{
		r20 += mpyi(r16,##640)
		r17 = asl(r26,#3)
	}
	{
		call hexkl_dcache_inva
		r1:0 = combine(r17,r20)
	}
	.falign
// %bb.15:                              // %if.then28
	{
		r3:2 = combine(r24,r24)
		r5:4 = combine(#2,r24)
		r1 = r18
		r0 = memw(r22+#8)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	.falign
// %bb.16:                              // %if.then28
	{
		r1 = r20
		r3:2 = combine(r21,r21)
		r5:4 = combine(#2,r21)
		r0 = memw(r25+#8)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	.falign
// %bb.17:                              // %if.then28
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.18:                              // %if.then28
	{
		call hexkl_dcache_inva
		r1 = r19
		r0 = memw(r22+#8)
	}
	.falign
// %bb.19:                              // %if.then28
	{
		call hexkl_dcache_inva
		r1 = r17
		r0 = memw(r25+#8)
	}
	.falign
// %bb.20:                              // %if.then28
	{
		r2 = memw(r29+#12)
		memw(r22+#80) = r2.new
	}                                       // 4-byte Folded Reload
	.falign
.LBB2_21:                               // %return
	{
		r0 = r23
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end2:
	.size	hexkl_weight_tl2_refresh_pair, .Lfunc_end2-hexkl_weight_tl2_refresh_pair
                                        // -- End function
	.globl	hexkl_weight_u8i4_register      // -- Begin function hexkl_weight_u8i4_register
	.falign
	.type	hexkl_weight_u8i4_register,@function
hexkl_weight_u8i4_register:             // @hexkl_weight_u8i4_register
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		r6 = ##-2147449855
		allocframe(#72)
	}
	{
		r20 = add(r6,#-32755)
		memd(r29+#64) = r17:16
		memd(r29+#48) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#56) = r19:18
		memd(r29+#40) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB3_96
		memd(r29+#32) = r25:24
		memd(r29+#24) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB3_96
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB3_96
	}
// %bb.3:                               // %entry
	{
		r18 = memw(r29+#80)
		if (cmp.eq(r18.new,#0)) jump:nt ##.LBB3_96
	}
// %bb.4:                               // %entry
	{
		r17 = memw(r29+#84)
		if (cmp.eq(r17.new,#0)) jump:nt ##.LBB3_96
	}
// %bb.5:                               // %entry
	{
		r16 = memw(r29+#88)
		if (cmp.eq(r16.new,#0)) jump:nt ##.LBB3_96
	}
// %bb.6:                               // %entry
	{
		r22 = memw(r29+#96)
		if (cmp.eq(r22.new,#0)) jump:nt ##.LBB3_96
	}
// %bb.7:                               // %if.end
	{
		if (!p1.new) r7 = or(r4,r3)
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB3_96
	}
// %bb.8:                               // %if.end
	{
		if (!p0.new) r23 = #0
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB3_96
	}
// %bb.9:                               // %if.end
	{
		r7 = and(r7,#31)
		if (!cmp.eq(r7.new,#0)) jump:nt ##.LBB3_96
	}
// %bb.10:                              // %if.end.i
	{
		r7 = lsr(r4,#5)
		r8 = r3
		r24 = add(r6,#-32767)
	}
	{
		r8 = and(##-512,asl(r8,#4))
	}
	{
		r19 = mpyi(r8,r7)
	}
	{
		if (!p0.new) r6 = add(r0,#0)
		p0 = cmp.gtu(r19,r2); if (!p0.new) jump:t .LBB3_12
		if (!p0.new) r2 = memw(r29+#92)
	}
// %bb.11:
	{
		r20 = r24
		jump .LBB3_96
	}
	.falign
.LBB3_12:
	{
		loop0(.LBB3_13,#128)
	}
	.falign
.LBB3_13:                               // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r8 = memw(r6+#0)
		if (cmp.eq(r8.new,#0)) jump:nt ##.LBB3_78
	}
// %bb.14:                              // %for.inc.i
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#96)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_47
	}
// %bb.15:                              // %for.inc.i.1
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#192)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_48
	}
// %bb.16:                              // %for.inc.i.2
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#288)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_49
	}
// %bb.17:                              // %for.inc.i.3
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#384)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_50
	}
// %bb.18:                              // %for.inc.i.4
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#480)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_51
	}
// %bb.19:                              // %for.inc.i.5
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#576)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_52
	}
// %bb.20:                              // %for.inc.i.6
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#672)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_53
	}
// %bb.21:                              // %for.inc.i.7
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#768)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_54
	}
// %bb.22:                              // %for.inc.i.8
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#864)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_55
	}
// %bb.23:                              // %for.inc.i.9
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#960)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_56
	}
// %bb.24:                              // %for.inc.i.10
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1056)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_57
	}
// %bb.25:                              // %for.inc.i.11
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1152)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_58
	}
// %bb.26:                              // %for.inc.i.12
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1248)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_59
	}
// %bb.27:                              // %for.inc.i.13
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1344)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_60
	}
// %bb.28:                              // %for.inc.i.14
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1440)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_61
	}
// %bb.29:                              // %for.inc.i.15
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1536)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_62
	}
// %bb.30:                              // %for.inc.i.16
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1632)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_63
	}
// %bb.31:                              // %for.inc.i.17
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1728)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_64
	}
// %bb.32:                              // %for.inc.i.18
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1824)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_65
	}
// %bb.33:                              // %for.inc.i.19
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#1920)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_66
	}
// %bb.34:                              // %for.inc.i.20
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2016)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_67
	}
// %bb.35:                              // %for.inc.i.21
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2112)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_68
	}
// %bb.36:                              // %for.inc.i.22
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2208)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_69
	}
// %bb.37:                              // %for.inc.i.23
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2304)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_70
	}
// %bb.38:                              // %for.inc.i.24
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2400)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_71
	}
// %bb.39:                              // %for.inc.i.25
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2496)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_72
	}
// %bb.40:                              // %for.inc.i.26
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2592)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_73
	}
// %bb.41:                              // %for.inc.i.27
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2688)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_74
	}
// %bb.42:                              // %for.inc.i.28
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2784)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_75
	}
// %bb.43:                              // %for.inc.i.29
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2880)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_76
	}
// %bb.44:                              // %for.inc.i.30
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r8 = memw(r6+#2976)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB3_77
	}
// %bb.45:                              // %for.inc.i.31
                                        //   in Loop: Header=BB3_13 Depth=1
	{
		r23 = add(r23,#32)
		r6 = add(r6,#3072)
	} :endloop0
// %bb.46:
	{
		r20 = r24
		jump .LBB3_96
	}
	.falign
.LBB3_47:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit142
	{
		r23 = add(r23,#1)
		jump .LBB3_78
	}
	.falign
.LBB3_48:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit140
	{
		r23 = add(r23,#2)
		jump .LBB3_78
	}
	.falign
.LBB3_49:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit138
	{
		r23 = add(r23,#3)
		jump .LBB3_78
	}
	.falign
.LBB3_50:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit136
	{
		r23 = add(r23,#4)
		jump .LBB3_78
	}
	.falign
.LBB3_51:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit134
	{
		r23 = add(r23,#5)
		jump .LBB3_78
	}
	.falign
.LBB3_52:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit132
	{
		r23 = add(r23,#6)
		jump .LBB3_78
	}
	.falign
.LBB3_53:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit130
	{
		r23 = add(r23,#7)
		jump .LBB3_78
	}
	.falign
.LBB3_54:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit128
	{
		r23 = add(r23,#8)
		jump .LBB3_78
	}
	.falign
.LBB3_55:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit126
	{
		r23 = add(r23,#9)
		jump .LBB3_78
	}
	.falign
.LBB3_56:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit124
	{
		r23 = add(r23,#10)
		jump .LBB3_78
	}
	.falign
.LBB3_57:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit122
	{
		r23 = add(r23,#11)
		jump .LBB3_78
	}
	.falign
.LBB3_58:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit120
	{
		r23 = add(r23,#12)
		jump .LBB3_78
	}
	.falign
.LBB3_59:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit118
	{
		r23 = add(r23,#13)
		jump .LBB3_78
	}
	.falign
.LBB3_60:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit116
	{
		r23 = add(r23,#14)
		jump .LBB3_78
	}
	.falign
.LBB3_61:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit114
	{
		r23 = add(r23,#15)
		jump .LBB3_78
	}
	.falign
.LBB3_62:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit112
	{
		r23 = add(r23,#16)
		jump .LBB3_78
	}
	.falign
.LBB3_63:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit110
	{
		r23 = add(r23,#17)
		jump .LBB3_78
	}
	.falign
.LBB3_64:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit108
	{
		r23 = add(r23,#18)
		jump .LBB3_78
	}
	.falign
.LBB3_65:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit106
	{
		r23 = add(r23,#19)
		jump .LBB3_78
	}
	.falign
.LBB3_66:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit104
	{
		r23 = add(r23,#20)
		jump .LBB3_78
	}
	.falign
.LBB3_67:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit102
	{
		r23 = add(r23,#21)
		jump .LBB3_78
	}
	.falign
.LBB3_68:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit100
	{
		r23 = add(r23,#22)
		jump .LBB3_78
	}
	.falign
.LBB3_69:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit98
	{
		r23 = add(r23,#23)
		jump .LBB3_78
	}
	.falign
.LBB3_70:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit96
	{
		r23 = add(r23,#24)
		jump .LBB3_78
	}
	.falign
.LBB3_71:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit94
	{
		r23 = add(r23,#25)
		jump .LBB3_78
	}
	.falign
.LBB3_72:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit92
	{
		r23 = add(r23,#26)
		jump .LBB3_78
	}
	.falign
.LBB3_73:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit90
	{
		r23 = add(r23,#27)
		jump .LBB3_78
	}
	.falign
.LBB3_74:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit88
	{
		r23 = add(r23,#28)
		jump .LBB3_78
	}
	.falign
.LBB3_75:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit86
	{
		r23 = add(r23,#29)
		jump .LBB3_78
	}
	.falign
.LBB3_76:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit84
	{
		r23 = add(r23,#30)
		jump .LBB3_78
	}
	.falign
.LBB3_77:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit
	{
		r23 = add(r23,#31)
	}
	.falign
.LBB3_78:                               // %hexkl_weight_u8i4_free_slot.exit
	{
		r25 = r3
		p1 = cmp.eq(r23,##4096)
		if (!p1.new) jump:t .LBB3_80
	}
// %bb.79:
	{
		r20 = r24
		jump .LBB3_96
	}
	.falign
.LBB3_80:                               // %if.end17
	{
		r6 = lsr(r19,#9)
		r21 = r1
		memw(r29+#8) = r6.new
	}
	{
		r6 = add(pc,##hexkl_bake_u8i4_worker@PCREL)
		r3 = r6
		r27:26 = combine(r0,r4)
	}
	{
		r1:0 = combine(r6,r2)
		r2 = add(r29,#0)
		memw(r29+#0) = r5
		memw(r29+#4) = r21
	}
	{
		memw(r29+#12) = r7
		memw(r29+#16) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r29+#20) = #0
	}
	.falign
// %bb.81:                              // %if.end17
	{
		r20 = memw(r29+#20)
		if (!cmp.eq(r20.new,#0)) jump:t .LBB3_96
	}
// %bb.82:                              // %cleanup.cont
	{
		call malloc
		r0 = r19
	}
	.falign
// %bb.83:                              // %cleanup.cont
	{
		r27 += mpyi(r23,#96)
		r2 = r26
		r20 = r0
	}
	{
		r2 = add(#128,asl(r2,#4))
	}
	{
		r0 = r2
		memw(r27+#4) = r0
		memw(r27+#44) = #0
	}
	{
		memw(r27+#48) = #0
		memw(r27+#76) = #0
	}
	{
		call malloc
		memw(r27+#80) = #0
		memw(r27+#20) = #0
	}
	.falign
// %bb.84:                              // %cleanup.cont
	{
		p1 = cmp.eq(r20,#0); if (p1.new) jump:nt .LBB3_92
		memw(r27+#24) = r0
	}
// %bb.85:                              // %cleanup.cont
	{
		r2 = add(r0,#127)
		if (!p0.new) r1:0 = combine(r21,r20)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB3_92
	}
// %bb.86:                              // %if.end34
	{
		r21 = asl(r26,#2)
		memw(r27+#36) = #0
		memw(r27+#28) = r25
	}
	{
		r20 = and(r2,#-128)
		r2 = r19
		memw(r27+#32) = r26
	}
	{
		r3 = addasl(r20,r26,#2)
		r4 = addasl(r20,r26,#3)
		memw(r27+#16) = r4.new
	}
	{
		r7:6 = combine(r3,r20)
	}
	{
		call memcpy
		memd(r27+#8) = r7:6
	}
	.falign
// %bb.87:                              // %if.end34
	{
		call memcpy
		r1:0 = combine(r18,r20)
		r2 = r21
	}
	.falign
// %bb.88:                              // %if.end34
	{
		call memcpy
		r1 = r17
		r2 = r21
		r0 = memw(r27+#12)
	}
	.falign
// %bb.89:                              // %if.end34
	{
		call memcpy
		r1 = r16
		r2 = r21
		r0 = memw(r27+#16)
	}
	.falign
// %bb.90:                              // %if.end34
	{
		r1 = r19
		r3:2 = combine(#1,#0)
		r20 = #0
		r0 = memw(r27+#4)
	}
	{
		call qurt_mem_cache_clean
	}
	.falign
// %bb.91:                              // %if.end34
	{
		r2 = cmp.eq(r0,#0)
		memw(r27+#84) = #4
		memw(r27+#0) = #1
	}
	{
		memw(r27+#40) = r2
		memw(r22+#0) = r23
	}
	{
		jump .LBB3_96
	}
	.falign
.LBB3_92:                               // %hexkl_weight_u8i4_fill_slot.exit
	{
		call free
		r17 = r0
		r0 = r20
	}
	.falign
// %bb.93:                              // %hexkl_weight_u8i4_fill_slot.exit
	{
		call free
		r0 = r17
	}
	.falign
// %bb.94:                              // %hexkl_weight_u8i4_fill_slot.exit
	{
		call memset
		r1:0 = combine(#0,r27)
		r2 = #96
	}
	.falign
// %bb.95:                              // %hexkl_weight_u8i4_fill_slot.exit
	{
		r20 = r24
	}
	.falign
.LBB3_96:                               // %cleanup35
	{
		r0 = r20
		r17:16 = memd(r29+#64)
		r19:18 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#48)
		r23:22 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#32)
		r27:26 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hexkl_weight_u8i4_register, .Lfunc_end3-hexkl_weight_u8i4_register
                                        // -- End function
	.falign
	.type	hexkl_bake_u8i4_worker,@function // -- Begin function hexkl_bake_u8i4_worker
hexkl_bake_u8i4_worker:                 // @hexkl_bake_u8i4_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r22 = memw(r2+#8)
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		memd(r29+#8) = r21:20
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.1:                               // %entry
	{
		r4 = add(r17,#1)
		r19:18 = combine(r1,r0)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r22,r4)
		call __hexagon_udivdi3
	}
	.falign
// %bb.2:                               // %entry
	{
		r21:20 = combine(r1,r0)
	}
	{
		p0 = cmp.gtu(r20,r18); if (!p0.new) jump:t .LBB4_7
	}
// %bb.3:                               // %for.body.lr.ph
	{
		r17 = asl(r18,#9)
	}
	.falign
.LBB4_4:                                // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r19 = memw(r16+#12)
		r21 = memw(r16+#4)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r18)
		r22 = memw(r16+#0)
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB4_4 Depth=1
	{
		r3:2 = combine(r0,r22)
		r4 = r18
		r5 = memw(r16+#16)
	}
	{
		r4 -= mpyi(r0,r19)
		call hexkl_micro_hmx_rm_to_wh_i4
		r1:0 = combine(r17,r21)
	}
	.falign
// %bb.6:                               // %for.body
                                        //   in Loop: Header=BB4_4 Depth=1
	{
		r18 = add(r18,#1)
		p1 = cmp.eq(r0,#0)
		r17 = add(r17,#512)
	}
	{
		p0 = cmp.gtu(r20,r18); if (p0.new) jump:t .LBB4_4
		if (!p1) memw(r16+#20) = r0
	}
	.falign
.LBB4_7:                                // %for.cond.cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end4:
	.size	hexkl_bake_u8i4_worker, .Lfunc_end4-hexkl_bake_u8i4_worker
                                        // -- End function
	.falign
	.type	hexkl_weight_u8i4_fill_slot,@function // -- Begin function hexkl_weight_u8i4_fill_slot
hexkl_weight_u8i4_fill_slot:            // @hexkl_weight_u8i4_fill_slot
// %bb.0:                               // %entry
	{
		r17:16 = combine(r4,r0)
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r22 = r2
		r23 = memw(r29+#76)
		memd(r29+#24) = r23:22
	}
	{
		p0 = cmp.eq(r23,#0)
		r19:18 = combine(r5,r5)
		memd(r29+#40) = r19:18
		memd(r29+#32) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r0 = p0
		r21:20 = combine(r1,r3)
		if (!p0) jump:nt .LBB5_3
		memw(r29+#12) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %cond.false
	{
		call malloc
		r0 = r17
	}
	.falign
// %bb.2:                               // %cond.false
	{
		r19 = r0
	}
	.falign
.LBB5_3:                                // %cond.end
	{
		r16 += mpyi(r21,#96)
		r0 = r20
	}
	{
		r0 = add(#128,asl(r0,#4))
	}
	{
		memw(r16+#4) = r19
		memw(r16+#44) = #0
	}
	{
		memw(r16+#48) = #0
		memw(r16+#76) = #0
	}
	{
		call malloc
		memw(r16+#80) = #0
		memw(r16+#20) = #0
	}
	.falign
// %bb.4:                               // %cond.end
	{
		if (!p0.new) r2 = add(r0,#127)
		p0 = cmp.eq(r19,#0); if (p0.new) jump:nt .LBB5_15
		memw(r16+#24) = r0
	}
// %bb.5:                               // %cond.end
	{
		r21 = asl(r20,#2)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB5_15
	}
// %bb.6:                               // %if.end12
	{
		r2 = and(r2,#-128)
		r1:0 = combine(r23,r20)
		r23 = memw(r29+#64)
	}
	{
		r3 = add(r2,r21)
		memd(r16+#32) = r1:0
		memw(r16+#28) = r22
	}
	{
		r2 = addasl(r2,r20,#3)
		r1:0 = combine(r3,r2)
		memw(r16+#16) = r2.new
	}
	{
		r0 = memw(r29+#12)
		memd(r16+#8) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		if (p1.new) r1:0 = combine(r18,r19)
		if (p1.new) r2 = add(r17,#0)
		if (p1.new) jump:nt .LBB5_22
	}
// %bb.7:                               // %if.end26
	{
		p0 = cmp.eq(r23,#0); if (p0.new) jump:nt .LBB5_24
	}
	.falign
.LBB5_8:                                // %if.then28
	{
		r1 = r23
		r2 = r21
		r0 = memw(r16+#8)
		r18 = memw(r29+#72)
	}
	{
		call memcpy
		r19 = memw(r29+#68)
	}
	.falign
// %bb.9:                               // %if.then28
	{
		call memcpy
		r2 = r21
		r1 = r19
		r0 = memw(r16+#12)
	}
	.falign
// %bb.10:                              // %if.then28
	{
		call memcpy
		r2 = r21
		r1 = r18
		r0 = memw(r16+#16)
	}
	.falign
// %bb.11:                              // %if.then28
	{
		r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB5_14
	}
	.falign
.LBB5_12:                               // %if.then34
	{
		call qurt_mem_cache_clean
		r3:2 = combine(#1,#0)
		r1 = r17
		r0 = memw(r16+#4)
	}
	.falign
// %bb.13:                              // %if.then34
	{
		r2 = cmp.eq(r0,#0)
		memw(r16+#40) = r2.new
	}
	.falign
.LBB5_14:                               // %if.end37
	{
		r0 = #0 ; jump .LBB5_21
		memw(r16+#84) = #4
		memw(r16+#0) = #1
	}
	.falign
.LBB5_15:                               // %if.then
	{
		r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) r0 = add(r19,#0)
		if (!p1.new) jump:t .LBB5_18
	}
// %bb.16:                              // %if.then9
	{
		call free
	}
	.falign
// %bb.17:                              // %if.then9
	{
		r0 = memw(r16+#24)
	}
	.falign
.LBB5_18:                               // %if.end
	{
		call free
	}
	.falign
// %bb.19:                              // %if.end
	{
		call memset
		r1:0 = combine(#0,r16)
		r2 = #96
	}
	.falign
// %bb.20:                              // %if.end
	{
		r0 = ##-2147482622
	}
	.falign
.LBB5_21:                               // %cleanup
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB5_22:                               // %if.then24
	{
		call memcpy
	}
	.falign
// %bb.23:                              // %if.then24
	{
		p0 = cmp.eq(r23,#0); if (!p0.new) jump:t .LBB5_8
	}
	.falign
.LBB5_24:                               // %if.else
	{
		r2 = memw(r16+#4)
		r21 = memw(r16+#32)
	}
	{
		r19 = asl(r21,#3)
		r20 = asl(r21,#2)
		r18 = add(r2,r17)
	}
	{
		call hexkl_dcache_inva
		r1:0 = combine(r19,r18)
	}
	.falign
// %bb.25:                              // %if.else
	{
		r3:2 = combine(r20,r20)
		r5:4 = combine(#1,r20)
		r1 = r18
		r0 = memw(r16+#8)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	.falign
// %bb.26:                              // %if.else
	{
		r1 = addasl(r18,r21,#2)
		r3:2 = combine(r20,r20)
		r5:4 = combine(#1,r20)
		r0 = memw(r16+#12)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	.falign
// %bb.27:                              // %if.else
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.28:                              // %if.else
	{
		call hexkl_dcache_inva
		r1 = r19
		r0 = memw(r16+#8)
	}
	.falign
// %bb.29:                              // %if.else
	{
		call memset
		r2 = r20
		r1 = #0
		r0 = memw(r16+#16)
	}
	.falign
// %bb.30:                              // %if.else
	{
		r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB5_14
	}
	{
		jump .LBB5_12
	}
.Lfunc_end5:
	.size	hexkl_weight_u8i4_fill_slot, .Lfunc_end5-hexkl_weight_u8i4_fill_slot
                                        // -- End function
	.globl	hexkl_weight_u8i4_register_arena // -- Begin function hexkl_weight_u8i4_register_arena
	.falign
	.type	hexkl_weight_u8i4_register_arena,@function
hexkl_weight_u8i4_register_arena:       // @hexkl_weight_u8i4_register_arena
// %bb.0:                               // %entry
	{
		r12 = ##-2147449855
		r6 = r0
		p0 = cmp.eq(r0,#0)
	}
	{
		r0 = add(r12,#-32755)
		if (p0) jump:nt .LBB6_6
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB6_6
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r5,#0)
		r17 = memw(r29+#40)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB6_6
	}
// %bb.3:                               // %lor.lhs.false4
	{
		r8 = memw(r29+#32)
	}
	{
		p0 = cmp.eq(r8,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:nt .LBB6_6
		if (p0.new) r9 = memw(r29+#36)
	}
// %bb.4:                               // %lor.lhs.false4
	{
		p0 = cmp.eq(r9,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = xor(p1,p0)
		if (p1.new) r7 = #511
		if (!p1.new) jump:nt .LBB6_6
	}
// %bb.5:                               // %if.end
	{
		p0 = !bitsclr(r4,r7)
		if (!p0.new) jump:nt .LBB6_7
	}
	.falign
.LBB6_6:                                // %cleanup
	{
		r17:16 = memd(r29+#16)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB6_7:                                // %if.end19
	{
		if (!p1.new) r7 = or(r3,r2)
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB6_6
	}
// %bb.8:                               // %if.end19
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB6_6
	}
// %bb.9:                               // %if.end19
	{
		r13 = lsr(r3,#5)
		r7 = and(r7,#31)
		if (!cmp.eq(r7.new,#0)) jump:nt .LBB6_6
	}
// %bb.10:                              // %if.end.i
	{
		r0 = add(r12,#-32767)
		r16 = #0
		r7 = r2
	}
	{
		r7 = and(##-512,asl(r7,#4))
	}
	{
		r7 = mpyi(r7,r13)
	}
	{
		if (!p0.new) r12 = add(r6,#0)
		p0 = cmp.gtu(r7,r1); if (p0.new) jump:t .LBB6_6
	}
// %bb.11:
	{
		loop0(.LBB6_12,#128)
	}
	.falign
.LBB6_12:                               // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r13 = memw(r12+#0)
		if (cmp.eq(r13.new,#0)) jump:nt ##.LBB6_76
	}
// %bb.13:                              // %for.inc.i
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#96)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_45
	}
// %bb.14:                              // %for.inc.i.1
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#192)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_46
	}
// %bb.15:                              // %for.inc.i.2
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#288)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_47
	}
// %bb.16:                              // %for.inc.i.3
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#384)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_48
	}
// %bb.17:                              // %for.inc.i.4
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#480)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_49
	}
// %bb.18:                              // %for.inc.i.5
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#576)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_50
	}
// %bb.19:                              // %for.inc.i.6
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#672)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_51
	}
// %bb.20:                              // %for.inc.i.7
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#768)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_52
	}
// %bb.21:                              // %for.inc.i.8
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#864)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_53
	}
// %bb.22:                              // %for.inc.i.9
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#960)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_54
	}
// %bb.23:                              // %for.inc.i.10
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1056)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_55
	}
// %bb.24:                              // %for.inc.i.11
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1152)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_56
	}
// %bb.25:                              // %for.inc.i.12
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1248)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_57
	}
// %bb.26:                              // %for.inc.i.13
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1344)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_58
	}
// %bb.27:                              // %for.inc.i.14
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1440)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_59
	}
// %bb.28:                              // %for.inc.i.15
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1536)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_60
	}
// %bb.29:                              // %for.inc.i.16
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1632)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_61
	}
// %bb.30:                              // %for.inc.i.17
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1728)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_62
	}
// %bb.31:                              // %for.inc.i.18
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1824)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_63
	}
// %bb.32:                              // %for.inc.i.19
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#1920)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_64
	}
// %bb.33:                              // %for.inc.i.20
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2016)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_65
	}
// %bb.34:                              // %for.inc.i.21
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2112)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_66
	}
// %bb.35:                              // %for.inc.i.22
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2208)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_67
	}
// %bb.36:                              // %for.inc.i.23
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2304)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_68
	}
// %bb.37:                              // %for.inc.i.24
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2400)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_69
	}
// %bb.38:                              // %for.inc.i.25
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2496)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_70
	}
// %bb.39:                              // %for.inc.i.26
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2592)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_71
	}
// %bb.40:                              // %for.inc.i.27
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2688)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_72
	}
// %bb.41:                              // %for.inc.i.28
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2784)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_73
	}
// %bb.42:                              // %for.inc.i.29
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2880)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_74
	}
// %bb.43:                              // %for.inc.i.30
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r13 = memw(r12+#2976)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB6_75
	}
// %bb.44:                              // %for.inc.i.31
                                        //   in Loop: Header=BB6_12 Depth=1
	{
		r16 = add(r16,#32)
		r12 = add(r12,#3072)
	} :endloop0
	{
		jump .LBB6_6
	}
	.falign
.LBB6_45:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit120
	{
		r16 = add(r16,#1)
		jump .LBB6_76
	}
	.falign
.LBB6_46:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit118
	{
		r16 = add(r16,#2)
		jump .LBB6_76
	}
	.falign
.LBB6_47:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit116
	{
		r16 = add(r16,#3)
		jump .LBB6_76
	}
	.falign
.LBB6_48:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit114
	{
		r16 = add(r16,#4)
		jump .LBB6_76
	}
	.falign
.LBB6_49:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit112
	{
		r16 = add(r16,#5)
		jump .LBB6_76
	}
	.falign
.LBB6_50:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit110
	{
		r16 = add(r16,#6)
		jump .LBB6_76
	}
	.falign
.LBB6_51:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit108
	{
		r16 = add(r16,#7)
		jump .LBB6_76
	}
	.falign
.LBB6_52:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit106
	{
		r16 = add(r16,#8)
		jump .LBB6_76
	}
	.falign
.LBB6_53:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit104
	{
		r16 = add(r16,#9)
		jump .LBB6_76
	}
	.falign
.LBB6_54:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit102
	{
		r16 = add(r16,#10)
		jump .LBB6_76
	}
	.falign
.LBB6_55:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit100
	{
		r16 = add(r16,#11)
		jump .LBB6_76
	}
	.falign
.LBB6_56:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit98
	{
		r16 = add(r16,#12)
		jump .LBB6_76
	}
	.falign
.LBB6_57:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit96
	{
		r16 = add(r16,#13)
		jump .LBB6_76
	}
	.falign
.LBB6_58:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit94
	{
		r16 = add(r16,#14)
		jump .LBB6_76
	}
	.falign
.LBB6_59:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit92
	{
		r16 = add(r16,#15)
		jump .LBB6_76
	}
	.falign
.LBB6_60:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit90
	{
		r16 = add(r16,#16)
		jump .LBB6_76
	}
	.falign
.LBB6_61:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit88
	{
		r16 = add(r16,#17)
		jump .LBB6_76
	}
	.falign
.LBB6_62:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit86
	{
		r16 = add(r16,#18)
		jump .LBB6_76
	}
	.falign
.LBB6_63:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit84
	{
		r16 = add(r16,#19)
		jump .LBB6_76
	}
	.falign
.LBB6_64:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit82
	{
		r16 = add(r16,#20)
		jump .LBB6_76
	}
	.falign
.LBB6_65:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit80
	{
		r16 = add(r16,#21)
		jump .LBB6_76
	}
	.falign
.LBB6_66:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit78
	{
		r16 = add(r16,#22)
		jump .LBB6_76
	}
	.falign
.LBB6_67:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit76
	{
		r16 = add(r16,#23)
		jump .LBB6_76
	}
	.falign
.LBB6_68:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit74
	{
		r16 = add(r16,#24)
		jump .LBB6_76
	}
	.falign
.LBB6_69:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit72
	{
		r16 = add(r16,#25)
		jump .LBB6_76
	}
	.falign
.LBB6_70:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit70
	{
		r16 = add(r16,#26)
		jump .LBB6_76
	}
	.falign
.LBB6_71:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit68
	{
		r16 = add(r16,#27)
		jump .LBB6_76
	}
	.falign
.LBB6_72:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit66
	{
		r16 = add(r16,#28)
		jump .LBB6_76
	}
	.falign
.LBB6_73:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit64
	{
		r16 = add(r16,#29)
		jump .LBB6_76
	}
	.falign
.LBB6_74:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit62
	{
		r16 = add(r16,#30)
		jump .LBB6_76
	}
	.falign
.LBB6_75:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit
	{
		r16 = add(r16,#31)
	}
	.falign
.LBB6_76:                               // %hexkl_weight_u8i4_free_slot.exit
	{
		p1 = cmp.eq(r16,##4096)
		if (!p1.new) r1:0 = combine(r16,r6)
		if (p1.new) jump:t .LBB6_6
	}
// %bb.77:                              // %if.end26
	{
		r4 = r7
		r5 = r4
		memw(r29+#0) = r5
	}
	{
		memw(r29+#8) = r9
		memw(r29+#4) = r8
	}
	{
		call hexkl_weight_u8i4_fill_slot
		memw(r29+#12) = #1
	}
	.falign
// %bb.78:                              // %if.end26
	{
		p0 = cmp.eq(r0,#0)
		if (p0.new) r0 = #0
		r17:16 = memd(r29+#16)
		if (p0.new) memw(r17+#0) = r16
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	hexkl_weight_u8i4_register_arena, .Lfunc_end6-hexkl_weight_u8i4_register_arena
                                        // -- End function
	.globl	hexkl_weight_u8i4_rebind_arena  // -- Begin function hexkl_weight_u8i4_rebind_arena
	.falign
	.type	hexkl_weight_u8i4_rebind_arena,@function
hexkl_weight_u8i4_rebind_arena:         // @hexkl_weight_u8i4_rebind_arena
// %bb.0:                               // %entry
	{
		r6 = r0
		r7 = ##-2147449843
		allocframe(#16)
	}
	{
		p0 = cmp.eq(r0,#0)
		r0 = add(r7,#-32767)
		memd(r29+#8) = r17:16
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r7 = add(r1,#0)
		if (p0) jump:nt .LBB7_18
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB7_18
	}
// %bb.2:                               // %lor.lhs.false2
	{
		p0 = cmp.gtu(r1,##4095)
		if (p0.new) jump:nt .LBB7_18
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r7 = +mpyi(r7,#96)
		r17 = memw(r29+#28)
		r1 = memw(r29+#24)
	}
	{
		p1 = cmp.eq(r17,#0)
		p0 = cmp.eq(r1,#0)
	}
	{
		p1 = xor(p0,p1)
		if (!p1.new) r16 = add(r6,r7)
		if (p1.new) jump:nt .LBB7_18
	}
// %bb.4:                               // %if.end
	{
		r8 = memw(r6+r7<<#0)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB7_18
	}
// %bb.5:                               // %lor.lhs.false10
	{
		r6 = memw(r16+#36)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB7_18
	}
// %bb.6:                               // %lor.lhs.false12
	{
		r6 = memw(r16+#28)
		if (!cmp.eq(r6.new,r2)) jump:t .LBB7_18
	}
// %bb.7:                               // %lor.lhs.false15
	{
		r6 = memw(r16+#32)
		if (!cmp.eq(r6.new,r3)) jump:t .LBB7_18
	}
// %bb.8:                               // %lor.lhs.false18
	{
		r6 = #511
	}
	{
		p1 = !bitsclr(r4,r6)
		if (p1.new) jump:t .LBB7_18
		if (!p1.new) memw(r16+#48) = #0
		if (!p1.new) memw(r16+#76) = #0
	}
// %bb.9:                               // %if.end21
	{
		p1 = cmp.eq(r5,#0)
		memw(r16+#4) = r4
		memw(r16+#44) = #0
	}
	{
		r4 = mux(p1,#4,#2)
		memw(r16+#80) = #0
		memw(r16+#20) = #0
	}
	{
		if (p1) jump:nt .LBB7_11
		memw(r16+#84) = r4
	}
// %bb.10:                              // %if.then24
	{
		r4 = memub(r5+#3)
		r6 = memub(r5+#1)
	}
	{
		r4 = asl(r4,#24)
		r6 = asl(r6,#8)
		r7 = memub(r5+#2)
		r5 = memub(r5+#0)
	}
	{
		r4 |= asl(r7,#16)
	}
	{
		r4 |= or(r6,r5)
		memw(r16+#88) = r4.new
	}
	.falign
.LBB7_11:                               // %if.end26
	{
		if (p0) r0 = add(r16,#0)
		if (p0) jump:nt .LBB7_16
		if (!p0) r0 = memw(r16+#8)
	}
// %bb.12:                              // %if.then28
	{
		r18 = asl(r3,#2)
	}
	{
		call memcpy
		r2 = r18
	}
	.falign
// %bb.13:                              // %if.then28
	{
		call memcpy
		r2 = r18
		r1 = r17
		r0 = memw(r16+#12)
	}
	.falign
// %bb.14:                              // %if.then28
	{
		call memset
		r2 = r18
		r1 = #0
		r0 = memw(r16+#16)
	}
	.falign
// %bb.15:                              // %if.then28
	{
		r0 = #0
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB7_16:                               // %if.else
	{
		r2 = and(##-512,asl(r2,#4))
		r3 = lsr(r3,#5)
	}
	{
		r1 = mpyi(r2,r3)
	}
	{
		r2 = lsr(r1,#1)
	}
	{
		call hexkl_weight_u8i4_tail_from_arena
		if (!p1) r1 = add(r2,#0)
	}
	.falign
// %bb.17:                              // %if.else
	{
		r0 = #0
	}
	.falign
.LBB7_18:                               // %cleanup
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	hexkl_weight_u8i4_rebind_arena, .Lfunc_end7-hexkl_weight_u8i4_rebind_arena
                                        // -- End function
	.falign
	.type	hexkl_weight_u8i4_tail_from_arena,@function // -- Begin function hexkl_weight_u8i4_tail_from_arena
hexkl_weight_u8i4_tail_from_arena:      // @hexkl_weight_u8i4_tail_from_arena
// %bb.0:                               // %entry
	{
		r16 = r0
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r0+#4)
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r17 = add(r2,r1)
		r20 = memw(r0+#32)
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r18 = asl(r20,#3)
		r19 = asl(r20,#2)
	}
	{
		call hexkl_dcache_inva
		r1:0 = combine(r18,r17)
	}
	{
		r3:2 = combine(r19,r19)
		r5:4 = combine(#1,r19)
		r1 = r17
		r0 = memw(r16+#8)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	{
		r1 = addasl(r17,r20,#2)
		r3:2 = combine(r19,r19)
		r5:4 = combine(#1,r19)
		r0 = memw(r16+#12)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	{
		call hexkl_dma_ring_drain
	}
	{
		call hexkl_dcache_inva
		r1 = r18
		r0 = memw(r16+#8)
	}
	{
		r2 = r19
		r1 = #0
		r0 = memw(r16+#16)
		r17:16 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#16)
		r21:20 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump memset
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end8:
	.size	hexkl_weight_u8i4_tail_from_arena, .Lfunc_end8-hexkl_weight_u8i4_tail_from_arena
                                        // -- End function
	.globl	hexkl_weight_u2i4_register_arena // -- Begin function hexkl_weight_u2i4_register_arena
	.falign
	.type	hexkl_weight_u2i4_register_arena,@function
hexkl_weight_u2i4_register_arena:       // @hexkl_weight_u2i4_register_arena
// %bb.0:                               // %entry
	{
		r13 = ##-2147449855
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r0,#0)
		r0 = add(r13,#-32755)
		r17 = r0
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB9_7
	}
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB9_7
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB9_7
	}
// %bb.3:                               // %entry
	{
		r18 = memw(r29+#52)
		if (cmp.eq(r18.new,#0)) jump:nt .LBB9_7
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r9 = memw(r29+#44)
		r8 = memw(r29+#40)
	}
	{
		p0 = cmp.eq(r9,#0)
		p1 = cmp.eq(r8,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:nt .LBB9_7
		if (p0.new) r7 = memw(r29+#48)
	}
// %bb.5:                               // %lor.lhs.false6
	{
		p0 = cmp.eq(r7,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = xor(p1,p0)
		if (p1.new) r12 = #511
		if (!p1.new) jump:nt .LBB9_7
	}
// %bb.6:                               // %if.end
	{
		p0 = !bitsclr(r4,r12)
		if (!p0.new) jump:nt .LBB9_8
	}
	.falign
.LBB9_7:                                // %cleanup
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB9_8:                                // %if.end21
	{
		if (!p1.new) r12 = or(r3,r2)
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB9_7
	}
// %bb.9:                               // %if.end21
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB9_7
	}
// %bb.10:                              // %if.end21
	{
		r14 = lsr(r3,#5)
		r12 = and(r12,#31)
		if (!cmp.eq(r12.new,#0)) jump:nt .LBB9_7
	}
// %bb.11:                              // %if.end.i
	{
		r16 = #0
		r12 = r2
		r0 = add(r13,#-32767)
	}
	{
		r12 = and(##-512,asl(r12,#4))
	}
	{
		r12 = mpyi(r12,r14)
	}
	{
		p0 = cmp.gtu(r12,r1)
		if (!p0.new) r13 = add(r17,#0)
		if (p0.new) jump:t .LBB9_7
	}
// %bb.12:
	{
		loop0(.LBB9_13,#128)
	}
	.falign
.LBB9_13:                               // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r14 = memw(r13+#0)
		if (cmp.eq(r14.new,#0)) jump:nt ##.LBB9_77
	}
// %bb.14:                              // %for.inc.i
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#96)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_46
	}
// %bb.15:                              // %for.inc.i.1
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#192)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_47
	}
// %bb.16:                              // %for.inc.i.2
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#288)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_48
	}
// %bb.17:                              // %for.inc.i.3
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#384)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_49
	}
// %bb.18:                              // %for.inc.i.4
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#480)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_50
	}
// %bb.19:                              // %for.inc.i.5
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#576)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_51
	}
// %bb.20:                              // %for.inc.i.6
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#672)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_52
	}
// %bb.21:                              // %for.inc.i.7
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#768)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_53
	}
// %bb.22:                              // %for.inc.i.8
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#864)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_54
	}
// %bb.23:                              // %for.inc.i.9
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#960)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_55
	}
// %bb.24:                              // %for.inc.i.10
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1056)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_56
	}
// %bb.25:                              // %for.inc.i.11
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1152)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_57
	}
// %bb.26:                              // %for.inc.i.12
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1248)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_58
	}
// %bb.27:                              // %for.inc.i.13
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1344)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_59
	}
// %bb.28:                              // %for.inc.i.14
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1440)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_60
	}
// %bb.29:                              // %for.inc.i.15
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1536)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_61
	}
// %bb.30:                              // %for.inc.i.16
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1632)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_62
	}
// %bb.31:                              // %for.inc.i.17
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1728)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_63
	}
// %bb.32:                              // %for.inc.i.18
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1824)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_64
	}
// %bb.33:                              // %for.inc.i.19
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#1920)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_65
	}
// %bb.34:                              // %for.inc.i.20
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2016)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_66
	}
// %bb.35:                              // %for.inc.i.21
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2112)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_67
	}
// %bb.36:                              // %for.inc.i.22
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2208)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_68
	}
// %bb.37:                              // %for.inc.i.23
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2304)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_69
	}
// %bb.38:                              // %for.inc.i.24
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2400)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_70
	}
// %bb.39:                              // %for.inc.i.25
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2496)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_71
	}
// %bb.40:                              // %for.inc.i.26
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2592)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_72
	}
// %bb.41:                              // %for.inc.i.27
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2688)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_73
	}
// %bb.42:                              // %for.inc.i.28
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2784)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_74
	}
// %bb.43:                              // %for.inc.i.29
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2880)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_75
	}
// %bb.44:                              // %for.inc.i.30
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r14 = memw(r13+#2976)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB9_76
	}
// %bb.45:                              // %for.inc.i.31
                                        //   in Loop: Header=BB9_13 Depth=1
	{
		r16 = add(r16,#32)
		r13 = add(r13,#3072)
	} :endloop0
	{
		jump .LBB9_7
	}
	.falign
.LBB9_46:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit132
	{
		r16 = add(r16,#1)
		jump .LBB9_77
	}
	.falign
.LBB9_47:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit130
	{
		r16 = add(r16,#2)
		jump .LBB9_77
	}
	.falign
.LBB9_48:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit128
	{
		r16 = add(r16,#3)
		jump .LBB9_77
	}
	.falign
.LBB9_49:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit126
	{
		r16 = add(r16,#4)
		jump .LBB9_77
	}
	.falign
.LBB9_50:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit124
	{
		r16 = add(r16,#5)
		jump .LBB9_77
	}
	.falign
.LBB9_51:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit122
	{
		r16 = add(r16,#6)
		jump .LBB9_77
	}
	.falign
.LBB9_52:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit120
	{
		r16 = add(r16,#7)
		jump .LBB9_77
	}
	.falign
.LBB9_53:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit118
	{
		r16 = add(r16,#8)
		jump .LBB9_77
	}
	.falign
.LBB9_54:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit116
	{
		r16 = add(r16,#9)
		jump .LBB9_77
	}
	.falign
.LBB9_55:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit114
	{
		r16 = add(r16,#10)
		jump .LBB9_77
	}
	.falign
.LBB9_56:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit112
	{
		r16 = add(r16,#11)
		jump .LBB9_77
	}
	.falign
.LBB9_57:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit110
	{
		r16 = add(r16,#12)
		jump .LBB9_77
	}
	.falign
.LBB9_58:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit108
	{
		r16 = add(r16,#13)
		jump .LBB9_77
	}
	.falign
.LBB9_59:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit106
	{
		r16 = add(r16,#14)
		jump .LBB9_77
	}
	.falign
.LBB9_60:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit104
	{
		r16 = add(r16,#15)
		jump .LBB9_77
	}
	.falign
.LBB9_61:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit102
	{
		r16 = add(r16,#16)
		jump .LBB9_77
	}
	.falign
.LBB9_62:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit100
	{
		r16 = add(r16,#17)
		jump .LBB9_77
	}
	.falign
.LBB9_63:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit98
	{
		r16 = add(r16,#18)
		jump .LBB9_77
	}
	.falign
.LBB9_64:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit96
	{
		r16 = add(r16,#19)
		jump .LBB9_77
	}
	.falign
.LBB9_65:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit94
	{
		r16 = add(r16,#20)
		jump .LBB9_77
	}
	.falign
.LBB9_66:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit92
	{
		r16 = add(r16,#21)
		jump .LBB9_77
	}
	.falign
.LBB9_67:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit90
	{
		r16 = add(r16,#22)
		jump .LBB9_77
	}
	.falign
.LBB9_68:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit88
	{
		r16 = add(r16,#23)
		jump .LBB9_77
	}
	.falign
.LBB9_69:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit86
	{
		r16 = add(r16,#24)
		jump .LBB9_77
	}
	.falign
.LBB9_70:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit84
	{
		r16 = add(r16,#25)
		jump .LBB9_77
	}
	.falign
.LBB9_71:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit82
	{
		r16 = add(r16,#26)
		jump .LBB9_77
	}
	.falign
.LBB9_72:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit80
	{
		r16 = add(r16,#27)
		jump .LBB9_77
	}
	.falign
.LBB9_73:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit78
	{
		r16 = add(r16,#28)
		jump .LBB9_77
	}
	.falign
.LBB9_74:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit76
	{
		r16 = add(r16,#29)
		jump .LBB9_77
	}
	.falign
.LBB9_75:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit74
	{
		r16 = add(r16,#30)
		jump .LBB9_77
	}
	.falign
.LBB9_76:                               // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit
	{
		r16 = add(r16,#31)
	}
	.falign
.LBB9_77:                               // %hexkl_weight_u8i4_free_slot.exit
	{
		r6 = r4
		p1 = cmp.eq(r16,##4096)
		if (p1.new) jump:t .LBB9_7
	}
// %bb.78:                              // %if.end28
	{
		r7 = lsr(r12,#1)
		r1:0 = combine(r16,r17)
		r19 = r5
		memw(r29+#8) = r7
	}
	{
		r5:4 = combine(r6,r7)
		memw(r29+#4) = r9
		memw(r29+#0) = r8
	}
	{
		call hexkl_weight_u8i4_fill_slot
		memw(r29+#12) = #1
	}
	.falign
// %bb.79:                              // %if.end28
	{
		r17 += mpyi(r16,#96)
		if (p0.new) r0 = #0
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:t .LBB9_7
	}
// %bb.80:                              // %if.end32
	{
		memw(r17+#84) = #2
		r3 = memub(r19+#3)

	} :mem_noshuf
	{
		r3 = asl(r3,#24)
		r4 = memub(r19+#2)
		r5 = memub(r19+#1)
	}
	{
		r3 |= asl(r4,#16)
		r5 = asl(r5,#8)
		r2 = memub(r19+#0)
	}
	{
		r3 |= or(r5,r2)
		memw(r17+#88) = r3.new
	}
	{
		r17:16 = memd(r29+#24)
		memw(r18+#0) = r16
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#16)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end9:
	.size	hexkl_weight_u2i4_register_arena, .Lfunc_end9-hexkl_weight_u2i4_register_arena
                                        // -- End function
	.globl	hexkl_weight_tl2_compact_register_arena // -- Begin function hexkl_weight_tl2_compact_register_arena
	.falign
	.type	hexkl_weight_tl2_compact_register_arena,@function
hexkl_weight_tl2_compact_register_arena: // @hexkl_weight_tl2_compact_register_arena
// %bb.0:                               // %entry
	{
		r6 = r3
		r7 = ##-2147449855
		allocframe(#32)
	}
	{
		p0 = cmp.eq(r0,#0)
		r3 = add(r7,#-32755)
		memd(r29+#24) = r17:16
		memd(r29+#16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB10_6
	}
// %bb.1:                               // %entry
	{
		if (!p1.new) r9 = add(r6,#-1)
		if (!p1.new) r8 = add(r2,#-1)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB10_6
	}
// %bb.2:                               // %entry
	{
		if (!p0.new) r8 = or(r9,r8)
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB10_6
	}
// %bb.3:                               // %lor.lhs.false4
	{
		r9 = and(r6,#127)
		p1 = cmp.gtu(r8,##8191)
		if (p1.new) jump:nt .LBB10_6
	}
// %bb.4:                               // %lor.lhs.false4
	{
		r8 = r2
	}
	{
		r8 = or(r9,and(r8,#31))
		if (!cmp.eq(r8.new,#0)) jump:nt .LBB10_6
	}
// %bb.5:                               // %lor.lhs.false6
	{
		r8 = #511
	}
	{
		p1 = !bitsclr(r4,r8)
		if (!p1.new) jump:nt .LBB10_7
	}
	.falign
.LBB10_6:                               // %cleanup23
	{
		r0 = r3
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB10_7:                               // %if.end
	{
		if (!p0.new) r8 = or(r6,r2)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB10_6
	}
// %bb.8:                               // %if.end
	{
		p1 = cmp.eq(r6,#0); if (p1.new) jump:nt .LBB10_6
	}
// %bb.9:                               // %if.end
	{
		r8 = and(r8,#31)
		if (!cmp.eq(r8.new,#0)) jump:nt .LBB10_6
	}
// %bb.10:                              // %if.end.i
	{
		r8 = lsr(r6,#5)
		r16 = #0
		r3 = r2
	}
	{
		r3 = and(##-512,asl(r3,#4))
	}
	{
		r3 = mpyi(r3,r8)
	}
	{
		r3 = add(r7,#-32767)
		if (!p1.new) r7 = add(r0,#0)
		p1 = cmp.gtu(r3,r1); if (p1.new) jump:t .LBB10_6
	}
// %bb.11:
	{
		loop0(.LBB10_12,#128)
	}
	.falign
.LBB10_12:                              // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r8 = memw(r7+#0)
		if (cmp.eq(r8.new,#0)) jump:nt ##.LBB10_76
	}
// %bb.13:                              // %for.inc.i
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#96)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_45
	}
// %bb.14:                              // %for.inc.i.1
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#192)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_46
	}
// %bb.15:                              // %for.inc.i.2
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#288)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_47
	}
// %bb.16:                              // %for.inc.i.3
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#384)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_48
	}
// %bb.17:                              // %for.inc.i.4
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#480)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_49
	}
// %bb.18:                              // %for.inc.i.5
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#576)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_50
	}
// %bb.19:                              // %for.inc.i.6
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#672)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_51
	}
// %bb.20:                              // %for.inc.i.7
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#768)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_52
	}
// %bb.21:                              // %for.inc.i.8
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#864)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_53
	}
// %bb.22:                              // %for.inc.i.9
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#960)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_54
	}
// %bb.23:                              // %for.inc.i.10
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1056)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_55
	}
// %bb.24:                              // %for.inc.i.11
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1152)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_56
	}
// %bb.25:                              // %for.inc.i.12
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1248)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_57
	}
// %bb.26:                              // %for.inc.i.13
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1344)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_58
	}
// %bb.27:                              // %for.inc.i.14
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1440)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_59
	}
// %bb.28:                              // %for.inc.i.15
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1536)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_60
	}
// %bb.29:                              // %for.inc.i.16
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1632)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_61
	}
// %bb.30:                              // %for.inc.i.17
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1728)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_62
	}
// %bb.31:                              // %for.inc.i.18
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1824)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_63
	}
// %bb.32:                              // %for.inc.i.19
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#1920)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_64
	}
// %bb.33:                              // %for.inc.i.20
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2016)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_65
	}
// %bb.34:                              // %for.inc.i.21
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2112)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_66
	}
// %bb.35:                              // %for.inc.i.22
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2208)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_67
	}
// %bb.36:                              // %for.inc.i.23
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2304)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_68
	}
// %bb.37:                              // %for.inc.i.24
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2400)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_69
	}
// %bb.38:                              // %for.inc.i.25
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2496)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_70
	}
// %bb.39:                              // %for.inc.i.26
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2592)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_71
	}
// %bb.40:                              // %for.inc.i.27
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2688)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_72
	}
// %bb.41:                              // %for.inc.i.28
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2784)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_73
	}
// %bb.42:                              // %for.inc.i.29
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2880)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_74
	}
// %bb.43:                              // %for.inc.i.30
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r8 = memw(r7+#2976)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB10_75
	}
// %bb.44:                              // %for.inc.i.31
                                        //   in Loop: Header=BB10_12 Depth=1
	{
		r16 = add(r16,#32)
		r7 = add(r7,#3072)
	} :endloop0
	{
		jump .LBB10_6
	}
	.falign
.LBB10_45:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit117
	{
		r16 = add(r16,#1)
		jump .LBB10_76
	}
	.falign
.LBB10_46:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit115
	{
		r16 = add(r16,#2)
		jump .LBB10_76
	}
	.falign
.LBB10_47:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit113
	{
		r16 = add(r16,#3)
		jump .LBB10_76
	}
	.falign
.LBB10_48:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit111
	{
		r16 = add(r16,#4)
		jump .LBB10_76
	}
	.falign
.LBB10_49:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit109
	{
		r16 = add(r16,#5)
		jump .LBB10_76
	}
	.falign
.LBB10_50:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit107
	{
		r16 = add(r16,#6)
		jump .LBB10_76
	}
	.falign
.LBB10_51:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit105
	{
		r16 = add(r16,#7)
		jump .LBB10_76
	}
	.falign
.LBB10_52:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit103
	{
		r16 = add(r16,#8)
		jump .LBB10_76
	}
	.falign
.LBB10_53:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit101
	{
		r16 = add(r16,#9)
		jump .LBB10_76
	}
	.falign
.LBB10_54:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit99
	{
		r16 = add(r16,#10)
		jump .LBB10_76
	}
	.falign
.LBB10_55:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit97
	{
		r16 = add(r16,#11)
		jump .LBB10_76
	}
	.falign
.LBB10_56:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit95
	{
		r16 = add(r16,#12)
		jump .LBB10_76
	}
	.falign
.LBB10_57:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit93
	{
		r16 = add(r16,#13)
		jump .LBB10_76
	}
	.falign
.LBB10_58:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit91
	{
		r16 = add(r16,#14)
		jump .LBB10_76
	}
	.falign
.LBB10_59:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit89
	{
		r16 = add(r16,#15)
		jump .LBB10_76
	}
	.falign
.LBB10_60:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit87
	{
		r16 = add(r16,#16)
		jump .LBB10_76
	}
	.falign
.LBB10_61:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit85
	{
		r16 = add(r16,#17)
		jump .LBB10_76
	}
	.falign
.LBB10_62:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit83
	{
		r16 = add(r16,#18)
		jump .LBB10_76
	}
	.falign
.LBB10_63:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit81
	{
		r16 = add(r16,#19)
		jump .LBB10_76
	}
	.falign
.LBB10_64:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit79
	{
		r16 = add(r16,#20)
		jump .LBB10_76
	}
	.falign
.LBB10_65:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit77
	{
		r16 = add(r16,#21)
		jump .LBB10_76
	}
	.falign
.LBB10_66:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit75
	{
		r16 = add(r16,#22)
		jump .LBB10_76
	}
	.falign
.LBB10_67:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit73
	{
		r16 = add(r16,#23)
		jump .LBB10_76
	}
	.falign
.LBB10_68:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit71
	{
		r16 = add(r16,#24)
		jump .LBB10_76
	}
	.falign
.LBB10_69:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit69
	{
		r16 = add(r16,#25)
		jump .LBB10_76
	}
	.falign
.LBB10_70:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit67
	{
		r16 = add(r16,#26)
		jump .LBB10_76
	}
	.falign
.LBB10_71:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit65
	{
		r16 = add(r16,#27)
		jump .LBB10_76
	}
	.falign
.LBB10_72:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit63
	{
		r16 = add(r16,#28)
		jump .LBB10_76
	}
	.falign
.LBB10_73:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit61
	{
		r16 = add(r16,#29)
		jump .LBB10_76
	}
	.falign
.LBB10_74:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit59
	{
		r16 = add(r16,#30)
		jump .LBB10_76
	}
	.falign
.LBB10_75:                              // %hexkl_weight_u8i4_free_slot.exit.split.loop.exit
	{
		r16 = add(r16,#31)
	}
	.falign
.LBB10_76:                              // %hexkl_weight_u8i4_free_slot.exit
	{
		r9:8 = combine(#0,#23)
		p0 = cmp.eq(r16,##4096)
		if (p0.new) jump:t .LBB10_6
	}
// %bb.77:                              // %if.end14
	{
		r12 = ##-1431655765
		r7 = #0
		r3 = #0
	}
	{
		r9:8 = add(r3:2,r9:8)
		r15:14 = combine(#0,#127)
		r13 = ##178956970
	}
	{
		r11:10 = mpyu(r8,r12)
		r19:18 = mpyu(r8,r13)
		r3 = r6
		r1 = r16
	}
	{
		r15:14 = add(r7:6,r15:14)
		r10 = r11
		r11 = #0
		memw(r29+#12) = #1
	}
	{
		r11:10 += mpyu(r9,r12)
		r8 = r19
		r19 = #0
		r17 = r0
	}
	{
		r11:10 = add(r11:10,r19:18)
		r7 = lsr(r14,#7)
		memw(r29+#8) = #0
		memw(r29+#4) = #0
	}
	{
		r10 = r11
		r11 = #0
		r18 = r5
		r5 = r4
	}
	{
		r7 = insert(r15,#7,#25)
		r11:10 += mpyu(r9,r13)
		r9 = #0
		memw(r29+#0) = #0
	}
	{
		r9:8 = add(r11:10,r9:8)
	}
	{
		r9:8 = mpyu(r8,r7)
	}
	{
		r4 = +mpyi(r8,##640)
		call hexkl_weight_u8i4_fill_slot
	}
	.falign
// %bb.78:                              // %if.end14
	{
		r17 += mpyi(r16,#96)
		r3 = r0
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB10_6
	}
// %bb.79:                              // %if.end20
	{
		r3 = #0
		r4 = memw(r17+#4)
	}
	{
		memw(r17+#88) = ##16843007
		memw(r17+#84) = #2
	}
	{
		memw(r17+#44) = r4
	}
	{
		r0 = #0
		memw(r17+#48) = #1
		memw(r18+#0) = r16
	}
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end10:
	.size	hexkl_weight_tl2_compact_register_arena, .Lfunc_end10-hexkl_weight_tl2_compact_register_arena
                                        // -- End function
	.globl	hexkl_weight_tl2_compact_rebind_arena // -- Begin function hexkl_weight_tl2_compact_rebind_arena
	.falign
	.type	hexkl_weight_tl2_compact_rebind_arena,@function
hexkl_weight_tl2_compact_rebind_arena:  // @hexkl_weight_tl2_compact_rebind_arena
// %bb.0:                               // %entry
	{
		r5 = ##-2147449843
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.gtu(r1,##4095)
		r17 = add(r5,#-32767)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB11_6
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB11_6
	}
// %bb.2:                               // %entry
	{
		r16 = r2
		if (!p0.new) r2 = add(r3,#0)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB11_6
	}
// %bb.3:                               // %lor.lhs.false3
	{
		r3 = add(r16,#-1)
		r5 = add(r2,#-1)
	}
	{
		r3 = or(r5,r3)
		r5 = and(r2,#127)
	}
	{
		p1 = cmp.gtu(r3,##8191)
		if (!p1.new) r3 = add(r16,#0)
		if (p1.new) jump:nt .LBB11_6
	}
// %bb.4:                               // %lor.lhs.false3
	{
		r3 = or(r5,and(r3,#31))
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB11_6
	}
// %bb.5:                               // %lor.lhs.false5
	{
		r3 = #511
	}
	{
		p1 = !bitsclr(r4,r3)
		if (!p1.new) jump:nt .LBB11_7
	}
	.falign
.LBB11_6:                               // %return
	{
		r0 = r17
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB11_7:                               // %if.end
	{
		r3 = +mpyi(r1,#96)
	}
	{
		r18 = add(r0,r3)
		r5 = memw(r0+r3<<#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB11_6
	}
// %bb.8:                               // %lor.lhs.false8
	{
		r3 = memw(r18+#36)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB11_6
	}
// %bb.9:                               // %lor.lhs.false10
	{
		r3 = memw(r18+#28)
		if (!cmp.eq(r3.new,r16)) jump:t .LBB11_6
	}
// %bb.10:                              // %lor.lhs.false13
	{
		r7:6 = combine(#0,#23)
		r3 = memw(r18+#32)
		if (!cmp.eq(r3.new,r2)) jump:t .LBB11_6
	}
// %bb.11:                              // %if.end17
	{
		r17 = #0
		r3 = ##-1431655765
		r0 = r18
	}
	{
		r7:6 = add(r17:16,r7:6)
		r5 = ##178956970
		r14 = memw(r18+#4)
	}
	{
		r9:8 = mpyu(r6,r3)
		r13:12 = mpyu(r6,r5)
		memw(r18+#4) = r4
		memw(r18+#44) = r4
	}
	{
		p0 = cmp.eq(r14,r4)
		r16 = r9
		r9:8 = combine(#0,#127)
		memw(r18+#84) = #2
	}
	{
		r11:10 = combine(r17,r16)
		r16 = r12
		if (!p0) memw(r18+#76) = #0
		if (!p0) memw(r18+#80) = #0
	}
	{
		r11:10 += mpyu(r7,r3)
		r3 = #0
		memw(r18+#48) = #1
		memw(r18+#20) = #0
	}
	{
		r11:10 = add(r11:10,r17:16)
		memw(r18+#88) = ##16843007
	}
	{
		r3:2 = add(r3:2,r9:8)
		r16 = r11
	}
	{
		r2 = lsr(r2,#7)
		r15:14 = combine(r17,r16)
		r16 = r13
	}
	{
		r2 = insert(r3,#7,#25)
		r15:14 += mpyu(r7,r5)
	}
	{
		r7:6 = add(r15:14,r17:16)
	}
	{
		r3:2 = mpyu(r6,r2)
	}
	{
		r1 = +mpyi(r2,##640)
		call hexkl_weight_u8i4_tail_from_arena
	}
	.falign
// %bb.12:                              // %if.end17
	{
		r2 = #0
		r16 = memw(r18+#76)
		if (cmp.eq(r16.new,#0)) jump:nt .LBB11_15
	}
// %bb.13:                              // %if.then.i
	{
		call hexkl_dcache_inva
		r0 = r16
		r1 = #128
	}
	.falign
// %bb.14:                              // %if.then.i
	{
		r2 = memw(r16+#0)
	}
	.falign
.LBB11_15:                              // %hexkl_weight_tl2_set_generation.exit
	{
		r0 = r17
		r17:16 = memd(r29+#8)
		memw(r18+#80) = r2
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end11:
	.size	hexkl_weight_tl2_compact_rebind_arena, .Lfunc_end11-hexkl_weight_tl2_compact_rebind_arena
                                        // -- End function
	.globl	hexkl_weight_u8i4_borrows       // -- Begin function hexkl_weight_u8i4_borrows
	.falign
	.type	hexkl_weight_u8i4_borrows,@function
hexkl_weight_u8i4_borrows:              // @hexkl_weight_u8i4_borrows
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_36
		r0 = #0
		r3 = r0
	}
// %bb.1:                               // %entry
	{
		r3 = add(r3,#708)
		r2 = add(r1,r2)
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB12_36
	}
// %bb.2:                               // %for.cond.preheader
	{
		loop0(.LBB12_3,#512)
	}
	.falign
.LBB12_3:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = memw(r3+#-708)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_7
	}
// %bb.4:                               // %land.lhs.true
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-672)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_7
	}
// %bb.5:                               // %land.lhs.true4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-704)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_7
	}
// %bb.6:                               // %land.lhs.true4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_37
	}
	.falign
.LBB12_7:                               // %for.inc
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-612)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_11
	}
// %bb.8:                               // %land.lhs.true.1
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-576)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_11
	}
// %bb.9:                               // %land.lhs.true4.1
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-608)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_11
	}
// %bb.10:                              // %land.lhs.true4.1
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_38
	}
	.falign
.LBB12_11:                              // %for.inc.1
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-516)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_15
	}
// %bb.12:                              // %land.lhs.true.2
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-480)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_15
	}
// %bb.13:                              // %land.lhs.true4.2
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-512)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_15
	}
// %bb.14:                              // %land.lhs.true4.2
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_39
	}
	.falign
.LBB12_15:                              // %for.inc.2
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-420)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_19
	}
// %bb.16:                              // %land.lhs.true.3
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-384)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_19
	}
// %bb.17:                              // %land.lhs.true4.3
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-416)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_19
	}
// %bb.18:                              // %land.lhs.true4.3
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_40
	}
	.falign
.LBB12_19:                              // %for.inc.3
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-324)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_23
	}
// %bb.20:                              // %land.lhs.true.4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-288)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_23
	}
// %bb.21:                              // %land.lhs.true4.4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-320)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_23
	}
// %bb.22:                              // %land.lhs.true4.4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_41
	}
	.falign
.LBB12_23:                              // %for.inc.4
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-228)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_27
	}
// %bb.24:                              // %land.lhs.true.5
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-192)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_27
	}
// %bb.25:                              // %land.lhs.true4.5
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-224)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_27
	}
// %bb.26:                              // %land.lhs.true4.5
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_42
	}
	.falign
.LBB12_27:                              // %for.inc.5
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-132)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_31
	}
// %bb.28:                              // %land.lhs.true.6
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-96)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_31
	}
// %bb.29:                              // %land.lhs.true4.6
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-128)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_31
	}
// %bb.30:                              // %land.lhs.true4.6
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_43
	}
	.falign
.LBB12_31:                              // %for.inc.6
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-36)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_35
	}
// %bb.32:                              // %land.lhs.true.7
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_35
	}
// %bb.33:                              // %land.lhs.true4.7
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r4 = memw(r3+#-32)
		if (cmp.gtu(r1,r4.new)) jump:nt .LBB12_35
	}
// %bb.34:                              // %land.lhs.true4.7
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		p1 = cmp.gtu(r2,r4); if (p1.new) jump:nt .LBB12_44
	}
	.falign
.LBB12_35:                              // %for.inc.7
                                        //   in Loop: Header=BB12_3 Depth=1
	{
		r3 = add(r3,#768)
		nop
	} :endloop0
	.falign
.LBB12_36:                              // %cleanup11
	{
		jumpr r31
	}
	.falign
.LBB12_37:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_38:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_39:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_40:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_41:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_42:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_43:
	{
		r0 = #1
		jumpr r31
	}
	.falign
.LBB12_44:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end12:
	.size	hexkl_weight_u8i4_borrows, .Lfunc_end12-hexkl_weight_u8i4_borrows
                                        // -- End function
	.globl	hexkl_weight_u8i4_export        // -- Begin function hexkl_weight_u8i4_export
	.falign
	.type	hexkl_weight_u8i4_export,@function
hexkl_weight_u8i4_export:               // @hexkl_weight_u8i4_export
// %bb.0:                               // %entry
	{
		r5 = ##-2147449843
		r4 = r0
	}
	{
		p0 = cmp.gtu(r1,##4095)
		r0 = add(r5,#-32767)
		if (p0.new) jump:nt .LBB13_8
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r4,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB13_2:                               // %entry
	{
		r5 = +mpyi(r1,#96)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB13_8
	}
// %bb.3:                               // %if.end
	{
		r6 = memw(r4+r5<<#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB13_8
	}
// %bb.4:                               // %lor.lhs.false4
	{
		r4 = add(r4,r5)
	}
	{
		r5 = memw(r4+#84)
		if (cmp.eq(r5.new,#2)) jump:t .LBB13_8
	}
// %bb.5:                               // %if.end7
	{
		r5 = memw(r4+#28)
		r6 = memw(r4+#32)
	}
	{
		r5 = and(##-512,asl(r5,#4))
		r6 = lsr(r6,#5)
	}
	{
		r5 = mpyi(r5,r6)
		if (!cmp.eq(r5.new,r3)) jump:t .LBB13_8
	}
// %bb.6:                               // %if.end12
	{
		r2 = r3
		r0 = r2
		allocframe(#0)
	}
	{
		call memcpy
		r1 = memw(r4+#4)
	}
	.falign
// %bb.7:                               // %if.end12
	{
		r0 = #0
		deallocframe
	}
	.falign
.LBB13_8:                               // %cleanup
	{
		jumpr r31
	}
.Lfunc_end13:
	.size	hexkl_weight_u8i4_export, .Lfunc_end13-hexkl_weight_u8i4_export
                                        // -- End function
	.globl	hexkl_weight_u8i4_release       // -- Begin function hexkl_weight_u8i4_release
	.falign
	.type	hexkl_weight_u8i4_release,@function
hexkl_weight_u8i4_release:              // @hexkl_weight_u8i4_release
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		r0 = ##-2147482610
		r2 = r0
	}
	{
		if (p0) jumpr:nt r31
	}
.LBB14_1:                               // %entry
	{
		r3 = +mpyi(r1,#96)
		p1 = cmp.gtu(r1,##4095)
		if (p1.new) jump:nt .LBB14_8
	}
// %bb.2:                               // %lor.lhs.false1
	{
		r4 = memw(r2+r3<<#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB14_8
	}
// %bb.3:                               // %if.end
	{
		r16 = add(r2,r3)
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r16+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB14_5
	}
// %bb.4:                               // %if.then6
	{
		call free
		r0 = memw(r16+#4)
	}
	.falign
.LBB14_5:                               // %if.end7
	{
		call free
		r0 = memw(r16+#24)
	}
	.falign
// %bb.6:                               // %if.end7
	{
		call memset
		r1:0 = combine(#0,r16)
		r2 = #96
	}
	.falign
// %bb.7:                               // %if.end7
	{
		r0 = #0
		r17:16 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB14_8:                               // %return
	{
		jumpr r31
	}
.Lfunc_end14:
	.size	hexkl_weight_u8i4_release, .Lfunc_end14-hexkl_weight_u8i4_release
                                        // -- End function
	.globl	hexkl_mm_u8i4_layer_run         // -- Begin function hexkl_mm_u8i4_layer_run
	.falign
	.type	hexkl_mm_u8i4_layer_run,@function
hexkl_mm_u8i4_layer_run:                // @hexkl_mm_u8i4_layer_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#672):raw
	}                                       // 8-byte Folded Spill
	{
		r25 = ##-2147449855
		memd(r29+#632) = r25:24
		memd(r29+#656) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r24 = add(r25,#-32755)
		memd(r29+#648) = r21:20
		memd(r29+#640) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB15_38
		memd(r29+#624) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB15_38
	}
// %bb.2:                               // %entry
	{
		r16 = memw(r29+#680)
		if (cmp.eq(r16.new,#0)) jump:nt .LBB15_38
	}
// %bb.3:                               // %entry
	{
		r17 = memw(r29+#684)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB15_38
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r26 = add(pc,##hexkl_mm_u8i4_fused_run.kDefaults@PCREL)
		r23 = memw(r29+#688)
		r6 = memw(r29+#696)
	}
	{
		p1 = cmp.eq(r6,#0)
		p0 = cmp.eq(r23,#0)
		if (!p1.new) r26 = add(r6,#0)
		r20 = memw(r29+#692)
	}
	{
		p1 = cmp.eq(r20,#0)
		if (!p0) jump:nt .LBB15_6
	}
// %bb.5:                               // %land.lhs.true
	{
		r6 = memw(r26+#16)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_20
	}
	.falign
.LBB15_6:                               // %lor.lhs.false11
	{
		if (p1) jump:nt .LBB15_38
	}
	.falign
.LBB15_7:                               // %lor.lhs.false13
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB15_38
	}
// %bb.8:                               // %lor.lhs.false13
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB15_38
	}
// %bb.9:                               // %if.end
	{
		r6 = memw(r26+#32)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_22
	}
// %bb.10:                              // %land.lhs.true19
	{
		r6 = memw(r26+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.11:                              // %lor.lhs.false21
	{
		r6 = memw(r26+#24)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.12:                              // %lor.lhs.false23
	{
		r6 = memw(r26+#4)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.13:                              // %lor.lhs.false25
	{
		r19:18 = combine(r2,r5)
		r27 = r0
		r6 = memw(r26+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.14:                              // %lor.lhs.false28
	{
		r6 = memw(r26+#36)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.15:                              // %lor.lhs.false30
	{
		r6 = memw(r26+#40)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.16:                              // %lor.lhs.false32
	{
		r1:0 = combine(r6,r5)
		memw(r29+#36) = r1
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_umodsi3
		r22 = r3
		r21 = r4
	}
	.falign
// %bb.17:                              // %lor.lhs.false32
	{
		if (p1.new) r0 = add(r27,#0)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB15_38
	}
// %bb.18:                              // %lor.lhs.false32.if.end36_crit_edge
	{
		p1 = or(p1,!p1)
		r2 = memw(r26+#8)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_38
	}
// %bb.19:
	{
		r5:4 = combine(r18,r21)
		r3:2 = combine(r22,r19)
		r1 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_23
	}
	.falign
.LBB15_20:                              // %land.lhs.true9
	{
		if (p1) jump:nt .LBB15_38
	}
// %bb.21:                              // %land.lhs.true9
	{
		r6 = memw(r26+#32)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_7
	}
	{
		jump .LBB15_38
	}
	.falign
.LBB15_22:                              // %if.end36
	{
		r6 = memw(r26+#8)
		r7 = memw(r26+#4)
	}
	{
		p0 = cmp.eq(r6,#0)
		p1 = cmp.eq(r7,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:t .LBB15_38
	}
	.falign
.LBB15_23:                              // %if.end44
	{
		if (!p1) jump:nt .LBB15_25
	}
// %bb.24:                              // %if.end44
	{
		r6 = memw(r26+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
	.falign
.LBB15_25:                              // %if.end53
	{
		r6 = memw(r26+#20)
	}
	{
		p0 = cmp.eq(r6,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = and(p0,!p1)
		if (!p1.new) r21 = #0
		if (p1.new) jump:t .LBB15_38
		if (!p1.new) r7 = memw(r26+#48)
	}
// %bb.26:                              // %if.end62
	{
		p0 = cmp.eq(r7,#0)
		r8 = memw(r26+#44)
		r6 = memw(r26+#80)
	}
	{
		p1 = cmp.eq(r8,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:t .LBB15_38
	}
// %bb.27:                              // %if.end70
	{
		r6 = #0
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB15_37
	}
// %bb.28:                              // %if.then73
	{
		if (p1) jump:nt .LBB15_38
		if (!p1) r9 = memw(r26+#52)
	}
// %bb.29:                              // %lor.lhs.false77
	{
		p1 = cmp.eq(r9,#0)
		if (!p1.new) r9 = add(r16,#0)
		if (p1.new) jump:nt .LBB15_38
	}
// %bb.30:
	{
		loop0(.LBB15_31,r17)
	}
	.falign
.LBB15_31:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r12 = #4095
	}
	{
		r12 = memw(r9+#0)
		if (cmp.gtu(r12.new,r12)) jump:nt .LBB15_38
	}
// %bb.32:                              // %lor.lhs.false86
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r9 = add(r9,#4)
		r13 = memw(r8+#0)
		if (!cmp.eq(r13.new,r21)) jump:nt .LBB15_38
	}
// %bb.33:                              // %if.end92
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r13 = r0
		r8 = add(r8,#4)
	}
	{
		r13 += mpyi(r12,#96)
	}
	{
		r12 = memw(r13+#32)
	}
	{
		r21 = add(r12,r21)
		nop
	} :endloop0
// %bb.34:
	{
		r8 = r17
	}
	.falign
.LBB15_35:                              // %for.body100
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = memw(r7+#0)
		if (!cmp.eq(r9.new,r21)) jump:nt .LBB15_38
	}
// %bb.36:                              // %for.cond96
                                        //   in Loop: Header=BB15_35 Depth=1
	{
		r7 = add(r7,#4)
		r8 = add(r8,#-1)
		if (!cmp.eq(r8.new,#0)) jump:t .LBB15_35
	}
	.falign
.LBB15_37:                              // %if.end112
	{
		r13 = lsr(r5,#5)
		p0 = !bitsclr(r5,#31)
		r28 = add(r4,#63)
		if (!p0.new) jump:nt .LBB15_39
	}
	.falign
.LBB15_38:                              // %cleanup1078
	{
		r0 = r24
		r19:18 = memd(r29+#656)
		r17:16 = memd(r29+#664)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#648)
		r23:22 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#632)
		r27:26 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB15_39:
	{
		r27 = #0
		r8 = r16
		r7 = #1
		r18 = #0
	}
	{
		r14 = lsr(r28,#6)
		r15 = and(r28,#-64)
	}
	{
		loop0(.LBB15_40,r17)
	}
	.falign
.LBB15_40:                              // Block address taken
                                        // %for.body126
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
	}
	{
		r9 = memw(r8+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt .LBB15_38
	}
// %bb.41:                              // %lor.lhs.false130
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r0+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB15_38
	}
// %bb.42:                              // %if.end136
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = add(r0,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r5)) jump:nt .LBB15_38
	}
// %bb.43:                              // %if.end144
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r8 = add(r8,#4)
		r12 = memw(r9+#32)
		r9 = memw(r9+#20)
	}
	{
		r18 = maxu(r12,r18)
		r9 = lsr(r12,#5)
		p0 = cmp.eq(r9,#0)
		if (!p0.new) r27 = add(r7,#0)
	}
	{
		r6 = maxu(r9,r6)
		nop
	} :endloop0
// %bb.44:                              // %for.end165
	{
		r7 = extractu(r13,#21,#0)
		r8 = extractu(r13,#23,#0)
		r24 = add(r25,#-32767)
	}
	{
		r7 = asl(r7,#11)
		r8 = asl(r8,#9)
	}
	{
		r9 = mpyi(r7,r14)
		r12 = mpyi(r8,r6)
		memw(r29+#48) = r9.new
	}                                       // 4-byte Folded Spill
	{
		r10 = minu(r2,r3)
		r19 = add(r12,r9)
		memw(r29+#312) = r9
	}
	{
		r6 = add(r12,add(r19,##2047))
		memw(r29+#316) = r19
	}
	{
		r6 = insert(r9,#11,#0)
	}
	{
		r2 = add(r6,#16384)
		if (cmp.gtu(r2.new,r10)) jump:t .LBB15_38
	}
// %bb.45:                              // %if.end194
	{
		r2 = sub(r10,r6)
		r1 = memw(r26+#52)
		memw(r29+#36) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = lsr(r2,#14)
		p1 = cmp.eq(r1,#0)
		r0 = #32
		memw(r29+#68) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = minu(r2,r0)
		memw(r29+#44) = r12
		memw(r29+#120) = r28
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#116) = r8
		memw(r29+#124) = r7
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#80) = r15
		memw(r29+#128) = r14
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#104) = r13
		memw(r29+#112) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#40) = r4
		memw(r29+#76) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#84) = r6
		memw(r29+#52) = r10
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB15_54
		memw(r29+#64) = r2
	}                                       // 4-byte Folded Spill
// %bb.46:                              // %for.body209.lr.ph
	{
		r3 = #0
		r1 = #1
		r4 = memw(r26+#56)
		r2 = memw(r26+#72)
	}
	{
		loop0(.LBB15_48,r17)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB15_49
	}
	.falign
.LBB15_48:                              // Block address taken
                                        // %for.body209
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r2,r3)
		r3 = add(r3,#1)
		r5 = #0
		r6 = memw(r4+#0)
	}
	{
		r4 = add(r4,#4)
		if (p1) r5 = memw(r26+#68)
	}
	{
		r5 = maxu(r6,r5)
	}
	{
		r5 = lsr(r5,#5)
	}
	{
		r1 = maxu(r5,r1)
		nop
	} :endloop0
	{
		jump .LBB15_51
	}
	.falign
.LBB15_49:
	{
		loop0(.LBB15_50,r17)
	}
	.balign 32
.LBB15_50:                              // Block address taken
                                        // %for.body209.us
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r2,r3)
		r4 = #0
		r3 = add(r3,#1)
	}
	{
		if (p1) r4 = memw(r26+#68)
	}
	{
		r4 = lsr(r4,#5)
	}
	{
		r1 = maxu(r4,r1)
		nop
	} :endloop0
	.falign
.LBB15_51:                              // %for.cond.cleanup208
	{
		r2 = memw(r29+#64)
		if (cmp.gtu(r1,r2.new)) jump:t .LBB15_54
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then242
	{
		r22 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r0 = r22
	}
	.falign
// %bb.53:                              // %if.then242
	{
		r22 = sub(r22,r0)
		memw(r29+#64) = r22.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_54:                              // %if.end246
	{
		r5:4 = combine(r17,r16)
		r2 = memw(r29+#52)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#44)
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#48)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#68)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Reload
	{
		r22 = memw(r29+#36)
		memw(r29+#12) = r19
	}                                       // 4-byte Folded Reload
	{
		r1 = r22
		r2 = memw(r29+#40)
		memw(r29+#0) = r26
	}                                       // 4-byte Folded Reload
	{
		call lfm2_fc_hmx_issue_ok
		r3 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.55:                              // %if.end246
	{
		call hexkl_dma_ring_reset
		memw(r29+#108) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.56:                              // %if.end246
	{
		call hexkl_acc_layout_get
		r0 = r22
		r1 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.57:                              // %if.end246
	{
		r2 = memw(r0+#4)
		memw(r29+#56) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p1 = cmp.eq(r2,#0)
		memw(r29+#44) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p1
		if (p1) jump:nt .LBB15_89
		memw(r29+#52) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.58:                              // %cond.end251.thread
	{
		r1 = #0
		r3 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r3+#12)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	.falign
.LBB15_59:                              // %if.end260
	{
		p1 = cmp.eq(r27,#0)
		r2 = #0
		memw(r29+#72) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		if (!p1) r2 = memw(r29+#40)
		memw(r29+#60) = r2
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB15_62
		memw(r29+#100) = r0
	}                                       // 4-byte Folded Spill
// %bb.60:                              // %cond.true262
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.61:                              // %cond.true262
	{
		memw(r29+#60) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_62:                              // %cond.end266
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB15_65
		if (p2.new) r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
// %bb.63:                              // %cond.false271
	{
		r2 = mpyi(r2,r18)
	}
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.64:                              // %cond.false271
	{
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_65:                              // %cond.end275
	{
		r1 = #0
		r2 = memw(r26+#4)
		memw(r29+#136) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		memw(r29+#88) = r1
		memw(r29+#92) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p0
		if (p0) r2 = memw(r29+#80)
		memw(r29+#96) = r1
	}                                       // 4-byte Folded Reload
	{
		if (!p0) jump:nt .LBB15_69
		memw(r29+#132) = r0
	}                                       // 4-byte Folded Spill
// %bb.66:                              // %if.then280
	{
		r25 = asl(r2,#2)
	}
	{
		call malloc
		r0 = r25
	}
	.falign
// %bb.67:                              // %if.then280
	{
		call malloc
		r0 = r25
		memw(r29+#96) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.68:                              // %if.then280
	{
		memw(r29+#92) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_69:                              // %if.end285
	{
		r2 = memw(r29+#52)
		r18 = memw(r26+#80)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_73
	}
// %bb.70:                              // %if.end285
	{
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB15_73
		if (!p1.new) r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
// %bb.71:                              // %cond.true292
	{
		call malloc
		r0 = asl(r2,#7)
	}
	.falign
// %bb.72:                              // %cond.true292
	{
		memw(r29+#88) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_73:                              // %cond.end296
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_75
	}
// %bb.74:                              // %cond.end296
	{
		r2 = memw(r29+#60)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_75:                              // %lor.lhs.false301
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB15_77
	}
// %bb.76:                              // %lor.lhs.false301
	{
		r2 = memw(r29+#72)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_77:                              // %lor.lhs.false306
	{
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB15_80
	}
// %bb.78:                              // %land.lhs.true310
	{
		r2 = memw(r29+#92)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_83
	}                                       // 4-byte Folded Reload
// %bb.79:                              // %land.lhs.true310
	{
		r2 = memw(r29+#96)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_80:                              // %lor.lhs.false314
	{
		p0 = cmp.eq(r18,#0); if (p0.new) jump:nt .LBB15_91
		if (!p0.new) r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
// %bb.81:                              // %lor.lhs.false314
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_91
	}
// %bb.82:                              // %lor.lhs.false314
	{
		r2 = memw(r29+#88)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB15_91
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_83:                              // %if.then323
	{
		call free
		r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.84:                              // %if.then323
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.85:                              // %if.then323
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.86:                              // %if.then323
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.87:                              // %if.then323
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.88:                              // %if.then323
	{
		jump .LBB15_38
	}
	.falign
.LBB15_89:                              // %cond.end251
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	{
		r2 = memw(r26+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_59
	}
// %bb.90:
	{
		r24 = add(r25,#-32749)
		jump .LBB15_38
	}
	.falign
.LBB15_91:                              // %if.end324
	{
		r2 = memw(r16+#0)
		r18 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#116)
		r1 = memw(r26+#8)
	}                                       // 4-byte Folded Reload
	{
		r18 += mpyi(r2,#96)
		memw(r29+#212) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r18+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r24 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r24
	}
	.falign
// %bb.92:                              // %if.end324
	{
		r25 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r25,r24)
		r24 = memw(r18+#4)
	}
	.falign
// %bb.93:                              // %if.end324
	{
		r5:4 = combine(r0,r25)
		r1 = r24
		r2 = memw(r29+#36)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r3)
		r3:2 = combine(r25,r25)
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	{
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.94:                              // %if.end324
	{
		r24 = memw(r26+#16)
		if (cmp.eq(r24.new,#0)) jump:nt .LBB15_101
	}
// %bb.95:                              // %if.then342
	{
		r18 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		call dma_row_size_dividing
		r0 = r18
	}
	.falign
// %bb.96:                              // %if.then342
	{
		r23 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r18)
	}
	.falign
// %bb.97:                              // %if.then342
	{
		r5:4 = combine(r0,r23)
		r1 = r24
		r3:2 = combine(r23,r23)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.98:                              // %if.then342
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_104
	}
// %bb.99:                              // %if.then348
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.100:                             // %if.then348
	{
		jump .LBB15_105
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_101:                             // %do.body360
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_109
	}
// %bb.102:                             // %if.then362
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.103:                             // %if.then362
	{
		jump .LBB15_110
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_104:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_105:                             // %do.end
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.106:                             // %do.end
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_125
	}
// %bb.107:                             // %if.then353
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.108:                             // %if.then353
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB15_125
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_109:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_110:                             // %do.end366
	{
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r0 = add(r23,#0)
		if (p2.new) jump:nt .LBB15_113
		if (p2.new) r1 = memw(r26+#32)
	}
// %bb.111:                             // %if.else377
	{
		r2 = memw(r26+#0)
		memw(r29+#4) = r2.new
	}
	{
		r1 = memw(r29+#40)
		r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#76)
		r5 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#136)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		memw(r29+#0) = r6
	}
	.falign
// %bb.112:                             // %if.else377
	{
		r24 = r0
		jump .LBB15_115
	}
	.falign
.LBB15_113:                             // %if.then369
	{
		r5 = memw(r26+#24)
		r2 = memw(r26+#36)
	}
	{
		r4 = memw(r29+#36)
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r26+#40)
		r6 = memw(r26+#28)
	}
	{
		r7 = memw(r26+#20)
	}
	{
		r8 = memw(r26+#0)
		memw(r29+#24) = r4

	} :mem_noshuf
	{
		r0 = r23
		memw(r29+#4) = r5
		memw(r29+#0) = r0
	}
	{
		r4 = memw(r29+#40)
		memw(r29+#28) = r8
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#80)
		memw(r29+#12) = r7
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#92)
		memw(r29+#20) = r18.new
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#96)
		memw(r29+#16) = r19.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_params_pack_u8_ah
		memw(r29+#8) = r6
	}
	.falign
// %bb.114:                             // %if.then369
	{
		r24 = r0
		memw(r29+#212) = r18
		memw(r29+#136) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_115:                             // %do.body382
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_118
	}
// %bb.116:                             // %if.then384
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.117:                             // %if.then384
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB15_118:                             // %if.end391
	{
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB15_125
		if (!p1.new) r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
// %bb.119:                             // %if.then394
	{
		call free
	}
	.falign
// %bb.120:                             // %if.then394
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.121:                             // %if.then394
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.122:                             // %if.then394
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.123:                             // %if.then394
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.124:                             // %if.then394
	{
		jump .LBB15_38
	}
	.falign
.LBB15_125:                             // %if.end395
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_127
		if (!p0.new) r4 = memw(r29+#76)
		if (!p0.new) r7 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.126:                             // %if.then397
	{
		r1 = add(pc,##fc_affine_sums_worker@PCREL)
		r2 = memw(r29+#36)
		memw(r29+#464) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#464)
		r0 = memw(r29+#40)
		memw(r29+#468) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#128)
		memw(r29+#476) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r26+#0)
		memw(r29+#472) = r4
	}
	{
		r6 = memw(r29+#60)
		memw(r29+#480) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#484) = r6
	}
	.falign
.LBB15_127:                             // %if.end401
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_130
		if (!p0.new) r2 = memw(r26+#12)
	}
// %bb.128:                             // %land.end
	{
		p2 = or(p2,!p2)
		p1 = cmp.eq(r2,#0)
	}
	{
		r0 = p2
		if (p1) jump:nt .LBB15_253
		memw(r29+#284) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.129:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		p1 = or(p1,!p1)
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		jump .LBB15_131
		memw(r29+#252) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_130:                             // %land.end.thread
	{
		p2 = or(p2,!p2)
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		r1 = p2
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p2
		memw(r29+#252) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#284) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_131:                             // %if.end470
	{
		r0 = memw(r29+#44)
		r2 = memw(r26+#60)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#204) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_134
	}
// %bb.132:                             // %if.then474
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.133:                             // %if.then474
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_134:                             // %do.end478
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.135:                             // %do.end478
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_138
	}
// %bb.136:                             // %if.then481
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.137:                             // %if.then481
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r5:4 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_138:                             // %for.body493.lr.ph
	{
		r3 = memw(r29+#64)
		memw(r29+#160) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r3,#13)
		r1 = asl(r3,#9)
		r0 = memw(r29+#36)
		memw(r29+#236) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r0,#11,#0)
		r0 = asl(r3,#7)
		r1 = memw(r29+#120)
		memw(r29+#272) = r1
	}                                       // 4-byte Folded Reload
	{
		r0 = #0
		p2 = cmp.gtu(r1,#63)
		memw(r29+#276) = r0
		memw(r29+#260) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#208) = r2.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#144) = r0
		memw(r29+#196) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#140) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_139:                             // %for.body493
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB15_168 Depth 2
                                        //       Child Loop BB15_169 Depth 3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
                                        //     Child Loop BB15_158 Depth 2
	{
		r2 = add(r29,#312)
		r3 = memw(r26+#44)
		r0 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r3,#0)
		r18 = memw(r29+#144)
		r7 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r4 = memw(r29+#140)
		r1 = memw(r26+#48)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r2 = insert(r5,#1,#2)
		r6 = add(r5,#1)
		if (!p0) r18 = memw(r3+r4<<#2)
		r4 = memw(r0+#0)
	}
	{
		r3 = addasl(r1,r5,#2)
		p0 = cmp.eq(r1,#0)
		p1 = cmp.gtu(r17,r6)
		memw(r29+#168) = r6
	}                                       // 4-byte Folded Spill
	{
		r7 += mpyi(r4,#96)
		r2 = memw(r2+#0)
		memw(r29+#172) = r2.new
	}                                       // 4-byte Folded Spill
	{
		if (p0) r3 = add(r7,#32)
		if (p1) r22 = memw(r29+#68)
		memw(r29+#100) = r7
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r7+#32)
		r0 = memw(r3+#0)
	}
	{
		if (!p1) jump:nt .LBB15_143
		if (p1) r25 = memw(r29+#168)
		memw(r29+#152) = r0
	}                                       // 4-byte Folded Reload
// %bb.140:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r3 = memw(r29+#116)
		r2 = memw(r16+r25<<#2)
	}                                       // 4-byte Folded Reload
	{
		r22 += mpyi(r2,#96)
	}
	{
		r2 = memw(r22+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r23 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r23
	}
	.falign
// %bb.141:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = add(r29,#312)
		r24 = r0
	}
	{
		r2 = insert(r25,#1,#2)
		r1:0 = combine(r24,r23)
		r23 = memw(r22+#4)
	}
	{
		call __hexagon_udivsi3
		r22 = memw(r2+#0)
	}
	.falign
// %bb.142:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5:4 = combine(r0,r24)
		r1 = r23
		r2 = memw(r29+#36)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r0 = add(r2,r22)
		r3:2 = combine(r24,r24)
		memw(r29+#0) = #0
	}
	.falign
.LBB15_143:                             // %if.end540
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB15_145
	}
// %bb.144:                             // %for.body545.lr.ph
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5 = addasl(r20,r18,#2)
		r4 = lsr(r19,#5)
		p0 = cmp.gtu(r19,#31); if (p0.new) jump:t .LBB15_167
	}
	.falign
.LBB15_145:                             // %do.body933
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_148
	}
// %bb.146:                             // %if.then935
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.147:                             // %if.then935
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_148:                             // %do.end939
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.149:                             // %do.end939
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_152
	}
// %bb.150:                             // %if.then942
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.151:                             // %if.then942
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_152:                             // %do.end948
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_164
	}
// %bb.153:                             // %do.body952
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_156
	}
// %bb.154:                             // %if.then954
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.155:                             // %if.then954
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_156:                             // %do.end958
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r2+#20)
		r23 = memw(r2+#32)
	}
	{
		r18 = asl(r23,#8)
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB15_160
		if (!p1.new) r22 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
// %bb.157:                             // %for.body967.preheader
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r19 = #0
		r27 = memw(r29+#60)
		r25 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_158:                             // %for.body967
                                        //   Parent Loop BB15_139 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = #64
		r1:0 = combine(r23,r25)
		r3 = r23
		r5:4 = combine(r27,r24)
	}
	{
		r2 = minu(r22,r2)
		call hexkl_wh_affine_acc
	}
	.falign
// %bb.159:                             // %for.body967
                                        //   in Loop: Header=BB15_158 Depth=2
	{
		r19 = add(r19,#64)
		r22 = add(r22,#-64)
		r27 = add(r27,#256)
		r25 = add(r25,r18)
	}
	{
		r2 = memw(r29+#40)
		if (cmp.gtu(r2.new,r19)) jump:t .LBB15_158
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_160:                             // %if.end988
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
		r3 = memw(r26+#12)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#72)
		r1 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r2 = memw(r29+#144)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r20,r2,#2)
		memw(r29+#12) = r2.new
	}
	{
		r3 = r23
		r2 = memw(r29+#80)
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r4
		memw(r29+#0) = r5
	}
	{
		call hvx_dequant_i32_to_f32
		r4 = memw(r29+#136)
		r5 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.161:                             // %if.end988
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_164
	}
// %bb.162:                             // %if.then997
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.163:                             // %if.then997
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_164:                             // %if.end1004
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
	}
	{
		r3 = memw(r26+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_166
	}
// %bb.165:                             // %if.then1010
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r4 = memw(r29+#140)
		r0 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r4 = addasl(r0,r3,#2)
		memw(r29+#204) = r4.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_166:                             // %for.inc1022
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5 = memw(r29+#168)
		memw(r29+#140) = r5.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r5,r17)
		if (p0.new) r24 = #0
		r3 = memw(r29+#40)
		r4 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r2,r3)
		r2 = add(r0,#4)
		memw(r29+#144) = r4.new
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB15_139
		memw(r29+#160) = r2
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_266
	}
	.falign
.LBB15_167:                             // %for.body545.us.preheader
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#36)
		r3 = memw(r29+#172)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r2)
		r1 = #0
		r0 = memw(r29+#152)
		memw(r29+#224) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r0,#8)
		r0 = #0
		r1 = memw(r29+#88)
		memw(r29+#308) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r4,#23,#0)
		r0 = memw(r29+#260)
		memw(r29+#228) = r0
	}                                       // 4-byte Folded Reload
	{
		r3 = or(r0,and(r3,#127))
		r2 = asl(r2,#9)
		memw(r29+#184) = r3
		memw(r29+#200) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#268) = r5
		memw(r29+#264) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#296) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#48) = r2
		memw(r29+#52) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_168:                             // %for.body545.us
                                        //   Parent Loop BB15_139 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB15_169 Depth 3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
	{
		r4 = #0
		r5 = memw(r29+#228)
		r3 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		r6 = asl(r5,#7)
		r2 = asl(r5,#6)
		r1 = memw(r29+#196)
		memw(r29+#304) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r5)
		p1 = tstbit(r1,#0)
		r6 = memw(r29+#152)
		memw(r29+#232) = r4
	}                                       // 4-byte Folded Reload
	{
		r4 = p1
		r0 = memw(r29+#40)
		memw(r29+#248) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r6 = mpyi(r2,r6)
		r4 = asl(r5,#8)
		p1 = cmp.gtu(r0,r2)
		r5 = sub(r0,r2)
	}
	{
		r2 = mpyi(r2,r21)
		r0 = memw(r29+#60)
		memw(r29+#300) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r4)
		r0 = #64
		r1 = memw(r29+#136)
		memw(r29+#164) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r5 = minu(r5,r0)
		r2 = add(r1,r4)
		r1 = memw(r29+#264)
		memw(r29+#240) = r1.new
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r5 = #0
		r0 = memw(r29+#212)
		memw(r29+#188) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r4)
		r0 = #0
		r1 = memw(r29+#36)
		memw(r29+#192) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,r3)
		r0 = #0
		r1 = memw(r29+#200)
		memw(r29+#216) = r0
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r5,#0)
		r1 = memw(r29+#268)
		memw(r29+#220) = r1
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r6,#2)
		r0 = p0
		memw(r29+#180) = r2
		memw(r29+#156) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#292) = r2
		memw(r29+#132) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#280) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_169:                             // %for.body566.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
	{
		r18 = #0
		r0 = memw(r29+#196)
		r2 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r5 = and(r0,#1)
		r3 = memw(r29+#156)
		r1 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r3)
		r0 = memw(r29+#220)
		memw(r29+#256) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r1)
		r19 = minu(r1,r0)
		r1 = memw(r29+#236)
		memw(r29+#176) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r4 = memw(r29+#84)
		r27 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r1,r5)
		r0 = p0
		memw(r29+#148) = r4.new
	}                                       // 4-byte Folded Spill
	{
		if (p0) jump:nt .LBB15_189
		memw(r29+#244) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_170:                             // %for.body583.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Loop Header: Depth=4
                                        //           Child Loop BB15_175 Depth 5
	{
		r2 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r22 = r2
		memw(r29+#120) = r22.new
	}                                       // 4-byte Folded Spill
	.falign
// %bb.171:                             // %for.body583.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = r22
	}
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_174
		if (!p0.new) r0 = memw(r29+#180)
		if (!p0.new) r1 = memw(r29+#184)
	}                                       // 4-byte Folded Reload
// %bb.172:                             // %if.then585.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r18,r2)
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		r1 += asl(r3,#9)
		call lfm2_fc_issue_aligned
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.173:                             // %if.then585.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		jump .LBB15_180
	}
	.falign
.LBB15_174:                             // %for.cond597.preheader.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#76)
		r25 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,#31); if (!p0.new) jump:t .LBB15_180
		r23 = memw(r29+#172)
		r22 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_175:                             // %for.body601.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        //         Parent Loop BB15_170 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		r5 = #384
		r4 = #31
		r2 = memw(r29+#52)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r25)
		if (p1.new) r2 = add(r23,#0)
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB15_178
	}
// %bb.176:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		call hexkl_micro_hmx_mm_u8i4
		r2 = add(r27,r23)
		r1 = r25
	}
	.falign
// %bb.177:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:t .LBB15_179
	}
	{
		jump .LBB15_239
	}
	.falign
.LBB15_178:                             // %mm_u8i4_tile.exit.thread.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		r2 += add(r0,r27)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	.falign
.LBB15_179:                             // %for.inc620.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		r25 = add(r25,#2048)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r23 = add(r23,r2)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB15_175
	}
	.falign
.LBB15_180:                             // %do.body626.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_183
	}
// %bb.181:                             // %if.then628.us
                                        //   in Loop: Header=BB15_170 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.182:                             // %if.then628.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_183:                             // %do.end632.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#148)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r18,#13)
		call hexkl_micro_hmx_acc_read_int32
		r1 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.184:                             // %do.end632.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r24 = r0
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_187
	}
// %bb.185:                             // %if.then638.us
                                        //   in Loop: Header=BB15_170 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.186:                             // %if.then638.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB15_187:                             // %do.end644.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r27 = add(r27,#512)
		p0 = cmp.eq(r24,#0)
		if (!p0.new) jump:nt .LBB15_240
	}
// %bb.188:                             // %for.cond579.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r18 = add(r18,#1)
		if (!cmp.eq(r18.new,r19)) jump:t .LBB15_170
	}
	.falign
.LBB15_189:                             // %for.end653.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#100)
		r3 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r18 = add(r0,r3)
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_193
	}
// %bb.190:                             // %land.lhs.true656.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r22 = r19
		r24 = r18
		r2 = memw(r29+#56)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r0 = memw(r29+#252)
		r23 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p0)
		p2 = r0
		r2 = memw(r2+#4)
	}
	{
		p0 = cmp.eq(r2,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = and(p2,and(p0,p1))
		if (!p1.new) jump:t .LBB15_193
	}
	.falign
.LBB15_191:                             // %for.body667.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r2 = memw(r29+#56)
		r3 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r3 = #32
		r4 = memw(r2+#8)
		r6 = memw(r3+#20)
	}
	{
		r0 = addasl(r24,r4,#2)
		r4 = add(r6,r23)
		r1 = memw(r2+#12)
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_acc
		r5 = memw(r29+#164)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.192:                             // %for.body667.us
                                        //   in Loop: Header=BB15_191 Depth=4
	{
		r23 = add(r23,#128)
		r24 = add(r24,#8192)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB15_191
	}
	.falign
.LBB15_193:                             // %if.end682.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB15_207
		if (!p0.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.194:                             // %if.else820.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_218
	}
// %bb.195:                             // %for.cond825.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_237
		if (!p2.new) r2 = memw(r29+##280)
	}                                       // 4-byte Folded Reload
// %bb.196:                             // %for.cond825.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		p2 = r2
		if (!p2.new) r19 = #0
		if (p2.new) jump:nt .LBB15_237
		if (!p2.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.197:                             // %for.body834.lr.ph.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r24 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_198:                             // %for.body834.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB15_201
		r22 = memw(r0+#8)
	}
// %bb.199:                             // %if.then844.us
                                        //   in Loop: Header=BB15_198 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.200:                             // %if.then844.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_201:                             // %do.end848.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r0 = asl(r22,#2)
		r2 = memw(r29+#56)
		r4 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r18,r0)
		r5 = memw(r26+#12)
		r6 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r2+#12)
		r3:2 = memd(r4+#8)
	}
	{
		r2 = add(r2,r24)
		r5 = add(r3,r24)
		r4 = memw(r4+#16)
		memw(r29+#16) = r5

	} :mem_noshuf
	{
		r3 = add(r4,r24)
		r2 = memw(r29+#132)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#188)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#192)
		memw(r29+#12) = r6
	}                                       // 4-byte Folded Reload
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#8) = r25
	}
	.falign
// %bb.202:                             // %do.end848.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_205
	}
// %bb.203:                             // %if.then864.us
                                        //   in Loop: Header=BB15_198 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.204:                             // %if.then864.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_206
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_205:                             //   in Loop: Header=BB15_198 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_206:                             // %do.end870.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r19 = add(r19,#1)
		r24 = add(r24,#128)
		r18 = add(r18,#8192)
		r25 = add(r25,#128)
	}
	{
		r3 = memw(r29+#176)
		if (cmp.gtu(r3.new,r19)) jump:t .LBB15_198
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_237
	}
	.falign
.LBB15_207:                             // %do.body685.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_210
	}
// %bb.208:                             // %if.then687.us
                                        //   in Loop: Header=BB15_169 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.209:                             // %if.then687.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_210:                             // %do.end691.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		call hvx_worker_pool_wait
		r0 = memw(r26+#0)
	}
	.falign
// %bb.211:                             // %do.end691.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_214
	}
// %bb.212:                             // %if.then695.us
                                        //   in Loop: Header=BB15_169 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.213:                             // %if.then695.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_214:                             // %do.end701.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_237
	}
// %bb.215:                             // %if.then704.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r3 = add(r29,#328)
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r2,#68)
		r2 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) r2 = #0
		if (!p2.new) jump:t .LBB15_230
		if (p2.new) r5 = memw(r26+#56)
	}
// %bb.216:                             // %land.lhs.true711.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r4 = #0
		p1 = cmp.eq(r5,#0)
		if (!p1.new) r2 = memw(r29+#140)
		r6 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r2 = memw(r5+r2<<#2)
	}
	{
		r5 = memw(r26+#72)
		memw(r3+#12) = r2
	}
	{
		r0 = memw(r29+#140)
		memw(r3+#0) = r6
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r5,r0)
		r5 = memw(r26+#64)
		memw(r3+#20) = r5.new
	}
	{
		if (!p0) jump:nt .LBB15_231
		r5 = memw(r26+#68)
		memw(r3+#16) = r5.new
	}
// %bb.217:                             // %cond.true727.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r6 = memw(r29+#304)
		r4 = memw(r26+#76)
	}                                       // 4-byte Folded Reload
	{
		r5 = mpyi(r6,r5)
	}
	{
		r4 = addasl(r4,r5,#2)
		jump .LBB15_231
	}
	.falign
.LBB15_218:                             // %for.cond877.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_237
		if (!p1.new) r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.219:                             // %do.body882.us.preheader
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = +mpyi(r2,#1)
		r3 = memw(r3+##hexkl_probe_on@GOT)
		r27 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#248)
		r0 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p0 = r5
		if (!p0.new) r2 = add(r4,#0)
	}
	{
		r25 = add(r0,r2)
		r2 = memw(r3+#0)
	}
	.falign
.LBB15_220:                             // %do.body882.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_223
	}
// %bb.221:                             // %if.then884.us
                                        //   in Loop: Header=BB15_220 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.222:                             // %if.then884.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_223:                             // %do.end888.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r1 = r25
		r4 = r27
		r0 = memw(r29+#36)
		r5 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#100)
		r3 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
		memw(r29+#0) = r2.new
	}
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.224:                             // %do.end888.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r24 = r0
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_227
	}
// %bb.225:                             // %if.then896.us
                                        //   in Loop: Header=BB15_220 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.226:                             // %if.then896.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_228
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_227:                             //   in Loop: Header=BB15_220 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_228:                             // %do.end902.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r27 = add(r27,#1)
		r25 = add(r25,#8192)
		p0 = cmp.eq(r24,#0)
		if (!p0.new) jump:nt .LBB15_240
	}
// %bb.229:                             // %for.cond877.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB15_220
	}
	{
		jump .LBB15_237
	}
	.falign
.LBB15_230:                             // %cond.end718.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#204)
		memw(r3+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r26+#64)
		memw(r3+#20) = r2.new
	}
	{
		r2 = memw(r26+#68)
		memw(r3+#16) = r2.new
	}
	{
		r2 = #0
		memw(r3+#12) = #0
	}
	.falign
.LBB15_231:                             // %cond.end733.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 = memw(r29+#176)
		memw(r3+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r5,#5)
		memw(r3+#8) = r5.new
	}
	{
		r5 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		p1 = r5
		if (p1.new) r6 = #0
		if (!p1.new) jump:t .LBB15_233
		if (!p1.new) r5 = memw(r26+#80)
	}
// %bb.232:                             // %cond.end742.us.thread
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 = memw(r26+#84)
		memw(r3+#28) = r5.new
	}
	{
		r5 = #0 ; jump .LBB15_234
		memw(r3+#24) = #0
		memw(r3+#32) = #0
	}
	.falign
.LBB15_233:                             // %cond.true753.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r7 = memw(r29+#296)
		r6 = memw(r26+#84)
	}                                       // 4-byte Folded Reload
	{
		memw(r3+#32) = r7
	}
	{
		r7 = memw(r29+#300)
		memw(r3+#28) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r7,#2)
		r6 = memw(r26+#44)
		memw(r3+#24) = r5.new
	}
	{
		r7 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r6+r7<<#2)
		r7 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r7,#5)
	}
	.falign
.LBB15_234:                             // %cond.end759.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 |= or(r2,r4)
		r7 = memw(r29+#168)
		r9 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(pc,##fc_row_post@PCREL)
		r0 = cmp.eq(r9,#0)
		r1 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r7,r17)
		r6 = or(r9,r1)
		r12 = memw(r29+#176)
		memw(r3+#36) = r6
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r12,r9)
		r6 = cmp.eq(r6,#0)
		r0 = memw(r29+#256)
		memw(r3+#52) = r0
	}                                       // 4-byte Folded Reload
	{
		r8 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,r8)
		r2 = cmp.eq(r2,r8)
		r1 = memw(r26+#88)
		memw(r3+#60) = r1.new
	}
	{
		r7 = +mpyi(r0,#76)
		p1 = and(p0,p1)
		r1 = memw(r26+#92)
		memw(r3+#44) = r6
	}
	{
		r6 = add(r29,#464)
		p0 = cmp.eq(r5,#0)
		memw(r3+#56) = r2
	}
	{
		r2 = add(r6,r7)
		if (p0) r4 = #0
		r1 = memw(r29+#56)
		memw(r3+#64) = r1
	}                                       // 4-byte Folded Reload
	{
		r5 = mux(p1,#1,#0)
		memw(r3+#40) = r21
		memw(r2+#60) = r4
	}
	{
		memw(r2+#64) = r3
		memw(r3+#48) = r5
	}
	{
		r3 = memw(r29+#36)
		r0 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r0)
		r0 = memw(r1+#8)
		memw(r2+#4) = ##8192

	} :mem_noshuf
	{
		r3 = addasl(r3,r0,#2)
		memw(r6+r7<<#0) = r3.new
	}
	{
		memw(r2+#8) = r9
		r3 = memw(r1+#12)

	} :mem_noshuf
	{
		r7 = memw(r29+#132)
		memw(r2+#12) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#188)
		memw(r2+#16) = r7
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#100)
		memw(r2+#20) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#192)
		memw(r2+#44) = #0
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r3+#8)
		memw(r2+#24) = r6
	}
	{
		r5:4 = memd(r3+#16)
		memw(r2+#56) = r12
	}
	{
		p1 = cmp.eq(r5,#0)
		r3 = memw(r3+#32)
		memw(r2+#28) = r1
	}
	{
		r3 = memw(r29+#152)
		memw(r2+#48) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#44)
		memw(r2+#52) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#292)
		memw(r2+#36) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#32) = r0
		memw(r2+#40) = r4
	}
	{
		if (p1) jump:nt .LBB15_236
		r1 = memw(r3+##hvx_dq_tiles_rows_worker@GOT)
	}
// %bb.235:                             // %if.then811.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r1 = add(pc,##fc_affine_worker@PCREL)
		r3 = memw(r29+#164)
		memw(r2+#68) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#72) = r3
	}
	.falign
.LBB15_236:                             // %for.inc919.us.sink.split
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		call hvx_worker_pool_submit
		r0 = memw(r26+#0)
		r3 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_237:                             // %for.inc919.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#64)
		r4 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r2)
		r3 = memw(r29+#196)
		r0 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		p0 = cmp.gtu(r0,r4)
		r1 = memw(r29+#220)
		memw(r29+#196) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r1,r2)
		r1 = memw(r29+#272)
		memw(r29+#220) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#216)
		memw(r29+#156) = r4
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		r0 = memw(r29+#248)
		memw(r29+#216) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r2 = memw(r29+#276)
		r1 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p2)
		r3 = add(r1,r2)
		r0 = memw(r29+#240)
		memw(r29+#232) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r1 = p2
		r3 = add(r0,r2)
		if (!p0) r0 = memw(r29+#124)
		memw(r29+#248) = r1.new
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB15_169
		if (!p0) r3 = memw(r29+#228)
		memw(r29+#240) = r3
	}                                       // 4-byte Folded Reload
// %bb.238:                             // %for.cond562.for.inc928_crit_edge.us
                                        //   in Loop: Header=BB15_168 Depth=2
	{
		r3 = add(r3,#1)
		r2 = memw(r29+#128)
		memw(r29+#228) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r3,r2)
		r1 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r1,r0)
		r0 = memw(r29+#296)
		memw(r29+#224) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,#8192)
		r1 = memw(r29+#308)
		memw(r29+#296) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		if (!p1) jump:nt .LBB15_168
		memw(r29+#264) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_145
	}
	.falign
.LBB15_239:
	{
		r24 = r0
	}
	.falign
.LBB15_240:                             // %do.body1027
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_243
	}
// %bb.241:                             // %if.then1029
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.242:                             // %if.then1029
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_243:                             // %do.end1033
	{
		call hvx_worker_pool_wait
		r0 = memw(r26+#0)
	}
	.falign
// %bb.244:                             // %do.end1033
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_247
	}
// %bb.245:                             // %if.then1037
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.246:                             // %if.then1037
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_247:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.248:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.249:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.250:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.251:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.252:                             // %cleanup1044
	{
		jump .LBB15_38
	}
	.falign
.LBB15_253:                             // %land.end411
	{
		p1 = and(p1,!p1)
		r2 = memw(r26+#52)
	}
	{
		r0 = p1
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_265
		memw(r29+#252) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.254:                             // %for.body422.lr.ph
	{
		p0 = or(p0,!p0)
		r25 = #1
		r2 = memw(r29+#64)
		r18 = memw(r26+#56)
	}                                       // 4-byte Folded Reload
	{
		r23 = asl(r2,#5)
		r1 = p0
		p0 = cmp.eq(r18,#0)
		r19 = memw(r26+#72)
	}
	{
		r0 = p0
		memw(r29+#284) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#48) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_255:                             // %for.body422
                                        // =>This Inner Loop Header: Depth=1
	{
		r24 = #0
		r1 = #0
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = add(r25,#-1)
		if (!p2.new) r1 = memw(r18+#0)
	}
	{
		p1 = cmp.gtu(r19,r2)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB15_258
		if (p1.new) r24 = memw(r26+#68)
	}
// %bb.256:                             // %lor.lhs.false444
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		call __hexagon_umodsi3
		r0 = r23
	}
	.falign
// %bb.257:                             // %lor.lhs.false444
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB15_267
	}
	.falign
.LBB15_258:                             // %land.rhs448
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p0 = or(p0,!p0)
		p1 = cmp.eq(r24,#0)
		if (!p1.new) r1:0 = combine(r24,r23)
		if (p1.new) jump:nt .LBB15_261
	}
// %bb.259:                             // %lor.rhs
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.260:                             // %lor.rhs
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p0 = cmp.eq(r0,#0)
	}
	.falign
.LBB15_261:                             // %land.end454
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		if (p0) r18 = add(r18,#4)
		if (!p0) jump:nt .LBB15_263
	}
// %bb.262:                             // %land.end454
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p1 = cmp.gtu(r17,r25)
		r25 = add(r25,#1)
		if (p1.new) jump:t .LBB15_255
	}
	.falign
.LBB15_263:                             // %for.cond.cleanup421
	{
		if (!p0) jump:nt .LBB15_268
		if (p0) r3 = memw(r26+#52)
		if (p0) r2 = memw(r26+#80)
	}
// %bb.264:                             // %if.then468
	{
		p0 = or(p0,!p0)
		p2 = cmp.eq(r2,#0)
	}
	{
		r0 = p0
		memw(r29+#288) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#284) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_131
		memw(r3+#0) = #1
	}
	.falign
.LBB15_265:
	{
		p2 = and(p2,!p2)
	}
	{
		r2 = p2
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_266:
	{
		jump .LBB15_240
	}
	.falign
.LBB15_267:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_268:
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
.Lfunc_end15:
	.size	hexkl_mm_u8i4_layer_run, .Lfunc_end15-hexkl_mm_u8i4_layer_run
                                        // -- End function
	.falign
	.type	lfm2_fc_hmx_issue_ok,@function  // -- Begin function lfm2_fc_hmx_issue_ok
lfm2_fc_hmx_issue_ok:                   // @lfm2_fc_hmx_issue_ok
// %bb.0:                               // %entry
	{
		p0 = cmp.gtu(r2,#1)
		r7 = #0
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		if (!p0) jump:nt .LBB16_4
	}
// %bb.1:                               // %entry
	{
		r9 = #2048
		if (!cmp.eq(r9.new,r3)) jump:nt .LBB16_4
	}
// %bb.2:                               // %lor.lhs.false2
	{
		r3 = setbit(r5,#1)
		if (!cmp.eq(r3.new,#3)) jump:nt .LBB16_4
	}
// %bb.3:                               // %lor.lhs.false5
	{
		r3 = memw(r29+#32)
	}
	{
		r6 = memw(r3+#16)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB16_5
	}
	.falign
.LBB16_4:                               // %return
	{
		r0 = r7
		r17:16 = memd(r29+#16)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB16_5:                               // %lor.lhs.false6
	{
		r6 = memw(r3+#32)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB16_4
	}
// %bb.6:                               // %lor.lhs.false8
	{
		r3 = memw(r3+#12)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB16_4
	}
// %bb.7:                               // %lor.lhs.false10
	{
		r3 = #2047
	}
	{
		p0 = !bitsclr(r1,r3)
		if (!p0.new) r3 = add(r29,#0)
		if (p0.new) jump:t .LBB16_4
		if (!p0.new) r6 = memw(r29+#48)
	}
// %bb.8:                               // %for.body.lr.ph
	{
		r17:16 = combine(#0,#0)
		r13 = r5
		r8 = memw(r29+#44)
		r12 = memw(r29+#52)
	}
	{
		r14 = memw(r29+#40)
		memd(r29+#0) = r17:16
	}
	{
		r10 = memw(r29+#36)
		memw(r29+#8) = #0
	}
	.falign
.LBB16_9:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r15 = #4095
	}
	{
		r15 = memw(r4+#0)
		if (cmp.gtu(r15.new,r15)) jump:nt .LBB16_4
	}
// %bb.10:                              // %if.end15
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r15 = +mpyi(r15,#96)
	}
	{
		r28 = memw(r0+r15<<#0)
		if (cmp.eq(r28.new,#0)) jump:nt .LBB16_4
	}
// %bb.11:                              // %lor.lhs.false19
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r15 = add(r0,r15)
	}
	{
		r28 = memw(r15+#28)
		if (!cmp.eq(r28.new,r9)) jump:nt .LBB16_4
	}
// %bb.12:                              // %lor.lhs.false22
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r28 = memw(r15+#84)
		if (!cmp.eq(r28.new,#4)) jump:nt .LBB16_4
	}
// %bb.13:                              // %lor.lhs.false24
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r28 = memw(r15+#20)
		if (cmp.eq(r28.new,#0)) jump:nt .LBB16_4
	}
// %bb.14:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r28 = memw(r15+#44)
		if (!cmp.eq(r28.new,#0)) jump:nt .LBB16_4
	}
// %bb.15:                              // %lor.lhs.false28
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		r15 = memw(r15+#32)
	}
	{
		r17:16 = combine(#0,r15)
	}
	{
		r17:16 = asl(r17:16,#10)
	}
	{
		p1 = cmp.gtu(r17:16,r7:6)
		if (!p1.new) r4 = add(r4,#4)
		if (!p1.new) r13 = add(r13,#-1)
		if (p1.new) jump:nt .LBB16_4
	}
// %bb.16:                              // %for.inc
                                        //   in Loop: Header=BB16_9 Depth=1
	{
		p0 = cmp.eq(r13,#0)
		memw(r3++#4) = r15
	}
	{
		if (!p0) jump:nt .LBB16_9
	}
// %bb.17:                              // %for.end
	{
		r3 = #512
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB16_20
		r4 = memw(r29+#0)
	}
// %bb.18:                              // %land.lhs.true41
	{
		p0 = cmp.eq(r4,r3); if (p0.new) jump:nt .LBB16_26
	}
// %bb.19:                              // %land.lhs.true41
	{
		p1 = cmp.eq(r4,r9)
		if (p1.new) jump:t .LBB16_26
	}
	{
		jump .LBB16_4
	}
	.falign
.LBB16_20:                              // %lor.lhs.false49
	{
		p0 = cmp.eq(r5,#3); if (!p0.new) jump:nt .LBB16_4
	}
// %bb.21:                              // %lor.lhs.false49
	{
		p1 = cmp.eq(r4,r9)
		if (!p1.new) jump:nt .LBB16_4
		if (p1.new) r4 = memw(r29+#8)
		if (p1.new) r5 = memw(r29+#4)
	}
// %bb.22:                              // %land.lhs.true56
	{
		p0 = cmp.eq(r5,r9)
		if (!p0.new) jump:nt .LBB16_24
	}
// %bb.23:                              // %land.lhs.true56
	{
		p1 = cmp.eq(r4,r9)
		if (p1.new) jump:t .LBB16_26
	}
	.falign
.LBB16_24:                              // %lor.lhs.false64
	{
		p0 = cmp.eq(r5,r3); if (!p0.new) jump:nt .LBB16_4
	}
// %bb.25:                              // %lor.lhs.false64
	{
		p1 = cmp.eq(r4,r3); if (!p1.new) jump:nt .LBB16_4
	}
	.falign
.LBB16_26:                              // %if.end73
	{
		r1 = #0
		r0 = ##129024
		r3 = #0
	}
	{
		r1:0 += asl(r3:2,#11)
		r4 = ##-131072
		r5 = #4095
	}
	{
		r1:0 = and(r1:0,r5:4)
		r11 = #0
		r7 = #0
	}
	{
		p0 = cmp.eq(r1:0,r11:10)
		if (!p0.new) jump:nt .LBB16_4
	}
// %bb.27:                              // %if.end73
	{
		p1 = cmp.gtu(r10,r12)
		if (!p1.new) r15 = #0
		if (p1.new) jump:nt .LBB16_4
	}
// %bb.28:                              // %if.end73
	{
		r1:0 = combine(#0,r6)
		p0 = cmp.gtu(r10,r14)
		if (!p0.new) r9 = #0
		if (p0.new) jump:nt .LBB16_4
	}
// %bb.29:                              // %land.lhs.true87
	{
		r3:2 = add(r1:0,r15:14)
	}
	{
		p1 = cmp.gtu(r3:2,r9:8)
		if (!p1.new) r2 = #127
		if (p1.new) jump:t .LBB16_4
	}
// %bb.30:                              // %land.lhs.true96
	{
		p0 = !bitsclr(r14,r2)
		if (!p0.new) r13 = add(r7,#0)
		if (p0.new) jump:nt .LBB16_4
	}
// %bb.31:                              // %land.lhs.true96
	{
		r1:0 = add(r1:0,r9:8)
	}
	{
		p1 = cmp.gtu(r1:0,r13:12)
		if (p1.new) jump:nt .LBB16_4
	}
// %bb.32:                              // %land.rhs
	{
		r2 = and(r8,#127)
	}
	{
		r7 = cmp.eq(r2,#0)
	}
	{
		r0 = r7
		r17:16 = memd(r29+#16)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end16:
	.size	lfm2_fc_hmx_issue_ok, .Lfunc_end16-lfm2_fc_hmx_issue_ok
                                        // -- End function
	.falign
	.type	dma_row_size_dividing,@function // -- Begin function dma_row_size_dividing
dma_row_size_dividing:                  // @dma_row_size_dividing
// %bb.0:                               // %entry
	{
		r2 = ##262143
	}
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r2 = ##131071
		if (p0.new) jump:nt .LBB17_18
	}
// %bb.1:                               // %while.body
	{
		p1 = bitsclr(r0,r2)
		if (!p1.new) r2 = ##65535
		if (p1.new) jump:nt .LBB17_19
	}
// %bb.2:                               // %while.body.1
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r3 = ##32767
		if (p0.new) jump:nt .LBB17_20
	}
// %bb.3:                               // %while.body.2
	{
		p1 = bitsclr(r0,r3)
		if (!p1.new) r2 = ##16383
		if (p1.new) jump:nt .LBB17_21
	}
// %bb.4:                               // %while.body.3
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r2 = ##8191
		if (p0.new) jump:nt .LBB17_22
	}
// %bb.5:                               // %while.body.4
	{
		p1 = bitsclr(r0,r2)
		if (!p1.new) r2 = ##4095
		if (p1.new) jump:nt .LBB17_23
	}
// %bb.6:                               // %while.body.5
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r2 = #2047
		if (p0.new) jump:nt .LBB17_24
	}
// %bb.7:                               // %while.body.6
	{
		p1 = bitsclr(r0,r2)
		if (!p1.new) r2 = #1023
		if (p1.new) jump:nt .LBB17_25
	}
// %bb.8:                               // %while.body.7
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r2 = #511
		if (p0.new) jump:nt .LBB17_26
	}
// %bb.9:                               // %while.body.8
	{
		p1 = bitsclr(r0,r2)
		if (!p1.new) r2 = #255
		if (p1.new) jump:nt .LBB17_27
	}
// %bb.10:                              // %while.body.9
	{
		p0 = bitsclr(r0,r2)
		if (!p0.new) r2 = #127
		if (p0.new) jump:nt .LBB17_28
	}
// %bb.11:                              // %while.body.10
	{
		p1 = bitsclr(r0,r2)
		if (p1.new) jump:nt .LBB17_29
	}
// %bb.12:                              // %while.body.11
	{
		p0 = bitsclr(r0,#63)
		if (p0.new) jump:nt .LBB17_30
	}
// %bb.13:                              // %while.body.12
	{
		p1 = bitsclr(r0,#31)
		if (p1.new) jump:nt .LBB17_31
	}
// %bb.14:                              // %while.body.13
	{
		p0 = bitsclr(r0,#15)
		if (p0.new) jump:nt .LBB17_32
	}
// %bb.15:                              // %while.body.14
	{
		p1 = bitsclr(r0,#7)
		if (p1.new) jump:nt .LBB17_33
	}
// %bb.16:                              // %while.body.15
	{
		p1 = tstbit(r0,#0)
		p0 = bitsclr(r0,#3)
		if (p0.new) jump:nt .LBB17_34
	}
// %bb.17:                              // %while.body.16
	{
		r0 = mux(p1,#1,#2)
		jumpr r31
	}
	.falign
.LBB17_18:
	{
		r0 = ##262144
		jumpr r31
	}
	.falign
.LBB17_19:
	{
		r0 = ##131072
		jumpr r31
	}
	.falign
.LBB17_20:
	{
		r0 = add(r2,#1)
		jumpr r31
	}
	.falign
.LBB17_21:
	{
		r0 = add(r2,#-32767)
		jumpr r31
	}
	.falign
.LBB17_22:
	{
		r0 = #16384
		jumpr r31
	}
	.falign
.LBB17_23:
	{
		r0 = #8192
		jumpr r31
	}
	.falign
.LBB17_24:
	{
		r0 = #4096
		jumpr r31
	}
	.falign
.LBB17_25:
	{
		r0 = #2048
		jumpr r31
	}
	.falign
.LBB17_26:
	{
		r0 = #1024
		jumpr r31
	}
	.falign
.LBB17_27:
	{
		r0 = #512
		jumpr r31
	}
	.falign
.LBB17_28:
	{
		r0 = #256
		jumpr r31
	}
	.falign
.LBB17_29:
	{
		r0 = #128
		jumpr r31
	}
	.falign
.LBB17_30:
	{
		r0 = #64
		jumpr r31
	}
	.falign
.LBB17_31:
	{
		r0 = #32
		jumpr r31
	}
	.falign
.LBB17_32:
	{
		r0 = #16
		jumpr r31
	}
	.falign
.LBB17_33:
	{
		r0 = #8
		jumpr r31
	}
	.falign
.LBB17_34:
	{
		r0 = #4
		jumpr r31
	}
.Lfunc_end17:
	.size	dma_row_size_dividing, .Lfunc_end17-dma_row_size_dividing
                                        // -- End function
	.falign
	.type	fc_affine_sums_worker,@function // -- Begin function fc_affine_sums_worker
fc_affine_sums_worker:                  // @fc_affine_sums_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#256):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = memw(r2+#12)
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(#0,r0)
		r17:16 = combine(r1,r2)
		memd(r30+#-24) = r21:20
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r22,r1)
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r4 = add(r17,#1)
		r19:18 = combine(r1,r0)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r22,r4)
		call __hexagon_udivdi3
	}
	.falign
// %bb.2:                               // %entry
	{
		r3:2 = combine(#16,#8)
		p1 = cmp.gtu(r0,r18); if (!p1.new) jump:t .LBB18_22
		v0 = vxor(v0,v0)
	}
// %bb.3:                               // %for.body.lr.ph
	{
		r7 = #64
		r8 = ##16843009
		r5 = memw(r16+#16)
	}
	{
		r4 = memw(r16+#0)
		r6 = memw(r16+#20)
	}
	{
		v5 = valign(v0,v0,#4)
	}
	{
		v6.w = vadd(v0.w,v5.w)
	}
	{
		v7 = vror(v6,r2)
	}
	{
		v8.w = vadd(v6.w,v7.w)
	}
	{
		v9 = vror(v8,r3)
	}
	{
		v1.w = vadd(v8.w,v9.w)
	}
	.falign
.LBB18_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB18_12 Depth 2
                                        //       Child Loop BB18_14 Depth 3
                                        //       Child Loop BB18_18 Depth 3
                                        //     Child Loop BB18_7 Depth 2
                                        //       Child Loop BB18_8 Depth 3
	{
		r15 = asl(r18,#6)
	}
	{
		r13 = addasl(r6,r15,#2)
		r12 = memw(r16+#4)
		if (cmp.eq(r12.new,r15)) jump:t .LBB18_21
	}
// %bb.5:                               // %for.body.lr.ph.i
                                        //   in Loop: Header=BB18_4 Depth=1
	{
		r12 = addasl(r5,r15,#2)
		r14 = sub(r12,r15)
		r9 = memw(r16+#8)
	}
	{
		r10 = mpyi(r9,r15)
		r14 = minu(r14,r7)
		p1 = cmp.gtu(r9,#31)
		if (p1.new) jump:t .LBB18_11
	}
// %bb.6:                               // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB18_4 Depth=1
	{
		r15 = add(r14,#3)
		r28 = #1
	}
	{
		r1 = lsr(r15,#2)
		r15 = #0
	}
	{
		loop1(.LBB18_7,r1)
	}
	.falign
.LBB18_7:                               // Block address taken
                                        // %for.body.i
                                        //   Parent Loop BB18_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB18_8 Depth 3
	{
		r1 = addasl(r12,r15,#2)
		r10 = addasl(r13,r15,#2)
		r11 = add(r29,#0)
		r17 = #0
	}
	{
		vmem(r29+#0) = v1
	}
	.falign
.LBB18_8:                               // %for.body11.i
                                        //   Parent Loop BB18_4 Depth=1
                                        //     Parent Loop BB18_7 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r17,#2)
		r19 = memw(r1++#4)
		r20 = memw(r11+#0)
	}
	{
		r20 -= mpyi(r19,r9)
		if (p1) jump:nt .LBB18_10
		memw(r10++#4) = r20.new
	}
// %bb.9:                               // %for.body11.i
                                        //   in Loop: Header=BB18_8 Depth=3
	{
		r19 = add(r28,r17)
		r11 = add(r11,#32)
		r17 = add(r17,#1)
	}
	{
		p0 = cmp.gtu(r14,r19)
		if (p0.new) jump:t .LBB18_8
	}
	.falign
.LBB18_10:                              // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB18_7 Depth=2
	{
		r15 = add(r15,#4)
		r28 = add(r28,#4)
		nop
	} :endloop1
	{
		jump .LBB18_21
	}
	.falign
.LBB18_11:                              //   in Loop: Header=BB18_4 Depth=1
	{
		r15 = lsr(r9,#5)
		r10 = add(r4,r10)
		r28 = add(r14,#3)
		r1 = #1
	}
	{
		r11 = lsr(r28,#2)
		r28 = #0
	}
	{
		loop1(.LBB18_12,r11)
	}
	.falign
.LBB18_12:                              // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB18_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB18_14 Depth 3
                                        //       Child Loop BB18_18 Depth 3
	{
		r11 = addasl(r10,r28,#5)
		p0 = cmp.gtu(r15,#1)
		if (p0.new) r17 = add(r15,#-2)
		v2 = v0
	}
	{
		r11 = add(r11,#2048)
		if (!p0) jump:nt .LBB18_17
		v3 = vmemu(r11+#0)
	}
// %bb.13:                              // %for.body4.us.i
                                        //   in Loop: Header=BB18_12 Depth=2
	{
		p0 = cmp.gtu(r15,#2)
		v4 = vmemu(r11+#0)
	}
	{
		loop0(.LBB18_14,r17)
		r11 = add(r11,#2048)
		if (!p0) jump:nt .LBB18_15
		v2 = v0
	}
	.balign 32
.LBB18_14:                              // %for.body4.us.i
                                        //   Parent Loop BB18_4 Depth=1
                                        //     Parent Loop BB18_12 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
		v4 = vmemu(r11+#0)
	}
	{
		r11 = add(r11,#2048)
		nop
	} :endloop0
	.falign
.LBB18_15:                              //   in Loop: Header=BB18_12 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
	}
	.falign
.LBB18_17:                              //   in Loop: Header=BB18_12 Depth=2
	{
		r11 = addasl(r12,r28,#2)
		v2.uw += vrmpy(v3.ub,r8.ub)
		r19 = #0
		r20 = add(r29,#0)
	}
	{
		r17 = addasl(r13,r28,#2)
	}
	{
		v10 = valign(v2,v2,#4)
	}
	{
		v11.w = vadd(v2.w,v10.w)
	}
	{
		v12 = vror(v11,r2)
	}
	{
		v13.w = vadd(v11.w,v12.w)
	}
	{
		v14 = vror(v13,r3)
	}
	{
		v15.w = vadd(v13.w,v14.w)
		vmem(r29+#0) = v15.new
	}
	.falign
.LBB18_18:                              // %for.body11.us.i
                                        //   Parent Loop BB18_4 Depth=1
                                        //     Parent Loop BB18_12 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p0 = cmp.gtu(r19,#2)
		r21 = memw(r11++#4)
		r22 = memw(r20+#0)
	}
	{
		r22 -= mpyi(r21,r9)
		if (p0) jump:nt .LBB18_20
		memw(r17++#4) = r22.new
	}
// %bb.19:                              // %for.body11.us.i
                                        //   in Loop: Header=BB18_18 Depth=3
	{
		r21 = add(r1,r19)
		r20 = add(r20,#32)
		r19 = add(r19,#1)
	}
	{
		p1 = cmp.gtu(r14,r21)
		if (p1.new) jump:t .LBB18_18
	}
	.falign
.LBB18_20:                              // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB18_12 Depth=2
	{
		r28 = add(r28,#4)
		r1 = add(r1,#4)
		nop
	} :endloop1
	.falign
.LBB18_21:                              // %hexkl_wh_affine_sums.exit
                                        //   in Loop: Header=BB18_4 Depth=1
	{
		r18 = add(r18,#1)
		if (cmp.gtu(r0,r18.new)) jump:t .LBB18_4
	}
	.falign
.LBB18_22:                              // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end18:
	.size	fc_affine_sums_worker, .Lfunc_end18-fc_affine_sums_worker
                                        // -- End function
	.falign
	.type	lfm2_fc_issue_aligned,@function // -- Begin function lfm2_fc_issue_aligned
lfm2_fc_issue_aligned:                  // @lfm2_fc_issue_aligned
// %bb.0:                               // %entry
	{
		r6 = lsr(r2,#1)
		r4 = #31
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB19_6
	}
// %bb.1:
	{
		loop0(.LBB19_3,r6)
		r5 = #384
		r2 = and(r2,#1)
		p1 = cmp.gtu(r6,#0)
	}
	{
		if (!p1) jump:nt .LBB19_4
	}
	.balign 32
.LBB19_3:                               // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	{
		r6 = add(r0,#2048)
		r7 = add(r1,r3)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r6,r4):cm
		weight.n = mxmem(r7,r5)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r7,r3)
	} :endloop0
	.falign
.LBB19_4:
	{
		p0 = cmp.gtu(r2,#0)
		if (!p0.new) jumpr:nt r31
	}
	.falign
.LBB19_5:                               // Block address taken
                                        // %for.body
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	.falign
.LBB19_6:                               // %for.cond.cleanup
	{
		jumpr r31
	}
.Lfunc_end19:
	.size	lfm2_fc_issue_aligned, .Lfunc_end19-lfm2_fc_issue_aligned
                                        // -- End function
	.falign
	.type	hexkl_wh_affine_acc,@function   // -- Begin function hexkl_wh_affine_acc
hexkl_wh_affine_acc:                    // @hexkl_wh_affine_acc
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB20_13
		r6 = #0
		p0 = cmp.eq(r2,#0)
	}
// %bb.1:                               // %for.cond.preheader
	{
		p1 = cmp.gtu(r3,#31); if (!p1.new) jump:t .LBB20_7
	}
// %bb.2:                               // %for.body.lr.ph
	{
		if (p0) jumpr:nt r31
	}
.LBB20_3:                               // %for.body.us.preheader
	{
		r8 = lsr(r3,#5)
		r7 = asl(r1,#2)
	}
	{
		loop0(.LBB20_4,r8)
		r9:8 = combine(#32,r0)
	}
	.falign
.LBB20_4:                               // Block address taken
                                        // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB20_5 Depth 2
	{
		r6 = addasl(r4,r6,#2)
		r13:12 = combine(r2,r8)
		r14 = r5
	}
	{
		r6 = r9
		v0 = vmemu(r6+#0)
	}
	.balign 32
.LBB20_5:                               // %for.body3.us
                                        //   Parent Loop BB20_4 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r13 = add(r13,#-1)
		r9 = memw(r14++#4)
	}
	{
		v1 = vsplat(r9)
		p1 = cmp.eq(r13,#0)
		v2 = vmemu(r12+#0)
	}
	{
		v2.w += vmpyie(v1.w,v0.h)
	}
	{
		r12 = add(r12,r7)
		if (!p1) jump:nt .LBB20_5
		vmemu(r12+#0) = v2
	}
// %bb.6:                               // %for.cond1.for.cond.loopexit_crit_edge.us
                                        //   in Loop: Header=BB20_4 Depth=1
	{
		r9 = add(r6,#32)
		r8 = add(r8,#128)
	} :endloop0
	.falign
.LBB20_7:                               // %for.cond10.preheader
	{
		if (p0) jumpr:nt r31
	}
.LBB20_8:                               // %for.cond10.preheader
	{
		r4 = addasl(r4,r6,#2)
		r8 = addasl(r0,r6,#2)
		p0 = cmp.gtu(r3,r6); if (!p0.new) jump:nt .LBB20_13
	}
// %bb.9:                               // %for.cond14.preheader.us.preheader
	{
		r3 = sub(r3,r6)
		r6 = #0
	}
	{
		loop1(.LBB20_10,r2)
		r7 = asl(r1,#2)
	}
	.falign
.LBB20_10:                              // Block address taken
                                        // %for.cond14.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB20_11 Depth 2
	{
		loop0(.LBB20_11,r3)
		r2 = addasl(r5,r6,#2)
		r9 = r4
		r12 = r8
	}
	.balign 32
.LBB20_11:                              // Block address taken
                                        // %for.body17.us
                                        //   Parent Loop BB20_10 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r13 = memw(r2+#0)
		r14 = memw(r9++#4)
	}
	{
		r15 = memw(r12+#0)
	}
	{
		r15 += mpyi(r14,r13)
		memw(r12++#4) = r15.new
	} :endloop0
// %bb.12:                              // %for.cond14.for.cond.cleanup16_crit_edge.us
                                        //   in Loop: Header=BB20_10 Depth=1
	{
		r6 = add(r6,#1)
		r8 = add(r8,r7)
		nop
	} :endloop1
	.falign
.LBB20_13:                              // %return
	{
		jumpr r31
	}
.Lfunc_end20:
	.size	hexkl_wh_affine_acc, .Lfunc_end20-hexkl_wh_affine_acc
                                        // -- End function
	.falign
	.type	fc_row_post,@function           // -- Begin function fc_row_post
fc_row_post:                            // @fc_row_post
// %bb.0:                               // %entry
	{
		r17:16 = combine(r2,r1)
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r4 = memw(r0+#12)
		memd(r29+#8) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = combine(r16,r16)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB21_2
		if (!p0.new) r2 = memw(r18+#0)
	}
// %bb.1:                               // %if.then
	{
		r3 = memw(r18+#8)
		r5 = memw(r18+#20)
	}
	{
		call hvx_rmsnorm_row_chunks_f32
	}
	.falign
.LBB21_2:                               // %if.end
	{
		r0 = r16
		r3 = memw(r18+#4)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB21_4
	}
// %bb.3:                               // %if.then3
	{
		r2 = memw(r18+#16)
		r1 = memw(r18+#8)
	}
	{
		r4 = mpyi(r17,r2)
	}
	{
		r3 = addasl(r3,r4,#3)
		call hvx_rope_row_f32
	}
	.falign
.LBB21_4:                               // %if.end8
	{
		r2 = memw(r18+#24)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_9
	}
// %bb.5:                               // %if.then10
	{
		r6 = memw(r18+#32)
		r2 = memw(r18+#8)
	}
	{
		r19 = addasl(r6,r17,#7)
		r3 = memw(r18+#52)
		r4 = memw(r18+#56)
	}
	{
		call hvx_rmsnorm_add_row_acc_f32
		r1:0 = combine(r16,r19)
		r5 = memw(r18+#44)
	}
	.falign
// %bb.6:                               // %if.then10
	{
		r2 = memw(r18+#48)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_9
	}
// %bb.7:                               // %if.then14
	{
		r2 = memw(r18+#36)
		r6 = memw(r18+#24)
	}
	{
		r16 -= asl(r2,#2)
		r4 = memw(r18+#40)
		r3 = memw(r18+#28)
	}
	{
		r0 = r16
		r2 = r16
		r7 = memw(r18+#64)
		r5 = memw(r18+#60)
	}
	{
		r7 = mpyi(r4,r17)
		memw(r29+#0) = r7
		memw(r29+#4) = r19
	}
	{
		r1 = addasl(r6,r7,#2)
		call hvx_rmsnorm_add_row_finish_f32
	}
	.falign
// %bb.8:                               // %if.then14
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB21_9:                               // %if.end21
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end21:
	.size	fc_row_post, .Lfunc_end21-fc_row_post
                                        // -- End function
	.balign 32                              // -- Begin function fc_affine_worker
	.type	fc_affine_worker,@function
fc_affine_worker:                       // @fc_affine_worker
// %bb.0:                               // %entry
	{
		jump hvx_dq_tiles_rows_affine
		r4 = memw(r2+#72)
		r3 = memw(r2+#68)
	}
.Lfunc_end22:
	.size	fc_affine_worker, .Lfunc_end22-fc_affine_worker
                                        // -- End function
	.globl	hexkl_mm_u8i4_fused_run         // -- Begin function hexkl_mm_u8i4_fused_run
	.falign
	.type	hexkl_mm_u8i4_fused_run,@function
hexkl_mm_u8i4_fused_run:                // @hexkl_mm_u8i4_fused_run
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r5,#0)
		memd(r29+#-16) = r17:16
		allocframe(#232)
	}                                       // 8-byte Folded Spill
	{
		r21 = ##-2147449855
		memd(r29+#208) = r21:20
		memd(r29+#216) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r18 = add(r21,#-32755)
		memd(r29+#200) = r23:22
		memd(r29+#192) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB23_9
		memd(r29+#184) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB23_9
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB23_9
	}
// %bb.3:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB23_9
	}
// %bb.4:                               // %entry
	{
		r6 = memw(r29+#240)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB23_9
	}
// %bb.5:                               // %entry
	{
		r23 = memw(r29+#244)
		if (cmp.eq(r23.new,#0)) jump:nt .LBB23_9
	}
// %bb.6:                               // %entry
	{
		r24 = memw(r29+#248)
		if (cmp.eq(r24.new,#0)) jump:nt .LBB23_9
	}
// %bb.7:                               // %if.end
	{
		r20 = add(pc,##hexkl_mm_u8i4_fused_run.kDefaults@PCREL)
		r7 = memw(r29+#252)
	}
	{
		p0 = cmp.eq(r7,#0)
		if (!p0.new) r20 = add(r7,#0)
	}
	{
		r7 = memw(r20+#4)
		if (!cmp.eq(r7.new,#0)) jump:t .LBB23_9
	}
// %bb.8:                               // %lor.lhs.false13
	{
		r7 = memw(r20+#8)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB23_10
	}
	.falign
.LBB23_9:                               // %cleanup459
	{
		r0 = r18
		r17:16 = memd(r29+#224)
		r19:18 = memd(r29+#216)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#208)
		r23:22 = memd(r29+#200)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#192)
		r27:26 = memd(r29+#184)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB23_10:                              // %lor.lhs.false15
	{
		p1 = !bitsclr(r5,#31)
		if (!p1.new) r8 = ##4095
		if (p1.new) jump:nt .LBB23_9
	}
// %bb.11:                              // %lor.lhs.false15
	{
		r7 = memw(r20+#16)
		if (!cmp.eq(r7.new,#0)) jump:nt .LBB23_9
	}
// %bb.12:                              // %if.end21
	{
		r7 = #4095
		r8 = memw(r6+#0)
		if (cmp.gtu(r8.new,r8)) jump:t .LBB23_9
	}
// %bb.13:                              // %lor.lhs.false23
	{
		r7 = memw(r6+#4)
		if (cmp.gtu(r7.new,r7)) jump:t .LBB23_9
	}
// %bb.14:                              // %lor.lhs.false26
	{
		r6 = +mpyi(r8,#96)
	}
	{
		r8 = memw(r0+r6<<#0)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB23_9
	}
// %bb.15:                              // %lor.lhs.false30
	{
		r7 = +mpyi(r7,#96)
	}
	{
		r8 = memw(r0+r7<<#0)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB23_9
	}
// %bb.16:                              // %if.end37
	{
		r26 = add(r0,r6)
	}
	{
		r6 = memw(r26+#28)
		if (!cmp.eq(r6.new,r5)) jump:t .LBB23_9
	}
// %bb.17:                              // %lor.lhs.false46
	{
		r27 = add(r0,r7)
		r9 = memw(r26+#32)
	}
	{
		r16 = memw(r27+#28)
	}
	{
		r6 = asl(r16,#1)
		if (!cmp.eq(r6.new,r9)) jump:nt .LBB23_9
	}
// %bb.18:                              // %lor.lhs.false46
	{
		r6 = extractu(r6,#5,#1)
		r22 = asl(r5,#6)
		if (!cmp.eq(r6.new,#0)) jump:nt .LBB23_9
	}
// %bb.19:                              // %if.end54
	{
		r6 = asl(r16,#8)
		r18 = add(r21,#-32767)
		r8 = memw(r27+#32)
	}
	{
		r13:12 = vlsrw(r9:8,#5)
	}
	{
		r7 = mpyi(r5,r13)
		r17 = mpyi(r16,r12)
	}
	{
		r25 = asl(r7,#4)
	}
	{
		r7 = add(r25,add(r22,##2047))
	}
	{
		r14 = add(r7,r6)
		r7 = and(r7,##-2048)
	}
	{
		r14 = insert(r7,#11,#0)
		r15 = add(r14,r6)
	}
	{
		r6 = addasl(r15,r16,#6)
		r15 = insert(r14,#11,#0)
	}
	{
		r6 = insert(r6,#2,#9)
		r28 = r6
	}
	{
		r28 = insert(r15,#11,#0)
		r10 = addasl(r6,r17,#4)
	}
	{
		r10 = insert(r28,#11,#0)
	}
	{
		r6 = add(r10,#8192)
		if (cmp.gtu(r6.new,r3)) jump:nt .LBB23_9
	}
// %bb.20:                              // %if.end54
	{
		r0 = r1
		p1 = cmp.gtu(r6,r2); if (p1.new) jump:nt .LBB23_9
		if (!p1.new) memw(r29+#68) = r7
	}                                       // 4-byte Folded Spill
// %bb.21:                              // %if.end100
	{
		r1 = r10
		memw(r29+#24) = r1
		memw(r29+#76) = r28
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#60) = r15
		memw(r29+#64) = r14
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#160) = r13:12
		memd(r29+#168) = r9:8
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#72) = r3
		memw(r29+#48) = r10
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#40) = r4
		memw(r29+#52) = r5
	}                                       // 4-byte Folded Spill
	{
		call hexkl_acc_layout_get
	}
	.falign
// %bb.22:                              // %if.end100
	{
		r2 = memw(r0+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_38
	}
// %bb.23:                              // %if.end109
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r2 = memw(r29+#40)
		memw(r29+#56) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = add(#252,asl(r2,#2))
		r5 = #0
		r4 = memw(r0+#12)
		memw(r29+#28) = r3
	}                                       // 4-byte Folded Spill
	{
		r21 = and(r2,#-256)
		r3 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r0 = r21
	}
	{
		call malloc
		memd(r3+#136) = r5:4
	}
	.falign
// %bb.24:                              // %if.end109
	{
		call malloc
		r19 = r0
		r0 = r21
	}
	.falign
// %bb.25:                              // %if.end109
	{
		call malloc
		r0 = r21
		memw(r29+#32) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.26:                              // %if.end109
	{
		call malloc
		r0 = r21
		memw(r29+#36) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.27:                              // %if.end109
	{
		p1 = cmp.eq(r19,#0); if (p1.new) jump:nt .LBB23_39
		memw(r29+#44) = r19
	}                                       // 4-byte Folded Spill
// %bb.28:                              // %if.end109
	{
		r2 = memw(r29+#32)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_39
	}                                       // 4-byte Folded Reload
// %bb.29:                              // %if.end109
	{
		r2 = memw(r29+#36)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_39
	}                                       // 4-byte Folded Reload
// %bb.30:                              // %if.end109
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB23_39
		if (!p0.new) memw(r29+#84) = r0
	}                                       // 4-byte Folded Spill
// %bb.31:                              // %if.end126
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.32:                              // %if.end126
	{
		call dma_row_size_dividing
		r0 = r25
	}
	.falign
// %bb.33:                              // %if.end126
	{
		r18 = r0
		r21 = memw(r26+#4)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r25)
	}
	.falign
// %bb.34:                              // %if.end126
	{
		r5:4 = combine(r0,r18)
		r1 = r21
		r2 = memw(r29+#24)
		memw(r29+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r0 = add(r2,r22)
		r3:2 = combine(r18,r18)
		memw(r29+#4) = #1
	}
	.falign
// %bb.35:                              // %if.end126
	{
		r21 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
		memw(r29+#108) = r22

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_44
	}
// %bb.36:                              // %if.then130
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.37:                              // %if.then130
	{
		jump .LBB23_45
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_38:                              // %cond.end104.thread
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r1:0 = combine(#0,#0)
		r18 = add(r21,#-32749)
	}
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		jump .LBB23_9
		memd(r2+#136) = r1:0
	}
	.falign
.LBB23_39:                              // %if.then125
	{
		call free
		r16 = r0
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.40:                              // %if.then125
	{
		call free
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.41:                              // %if.then125
	{
		call free
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.42:                              // %if.then125
	{
		call free
		r0 = r16
	}
	.falign
// %bb.43:                              // %if.then125
	{
		jump .LBB23_9
	}
	.falign
.LBB23_44:
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_45:                              // %do.end
	{
		r19:18 = bitsplit(r16,#5)
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r22 = lsr(r2,#5)
		r18 = asl(r17,#4)
	}
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.46:                              // %do.end
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_49
	}
// %bb.47:                              // %if.then135
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.48:                              // %if.then135
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB23_49:                              // %for.body.lr.ph
	{
		call dma_row_size_dividing
		r0 = r18
	}
	.falign
// %bb.50:                              // %for.body.lr.ph
	{
		r21 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r18)
		r18 = memw(r27+#4)
	}
	.falign
// %bb.51:                              // %for.body.lr.ph
	{
		r5:4 = combine(r0,r21)
		r1 = r18
		r17 = memw(r29+#24)
		r2 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r3:2 = combine(r21,r21)
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	{
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.52:                              // %for.body.lr.ph
	{
		r25 = extractu(r17,#11,#0)
		r3:2 = combine(#1,r17)
		r21 = #0
		r1:0 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r5 = maxu(r22,r3)
		r4 = extractu(r1,#23,#0)
		r22 = #64
		r1 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r19,r3)
		r0 = extractu(r0,#23,#0)
		p0 = cmp.eq(r16,#0)
		memw(r29+#116) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r17 = asl(r4,#9)
		r4 = asl(r0,#9)
		r3 = add(r2,r1)
		r0 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,r0)
		r1 = memw(r29+#64)
		memw(r29+#88) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,r1)
		r0 = memw(r29+#60)
		memw(r29+#104) = r3
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r0)
		r1:0 = memd(r29+#168)
		memw(r29+#92) = r5
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.gtu(r1,#31)
		memw(r29+#140) = r3
		memw(r29+#144) = r2
	}                                       // 4-byte Folded Spill
	{
		r1 = p1
		r0 = p0
		p1 = cmp.gtu(r0,#31)
		memw(r29+#112) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r1 = p1
		memw(r29+#148) = r1.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#120) = r0
		memw(r29+#136) = r27
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#96) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_53:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB23_86 Depth 2
                                        //       Child Loop BB23_88 Depth 3
                                        //     Child Loop BB23_110 Depth 2
                                        //       Child Loop BB23_112 Depth 3
	{
		r2 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_56
	}
// %bb.54:                              // %if.then159
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.55:                              // %if.then159
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_56:                              // %do.end163
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r18 = memw(r29+#52)
		memw(r29+#124) = r21
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r20+#0)
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r21,r18)
		r2 = sub(r2,r21)
		r19 = memw(r29+#44)
		memw(r29+#0) = r0
	}                                       // 4-byte Folded Reload
	{
		r27 = minu(r2,r22)
		r21 = addasl(r23,r3,#2)
		r3:2 = combine(r18,#64)
		r22 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_rows_u8_params
		r1:0 = combine(r27,r21)
		r5:4 = combine(r22,r19)
	}
	.falign
// %bb.57:                              // %do.end163
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r5:4 = combine(r22,r19)
		r2 = memw(r20+#0)
		memw(r29+#4) = r2.new
	}
	{
		r3:2 = combine(r18,#64)
		r0 = memw(r29+#24)
		memw(r29+#0) = r0.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		r1:0 = combine(r27,r21)
		memw(r29+#80) = r27
	}                                       // 4-byte Folded Spill
	.falign
// %bb.58:                              // %do.end163
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r18 = r0
		r21 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_61
	}
// %bb.59:                              // %if.then169
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.60:                              // %if.then169
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB23_61:                              // %do.end175
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r19 = #0
		p1 = cmp.eq(r18,#0); if (!p1.new) jump:nt .LBB23_134
		if (p1.new) r2 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %for.cond180.preheader
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		p0 = r2
		if (p0.new) jump:t .LBB23_86
		r22 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_63:                              // %do.body268
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r18 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_66
	}
// %bb.64:                              // %if.then270
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.65:                              // %if.then270
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_66:                              // %do.end274
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.67:                              // %do.end274
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_72
	}
// %bb.68:                              // %do.body284
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.69:                              // %do.body284
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_72
	}
// %bb.70:                              // %if.then286
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.71:                              // %if.then286
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_72:                              // %do.end290
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r3 = r16
		r4 = memw(r20+#0)
		r0 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		call hvx_swiglu_inplace_f32
		r1 = memw(r29+#140)
		r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.73:                              // %do.end290
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_78
	}
// %bb.74:                              // %do.body303
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.75:                              // %do.body303
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#112)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#112) = r1:0
	}
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_78
	}
// %bb.76:                              // %if.then305
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.77:                              // %if.then305
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_78:                              // %do.end309
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r27 = memw(r29+#80)
		r2 = memw(r20+#0)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r16,#64)
		r19 = memw(r29+#104)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r27,r19)
		r22 = memw(r29+#36)
		r21 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_rows_u8_params
		r5:4 = combine(r21,r22)
	}
	.falign
// %bb.79:                              // %do.end309
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r1:0 = combine(r27,r19)
		r5:4 = combine(r21,r22)
		r2 = memw(r20+#0)
		r3 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		r3:2 = combine(r16,#64)
		memw(r29+#0) = r3
		memw(r29+#4) = r2
	}
	.falign
// %bb.80:                              // %do.end309
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r18 = r0
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_83
	}
// %bb.81:                              // %if.then318
                                        //   in Loop: Header=BB23_53 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.82:                              // %if.then318
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB23_83:                              // %do.end324
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		p1 = cmp.eq(r18,#0); if (!p1.new) jump:nt .LBB23_134
		if (p1.new) r2 = memw(r29+#148)
		r19 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
// %bb.84:                              // %for.cond330.preheader
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		p0 = r2
		r3 = #0
		if (p0.new) jump:t .LBB23_109
		if (p0.new) r1:0 = memd(r29+#168)
	}                                       // 8-byte Folded Reload
	.falign
.LBB23_85:                              // %for.inc425
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r22 = #64
		r21 = memw(r29+#124)
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r21 = add(r21,#64)
		if (cmp.gtu(r2,r21.new)) jump:t .LBB23_53
	}
	{
		jump .LBB23_133
	}
	.falign
.LBB23_86:                              // %for.body189.preheader
                                        //   Parent Loop BB23_53 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB23_88 Depth 3
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.87:                              // %for.body189.preheader
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r21 = #0
		r27 = memw(r29+#92)
		memw(r29+#100) = r22
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_88:                              // %for.body189
                                        //   Parent Loop BB23_53 Depth=1
                                        //     Parent Loop BB23_86 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r3 = add(r2,r22)
	}
	{
		r4 = r3
	}
	{
		r4 = or(r25,and(r4,#127))
		if (cmp.eq(r4.new,#0)) jump:nt .LBB23_91
	}
// %bb.89:                              // %mm_u8i4_tile.exit
                                        //   in Loop: Header=BB23_88 Depth=3
	{
		call hexkl_micro_hmx_mm_u8i4
		r1:0 = combine(r21,r2)
		r2 = r22
	}
	.falign
// %bb.90:                              // %mm_u8i4_tile.exit
                                        //   in Loop: Header=BB23_88 Depth=3
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:t .LBB23_92
		r18 = r0
		r2 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB23_134
	}
	.falign
.LBB23_91:                              // %mm_u8i4_tile.exit.thread
                                        //   in Loop: Header=BB23_88 Depth=3
	{
		r4 = add(r2,r21)
		r5 = #31
		r6 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r5):cm
		weight.n = mxmem(r3,r6)
	}

	//# InlineAsm End
	.falign
.LBB23_92:                              // %for.inc
                                        //   in Loop: Header=BB23_88 Depth=3
	{
		r22 = add(r22,r17)
		r21 = add(r21,#2048)
		r27 = add(r27,#-1)
		if (!cmp.eq(r27.new,#0)) jump:t .LBB23_88
	}
// %bb.93:                              // %do.body204
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r21 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_96
	}
// %bb.94:                              // %if.then206
                                        //   in Loop: Header=BB23_86 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.95:                              // %if.then206
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_96:                              // %do.end210
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r0 = memw(r29+#24)
		r1 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_micro_hmx_acc_read_int32
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.97:                              // %do.end210
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r18 = r0
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_100
	}
// %bb.98:                              // %if.then214
                                        //   in Loop: Header=BB23_86 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.99:                              // %if.then214
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r5:4 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB23_100:                             // %do.end220
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		p1 = cmp.eq(r18,#0); if (!p1.new) jump:nt .LBB23_134
		if (p1.new) r21 = memw(r29+#28)
		if (p1.new) r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
// %bb.101:                             // %if.end224
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r18 = memw(r2+#8)
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_104
	}
// %bb.102:                             // %if.then245
                                        //   in Loop: Header=BB23_86 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.103:                             // %if.then245
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_104:                             // %do.end249
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r4 = asl(r19,#5)
		r2 = memw(r29+#56)
		r6 = memw(r26+#16)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r16,r4)
		r5 = memw(r29+#88)
		r8 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r0 = addasl(r5,r18,#2)
		r7 = mux(p1,#0,r16)
		r1 = memw(r2+#12)
		r3:2 = memd(r26+#8)
	}
	{
		r5 = addasl(r3,r4,#2)
		r3 = addasl(r6,r4,#2)
		r7 = sub(r4,r7)
		memw(r29+#4) = r3.new
	}
	{
		r2 = addasl(r2,r4,#2)
		r3 = memw(r29+#68)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#64)
		memw(r29+#12) = r16
	}                                       // 4-byte Folded Reload
	{
		r6 = mux(p1,r3,r2)
		r4 = memw(r29+#32)
		memw(r29+#16) = #0
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r8,r6)
		r2 = memw(r29+#80)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r7,#2)
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#8) = r6.new
	}
	.falign
// %bb.105:                             // %do.end249
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_108
	}
// %bb.106:                             // %if.then256
                                        //   in Loop: Header=BB23_86 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.107:                             // %if.then256
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB23_108:                             // %do.end262
                                        //   in Loop: Header=BB23_86 Depth=2
	{
		r22 = memw(r29+#100)
		r1:0 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r22 = add(r22,#512)
		r19 = add(r19,#1)
		if (!cmp.eq(r19.new,r1)) jump:t .LBB23_86
	}
	{
		jump .LBB23_63
	}
	.falign
.LBB23_109:                             // %for.body334.lr.ph
                                        //   in Loop: Header=BB23_53 Depth=1
	{
		r2 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		r22 = memw(r29+#76)
		memw(r29+#100) = r3
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r0)
	}
	{
		r2 = addasl(r24,r2,#2)
		memw(r29+#128) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_110:                             // %for.body334
                                        //   Parent Loop BB23_53 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB23_112 Depth 3
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.111:                             // %for.body334
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r21 = memw(r29+#60)
		memw(r29+#132) = r22
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#24)
		r27 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#120)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:nt .LBB23_117
	}
	.falign
.LBB23_112:                             // %for.body340
                                        //   Parent Loop BB23_53 Depth=1
                                        //     Parent Loop BB23_110 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r4 = add(r2,r21)
		r3 = add(r2,r22)
		p0 = cmp.eq(r25,#0)
		if (p0.new) jump:nt .LBB23_115
	}
// %bb.113:                             // %mm_u8i4_tile.exit735
                                        //   in Loop: Header=BB23_112 Depth=3
	{
		call hexkl_micro_hmx_mm_u8i4
		r1:0 = combine(r21,r2)
		r2 = r22
	}
	.falign
// %bb.114:                             // %mm_u8i4_tile.exit735
                                        //   in Loop: Header=BB23_112 Depth=3
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:t .LBB23_116
		r18 = r0
		r2 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB23_134
	}
	.falign
.LBB23_115:                             // %mm_u8i4_tile.exit735.thread
                                        //   in Loop: Header=BB23_112 Depth=3
	{
		r5 = #31
		r6 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r4,r5):cm
		weight.n = mxmem(r3,r6)
	}

	//# InlineAsm End
	.falign
.LBB23_116:                             // %for.inc358
                                        //   in Loop: Header=BB23_112 Depth=3
	{
		r22 = add(r22,r19)
		r21 = add(r21,#2048)
		r27 = add(r27,#-1)
		if (!cmp.eq(r27.new,#0)) jump:t .LBB23_112
	}
	.falign
.LBB23_117:                             // %do.body363
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r21 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_120
	}
// %bb.118:                             // %if.then365
                                        //   in Loop: Header=BB23_110 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.119:                             // %if.then365
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_120:                             // %do.end369
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r0 = memw(r29+#24)
		r1 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_micro_hmx_acc_read_int32
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.121:                             // %do.end369
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r18 = r0
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_124
	}
// %bb.122:                             // %if.then373
                                        //   in Loop: Header=BB23_110 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.123:                             // %if.then373
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB23_124:                             // %do.end379
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		p1 = cmp.eq(r18,#0); if (!p1.new) jump:nt .LBB23_134
		if (p1.new) r21 = memw(r29+#28)
		if (p1.new) r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
// %bb.125:                             // %if.end383
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r18 = memw(r2+#8)
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_128
	}
// %bb.126:                             // %if.then392
                                        //   in Loop: Header=BB23_110 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.127:                             // %if.then392
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		memd(r29+#152) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB23_128:                             // %do.end396
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r2 = memw(r29+#56)
		r4 = memw(r29+#136)
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#100)
		r7:6 = memd(r29+#168)
	}                                       // 8-byte Folded Reload
	{
		r1 = memw(r2+#12)
		r3:2 = memd(r4+#8)
	}
	{
		r4 = memw(r4+#16)
		r5 = memw(r20+#12)
	}
	{
		r6 = asl(r19,#5)
		r7 = memw(r29+#88)
		memw(r29+#12) = r6
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r6,#2)
		r0 = addasl(r7,r18,#2)
		r18 = memw(r29+#128)
		memw(r29+#16) = r5
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r3,r6,#2)
		r3 = addasl(r4,r6,#2)
		r2 = memw(r29+#80)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#36)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		call hvx_dequant_acc_tile_to_f32
		r4 = memw(r29+#84)
		memw(r29+#8) = r18
	}                                       // 4-byte Folded Reload
	.falign
// %bb.129:                             // %do.end396
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_132
	}
// %bb.130:                             // %if.then409
                                        //   in Loop: Header=BB23_110 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.131:                             // %if.then409
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB23_132:                             // %do.end415
                                        //   in Loop: Header=BB23_110 Depth=2
	{
		r19 = add(r19,#1)
		r18 = add(r18,#128)
		r1:0 = memd(r29+#160)
		memw(r29+#100) = r19.new
	}                                       // 8-byte Folded Reload
	{
		p0 = cmp.eq(r19,r0)
		r22 = memw(r29+#132)
		memw(r29+#128) = r18
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r22,#512)
		if (!p0) jump:nt .LBB23_110
		r19 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB23_85
	}
	.falign
.LBB23_133:
	{
		r18 = #0
	}
	.falign
.LBB23_134:                             // %cleanup431
	{
		call free
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.135:                             // %cleanup431
	{
		call free
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.136:                             // %cleanup431
	{
		call free
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.137:                             // %cleanup431
	{
		call free
		r0 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.138:                             // %cleanup431
	{
		jump .LBB23_9
	}
.Lfunc_end23:
	.size	hexkl_mm_u8i4_fused_run, .Lfunc_end23-hexkl_mm_u8i4_fused_run
                                        // -- End function
	.globl	hexkl_mm_u8i4_gate_up_swiglu_run // -- Begin function hexkl_mm_u8i4_gate_up_swiglu_run
	.falign
	.type	hexkl_mm_u8i4_gate_up_swiglu_run,@function
hexkl_mm_u8i4_gate_up_swiglu_run:       // @hexkl_mm_u8i4_gate_up_swiglu_run
// %bb.0:                               // %entry
	{
		r6 = r0
		memd(r29+#-16) = r17:16
		allocframe(#200)
	}                                       // 8-byte Folded Spill
	{
		r18 = ##-2147449855
		r7 = memw(r29+#208)
		memd(r29+#184) = r19:18
	}
	{
		p1 = cmp.gtu(r7,##4095)
		r0 = add(r18,#-32755)
		memd(r29+#176) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#168) = r23:22
		memd(r29+#160) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB24_14
		memd(r29+#152) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r21:20 = bitsplit(r5,#5)
	}
	{
		p0 = cmp.eq(r20,#0); if (!p0.new) jump:nt .LBB24_14
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB24_14
	}
// %bb.3:                               // %entry
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB24_14
	}
// %bb.4:                               // %entry
	{
		p1 = cmp.eq(r6,#0); if (p1.new) jump:nt .LBB24_14
	}
// %bb.5:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB24_14
	}
// %bb.6:                               // %entry
	{
		r20 = memw(r29+#212)
		if (cmp.eq(r20.new,#0)) jump:nt .LBB24_14
	}
// %bb.7:                               // %entry
	{
		r24 = memw(r29+#216)
		if (cmp.eq(r24.new,#0)) jump:nt .LBB24_14
	}
// %bb.8:                               // %entry
	{
		r25 = memw(r29+#220)
		if (cmp.eq(r25.new,#0)) jump:nt .LBB24_14
	}
// %bb.9:                               // %entry
	{
		r7 = +mpyi(r7,#96)
		r26 = memw(r29+#224)
		if (cmp.eq(r26.new,#0)) jump:nt .LBB24_14
	}
// %bb.10:                              // %lor.lhs.false17
	{
		r17 = add(r6,r7)
		r8 = memw(r6+r7<<#0)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB24_14
	}
// %bb.11:                              // %if.end20
	{
		r6 = memw(r17+#28)
		if (!cmp.eq(r6.new,r5)) jump:t .LBB24_14
	}
// %bb.12:                              // %lor.lhs.false25
	{
		r27 = memw(r17+#32)
	}
	{
		r19 = lsr(r27,#5)
		p1 = tstbit(r27,#0)
		if (p1.new) jump:t .LBB24_14
	}
// %bb.13:                              // %if.end29
	{
		p0 = !bitsclr(r27,#62)
		if (!p0.new) r0 = add(r18,##-32767)
		if (!p0.new) jump:nt .LBB24_15
	}
	.falign
.LBB24_14:                              // %return
	{
		r17:16 = memd(r29+#192)
		r19:18 = memd(r29+#184)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#176)
		r23:22 = memd(r29+#168)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#160)
		r27:26 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB24_15:                              // %if.end34
	{
		r6 = mpyi(r5,r19)
		r7 = asl(r5,#6)
	}
	{
		r22 = asl(r6,#4)
	}
	{
		r6 = add(r22,add(r7,##2047))
	}
	{
		r8 = addasl(r6,r27,#7)
		r9 = and(r6,##-2048)
	}
	{
		r6 = addasl(r8,r27,#7)
		r8 = insert(r9,#11,#0)
	}
	{
		r6 = insert(r8,#11,#0)
		memw(r29+#36) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r6 = add(r6,#8192)
		if (cmp.gtu(r6.new,r3)) jump:nt .LBB24_14
	}
// %bb.16:                              // %if.end34
	{
		r23 = r0
		if (!p0.new) r0 = add(r1,#0)
		p0 = cmp.gtu(r6,r2); if (p0.new) jump:nt .LBB24_14
	}
// %bb.17:                              // %if.end64
	{
		r1 = memw(r29+#36)
		memw(r29+#28) = r1
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#72) = r9
		memw(r29+#68) = r8
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#64) = r7
		memw(r29+#32) = r3
	}                                       // 4-byte Folded Spill
	{
		call hexkl_acc_layout_get
		memw(r29+#56) = r4
		memw(r29+#60) = r5
	}                                       // 4-byte Folded Spill
	.falign
// %bb.18:                              // %if.end64
	{
		r5:4 = combine(#0,#0)
		r2 = memw(r0+#4)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB24_93
	}
// %bb.19:                              // %if.end69
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r29+#84) = r0
	}                                       // 4-byte Folded Spill
	{
		r0 = #256
		r2 = memw(r0+#12)
		memw(r29+#40) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = #0
		r4 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		call malloc
		memd(r4+#136) = r3:2
	}
	.falign
// %bb.20:                              // %if.end69
	{
		call malloc
		r18 = r0
		r0 = #256
	}
	.falign
// %bb.21:                              // %if.end69
	{
		p0 = cmp.eq(r18,#0); if (p0.new) jump:nt .LBB24_94
		memw(r29+#44) = r18
	}                                       // 4-byte Folded Spill
// %bb.22:                              // %if.end69
	{
		r16 = lsr(r27,#1)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB24_94
		if (!p1.new) r2 = memw(r29+#228)
	}
// %bb.23:                              // %for.body.lr.ph
	{
		memw(r29+#52) = r0
		memw(r29+#80) = r2
	}                                       // 4-byte Folded Spill
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.24:                              // %for.body.lr.ph
	{
		call dma_row_size_dividing
		r0 = r22
	}
	.falign
// %bb.25:                              // %for.body.lr.ph
	{
		r23 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r22)
		r22 = memw(r17+#4)
	}
	.falign
// %bb.26:                              // %for.body.lr.ph
	{
		r5:4 = combine(r0,r23)
		r1 = r22
		r18 = memw(r29+#28)
		r2 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r18,r2)
		r3:2 = combine(r23,r23)
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	{
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.27:                              // %for.body.lr.ph
	{
		r2 = asl(r27,#5)
		r4 = #1
		r3 = r18
		memw(r29+#128) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r4 = maxu(r19,r4)
		r22 = extractu(r3,#11,#0)
		r6 = r16
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r27,#0)
		r1:0 = combine(#0,#0)
	}
	{
		r4 = extractu(r16,#23,#4)
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memw(r29+#120) = r4

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r16 = asl(r4,#9)
		r4 = memw(r29+#36)
		memd(r29+#136) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r3,r4)
		r2 = memw(r2+#0)
		memw(r29+#124) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r29+#72)
		memw(r29+#104) = r6
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r3,r4)
		memw(r29+#96) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r29+#68)
		memw(r29+#108) = r16
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r4)
		r4 = memw(r29+#56)
		memw(r29+#112) = r22
	}                                       // 4-byte Folded Reload
	{
		r3 = #0
		r27 = memw(r29+#60)
		memw(r29+#132) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = p0
		memw(r29+#48) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#116) = r3
		memw(r29+#100) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB24_28:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB24_47 Depth 2
                                        //       Child Loop BB24_49 Depth 3
                                        //     Child Loop BB24_81 Depth 2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB24_31
	}
// %bb.29:                              // %if.then91
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.30:                              // %if.then91
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r4 = memw(r29+#56)
		memd(r29+#136) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r27 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_31:                              // %do.end
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r0 = #64
		r5 = memw(r29+#48)
		r19 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r4,r5)
		r18 = memw(r29+#80)
		memw(r29+#0) = r18.new
	}                                       // 4-byte Folded Reload
	{
		r1 = mpyi(r5,r27)
		r22 = minu(r2,r0)
		r3:2 = combine(r27,#64)
		r16 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r23 = addasl(r20,r1,#2)
		r5:4 = combine(r16,r19)
	}
	{
		call hvx_quant_rows_u8_params
		r1:0 = combine(r22,r23)
	}
	.falign
// %bb.32:                              // %do.end
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r1:0 = combine(r22,r23)
		r5:4 = combine(r16,r19)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		r3:2 = combine(r27,#64)
		memw(r29+#4) = r18
		memw(r29+#76) = r22
	}                                       // 4-byte Folded Spill
	.falign
// %bb.33:                              // %do.end
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r23 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_36
	}
// %bb.34:                              // %if.then98
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
		r19 = r0
		r1:0 = combine(r3,r2)
	}
	.falign
// %bb.35:                              // %if.then98
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r3:2 = combine(r1,r0)
		r0 = r19
		r4 = memw(r23+##hexkl_probe_us@GOT)
	}
	{
		r7:6 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r3:2 = sub(r3:2,r7:6)
		r7:6 = memd(r4+#24)
	}
	{
		r3:2 = add(r3:2,r7:6)
	}
	{
		memd(r4+#24) = r3:2
	}
	.falign
.LBB24_36:                              // %do.end104
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		p1 = cmp.eq(r0,#0)
		r18 = memw(r29+#104)
		r22 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) jump:nt .LBB24_90
		r16 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
// %bb.37:                              // %if.end108
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r29+#48)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_39
	}                                       // 4-byte Folded Reload
// %bb.38:                              //   in Loop: Header=BB24_28 Depth=1
	{
		jump .LBB24_46
		r23 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_39:                              // %do.body112
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r23 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_42
	}
// %bb.40:                              // %if.then114
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.41:                              // %if.then114
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		memd(r29+#136) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB24_42:                              // %do.end118
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.43:                              // %do.end118
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_46
	}
// %bb.44:                              // %if.then121
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %if.then121
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB24_46:                              // %if.end128
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r27 = #0
		r2 = memw(r29+#116)
		r19 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB24_70
	}
	.falign
.LBB24_47:                              // %for.body138.preheader
                                        //   Parent Loop BB24_28 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB24_49 Depth 3
	{
		call hexkl_micro_hmx_acc_clear_int32
		memw(r29+#88) = r27
	}                                       // 4-byte Folded Spill
	.falign
// %bb.48:                              // %for.body138.preheader
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r27 = #0
		r23 = r19
		r2 = memw(r29+#32)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r19 = r21
		memw(r29+#92) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB24_49:                              // %for.body138
                                        //   Parent Loop BB24_28 Depth=1
                                        //     Parent Loop BB24_47 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r4 = add(r3,r23)
	}
	{
		r5 = r4
	}
	{
		r5 = or(r22,and(r5,#127))
		if (cmp.eq(r5.new,#0)) jump:nt .LBB24_52
	}
// %bb.50:                              // %mm_u8i4_tile.exit
                                        //   in Loop: Header=BB24_49 Depth=3
	{
		call hexkl_micro_hmx_mm_u8i4
		r1:0 = combine(r27,r3)
		r2 = r23
	}
	.falign
// %bb.51:                              // %mm_u8i4_tile.exit
                                        //   in Loop: Header=BB24_49 Depth=3
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:t .LBB24_53
		r3 = memw(r29+#28)
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB24_90
	}
	.falign
.LBB24_52:                              // %mm_u8i4_tile.exit.thread
                                        //   in Loop: Header=BB24_49 Depth=3
	{
		r5 = add(r3,r27)
		r6 = #31
		r7 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r6):cm
		weight.n = mxmem(r4,r7)
	}

	//# InlineAsm End
	.falign
.LBB24_53:                              // %for.inc
                                        //   in Loop: Header=BB24_49 Depth=3
	{
		r23 = add(r23,r16)
		r27 = add(r27,#2048)
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB24_49
	}
// %bb.54:                              // %do.body153
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r23 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r4 = memw(r4+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB24_57
	}
// %bb.55:                              // %if.then155
                                        //   in Loop: Header=BB24_47 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.56:                              // %if.then155
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r2 = memw(r29+#32)
		memd(r29+#136) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_57:                              // %do.end159
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		call hexkl_micro_hmx_acc_read_int32
		r1:0 = combine(r2,r3)
		r2 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.58:                              // %do.end159
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_61
	}
// %bb.59:                              // %if.then163
                                        //   in Loop: Header=BB24_47 Depth=2
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
		r19 = r0
		r1:0 = combine(r3,r2)
	}
	.falign
// %bb.60:                              // %if.then163
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r3:2 = combine(r1,r0)
		r4 = memw(r23+##hexkl_probe_us@GOT)
		r7:6 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r3:2 = sub(r3:2,r7:6)
		r0 = r19
	}
	{
		r7:6 = memd(r4+#0)
	}
	{
		r3:2 = add(r3:2,r7:6)
	}
	{
		memd(r4+#0) = r3:2
	}
	.falign
.LBB24_61:                              // %do.end169
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB24_90
		if (p0.new) r23 = memw(r29+#40)
		if (p0.new) r3 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %if.end173
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r19 = memw(r3+#8)
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_65
	}
// %bb.63:                              // %if.then194
                                        //   in Loop: Header=BB24_47 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.64:                              // %if.then194
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r3 = memw(r29+#84)
		memd(r29+#136) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_65:                              // %do.end198
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r27 = memw(r29+#88)
		r1 = memw(r3+#12)
	}                                       // 4-byte Folded Reload
	{
		r4 = asl(r27,#5)
		r5 = memw(r29+#124)
		r3:2 = memd(r17+#8)
	}                                       // 4-byte Folded Reload
	{
		r0 = addasl(r5,r19,#2)
		r5 = addasl(r3,r4,#2)
		p0 = cmp.gtu(r18,r4)
		r6 = memw(r17+#16)
	}
	{
		r3 = addasl(r6,r4,#2)
		r2 = addasl(r2,r4,#2)
		r7 = mux(p0,#0,r18)
		memw(r29+#4) = r3.new
	}
	{
		r7 = sub(r4,r7)
		r3 = memw(r29+#72)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#68)
		r8 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r6 = mux(p0,r3,r2)
		r2 = memw(r29+#76)
		memw(r29+#12) = r18
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r8,r6)
		r3 = memw(r29+#44)
		memw(r29+#16) = #0
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r7,#2)
		call hvx_dequant_acc_tile_to_f32
		r4 = memw(r29+#52)
		memw(r29+#8) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.66:                              // %do.end198
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_69
	}
// %bb.67:                              // %if.then205
                                        //   in Loop: Header=BB24_47 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.68:                              // %if.then205
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r2 = memw(r23+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB24_69:                              // %do.end211
                                        //   in Loop: Header=BB24_47 Depth=2
	{
		r2 = memw(r29+#120)
		r19 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r19 = add(r19,#512)
		r27 = add(r27,#1)
		if (!cmp.eq(r27.new,r2)) jump:t .LBB24_47
	}
	.falign
.LBB24_70:                              // %do.body217
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_73
	}
// %bb.71:                              // %if.then219
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.72:                              // %if.then219
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		memd(r29+#136) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB24_73:                              // %do.end223
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r3 = r18
		r0 = memw(r29+#96)
		r2 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		call hvx_swiglu_inplace_f32
		r1 = memw(r29+#132)
		r4 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.74:                              // %do.end223
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_79
	}
// %bb.75:                              // %do.body235
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.76:                              // %do.body235
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#112)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#112) = r1:0
	}
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_79
	}
// %bb.77:                              // %if.then237
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.78:                              // %if.then237
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		memd(r29+#136) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB24_79:                              // %do.end241
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = #64
		r7 = #1
		r0 = memw(r29+#80)
		r1 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#100)
		memw(r29+#0) = r0
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r3,r2)
		r3:2 = combine(r18,#64)
		r27 = memw(r29+#44)
		r16 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r19 = maxu(r6,r7)
		call hvx_quant_rows_u8_params
		r5:4 = combine(r16,r27)
		r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.80:                              // %do.end241
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		loop0(.LBB24_81,r19)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r25,r3,#2)
		r3 = addasl(r26,r3,#2)
	}
	.balign 32
.LBB24_81:                              // Block address taken
                                        // %for.body247
                                        //   Parent Loop BB24_28 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r6 = memw(r27++#4)
		memw(r2++#4) = r6.new
	}
	{
		r0 = memw(r16++#4)
		memw(r3++#4) = r0.new
	} :endloop0
// %bb.82:                              // %for.cond.cleanup246
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r5 = r24
		r0 = memw(r29+#96)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r6 = lsr(r2,#6)
		r7 = memw(r29+#128)
		r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r18,#64)
		r1 = memw(r29+#76)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Reload
	{
		r5 += mpyi(r7,r6)
		r4 = memw(r29+#44)
		memw(r29+#0) = r5.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		r5 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.83:                              // %for.cond.cleanup246
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB24_86
	}
// %bb.84:                              // %if.then266
                                        //   in Loop: Header=BB24_28 Depth=1
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
		r19 = r0
		r1:0 = combine(r3,r2)
	}
	.falign
// %bb.85:                              // %if.then266
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r3:2 = combine(r1,r0)
		r4 = memw(r23+##hexkl_probe_us@GOT)
		r7:6 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r3:2 = sub(r3:2,r7:6)
		r0 = r19
	}
	{
		r7:6 = memd(r4+#24)
	}
	{
		r3:2 = add(r3:2,r7:6)
	}
	{
		memd(r4+#24) = r3:2
	}
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
		r27 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB24_87
		r2 = memw(r2+#0)
	}
	.falign
.LBB24_86:                              //   in Loop: Header=BB24_28 Depth=1
	{
		r2 = #0
		r27 = memw(r29+#60)
		r4 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB24_87:                              // %do.end272
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB24_90
		if (p0.new) r5 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
// %bb.88:                              // %for.cond
                                        //   in Loop: Header=BB24_28 Depth=1
	{
		r5 = add(r5,#64)
		memw(r29+#48) = r5.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.gtu(r4,r5)
		if (!p0.new) r0 = #0
		r5 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r5,#-64)
		if (p0) jump:nt .LBB24_28
		memw(r29+#100) = r5.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB24_90:                              // %cleanup287
	{
		call free
		r16 = r0
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.91:                              // %cleanup287
	{
		call free
		r0 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.92:                              // %cleanup287
	{
		r0 = r16 ; jump .LBB24_14
	}
	.falign
.LBB24_93:                              // %cond.end.thread
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r0 = add(r18,#-32749)
	}
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		jump .LBB24_14
		memd(r2+#136) = r5:4
	}
	.falign
.LBB24_94:                              // %if.then75
	{
		call free
		r16 = r0
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.95:                              // %if.then75
	{
		call free
		r0 = r16
	}
	.falign
// %bb.96:                              // %if.then75
	{
		r0 = r23 ; jump .LBB24_14
	}
.Lfunc_end24:
	.size	hexkl_mm_u8i4_gate_up_swiglu_run, .Lfunc_end24-hexkl_mm_u8i4_gate_up_swiglu_run
                                        // -- End function
	.type	hexkl_mm_u8i4_fused_run.kDefaults,@object // @hexkl_mm_u8i4_fused_run.kDefaults
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
hexkl_mm_u8i4_fused_run.kDefaults:
	.space	96
	.size	hexkl_mm_u8i4_fused_run.kDefaults, 96

	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym hexkl_bake_u8i4_worker
	.addrsig_sym fc_affine_sums_worker
	.addrsig_sym fc_row_post
	.addrsig_sym fc_affine_worker
	.addrsig_sym hvx_dq_tiles_rows_worker
	.addrsig_sym hexkl_mm_u8i4_fused_run.kDefaults
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#hexkl_bake_u8i4_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#fc_affine_sums_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#fc_row_post#(void)#(ptr, ptr, i32)#1##"
	.ascii	"C#fc_affine_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#hvx_dq_tiles_rows_worker#(void)#(i32, i32, ptr)#1##"

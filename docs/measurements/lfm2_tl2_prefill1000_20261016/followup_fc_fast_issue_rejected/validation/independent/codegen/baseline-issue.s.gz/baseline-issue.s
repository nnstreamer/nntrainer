
.LBB15_171:                             // %for.body587.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        //         Parent Loop BB15_169 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		r3 = add(r0,r26)
		r2 = r27
		p2 = cmp.eq(r24,#0)
		if (p2.new) jump:nt .LBB15_174
	}
// %bb.172:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		call hexkl_micro_hmx_mm_u8i4
		r2 = add(r17,r27)
		r1 = r26
	}
	.falign
// %bb.173:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:t .LBB15_175
	}
	{
		jump .LBB15_235
	}
	.falign
.LBB15_174:                             // %mm_u8i4_tile.exit.thread.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		r4 = #31
		r5 = #384
	}
	{
		r2 += add(r0,r17)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	.falign
.LBB15_175:                             // %for.inc606.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		r26 = add(r26,#2048)
		r2 = memw(r29+#40)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r27,r2)
		r18 = add(r18,#-1)
		if (!cmp.eq(r18.new,#0)) jump:t .LBB15_171
	}
	.falign

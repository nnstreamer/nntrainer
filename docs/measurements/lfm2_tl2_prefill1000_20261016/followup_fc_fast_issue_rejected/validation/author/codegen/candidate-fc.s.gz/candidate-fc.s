hexkl_mm_u8i4_layer_run:                // @hexkl_mm_u8i4_layer_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#672):raw
	}                                       // 8-byte Folded Spill
	{
		r25 = ##-2147449855
		memd(r29+#632) = r25:24
		memd(r29+#656) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r24 = add(r25,#-32755)
		memd(r29+#648) = r21:20
		memd(r29+#640) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB15_38
		memd(r29+#624) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB15_38
	}
// %bb.2:                               // %entry
	{
		r16 = memw(r29+#680)
		if (cmp.eq(r16.new,#0)) jump:nt .LBB15_38
	}
// %bb.3:                               // %entry
	{
		r17 = memw(r29+#684)
		if (cmp.eq(r17.new,#0)) jump:nt .LBB15_38
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r26 = add(pc,##hexkl_mm_u8i4_fused_run.kDefaults@PCREL)
		r23 = memw(r29+#688)
		r6 = memw(r29+#696)
	}
	{
		p1 = cmp.eq(r6,#0)
		p0 = cmp.eq(r23,#0)
		if (!p1.new) r26 = add(r6,#0)
		r20 = memw(r29+#692)
	}
	{
		p1 = cmp.eq(r20,#0)
		if (!p0) jump:nt .LBB15_6
	}
// %bb.5:                               // %land.lhs.true
	{
		r6 = memw(r26+#16)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_20
	}
	.falign
.LBB15_6:                               // %lor.lhs.false11
	{
		if (p1) jump:nt .LBB15_38
	}
	.falign
.LBB15_7:                               // %lor.lhs.false13
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB15_38
	}
// %bb.8:                               // %lor.lhs.false13
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB15_38
	}
// %bb.9:                               // %if.end
	{
		r6 = memw(r26+#32)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_22
	}
// %bb.10:                              // %land.lhs.true19
	{
		r6 = memw(r26+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.11:                              // %lor.lhs.false21
	{
		r6 = memw(r26+#24)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.12:                              // %lor.lhs.false23
	{
		r6 = memw(r26+#4)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.13:                              // %lor.lhs.false25
	{
		r19:18 = combine(r2,r5)
		r27 = r0
		r6 = memw(r26+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.14:                              // %lor.lhs.false28
	{
		r6 = memw(r26+#36)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.15:                              // %lor.lhs.false30
	{
		r6 = memw(r26+#40)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.16:                              // %lor.lhs.false32
	{
		r1:0 = combine(r6,r5)
		memw(r29+#36) = r1
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_umodsi3
		r22 = r3
		r21 = r4
	}
	.falign
// %bb.17:                              // %lor.lhs.false32
	{
		if (p1.new) r0 = add(r27,#0)
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:t .LBB15_38
	}
// %bb.18:                              // %lor.lhs.false32.if.end36_crit_edge
	{
		p1 = or(p1,!p1)
		r2 = memw(r26+#8)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_38
	}
// %bb.19:
	{
		r5:4 = combine(r18,r21)
		r3:2 = combine(r22,r19)
		r1 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_23
	}
	.falign
.LBB15_20:                              // %land.lhs.true9
	{
		if (p1) jump:nt .LBB15_38
	}
// %bb.21:                              // %land.lhs.true9
	{
		r6 = memw(r26+#32)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_7
	}
	{
		jump .LBB15_38
	}
	.falign
.LBB15_22:                              // %if.end36
	{
		r6 = memw(r26+#8)
		r7 = memw(r26+#4)
	}
	{
		p0 = cmp.eq(r6,#0)
		p1 = cmp.eq(r7,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:t .LBB15_38
	}
	.falign
.LBB15_23:                              // %if.end44
	{
		if (!p1) jump:nt .LBB15_25
	}
// %bb.24:                              // %if.end44
	{
		r6 = memw(r26+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
	.falign
.LBB15_25:                              // %if.end53
	{
		r6 = memw(r26+#20)
	}
	{
		p0 = cmp.eq(r6,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = and(p0,!p1)
		if (!p1.new) r21 = #0
		if (p1.new) jump:t .LBB15_38
		if (!p1.new) r7 = memw(r26+#48)
	}
// %bb.26:                              // %if.end62
	{
		p0 = cmp.eq(r7,#0)
		r8 = memw(r26+#44)
		r6 = memw(r26+#80)
	}
	{
		p1 = cmp.eq(r8,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p0 = xor(p1,p0)
		if (!p0.new) jump:t .LBB15_38
	}
// %bb.27:                              // %if.end70
	{
		r6 = #0
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB15_37
	}
// %bb.28:                              // %if.then73
	{
		if (p1) jump:nt .LBB15_38
		if (!p1) r9 = memw(r26+#52)
	}
// %bb.29:                              // %lor.lhs.false77
	{
		p1 = cmp.eq(r9,#0)
		if (!p1.new) r9 = add(r16,#0)
		if (p1.new) jump:nt .LBB15_38
	}
// %bb.30:
	{
		loop0(.LBB15_31,r17)
	}
	.falign
.LBB15_31:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r12 = #4095
	}
	{
		r12 = memw(r9+#0)
		if (cmp.gtu(r12.new,r12)) jump:nt .LBB15_38
	}
// %bb.32:                              // %lor.lhs.false86
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r9 = add(r9,#4)
		r13 = memw(r8+#0)
		if (!cmp.eq(r13.new,r21)) jump:nt .LBB15_38
	}
// %bb.33:                              // %if.end92
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r13 = r0
		r8 = add(r8,#4)
	}
	{
		r13 += mpyi(r12,#96)
	}
	{
		r12 = memw(r13+#32)
	}
	{
		r21 = add(r12,r21)
		nop
	} :endloop0
// %bb.34:
	{
		r8 = r17
	}
	.falign
.LBB15_35:                              // %for.body100
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = memw(r7+#0)
		if (!cmp.eq(r9.new,r21)) jump:nt .LBB15_38
	}
// %bb.36:                              // %for.cond96
                                        //   in Loop: Header=BB15_35 Depth=1
	{
		r7 = add(r7,#4)
		r8 = add(r8,#-1)
		if (!cmp.eq(r8.new,#0)) jump:t .LBB15_35
	}
	.falign
.LBB15_37:                              // %if.end112
	{
		r13 = lsr(r5,#5)
		p0 = !bitsclr(r5,#31)
		r28 = add(r4,#63)
		if (!p0.new) jump:nt .LBB15_39
	}
	.falign
.LBB15_38:                              // %cleanup1078
	{
		r0 = r24
		r19:18 = memd(r29+#656)
		r17:16 = memd(r29+#664)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#648)
		r23:22 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#632)
		r27:26 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB15_39:
	{
		r27 = #0
		r8 = r16
		r7 = #1
		r18 = #0
	}
	{
		r14 = lsr(r28,#6)
		r15 = and(r28,#-64)
	}
	{
		loop0(.LBB15_40,r17)
	}
	.falign
.LBB15_40:                              // Block address taken
                                        // %for.body126
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
	}
	{
		r9 = memw(r8+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt .LBB15_38
	}
// %bb.41:                              // %lor.lhs.false130
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r0+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB15_38
	}
// %bb.42:                              // %if.end136
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = add(r0,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r5)) jump:nt .LBB15_38
	}
// %bb.43:                              // %if.end144
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r8 = add(r8,#4)
		r12 = memw(r9+#32)
		r9 = memw(r9+#20)
	}
	{
		r18 = maxu(r12,r18)
		r9 = lsr(r12,#5)
		p0 = cmp.eq(r9,#0)
		if (!p0.new) r27 = add(r7,#0)
	}
	{
		r6 = maxu(r9,r6)
		nop
	} :endloop0
// %bb.44:                              // %for.end165
	{
		r7 = extractu(r13,#21,#0)
		r8 = extractu(r13,#23,#0)
		r24 = add(r25,#-32767)
	}
	{
		r7 = asl(r7,#11)
		r8 = asl(r8,#9)
	}
	{
		r9 = mpyi(r7,r14)
		r12 = mpyi(r8,r6)
		memw(r29+#48) = r9.new
	}                                       // 4-byte Folded Spill
	{
		r10 = minu(r2,r3)
		r19 = add(r12,r9)
		memw(r29+#312) = r9
	}
	{
		r6 = add(r12,add(r19,##2047))
		memw(r29+#316) = r19
	}
	{
		r6 = insert(r9,#11,#0)
	}
	{
		r2 = add(r6,#16384)
		if (cmp.gtu(r2.new,r10)) jump:t .LBB15_38
	}
// %bb.45:                              // %if.end194
	{
		r2 = sub(r10,r6)
		r1 = memw(r26+#52)
		memw(r29+#36) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = lsr(r2,#14)
		p1 = cmp.eq(r1,#0)
		r0 = #32
		memw(r29+#68) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = minu(r2,r0)
		memw(r29+#44) = r12
		memw(r29+#120) = r28
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#116) = r8
		memw(r29+#124) = r7
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#80) = r15
		memw(r29+#128) = r14
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#104) = r13
		memw(r29+#112) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#40) = r4
		memw(r29+#76) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#84) = r6
		memw(r29+#52) = r10
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB15_54
		memw(r29+#64) = r2
	}                                       // 4-byte Folded Spill
// %bb.46:                              // %for.body209.lr.ph
	{
		r3 = #0
		r1 = #1
		r4 = memw(r26+#56)
		r2 = memw(r26+#72)
	}
	{
		loop0(.LBB15_48,r17)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB15_49
	}
	.falign
.LBB15_48:                              // Block address taken
                                        // %for.body209
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r2,r3)
		r3 = add(r3,#1)
		r5 = #0
		r6 = memw(r4+#0)
	}
	{
		r4 = add(r4,#4)
		if (p1) r5 = memw(r26+#68)
	}
	{
		r5 = maxu(r6,r5)
	}
	{
		r5 = lsr(r5,#5)
	}
	{
		r1 = maxu(r5,r1)
		nop
	} :endloop0
	{
		jump .LBB15_51
	}
	.falign
.LBB15_49:
	{
		loop0(.LBB15_50,r17)
	}
	.balign 32
.LBB15_50:                              // Block address taken
                                        // %for.body209.us
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r2,r3)
		r4 = #0
		r3 = add(r3,#1)
	}
	{
		if (p1) r4 = memw(r26+#68)
	}
	{
		r4 = lsr(r4,#5)
	}
	{
		r1 = maxu(r4,r1)
		nop
	} :endloop0
	.falign
.LBB15_51:                              // %for.cond.cleanup208
	{
		r2 = memw(r29+#64)
		if (cmp.gtu(r1,r2.new)) jump:t .LBB15_54
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then242
	{
		r22 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r0 = r22
	}
	.falign
// %bb.53:                              // %if.then242
	{
		r22 = sub(r22,r0)
		memw(r29+#64) = r22.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_54:                              // %if.end246
	{
		r5:4 = combine(r17,r16)
		r2 = memw(r29+#52)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#44)
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#48)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#68)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Reload
	{
		r22 = memw(r29+#36)
		memw(r29+#12) = r19
	}                                       // 4-byte Folded Reload
	{
		r1 = r22
		r2 = memw(r29+#40)
		memw(r29+#0) = r26
	}                                       // 4-byte Folded Reload
	{
		call lfm2_fc_hmx_issue_ok
		r3 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.55:                              // %if.end246
	{
		call hexkl_dma_ring_reset
		memw(r29+#108) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.56:                              // %if.end246
	{
		call hexkl_acc_layout_get
		r0 = r22
		r1 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.57:                              // %if.end246
	{
		r2 = memw(r0+#4)
		memw(r29+#56) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p1 = cmp.eq(r2,#0)
		memw(r29+#44) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p1
		if (p1) jump:nt .LBB15_89
		memw(r29+#52) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.58:                              // %cond.end251.thread
	{
		r1 = #0
		r3 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r3+#12)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	.falign
.LBB15_59:                              // %if.end260
	{
		p1 = cmp.eq(r27,#0)
		r2 = #0
		memw(r29+#72) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		if (!p1) r2 = memw(r29+#40)
		memw(r29+#60) = r2
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB15_62
		memw(r29+#100) = r0
	}                                       // 4-byte Folded Spill
// %bb.60:                              // %cond.true262
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.61:                              // %cond.true262
	{
		memw(r29+#60) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_62:                              // %cond.end266
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB15_65
		if (p2.new) r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
// %bb.63:                              // %cond.false271
	{
		r2 = mpyi(r2,r18)
	}
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.64:                              // %cond.false271
	{
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_65:                              // %cond.end275
	{
		r1 = #0
		r2 = memw(r26+#4)
		memw(r29+#136) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		memw(r29+#88) = r1
		memw(r29+#92) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p0
		if (p0) r2 = memw(r29+#80)
		memw(r29+#96) = r1
	}                                       // 4-byte Folded Reload
	{
		if (!p0) jump:nt .LBB15_69
		memw(r29+#132) = r0
	}                                       // 4-byte Folded Spill
// %bb.66:                              // %if.then280
	{
		r25 = asl(r2,#2)
	}
	{
		call malloc
		r0 = r25
	}
	.falign
// %bb.67:                              // %if.then280
	{
		call malloc
		r0 = r25
		memw(r29+#96) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.68:                              // %if.then280
	{
		memw(r29+#92) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_69:                              // %if.end285
	{
		r2 = memw(r29+#52)
		r18 = memw(r26+#80)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_73
	}
// %bb.70:                              // %if.end285
	{
		p1 = cmp.eq(r18,#0); if (p1.new) jump:nt .LBB15_73
		if (!p1.new) r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
// %bb.71:                              // %cond.true292
	{
		call malloc
		r0 = asl(r2,#7)
	}
	.falign
// %bb.72:                              // %cond.true292
	{
		memw(r29+#88) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_73:                              // %cond.end296
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_75
	}
// %bb.74:                              // %cond.end296
	{
		r2 = memw(r29+#60)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_75:                              // %lor.lhs.false301
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB15_77
	}
// %bb.76:                              // %lor.lhs.false301
	{
		r2 = memw(r29+#72)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_77:                              // %lor.lhs.false306
	{
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB15_80
	}
// %bb.78:                              // %land.lhs.true310
	{
		r2 = memw(r29+#92)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_83
	}                                       // 4-byte Folded Reload
// %bb.79:                              // %land.lhs.true310
	{
		r2 = memw(r29+#96)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_83
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_80:                              // %lor.lhs.false314
	{
		p0 = cmp.eq(r18,#0); if (p0.new) jump:nt .LBB15_91
		if (!p0.new) r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
// %bb.81:                              // %lor.lhs.false314
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_91
	}
// %bb.82:                              // %lor.lhs.false314
	{
		r2 = memw(r29+#88)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB15_91
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_83:                              // %if.then323
	{
		call free
		r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.84:                              // %if.then323
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.85:                              // %if.then323
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.86:                              // %if.then323
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.87:                              // %if.then323
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.88:                              // %if.then323
	{
		jump .LBB15_38
	}
	.falign
.LBB15_89:                              // %cond.end251
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	{
		r2 = memw(r26+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_59
	}
// %bb.90:
	{
		r24 = add(r25,#-32749)
		jump .LBB15_38
	}
	.falign
.LBB15_91:                              // %if.end324
	{
		r2 = memw(r16+#0)
		r18 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#116)
		r1 = memw(r26+#8)
	}                                       // 4-byte Folded Reload
	{
		r18 += mpyi(r2,#96)
		memw(r29+#212) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r18+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r24 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r24
	}
	.falign
// %bb.92:                              // %if.end324
	{
		r25 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r25,r24)
		r24 = memw(r18+#4)
	}
	.falign
// %bb.93:                              // %if.end324
	{
		r5:4 = combine(r0,r25)
		r1 = r24
		r2 = memw(r29+#36)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r3)
		r3:2 = combine(r25,r25)
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	{
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.94:                              // %if.end324
	{
		r24 = memw(r26+#16)
		if (cmp.eq(r24.new,#0)) jump:nt .LBB15_101
	}
// %bb.95:                              // %if.then342
	{
		r18 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		call dma_row_size_dividing
		r0 = r18
	}
	.falign
// %bb.96:                              // %if.then342
	{
		r23 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r18)
	}
	.falign
// %bb.97:                              // %if.then342
	{
		r5:4 = combine(r0,r23)
		r1 = r24
		r3:2 = combine(r23,r23)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.98:                              // %if.then342
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_104
	}
// %bb.99:                              // %if.then348
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.100:                             // %if.then348
	{
		jump .LBB15_105
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_101:                             // %do.body360
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_109
	}
// %bb.102:                             // %if.then362
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.103:                             // %if.then362
	{
		jump .LBB15_110
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_104:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_105:                             // %do.end
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.106:                             // %do.end
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_125
	}
// %bb.107:                             // %if.then353
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.108:                             // %if.then353
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB15_125
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_109:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_110:                             // %do.end366
	{
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r0 = add(r23,#0)
		if (p2.new) jump:nt .LBB15_113
		if (p2.new) r1 = memw(r26+#32)
	}
// %bb.111:                             // %if.else377
	{
		r2 = memw(r26+#0)
		memw(r29+#4) = r2.new
	}
	{
		r1 = memw(r29+#40)
		r2 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#76)
		r5 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#136)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		memw(r29+#0) = r6
	}
	.falign
// %bb.112:                             // %if.else377
	{
		r24 = r0
		jump .LBB15_115
	}
	.falign
.LBB15_113:                             // %if.then369
	{
		r5 = memw(r26+#24)
		r2 = memw(r26+#36)
	}
	{
		r4 = memw(r29+#36)
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r26+#40)
		r6 = memw(r26+#28)
	}
	{
		r7 = memw(r26+#20)
	}
	{
		r8 = memw(r26+#0)
		memw(r29+#24) = r4

	} :mem_noshuf
	{
		r0 = r23
		memw(r29+#4) = r5
		memw(r29+#0) = r0
	}
	{
		r4 = memw(r29+#40)
		memw(r29+#28) = r8
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#80)
		memw(r29+#12) = r7
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#92)
		memw(r29+#20) = r18.new
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#96)
		memw(r29+#16) = r19.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_params_pack_u8_ah
		memw(r29+#8) = r6
	}
	.falign
// %bb.114:                             // %if.then369
	{
		r24 = r0
		memw(r29+#212) = r18
		memw(r29+#136) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_115:                             // %do.body382
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_118
	}
// %bb.116:                             // %if.then384
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.117:                             // %if.then384
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB15_118:                             // %if.end391
	{
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB15_125
		if (!p1.new) r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
// %bb.119:                             // %if.then394
	{
		call free
	}
	.falign
// %bb.120:                             // %if.then394
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.121:                             // %if.then394
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.122:                             // %if.then394
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.123:                             // %if.then394
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.124:                             // %if.then394
	{
		jump .LBB15_38
	}
	.falign
.LBB15_125:                             // %if.end395
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_127
		if (!p0.new) r4 = memw(r29+#76)
		if (!p0.new) r7 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
// %bb.126:                             // %if.then397
	{
		r1 = add(pc,##fc_affine_sums_worker@PCREL)
		r2 = memw(r29+#36)
		memw(r29+#464) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#464)
		r0 = memw(r29+#40)
		memw(r29+#468) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#128)
		memw(r29+#476) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r26+#0)
		memw(r29+#472) = r4
	}
	{
		r6 = memw(r29+#60)
		memw(r29+#480) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#484) = r6
	}
	.falign
.LBB15_127:                             // %if.end401
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_130
		if (!p0.new) r2 = memw(r26+#12)
	}
// %bb.128:                             // %land.end
	{
		p2 = or(p2,!p2)
		p1 = cmp.eq(r2,#0)
	}
	{
		r0 = p2
		if (p1) jump:nt .LBB15_253
		memw(r29+#284) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.129:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		p1 = or(p1,!p1)
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		jump .LBB15_131
		memw(r29+#252) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_130:                             // %land.end.thread
	{
		p2 = or(p2,!p2)
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		r1 = p2
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p2
		memw(r29+#252) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#284) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_131:                             // %if.end470
	{
		r0 = memw(r29+#44)
		r2 = memw(r26+#60)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#204) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_134
	}
// %bb.132:                             // %if.then474
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.133:                             // %if.then474
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_134:                             // %do.end478
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.135:                             // %do.end478
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_138
	}
// %bb.136:                             // %if.then481
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.137:                             // %if.then481
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r5:4 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_138:                             // %for.body493.lr.ph
	{
		r3 = memw(r29+#64)
		memw(r29+#160) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r3,#13)
		r1 = asl(r3,#9)
		r0 = memw(r29+#36)
		memw(r29+#236) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r0,#11,#0)
		r0 = asl(r3,#7)
		r1 = memw(r29+#120)
		memw(r29+#272) = r1
	}                                       // 4-byte Folded Reload
	{
		r0 = #0
		p2 = cmp.gtu(r1,#63)
		memw(r29+#276) = r0
		memw(r29+#260) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#208) = r2.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#144) = r0
		memw(r29+#196) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#140) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_139:                             // %for.body493
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB15_168 Depth 2
                                        //       Child Loop BB15_169 Depth 3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
                                        //     Child Loop BB15_158 Depth 2
	{
		r2 = add(r29,#312)
		r3 = memw(r26+#44)
		r0 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r3,#0)
		r18 = memw(r29+#144)
		r7 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		if (!p0) r4 = memw(r29+#140)
		r1 = memw(r26+#48)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r2 = insert(r5,#1,#2)
		r6 = add(r5,#1)
		if (!p0) r18 = memw(r3+r4<<#2)
		r4 = memw(r0+#0)
	}
	{
		r3 = addasl(r1,r5,#2)
		p0 = cmp.eq(r1,#0)
		p1 = cmp.gtu(r17,r6)
		memw(r29+#168) = r6
	}                                       // 4-byte Folded Spill
	{
		r7 += mpyi(r4,#96)
		r2 = memw(r2+#0)
		memw(r29+#172) = r2.new
	}                                       // 4-byte Folded Spill
	{
		if (p0) r3 = add(r7,#32)
		if (p1) r22 = memw(r29+#68)
		memw(r29+#100) = r7
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r7+#32)
		r0 = memw(r3+#0)
	}
	{
		if (!p1) jump:nt .LBB15_143
		if (p1) r25 = memw(r29+#168)
		memw(r29+#152) = r0
	}                                       // 4-byte Folded Reload
// %bb.140:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r3 = memw(r29+#116)
		r2 = memw(r16+r25<<#2)
	}                                       // 4-byte Folded Reload
	{
		r22 += mpyi(r2,#96)
	}
	{
		r2 = memw(r22+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r23 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r23
	}
	.falign
// %bb.141:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = add(r29,#312)
		r24 = r0
	}
	{
		r2 = insert(r25,#1,#2)
		r1:0 = combine(r24,r23)
		r23 = memw(r22+#4)
	}
	{
		call __hexagon_udivsi3
		r22 = memw(r2+#0)
	}
	.falign
// %bb.142:                             // %if.then523
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5:4 = combine(r0,r24)
		r1 = r23
		r2 = memw(r29+#36)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r0 = add(r2,r22)
		r3:2 = combine(r24,r24)
		memw(r29+#0) = #0
	}
	.falign
.LBB15_143:                             // %if.end540
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB15_145
	}
// %bb.144:                             // %for.body545.lr.ph
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5 = addasl(r20,r18,#2)
		r4 = lsr(r19,#5)
		p0 = cmp.gtu(r19,#31); if (p0.new) jump:t .LBB15_167
	}
	.falign
.LBB15_145:                             // %do.body933
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_148
	}
// %bb.146:                             // %if.then935
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.147:                             // %if.then935
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_148:                             // %do.end939
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.149:                             // %do.end939
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_152
	}
// %bb.150:                             // %if.then942
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.151:                             // %if.then942
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_152:                             // %do.end948
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_164
	}
// %bb.153:                             // %do.body952
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_156
	}
// %bb.154:                             // %if.then954
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.155:                             // %if.then954
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_156:                             // %do.end958
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r2+#20)
		r23 = memw(r2+#32)
	}
	{
		r18 = asl(r23,#8)
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB15_160
		if (!p1.new) r22 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
// %bb.157:                             // %for.body967.preheader
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r19 = #0
		r27 = memw(r29+#60)
		r25 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_158:                             // %for.body967
                                        //   Parent Loop BB15_139 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = #64
		r1:0 = combine(r23,r25)
		r3 = r23
		r5:4 = combine(r27,r24)
	}
	{
		r2 = minu(r22,r2)
		call hexkl_wh_affine_acc
	}
	.falign
// %bb.159:                             // %for.body967
                                        //   in Loop: Header=BB15_158 Depth=2
	{
		r19 = add(r19,#64)
		r22 = add(r22,#-64)
		r27 = add(r27,#256)
		r25 = add(r25,r18)
	}
	{
		r2 = memw(r29+#40)
		if (cmp.gtu(r2.new,r19)) jump:t .LBB15_158
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_160:                             // %if.end988
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
		r3 = memw(r26+#12)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#72)
		r1 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r2 = memw(r29+#144)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r20,r2,#2)
		memw(r29+#12) = r2.new
	}
	{
		r3 = r23
		r2 = memw(r29+#80)
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r4
		memw(r29+#0) = r5
	}
	{
		call hvx_dequant_i32_to_f32
		r4 = memw(r29+#136)
		r5 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.161:                             // %if.end988
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_164
	}
// %bb.162:                             // %if.then997
                                        //   in Loop: Header=BB15_139 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.163:                             // %if.then997
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_164:                             // %if.end1004
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
	}
	{
		r3 = memw(r26+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_166
	}
// %bb.165:                             // %if.then1010
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r4 = memw(r29+#140)
		r0 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r4 = addasl(r0,r3,#2)
		memw(r29+#204) = r4.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_166:                             // %for.inc1022
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r5 = memw(r29+#168)
		memw(r29+#140) = r5.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r5,r17)
		if (p0.new) r24 = #0
		r3 = memw(r29+#40)
		r4 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r2,r3)
		r2 = add(r0,#4)
		memw(r29+#144) = r4.new
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB15_139
		memw(r29+#160) = r2
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_266
	}
	.falign
.LBB15_167:                             // %for.body545.us.preheader
                                        //   in Loop: Header=BB15_139 Depth=1
	{
		r2 = memw(r29+#36)
		r3 = memw(r29+#172)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r2)
		r1 = #0
		r0 = memw(r29+#152)
		memw(r29+#224) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r0,#8)
		r0 = #0
		r1 = memw(r29+#88)
		memw(r29+#308) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r4,#23,#0)
		r0 = memw(r29+#260)
		memw(r29+#228) = r0
	}                                       // 4-byte Folded Reload
	{
		r3 = or(r0,and(r3,#127))
		r2 = asl(r2,#9)
		memw(r29+#184) = r3
		memw(r29+#200) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#268) = r5
		memw(r29+#264) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#296) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#48) = r2
		memw(r29+#52) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_168:                             // %for.body545.us
                                        //   Parent Loop BB15_139 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB15_169 Depth 3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
	{
		r4 = #0
		r5 = memw(r29+#228)
		r3 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		r6 = asl(r5,#7)
		r2 = asl(r5,#6)
		r1 = memw(r29+#196)
		memw(r29+#304) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r5)
		p1 = tstbit(r1,#0)
		r6 = memw(r29+#152)
		memw(r29+#232) = r4
	}                                       // 4-byte Folded Reload
	{
		r4 = p1
		r0 = memw(r29+#40)
		memw(r29+#248) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r6 = mpyi(r2,r6)
		r4 = asl(r5,#8)
		p1 = cmp.gtu(r0,r2)
		r5 = sub(r0,r2)
	}
	{
		r2 = mpyi(r2,r21)
		r0 = memw(r29+#60)
		memw(r29+#300) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r4)
		r0 = #64
		r1 = memw(r29+#136)
		memw(r29+#164) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r5 = minu(r5,r0)
		r2 = add(r1,r4)
		r1 = memw(r29+#264)
		memw(r29+#240) = r1.new
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r5 = #0
		r0 = memw(r29+#212)
		memw(r29+#188) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r4)
		r0 = #0
		r1 = memw(r29+#36)
		memw(r29+#192) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,r3)
		r0 = #0
		r1 = memw(r29+#200)
		memw(r29+#216) = r0
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r5,#0)
		r1 = memw(r29+#268)
		memw(r29+#220) = r1
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r6,#2)
		r0 = p0
		memw(r29+#180) = r2
		memw(r29+#156) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#292) = r2
		memw(r29+#132) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#280) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_169:                             // %for.body566.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB15_170 Depth 4
                                        //           Child Loop BB15_175 Depth 5
                                        //         Child Loop BB15_191 Depth 4
                                        //         Child Loop BB15_198 Depth 4
                                        //         Child Loop BB15_220 Depth 4
	{
		r18 = #0
		r0 = memw(r29+#196)
		r2 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r5 = and(r0,#1)
		r3 = memw(r29+#156)
		r1 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r3)
		r0 = memw(r29+#220)
		memw(r29+#256) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r1)
		r19 = minu(r1,r0)
		r1 = memw(r29+#236)
		memw(r29+#176) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r4 = memw(r29+#84)
		r27 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r1,r5)
		r0 = p0
		memw(r29+#148) = r4.new
	}                                       // 4-byte Folded Spill
	{
		if (p0) jump:nt .LBB15_189
		memw(r29+#244) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_170:                             // %for.body583.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Loop Header: Depth=4
                                        //           Child Loop BB15_175 Depth 5
	{
		r2 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r22 = r2
		memw(r29+#120) = r22.new
	}                                       // 4-byte Folded Spill
	.falign
// %bb.171:                             // %for.body583.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = r22
	}
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_174
		if (!p0.new) r0 = memw(r29+#180)
		if (!p0.new) r1 = memw(r29+#184)
	}                                       // 4-byte Folded Reload
// %bb.172:                             // %if.then585.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r18,r2)
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		r1 += asl(r3,#9)
		call lfm2_fc_issue_aligned
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.173:                             // %if.then585.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		jump .LBB15_180
	}
	.falign
.LBB15_174:                             // %for.cond597.preheader.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#76)
		r25 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,#31); if (!p0.new) jump:t .LBB15_180
		r23 = memw(r29+#172)
		r22 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_175:                             // %for.body601.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        //         Parent Loop BB15_170 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		r5 = #384
		r4 = #31
		r2 = memw(r29+#52)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r25)
		if (p1.new) r2 = add(r23,#0)
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB15_178
	}
// %bb.176:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		call hexkl_micro_hmx_mm_u8i4
		r2 = add(r27,r23)
		r1 = r25
	}
	.falign
// %bb.177:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		p0 = cmp.eq(r0,#0); if (p0.new) jump:t .LBB15_179
	}
	{
		jump .LBB15_239
	}
	.falign
.LBB15_178:                             // %mm_u8i4_tile.exit.thread.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		r2 += add(r0,r27)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	.falign
.LBB15_179:                             // %for.inc620.us
                                        //   in Loop: Header=BB15_175 Depth=5
	{
		r25 = add(r25,#2048)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r23 = add(r23,r2)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB15_175
	}
	.falign
.LBB15_180:                             // %do.body626.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_183
	}
// %bb.181:                             // %if.then628.us
                                        //   in Loop: Header=BB15_170 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.182:                             // %if.then628.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_183:                             // %do.end632.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#148)
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r18,#13)
		call hexkl_micro_hmx_acc_read_int32
		r1 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.184:                             // %do.end632.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r24 = r0
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_187
	}
// %bb.185:                             // %if.then638.us
                                        //   in Loop: Header=BB15_170 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.186:                             // %if.then638.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB15_187:                             // %do.end644.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r27 = add(r27,#512)
		p0 = cmp.eq(r24,#0)
		if (!p0.new) jump:nt .LBB15_240
	}
// %bb.188:                             // %for.cond579.us
                                        //   in Loop: Header=BB15_170 Depth=4
	{
		r18 = add(r18,#1)
		if (!cmp.eq(r18.new,r19)) jump:t .LBB15_170
	}
	.falign
.LBB15_189:                             // %for.end653.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#100)
		r3 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r18 = add(r0,r3)
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_193
	}
// %bb.190:                             // %land.lhs.true656.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r22 = r19
		r24 = r18
		r2 = memw(r29+#56)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r0 = memw(r29+#252)
		r23 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p0)
		p2 = r0
		r2 = memw(r2+#4)
	}
	{
		p0 = cmp.eq(r2,#0)
	}
	{
		p0 = not(p0)
	}
	{
		p1 = and(p2,and(p0,p1))
		if (!p1.new) jump:t .LBB15_193
	}
	.falign
.LBB15_191:                             // %for.body667.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r2 = memw(r29+#56)
		r3 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r3 = #32
		r4 = memw(r2+#8)
		r6 = memw(r3+#20)
	}
	{
		r0 = addasl(r24,r4,#2)
		r4 = add(r6,r23)
		r1 = memw(r2+#12)
		r2 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_acc
		r5 = memw(r29+#164)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.192:                             // %for.body667.us
                                        //   in Loop: Header=BB15_191 Depth=4
	{
		r23 = add(r23,#128)
		r24 = add(r24,#8192)
		r22 = add(r22,#-1)
		if (!cmp.eq(r22.new,#0)) jump:t .LBB15_191
	}
	.falign
.LBB15_193:                             // %if.end682.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB15_207
		if (!p0.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.194:                             // %if.else820.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_218
	}
// %bb.195:                             // %for.cond825.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_237
		if (!p2.new) r2 = memw(r29+##280)
	}                                       // 4-byte Folded Reload
// %bb.196:                             // %for.cond825.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		p2 = r2
		if (!p2.new) r19 = #0
		if (p2.new) jump:nt .LBB15_237
		if (!p2.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.197:                             // %for.body834.lr.ph.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r24 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_198:                             // %for.body834.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB15_201
		r22 = memw(r0+#8)
	}
// %bb.199:                             // %if.then844.us
                                        //   in Loop: Header=BB15_198 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.200:                             // %if.then844.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_201:                             // %do.end848.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r0 = asl(r22,#2)
		r2 = memw(r29+#56)
		r4 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r18,r0)
		r5 = memw(r26+#12)
		r6 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r2+#12)
		r3:2 = memd(r4+#8)
	}
	{
		r2 = add(r2,r24)
		r5 = add(r3,r24)
		r4 = memw(r4+#16)
		memw(r29+#16) = r5

	} :mem_noshuf
	{
		r3 = add(r4,r24)
		r2 = memw(r29+#132)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#188)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#192)
		memw(r29+#12) = r6
	}                                       // 4-byte Folded Reload
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#8) = r25
	}
	.falign
// %bb.202:                             // %do.end848.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_205
	}
// %bb.203:                             // %if.then864.us
                                        //   in Loop: Header=BB15_198 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.204:                             // %if.then864.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_206
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_205:                             //   in Loop: Header=BB15_198 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_206:                             // %do.end870.us
                                        //   in Loop: Header=BB15_198 Depth=4
	{
		r19 = add(r19,#1)
		r24 = add(r24,#128)
		r18 = add(r18,#8192)
		r25 = add(r25,#128)
	}
	{
		r3 = memw(r29+#176)
		if (cmp.gtu(r3.new,r19)) jump:t .LBB15_198
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_237
	}
	.falign
.LBB15_207:                             // %do.body685.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_210
	}
// %bb.208:                             // %if.then687.us
                                        //   in Loop: Header=BB15_169 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.209:                             // %if.then687.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_210:                             // %do.end691.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		call hvx_worker_pool_wait
		r0 = memw(r26+#0)
	}
	.falign
// %bb.211:                             // %do.end691.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_214
	}
// %bb.212:                             // %if.then695.us
                                        //   in Loop: Header=BB15_169 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.213:                             // %if.then695.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_214:                             // %do.end701.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_237
	}
// %bb.215:                             // %if.then704.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r3 = add(r29,#328)
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r2,#68)
		r2 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) r2 = #0
		if (!p2.new) jump:t .LBB15_230
		if (p2.new) r5 = memw(r26+#56)
	}
// %bb.216:                             // %land.lhs.true711.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r4 = #0
		p1 = cmp.eq(r5,#0)
		if (!p1.new) r2 = memw(r29+#140)
		r6 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r2 = memw(r5+r2<<#2)
	}
	{
		r5 = memw(r26+#72)
		memw(r3+#12) = r2
	}
	{
		r0 = memw(r29+#140)
		memw(r3+#0) = r6
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r5,r0)
		r5 = memw(r26+#64)
		memw(r3+#20) = r5.new
	}
	{
		if (!p0) jump:nt .LBB15_231
		r5 = memw(r26+#68)
		memw(r3+#16) = r5.new
	}
// %bb.217:                             // %cond.true727.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r6 = memw(r29+#304)
		r4 = memw(r26+#76)
	}                                       // 4-byte Folded Reload
	{
		r5 = mpyi(r6,r5)
	}
	{
		r4 = addasl(r4,r5,#2)
		jump .LBB15_231
	}
	.falign
.LBB15_218:                             // %for.cond877.preheader.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_237
		if (!p1.new) r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.219:                             // %do.body882.us.preheader
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = +mpyi(r2,#1)
		r3 = memw(r3+##hexkl_probe_on@GOT)
		r27 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#248)
		r0 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p0 = r5
		if (!p0.new) r2 = add(r4,#0)
	}
	{
		r25 = add(r0,r2)
		r2 = memw(r3+#0)
	}
	.falign
.LBB15_220:                             // %do.body882.us
                                        //   Parent Loop BB15_139 Depth=1
                                        //     Parent Loop BB15_168 Depth=2
                                        //       Parent Loop BB15_169 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_223
	}
// %bb.221:                             // %if.then884.us
                                        //   in Loop: Header=BB15_220 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.222:                             // %if.then884.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_223:                             // %do.end888.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r1 = r25
		r4 = r27
		r0 = memw(r29+#36)
		r5 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#100)
		r3 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
		memw(r29+#0) = r2.new
	}
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.224:                             // %do.end888.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r24 = r0
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_227
	}
// %bb.225:                             // %if.then896.us
                                        //   in Loop: Header=BB15_220 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.226:                             // %if.then896.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_228
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_227:                             //   in Loop: Header=BB15_220 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_228:                             // %do.end902.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r27 = add(r27,#1)
		r25 = add(r25,#8192)
		p0 = cmp.eq(r24,#0)
		if (!p0.new) jump:nt .LBB15_240
	}
// %bb.229:                             // %for.cond877.us
                                        //   in Loop: Header=BB15_220 Depth=4
	{
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB15_220
	}
	{
		jump .LBB15_237
	}
	.falign
.LBB15_230:                             // %cond.end718.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#204)
		memw(r3+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r26+#64)
		memw(r3+#20) = r2.new
	}
	{
		r2 = memw(r26+#68)
		memw(r3+#16) = r2.new
	}
	{
		r2 = #0
		memw(r3+#12) = #0
	}
	.falign
.LBB15_231:                             // %cond.end733.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 = memw(r29+#176)
		memw(r3+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r5,#5)
		memw(r3+#8) = r5.new
	}
	{
		r5 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		p1 = r5
		if (p1.new) r6 = #0
		if (!p1.new) jump:t .LBB15_233
		if (!p1.new) r5 = memw(r26+#80)
	}
// %bb.232:                             // %cond.end742.us.thread
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 = memw(r26+#84)
		memw(r3+#28) = r5.new
	}
	{
		r5 = #0 ; jump .LBB15_234
		memw(r3+#24) = #0
		memw(r3+#32) = #0
	}
	.falign
.LBB15_233:                             // %cond.true753.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r7 = memw(r29+#296)
		r6 = memw(r26+#84)
	}                                       // 4-byte Folded Reload
	{
		memw(r3+#32) = r7
	}
	{
		r7 = memw(r29+#300)
		memw(r3+#28) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r7,#2)
		r6 = memw(r26+#44)
		memw(r3+#24) = r5.new
	}
	{
		r7 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r6+r7<<#2)
		r7 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r7,#5)
	}
	.falign
.LBB15_234:                             // %cond.end759.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r5 |= or(r2,r4)
		r7 = memw(r29+#168)
		r9 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(pc,##fc_row_post@PCREL)
		r0 = cmp.eq(r9,#0)
		r1 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r7,r17)
		r6 = or(r9,r1)
		r12 = memw(r29+#176)
		memw(r3+#36) = r6
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r12,r9)
		r6 = cmp.eq(r6,#0)
		r0 = memw(r29+#256)
		memw(r3+#52) = r0
	}                                       // 4-byte Folded Reload
	{
		r8 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,r8)
		r2 = cmp.eq(r2,r8)
		r1 = memw(r26+#88)
		memw(r3+#60) = r1.new
	}
	{
		r7 = +mpyi(r0,#76)
		p1 = and(p0,p1)
		r1 = memw(r26+#92)
		memw(r3+#44) = r6
	}
	{
		r6 = add(r29,#464)
		p0 = cmp.eq(r5,#0)
		memw(r3+#56) = r2
	}
	{
		r2 = add(r6,r7)
		if (p0) r4 = #0
		r1 = memw(r29+#56)
		memw(r3+#64) = r1
	}                                       // 4-byte Folded Reload
	{
		r5 = mux(p1,#1,#0)
		memw(r3+#40) = r21
		memw(r2+#60) = r4
	}
	{
		memw(r2+#64) = r3
		memw(r3+#48) = r5
	}
	{
		r3 = memw(r29+#36)
		r0 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r0)
		r0 = memw(r1+#8)
		memw(r2+#4) = ##8192

	} :mem_noshuf
	{
		r3 = addasl(r3,r0,#2)
		memw(r6+r7<<#0) = r3.new
	}
	{
		memw(r2+#8) = r9
		r3 = memw(r1+#12)

	} :mem_noshuf
	{
		r7 = memw(r29+#132)
		memw(r2+#12) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#188)
		memw(r2+#16) = r7
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#100)
		memw(r2+#20) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#192)
		memw(r2+#44) = #0
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r3+#8)
		memw(r2+#24) = r6
	}
	{
		r5:4 = memd(r3+#16)
		memw(r2+#56) = r12
	}
	{
		p1 = cmp.eq(r5,#0)
		r3 = memw(r3+#32)
		memw(r2+#28) = r1
	}
	{
		r3 = memw(r29+#152)
		memw(r2+#48) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#44)
		memw(r2+#52) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#292)
		memw(r2+#36) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#32) = r0
		memw(r2+#40) = r4
	}
	{
		if (p1) jump:nt .LBB15_236
		r1 = memw(r3+##hvx_dq_tiles_rows_worker@GOT)
	}
// %bb.235:                             // %if.then811.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r1 = add(pc,##fc_affine_worker@PCREL)
		r3 = memw(r29+#164)
		memw(r2+#68) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#72) = r3
	}
	.falign
.LBB15_236:                             // %for.inc919.us.sink.split
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		call hvx_worker_pool_submit
		r0 = memw(r26+#0)
		r3 = memw(r29+#132)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_237:                             // %for.inc919.us
                                        //   in Loop: Header=BB15_169 Depth=3
	{
		r2 = memw(r29+#64)
		r4 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r2)
		r3 = memw(r29+#196)
		r0 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		p0 = cmp.gtu(r0,r4)
		r1 = memw(r29+#220)
		memw(r29+#196) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r1,r2)
		r1 = memw(r29+#272)
		memw(r29+#220) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#216)
		memw(r29+#156) = r4
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		r0 = memw(r29+#248)
		memw(r29+#216) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r2 = memw(r29+#276)
		r1 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p2)
		r3 = add(r1,r2)
		r0 = memw(r29+#240)
		memw(r29+#232) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r1 = p2
		r3 = add(r0,r2)
		if (!p0) r0 = memw(r29+#124)
		memw(r29+#248) = r1.new
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB15_169
		if (!p0) r3 = memw(r29+#228)
		memw(r29+#240) = r3
	}                                       // 4-byte Folded Reload
// %bb.238:                             // %for.cond562.for.inc928_crit_edge.us
                                        //   in Loop: Header=BB15_168 Depth=2
	{
		r3 = add(r3,#1)
		r2 = memw(r29+#128)
		memw(r29+#228) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r3,r2)
		r1 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r1,r0)
		r0 = memw(r29+#296)
		memw(r29+#224) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,#8192)
		r1 = memw(r29+#308)
		memw(r29+#296) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		if (!p1) jump:nt .LBB15_168
		memw(r29+#264) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_145
	}
	.falign
.LBB15_239:
	{
		r24 = r0
	}
	.falign
.LBB15_240:                             // %do.body1027
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_243
	}
// %bb.241:                             // %if.then1029
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.242:                             // %if.then1029
	{
		memd(r29+#320) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_243:                             // %do.end1033
	{
		call hvx_worker_pool_wait
		r0 = memw(r26+#0)
	}
	.falign
// %bb.244:                             // %do.end1033
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_247
	}
// %bb.245:                             // %if.then1037
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.246:                             // %if.then1037
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#320)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_247:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.248:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.249:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.250:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.251:                             // %cleanup1044
	{
		call free
		r0 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.252:                             // %cleanup1044
	{
		jump .LBB15_38
	}
	.falign
.LBB15_253:                             // %land.end411
	{
		p1 = and(p1,!p1)
		r2 = memw(r26+#52)
	}
	{
		r0 = p1
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_265
		memw(r29+#252) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.254:                             // %for.body422.lr.ph
	{
		p0 = or(p0,!p0)
		r25 = #1
		r2 = memw(r29+#64)
		r18 = memw(r26+#56)
	}                                       // 4-byte Folded Reload
	{
		r23 = asl(r2,#5)
		r1 = p0
		p0 = cmp.eq(r18,#0)
		r19 = memw(r26+#72)
	}
	{
		r0 = p0
		memw(r29+#284) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#48) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_255:                             // %for.body422
                                        // =>This Inner Loop Header: Depth=1
	{
		r24 = #0
		r1 = #0
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = add(r25,#-1)
		if (!p2.new) r1 = memw(r18+#0)
	}
	{
		p1 = cmp.gtu(r19,r2)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB15_258
		if (p1.new) r24 = memw(r26+#68)
	}
// %bb.256:                             // %lor.lhs.false444
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		call __hexagon_umodsi3
		r0 = r23
	}
	.falign
// %bb.257:                             // %lor.lhs.false444
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p1 = cmp.eq(r0,#0); if (!p1.new) jump:nt .LBB15_267
	}
	.falign
.LBB15_258:                             // %land.rhs448
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p0 = or(p0,!p0)
		p1 = cmp.eq(r24,#0)
		if (!p1.new) r1:0 = combine(r24,r23)
		if (p1.new) jump:nt .LBB15_261
	}
// %bb.259:                             // %lor.rhs
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.260:                             // %lor.rhs
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p0 = cmp.eq(r0,#0)
	}
	.falign
.LBB15_261:                             // %land.end454
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		if (p0) r18 = add(r18,#4)
		if (!p0) jump:nt .LBB15_263
	}
// %bb.262:                             // %land.end454
                                        //   in Loop: Header=BB15_255 Depth=1
	{
		p1 = cmp.gtu(r17,r25)
		r25 = add(r25,#1)
		if (p1.new) jump:t .LBB15_255
	}
	.falign
.LBB15_263:                             // %for.cond.cleanup421
	{
		if (!p0) jump:nt .LBB15_268
		if (p0) r3 = memw(r26+#52)
		if (p0) r2 = memw(r26+#80)
	}
// %bb.264:                             // %if.then468
	{
		p0 = or(p0,!p0)
		p2 = cmp.eq(r2,#0)
	}
	{
		r0 = p0
		memw(r29+#288) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		memw(r29+#284) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_131
		memw(r3+#0) = #1
	}
	.falign
.LBB15_265:
	{
		p2 = and(p2,!p2)
	}
	{
		r2 = p2
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_266:
	{
		jump .LBB15_240
	}
	.falign
.LBB15_267:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_268:
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB15_131
		memw(r29+#288) = r2.new
	}                                       // 4-byte Folded Spill
.Lfunc_end15:

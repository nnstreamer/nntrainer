// SPDX-License-Identifier: Apache-2.0
/** Whole production FC caller with the repository's scalar HMX/HVX stand-ins.
 * This checks byte equality between two schedules; it is not a replacement
 * for device parity or an assertion of the scalar stand-ins' hardware math.
 */
#define _POSIX_C_SOURCE 200112L
#include "hexkl_mm_opts.h"
#include "hexkl_mm_u8i4_dma.h"
#include "hexkl_probe.h"
#include "hvx_scalar_stubs.h"
#include <assert.h>
#include <hexkl_micro.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

uint64_t review_align_queries;
static uint8_t *base;
static size_t arena_size;
static uint64_t packets;

void review_packet(const uint8_t *a, const uint8_t *w) {
  assert(a >= base && (size_t)(a - base) + 2048u <= arena_size);
  assert(w >= base && (size_t)(w - base) + 512u <= arena_size);
  assert(((uintptr_t)a & 2047u) == 0u && ((uintptr_t)w & 127u) == 0u);
  assert(hexkl_micro_hmx_mm_u8i4(base, (uint32_t)(a - base),
                                 (uint32_t)(w - base)) == 0);
  ++packets;
}

static void run(FILE *fp, uint32_t M, const uint32_t widths[3], uint32_t nh,
                int interleaved, int tight, int affine) {
  const uint32_t K = 2048u;
  uint32_t total = 0, widest = 0;
  for (uint32_t i = 0; i < nh; ++i) {
    total += widths[i];
    if (widths[i] > widest)
      widest = widths[i];
  }
  const uint32_t padded = (M + 63u) & ~63u;
  arena_size = tight ? padded * K + K * widest + 16384u : 8u << 20;
  void *allocation = NULL;
  assert(posix_memalign(&allocation, 2048u, arena_size) == 0);
  base = allocation;
  memset(base, 0x9d, arena_size);
  memset(&g_tbl, 0, sizeof g_tbl);
  W weights[3] = {{0}};
  int32_t *offsets[3] = {0};
  uint32_t handles[3] = {0, 1, 2}, off[3], ld[3];
  uint32_t col = 0;
  for (uint32_t i = 0; i < nh; ++i) {
    make_weight(i, K, widths[i], &weights[i]);
    g_tbl.slots[i].bits = 4u;
    offsets[i] = malloc(sizeof(int32_t) * widths[i]);
    assert(offsets[i]);
    for (uint32_t j = 0; j < widths[i]; ++j)
      offsets[i][j] = (int32_t)(rnd() % 7u) - 3;
    g_tbl.slots[i].w_offset = affine ? offsets[i] : NULL;
    off[i] = col;
    ld[i] = total;
    col += widths[i];
  }
  float *input = malloc(sizeof(float) * (size_t)M * K);
  float *output = malloc(sizeof(float) * (size_t)M * total);
  assert(input && output);
  for (size_t i = 0; i < (size_t)M * K; ++i)
    input[i] = rndf() * (float)(1u + i % 5u);
  memset(output, 0xa5, sizeof(float) * (size_t)M * total);
  hexkl_mm_opts options = {0};
  if (interleaved) {
    options.out_off = off;
    options.out_ld = ld;
  }
  review_align_queries = packets = 0;
  hexkl_probe_on = 0;
  assert(hexkl_mm_u8i4_layer_run(&g_tbl, base, (uint32_t)arena_size,
                                 (uint32_t)arena_size, M, K, handles, nh, input,
                                 output, &options) == 0);
  assert(packets == (uint64_t)(padded / 64u) * (total / 32u) * (K / 32u));
#ifdef REVIEW_CANDIDATE
  if (M > 1u && affine)
    assert(review_align_queries == 1u);
  else
    assert(review_align_queries >= packets);
#else
  assert(review_align_queries == packets);
#endif
  for (size_t i = 0; i < (size_t)M * total; ++i)
    assert(isfinite(output[i]));
  assert(fwrite(output, sizeof(float), (size_t)M * total, fp) ==
         (size_t)M * total);
  printf("NUMERIC M%u N%u handles%u interleaved%d tight%d affine%d PASS\n", M,
         total, nh, interleaved, tight, affine);
  free(input);
  free(output);
  for (uint32_t i = 0; i < nh; ++i) {
    free(weights[i].nib);
    free(weights[i].ws);
    free(weights[i].cs);
    free(weights[i].bias);
    free(offsets[i]);
  }
  free(allocation);
}

int main(int argc, char **argv) {
  assert(argc == 2);
  FILE *fp = fopen(argv[1], "wb");
  assert(fp);
  const uint32_t small[3] = {512, 0, 0};
  const uint32_t out[3] = {2048, 0, 0};
  const uint32_t qkv[3] = {2048, 512, 512};
  const uint32_t conv[3] = {2048, 2048, 2048};
  run(fp, 2, small, 1, 0, 0, 1);
  run(fp, 65, small, 1, 0, 1, 1);
  run(fp, 2, out, 1, 0, 0, 1);
  run(fp, 2, qkv, 3, 1, 0, 1);
  run(fp, 2, conv, 3, 0, 0, 1);
  run(fp, 1, small, 1, 0, 0, 1);
  run(fp, 2, small, 1, 0, 0, 0);
  assert(fclose(fp) == 0);
  puts("FC_ISSUE_SCALAR_NUMERIC 7 cases PASS");
}

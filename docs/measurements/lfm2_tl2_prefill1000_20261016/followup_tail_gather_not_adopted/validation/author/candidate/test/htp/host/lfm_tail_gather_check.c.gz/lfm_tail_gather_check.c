// SPDX-License-Identifier: Apache-2.0
/** @file lfm_tail_gather_check.c
 * @brief Actual native gather parity and bounded worker partition checks.
 * @author NNTrainer contributors
 * @bug This tests libnative HVX, not physical DMA/HMX or model TPS.
 */
#include "hexkl_mm_u8i4_moe.h"
#include "hvx_dequant_i32.h"
#include "hvx_quant_u8.h"
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void native_gather(const uint8_t *, const uint32_t *, uint32_t, uint32_t,
                   uint32_t, uint8_t *);
static uint32_t gather_calls, gather_rows;
void hvx_gather_u8_ah_rows(const uint8_t *x, const uint32_t *map, uint32_t lo,
                           uint32_t hi, uint32_t k, uint8_t *out) {
  __atomic_fetch_add(&gather_calls, 1u, __ATOMIC_RELAXED);
  __atomic_fetch_add(&gather_rows, hi - lo, __ATOMIC_RELAXED);
  native_gather(x, map, lo, hi, k, out);
}
void hvx_quant_pack_u8_ah_rows(const float *x, const uint32_t *map, uint32_t lo,
                               uint32_t hi, uint32_t k, const float *s,
                               const int32_t *z, uint8_t *out) {
  (void)x;
  (void)map;
  (void)lo;
  (void)hi;
  (void)k;
  (void)s;
  (void)z;
  (void)out;
  assert(!"unexpected quantized fallback in gather fixture");
}
#define ROUND_UP_U32(x, a) (((x) + (a)-1u) / (a) * (a))
#include "actual-tail-workers.inc"

typedef struct {
  hexkl_moe_pack_ctx *ctx;
  uint32_t first, units, lane, lanes;
} job;
static void *lane(void *ptr) {
  const job *j = ptr;
  /* Reverse order deliberately exercises disjoint four-row stores. */
  for (uint32_t v = j->lane; v < j->units; v += j->lanes)
    moe_lfm_pack_bg_worker(j->units, j->first + j->units - 1u - v, j->ctx);
  return NULL;
}
static uint32_t checks;
static void check_rows(uint32_t rows, uint32_t slot, uint32_t pattern,
                       uint32_t lanes) {
  enum { K = 2048, M = 97, SLOTS = 256, GUARD = 128 };
  uint8_t *input = malloc(M * K + 2u * GUARD);
  uint8_t *reference = malloc(SLOTS * K + 2u * GUARD);
  uint8_t *candidate = malloc(SLOTS * K + 2u * GUARD);
  uint32_t map[SLOTS];
  uint8_t oldmeta[SLOTS / 16], newmeta[SLOTS / 16];
  assert(input && reference && candidate);
  for (uint32_t b = 0; b < M * K + 2u * GUARD; ++b)
    input[b] = (uint8_t)(b * 37u + b / 257u + pattern * 53u);
  memset(reference, 0xa5, SLOTS * K + 2u * GUARD);
  memset(candidate, 0xa5, SLOTS * K + 2u * GUARD);
  memset(oldmeta, 0xe7, sizeof oldmeta);
  memset(newmeta, 0xe7, sizeof newmeta);
  for (uint32_t r = 0; r < SLOTS; ++r)
    map[r] = 0;
  for (uint32_t r = 0; r < rows; ++r)
    map[slot + r] = pattern == 0u   ? r % M
                    : pattern == 1u ? 0u
                                    : (r * 17u + 5u) % M;
  uint32_t counts[1] = {rows};
  uint32_t padded = ROUND_UP_U32(rows, 64u);
  actual_metadata(oldmeta, counts, 0u, slot, padded, 0);
  actual_metadata(newmeta, counts, 0u, slot, padded, 1);
  uint32_t expected4 = ROUND_UP_U32(rows, 4u),
           expected16 = ROUND_UP_U32(rows, 16u);
  for (uint32_t u = 0; u < SLOTS / 16; ++u) {
    if (u < slot / 16 || u >= (slot + padded) / 16) {
      assert(oldmeta[u] == 0xe7 && newmeta[u] == 0xe7);
      continue;
    }
    uint32_t rel = u * 16u - slot;
    assert(oldmeta[u] == (rel >= rows));
    uint32_t count = rel >= expected4 ? 0u : expected4 - rel;
    if (count > 16u)
      count = 16u;
    assert(newmeta[u] == count);
  }
  hexkl_moe_pack_ctx ref = {0}, cand = {0};
  ref.act_u8 = cand.act_u8 = input + GUARD;
  ref.slot_row = cand.slot_row = map;
  ref.K = cand.K = K;
  ref.act_ah = reference + GUARD;
  cand.act_ah = candidate + GUARD;
  ref.skip = oldmeta;
  cand.skip = newmeta;
  gather_calls = gather_rows = 0;
  for (uint32_t u = slot / 16; u < (slot + padded) / 16; ++u)
    hexkl_moe_pack_bg_worker(padded / 16, u, &ref);
  assert(gather_rows == expected16);
  gather_calls = gather_rows = 0;
  pthread_t threads[8];
  job jobs[8];
  assert(lanes && lanes <= 8u);
  for (uint32_t i = 0; i < lanes; ++i) {
    jobs[i] = (job){&cand, slot / 16, padded / 16, i, lanes};
    assert(!pthread_create(&threads[i], NULL, lane, &jobs[i]));
  }
  for (uint32_t i = 0; i < lanes; ++i)
    assert(!pthread_join(threads[i], NULL));
  assert(gather_rows == expected4);
  assert(gather_calls == (rows + 15u) / 16u);
  for (uint32_t r = 0; r < SLOTS; ++r) {
    const int live = r >= slot && r < slot + expected4;
    for (uint32_t kt = 0; kt < K / 32u; ++kt) {
      size_t off = (size_t)(r / 64u) * K * 64u + kt * 2048u + (r % 64u) * 32u;
      if (live) {
        assert(!memcmp(cand.act_ah + off, ref.act_ah + off, 32u));
        assert(!memcmp(cand.act_ah + off, input + GUARD + map[r] * K + kt * 32u,
                       32u));
      } else {
        for (uint32_t b = 0; b < 32u; ++b)
          assert(cand.act_ah[off + b] == 0xa5);
      }
    }
  }
  for (uint32_t b = 0; b < GUARD; ++b) {
    assert(candidate[b] == 0xa5 && candidate[GUARD + SLOTS * K + b] == 0xa5);
    assert(reference[b] == 0xa5 && reference[GUARD + SLOTS * K + b] == 0xa5);
  }
  /* Generic nonzero skip values must still skip, including the new native
   * count encodings if supplied to the original public worker. */
  uint8_t skip[4] = {2u, 4u, 16u, 255u};
  ref.skip = skip;
  gather_calls = gather_rows = 0;
  for (uint32_t u = 0; u < 4; ++u)
    hexkl_moe_pack_bg_worker(4u, u, &ref);
  assert(!gather_calls && !gather_rows);
  free(input);
  free(reference);
  free(candidate);
  ++checks;
}
static void check_guards(void) {
  const uint32_t valid[10] = {0,  1024, 2048, 1536, 2048,
                              64, 37,   37,   0,    HVX_GLU_SILU};
  assert(actual_guard(valid));
  uint32_t x[10];
  const uint32_t bad[10] = {1,  1, 2816, 704, 2816,
                            65, 0, 36,   1,   HVX_GLU_GELU_TANH};
  for (uint32_t i = 0; i < 10; ++i) {
    memcpy(x, valid, sizeof x);
    x[i] = bad[i];
    assert(!actual_guard(x));
  }
  memcpy(x, valid, sizeof x);
  x[1] = 2048;
  assert(actual_guard(x));
  memcpy(x, valid, sizeof x);
  x[5] = 0;
  assert(!actual_guard(x));
  const uint32_t experts[] = {1, 63, 64};
  for (uint32_t i = 0; i < 3; ++i) {
    memcpy(x, valid, sizeof x);
    x[5] = x[6] = x[7] = experts[i];
    assert(actual_guard(x));
  }
}
int main(void) {
  check_guards();
  for (uint32_t rows = 0; rows <= 65u; ++rows)
    for (uint32_t pattern = 0; pattern < 3u; ++pattern)
      check_rows(rows, pattern == 2u ? 64u : 0u, pattern,
                 pattern == 2u ? 8u : 1u);
  printf("TAIL_GATHER_NATIVE cases=%u guards=16 valid-bytes-exact "
         "untouched-gaps PASS\n",
         checks);
  return 0;
}

// SPDX-License-Identifier: Apache-2.0
/** @file lfm_tail_gather_tu_check.c
 * @brief Whole production MoE TU, native gather, and real pthread pool.
 * @author NNTrainer contributors
 * @bug DMA/HMX and other math use the established host stand-ins.
 */
#define main old_moe_check_main
#define hvx_worker_pool_run unused_pool_run
#define hvx_worker_pool_submit unused_pool_submit
#define hvx_worker_pool_wait unused_pool_wait
#define hvx_worker_pool_workers unused_pool_workers
#define hvx_worker_pool_submit_bg unused_pool_submit_bg
#define hvx_worker_pool_wait_bg unused_pool_wait_bg
#include "moe_layer_host_check.c"
#undef main
#undef hvx_worker_pool_run
#undef hvx_worker_pool_submit
#undef hvx_worker_pool_wait
#undef hvx_worker_pool_workers
#undef hvx_worker_pool_submit_bg
#undef hvx_worker_pool_wait_bg
#include "hvx_gemv_u8tl2.h"
#include <assert.h>

void native_gather(const uint8_t *, const uint32_t *, uint32_t, uint32_t,
                   uint32_t, uint8_t *);
static uint32_t gather_rows, gather_busy;
void hvx_gather_u8_ah_rows(const uint8_t *x, const uint32_t *map, uint32_t lo,
                           uint32_t hi, uint32_t k, uint8_t *out) {
  __atomic_fetch_add(&gather_busy, 1u, __ATOMIC_RELAXED);
  native_gather(x, map, lo, hi, k, out);
  __atomic_fetch_add(&gather_rows, hi - lo, __ATOMIC_RELAXED);
  __atomic_fetch_sub(&gather_busy, 1u, __ATOMIC_RELEASE);
}
static uint32_t hmx_calls, fail_at;
int __real_hexkl_micro_hmx_mm_u8i4(uint8_t *, uint32_t, uint32_t);
int __wrap_hexkl_micro_hmx_mm_u8i4(uint8_t *base, uint32_t a, uint32_t w) {
  if (++hmx_calls == fail_at)
    return AEE_EFAILED;
  return __real_hexkl_micro_hmx_mm_u8i4(base, a, w);
}
extern int reference_hexkl_mm_u8i4_moe_layer_run(
  hexkl_weight_u8i4_table *, uint8_t *, uint32_t, uint32_t, uint32_t, uint32_t,
  uint32_t, uint32_t, uint32_t, const uint32_t *, const uint32_t *,
  const uint32_t *, const uint32_t *, const float *, const float *, float *,
  hvx_worker_pool *, hexkl_moe_scratch *, uint32_t);
extern void reference_hexkl_moe_scratch_free(hexkl_moe_scratch *);
typedef int (*run_fn)(hexkl_weight_u8i4_table *, uint8_t *, uint32_t, uint32_t,
                      uint32_t, uint32_t, uint32_t, uint32_t, uint32_t,
                      const uint32_t *, const uint32_t *, const uint32_t *,
                      const uint32_t *, const float *, const float *, float *,
                      hvx_worker_pool *, hexkl_moe_scratch *, uint32_t);
enum { K = 2048, I = 1536, N = 2048, MAXM = 2048, MAXE = 65 };
static W weights[2];
static uint8_t *packed[2];
static void init_weights(void) {
  const int8_t pal[4] = {-1, 0, 1, 1};
  uint8_t lut[128];
  hvx_expand_i2i4_table(pal, lut);
  memset(&g_tbl, 0, sizeof g_tbl);
  for (uint32_t h = 0; h < 2; ++h) {
    make_weight(h + 2u, h ? I : K, h ? N : 2u * I, &weights[h]);
    hexkl_weight_u8i4 *w = &g_tbl.slots[h + 2u];
    const size_t count = (size_t)w->K * w->N;
    uint8_t *codes = malloc(count / 4u);
    int8_t *dense = malloc(count);
    assert(codes && dense);
    for (size_t b = 0; b < count / 4u; ++b)
      codes[b] = rnd();
    hvx_expand_i2i4_scalar(codes, count / 4u, lut, w->wh_bytes);
    for (uint32_t n = 0; n < w->N; ++n) {
      int sum = 0;
      for (uint32_t k = 0; k < w->K; ++k) {
        const size_t off = ((size_t)(k / 32u) * (w->N / 32u) + n / 32u) * 512u;
        int q = wh_value(w->wh_bytes + off, k % 32u, n % 32u);
        dense[(size_t)k * w->N + n] = q;
        sum += q;
      }
      w->colsum_w[n] = sum;
    }
    packed[h] = malloc(hvx_tl2_weight_bytes(w->K, w->N));
    assert(packed[h]);
    assert(!hvx_tl2_pack(dense, w->K, w->N, packed[h]));
    g_tbl.slots[h] = *w;
    g_tbl.slots[h].wh_bytes = packed[h];
    g_tbl.slots[h].tl2_bytes = packed[h];
    g_tbl.slots[h].bits = 2u;
    memcpy(g_tbl.slots[h].pal, pal, 4u);
    free(codes);
    free(dense);
  }
}
static uint32_t cases;
static void check(uint32_t experts, uint32_t m, uint32_t rows, uint32_t active,
                  int shared, int mixed, uint32_t fail, uint32_t lanes,
                  uint32_t arena) {
  uint32_t gu[MAXE] = {0}, dn[MAXE] = {0}, counts[MAXE] = {0};
  uint32_t ids[MAXM * 2u];
  float routing[MAXM * 2u];
  assert(active <= 2u && experts >= active && experts <= MAXE && rows <= m);
  for (uint32_t e = 0; e < active; ++e) {
    gu[e] = mixed && e ? 2u : 0u;
    dn[e] = gu[e] + 1u;
    counts[e] = rows;
    for (uint32_t r = 0; r < rows; ++r) {
      ids[e * rows + r] = (r * 7u + (shared ? 0u : e)) % m;
      routing[e * rows + r] = 0.25f + (float)((r + e) % 5u) * 0.125f;
    }
  }
  float *input = malloc((size_t)m * K * sizeof(float));
  uint8_t *output[2], *vtcm[2];
  for (uint32_t b = 0; b < m * K; ++b)
    input[b] = rndf();
  const size_t outbytes = (size_t)m * N * sizeof(float);
  for (uint32_t j = 0; j < 2; ++j) {
    assert(!posix_memalign((void **)&vtcm[j], 128u, arena + 128u));
    assert(!posix_memalign((void **)&output[j], 128u, outbytes + 256u));
    memset(vtcm[j], j ? 0xcd : 0xa5, arena); // dead rows intentionally differ
    memset(vtcm[j] + arena, 0x79, 128u);
    memset(output[j], 0x6b, outbytes + 256u);
  }
  hexkl_moe_scratch scratch[2] = {{0}, {0}};
  const run_fn run[2] = {reference_hexkl_mm_u8i4_moe_layer_run,
                         hexkl_mm_u8i4_moe_layer_run};
  hvx_worker_pool *pool = hvx_worker_pool_create(lanes - 1u);
  assert(pool || lanes == 1u);
  const uint32_t unique = shared ? 1u : active;
  const int fast = experts <= 64u && !mixed && m > 1u;
  for (uint32_t j = 0; j < 2; ++j) {
    gather_rows = gather_busy = hmx_calls = 0;
    fail_at = fail;
    const int rc = run[j](&g_tbl, vtcm[j], arena, arena, m, K, I, N, experts,
                          gu, dn, ids, counts, routing, input,
                          (float *)(output[j] + 128u), pool, &scratch[j], 0u);
    assert(rc == (fail ? AEE_EFAILED : AEE_SUCCESS));
    assert(__atomic_load_n(&gather_busy, __ATOMIC_ACQUIRE) == 0u);
    const uint32_t step = j && fast ? 4u : 16u;
    const uint32_t gathered = unique * ((rows + step - 1u) / step) * step;
    assert(gather_rows == gathered);
    for (uint32_t b = 0; b < 128; ++b) {
      assert(vtcm[j][arena + b] == 0x79);
      assert(output[j][b] == 0x6b && output[j][outbytes + 128u + b] == 0x6b);
    }
  }
  assert(scratch[0].cap == scratch[1].cap);
  if (!fail)
    assert(!memcmp(output[0] + 128u, output[1] + 128u, outbytes));
  hvx_worker_pool_destroy(pool);
  reference_hexkl_moe_scratch_free(&scratch[0]);
  hexkl_moe_scratch_free(&scratch[1]);
  for (uint32_t j = 0; j < 2; ++j) {
    free(vtcm[j]);
    free(output[j]);
  }
  free(input);
  ++cases;
}
int main(void) {
  init_weights();
  const uint32_t arena = 8372224u;
  /* Successful real-size GU+DN loops, including a second M block, compact
   * expert arrays, shared row slots, and mixed native/int4 fallback. */
  check(1, 17, 17, 1, 0, 0, 0, 1, arena);
  check(64, 65, 65, 1, 0, 0, 0, 8, arena);
  check(63, 17, 5, 2, 1, 0, 0, 8, arena);
  check(64, 17, 5, 2, 0, 1, 0, 8, arena);
  check(65, 17, 1, 1, 0, 0, 0, 1, arena);
  /* First-HMX failures must still retire the actual gather/background jobs.
   * Each next call creates new buffers, so leaked work is an ASan violation. */
  const uint32_t tail[] = {1, 2, 3, 4, 5, 12, 13, 16, 17, 63, 64, 65};
  for (uint32_t i = 0; i < sizeof tail / sizeof tail[0]; ++i)
    check(i % 3u ? 64u : 1u, 65u, tail[i], 1, 0, 0, 1, 8, arena);
  check(63, 17, 5, 2, 1, 0, 1, 8, 9u << 20);
  check(65, 17, 5, 1, 0, 0, 1, 8, arena);
  check(63, 1024, 1023, 1, 0, 0, 1, 8, arena);
  check(64, 2048, 2047, 1, 0, 0, 1, 8, arena);
  for (uint32_t h = 0; h < 2; ++h) {
    free(packed[h]);
    free(weights[h].nib);
    free(weights[h].ws);
    free(weights[h].cs);
    free(weights[h].bias);
  }
  printf("TAIL_GATHER_TU cases=%u full=5 failure=16 capacity-same "
         "output-byte-exact PASS\n",
         cases);
  return 0;
}

// SPDX-License-Identifier: Apache-2.0
/** @file lfm_tail_readout_check.c
 * @brief Unused accumulator rows cannot change native GU/DN output bytes.
 * @author NNTrainer contributors
 * @bug Libnative epilogues; the HMX read/convert itself is not simulated.
 */
#include "hvx_dequant_i32.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

enum { ROWS = 64, WIDTH = 128, NP = 2, NT = 4, PAD = 128 };
static uint8_t a[NT * 8192 + PAD] __attribute__((aligned(128)));
static uint8_t b[sizeof a] __attribute__((aligned(128)));
static float ref[ROWS][WIDTH], out[ROWS][WIDTH];
static uint32_t state = 0x154ae3u;
static uint32_t random_u32(void) {
  state = state * 1664525u + 1013904223u;
  return state;
}
int main(void) {
  float as[ROWS], ws[WIDTH * 2], bs[WIDTH * 2], weights[ROWS];
  int32_t az[ROWS], cs[WIDTH * 2];
  uint32_t rows[ROWS];
  uint8_t seen[ROWS], seen_ref[ROWS];
  for (uint32_t r = 0; r < ROWS; ++r) {
    as[r] = 0.000125f * (float)(1u + r % 3u);
    az[r] = 127 + (int32_t)r;
    weights[r] = (float)(1u + r % 5u) * 0.125f;
    rows[r] = (r * 13u + 17u) % ROWS;
  }
  for (uint32_t c = 0; c < WIDTH * 2; ++c) {
    ws[c] = 0.001f * (float)(1u + c % 5u);
    bs[c] = ((float)(c % 7u) - 3.0f) * 0.01f;
    cs[c] = (int32_t)(c * 317u % 2048u) - 1024;
  }
  uint32_t cases = 0;
  const uint32_t strides[] = {6144u, 8192u};
  for (uint32_t si = 0; si < 2; ++si)
    for (uint32_t m = 1; m <= ROWS; ++m)
      for (uint32_t lanes = 1; lanes <= 8; lanes += 7) {
        const uint32_t stride = strides[si];
        memset(a, 0x55, sizeof a);
        memset(b, 0xaa, sizeof b);
        for (uint32_t t = 0; t < NT; ++t)
          for (uint32_t r = 0; r < ROWS; ++r)
            for (uint32_t c = 0; c < 32; ++c) {
              const uint32_t va = random_u32() & 0xffffffu;
              const uint32_t vb = r < m ? va : random_u32() & 0xffffffu;
              for (uint32_t p = 0; p < 3; ++p) {
                size_t at = t * stride + p * 2048u + r * 32u + c;
                a[at] = (uint8_t)(va >> (p * 8u));
                b[at] = (uint8_t)(vb >> (p * 8u));
              }
            }
        memset(ref, 0xa5, sizeof ref);
        memset(out, 0xa5, sizeof out);
        hvx_dq_swiglu_job j = {a,  stride, NP,         1u,    32u,
                               m,  as,     az,         cs,    ws,
                               bs, WIDTH,  &ref[0][0], WIDTH, HVX_GLU_SILU};
        hvx_dq_swiglu_i24(1, 0, &j);
        j.tiles_base = b;
        j.dst = &out[0][0];
        for (uint32_t lane = 0; lane < lanes; ++lane)
          hvx_dq_swiglu_i24(lanes, lane, &j);
        assert(!memcmp(out, ref, sizeof out));
        ++cases;
        for (uint32_t r = 0; r < ROWS; ++r) {
          seen[r] = seen_ref[r] = (uint8_t)(r % 3u == 0u);
          for (uint32_t c = 0; c < WIDTH; ++c)
            ref[r][c] = out[r][c] = (float)((r * 17u + c) % 23u) * 0.02f;
        }
        hvx_dequant_i24_tiles_scatter_rows_f32(a, stride, NP, 0, m, as, az, cs,
                                               ws, bs, &ref[0][0], WIDTH, rows,
                                               weights, seen_ref);
        for (uint32_t lane = 0; lane < lanes; ++lane)
          hvx_dequant_i24_tiles_scatter_rows_f32(
            b, stride, NP, m * lane / lanes, m * (lane + 1u) / lanes, as, az,
            cs, ws, bs, &out[0][0], WIDTH, rows, weights, seen);
        assert(!memcmp(out, ref, sizeof out));
        assert(!memcmp(seen, seen_ref, sizeof seen));
        ++cases;
      }
  printf("TAIL_READOUT cases=%u GU/DN dead-row-poison float-bytes-exact PASS\n",
         cases);
  return 0;
}

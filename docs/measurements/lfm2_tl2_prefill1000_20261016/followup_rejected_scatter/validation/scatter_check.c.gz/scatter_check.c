// SPDX-License-Identifier: Apache-2.0
/** Production DN worker partitioning with real HVX dequant/scatter. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(SCATTER_SIM)
#include <hexagon_sim_timer.h>
#endif
#include "scatter_under_test.h"

enum { MAX_TILES = 32, MAX_OUT = 2816, ROWS = 64, GUARD = 128 };
static uint8_t planes[MAX_TILES][8192] __attribute__((aligned(128)));
static uint8_t saved_planes[sizeof planes];
static int32_t int32_tiles[MAX_TILES][2048] __attribute__((aligned(128)));
static float output[2][ROWS * MAX_OUT + 2 * GUARD]
  __attribute__((aligned(128)));
static float scale[ROWS], weight[ROWS], ws[MAX_OUT], bias[MAX_OUT];
static int32_t zp[ROWS], colsum[MAX_OUT];
static uint32_t row_index[ROWS];
static uint8_t seen_data[2][ROWS], rq_done[2][ROWS];
static unsigned rq_side;
#if !defined(SCATTER_SIM)
static hvx_worker_pool *test_pool;
#endif
static uint32_t state = 71923u;
static uint32_t random_u32(void) {
  state ^= state << 13;
  state ^= state >> 17;
  state ^= state << 5;
  return state;
}

/* The partitioning change is downstream of this unchanged worker. The mock
 * verifies its original lane/row ownership and unchanged call count; it does
 * not claim to numerically validate the separately unchanged quantizer. */
static void moe_dn_worker(uint32_t threads, uint32_t id, void *ctx) {
  const moe_dn_ctx *c = (const moe_dn_ctx *)ctx;
  for (unsigned unit = id; unit < 4; unit += threads) {
    for (unsigned r = unit * 16; r < (unit + 1) * 16 && r < c->rq_m_blk; ++r) {
      assert(rq_done[rq_side][r] == 0);
      rq_done[rq_side][r] = 1;
    }
  }
}

static void fill(unsigned pattern, unsigned stride) {
  const int32_t edges[] = {-8388608, -8388607, -65537, -256,  -1,      0,
                           1,        127,      255,    65536, 8388606, 8388607};
  memset(planes, 0x5a, sizeof planes);
  for (unsigned t = 0; t < MAX_TILES; ++t)
    for (unsigned p = 0; p < 2048; ++p) {
      int32_t v = (int32_t)(random_u32() & 0xffffffu) - 8388608;
      if (p < sizeof edges / sizeof *edges)
        v = edges[p];
      int32_tiles[t][p] = v;
      for (unsigned b = 0; b < 3; ++b)
        ((uint8_t *)planes)[t * stride + b * 2048 + p] =
          (uint8_t)((uint32_t)v >> (b * 8));
    }
  memcpy(saved_planes, planes, sizeof planes);
  for (unsigned r = 0; r < ROWS; ++r) {
    scale[r] = (float)(1 + r % 5) * 0x1p-12f;
    zp[r] = (int32_t)(random_u32() % 256);
    weight[r] = (float)(1 + r % 7) * 0.125f;
    row_index[r] = (r * 13 + 17) % ROWS;
    if (pattern == 1) {
      scale[r] *= 0x1p-120f;
      weight[r] = r % 2 ? -0.0f : 0.0f;
    } else if (pattern == 2) {
      scale[r] *= 0x1p60f;
      weight[r] *= 0x1p-60f;
    }
  }
  for (unsigned c = 0; c < MAX_OUT; ++c) {
    ws[c] = (float)(1 + c % 5) * 0x1p-10f;
    bias[c] = ((float)(c % 11) - 5.0f) * 0.01f;
    colsum[c] = (int32_t)(random_u32() % 65537) - 32768;
  }
}

static void reset_output(unsigned seen_mode) {
  memset(output, 0xa5, sizeof output);
  for (unsigned r = 0; r < ROWS; ++r) {
    seen_data[0][r] = seen_data[1][r] =
      seen_mode == 1 ? 1 : (seen_mode == 2 ? r % 3 == 0 : 0);
    for (unsigned c = 0; c < MAX_OUT; ++c) {
      float v = (float)((r * 19 + c) % 47) * 0.03125f;
      output[0][GUARD + r * MAX_OUT + c] = v;
      output[1][GUARD + r * MAX_OUT + c] = v;
    }
  }
  memset(rq_done, 0, sizeof rq_done);
}

static void run_job(moe_dn_ctx *ctx, unsigned workers, int candidate) {
  hvx_bg_job job = {0};
  job.ctx = ctx;
  unsigned units = ctx->gate && ctx->m_count < 4 ? 4 : ctx->m_count;
#if !defined(SCATTER_SIM)
  if (test_pool) {
    hvx_worker_pool_submit(
      test_pool, candidate ? moe_dn_fg_worker : reference_moe_dn_fg_worker,
      &job, units);
    hvx_worker_pool_wait(test_pool);
    return;
  }
#endif
  unsigned threads = workers < units ? workers : units;
  if (!threads)
    threads = 1;
  for (unsigned i = 0; i < threads; ++i) {
    if (candidate)
      moe_dn_fg_worker(threads, i, &job);
    else
      reference_moe_dn_fg_worker(threads, i, &job);
  }
}

static unsigned checks;
static void check(unsigned m, unsigned workers, unsigned nt, unsigned stride,
                  unsigned nout, unsigned seen_mode, unsigned gate,
                  unsigned i24) {
  reset_output(seen_mode);
  moe_dn_ctx c = {0};
  c.tiles_base = i24 ? (const uint8_t *)planes : (const uint8_t *)int32_tiles;
  c.tile_stride = i24 ? stride : sizeof int32_tiles[0];
  c.nb = nt;
  c.row_stride = 32;
  c.m_count = m;
  c.act_scale = scale;
  c.act_zp = zp;
  c.acc_i24 = i24;
  c.colsum_w = colsum;
  c.w_scale = ws;
  c.bias = bias;
  c.rows = row_index;
  c.weights = weight;
  c.N_out = nout;
  c.gate = gate ? (float *)1 : NULL;
  c.rq_m_blk = m;
  for (unsigned repeat = 0; repeat < 3; ++repeat) {
    for (unsigned side = 0; side < 2; ++side) {
      memset(rq_done[side], 0, sizeof rq_done[side]);
      rq_side = side;
      c.out = output[side] + GUARD;
      c.seen = seen_mode == 3 ? NULL : seen_data[side];
      run_job(&c, workers, side);
    }
    assert(memcmp(output[0], output[1], sizeof output[0]) == 0);
    assert(memcmp(seen_data[0], seen_data[1], sizeof seen_data[0]) == 0);
    assert(memcmp(rq_done[0], rq_done[1], sizeof rq_done[0]) == 0);
  }
  assert(memcmp(planes, saved_planes, sizeof planes) == 0);
  ++checks;
}

#if defined(SCATTER_SIM)
static unsigned route_hist[65] = {ROUTE_HIST};
static uint64_t time_lane(moe_dn_ctx *c, unsigned threads, unsigned lane,
                          int candidate) {
  hvx_bg_job job = {0};
  job.ctx = c;
  uint64_t before = hexagon_sim_read_pcycles();
  for (unsigned r = 0; r < 1; ++r) {
    if (candidate)
      moe_dn_fg_worker(threads, lane, &job);
    else
      reference_moe_dn_fg_worker(threads, lane, &job);
  }
  return hexagon_sim_read_pcycles() - before;
}
static void timing(void) {
  moe_dn_ctx c = {0};
  c.tiles_base = (const uint8_t *)planes;
  c.tile_stride = 6144;
  c.nb = 32;
  c.row_stride = 32;
  c.act_scale = scale;
  c.act_zp = zp;
  c.acc_i24 = 1;
  c.colsum_w = colsum;
  c.w_scale = ws;
  c.bias = bias;
  c.rows = row_index;
  c.weights = weight;
  c.N_out = 2048;
  c.seen = NULL;
  c.out = output[0] + GUARD;
  for (unsigned workers = 3; workers <= 8; ++workers) {
    uint64_t total[2] = {0}, critical[2] = {0};
    for (unsigned m = 1; m <= 64; ++m) {
      c.m_count = m;
      unsigned threads = workers < m ? workers : m;
      uint64_t sum[2] = {0}, high[2] = {0};
      for (unsigned i = 0; i < threads; ++i)
        for (unsigned v = 0; v < 2; ++v) {
          uint64_t cycles = time_lane(&c, threads, i, v);
          sum[v] += cycles;
          if (cycles > high[v])
            high[v] = cycles;
        }
      for (unsigned v = 0; v < 2; ++v) {
        total[v] += sum[v] * route_hist[m];
        critical[v] += high[v] * route_hist[m];
      }
      if (workers == 7)
        printf("row=%u count=%u old_sum=%llu new_sum=%llu old_max=%llu "
               "new_max=%llu\n",
               m, route_hist[m], (unsigned long long)sum[0],
               (unsigned long long)sum[1], (unsigned long long)high[0],
               (unsigned long long)high[1]);
    }
    printf("cycles workers=%u old_sum=%llu new_sum=%llu old_critical=%llu "
           "new_critical=%llu\n",
           workers, (unsigned long long)total[0], (unsigned long long)total[1],
           (unsigned long long)critical[0], (unsigned long long)critical[1]);
  }
}
#endif

int main(void) {
  setvbuf(stdout, NULL, _IOLBF, 0);
#if defined(SCATTER_SIM)
  const unsigned patterns = 1;
#else
  const unsigned patterns = 3;
#endif
  for (unsigned pattern = 0; pattern < patterns; ++pattern)
    for (unsigned shape = 0; shape < 4; ++shape) {
      unsigned stride = shape == 1 ? 8192 : 6144;
      unsigned nout = shape == 2 ? 2816 : 2048;
      unsigned i24 = shape != 3;
      fill(pattern, stride);
      for (unsigned m = 1; m <= 64; ++m)
        for (unsigned workers = 1; workers <= 8; ++workers)
          for (unsigned seen = 0; seen < 4; ++seen) {
#if defined(SCATTER_SIM)
            if (shape != 0 || seen > 0 || workers != 7 ||
                (m != 1 && m != 4 && m != 16 && m != 63 && m != 64))
              continue;
#endif
            check(m, workers, 2, stride, nout, seen, m % 2, i24);
          }
    }
  printf("SCATTER_ROW4_EXACT_PASS cases=%u repeated=3 shapes=4 rows=1..64\n",
         checks);
#if !defined(SCATTER_SIM)
  const unsigned pool_counts[] = {0, 1, 3, 7, 8};
  const unsigned edge_counts[] = {1, 2, 3, 4, 7, 15, 16, 31, 32, 33, 63, 64};
  fill(0, 6144);
  unsigned pool_checks = checks;
  for (unsigned p = 0; p < sizeof pool_counts / sizeof *pool_counts; ++p) {
    test_pool = hvx_worker_pool_create(pool_counts[p]);
    assert(test_pool != NULL);
    for (unsigned i = 0; i < sizeof edge_counts / sizeof *edge_counts; ++i)
      for (unsigned seen = 0; seen < 4; ++seen)
        check(edge_counts[i], pool_counts[p], 32, 6144, 2048, seen, i % 2, 1);
    hvx_worker_pool_destroy(test_pool);
    test_pool = NULL;
  }
  printf(
    "SCATTER_ROW4_POOL_PASS cases=%u repeated=3 tiles=32 workers=0,1,3,7,8\n",
    checks - pool_checks);
#endif
#if defined(SCATTER_SIM)
  fill(0, 6144);
  reset_output(1);
  timing();
#endif
  return 0;
}

#include "lfm2_sigmoid_topk.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <random>
#include <vector>

using Score = std::pair<float,int>;
static bool better(const Score &a,const Score &b) {
 return a.first>b.first || (a.first==b.first && a.second<b.second);
}
__attribute__((noinline)) static void baseline(Score *scores,unsigned count,unsigned k) {
 std::partial_sort(scores,scores+k,scores+count,better);
}
__attribute__((noinline)) static void candidate(Score *scores,unsigned count,unsigned k) {
 if(!causallm::tryLfmSigmoidTopK(scores,count,k)) baseline(scores,count,k);
}
static volatile uint64_t checksum=0;
using Fn=void(*)(Score*,unsigned,unsigned);
static double bench(Fn fn,const std::vector<Score>&input,unsigned k) {
 const unsigned rows=input.size()/64;
 std::vector<Score> work(input.size());
 const auto start=std::chrono::steady_clock::now();
 for(unsigned repeat=0;repeat<8;++repeat) {
  std::copy(input.begin(),input.end(),work.begin());
  for(unsigned r=0;r<rows;++r) {
   fn(work.data()+64*r,64,k);
   checksum+=unsigned(work[64*r].second);
  }
 }
 return std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/(8.0*rows);
}
int main(int argc,char **argv) {
 if(argc!=2) return 2;
 std::FILE *f=std::fopen(argv[1],"rb");if(!f)return 3;
 std::fseek(f,0,SEEK_END);const long bytes=std::ftell(f);std::rewind(f);
 if(bytes<=0 || bytes%512) return 4;
 std::vector<Score> input(bytes/sizeof(Score));
 if(std::fread(input.data(),1,bytes,f)!=(size_t)bytes)return 5;
 std::fclose(f);
 for(unsigned r=0;r<input.size()/64;++r) {
  std::array<Score,64>a,b;std::copy_n(input.data()+64*r,64,a.data());b=a;
  baseline(a.data(),64,9);candidate(b.data(),64,9);
  for(unsigned i=0;i<9;++i)
   if(a[i].second!=b[i].second || std::memcmp(&a[i].first,&b[i].first,4))return 6;
 }
 for(unsigned trial=0;trial<4;++trial) {
  double a,b;
  if(trial%2==0){a=bench(baseline,input,9);b=bench(candidate,input,9);}
  else{b=bench(candidate,input,9);a=bench(baseline,input,9);}
  std::printf("REAL trial=%u rows=%zu base_us=%.5f candidate_us=%.5f\n",trial,input.size()/64,a,b);
 }
 std::printf("REAL PASS bytes=%ld rows=%zu checksum=%llu\n",bytes,input.size()/64,(unsigned long long)checksum);
}

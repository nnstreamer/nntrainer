#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <random>
#include <vector>

using Score = std::pair<float,int>;
static bool better(const Score &a,const Score &b) {
 return a.first>b.first || (a.first==b.first && a.second<b.second);
}
__attribute__((noinline)) static void baseline(Score *scores,unsigned count,unsigned k) {
 std::partial_sort(scores,scores+k,scores+count,better);
}
__attribute__((noinline)) static void candidate(Score *scores,unsigned count,unsigned k) {
 // Input arrives in increasing expert order. Equal scores keep the older ID.
 for(unsigned e=1;e<k;++e) {
  Score v=scores[e];unsigned at=e;
  while(at && v.first>scores[at-1].first) {scores[at]=scores[at-1];--at;}
  scores[at]=v;
 }
 for(unsigned e=k;e<count;++e) {
  const Score v=scores[e];
  if(!(v.first>scores[k-1].first)) continue;
  unsigned at=k-1;
  while(at && v.first>scores[at-1].first) {scores[at]=scores[at-1];--at;}
  scores[at]=v;
 }
}
static volatile uint64_t checksum=0;
using Fn=void(*)(Score*,unsigned,unsigned);
static double bench(Fn fn,const std::vector<Score>&input,unsigned k) {
 const unsigned rows=input.size()/64;
 std::vector<Score> work(input.size());
 const auto start=std::chrono::steady_clock::now();
 for(unsigned repeat=0;repeat<160;++repeat) {
  std::copy(input.begin(),input.end(),work.begin());
  for(unsigned r=0;r<rows;++r) {
   fn(work.data()+64*r,64,k);
   checksum+=unsigned(work[64*r].second);
  }
 }
 return std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-start).count()/(160.0*rows);
}
int main() {
 std::mt19937 rng(0x20261016);
 unsigned cases=0;
 for(unsigned mode=0;mode<8;++mode) {
  for(unsigned k:{4u,9u}) {
   std::vector<Score> input(1024*64);
   for(unsigned r=0;r<1024;++r) {
    for(unsigned e=0;e<64;++e) {
     float s=float(int(rng()%20000)-10000)/512.0f;
     if(mode==1)s=float(rng()%4);
     if(mode==2)s=0;
     if(mode==3)s=float(e);
     if(mode==4)s=-float(e);
     if(mode==5)s=e%2?std::numeric_limits<float>::infinity():-std::numeric_limits<float>::infinity();
     if(mode==6)s=e%2?0.0f:-0.0f;
     if(mode==7)s=1.0f/(1.0f+std::exp(-s))+(float(int(rng()%200)-100)/128.0f);
     input[64*r+e]={s,int(e)};
    }
    std::array<Score,64>a,b;
    std::copy_n(input.data()+64*r,64,a.data());b=a;
    baseline(a.data(),64,k);candidate(b.data(),64,k);
    for(unsigned i=0;i<k;++i) if(a[i].second!=b[i].second || std::memcmp(&a[i].first,&b[i].first,4)) {
     std::printf("FAIL mode=%u k=%u r=%u i=%u\n",mode,k,r,i);return 1;
    }
    ++cases;
   }
   if(mode==0 || mode==7) {
    for(unsigned trial=0;trial<4;++trial) {
     double a,b;
     if(trial%2==0){a=bench(baseline,input,k);b=bench(candidate,input,k);}
     else {b=bench(candidate,input,k);a=bench(baseline,input,k);}
     std::printf("BENCH mode=%u k=%u trial=%u base_us=%.5f candidate_us=%.5f\n",mode,k,trial,a,b);
    }
   }
  }
 }
 std::printf("PASS cases=%u checksum=%llu\n",cases,(unsigned long long)checksum);
}

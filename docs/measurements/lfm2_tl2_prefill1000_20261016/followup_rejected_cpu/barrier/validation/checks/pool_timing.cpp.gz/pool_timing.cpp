#include "htp_expert_read_pool.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <thread>
#include <vector>
using Clock = std::chrono::steady_clock;
int main() {
  nntrainer::HtpExpertReadPool pool(4);
  for (unsigned delay : {0u, 100u, 500u}) {
    for (size_t count : {2u, 3u, 4u}) {
      std::vector<double> times[2];
      for (unsigned i = 0; i < 2000; ++i) {
        const bool bounded = (i ^ (i >> 1)) & 1u;
        const auto t = Clock::now();
        pool.run(count, [&](size_t) {
          if (delay)
            std::this_thread::sleep_for(std::chrono::microseconds(delay));
        }, bounded);
        if (i >= 200)
          times[bounded].push_back(std::chrono::duration<double, std::micro>(Clock::now() - t).count());
      }
      for (unsigned mode = 0; mode < 2; ++mode) {
        auto &a = times[mode];
        std::sort(a.begin(), a.end());
        double sum = 0;
        for (auto t : a) sum += t;
        std::printf("jobs=%zu delay_us=%u bounded=%u samples=%zu median_us=%.3f mean_us=%.3f p95_us=%.3f\n", count, delay, mode, a.size(), a[a.size()/2], sum/a.size(), a[a.size()*95/100]);
      }
    }
  }
}

lfm2_moe_issue_aligned:                 // @lfm2_moe_issue_aligned
// %bb.0:                               // %entry
	{
		r6 = lsr(r2,#1)
		r4 = #31
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB31_6
	}
// %bb.1:
	{
		loop0(.LBB31_3,r6)
		r5 = #384
		r2 = and(r2,#1)
		p1 = cmp.gtu(r6,#0)
	}
	{
		if (!p1) jump:nt .LBB31_4
	}
	.balign 32
.LBB31_3:                               // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	{
		r6 = add(r0,#2048)
		r7 = add(r1,r3)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r6,r4):cm
		weight.n = mxmem(r7,r5)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r7,r3)
	} :endloop0
	.falign
.LBB31_4:
	{
		p0 = cmp.gtu(r2,#0)
		if (!p0.new) jumpr:nt r31
	}
	.falign
.LBB31_5:                               // Block address taken
                                        // %for.body
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	.falign
.LBB31_6:                               // %for.cond.cleanup
	{
		jumpr r31
	}

.LBB31_3:                               // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	{
		r6 = add(r0,#2048)
		r7 = add(r1,r3)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r6,r4):cm
		weight.n = mxmem(r7,r5)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r7,r3)
	} :endloop0

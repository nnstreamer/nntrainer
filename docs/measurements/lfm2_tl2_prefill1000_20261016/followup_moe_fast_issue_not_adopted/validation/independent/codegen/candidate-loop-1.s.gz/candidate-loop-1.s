.LBB12_454:                             //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        //       Parent Loop BB12_441 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r6 = #31
		r7 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r6):cm
		weight.n = mxmem(r1,r7)
	}

	//# InlineAsm End
	{
		r3 = add(r0,#2048)
		r5 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r1,r5)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r6):cm
		weight.n = mxmem(r4,r7)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r4,r5)
	} :endloop0

	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hexkl_mm_u8i4_moe.c"
	.globl	hexkl_moe_scratch_free          // -- Begin function hexkl_moe_scratch_free
	.falign
	.type	hexkl_moe_scratch_free,@function
hexkl_moe_scratch_free:                 // @hexkl_moe_scratch_free
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#1)
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB0_3
	}
// %bb.1:                               // %if.then
	{
		r17:16 = combine(#0,#0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r3:2 = add(r3:2,r5:4)
		r1 = memw(r0+#0)
		memw(r0+#48) = #0
	}
	{
		r0 = r1
		memd(r0+#24) = r3:2
		memd(r18+#40) = r17:16
	}
	{
		call free
		memd(r18+#56) = r17:16
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r18+#0) = r17:16
		memw(r18+#8) = #0
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB0_3:                                // %if.end
	{
		jumpr r31
	}
.Lfunc_end0:
	.size	hexkl_moe_scratch_free, .Lfunc_end0-hexkl_moe_scratch_free
                                        // -- End function
	.globl	hexkl_moe_scratch_reserve       // -- Begin function hexkl_moe_scratch_reserve
	.falign
	.type	hexkl_moe_scratch_reserve,@function
hexkl_moe_scratch_reserve:              // @hexkl_moe_scratch_reserve
// %bb.0:                               // %entry
	{
		r5:4 = combine(#0,#0)
		r17:16 = combine(r1,r0)
		memd(r29+#-16) = r17:16
		allocframe(#16)
	}                                       // 8-byte Folded Spill
	{
		r6 = memw(r0+#8)
		memd(r0+#40) = r5:4
	}
	{
		r1:0 = combine(#0,#1)
		p0 = cmp.gtu(r17,r6)
		r3:2 = memd(r0+#24)
		memd(r29+#0) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r3:2,r1:0)
		r18 = #0
		memd(r16+#56) = r5:4
		memw(r16+#48) = #0
	}
	{
		if (!p0) jump:nt .LBB1_5
		memd(r16+#24) = r1:0
	}
// %bb.1:                               // %hexkl_moe_scratch_free.exit
	{
		r1:0 = combine(#0,#2)
		memw(r16+#40) = #0
		memw(r16+#56) = #0
	}
	{
		r3:2 = add(r3:2,r1:0)
		r0 = memw(r16+#0)
	}
	{
		call free
		memd(r16+#24) = r3:2
	}
	.falign
// %bb.2:                               // %hexkl_moe_scratch_free.exit
	{
		call malloc
		r0 = add(r17,#128)
		memw(r16+#4) = #0
		memw(r16+#8) = #0
	}
	.falign
// %bb.3:                               // %hexkl_moe_scratch_free.exit
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB1_6
		memw(r16+#0) = r0
		if (!p1.new) memw(r16+#8) = r17
	}
// %bb.4:                               // %if.end3
	{
		r2 = add(r0,#127)
	}
	{
		r2 = and(r2,#-128)
		memw(r16+#4) = r2.new
	}
	.falign
.LBB1_5:                                // %return
	{
		r0 = r18
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB1_6:
	{
		r18 = ##-2147482622
		r0 = ##-2147482622
	}
	{
		r17:16 = memd(r29+#8)
		r19:18 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end1:
	.size	hexkl_moe_scratch_reserve, .Lfunc_end1-hexkl_moe_scratch_reserve
                                        // -- End function
	.globl	hexkl_moe_carve                 // -- Begin function hexkl_moe_carve
	.balign 32
	.type	hexkl_moe_carve,@function
hexkl_moe_carve:                        // @hexkl_moe_carve
// %bb.0:                               // %entry
	{
		r3 = add(r1,#127)
		r2 = memw(r0+#0)
	}
	{
		r3 = and(r3,#-128)
	}
	{
		r3 = add(r2,r3)
		jumpr r31
		r0 = r2
		memw(r0+#0) = r3.new
	}
.Lfunc_end2:
	.size	hexkl_moe_carve, .Lfunc_end2-hexkl_moe_carve
                                        // -- End function
	.globl	hexkl_moe_push_weight_chunk     // -- Begin function hexkl_moe_push_weight_chunk
	.falign
	.type	hexkl_moe_push_weight_chunk,@function
hexkl_moe_push_weight_chunk:            // @hexkl_moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		r6 = r5
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		memd(r29+#48) = r19:18
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r24 = memw(r29+#76)
		memd(r29+#32) = r23:22
	}
	{
		if (p0) jump:nt .LBB3_3
		r5 = memw(r29+#72)
		memd(r29+#16) = r27:26
	}
// %bb.1:                               // %if.then
	{
		r3:2 = combine(r18,#0)
		r4 = r6
		memw(r29+#0) = r24
		memw(r29+#4) = #0
	}
	{
		call moe_push_native_chunk
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB3_3:                                // %if.end
	{
		r27 = asl(r5,#9)
		r7 = r4
		r17 = r3
	}
	{
		r21:20 = vaslw(r7:6,#9)
	}
	{
		r19 = r20
	}
	{
		r19 += add(r0,r1)
		r2 = memw(r18+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB3_8
	}
// %bb.4:                               // %if.then3
	{
		r26 = r21
	}
	{
		call hexkl_dma_ring_next_idx
		r27:26 = vlsrw(r27:26,#1)
	}
	.falign
// %bb.5:                               // %if.then3
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
		memw(r29+#12) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_12
	}
// %bb.6:                               // %if.then12
	{
		r0 = lsr(r3,#10)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then12
	{
		r3 = lsr(r20,#1)
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		r2 = memw(r18+#4)
	}
	{
		if (!p1) jump:nt .LBB3_13
	}
	{
		jump .LBB3_15
	}
	.falign
.LBB3_8:                                // %if.end30
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.9:                               // %if.end30
	{
		r25 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = r0
		r16 = #0
	}
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_19
	}
// %bb.10:                              // %if.then44
	{
		r3 = mpyi(r27,r17)
		r1 = #0
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then44
	{
		r23:22 = combine(r1,r0)
		p1 = cmp.eq(r24,#0)
		if (!p1.new) jump:t .LBB3_20
		r2 = memw(r18+#4)
	}
	{
		jump .LBB3_22
	}
	.falign
.LBB3_12:
	{
		r3 = lsr(r20,#1)
		p1 = cmp.eq(r24,#0)
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	{
		if (p1) jump:nt .LBB3_15
	}
	.falign
.LBB3_13:                               // %land.rhs.i
	{
		r16 = #1
		r4 = memw(r18+#36)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB3_15
	}
// %bb.14:                              // %lor.rhs.i
	{
		r4 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r4,#0)
	}
	.falign
.LBB3_15:                               // %moe_weight_src_bypass.exit
	{
		r1 = add(r2,r3)
		r0 = add(r19,r27)
		r3:2 = combine(r26,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.16:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_26
	}
// %bb.17:                              // %if.then24
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.18:                              // %if.then24
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
		memd(r2+#96) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_19:
	{
		p1 = cmp.eq(r24,#0)
		if (p1.new) jump:nt .LBB3_22
		r23:22 = combine(#0,#0)
		r2 = memw(r18+#4)
	}
	.falign
.LBB3_20:                               // %land.rhs.i105
	{
		r16 = #1
		r3 = memw(r18+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB3_22
	}
// %bb.21:                              // %lor.rhs.i109
	{
		r3 = memw(r18+#40)
	}
	{
		r16 = !cmp.eq(r3,#0)
	}
	.falign
.LBB3_22:                               // %moe_weight_src_bypass.exit112
	{
		r1 = add(r2,r20)
		r0 = r19
		r3:2 = combine(r21,r21)
		r5:4 = combine(r17,r27)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r16
		memw(r29+#4) = #1
	}
	.falign
// %bb.23:                              // %moe_weight_src_bypass.exit112
	{
		r2 = memw(r25+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB3_27
	}
// %bb.24:                              // %if.then56
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then56
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r25+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		r0 = r26
		jump .LBB3_28
		memd(r2+#96) = r1:0
	}
	.falign
.LBB3_26:
	{
		jump .LBB3_28
		r0 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	.falign
.LBB3_27:
	{
		r0 = r26
	}
	.falign
.LBB3_28:                               // %cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hexkl_moe_push_weight_chunk, .Lfunc_end3-hexkl_moe_push_weight_chunk
                                        // -- End function
	.falign
	.type	moe_push_native_chunk,@function // -- Begin function moe_push_native_chunk
moe_push_native_chunk:                  // @moe_push_native_chunk
// %bb.0:                               // %entry
	{
		r9:8 = combine(#0,#0)
		p1 = cmp.eq(r4,#0)
		memd(r29+#-16) = r17:16
		allocframe(#136)
	}                                       // 8-byte Folded Spill
	{
		r2 = add(r4,add(r5,#3))
		r17:16 = combine(r0,r3)
		r6 = memw(r29+#144)
		memw(r29+#36) = r2
	}
	{
		r27 = lsr(r2,#2)
		p0 = cmp.eq(r6,#0)
		r13 = #0
		memd(r29+#88) = r27:26
	}                                       // 8-byte Folded Spill
	{
		r2 = #0
		memd(r29+#120) = r19:18
		memd(r29+#112) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#104) = r23:22
		memd(r29+#96) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) memd(r3+#64) = r9:8
		if (p1) memd(r3+#56) = r9:8
	}
	{
		if (p0) jump:nt .LBB4_3
		memw(r29+#28) = r2
	}                                       // 4-byte Folded Spill
// %bb.1:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB4_3
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_3:                                // %moe_weight_src_bypass.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r26 = lsr(r4,#2)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.gtu(r27,r26)
		if (!p0.new) jump:t .LBB4_95
		if (p0.new) r2 = memw(r29+#36)
		if (p0.new) r4 = memw(r16+#28)
	}                                       // 4-byte Folded Reload
// %bb.4:                               // %for.body.lr.ph
	{
		r5 = ##-1431655765
		r3 = add(r4,#23)
		r6 = memw(r29+#148)
	}
	{
		r3 = mpyu(r3,r5)
		p0 = cmp.eq(r2,#0)
		r2 = #640
	}
	{
		if (p0) r12 = ##2560
		memw(r29+#40) = r6
		if (!p0) memw(r29+#44) = r27
	}                                       // 4-byte Folded Spill
	{
		r3 = lsr(r3,#4)
	}
	{
		r14 = mpyi(r3,r2)
		if (p0) jump:nt .LBB4_39
		memw(r29+#24) = r14.new
	}                                       // 4-byte Folded Spill
// %bb.5:
	{
		p1 = cmp.eq(r6,#0)
		r9:8 = combine(#0,#1)
		r25:24 = combine(#0,#0)
	}
	{
		r2 = p1
		memw(r29+#48) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_6:                                // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_10 Depth 2
	{
		r1:0 = asl(r9:8,r26)
		r18 = add(r26,#1)
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p0 = cmp.eq(r5:4,r25:24)
		if (!p0.new) r18 = add(r26,#1)
		if (p0.new) jump:t .LBB4_8
	}
// %bb.7:                               //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = cmp.gtu(r27,r18)
		r26 = r18
		if (p1.new) jump:t .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_8:                                // %if.end13
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		p1 = cmp.gtu(r27,r18)
		if (p1.new) r2 = sub(r27,r18)
	}
	{
		if (!p1) jump:nt .LBB4_13
		memd(r16+#64) = r1:0
	}
// %bb.9:                               //   in Loop: Header=BB4_6 Depth=1
	{
		loop0(.LBB4_10,r2)
	}
	.falign
.LBB4_10:                               // Block address taken
                                        // %land.rhs
                                        //   Parent Loop BB4_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3:2 = asl(r9:8,r18)
	}
	{
		r5:4 = and(r1:0,r3:2)
	}
	{
		r1:0 = or(r1:0,r3:2)
		p0 = cmp.eq(r5:4,r25:24)
		if (p0.new) r18 = add(r18,#1)
		if (!p0.new) jump:nt .LBB4_13
	}
// %bb.11:                              // %while.body
                                        //   in Loop: Header=BB4_10 Depth=2
	{
		nop
		memd(r16+#64) = r1:0
	} :endloop0
// %bb.12:                              //   in Loop: Header=BB4_6 Depth=1
	{
		r18 = r27
	}
	.falign
.LBB4_13:                               // %while.end
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = sub(r18,r26)
		r0 = #16256
	}
	{
		r17 = mpyi(r2,r14)
		r2 = #8064
	}
	{
		p1 = bitsclr(r17,r0)
		if (!p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB4_20
	}
// %bb.14:                              // %while.body.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		if (!p0.new) r2 = ##3968
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.15:                              // %while.body.1.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		if (!p1.new) r2 = #1920
		if (p1.new) jump:nt .LBB4_22
	}
// %bb.16:                              // %while.body.2.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #2048
		if (!p0.new) r2 = #896
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.17:                              // %while.body.3.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = bitsclr(r17,r2)
		r19 = #1024
		if (!p1.new) r2 = #384
		if (p1.new) jump:nt .LBB4_26
	}
// %bb.18:                              // %while.body.4.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p0 = bitsclr(r17,r2)
		r19 = #512
		if (!p0.new) r2 = #128
		if (p0.new) jump:nt .LBB4_26
	}
// %bb.19:                              // %while.body.5.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		p1 = !tstbit(r17,#7)
	}
	{
		r19 = mux(p1,##256,r2)
		jump .LBB4_26
	}
	.falign
.LBB4_20:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #16384
		jump .LBB4_26
	}
	.falign
.LBB4_22:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r19 = #4096
	}
	.falign
.LBB4_26:                               // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r17)
		r27 = memw(r16+#44)
		memw(r29+#32) = r13
	}                                       // 4-byte Folded Spill
	.falign
// %bb.27:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r21 = r0
	}
	.falign
// %bb.28:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r20 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_31
	}
// %bb.29:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.30:                              // %if.then.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(r1,r0)
		jump .LBB4_32
	}
	.falign
.LBB4_31:                               //   in Loop: Header=BB4_6 Depth=1
	{
		r23:22 = combine(#0,#0)
	}
	.falign
.LBB4_32:                               // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r5:4 = combine(r21,r19)
		r2 = memw(r29+#24)
		r7 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = #1
	}
	{
		r6 = mpyi(r26,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3:2 = combine(r19,r19)
		r1 = add(r27,r6)
		r0 = add(r7,r6)
	}
	.falign
// %bb.33:                              // %do.end.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r26 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.34:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.35:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r1:0 = sub(r1:0,r23:22)
		r2 = memw(r26+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r26+##hexkl_probe_on@GOT)
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_38
	}
// %bb.36:                              // %do.end8.i
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_38
	}
// %bb.37:                              // %if.then11.i
                                        //   in Loop: Header=BB4_6 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r20
		r4 = memw(r2+#4)
		memw(r29+#0) = r19

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = r21
		memw(r29+#8) = r19
	}
	.falign
.LBB4_38:                               // %moe_native_push2d.exit
                                        //   in Loop: Header=BB4_6 Depth=1
	{
		r9:8 = combine(#0,#1)
		r26 = r18
		r13 = memw(r29+#32)
		r27 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r17,r13)
		p1 = cmp.gtu(r27,r18)
		r14 = memw(r29+#24)
		memw(r16+#72) = r20
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB4_6
	}
	{
		jump .LBB4_95
	}
	.falign
.LBB4_39:                               // %for.body.us.preheader
	{
		r5 = mpyu(r4,r5)
		p0 = cmp.gtu(r4,#95)
		r7:6 = combine(#0,#2)
		r21 = memw(r16+#32)
	}
	{
		r5 = mpyi(r26,r3)
		r15 = lsr(r5,#6)
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
	}
	{
		r7 = insert(r26,#21,#11)
		r8 = asl(r15,#2)
		memw(r29+#36) = r15
	}                                       // 4-byte Folded Spill
	{
		r9 = +mpyi(r15,#3)
		r21 = and(##-512,asl(r21,#4))
		p1 = cmp.eq(r3,r8)
	}
	{
		r20 = mpyi(r5,r2)
		r3 = p1
		r5 = sub(r3,r8)
		memw(r29+#52) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r17 += add(r1,r7)
		r7 = mpyi(r15,r12)
		p1 = cmp.gtu(r5,#2)
		memw(r29+#44) = r7.new
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r9,r21)
		r4 = p0
		r7 = add(r5,#-2)
		memw(r29+#32) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r12 = minu(r5,r6)
		r6 = minu(r7,r6)
		r4 = add(r9,#1)
		memw(r29+#72) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r4,r21)
		r7 = +mpyi(r21,#3)
		memw(r29+#76) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = p1
		memw(r29+#48) = r7
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r12,r2)
		r2 = mpyi(r6,r2)
		memw(r29+#56) = r3
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#60) = r3
		memw(r29+#64) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_40:                               // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1:0 = asl(r11:10,r26)
		r25 = r13
		r3:2 = memd(r16+#64)
	}
	{
		r5:4 = and(r3:2,r1:0)
	}
	{
		p1 = cmp.eq(r5:4,r19:18)
		if (!p1.new) jump:t .LBB4_94
		if (p1.new) r23 = memw(r16+#44)
	}
// %bb.41:                              // %if.end13.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = or(r3:2,r1:0)
		r24 = add(r23,r20)
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB4_54
		memd(r16+#64) = r1:0
	}
// %bb.42:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.43:                              // %if.then47.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_46
	}
// %bb.44:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %if.then.i164.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_47
	}
	.falign
.LBB4_46:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_47:                               // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = combine(r24,r17)
		r3 = #2560
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = #1280
		r2 = memw(r29+#48)
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.48:                              // %do.end.i166.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.49:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.50:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_53
	}
// %bb.51:                              // %do.end8.i169.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_53
	}
// %bb.52:                              // %if.then11.i176.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_53:                               // %moe_native_push2d.exit179.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r22
	}
	.falign
.LBB4_54:                               // %if.end55.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r2)
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_57
		if (p0.new) r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
// %bb.55:                              // %for.inc.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		p0 = r2
		if (p0.new) jump:t .LBB4_69
	}
	.falign
.LBB4_56:                               // %if.end55.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	{
		jump .LBB4_81
	}
	.falign
.LBB4_57:                               // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.58:                              // %if.then58.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_61
	}
// %bb.59:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.60:                              // %if.then.i182.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_62
	}
	.falign
.LBB4_61:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_62:                               // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = r24
		r3 = #1280
		r5 = #1
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		r4 = memw(r29+#60)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	.falign
// %bb.63:                              // %do.end.i184.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.64:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		memw(r29+#68) = r2.new
	}                                       // 4-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.65:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		r3 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_68
	}
// %bb.66:                              // %do.end8.i187.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_68
	}
// %bb.67:                              // %if.then11.i194.us
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_68:                               // %moe_native_push2d.exit197.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#32)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_56
	}
	.falign
.LBB4_69:                               // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.70:                              // %if.then47.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r22 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_73
	}
// %bb.71:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.72:                              // %if.then.i164.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_74
	}
	.falign
.LBB4_73:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_74:                               // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = #1280
		r0 = add(r17,r21)
		r3 = #2560
		r4 = #1280
	}
	{
		r23 += add(r20,r2)
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r1 = r23
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.75:                              // %do.end.i166.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.76:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r23 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.77:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r23
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_80
	}
// %bb.78:                              // %do.end8.i169.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_80
	}
// %bb.79:                              // %if.then11.i176.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r22
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#4) = r6

	} :mem_noshuf
	{
		r6 = #2560
		memw(r29+#0) = r6
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
.LBB4_80:                               // %moe_native_push2d.exit179.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#56)
		memw(r16+#72) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB4_93
	}
	.falign
.LBB4_81:                               // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.82:                              // %if.then58.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r23 = r0
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_85
	}
// %bb.83:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.84:                              // %if.then.i182.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(r1,r0)
		jump .LBB4_86
	}
	.falign
.LBB4_85:                               //   in Loop: Header=BB4_40 Depth=1
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB4_86:                               // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1 = add(r24,#1280)
		r3 = #1280
		r2 = memw(r29+#76)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r17,r2)
		r5 = #1
		r2 = memw(r29+#28)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r2 = r21
		memw(r29+#4) = #1
	}
	.falign
// %bb.87:                              // %do.end.i184.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.88:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
	}
	{
		r22 = r2
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.89:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r1:0 = sub(r1:0,r19:18)
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r3 = r22
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		p0 = r3
		if (p0.new) jump:nt .LBB4_92
	}
// %bb.90:                              // %do.end8.i187.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_92
	}
// %bb.91:                              // %if.then11.i194.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r2 = memw(r29+#40)
		r6 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r5 = memw(r2+#8)
	}
	{
		r2 = r23
		r6 = #1280
		r4 = memw(r2+#4)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		call hexkl_dma_trace_push
		memw(r29+#4) = #1
		memw(r29+#8) = r6
	}
	.falign
.LBB4_92:                               // %moe_native_push2d.exit197.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		memw(r16+#72) = r23
	}
	.falign
.LBB4_93:                               // %for.inc.us.1
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r11:10 = combine(#0,#1)
		r19:18 = combine(#0,#0)
		r14 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r13 = add(r25,r14)
	}
	.falign
.LBB4_94:                               // %cleanup77.us
                                        //   in Loop: Header=BB4_40 Depth=1
	{
		r20 = add(r20,r14)
		r17 = add(r17,#2048)
	}
	{
		r26 = add(r26,#1)
		if (!cmp.eq(r26.new,r27)) jump:t ##.LBB4_40
	}
	.falign
.LBB4_95:                               // %for.cond.cleanup
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB4_97
	}
// %bb.96:                              // %if.then81
	{
		r0 = lsr(r13,#10)
		r1 = #0
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB4_97:                               // %do.end
	{
		r0 = memw(r16+#72)
		r17:16 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#120)
		r21:20 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r23:22 = memd(r29+#104)
		r25:24 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r27:26 = memd(r29+#88)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end4:
	.size	moe_push_native_chunk, .Lfunc_end4-moe_push_native_chunk
                                        // -- End function
	.globl	hexkl_moe_expand_chunk          // -- Begin function hexkl_moe_expand_chunk
	.balign 32
	.type	hexkl_moe_expand_chunk,@function
hexkl_moe_expand_chunk:                 // @hexkl_moe_expand_chunk
// %bb.0:                               // %entry
	{
		r4 = r3
		r3 = r2
		r6 = r4
		allocframe(#16)
	}
	{
		r2 = memw(r29+#28)
		memw(r29+#8) = r2.new
	}
	{
		r2 = memw(r29+#24)
		memw(r29+#4) = r2.new
	}
	{
		call moe_expand_chunk
		r5 = r6
		r2 = #0
		memw(r29+#0) = r5
	}
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end5:
	.size	hexkl_moe_expand_chunk, .Lfunc_end5-hexkl_moe_expand_chunk
                                        // -- End function
	.falign
	.type	moe_expand_chunk,@function      // -- Begin function moe_expand_chunk
moe_expand_chunk:                       // @moe_expand_chunk
// %bb.0:                               // %entry
	{
		r6 = r3
		allocframe(r29,#256):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r7 = memw(r3+#44)
		deallocframe
	}
	{
		p1 = cmp.eq(r7,#0)
	}
	{
		r18 = memw(r30+#12)
		memd(r30+#-16) = r19:18
	}
	{
		r22 = r4
		r17 = r0
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r0 = add(r3,#88)
		if (!p1) r12 = add(r17,r1)
		r16 = memw(r30+#16)
		r4 = memw(r30+#8)
	}
	{
		if (p1) jump:nt .LBB6_10
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r5 = add(r4,add(r18,#3))
		r3 = lsr(r4,#2)
	}
	{
		r7 = lsr(r5,#2)
		r5:4 = combine(#0,#0)
	}
	{
		if (p0.new) r7 = sub(r7,r3)
		p0 = cmp.gtu(r7,r3); if (!p0.new) jump:t .LBB6_4
	}
// %bb.2:
	{
		loop0(.LBB6_3,r7)
		r9:8 = combine(#0,#1)
	}
	.falign
.LBB6_3:                                // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r9:8,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB6_4:                                // %for.cond.cleanup7.i
	{
		r15 = ##-1431655765
		r13 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r7 = #0
		r28 = add(r13,#23)
		r1 = add(r13,#95)
		r14 = add(r3,#127)
	}
	{
		r2 = mpyu(r28,r15)
		r15 = mpyu(r1,r15)
		r9:8 = memd(r6+#56)
		memw(r29+#156) = r2
	}
	{
		r14 = lsr(r14,#7)
		r28 = lsr(r2,#4)
		p1 = cmp.gtu(r14,#127)
		memw(r29+#168) = r13
	}
	{
		r2 = lsr(r15,#6)
		r13:12 = and(r5:4,~r9:8)
		memw(r29+#152) = r12
		memw(r29+#172) = r14
	}
	{
		r15 = +mpyi(r28,##640)
		memw(r29+#184) = r7
		memd(r29+#160) = r13:12
	}
	{
		if (!p1) jump:nt .LBB6_16
		memw(r29+#176) = r2
		memw(r29+#180) = r15
	}
// %bb.5:
	{
		r15 = lsr(r14,#1)
		r19:18 = combine(#0,#1)
		r11:10 = combine(#0,#0)
		r28 = and(r14,#1)
	}
	{
		p1 = cmp.gtu(r15,#0)
		if (!p1.new) jump:t .LBB6_14
	}
// %bb.6:
	{
		loop0(.LBB6_7,r15)
		r15:14 = combine(#0,#0)
	}
	.falign
.LBB6_7:                                // =>This Inner Loop Header: Depth=1
	{
		r21:20 = combine(r13,r12)
		r1 = add(r14,r2)
		r17 = add(r15,#1)
		r23:22 = combine(r13,r12)
	}
	{
		r21:20 &= asl(r19:18,r15)
		r23:22 &= asl(r19:18,r17)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r21:20,r11:10)
		if (!p0.new) r14 = add(r1,#0)
		if (!p0.new) r7 = add(r1,#0)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r1 = add(r14,r2)
	}
	{
		if (!p0) r14 = add(r1,#0)
		if (!p0) r7 = add(r1,#0)
	} :endloop0
// %bb.8:
	{
		p1 = cmp.gtu(r28,#0)
		if (!p1.new) jump:t .LBB6_15
	}
	.falign
.LBB6_9:                                // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r19:18,r15)
		r2 = add(r14,r2)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		if (!p1.new) r7 = add(r2,#0)
		jump .LBB6_15
	}
	.falign
.LBB6_10:                               // %if.end
	{
		r23 = r1
		r19 = add(r29,#0)
		r2 = memw(r6+#84)
		if (!cmp.eq(r2.new,#2)) jump:t .LBB6_39
	}
// %bb.11:                              // %if.end4
	{
		r21:20 = vaslw(r5:4,#9)
		r1 = r19
	}
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.12:                              // %if.end4
	{
		r20 += add(r17,r23)
		r18 = and(##2147483392,asl(r18,#8))
		r5:4 = combine(r16,r19)
	}
	{
		call hvx_expand_i2i4_rows
		r1:0 = combine(r21,r20)
		r3:2 = combine(r22,r18)
	}
	.falign
// %bb.13:                              // %if.end4
	{
		jump .LBB6_39
	}
	.falign
.LBB6_14:
	{
		r15:14 = combine(#0,#0)
		p1 = cmp.gtu(r28,#0)
		if (p1.new) jump:t .LBB6_9
	}
	.falign
.LBB6_15:                               // %for.cond.cleanup24.i.loopexit
	{
		memw(r29+#184) = r7
	}
	.falign
.LBB6_16:                               // %for.cond.cleanup24.i
	{
		r7 = #0
		r2 = memb(r0+#0)
	}
	{
		r2 = abs(r2)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB6_19
	}
// %bb.17:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#7); if (p1.new) jump:nt .LBB6_19
	}
// %bb.18:                              // %for.cond.cleanup24.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_19:                               // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_24
	}
// %bb.20:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_22
	}
// %bb.21:                              // %for.inc.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_22:                               // %lor.lhs.false.1.i.i
	{
		if (p0) jump:nt .LBB6_25
	}
// %bb.23:                              // %lor.lhs.false.1.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_25
	}
	.falign
.LBB6_24:
	{
		r12 = r2
	}
	.falign
.LBB6_25:                               // %for.inc.1.i.i
	{
		r2 = memb(r6+#90)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB6_30
	}
// %bb.26:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB6_28
	}
// %bb.27:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB6_38
	}
	.falign
.LBB6_28:                               // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,#0)
		if (p0.new) jump:nt .LBB6_31
	}
// %bb.29:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,r2)
		if (!p1.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_31
	}
	.falign
.LBB6_30:
	{
		r2 = r12
	}
	.falign
.LBB6_31:                               // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB6_36
	}
// %bb.32:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#7)
		if (p1.new) jump:nt .LBB6_34
	}
// %bb.33:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB6_38
	}
	.falign
.LBB6_34:                               // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB6_37
	}
// %bb.35:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r2,r12)
		if (!p0.new) jump:t .LBB6_38
	}
	{
		jump .LBB6_37
	}
	.falign
.LBB6_36:
	{
		r12 = r2
	}
	.falign
.LBB6_37:                               // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r7 = maxu(r12,r2)
	}
	.falign
.LBB6_38:                               // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r29+#12) = r3.new
	}
	{
		r1 = add(pc,##moe_expand_unit@PCREL)
		r2 = add(r29,#0)
		r0 = r16
	}
	{
		call hvx_worker_pool_run
		r3 = #8
		memw(r29+#188) = r7
		memd(r6+#56) = r5:4
	}
	.falign
.LBB6_39:                               // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end6:
	.size	moe_expand_chunk, .Lfunc_end6-moe_expand_chunk
                                        // -- End function
	.globl	hexkl_moe_push_act_block        // -- Begin function hexkl_moe_push_act_block
	.falign
	.type	hexkl_moe_push_act_block,@function
hexkl_moe_push_act_block:               // @hexkl_moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17:16 = combine(r4,r2)
		memd(r29+#-16) = r17:16
		allocframe(#40)
	}                                       // 8-byte Folded Spill
	{
		r18 = r3
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r19:18
		memd(r29+#16) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) r19 = ##16384
		if (p0) jump:nt .LBB7_5
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = bitsclr(r5,#3)
		if (p1.new) r19 = ##8192
		if (p1.new) jump:nt .LBB7_5
	}
// %bb.2:                               // %while.body.1.i
	{
		p0 = tstbit(r5,#0)
		if (p0.new) r19 = ##2048
	}
	{
		if (!p0) r19 = ##4096
		jump .LBB7_5
	}
	.falign
.LBB7_5:                                // %moe_dma_row_size.exit
	{
		call hexkl_dma_ring_next_idx
		r22 = asl(r5,#11)
	}
	.falign
// %bb.6:                               // %moe_dma_row_size.exit
	{
		call __hexagon_udivsi3
		r23 = r0
		r1:0 = combine(r19,r22)
	}
	.falign
// %bb.7:                               // %moe_dma_row_size.exit
	{
		r16 += mpyi(r17,r18)
		r5:4 = combine(r0,r19)
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r16
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.8:                               // %moe_dma_row_size.exit
	{
		r0 = r23
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end7:
	.size	hexkl_moe_push_act_block, .Lfunc_end7-hexkl_moe_push_act_block
                                        // -- End function
	.globl	hexkl_moe_pack_bg_worker        // -- Begin function hexkl_moe_pack_bg_worker
	.falign
	.type	hexkl_moe_pack_bg_worker,@function
hexkl_moe_pack_bg_worker:               // @hexkl_moe_pack_bg_worker
// %bb.0:                               // %entry
	{
		r3 = r1
		allocframe(#8)
	}
	{
		r4 = memw(r2+#28)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.1:                               // %land.lhs.true
	{
		r4 = memb(r4+r1<<#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB8_3
	}
// %bb.2:                               // %cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB8_3:                                // %if.end
	{
		r4 = asl(r3,#4)
		r5 = #16
		r0 = memw(r2+#4)
		if (cmp.eq(r0.new,#0)) jump:nt .LBB8_5
	}
// %bb.4:                               // %if.then4
	{
		r6 = r2
		r1 = memw(r2+#8)
	}
	{
		r3 = addasl(r5,r3,#4)
		r2 = r4
		r4 = memw(r6+#24)
		r5 = memw(r6+#20)
	}
	{
		jump hvx_gather_u8_ah_rows
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB8_5:                                // %if.end7
	{
		r6 = asl(r3,#4)
		r7 = #16
		r1 = memw(r2+#8)
		r8 = memw(r2+#16)
	}
	{
		r3 = addasl(r7,r3,#4)
		r0 = memw(r2+#0)
		r4 = memw(r2+#24)
	}
	{
		r5 = memw(r2+#12)
		r2 = memw(r2+#20)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r2 = r6
		memw(r29+#4) = r2
		memw(r29+#0) = r8
	}
	.falign
// %bb.6:                               // %if.end7
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end8:
	.size	hexkl_moe_pack_bg_worker, .Lfunc_end8-hexkl_moe_pack_bg_worker
                                        // -- End function
	.globl	hexkl_moe_dma_copy              // -- Begin function hexkl_moe_dma_copy
	.falign
	.type	hexkl_moe_dma_copy,@function
hexkl_moe_dma_copy:                     // @hexkl_moe_dma_copy
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r2,#0)
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r19:18
		memd(r29+#32) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r24 = ##1048576
		memd(r29+#24) = r23:22
		memd(r29+#16) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r27 = ##4095
		if (p0) jump:nt .LBB9_33
		memd(r29+#8) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:
	{
		r17:16 = combine(r4,r2)
		r19:18 = combine(r1,r3)
		r23 = #0
		r20 = r0
	}
	{
		r25 = #16383
		r26 = #8191
	}
	.falign
.LBB9_2:                                // %while.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r16,r23)
	}
	{
		r21 = minu(r2,r24)
	}
	{
		p1 = bitsclr(r21,r25)
		if (!p1.new) r22 = ##8192
		if (p1.new) jump:nt .LBB9_16
	}
// %bb.3:                               // %while.body.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r26)
		if (!p0.new) r2 = #2047
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.4:                               // %while.body.1.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r27)
		if (!p1.new) r22 = ##2048
		if (p1.new) jump:nt .LBB9_18
	}
// %bb.5:                               // %while.body.2.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #1023
		if (!p0.new) r22 = #1024
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.6:                               // %while.body.3.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #511
		if (!p1.new) r22 = #512
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.7:                               // %while.body.4.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r2 = #255
		if (!p0.new) r22 = #256
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.8:                               // %while.body.5.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,r2)
		if (!p1.new) r2 = #127
		if (!p1.new) r22 = #128
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.9:                               // %while.body.6.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,r2)
		if (!p0.new) r22 = #64
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.10:                              // %while.body.7.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#63)
		if (!p1.new) r22 = #32
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.11:                              // %while.body.8.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#31)
		if (!p0.new) r22 = #16
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.12:                              // %while.body.9.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p1 = bitsclr(r21,#15)
		if (!p1.new) r22 = #8
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.13:                              // %while.body.10.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = bitsclr(r21,#7)
		if (p0.new) jump:nt .LBB9_29
	}
// %bb.14:                              // %while.body.11.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		p0 = tstbit(r21,#0)
		p1 = bitsclr(r21,#3)
		if (p1.new) r22 = #4
		if (p1.new) jump:nt .LBB9_29
	}
// %bb.15:                              // %while.body.12.i.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = mux(p0,#1,#2)
		jump .LBB9_29
	}
	.falign
.LBB9_16:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #16384
		jump .LBB9_29
	}
	.falign
.LBB9_18:                               //   in Loop: Header=BB9_2 Depth=1
	{
		r22 = #4096
	}
	.falign
.LBB9_29:                               // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r5:4 = combine(r0,r22)
		r0 = add(r20,r23)
		r1 = add(r19,r23)
		r3:2 = combine(r22,r22)
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = r18
		memw(r29+#4) = r17
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit.i
                                        //   in Loop: Header=BB9_2 Depth=1
	{
		r23 = add(r21,r23)
		if (cmp.gtu(r16,r23.new)) jump:t .LBB9_2
	}
	.falign
.LBB9_33:                               // %moe_dma_copy.exit
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		r23:22 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#16)
		r27:26 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end9:
	.size	hexkl_moe_dma_copy, .Lfunc_end9-hexkl_moe_dma_copy
                                        // -- End function
	.falign
	.type	moe_dma_copy,@function          // -- Begin function moe_dma_copy
moe_dma_copy:                           // @moe_dma_copy
// %bb.0:                               // %entry
	{
		r6 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17 = r2
		p0 = cmp.eq(r2,#0)
		memd(r29+#32) = r27:26
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gt(r5,#-1)
		r27 = #0
		memd(r29+#56) = r21:20
		memd(r29+#48) = r23:22
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#40) = r25:24
		memw(r29+#20) = r5
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r6+##hexkl_probe_on@GOT)
	}
	{
		if (p0) r25 = #0
		r2 = memw(r2+#0)
	}
	{
		p2 = cmp.eq(r2,#0)
	}
	{
		p1 = and(p1,!p2)
	}
	{
		r2 = p1
		if (p0) jump:nt .LBB10_38
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.1:
	{
		r19:18 = combine(r3,r4)
		r21:20 = combine(r0,r1)
		r16 = #16383
		r22 = #0
	}
	.falign
.LBB10_2:                               // %while.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = sub(r17,r27)
		r3 = ##1048576
	}
	{
		r23 = minu(r2,r3)
		r2 = #8191
	}
	{
		p0 = bitsclr(r23,r16)
		if (!p0.new) r24 = ##8192
		if (p0.new) jump:nt .LBB10_16
	}
// %bb.3:                               // %while.body.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		if (!p1.new) r2 = ##4095
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.4:                               // %while.body.1.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		if (!p2.new) r2 = #2047
		if (p2.new) jump:nt .LBB10_18
	}
// %bb.5:                               // %while.body.2.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #2048
		if (!p0.new) r2 = #1023
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.6:                               // %while.body.3.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #1024
		if (!p1.new) r2 = #511
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.7:                               // %while.body.4.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,r2)
		r24 = #512
		if (!p2.new) r2 = #255
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.8:                               // %while.body.5.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,r2)
		r24 = #256
		if (!p0.new) r2 = #127
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.9:                               // %while.body.6.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,r2)
		r24 = #128
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.10:                              // %while.body.7.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p2 = bitsclr(r23,#63)
		r24 = #64
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.11:                              // %while.body.8.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#31)
		r24 = #32
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.12:                              // %while.body.9.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = bitsclr(r23,#15)
		r24 = #16
		if (p1.new) jump:nt .LBB10_29
	}
// %bb.13:                              // %while.body.10.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p1 = tstbit(r23,#0)
		p2 = bitsclr(r23,#7)
		if (p2.new) r24 = #8
		if (p2.new) jump:nt .LBB10_29
	}
// %bb.14:                              // %while.body.11.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		p0 = bitsclr(r23,#3)
		if (p0.new) r24 = #4
		if (p0.new) jump:nt .LBB10_29
	}
// %bb.15:                              // %while.body.12.i
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = mux(p1,#1,#2)
		jump .LBB10_29
	}
	.falign
.LBB10_16:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #16384
		jump .LBB10_29
	}
	.falign
.LBB10_18:                              //   in Loop: Header=BB10_2 Depth=1
	{
		r24 = #4096
	}
	.falign
.LBB10_29:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.30:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		call __hexagon_udivsi3
		r25 = r0
		r1:0 = combine(r24,r23)
	}
	.falign
// %bb.31:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r26 = r0
		r0 = add(r21,r27)
		r1 = add(r20,r27)
		r3:2 = combine(r24,r24)
	}
	{
		call hexkl_dma_ring_push2d
		r5:4 = combine(r26,r24)
		memw(r29+#0) = r19
		memw(r29+#4) = r18
	}
	.falign
// %bb.32:                              // %moe_dma_row_size.exit
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB10_34
	}
// %bb.33:                              // %if.then
                                        //   in Loop: Header=BB10_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = combine(r22,#0)
		r3:2 = combine(#4,r25)
		memw(r29+#0) = r24
		memw(r29+#4) = r26
	}
	{
		call hexkl_dma_trace_push
		r22 = add(r22,#1)
		memw(r29+#8) = r24
	}
	.falign
.LBB10_34:                              // %if.end
                                        //   in Loop: Header=BB10_2 Depth=1
	{
		r27 = add(r23,r27)
		if (cmp.gtu(r17,r27.new)) jump:t .LBB10_2
	}
// %bb.35:                              // %while.end
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB10_39
	}
	.falign
.LBB10_36:                              // %if.then14
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r25
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.37:                              // %if.then14
	{
		call hexkl_dma_ring_drain
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_trace_wait_end
		r31:30 = deallocframe(r30):raw
	}
	.falign
.LBB10_38:
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB10_36
	}
	.falign
.LBB10_39:                              // %if.end12
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		jump hexkl_dma_ring_drain
		r31:30 = deallocframe(r30):raw
	}
.Lfunc_end10:
	.size	moe_dma_copy, .Lfunc_end10-moe_dma_copy
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layout        // -- Begin function hexkl_mm_u8i4_moe_layout
	.falign
	.type	hexkl_mm_u8i4_moe_layout,@function
hexkl_mm_u8i4_moe_layout:               // @hexkl_mm_u8i4_moe_layout
// %bb.0:                               // %entry
	{
		r8 = r1
		r6 = ##-2147449855
		r7 = r2
	}
	{
		r7 |= or(r1,r0)
		r0 = add(r6,#-32755)
		r5 = r0
		allocframe(#40)
	}
	{
		r7 = and(r7,#31)
		memd(r29+#32) = r17:16
		memd(r29+#24) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r8 = or(r7,and(r8,#15))
		memd(r29+#16) = r21:20
		memd(r29+#8) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r8,#0)
		if (!p0.new) jump:nt .LBB11_11
		memd(r29+#0) = r25:24
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.3:                               // %entry
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB11_11
	}
// %bb.4:                               // %entry
	{
		r5 = extractu(r5,#23,#5)
		r7 = extractu(r1,#27,#4)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB11_11
	}
// %bb.5:                               // %if.end16
	{
		r8 = extractu(r5,#21,#0)
		r12 = extractu(r7,#23,#1)
		r0 = add(r6,#-32767)
	}
	{
		r5 = mpyi(r5,r7)
		r9 = lsr(r2,#5)
	}
	{
		r5 = asl(r5,#9)
		r17 = asl(r8,#11)
	}
	{
		r19 = add(r5,add(r17,##1536))
		r5 = mpyi(r12,r9)
	}
	{
		r19 = insert(r19,#9,#2)
		r5 = asl(r5,#9)
	}
	{
		r18 = add(r5,add(r19,##2047))
		r5 = extractu(r7,#20,#1)
	}
	{
		r18 += asl(r1,#8)
		r2 = add(##2047,asl(r2,#8))
		r20 = r18
	}
	{
		r20 = insert(r19,#11,#0)
		r18 += asl(r5,#12)
		r21 = r18
	}
	{
		r21 = insert(r20,#11,#0)
		r22 = r18
	}
	{
		r22 = insert(r21,#12,#0)
	}
	{
		r2 = insert(r22,#11,#0)
	}
	{
		r2 = add(r22,r2)
	}
	{
		r5 = sub(r3,r2)
		p1 = cmp.gtu(r3,r2)
	}
	{
		r2 = lsr(r5,#14)
	}
	{
		if (!p1) r2 = #0
	}
	{
		r2 = minu(r7,r2)
		if (!cmp.gtu(r2.new,#1)) jump:t .LBB11_11
	}
// %bb.6:                               // %cleanup.cont
	{
		r5 = #32
	}
	{
		r2 = minu(r2,r5)
	}
	{
		r23 = and(r2,#62)
	}
	{
		r18 += asl(r23,#14)
		r16 = asl(r23,#13)
	}
	{
		r18 = insert(r16,#11,#0)
		if (!cmp.gtu(r3,r18.new)) jump:t .LBB11_11
	}
// %bb.7:                               // %cond.end95
	{
		r2 = sub(r3,r18)
		r25:24 = combine(r4,r0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r2)
	}
	.falign
// %bb.8:                               // %cond.end95
	{
		r3:2 = combine(r25,r0)
		r4 = #4
		p0 = cmp.gtu(r0,#3); if (p0.new) jump:t .LBB11_10
	}
// %bb.9:
	{
		r0 = r24
		r4 = r2
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB11_11
	}
	.falign
.LBB11_10:                              // %cleanup.cont113
	{
		r18 += mpyi(r4,r16)
		r0 = #0
		memw(r3+#28) = r18
		memw(r3+#0) = #0
	}
	{
		memw(r3+#4) = r17
		memw(r3+#8) = r19
	}
	{
		memw(r3+#12) = r20
		memw(r3+#16) = r21
	}
	{
		memw(r3+#20) = r22
		memw(r3+#24) = r23
	}
	{
		memw(r3+#32) = r4
		memw(r3+#36) = r18
	}
	.falign
.LBB11_11:                              // %return
	{
		r17:16 = memd(r29+#32)
		r19:18 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#16)
		r23:22 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#0)
		r31:30 = dealloc_return(r30):raw
	}                                       // 8-byte Folded Reload
.Lfunc_end11:
	.size	hexkl_mm_u8i4_moe_layout, .Lfunc_end11-hexkl_mm_u8i4_moe_layout
                                        // -- End function
	.globl	hexkl_mm_u8i4_moe_layer_run     // -- Begin function hexkl_mm_u8i4_moe_layer_run
	.falign
	.type	hexkl_mm_u8i4_moe_layer_run,@function
hexkl_mm_u8i4_moe_layer_run:            // @hexkl_mm_u8i4_moe_layer_run
// %bb.0:                               // %entry
	{
		r14 = r4
		allocframe(r29,##17152):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r23 = memw(r30+#52)
		memd(r30+#-32) = r23:22
	}
	{
		p0 = cmp.eq(r23,#0)
		if (p0.new) r17 = #0
		r16 = memw(r30+#16)
		memd(r30+#-8) = r17:16
	}
	{
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB12_2
		memd(r30+#-40) = r25:24
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r9:8 = combine(#0,#1)
		r13:12 = combine(#0,#0)
		r7:6 = memd(r23+#24)
		memw(r23+#48) = #0
	}
	{
		r7:6 = add(r7:6,r9:8)
		p1 = cmp.eq(r16,#0)
		r17 = memw(r23+#56)
		memd(r23+#40) = r13:12
	}
	{
		r27 = ##-2147449856
		memd(r23+#56) = r13:12
		memd(r23+#24) = r7:6
	}
	{
		r4 = add(r27,#-32754)
		if (!p1) jump:nt .LBB12_3
	}
	{
		jump .LBB12_78
	}
	.falign
.LBB12_2:
	{
		r27 = ##-2147449856
		p1 = cmp.eq(r16,#0)
	}
	{
		r4 = add(r27,#-32754)
		if (p1) jump:nt .LBB12_78
	}
	.falign
.LBB12_3:                               // %if.end
	{
		p2 = cmp.eq(r14,#0)
		if (p2.new) jump:nt .LBB12_78
	}
// %bb.4:                               // %if.end
	{
		p3 = cmp.eq(r0,#0)
		if (p3.new) jump:nt .LBB12_78
	}
// %bb.5:                               // %if.end
	{
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB12_78
	}
// %bb.6:                               // %if.end
	{
		r10 = memw(r30+#20)
		if (cmp.eq(r10.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.7:                               // %if.end
	{
		r11 = memw(r30+#24)
		if (cmp.eq(r11.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.8:                               // %if.end
	{
		r8 = memw(r30+#28)
		if (cmp.eq(r8.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.9:                               // %if.end
	{
		r19 = memw(r30+#32)
		if (cmp.eq(r19.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.10:                              // %if.end
	{
		r9 = memw(r30+#36)
		if (cmp.eq(r9.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.11:                              // %if.end
	{
		r15 = memw(r30+#40)
		if (cmp.eq(r15.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.12:                              // %if.end
	{
		r6 = memw(r30+#44)
		if (cmp.eq(r6.new,#0)) jump:nt ##.LBB12_78
	}
// %bb.13:                              // %if.end
	{
		if (p0) jump:nt .LBB12_78
		if (!p0) r13 = memw(r30+#56)
		if (!p0) r7 = memw(r30+#12)
	}
// %bb.14:                              // %if.end26
	{
		r12 = add(pc,##g_moe_src_bypass@PCREL)
		p0 = cmp.eq(r7,#0)
		r22 = add(r27,#-32754)
	}
	{
		r4 = extractu(r13,#1,#18)
		memw(r12+#0) = r4.new
	}
	{
		if (p0) r4 = add(r22,#0)
		if (p0) jump:nt .LBB12_78
	}
// %bb.15:                              // %if.end26
	{
		r4 = r22
		p3 = cmp.eq(r5,#0)
		if (!p3.new) r12 = add(r7,#0)
		if (p3.new) jump:nt .LBB12_78
	}
// %bb.16:                              // %if.end26
	{
		r28 = memw(r30+#8)
		if (cmp.eq(r28.new,#0)) jump:nt ##.LBB12_76
	}
// %bb.17:                              // %if.end26
	{
		r12 |= or(r28,r5)
		r4 = r28
	}
	{
		r12 = and(r12,#31)
	}
	{
		r4 = or(r12,and(r4,#15))
		if (!cmp.eq(r4.new,#0)) jump:nt ##.LBB12_74
	}
// %bb.18:                              // %if.end16.i
	{
		r13 = lsr(r28,#5)
		r12 = lsr(r7,#5)
		memw(r29+#236) = r13
		memd(r29+#1656) = r17:16
	}                                       // 4-byte Folded Spill
	{
		r16 = extractu(r13,#23,#0)
		r14 = lsr(r5,#5)
		memd(r29+#1664) = r15:14
		memw(r29+#1672) = r15
	}                                       // 8-byte Folded Spill
	{
		r4 = extractu(r14,#23,#0)
		r15 = extractu(r28,#27,#4)
		r17 = #1536
		memw(r29+#244) = r17
	}                                       // 4-byte Folded Spill
	{
		r16 = mpyi(r16,r12)
		r4 = asl(r4,#9)
	}
	{
		r24 = mpyi(r4,r15)
		r21 = asl(r16,#9)
		memw(r29+#240) = r24.new
	}                                       // 4-byte Folded Spill
	{
		r20 = minu(r2,r3)
		r26 = r21
	}
	{
		r26 = insert(r4,#30,#2)
		r4 = extractu(r13,#20,#0)
		memw(r29+#248) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r24 += add(r26,r17)
	}
	{
		r24 = insert(r24,#9,#2)
	}
	{
		r25 = add(r21,add(r24,##2047))
	}
	{
		r25 += asl(r28,#8)
		r17 = r25
	}
	{
		r25 += asl(r4,#12)
		r17 = insert(r24,#11,#0)
		r16 = r25
		r4 = r7
	}
	{
		r16 = insert(r17,#11,#0)
		r4 = add(##2047,asl(r4,#8))
		r18 = r25
	}
	{
		r18 = insert(r16,#12,#0)
	}
	{
		r4 = insert(r18,#11,#0)
	}
	{
		r2 = add(r18,r4)
	}
	{
		r4 = sub(r20,r2)
		p0 = cmp.gtu(r20,r2)
	}
	{
		r2 = lsr(r4,#14)
		r4 = add(r27,#-32766)
	}
	{
		if (!p0) r2 = #0
	}
	{
		r2 = minu(r15,r2)
		if (!cmp.gtu(r2.new,#1)) jump:t ##.LBB12_78
	}
// %bb.19:                              // %cleanup.cont.i
	{
		r3 = #32
		memw(r29+#268) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = minu(r2,r3)
	}
	{
		r2 = and(r3,#62)
	}
	{
		r25 += asl(r2,#14)
		r27 = asl(r2,#13)
	}
	{
		r25 = insert(r27,#11,#0)
		if (!cmp.gtu(r20,r25.new)) jump:t ##.LBB12_78
	}
// %bb.20:                              // %cond.end95.i
	{
		r2 = r20
		memw(r29+#1680) = r2
		memw(r29+#284) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = sub(r20,r25)
		r20 = r0
		memd(r29+#1688) = r3:2
		memw(r29+#272) = r19
	}                                       // 8-byte Folded Spill
	{
		r1:0 = combine(r27,r2)
		r19 = r4
		memw(r29+#292) = r3
		memw(r29+#280) = r11
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#276) = r10
		memw(r29+#316) = r15
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#312) = r14
		memw(r29+#300) = r13
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#296) = r12
		memw(r29+#304) = r9
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#288) = r8
		memw(r29+#308) = r6
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#252) = r20
		memw(r29+#256) = r5
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		memw(r29+#264) = r7
		memw(r29+#260) = r28
	}                                       // 4-byte Folded Spill
	.falign
// %bb.21:                              // %cond.end95.i
	{
		r1 = r20
		p2 = cmp.gtu(r0,#3)
		r15 = memw(r29+#260)
		r14 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r4 = r19
		r3 = #4
		if (p2) jump:nt .LBB12_23
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
// %bb.22:
	{
		r3 = r0
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_78
	}
	.falign
.LBB12_23:                              // %for.body.lr.ph
	{
		r20 = #0
		r19 = #0
		r4 = memw(r30+#48)
		memw(r29+#324) = r4.new
	}
	{
		r26 = asl(r15,#1)
		r28 = #0
		r4 = memw(r29+#236)
		memw(r29+#676) = r26
	}                                       // 4-byte Folded Reload
	{
		r4 = extractu(r4,#1,#19)
		r9:8 = memd(r29+#1664)
		memw(r29+#320) = r4.new
	}                                       // 8-byte Folded Reload
	{
		r17 = #8192
		r0 = r8
		r5:4 = memd(r29+#1656)
		memw(r29+#684) = r17
	}                                       // 8-byte Folded Reload
	{
		r25 += mpyi(r3,r27)
		r27 = #0
		r11:10 = combine(#0,r4)
		memw(r29+#700) = r25
	}
	{
		r4 = memw(r29+#1680)
		memw(r29+#696) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r4 = maxu(r26,r15)
		r3 = or(r26,r14)
		memw(r29+#704) = r3
		memw(r29+#688) = r16
	}
	{
		r6 = maxu(r4,r14)
		r3 = and(r3,#127)
		r4 = memw(r29+#276)
		r5 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r6,r17)
		r16 = #0
		r7 = memw(r29+#272)
		memw(r29+#672) = r11
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB12_24,r10)
		memw(r29+#680) = r24
		memw(r29+#692) = r18
	}
	{
		memw(r29+#708) = r25
	}
	.falign
.LBB12_24:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
		r8 = r11
		r6 = memw(r7+#0)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB12_44
	}
// %bb.25:                              // %if.end46
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r9 = memw(r4+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt ##.LBB12_79
	}
// %bb.26:                              // %lor.lhs.false58
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r13 = #4095
	}
	{
		r13 = memw(r5+#0)
		if (cmp.gtu(r13.new,r13)) jump:nt ##.LBB12_80
	}
// %bb.27:                              // %if.end63
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r1+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_81
	}
// %bb.28:                              // %lor.lhs.false70
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r12 = +mpyi(r13,#96)
	}
	{
		r12 = memw(r1+r12<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt ##.LBB12_82
	}
// %bb.29:                              // %lor.lhs.false73
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r9 = add(r1,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r2)) jump:nt ##.LBB12_83
	}
// %bb.30:                              // %lor.lhs.false77
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r12 = memw(r9+#32)
		if (!cmp.eq(r12.new,r26)) jump:nt ##.LBB12_84
	}
// %bb.31:                              // %lor.lhs.false80
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r12 = r1
	}
	{
		r12 += mpyi(r13,#96)
	}
	{
		r13 = memw(r12+#28)
		if (!cmp.eq(r13.new,r15)) jump:nt ##.LBB12_85
	}
// %bb.32:                              // %lor.lhs.false84
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r13 = memw(r12+#32)
		if (!cmp.eq(r13.new,r14)) jump:nt ##.LBB12_86
	}
// %bb.33:                              // %if.end89
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r13 = memw(r9+#44)
	}
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_40
		r13 = memw(r12+#44)
	}
// %bb.34:                              // %lor.lhs.false97
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) r4 = add(r22,#0)
		if (p3.new) jump:nt .LBB12_78
	}
// %bb.35:                              // %lor.lhs.false100
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p3 = cmp.eq(r3,#0)
		r13 = memw(r9+#84)
		if (!cmp.eq(r13.new,#2)) jump:nt ##.LBB12_88
	}
// %bb.36:                              // %lor.lhs.false103
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p0 = cmp.gtu(r2,r17)
		r13 = memw(r12+#84)
	}
	{
		p1 = cmp.eq(r13,#2)
	}
	{
		p1 = not(p1)
	}
	{
		p3 = or(p1,!p3)
	}
	{
		p1 = or(p2,or(p0,p3))
		if (p1.new) r4 = add(r22,#0)
		if (p1.new) jump:nt .LBB12_78
	}
// %bb.37:                              // %if.end132
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p3 = and(p3,!p3)
		r13 = memw(r9+#48)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_39
	}
// %bb.38:                              // %land.rhs
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r13 = memw(r12+#48)
	}
	{
		p3 = cmp.eq(r13,#0)
	}
	{
		p3 = not(p3)
	}
	.falign
.LBB12_39:                              // %land.end
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r19 = add(r19,#1)
		if (p3) r16 = add(r16,#1)
		jump .LBB12_41
	}
	.falign
.LBB12_40:                              // %lor.lhs.false91
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (!p3.new) r4 = add(r22,#0)
		if (!p3.new) jump:nt .LBB12_78
	}
	.falign
.LBB12_41:                              // %if.end137
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		p3 = or(p3,!p3)
		r9 = memw(r9+#20)
		if (!cmp.eq(r9.new,#0)) jump:t .LBB12_43
	}
// %bb.42:                              // %lor.rhs
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r9 = memw(r12+#20)
	}
	{
		p0 = cmp.eq(r9,#0)
	}
	{
		p3 = not(p0)
	}
	.falign
.LBB12_43:                              // %cleanup
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r27 = maxu(r6,r27)
		r20 = add(r20,#1)
		if (p3) r28 = add(r28,#1)
		r11 = add(r6,r11)
	}
	.falign
.LBB12_44:                              // %for.inc
                                        //   in Loop: Header=BB12_24 Depth=1
	{
		r5 = add(r5,#4)
		r7 = add(r7,#4)
		r4 = add(r4,#4)
	} :endloop0
// %bb.45:                              // %for.cond150.preheader
	{
		r3 = add(r8,r6)
		p3 = cmp.eq(r11,#0)
		if (p3.new) jump:nt .LBB12_49
	}
// %bb.46:                              // %for.body154.preheader
	{
		r4 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_47:                              // %for.body154
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r4+#0)
		if (!cmp.gtu(r0,r5.new)) jump:nt ##.LBB12_90
	}
// %bb.48:                              // %for.cond150
                                        //   in Loop: Header=BB12_47 Depth=1
	{
		r4 = add(r4,#4)
		r3 = add(r3,#-1)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_47
	}
	.falign
.LBB12_49:                              // %for.end164
	{
		r3 = #2048
		p2 = cmp.eq(r19,#0)
		memw(r29+#1704) = r16
		memw(r29+#348) = r28
	}                                       // 4-byte Folded Spill
	{
		r4 = p2
		p1 = cmp.eq(r14,r3)
		p3 = cmp.eq(r2,r3)
		memd(r29+#1656) = r11:10
	}                                       // 8-byte Folded Spill
	{
		r2 = p1
		memw(r29+#336) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p3
		memw(r29+#328) = r4
	}                                       // 4-byte Folded Spill
	{
		if (!p3) jump:nt .LBB12_58
		memw(r29+#344) = r2
	}                                       // 4-byte Folded Spill
// %bb.50:                              // %for.end164
	{
		r2 = #1536
		if (!cmp.eq(r2.new,r15)) jump:nt .LBB12_58
	}
// %bb.51:                              // %for.end164
	{
		r2 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB12_58
		if (p0.new) r2 = memw(r29+##328)
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %for.end164
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_58
		if (!p0.new) r3:2 = memd(r29+##1656)
	}                                       // 8-byte Folded Reload
// %bb.53:
	{
		r16 = r2
		r17 = memw(r29+#276)
		r22 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_54:                              // %for.body181
                                        // =>This Inner Loop Header: Depth=1
	{
		r0 = r1
		r2 = memw(r24+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_57
	}
// %bb.55:                              // %if.end186
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r2 = memw(r17+#0)
		r3 = memw(r22+#0)
	}
	{
		r0 += mpyi(r2,#96)
		r1 += mpyi(r3,#96)
	}
	{
		call hexkl_weight_tl2_refresh_pair
	}
	.falign
// %bb.56:                              // %if.end186
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r4 = r0
		p2 = cmp.eq(r0,#0)
		if (!p2.new) jump:nt .LBB12_78
		r1 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_57:                              // %for.inc198
                                        //   in Loop: Header=BB12_54 Depth=1
	{
		r24 = add(r24,#4)
		r22 = add(r22,#4)
		r17 = add(r17,#4)
	}
	{
		r16 = add(r16,#-1)
		if (!cmp.eq(r16.new,#0)) jump:t .LBB12_54
	}
	.falign
.LBB12_58:                              // %if.end203
	{
		r22 = r1
		r0 = r1
		r17:16 = memd(r29+#1656)
		memw(r29+#360) = r19
	}                                       // 8-byte Folded Reload
	{
		r1 = r16
		r17 = memw(r29+#276)
		r19 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r19,r17)
		r24 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		call moe_all_4bit
		r4 = r24
	}
	.falign
// %bb.59:                              // %if.end203
	{
		r1:0 = combine(r16,r22)
		r3:2 = combine(r19,r17)
		r4 = r24
		memw(r29+#364) = r0
	}                                       // 4-byte Folded Spill
	{
		call moe_all_2bit
	}
	.falign
// %bb.60:                              // %if.end203
	{
		r3:2 = combine(#0,#0)
		r1 = r18
		r0 = memw(r29+#284)
		memw(r29+#352) = r0
	}                                       // 4-byte Folded Reload
	{
		memd(r29+#1808) = r3:2
		memd(r29+#1800) = r3:2
	}
	{
		memd(r29+#1792) = r3:2
		memd(r29+#1784) = r3:2
	}
	{
		memd(r29+#1776) = r3:2
		memd(r29+#1768) = r3:2
	}
	{
		call hexkl_acc_layout_get
		memd(r29+#1760) = r3:2
		memd(r29+#1752) = r3:2
	}
	.falign
// %bb.61:                              // %if.end203
	{
		r2 = memw(r0+#4)
	}
	{
		p1 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (!p1.new) r22 = add(r0,#0)
	}
	{
		r2 = add(r2,#-32748)
		if (p1) jump:nt .LBB12_850
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.62:                              // %if.end214
	{
		r19 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p1 = and(p1,!p1)
	}
	{
		r3 = p1
		r5 = #0
		r4 = memw(r0+#12)
		r1:0 = memd(r29+#1664)
	}                                       // 8-byte Folded Reload
	{
		p2 = cmp.gtu(r0,#4)
		r1 = #0
		r2 = memw(r19+##hexkl_probe_us@GOT)
	}
	{
		p3 = cmp.eq(r0,#1)
		memw(r29+#332) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = p3
		memw(r29+#356) = r3.new
	}                                       // 4-byte Folded Spill
	{
		if (p2) jump:nt .LBB12_94
		memd(r29+#1696) = r1:0
		memd(r2+#136) = r5:4
	}                                       // 8-byte Folded Spill
// %bb.63:                              // %if.end214
	{
		r2 = memw(r29+#236)
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#252)
		r16 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r29+#360)
		r17 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		r2 = and(r2,#1)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_68
	}
// %bb.64:                              // %if.end214
	{
		p2 = cmp.gtu(r27,#4)
		if (p2.new) jump:nt .LBB12_68
	}
// %bb.65:                              // %if.end214
	{
		r2 = add(r20,#-1)
		if (cmp.gtu(r2.new,#15)) jump:nt .LBB12_68
	}
// %bb.66:                              // %if.end214
	{
		r2 = memw(r29+#352)
		r4 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		r2 = or(r4,r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_68
	}
// %bb.67:                              // %land.rhs238
	{
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p1 = or(p1,p2)
	}
	{
		r2 = p1
		memw(r29+#332) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_68:                              // %land.end245
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB12_95
	}
	.falign
.LBB12_69:                              // %land.end245
	{
		r2 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r1 = add(r26,#0)
		if (p1.new) jump:nt .LBB12_92
	}
// %bb.70:                              // %if.then250
	{
		call hvx_tl2_weight_bytes
		r22 = r19
		memw(r29+#376) = r22
	}                                       // 4-byte Folded Spill
	.falign
// %bb.71:                              // %if.then250
	{
		call hvx_tl2_weight_bytes
		r19 = r0
		r0 = r16
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.72:                              // %if.then250
	{
		r4 = add(r0,r19)
		r2 = memw(r29+#284)
		r1:0 = memd(r29+#1688)
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r0,r25)
	}
	{
		r4 = add(r2,r25)
		p0 = cmp.gtu(r4,r3); if (!p0.new) jump:t .LBB12_93
		if (!p0.new) r3 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
// %bb.73:                              // %if.else
	{
		p2 = cmp.gtu(r19,r3)
		r19 = r22
		r2 = memw(r29+#320)
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = #1536
		if (p2) r4 = #0
	}
	{
		p1 = cmp.eq(r16,r2)
		if (!p3) r4 = #0
		r2 = memw(r29+#344)
		r3 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r4 = #0
		r2 = memw(r29+#336)
		r22 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p1) r4 = #0
	}
	{
		if (!p2) r4 = #0
	}
	{
		jump .LBB12_96
		memw(r29+#364) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_74:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_76:
	{
		r4 = r22
	}
	.falign
.LBB12_78:                              // %cleanup3385
	{
		r0 = r4
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB12_79:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_80:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_81:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_82:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_83:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_84:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_85:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_86:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_88:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_90:
	{
		r4 = r22 ; jump .LBB12_78
	}
	.falign
.LBB12_92:
	{
		r2 = #0 ; jump .LBB12_96
		memw(r29+#364) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_93:                              // %if.then257
	{
		r19 += add(r2,r25)
		memw(r29+#364) = r4
	}                                       // 4-byte Folded Spill
	{
		r1 = r19
		r19 = r22
		r22 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_96
		r0 = memw(r29+#256)
		memd(r29+#1696) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_94:
	{
		r0 = memw(r29+#256)
		r3 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#260)
		r24 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#348)
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_69
	}
	.falign
.LBB12_95:
	{
		r2 = #0
		memw(r29+#364) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_96:                              // %if.end281
	{
		p2 = cmp.eq(r17,#0)
		r4 = #8192
		r2 = memw(r29+#332)
		r17:16 = memd(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r5 = p2
		r2 = #0
		memw(r29+#376) = r5.new
	}                                       // 4-byte Folded Spill
	{
		p0 = or(p3,!p2)
		if (p0.new) r25 = #0
		if (p0.new) jump:nt .LBB12_148
		memw(r29+#368) = r20
	}                                       // 4-byte Folded Spill
// %bb.97:                              // %if.end281
	{
		r5 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p3 = r5
		if (p3.new) r25 = #0
		if (p3.new) jump:nt .LBB12_190
		if (p3.new) r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.98:                              // %if.end281
	{
		r8 = #0
		p2 = cmp.eq(r24,r20)
		if (!p2.new) r25 = #0
		if (!p2.new) jump:nt .LBB12_147
	}
// %bb.99:
	{
		r5:4 = combine(#1,#0)
		r7:6 = memd(r29+#1656)
		r9 = memw(r29+#272)
	}                                       // 8-byte Folded Reload
	{
		r7 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB12_100,r6)
		r6 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_100:                             // Block address taken
                                        // %for.body296
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r9+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_146
	}
// %bb.101:                             // %if.end300
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = r3
		r12 = memw(r6+#0)
	}
	{
		r2 += mpyi(r12,#96)
	}
	{
		r12 = memb(r2+#88)
	}
	{
		r13 = abs(r12)
		r12 = #0
	}
	{
		p1 = cmp.eq(r13,#0)
		if (p1.new) jump:nt .LBB12_104
	}
// %bb.102:                             // %if.end300
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_104
	}
// %bb.103:                             // %if.end300
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r13,#1)
		if (!p2.new) jump:t .LBB12_123
	}
	.falign
.LBB12_104:                             // %for.inc.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_109
	}
// %bb.105:                             // %for.inc.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r14,#7)
		if (p0.new) jump:nt .LBB12_107
	}
// %bb.106:                             // %for.inc.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r14,#1)
		if (!p2.new) jump:t .LBB12_123
	}
	.falign
.LBB12_107:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		if (p1) jump:nt .LBB12_110
	}
// %bb.108:                             // %lor.lhs.false.1.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r13,r14)
		if (!p1.new) jump:t .LBB12_123
	}
	{
		jump .LBB12_110
	}
	.falign
.LBB12_109:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_110:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_115
	}
// %bb.111:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r13,#7)
		if (p0.new) jump:nt .LBB12_113
	}
// %bb.112:                             // %for.inc.1.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r13,#1)
		if (!p2.new) jump:t .LBB12_123
	}
	.falign
.LBB12_113:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r14,#0)
		if (p1.new) jump:nt .LBB12_116
	}
// %bb.114:                             // %lor.lhs.false.2.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r14,r13)
		if (!p3.new) jump:t .LBB12_123
	}
	{
		jump .LBB12_116
	}
	.falign
.LBB12_115:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_116:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_121
	}
// %bb.117:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r2,#7)
		if (p2.new) jump:nt .LBB12_119
	}
// %bb.118:                             // %for.inc.2.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB12_123
	}
	.falign
.LBB12_119:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r13,#0)
		if (p3.new) jump:nt .LBB12_122
	}
// %bb.120:                             // %lor.lhs.false.3.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r13,r2)
		if (!p0.new) jump:t .LBB12_123
	}
	{
		jump .LBB12_122
	}
	.falign
.LBB12_121:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = r13
	}
	.falign
.LBB12_122:                             // %for.inc.3.i
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r12 = maxu(r2,r5)
	}
	.falign
.LBB12_123:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = r3
		r17 = #8
		r13 = memw(r7+#0)
	}
	{
		r2 += mpyi(r13,#96)
	}
	{
		r13 = memb(r2+#88)
	}
	{
		r13 = abs(r13)
	}
	{
		p2 = cmp.eq(r13,#0)
		if (p2.new) jump:nt .LBB12_126
	}
// %bb.124:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r13,#7)
		if (p1.new) jump:nt .LBB12_126
	}
// %bb.125:                             // %htp_tl2_palette_magnitude.exit
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r13,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_157
	}
	.falign
.LBB12_126:                             // %for.inc.i5213
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r14 = memb(r2+#89)
	}
	{
		r14 = abs(r14)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_131
	}
// %bb.127:                             // %for.inc.i5213
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r14,#7)
		if (p1.new) jump:nt .LBB12_129
	}
// %bb.128:                             // %for.inc.i5213
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r14,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_157
	}
	.falign
.LBB12_129:                             // %lor.lhs.false.1.i5216
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		if (p2) jump:nt .LBB12_132
	}
// %bb.130:                             // %lor.lhs.false.1.i5216
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r13,r14)
		if (p2.new) jump:t .LBB12_132
	}
	{
		jump .LBB12_150
	}
	.falign
.LBB12_131:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_132:                             // %for.inc.1.i5221
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r13 = memb(r2+#90)
	}
	{
		r13 = abs(r13)
		if (cmp.eq(r13.new,#0)) jump:nt .LBB12_137
	}
// %bb.133:                             // %for.inc.1.i5221
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r13,#7)
		if (p1.new) jump:nt .LBB12_135
	}
// %bb.134:                             // %for.inc.1.i5221
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r13,#1)
		if (!p3.new) r2 = #8
		if (!p3.new) jump:nt .LBB12_157
	}
	.falign
.LBB12_135:                             // %lor.lhs.false.2.i5224
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r14,#0)
		if (p2.new) jump:nt .LBB12_138
	}
// %bb.136:                             // %lor.lhs.false.2.i5224
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r14,r13)
		if (p0.new) jump:t .LBB12_138
	}
	{
		jump .LBB12_151
	}
	.falign
.LBB12_137:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r13 = r14
	}
	.falign
.LBB12_138:                             // %for.inc.2.i5229
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r14 = abs(r2)
		if (cmp.eq(r14.new,#0)) jump:nt .LBB12_143
	}
// %bb.139:                             // %for.inc.2.i5229
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p3 = cmp.eq(r14,#7)
		if (p3.new) jump:nt .LBB12_141
	}
// %bb.140:                             // %for.inc.2.i5229
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p2 = cmp.eq(r14,#1)
		if (!p2.new) r2 = #8
		if (!p2.new) jump:nt .LBB12_157
	}
	.falign
.LBB12_141:                             // %lor.lhs.false.3.i5232
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p0 = cmp.eq(r13,#0)
		if (p0.new) jump:nt .LBB12_144
	}
// %bb.142:                             // %lor.lhs.false.3.i5232
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		p1 = cmp.eq(r13,r14)
		if (p1.new) jump:t .LBB12_144
	}
	{
		jump .LBB12_152
	}
	.falign
.LBB12_143:                             //   in Loop: Header=BB12_100 Depth=1
	{
		r14 = r13
	}
	.falign
.LBB12_144:                             // %htp_tl2_palette_magnitude.exit5241
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r4 = max(r12,r4)
		p3 = cmp.eq(r12,#0)
		r2 = #8
		if (p3.new) jump:nt .LBB12_157
	}
// %bb.145:                             // %if.end316
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r2 = maxu(r14,r5)
	}
	{
		r8 = max(r2,r8)
	}
	.falign
.LBB12_146:                             // %for.inc329
                                        //   in Loop: Header=BB12_100 Depth=1
	{
		r9 = add(r9,#4)
		r17 = r8
		r7 = add(r7,#4)
		r6 = add(r6,#4)
	}
	{
		r2 = r4
		nop
	} :endloop0
	{
		jump .LBB12_157
	}
	.falign
.LBB12_147:
	{
		jump .LBB12_190
		r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_148:
	{
		jump .LBB12_190
		r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_150:
	{
		r2 = #8 ; jump .LBB12_157
	}
	.falign
.LBB12_151:
	{
		r2 = #8 ; jump .LBB12_157
	}
	.falign
.LBB12_152:
	{
		r2 = #8 ; jump .LBB12_157
	}
	.falign
.LBB12_157:                             // %cleanup331
	{
		call hexkl_acc_i24_usable
		r1 = sub(#0,r2)
		r3 = r22
	}
	.falign
// %bb.158:                             // %cleanup331
	{
		r20 = r0
		r1 = sub(#0,r17)
		r3:2 = combine(r22,r17)
		r0 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_acc_i24_usable
	}
	.falign
// %bb.159:                             // %cleanup331
	{
		p3 = cmp.eq(r0,#0)
		p1 = cmp.eq(r20,#0)
		r17 = #8192
		r2 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		r1 = p1
		r0 = p3
		p2 = cmp.eq(r2,#0)
		memw(r29+#372) = r1.new
	}                                       // 4-byte Folded Spill
	{
		if (!p2) jump:nt .LBB12_653
		if (!p2) r0 = memw(r29+##256)
		memw(r29+#380) = r0
	}                                       // 4-byte Folded Reload
// %bb.160:                             // %cleanup331
	{
		p0 = cmp.gtu(r16,#1); if (!p0.new) jump:nt .LBB12_696
		if (p0.new) r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.161:                             // %cleanup331
	{
		r1:0 = memd(r29+#1696)
		r2 = memw(r29+#260)
	}                                       // 8-byte Folded Reload
	{
		if (p1.new) r3 = #32
		p1 = cmp.eq(r1,#0); if (!p1.new) jump:nt .LBB12_174
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
// %bb.162:                             // %cleanup331
	{
		r3 = memw(r29+#1680)
		if (!cmp.eq(r3.new,r3)) jump:nt .LBB12_174
	}                                       // 4-byte Folded Reload
// %bb.163:                             // %cleanup331
	{
		r3 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) jump:nt .LBB12_174
	}
// %bb.164:                             // %cleanup331
	{
		r3 = #1536
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB12_174
	}
// %bb.165:                             // %cleanup331
	{
		r3 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (!p3.new) jump:nt .LBB12_174
		if (p3.new) r3 = memw(r29+##372)
	}                                       // 4-byte Folded Reload
// %bb.166:                             // %cleanup331
	{
		p2 = r3
		if (p2.new) jump:nt .LBB12_174
		if (!p2.new) r3 = memw(r29+##380)
	}                                       // 4-byte Folded Reload
// %bb.167:                             // %cleanup331
	{
		p1 = r3
		if (p1.new) jump:nt .LBB12_174
	}
// %bb.168:                             // %if.then360
	{
		call hvx_tl2_weight_bytes
		r0 = #2048
		r1 = #3072
	}
	.falign
// %bb.169:                             // %if.then360
	{
		call hvx_tl2_weight_bytes
		r17 = r0
		r0 = #1536
		r1 = #2048
	}
	.falign
// %bb.170:                             // %if.then360
	{
		r3 = add(r0,r17)
		r4 = add(r29,#8704)
		r5 = add(r29,#3872)
		r1:0 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		call hexkl_acc_i24_banks
		r2 = #32
		r1 = r18
	}
	.falign
// %bb.171:                             // %if.then360
	{
		r1 = #0
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB12_173
	}
// %bb.172:                             // %if.then369
	{
		r25 = memw(r29+#3872)
		memw(r29+#708) = r25.new
	}
	{
		r2 = memw(r29+##8704)
		memw(r29+#700) = r2.new
	}
	{
		r2 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,r25)
		r2 = #2
		memw(r29+#704) = r2.new
	}
	{
		r2 = r17
		r17 = #6144
		memw(r29+#364) = r3
	}                                       // 4-byte Folded Spill
	{
		r1 = add(r3,r2)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#256)
		memd(r29+#1696) = r1:0
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_174
	}
	.falign
.LBB12_173:
	{
		r17 = #8192
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#256)
		memd(r29+#1696) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_174:                             // %if.end374
	{
		r3 = memw(r29+#364)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_177
	}                                       // 4-byte Folded Reload
// %bb.175:                             // %if.then377
	{
		call hvx_tl2_weight_bytes
		r1 = r26
	}
	.falign
// %bb.176:                             // %if.then377
	{
		r25 = add(r0,r25)
		jump .LBB12_178
		r2 = memw(r29+#260)
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_177:
	{
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_178:                             // %if.end381
	{
		r5:4 = memd(r29+#1696)
	}                                       // 8-byte Folded Reload
	{
		r4 = r17
		p3 = cmp.eq(r5,#0)
		if (!p3.new) r0 = add(r2,#0)
		if (p3.new) jump:nt .LBB12_181
	}
// %bb.179:                             // %if.then383
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.180:                             // %if.then383
	{
		r25 = add(r0,r25)
		r4 = r17
		r2 = memw(r29+#284)
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_182
	}
	.falign
.LBB12_181:
	{
		r2 = memw(r29+#284)
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_182:                             // %if.end386
	{
		r7:6 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		r3 = add(r6,#-3072)
		p2 = cmp.gtu(r6,##3071)
		if (!p2.new) jump:nt .LBB12_188
	}
// %bb.183:                             // %if.end386
	{
		r3 = insert(r4,#11,#0)
		if (cmp.gtu(r25,r3.new)) jump:nt .LBB12_187
	}
// %bb.184:                             // %if.then390
	{
		r2 = add(r2,r3)
		r3 = memw(r29+#372)
		r5 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		p2 = r5
		r3 = #0
	}
	{
		r3 = mux(p2,#0,r2)
		r25 = mux(p0,#0,r2)
	}
	{
		r16 = r3
		r3 = or(r25,r3)
		if (cmp.eq(r3.new,#0)) jump:t .LBB12_189
	}
// %bb.185:                             // %if.then402
	{
		call hexkl_acc_i24_prepare
		r0 = r2
	}
	.falign
// %bb.186:                             // %if.then402
	{
		r2 = r16
		r4 = r17
		r0 = memw(r29+#256)
		r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_190
	}
	.falign
.LBB12_187:
	{
		r2 = #0 ; jump .LBB12_190
		r25 = #0
	}
	.falign
.LBB12_188:
	{
		r2 = #0 ; jump .LBB12_190
		r25 = #0
	}
	.falign
.LBB12_189:
	{
		r2 = #0
		r25 = #0
		r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_190:                             // %if.end405
	{
		r20 = and(r16,##33554432)
		r5 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p0 = r5
		r5 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p2 = r5
	}
	{
		p3 = and(p2,p0)
		if (p3.new) jump:nt .LBB12_192
	}
// %bb.191:                             // %if.end405
	{
		p2 = cmp.eq(r20,#0)
		if (!p2.new) jump:t .LBB12_850
	}
	.falign
.LBB12_192:                             // %if.end416
	{
		p2 = and(p2,!p2)
		r2 = memw(r29+#332)
		memw(r29+#392) = r2
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		memw(r29+#388) = r4
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r19+##hexkl_probe_us@GOT)
		r5 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		r21 = lsr(r21,r5)
		r2 = mux(p3,#1,#0)
		r3 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r17 = lsr(r3,r5)
		r5 = p2
		r3 = #0
		memw(r29+#240) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = p2
		memw(r29+#380) = r5.new
	}                                       // 4-byte Folded Spill
	{
		r5 = p2
		memd(r4+#224) = r3:2
	}
	{
		if (!p3) jump:nt .LBB12_198
		memw(r29+#372) = r5
	}                                       // 4-byte Folded Spill
// %bb.193:                             // %land.lhs.true444
	{
		r2 = and(r16,##131104)
	}
	{
		p0 = cmp.eq(r2,#32)
		r2 = memw(r29+#328)
		if (!p0.new) r5:4 = memd(r29+##1688)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
	}
	{
		p1 = not(p3)
	}
	{
		r2 = p1
		if (!p0) jump:nt .LBB12_195
		memw(r29+#240) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.194:
	{
		r2 = p2
		jump .LBB12_198
		memw(r29+#372) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_195:                             // %land.lhs.true448
	{
		r3:2 = combine(#0,r17)
	}
	{
		r5:4 = asl(r3:2,#1)
		r9:8 = combine(#0,r4)
	}
	{
		p1 = cmp.gtu(r5:4,r9:8)
		r6 = r8
	}
	{
		if (!p1) jump:nt .LBB12_197
		memd(r29+#1688) = r7:6
	}                                       // 8-byte Folded Spill
// %bb.196:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB12_198
		memw(r29+#372) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_197:                             // %land.rhs454
	{
		r5:4 = combine(#0,r21)
	}
	{
		r5:4 = asl(r5:4,#1)
	}
	{
		p3 = cmp.gtu(r5:4,r3:2)
	}
	{
		p3 = not(p3)
	}
	{
		r2 = p3
		memw(r29+#372) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_198:                             // %land.end460
	{
		call hvx_tl2_table_bytes
	}
	.falign
// %bb.199:                             // %land.end460
	{
		r16 = memw(r29+#260)
		memd(r29+#1712) = r1:0
	}                                       // 4-byte Folded Reload
	{
		call hvx_tl2_table_bytes
		r0 = r16
	}
	.falign
// %bb.200:                             // %land.end460
	{
		r8 = r0
		r2 = memw(r29+#336)
		memw(r29+#384) = r17
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB12_238
		if (!p1.new) r0 = memw(r29+##256)
	}                                       // 4-byte Folded Reload
// %bb.201:                             // %land.end460
	{
		r2 = #1536
		if (!cmp.eq(r2.new,r16)) jump:nt ##.LBB12_260
	}
// %bb.202:                             // %land.end460
	{
		r2 = memw(r29+#344)
		r0 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB12_611
		if (p0.new) r3:2 = memd(r29+##1656)
	}                                       // 8-byte Folded Reload
// %bb.203:                             // %land.end460
	{
		p0 = cmp.eq(r2,#64)
		if (!p0.new) jump:nt .LBB12_610
		if (p0.new) r2 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.204:                             // %land.end460
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB12_270
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
// %bb.205:                             // %land.end460
	{
		r2 = memw(r29+#368)
		if (cmp.gtu(r2.new,#4)) jump:nt .LBB12_227
	}                                       // 4-byte Folded Reload
// %bb.206:                             // %land.end460
	{
		p3 = cmp.eq(r27,#1)
		r17 = ##-2147449856
		if (!p3.new) jump:nt .LBB12_208
	}
// %bb.207:                             // %land.lhs.true489
	{
		r2 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r24,r2)
		r2 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r2 = memw(r29+#376)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
	}
	{
		p0 = and(p0,and(p2,p3))
	}
	{
		r2 = p0
		memw(r29+#380) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_208:                             // %land.end497
	{
		r4 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		p0 = r4
		if (!p0.new) jump:t .LBB12_218
		if (!p0.new) r4 = memw(r29+##372)
	}                                       // 4-byte Folded Reload
// %bb.209:                             // %land.lhs.true500
	{
		r3 = #8192
		r2 = add(r17,#-32754)
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.gtu(r16,r3); if (p1.new) jump:nt .LBB12_850
	}
// %bb.210:                             // %land.lhs.true500
	{
		p3 = cmp.gtu(r0,r3)
		if (!p3.new) r3 = #0
		if (p3.new) jump:nt .LBB12_850
	}
// %bb.211:                             // %land.lhs.true500
	{
		r2 = memw(r29+#356)
		r4 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p1 = r4
		p0 = r2
		r16 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r16,#1)
		p2 = and(p0,p1)
		if (!p2.new) jump:nt .LBB12_850
	}
// %bb.212:                             // %lor.lhs.false511
	{
		r5:4 = memd(r29+#1712)
	}                                       // 8-byte Folded Reload
	{
		r5 = #0
		r6 = r4
	}
	{
		r5:4 = add(r5:4,r3:2)
		r2 = memw(r29+#368)
		memd(r29+#1712) = r7:6
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r8,r2)
		r7:6 = memd(r29+#1688)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r3:2)
		r2 = r6
	}
	{
		p0 = cmp.gtu(r5:4,r3:2)
		if (!p0.new) r1 = add(r26,#0)
		if (p0.new) jump:t .LBB12_850
	}
// %bb.213:                             // %lor.lhs.false522
	{
		call hvx_tl2_weight_bytes
		memw(r29+#396) = r8
		memd(r29+#1688) = r3:2
	}                                       // 4-byte Folded Spill
	.falign
// %bb.214:                             // %lor.lhs.false522
	{
		p1 = cmp.gtu(r0,r16); if (p1.new) jump:t .LBB12_850
		if (!p1.new) r0 = memw(r29+##260)
	}                                       // 4-byte Folded Reload
// %bb.215:                             // %lor.lhs.false527
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.216:                             // %lor.lhs.false527
	{
		p3 = cmp.gtu(r0,r21)
		if (!p3.new) r2 = #0
		if (p3.new) jump:t .LBB12_850
		memw(r29+#356) = r21
	}                                       // 4-byte Folded Spill
// %bb.217:                             // %if.end532.thread
	{
		r17 = ##-2147449856
		memw(r29+#400) = r20
		memw(r29+#752) = r2
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_219
	}
	.falign
.LBB12_218:                             // %if.end532
	{
		p2 = r4
		r2 = #0
		memw(r29+#752) = r2.new
	}
	{
		r2 = #1
		memw(r29+#396) = r8
		memw(r29+#356) = r21
	}                                       // 4-byte Folded Spill
	{
		if (!p2) jump:nt .LBB12_220
		memw(r29+#400) = r20
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_219:                             // %cond.true534
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r2,#2,#22)
	}
	{
		r2 = add(r2,#1)
	}
	.falign
.LBB12_220:                             // %cond.end537
	{
		r21 = lsr(r3,#1)
		r20 = lsr(r26,#6)
		r2 = #1
		memw(r29+#756) = r2
	}
	{
		r0 = add(r20,add(r21,#-1))
		r1 = r21
		r2 = #0
		memw(r29+#760) = r2
	}
	{
		call __hexagon_udivsi3
		memw(r29+#764) = r2
	}
	.falign
// %bb.221:                             // %cond.end537
	{
		r2 = add(r17,#-32748)
		p2 = cmp.gtu(r0,#16)
		r17:16 = memd(r29+#1664)
		memw(r29+#340) = r2.new
	}                                       // 8-byte Folded Reload
	{
		if (!p2) r24 = add(r19,#0)
		if (p2) jump:nt .LBB12_850
		if (!p2) r2 = memw(r29+##296)
	}                                       // 4-byte Folded Reload
// %bb.222:                             // %lor.lhs.false546
	{
		r27 = add(r2,#-1)
		r1 = memw(r29+#1680)
		memw(r29+#428) = r0
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#420) = r21
		memw(r29+#376) = r22
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		r0 = add(r27,r1)
		memw(r29+#424) = r26
	}                                       // 4-byte Folded Spill
	.falign
// %bb.223:                             // %lor.lhs.false546
	{
		r3 = add(r16,#63)
		p0 = cmp.gtu(r0,#16); if (p0.new) jump:t .LBB12_850
		if (!p0.new) r4 = memw(r23+#12)
	}
// %bb.224:                             // %if.end555
	{
		p2 = cmp.eq(r4,#0)
		r2 = memw(r23+#64)
		r1:0 = memd(r29+#1656)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r17 = and(r3,#-64)
		r8 = memw(r29+#264)
		memw(r29+#492) = r4
	}                                       // 4-byte Folded Reload
	{
		r2 = p2
		p2 = not(p2)
		memw(r29+#500) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r1 += mpyi(r0,#63)
		r7:6 = vaslw(r17:16,#2)
		r2 = memw(r29+#332)
		memw(r29+#520) = r3
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = p2
		r4 = memw(r29+#256)
		memd(r29+#1664) = r17:16
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r6,r8)
		p1 = not(p1)
		memw(r29+#292) = r2
		memd(r29+#1656) = r1:0
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r6,r4)
		p1 = and(p1,!p3)
		memw(r29+#504) = r2
	}                                       // 4-byte Folded Spill
	{
		r19:18 = vaslw(r1:0,#2)
		p0 = and(p2,!p3)
		memw(r29+#532) = r3
	}                                       // 4-byte Folded Spill
	{
		r16 = mpyi(r1,r4)
		r5 = p1
		r1 = r7
		r17 = add(r2,#127)
	}
	{
		r2 = p0
		memd(r29+#1680) = r1:0
		memw(r29+#404) = r5
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r2 = #0
		if (!p0) r3 = add(r3,#127)
		if (!p0) jump:nt .LBB12_229
		memw(r29+#460) = r2
	}                                       // 4-byte Folded Spill
// %bb.225:                             // %cond.true608
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.226:                             // %cond.true608
	{
		r0 = add(#4,asl(r0,#2))
		r3 = #127
		r4 = memw(r29+#256)
		r8 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r0,r4)
		jump .LBB12_229
	}
	.falign
.LBB12_227:
	{
		r17 = ##-2147449856
		jump .LBB12_208
	}
	.falign
.LBB12_229:                             // %cond.end614
	{
		r8 = add(#127,asl(r8,#4))
		r9 = add(r16,#127)
		r14 = memw(r29+#296)
		r11:10 = memd(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r22 = lsr(r11,#4)
		r28 = and(r9,#-128)
		r12 = memw(r29+#332)
		r1:0 = memd(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		p1 = r12
		r26 = asl(r0,#4)
		r13 = memw(r29+#300)
		r15 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r11 = extractu(r13,#21,#0)
		r13 = extractu(r13,#22,#0)
		r7 = r15
		r5 = r22
	}
	{
		r12 = asl(r11,#11)
		r11 = asl(r13,#10)
		if (p1) r26 = #0
		memw(r29+#516) = r11.new
	}                                       // 4-byte Folded Spill
	{
		r13 = extractu(r14,#23,#0)
		r4 = add(##383,mpyi(r4,r0))
		r0 = add(r19,#127)
	}
	{
		r6 = add(r20,add(r14,#1))
		r9 = asl(r13,#9)
		r16 = and(r0,#-128)
		memw(r29+#484) = r0
	}                                       // 4-byte Folded Spill
	{
		r11 += add(r9,r12)
		r0 = and(r8,#-128)
		r9:8 = combine(r10,#96)
		memw(r29+#432) = r9
	}                                       // 4-byte Folded Spill
	{
		r9 = add(#127,asl(r9,#6))
		r7 = add(#127,asl(r7,#4))
		memw(r29+#436) = r0
		memw(r29+#444) = r12
	}                                       // 4-byte Folded Spill
	{
		r14 = and(r7,#-128)
		r7 = r0
		r0 = add(r18,#127)
		r9 = and(r9,#-128)
	}
	{
		r8 = add(##159,mpyi(r10,r8))
		r6 = add(##127,mpyi(r6,r10))
	}
	{
		r7 += add(r11,r14)
		r13 = and(r0,#-128)
		memw(r29+#496) = r0
		memw(r29+#512) = r14
	}                                       // 4-byte Folded Spill
	{
		r1 = addasl(r12,r1,#3)
		r14 = and(r8,#-128)
		r0 = and(r6,#-128)
		r11 = r9
	}
	{
		r5 = add(##256,asl(r5,#1))
		r11 += add(r1,r14)
		r12 = and(r4,#-128)
	}
	{
		r4 = r0
		r1 = add(r26,#127)
		r9 = #8192
		memw(r29+#472) = r9
	}                                       // 4-byte Folded Spill
	{
		r0 = add(r16,r13)
		r1 = and(r1,#-128)
		r21 = mux(p1,#0,r12)
		memw(r29+#1736) = r0
	}                                       // 4-byte Folded Spill
	{
		r4 += add(r11,r13)
		r9 += asl(r7,#4)
		r5 = and(r5,##1073741568)
	}
	{
		r6 = +mpyi(r0,#3)
		r5 += add(r4,r28)
		r0 = and(r3,#-128)
		memw(r29+#1744) = r1
	}                                       // 4-byte Folded Spill
	{
		if (!p1) r9 = #0
		r4 = r21
		r3 = r1
		r1 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r5,r6)
		p0 = r1
		r2 = add(r2,#127)
		r5 = and(r17,#-128)
	}
	{
		r3 += add(r4,r9)
		p1 = and(p1,!p1)
		r17 = r0
		if (p0) r5 = #0
	}
	{
		r17 += add(r3,r5)
		r0 = and(r2,#-128)
		r3 = memw(r29+#244)
		memw(r29+#476) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = #1536
		p3 = cmp.eq(r3,#0)
		memw(r29+#1728) = r14
		memw(r29+#456) = r16
	}                                       // 4-byte Folded Spill
	{
		r17 += add(r0,r2)
		r2 = p1
		memw(r29+#480) = r13
		memw(r29+#508) = r26
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#412) = r28
		memw(r29+#448) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#452) = r0
		memw(r29+#1720) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#408) = r20
		memw(r29+#524) = r12
	}                                       // 4-byte Folded Spill
	{
		if (p3) jump:nt .LBB12_235
	}
// %bb.230:                             // %land.lhs.true759
	{
		r2 = memw(r23+#4)
		if (!cmp.eq(r2.new,r3)) jump:t .LBB12_235
	}
// %bb.231:                             // %land.lhs.true762
	{
		r19 = r27
		r1:0 = memd(r29+#1664)
		r3 = memw(r29+#336)
	}                                       // 8-byte Folded Reload
	{
		p2 = r3
		r2 = add(r0,#-128)
		r0 = #1536
		r1 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		p1 = not(p2)
		p0 = cmp.eq(r1,#0)
		p3 = cmp.eq(r15,r0)
		r1 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p0)
		p0 = not(p3)
		r27 = r19
		r0 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p3 = r1
		r1 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		p3 = or(p2,!p3)
		p2 = cmp.gtu(r2,##3968)
	}
	{
		p0 = or(p0,or(p3,p2))
		p2 = r0
		r0 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		p1 = or(p2,or(p1,p0))
		p3 = r1
	}
	{
		p0 = r0
	}
	{
		p3 = or(p3,or(p1,p0))
		if (!p3.new) r27 = add(r19,#0)
		if (p3.new) jump:nt .LBB12_235
	}
// %bb.232:                             // %land.lhs.true762
	{
		r2 = memw(r29+#368)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_655
	}                                       // 4-byte Folded Reload
// %bb.233:                             // %land.lhs.true762
	{
		r2 = memw(r29+#1704)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#368)
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB12_235
	}                                       // 4-byte Folded Reload
// %bb.234:                             // %land.rhs785
	{
		r2 = memw(r23+#8)
	}
	{
		p1 = cmp.gtu(r17,r2)
	}
	{
		p3 = not(p1)
	}
	{
		r0 = p3
		memw(r29+#1720) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_235:                             // %land.end788
	{
		r2 = memw(r24+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_239
	}
// %bb.236:                             // %if.then791
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.237:                             // %if.then791
	{
		r19:18 = combine(r1,r0)
		jump .LBB12_240
	}
	.falign
.LBB12_238:
	{
		r17 = ##-2147449856
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_208
	}
	.falign
.LBB12_239:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB12_240:                             // %do.end
	{
		call hexkl_moe_scratch_reserve
		r1:0 = combine(r17,r23)
	}
	.falign
// %bb.241:                             // %do.end
	{
		r2 = memw(r24+##hexkl_probe_on@GOT)
		memw(r29+#340) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_244
	}
// %bb.242:                             // %if.then797
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.243:                             // %if.then797
	{
		r1:0 = sub(r1:0,r19:18)
		r2 = memw(r24+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#72)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#72) = r1:0
	}
	.falign
.LBB12_244:                             // %do.end803
	{
		r20 = #0
		r2 = memw(r29+#340)
		if (!cmp.eq(r2.new,#0)) jump:t ##.LBB12_850
	}                                       // 4-byte Folded Reload
// %bb.245:                             // %for.body874.preheader
	{
		r19 = #0
		r1 = memw(r29+#1720)
		memw(r29+#588) = r27
	}                                       // 4-byte Folded Reload
	{
		p0 = r1
		r2 = memw(r29+#240)
		r3 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = mux(p0,#1,#0)
		r4 = memw(r23+#4)
		memw(r23+#60) = r2.new
	}
	{
		r7 = mux(p0,r3,#0)
		r8 = mux(p0,#0,r3)
		r2 = memw(r29+#308)
		memw(r29+#556) = r7.new
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r4,r7)
		r5 = mux(p3,#1,#0)
		r0 = memw(r29+#404)
		memw(r29+#592) = r5.new
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		r0 = add(r7,#1024)
		r6 = memw(r29+#1736)
		memw(r29+#416) = r0.new
	}                                       // 4-byte Folded Reload
	{
		if (p1) r5 = add(r2,#0)
		r1 = memw(r29+#412)
		r14 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r1)
		r0 = memw(r29+#456)
		memw(r29+#528) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r0)
		memw(r29+#344) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r2,r0)
		memw(r29+#560) = r8
		memw(r29+#540) = r4
	}                                       // 4-byte Folded Spill
	{
		r9 = add(r2,r0)
		r1:0 = memd(r29+#1680)
		memw(r29+#336) = r2
	}                                       // 8-byte Folded Reload
	{
		r24 = #0
		r12 = add(r9,r14)
		memw(r29+#244) = r24
		memw(r29+#536) = r25
	}                                       // 4-byte Folded Spill
	{
		r16 = add(r12,r14)
		r27 = memw(r29+#272)
		memw(r29+#580) = r7
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r16,r14)
		memw(r29+#440) = r9
		memw(r29+#292) = r12
	}                                       // 4-byte Folded Spill
	{
		r17 = add(r2,r1)
		r0 = memw(r29+#452)
		memw(r29+#488) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r17,r1)
		r1 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(r2,r8)
		r13 = mux(p0,r4,r2)
		memw(r29+#468) = r13.new
	}                                       // 4-byte Folded Spill
	{
		r15 = add(r8,r1)
		r1 = add(r22,#128)
		r22 = #0
		memw(r29+#596) = r1.new
	}                                       // 4-byte Folded Spill
	{
		r3 = add(r15,r0)
		r11 = and(r1,##536870784)
		r1 = memw(r29+#1728)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r5 = add(r8,#0)
		r0 = add(r3,r21)
		memw(r29+#600) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r4 = add(r0,r11)
		r0 = memw(r29+#1744)
		memw(r29+#568) = r15
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r11)
		memw(r29+#604) = r4
		memw(r29+#564) = r11
	}                                       // 4-byte Folded Spill
	{
		r4 = add(r4,r0)
		memw(r29+#548) = r4
		memw(r29+#620) = r8
	}                                       // 4-byte Folded Spill
	{
		r6 += add(r4,r1)
		r1 = memw(r29+#472)
		memw(r29+#552) = r4
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r6,r1)
		r0 = memw(r29+#444)
		memw(r29+#624) = r6
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#332)
		memw(r29+#544) = r5
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,add(r0,##512))
		r0 = add(r7,#512)
		memw(r29+#584) = r4.new
	}                                       // 4-byte Folded Spill
	{
		p2 = r1
		r2 = add(r4,r14)
		r4 = add(r3,#128)
		memw(r29+#576) = r0
	}                                       // 4-byte Folded Spill
	{
		r6 = mux(p2,#0,r4)
		r3 = mux(p2,r2,#0)
		memw(r29+#616) = r2
		memw(r29+#608) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#572) = r6
		memw(r29+#612) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_246:                             // %for.body874
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_255
	}
// %bb.247:                             // %if.then878
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		p2 = cmp.eq(r20,#0)
		if (p2.new) jump:nt .LBB12_253
		if (!p2.new) r3 = memw(r29+##332)
	}                                       // 4-byte Folded Reload
// %bb.248:                             // %cond.end884
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		p0 = r3
		if (!p0.new) r25 = add(r20,#-1)
		if (p0.new) jump:t .LBB12_253
	}
// %bb.249:                             // %land.lhs.true889
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		r4 = memw(r29+#272)
		r3 = memw(r12+r25<<#2)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r4+r3<<#2)
		if (!cmp.eq(r3.new,r2)) jump:t .LBB12_253
	}
// %bb.250:                             // %land.end904
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		r2 = asl(r2,#2)
		r4 = memw(r29+#288)
		r3 = memw(r16+r25<<#2)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r19,#2)
		r0 = addasl(r4,r3,#2)
	}
	{
		call memcmp
	}
	.falign
// %bb.251:                             // %land.end904
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		p1 = cmp.eq(r0,#0)
		r12 = memw(r29+#292)
		r9 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) jump:nt .LBB12_254
		memw(r16+r20<<#2) = r19
	}
// %bb.252:                             // %cond.end912.thread5555
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		r2 = memw(r9+r25<<#2)
		memw(r9+r20<<#2) = r2.new
	}
	{
		r20 = add(r20,#1)
		jump .LBB12_256
		memw(r12+r20<<#2) = r24
		r2 = memw(r27+#0)

	} :mem_noshuf
	.falign
.LBB12_253:                             // %cond.end912.thread
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		memw(r16+r20<<#2) = r19
	}
	.falign
.LBB12_254:                             // %if.then918
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		r20 = add(r20,#1)
		memw(r9+r20<<#2) = r22
		memw(r12+r20<<#2) = r24
	}
	{
		r2 = memw(r27+#0)
	}
	{
		r3 = add(r2,#63)
	}
	{
		r3 = and(r3,#-64)
	}
	{
		r22 = add(r3,r22)
		jump .LBB12_256
	}
	.falign
.LBB12_255:                             //   in Loop: Header=BB12_246 Depth=1
	{
		r2 = #0
	}
	.falign
.LBB12_256:                             // %if.end925
                                        //   in Loop: Header=BB12_246 Depth=1
	{
		r19 = add(r2,r19)
		r27 = add(r27,#4)
		r1:0 = memd(r29+#1656)
	}                                       // 8-byte Folded Reload
	{
		r24 = add(r24,#1)
		if (!cmp.eq(r24.new,r0)) jump:t .LBB12_246
	}
// %bb.257:                             // %for.cond.cleanup873
	{
		r2 = memw(r29+#244)
		memw(r29+#1680) = r20
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#464) = r16
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_261
	}
// %bb.258:                             // %if.then934
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.259:                             // %if.then934
	{
		jump .LBB12_262
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_260:
	{
		r17 = ##-2147449856
		r0 = memw(r29+#256)
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_208
	}
	.falign
.LBB12_261:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_262:                             // %do.end938
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.263:                             // %do.end938
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_265
	}
// %bb.264:                             // %if.then940
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_reset
	}
	.falign
.LBB12_265:                             // %if.end942
	{
		r2 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
	}
	{
		p0 = or(p1,p2)
		if (p0.new) jump:t .LBB12_272
		if (!p0.new) r2 = memw(r29+##500)
	}                                       // 4-byte Folded Reload
// %bb.266:                             // %if.else948
	{
		p0 = r2
		if (p0.new) r3 = #0
		if (p0.new) jump:nt .LBB12_271
	}
// %bb.267:                             // %if.then950
	{
		r2 = memw(r23+#16)
		memw(r29+#0) = r2.new
	}
	{
		r3:2 = memd(r29+#1664)
		r0 = memw(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		r3 = memw(r29+#256)
		r1 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r4 = r3
		r5 = memw(r29+#492)
		r6 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_rmsnorm_rows_f32
		memw(r29+#4) = r6
	}
	.falign
// %bb.268:                             // %if.then950
	{
		if (!p1.new) r2 = ##-2147449856
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB12_272
	}
// %bb.269:
	{
		r2 = add(r2,#-32754)
		jump .LBB12_808
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_270:
	{
		r17 = ##-2147449856
		jump .LBB12_208
	}
	.falign
.LBB12_271:                             // %if.else956
	{
		r5:4 = combine(#3,#0)
		r0 = memw(r29+#468)
		r1 = memw(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_272:                             // %if.end961
	{
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#0)
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r2 = p0
		memw(r29+#1720) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p3 = or(p1,p0)
		if (!p3.new) jump:t .LBB12_276
		if (!p3.new) r0 = memw(r29+##548)
	}                                       // 4-byte Folded Reload
// %bb.273:                             // %if.then966
	{
		r2 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		r2 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
	}
	{
		p0 = and(p1,!p2)
		if (p0.new) jump:t .LBB12_277
		if (!p0.new) r0 = memw(r29+##544)
	}                                       // 4-byte Folded Reload
// %bb.274:                             // %if.then970
	{
		call memset
		r1 = #0
		r2 = memw(r29+#504)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.275:                             // %if.then970
	{
		jump .LBB12_277
	}
	.falign
.LBB12_276:                             // %if.else974
	{
		call memset
		r1 = #0
		r2 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_277:                             // %do.body976
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_280
	}
// %bb.278:                             // %if.then978
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.279:                             // %if.then978
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_280:                             // %do.end984
	{
		r2 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:nt .LBB12_289
		if (!p3.new) r2 = memw(r29+##332)
	}                                       // 4-byte Folded Reload
// %bb.281:                             // %if.end993
	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_292
		if (!p3.new) r2 = memw(r29+##292)
	}                                       // 4-byte Folded Reload
// %bb.282:                             // %if.else1002
	{
		r2 = memw(r29+#756)
	}
	{
		p3 = cmp.gtu(r2,#1)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
	}
	{
		p2 = and(p0,p3)
		if (!p2.new) r1 = #0
		if (!p2.new) jump:t .LBB12_613
	}
// %bb.283:                             // %if.then1008
	{
		r0 = add(r29,#712)
		r2 = memw(r29+#292)
		r4 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+#0)
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r4+r3<<#2)
		r3 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r5,#96)
		call moe_m1_q_post
	}
	.falign
// %bb.284:                             // %if.then1008
	{
		call hvx_worker_pool_workers
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.285:                             // %if.then1008
	{
		r2 = add(r29,#712)
		r3 = memw(r29+#756)
		if (!cmp.gtu(r3.new,r0)) jump:t ##.LBB12_656
	}
// %bb.286:                             // %if.else1020
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_697
	}
// %bb.287:                             // %if.then1023
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.288:                             // %if.then1023
	{
		r25:24 = combine(r1,r0)
		jump .LBB12_698
		r3 = memw(r29+#756)
	}
	.falign
.LBB12_289:                             // %if.then987
	{
		r2 = #0
		r3 = #0
		r0 = memw(r29+#404)
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r5:4 = combine(#4,#0)
		if (p3.new) jump:t .LBB12_808
	}
// %bb.290:                             // %if.then989
	{
		r0 = memw(r29+#308)
		r1 = memw(r29+#620)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r6 = #0
		r2 = memw(r29+#504)
		memw(r29+#340) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.291:                             // %if.then989
	{
		jump .LBB12_808
	}
	.falign
.LBB12_292:                             // %if.then995
	{
		r5 = add(r29,#1816)
		r4 = memw(r29+#276)
		r3 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#676)
		r7 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r4+r2<<#2)
		memw(r29+#12) = r5

	} :mem_noshuf
	{
		r4 = memw(r29+#312)
		memw(r29+#4) = r7
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r6,#96)
		r2 = memw(r29+#364)
		r5 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#408)
		memw(r29+#0) = r6.new
	}                                       // 4-byte Folded Reload
	{
		call moe_push_gate_up_chunks
		memw(r29+#8) = #0
	}
	.falign
// %bb.293:                             // %if.then995
	{
		r1 = #0
	}
	{
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_294:                             // %if.end1074
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_297
	}
// %bb.295:                             // %if.then1077
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.296:                             // %if.then1077
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_297:                             // %do.end1081
	{
		r0 = memw(r29+#1672)
		r2 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#460)
		r5:4 = memd(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		if (!p2.new) r0 = add(r2,#0)
		r3 = memw(r23+#16)
		memw(r29+#8) = r3.new
	}
	{
		r2 = memw(r29+#380)
		r23:22 = memd(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r1 = r22
		r3 = memw(r29+#332)
		r4 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r5,#0)
		r2 = mux(p0,#1,r23)
		r5 = memw(r29+#568)
		r20 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p3) r4 = #0
		r3 = memw(r29+#492)
	}                                       // 4-byte Folded Reload
	{
		if (p0) r3 = #0
		r4 = memw(r29+#240)
		memw(r29+#16) = r4
	}                                       // 4-byte Folded Reload
	{
		p0 = r4
		r3 = memw(r29+#416)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		r5 = p3
		r4 = memw(r29+#572)
		memw(r29+#12) = r5
	}                                       // 4-byte Folded Reload
	{
		if (p0) r4 = add(r3,#0)
		r3 = memw(r29+#256)
		memw(r29+#460) = r5
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_rows_u8_params_rm
		r5:4 = combine(r17,r20)
		memw(r29+#0) = r4
	}
	.falign
// %bb.298:                             // %do.end1081
	{
		r2 = #1
		r3 = memw(r29+#496)
		r6 = memw(r29+#556)
	}                                       // 4-byte Folded Reload
	{
		r3 = lsr(r3,#7)
		r4 = memw(r29+#1680)
		r7 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		r8 = maxu(r4,r2)
		r2 = memw(r29+#560)
		memw(r29+#1720) = r8.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r6,r2)
		r4 = memw(r29+#448)
		r9 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r2,r21)
		r2 = extractu(r23,#23,#6)
		r23 = #384
		r5 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	{
		r3 += lsr(r5,#7)
		r4 += asl(r2,#9)
		r2 = r7
		r5 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r4,add(r5,##1024))
		r4 = add(r6,#1024)
		r6 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		loop1(.LBB12_299,r8)
		r3 = mpyi(r3,r23)
		r4 = add(r9,r4)
		r11 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r2 += add(r3,r6)
		r5 = add(r9,r5)
		r16 = memw(r29+#272)
		r3 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#24,#7)
		r6 = add(r7,r3)
		r8 = memw(r29+#440)
		r19 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r7 += asl(r3,#8)
		r9 = #0
		r3 = #0
		r15 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r4,r6)
		r7 = add(r4,r7)
	}
	.falign
.LBB12_299:                             // Block address taken
                                        // %for.body1114
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_305 Depth 2
                                        //     Child Loop BB12_311 Depth 2
	{
		r28 = lsr(r3,#4)
		r12 = memw(r8+#0)
		if (!cmp.eq(r12.new,r3)) jump:t .LBB12_314
	}
// %bb.300:                             // %if.end1121
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r13 = memw(r15+r9<<#2)
		r18 = memw(r29+#380)
	}                                       // 4-byte Folded Reload
	{
		p3 = r18
		if (!p3.new) r15 = memw(r19+r9<<#2)
		r12 = memw(r16+r13<<#2)
	}
	{
		r12 = add(r12,#63)
		if (p3) r13 = memw(r20+#0)
	}
	{
		r14 = and(r12,#-64)
	}
	{
		r12 = add(r14,r3)
		if (!p3) jump:nt .LBB12_302
		if (p3) r14 = memw(r29+##344)
	}                                       // 4-byte Folded Reload
// %bb.301:                             // %if.then1129
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r14 = memw(r29+#336)
		memw(r14+r3<<#2) = r13
	}                                       // 4-byte Folded Reload
	{
		r3 = r12
		jump .LBB12_314
		r13 = memw(r17+#0)
		memw(r14+r3<<#2) = r13.new
	}
	.falign
.LBB12_302:                             // %if.end1135
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r13 = addasl(r16,r13,#2)
		r0 = lsr(r12,#4)
		if (!cmp.gtu(r0.new,r28)) jump:t .LBB12_309
	}
// %bb.303:                             // %for.body1143.preheader
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r28 += add(r5,r2)
		r0 = sub(r28,r0)
	}
	{
		r10 = sub(#0,r0)
		r1:0 = combine(r3,r28)
	}
	{
		r11 = lsr(r10,#1)
		r10 = and(r10,#1)
	}
	{
		p0 = cmp.gtu(r11,#0)
		if (!p0.new) jump:t .LBB12_306
	}
// %bb.304:                             //   in Loop: Header=BB12_299 Depth=1
	{
		loop0(.LBB12_305,r11)
	}
	.falign
.LBB12_305:                             //   Parent Loop BB12_299 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r16 = add(r1,#16)
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p3 = cmp.gtu(r11,r1)
		r1 = add(r1,#32)
	}
	{
		r11 = mux(p3,#0,#1)
		memb(r0++#2) = r11.new
	}
	{
		r11 = memw(r13+#0)
	}
	{
		r11 = add(r11,r3)
	}
	{
		p2 = cmp.gtu(r11,r16)
	}
	{
		r11 = mux(p2,#0,#1)
		r28 = r0
		memb(r28+#1) = r11.new
	} :endloop0
	.falign
.LBB12_306:                             //   in Loop: Header=BB12_299 Depth=1
	{
		p0 = cmp.gtu(r10,#0)
		if (!p0.new) jump:t .LBB12_308
		if (p0.new) r28 = memw(r13+#0)
	}
	.falign
.LBB12_307:                             // Block address taken
                                        // %for.body1143
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r28 = add(r28,r3)
	}
	{
		p1 = cmp.gtu(r28,r1)
	}
	{
		r28 = mux(p1,#0,#1)
		memb(r0++#1) = r28.new
	}
	.falign
.LBB12_308:                             //   in Loop: Header=BB12_299 Depth=1
	{
		r16 = memw(r29+#272)
		r11 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#464)
		r20 = memw(r29+#488)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_309:                             // %for.cond1155.preheader
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r0 = addasl(r7,r3,#2)
		r15 = addasl(r11,r15,#2)
		p1 = cmp.eq(r14,#0)
		if (p1.new) jump:nt .LBB12_313
	}
// %bb.310:                             // %for.body1159.preheader
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r28 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB12_311,r14)
		r28 = addasl(r6,r3,#2)
		r1 = add(r4,r28)
		r14 = #0
	}
	{
		r3 = addasl(r1,r3,#2)
	}
	.falign
.LBB12_311:                             // Block address taken
                                        // %for.body1159
                                        //   Parent Loop BB12_299 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r1 = memw(r13+#0)
	}
	{
		p3 = cmp.gtu(r1,r14)
		r1 = #0
		r14 = add(r14,#1)
	}
	{
		if (p3) r1 = memw(r15+#0)
	}
	{
		r15 = add(r15,#4)
		memw(r3++#4) = r1
	}
	{
		r10 = memw(r20+r1<<#2)
		memw(r28++#4) = r10.new
	}
	{
		r1 = memw(r17+r1<<#2)
		memw(r0++#4) = r1.new
	} :endloop0
// %bb.312:                             //   in Loop: Header=BB12_299 Depth=1
	{
		r3 = r12
		jump .LBB12_314
		r15 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_313:                             //   in Loop: Header=BB12_299 Depth=1
	{
		r15 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_314:                             // %cleanup1180
                                        //   in Loop: Header=BB12_299 Depth=1
	{
		r9 = add(r9,#1)
		r8 = add(r8,#4)
		nop
	} :endloop1
// %bb.315:                             // %for.cond.cleanup1113
	{
		r2 = memw(r29+#332)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r4 = add(r29,##640)
		if (!p2.new) jump:t .LBB12_321
	}
// %bb.316:                             // %if.then1188
	{
		r5 = add(r29,#8704)
		r16 = add(r29,#16896)
		r2 = memw(r29+#360)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#3)
		r2 = memw(r29+#284)
		memw(r29+#328) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r3,#1)
		r3 = mux(p2,#1,#0)
		r4 = memw(r29+#352)
		memw(r16+#44) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		r0 = memw(r29+#324)
		r6 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r5,#8252)
		memw(r16+#48) = r6
		memd(r16+#56) = r3:2
	}
	{
		call hvx_worker_pool_workers
		memw(r29+#1664) = r2
	}                                       // 4-byte Folded Spill
	.falign
// %bb.317:                             // %if.then1188
	{
		call hvx_tl2_k_splits
		r2 = add(r0,#1)
		r0 = memw(r29+#256)
		r1 = memw(r29+#424)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.318:                             // %if.then1188
	{
		r2 = memw(r29+#240)
		memw(r29+#332) = r16
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_617
		memw(r16+#52) = r0
	}
// %bb.319:                             // %land.lhs.true1200
	{
		r2 = memw(r29+#424)
		r3 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#24,#0)
		r2 = add(r2,#127)
	}
	{
		r2 = and(r2,#-128)
	}
	{
		r3 = asl(r3,#8)
	}
	{
		r2 = mpyi(r0,r2)
		if (!cmp.gtu(r2.new,r3)) jump:t ##.LBB12_658
	}
// %bb.320:
	{
		r2 = ##-2147449856
	}
	{
		r2 = add(r2,#-32754)
		jump .LBB12_808
		memw(r29+#340) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_321:                             // %if.end1798
	{
		r2 = memw(r29+#468)
		memw(r29+#640) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#608)
		memw(r29+#644) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#528)
		memw(r29+#648) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#336)
		memw(r29+#656) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#324)
		r0 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#416)
		memw(r29+#660) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#256)
		memw(r29+#664) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#244)
		memw(r29+#652) = r0
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#552)
		r2 = memw(r29+#604)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r19,r16)
		memw(r29+#668) = r2
	}
	{
		r2 = memw(r17+##hexkl_moe_pack_bg_worker@GOT)
		memw(r19+#0) = r2.new
	}
	{
		r2 = lsr(r3,#4)
		memw(r19+#8) = r2.new
	}
	{
		r2 = memw(r29+#600)
		memw(r19+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit_bg
		memw(r19+#12) = r2
	}
	.falign
// %bb.322:                             // %if.end1798
	{
		r3 = memw(r29+#476)
		r4 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	{
		r4 = and(##-512,asl(r4,#3))
		r2 = memw(r29+#484)
		r5 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#7)
		r3 = add(r5,r3)
		r1 = memw(r29+#496)
		r0 = memw(r29+#524)
	}                                       // 4-byte Folded Reload
	{
		r2 += lsr(r1,#7)
		r6 = memw(r29+#448)
		r1 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r3,r0)
		r3 = #1536
		r0 = memw(r29+#596)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r6,r1)
		r0 = and(##1073741568,asl(r0,#1))
		r1 = memw(r29+#1728)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r2,r23)
		r6 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	{
		r1 += add(r4,r0)
		r0 = memw(r29+#1744)
	}                                       // 4-byte Folded Reload
	{
		r6 += add(r1,r0)
		r0 = memw(r29+#412)
		r1 = memw(r29+#1736)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r1)
		r1 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#2)
		r1 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r1,r3)
		call memset
		r1 = #255
	}
	.falign
// %bb.323:                             // %if.end1798
	{
		r1:0 = combine(r19,r16)
		r2 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r2,#64)
	}
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.324:                             // %if.end1798
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_327
	}
// %bb.325:                             // %if.then1909
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.326:                             // %if.then1909
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_327:                             // %do.end1915
	{
		p0 = and(p0,!p0)
		r2 = memw(r29+#676)
		r3 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r0 = p0
		r2 = add(r3,r2)
		r17 = memw(r29+#672)
		memw(r29+#236) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r3 = add(r3,r17)
		r2 = and(r2,#127)
	}
	{
		r3 = or(r2,and(r3,##2047))
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_329
	}
// %bb.328:                             // %land.rhs1921
	{
		r2 = memw(r29+#680)
		r4 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,r2)
		r3 = memw(r29+#688)
	}
	{
		r3 = add(r4,r3)
		r2 = and(r2,#127)
	}
	{
		r3 = or(r2,and(r3,##2047))
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		r0 = p1
		memw(r29+#236) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_329:                             // %land.end1926
	{
		r1:0 = memd(r29+#1688)
		r2 = memw(r29+#236)
	}                                       // 8-byte Folded Reload
	{
		p0 = r2
		r1 = add(r29,#672)
		r3:2 = memd(r29+#1664)
		memw(r29+#16) = r1.new
	}                                       // 8-byte Folded Reload
	{
		r0 = mux(p0,#1,#0)
		r1 = memw(r29+#320)
		memw(r29+#20) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#348)
		memw(r29+#12) = r1
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#256)
		r7:6 = memd(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r5 = r6
		r1 = memw(r29+#368)
		memw(r29+#8) = r1
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#352)
		memw(r29+#4) = r1
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r6,#0)
		r19 = memw(r29+#260)
		r1 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r19,r16)
		r1 = r2
		memw(r29+#0) = r1
	}
	{
		call lfm2_moe_hmx_issue_ok
		r6 = p1
		r4 = memw(r29+#264)
		memw(r29+#1656) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.330:                             // %land.end1926
	{
		r1 = memw(r29+#696)
		memw(r29+#480) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#588)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r0 = add(r2,r1)
	}
	.falign
// %bb.331:                             // %land.end1926
	{
		r9:8 = combine(#64,r0)
		r4 = r16
		r3 = memw(r29+#292)
		r7 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r2 = maxu(r7,r0)
		r1 = memw(r29+#1656)
		memw(r29+#540) = r8
	}                                       // 4-byte Folded Reload
	{
		p2 = r1
		p0 = cmp.gtu(r2,#8)
		r2 = sub(r2,r0)
		r3 = memw(r3+#0)
	}
	{
		p1 = not(p0)
		r0 = memw(r29+#272)
		memw(r29+#556) = r2
	}                                       // 4-byte Folded Reload
	{
		p3 = and(p1,!p2)
		r2 = memw(r29+#416)
		memw(r29+#352) = r3
	}                                       // 4-byte Folded Reload
	{
		r1 = p3
		r6 = memw(r0+r3<<#2)
		r0 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		p1 = cmp.gtu(r6,#64)
		r0 = memw(r29+#440)
		memw(r29+#468) = r1
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r6,r9)
		p2 = and(p3,!p0)
		r12 = mux(p1,#0,#1)
		r23 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = p2
		r22 = memw(r0+#0)
		r16 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r17,r23)
		r3 = r22
		r5 = r16
		memw(r29+#564) = r1
	}                                       // 4-byte Folded Spill
	{
		r17 = minu(r8,r7)
		memw(r29+#4) = #0
		memw(r29+#0) = #0
	}
	{
		call moe_push_act_block
		memw(r29+#368) = r6
		memw(r29+#1688) = r12
	}                                       // 4-byte Folded Spill
	.falign
// %bb.332:                             // %land.end1926
	{
		p3 = or(p3,!p3)
		r1 = #0
		r2 = memw(r29+#684)
		memw(r29+#528) = r17
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r23,r2)
		r4 = memw(r29+#552)
		memw(r29+#488) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r4,#96)
		r2 = #-1
		memw(r29+#568) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = extractu(r16,#22,#0)
		r2 = #1
		memw(r29+#492) = r2
		memw(r29+#472) = r0
	}                                       // 4-byte Folded Spill
	{
		r3 = asl(r3,#10)
		r2 = #0
		memw(r29+#328) = r2
		memw(r29+#484) = r4
	}                                       // 4-byte Folded Spill
	{
		r3 = extractu(r19,#23,#4)
		memw(r29+#604) = r3
		memw(r29+#356) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#332) = r2
		memw(r29+#412) = r2
	}                                       // 4-byte Folded Spill
	{
		r3 = asl(r3,#9)
		memw(r29+#436) = r2
		memw(r29+#520) = r2
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#420)
		memw(r29+#396) = r3
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#456) = r2
		memw(r29+#476) = r2
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r17,r3)
		memw(r29+#572) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p3
		r3 = memw(r29+#536)
		memw(r29+#500) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = #0
		r3 = !cmp.eq(r3,#0)
		memw(r29+#460) = r2
		memd(r29+#1672) = r1:0
	}                                       // 4-byte Folded Spill
	{
		r2 = #1
		memw(r29+#560) = r3
		memw(r29+#1720) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = #0
		r3 = memw(r29+#392)
		memw(r29+#348) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = !cmp.eq(r3,#0)
		memw(r29+#596) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3:2 = combine(#0,#0)
		memw(r29+#248) = r2
		memw(r29+#516) = r2
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#1736) = r3:2
		memd(r29+#1728) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#1744) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_333:                             // %for.cond1971
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_368 Depth 2
                                        //       Child Loop BB12_396 Depth 3
                                        //       Child Loop BB12_441 Depth 3
                                        //         Child Loop BB12_448 Depth 4
                                        //         Child Loop BB12_454 Depth 4
                                        //       Child Loop BB12_419 Depth 3
                                        //     Child Loop BB12_507 Depth 2
                                        //       Child Loop BB12_544 Depth 3
                                        //         Child Loop BB12_551 Depth 4
                                        //         Child Loop BB12_557 Depth 4
                                        //     Child Loop BB12_503 Depth 2
	{
		r1 = memw(r29+#332)
		memw(r29+#384) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#352)
		memw(r29+#340) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#368)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#348)
		r1 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r1 = memw(r29+#328)
		memw(r29+#1712) = r1
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#1688)
		memw(r29+#380) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#280)
		memw(r29+#360) = r0
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#436)
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r3,#2)
		p2 = cmp.eq(r0,#0)
		r1 = memw(r29+#480)
		memw(r29+#1656) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = p2
		r0 = p3
		p1 = cmp.eq(r1,#0)
		memw(r29+#448) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#372) = r2.new
	}                                       // 4-byte Folded Spill
	{
		if (p3) jump:nt .LBB12_337
		memw(r29+#400) = r0
		if (p3) memw(r29+##452) = r22
	}                                       // 4-byte Folded Spill
// %bb.334:                             // %if.then1973
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		p2 = or(p2,!p2)
		r2 = memw(r29+#360)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_338
	}                                       // 4-byte Folded Reload
// %bb.335:                             // %if.end.i
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r3 = #0
		r4 = memw(r29+#384)
		memw(r29+#348) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r4,#1)
		r3 = memw(r29+#360)
		memw(r29+#1688) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#380)
		memw(r29+#328) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#1680)
		memw(r29+#452) = r22
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r3,r2)
		r3 = memw(r29+#240)
		memw(r29+#368) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#1712)
		memw(r29+#356) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#340)
		memw(r29+#352) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = p2
		memw(r29+#332) = r4
	}                                       // 4-byte Folded Spill
	{
		if (!p0) jump:nt .LBB12_340
		if (p0) r3 = memw(r29+##292)
		memw(r29+#524) = r3
	}                                       // 4-byte Folded Reload
// %bb.336:                             // %if.then3.i
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r0 = #64
		r6 = #0
		r1 = #1
	}
	{
		memw(r29+#356) = r6
		memw(r29+#328) = r1
	}                                       // 4-byte Folded Spill
	{
		r4 = memw(r3+r2<<#2)
		memw(r29+#352) = r4.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r2<<#2)
		memw(r29+#452) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r3 = minu(r3,r0)
		p1 = cmp.gtu(r3,#64)
		memw(r29+#368) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p0 = not(p1)
		jump .LBB12_339
	}
	.falign
.LBB12_337:                             //   in Loop: Header=BB12_333 Depth=1
	{
		r0 = memw(r29+#380)
		memw(r29+#328) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#240)
		memw(r29+#368) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#1712)
		memw(r29+#356) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#360)
		memw(r29+#1688) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#340)
		memw(r29+#352) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#384)
		memw(r29+#332) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		jump .LBB12_364
		memw(r29+#348) = r1
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_338:                             // %if.then.i
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#292)
		r4 = memw(r29+#1712)
	}                                       // 4-byte Folded Reload
	{
		r7 = add(r4,#64)
		r4 = add(r4,#128)
		r5 = memw(r29+#384)
		r1 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r0 = cmp.eq(r7,#0)
		memw(r29+#328) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r6 = memw(r2+r5<<#2)
		memw(r29+#356) = r7
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#440)
		memw(r29+#352) = r6
	}                                       // 4-byte Folded Reload
	{
		r2 = r5
		r3 = memw(r2+r5<<#2)
		r5 = memw(r1+r6<<#2)
	}
	{
		r3 = add(r3,r7)
		p2 = cmp.gtu(r5,r4)
		r6 = sub(r5,r7)
		memw(r29+#452) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p0 = not(p2)
		r3 = #64
	}
	{
		r3 = minu(r6,r3)
		memw(r29+#368) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_339:                             // %return.sink.split.i
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		p2 = and(p2,!p2)
		r4 = #1
		r3 = memw(r29+#1688)
		memw(r29+#348) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r0 = p2
		r3 = mux(p0,#1,#0)
		memw(r29+#332) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#524) = r0
		memw(r29+#1688) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_340:                             // %moe_blk_next.exit
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r5:4 = combine(#0,#1)
		r2 = memw(r29+#276)
		r3 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r2+r3<<#2)
	}
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_344
	}
// %bb.341:                             // %do.end1999
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#128)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#128) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.342:                             // %do.end1999
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
		memd(r29+#1704) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_344
	}
// %bb.343:                             // %if.then2001
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5:4 = memd(r29+#1672)
		r2 = memw(r29+#472)
	}                                       // 8-byte Folded Reload
	{
		call hexkl_dma_trace_wait_begin
		r3 = r5
	}
	.falign
.LBB12_344:                             // %if.end2003
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		call hexkl_dma_ring_wait
		r0 = memw(r29+#472)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.345:                             // %if.end2003
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_350
	}
// %bb.346:                             // %do.body2008
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.347:                             // %do.body2008
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_350
	}
// %bb.348:                             // %if.then2010
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.349:                             // %if.then2010
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#32)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#32) = r1:0
	}
	.falign
.LBB12_350:                             // %do.end2016
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r16 = memw(r29+#252)
		r0 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r18,#96)
	}
	{
		r2 = memw(r16+#20)
	}
	{
		r2 = addasl(r0,r22,#2)
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_352
		memw(r29+#508) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.351:                             // %if.then2020
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r4 = add(r29,#2456)
		r3 = memw(r29+#508)
		r6 = memw(r29+#672)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#284)
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_sums
		r0 = add(r5,r6)
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_352:                             // %if.end2024
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = #63
	}
	{
		r2 = memw(r29+#424)
		if (cmp.gtu(r2.new,r2)) jump:t .LBB12_367
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_353:                             // %for.end2461
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#524)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:t .LBB12_364
		if (!p2.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.354:                             // %do.body2464
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_357
	}
// %bb.355:                             // %if.then2466
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.356:                             // %if.then2466
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_357:                             // %do.end2470
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#452)
		r1 = memw(r29+#552)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#64)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
		r2 = lsr(r2,#4)
	}
	.falign
// %bb.358:                             // %do.end2470
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_361
	}
// %bb.359:                             // %if.then2476
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.360:                             // %if.then2476
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_361:                             // %do.end2482
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#332)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#672)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#356)
		r5 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r2 = lsr(r2,#6)
		r3 = memw(r29+#452)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#416)
		r4 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		call moe_push_act_block
	}
	.falign
// %bb.362:                             // %do.end2482
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#328)
		memw(r29+#472) = r0
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB12_364
		if (!p2.new) r3 = memw(r29+##352)
	}                                       // 4-byte Folded Reload
// %bb.363:                             // %if.then2490
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#276)
		r1 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#332)
		r4 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r2+r3<<#2)
		memw(r29+#8) = r0

	} :mem_noshuf
	{
		r3 = memw(r29+#252)
		r2 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r3 += mpyi(r5,#96)
		r0 = memw(r29+#284)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#408)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#1816)
		r5 = memw(r29+#316)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Reload
	{
		call moe_push_gate_up_chunks
		r2 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_364:                             // %if.end2507
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB12_469
		if (p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.365:                             // %if.else2534
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#500)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_479
	}                                       // 4-byte Folded Reload
// %bb.366:                             // %land.lhs.true2555
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#584)
		r3 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#624)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r3<<#2)
	}
	{
		r2 = addasl(r0,r2,#6)
		p2 = cmp.eq(r2,#-1)
	}
	{
		if (p2) r2 = #0
	}
	{
		jump .LBB12_480
		memw(r29+#448) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_367:                             // %for.body2029.lr.ph
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r18 = #0
		r20 = #0
		r2 = memw(r29+#476)
		r1 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		p3 = r1
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#380)
		r1 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		p3 = not(p3)
		p0 = not(p0)
		p2 = cmp.eq(r0,#0)
		r0 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r22,#2)
		r0 = memw(r29+#408)
		memw(r29+#588) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r1,#2)
		r1 = memw(r29+#468)
		memw(r29+#496) = r0
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		r1 = p2
		memw(r29+#608) = r2
	}                                       // 4-byte Folded Spill
	{
		p3 = and(p0,and(p1,p3))
		p0 = and(p1,!p2)
		memw(r29+#600) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p3
		memw(r29+#592) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p0
		memw(r29+#512) = r0.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_368:                             // %for.body2029
                                        //   Parent Loop BB12_333 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_396 Depth 3
                                        //       Child Loop BB12_441 Depth 3
                                        //         Child Loop BB12_448 Depth 4
                                        //         Child Loop BB12_454 Depth 4
                                        //       Child Loop BB12_419 Depth 3
	{
		r17 = add(r29,#1752)
		r2 = memw(r29+#408)
		r3 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r20)
		r0 = memw(r29+#512)
		r26 = memw(r29+#692)
	}                                       // 4-byte Folded Reload
	{
		r24 = minu(r2,r3)
		p2 = r0
		if (!p2.new) jump:t .LBB12_378
		r23 = memw(r29+#696)
	}
// %bb.369:                             // %land.lhs.true2047
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3 = memw(r29+#244)
		r2 = memw(r17+r18<<#2)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p1) jump:nt .LBB12_380
		r2 = memw(r3+#0)
	}
// %bb.370:                             // %do.body2051
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_373
	}
// %bb.371:                             // %if.then2053
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.372:                             // %if.then2053
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_373:                             // %do.end2057
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r18,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.374:                             // %do.end2057
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_377
	}
// %bb.375:                             // %if.then2061
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.376:                             // %if.then2061
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_377:                             // %do.end2067
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = addasl(r17,r18,#2)
	}
	{
		jump .LBB12_401
		memw(r2+#0) = #0
	}
	.falign
.LBB12_378:                             // %if.else2069
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#600)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_401
		if (!p0.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.379:                             // %if.else2069.do.body2073_crit_edge
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_380:                             // %do.body2073
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r0 = add(r29,#1816)
		p0 = cmp.eq(r2,#0)
	}
	{
		r17 = addasl(r0,r18,#2)
		if (p0) jump:nt .LBB12_384
	}
// %bb.381:                             // %do.end2079
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.382:                             // %do.end2079
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1704) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_384
	}
// %bb.383:                             // %if.then2081
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #1
		r2 = memw(r17+#0)
	}
	.falign
.LBB12_384:                             // %if.end2084
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r17+#0)
	}
	.falign
// %bb.385:                             // %if.end2084
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_390
	}
// %bb.386:                             // %do.body2090
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.387:                             // %do.body2090
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_390
	}
// %bb.388:                             // %if.then2092
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.389:                             // %if.then2092
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_390:                             // %do.end2098
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r22 = memw(r29+#284)
		memw(r29+#4) = r24
	}                                       // 4-byte Folded Reload
	{
		r0 = r22
		r21 = memw(r29+#312)
		r27 = memw(r29+#364)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r16,r27)
		r25 = memw(r29+#316)
		r1 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r25,r21)
		r6 = memw(r29+#248)
		memw(r29+#0) = r20
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
		r17 = or(r6,r18)
		r19 = memw(r29+#324)
		memw(r29+#8) = r19.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.391:                             // %do.end2098
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r0 = r22
		r5:4 = combine(r25,r21)
		r2 = memw(r29+#408)
		r1 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r20,r2)
		memw(r29+#0) = r2.new
	}
	{
		call moe_expand_chunk
		r3:2 = combine(r16,r27)
		memw(r29+#8) = r19
		memw(r29+#4) = r24
	}
	.falign
// %bb.392:                             // %do.end2098
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB12_401
		if (p0.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.393:                             // %if.then2107
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#104)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r16+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_397
	}
// %bb.394:                             // %if.then2113
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3:2 = combine(#0,#0)
		r1:0 = memd(r16+#56)
	}
	{
		p3 = cmp.eq(r1:0,r3:2)
		if (p3.new) jump:nt .LBB12_398
		if (!p3.new) r2 = memw(r16+#28)
	}
// %bb.395:                             // %for.body2117.lr.ph
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3 = ##-1431655765
		r2 = add(r2,#23)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r3 = lsr(r2,#4)
		r2 = #0
	}
	{
		r3 = +mpyi(r3,##640)
	}
	.balign 32
.LBB12_396:                             // %for.body2117
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r5:4 = combine(#-1,#-1)
		r2 = add(r2,r3)
	}
	{
		r5:4 = add(r1:0,r5:4)
	}
	{
		r1:0 = and(r5:4,r1:0)
		r5:4 = combine(#0,#0)
	}
	{
		p2 = cmp.eq(r1:0,r5:4)
		if (!p2.new) jump:t .LBB12_396
	}
	{
		jump .LBB12_399
	}
	.falign
.LBB12_397:                             //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#604)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r24)
		jump .LBB12_399
	}
	.falign
.LBB12_398:                             //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = #0
	}
	.falign
.LBB12_399:                             // %do.body2129
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_404
	}
// %bb.400:                             // %if.then2131
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r6 = lsr(r2,#10)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+##hexkl_probe_us@GOT)
		r1:0 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		r7 = r1
	}
	{
		r5 = r7
		r1:0 = memd(r3+#80)
	}
	{
		r1:0 = add(r1:0,r7:6)
		memd(r29+#1672) = r5:4
	}                                       // 8-byte Folded Spill
	{
		memd(r3+#80) = r1:0
	}
	.falign
.LBB12_401:                             // %do.body2141
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_404
	}
// %bb.402:                             // %if.then2143
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.403:                             // %if.then2143
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_404:                             // %do.end2147
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r22 = #0
		r2 = memw(r29+#1720)
		r1 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r3 = and(r2,#1)
		r0 = memw(r29+#408)
		memw(r29+#532) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r3,r1)
		p3 = cmp.eq(r0,r20)
		if (!p3.new) r3 = memw(r29+##496)
	}                                       // 4-byte Folded Reload
	{
		r26 += mpyi(r2,r23)
		if (!p3) jump:nt .LBB12_440
		if (!p3) r2 = memw(r29+##420)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_405:                             // %do.body2247
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_408
	}
// %bb.406:                             // %if.then2249
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.407:                             // %if.then2249
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_408:                             // %do.end2260
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#528)
		r0 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	{
		p3 = r0
		r19 = add(r18,r2)
		r1 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r1,r19)
	}
	{
		p1 = and(p3,p0)
		if (!p1.new) jump:t .LBB12_418
		if (p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.409:                             // %if.then2269
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_412
	}
// %bb.410:                             // %if.then2282
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.411:                             // %if.then2282
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_412:                             // %do.end2286
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r19<<#2)
	}
	.falign
// %bb.413:                             // %do.end2286
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_416
	}
// %bb.414:                             // %if.then2291
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.415:                             // %if.then2291
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_416:                             // %do.end2297
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r3 = add(r29,#2712)
		r6 = add(r29,#2328)
		r2 = memw(r29+#572)
		r5 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r20,r2)
		r2 = add(r29,#5632)
		r0 = memw(r29+#316)
		memw(r29+#12) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r19,#5)
		r3 = addasl(r6,r19,#3)
		r7 = memw(r29+#312)
		memw(r29+#16) = r4
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r19,#192)
		r0 = memw(r29+#364)
		memw(r29+#0) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r8 = memw(r29+#408)
		memw(r29+#8) = r7
	}                                       // 4-byte Folded Reload
	{
		r7 = sub(r8,r4)
		r4 = add(r4,r8)
		r0 = memw(r29+#324)
		memw(r29+#20) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#420)
		memw(r29+#4) = r16
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r7,r6)
		call moe_expand_submit
		r4 = memw(r29+#284)
		memw(r29+#24) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.417:                             // %do.end2297
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r19<<#2) = r3
	}
	.falign
.LBB12_418:                             // %if.end2309
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r23 = add(r18,#1)
		r5 = memw(r29+#556)
		r0 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r18,r5)
		r2 = add(r18,sub(#1,r5))
		p0 = cmp.gtu(r5,r18)
		r4 = memw(r29+#428)
	}                                       // 4-byte Folded Reload
	{
		r19 = sub(r3,r5)
		if (p0) r2 = #0
		p1 = cmp.eq(r23,r4)
		r3 = memw(r29+#540)
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		if (p1) r2 = add(r3,#0)
	}
	{
		r21 = minu(r2,r3)
	}
	{
		p3 = cmp.gtu(r21,r19)
	}
	{
		p2 = and(p1,p3)
		if (!p2.new) jump:t .LBB12_429
	}
	.falign
.LBB12_419:                             // %land.rhs2346
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r22 = add(r19,#8)
		r25 = add(r29,#1752)
	}
	{
		r2 = memw(r25+r22<<#2)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_429
	}
// %bb.420:                             // %for.body2354
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r2 = memw(r29+#1656)
		r0 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r27 = memw(r29+#696)
	}
	{
		r17 = memw(r2+#0)
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_423
	}
// %bb.421:                             // %if.then2373
                                        //   in Loop: Header=BB12_419 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.422:                             // %if.then2373
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_423:                             // %do.end2377
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r2 = add(r29,#2008)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r19<<#2)
	}
	.falign
// %bb.424:                             // %do.end2377
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_427
	}
// %bb.425:                             // %if.then2381
                                        //   in Loop: Header=BB12_419 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.426:                             // %if.then2381
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_427:                             // %do.end2387
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r4 = mpyi(r27,r19)
		r3 = add(r29,#2712)
		r5 = memw(r29+#680)
		memw(r29+#16) = r4.new
	}
	{
		r6 = add(r29,#2328)
		r8 = memw(r29+#296)
		r1:0 = memd(r29+#1696)
	}                                       // 4-byte Folded Reload
	{
		r4 = sub(r8,r4)
		r2 = memw(r29+#300)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = minu(r4,r27)
		r2 = add(r29,#5632)
		r7 = memw(r29+#252)
		memw(r29+#0) = r1
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r22,#5)
		r3 = addasl(r6,r22,#3)
		r0 = memw(r29+#324)
		memw(r29+#24) = r4
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r22,#192)
		r7 += mpyi(r17,#96)
		r4 = memw(r29+#284)
		memw(r29+#12) = r8
	}                                       // 4-byte Folded Reload
	{
		r17 = addasl(r25,r22,#2)
		call moe_expand_submit
		memw(r29+#20) = #-1
		memw(r29+#4) = r7
	}
	.falign
// %bb.428:                             // %do.end2387
                                        //   in Loop: Header=BB12_419 Depth=3
	{
		r19 = add(r19,#1)
		memw(r17+#0) = #1
	}
	{
		p0 = cmp.gtu(r21,r19); if (p0.new) jump:t .LBB12_419
	}
	.falign
.LBB12_429:                             // %for.cond.cleanup2353
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_432
	}
// %bb.430:                             // %if.then2404
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.431:                             // %if.then2404
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_432:                             // %do.end2408
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.433:                             // %do.end2408
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_436
	}
// %bb.434:                             // %if.then2411
                                        //   in Loop: Header=BB12_368 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.435:                             // %if.then2411
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		p3 = cmp.eq(r18,#0)
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r3 = mux(p3,#120,#16)
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+r3<<#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+r3<<#0) = r1:0
	}
	.falign
.LBB12_436:                             // %do.end2421
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r22 = add(r29,#3224)
		r3 = memw(r29+#532)
		r2 = memw(r16+#20)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#0)
		if (!p2.new) r1 = add(r29,##2456)
		r0 = memw(r29+#560)
	}                                       // 4-byte Folded Reload
	{
		r22 += mpyi(r3,##324)
	}
	{
		if (!p2) r0 = add(r22,#68)
		if (p2) jump:nt .LBB12_438
		memw(r22+#60) = r0
		memw(r22+#64) = r2
	}
// %bb.437:                             // %if.then2430
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		call memcpy
		r2 = memw(r29+#608)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_438:                             // %for.inc2455
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r4 = memw(r29+#376)
		r5 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#284)
		r1:0 = memd(r16+#8)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r26)
		r3 = memw(r4+#8)
		memw(r22+#4) = r5

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		memw(r22+#8) = r24
		memw(r22+#12) = r20
	}
	{
		r3 = memw(r29+#240)
		memw(r22+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r4+#12)
		memw(r22+#20) = r3

	} :mem_noshuf
	{
		r3 = memw(r29+#588)
		memw(r22+#24) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#260)
		memw(r22+#36) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_gu_worker@PCREL)
		r3 = memw(r29+#508)
		memw(r22+#32) = r1
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r16+#16)
		memw(r22+#40) = r0.new
	}
	{
		r3:2 = combine(r24,r22)
		memw(r22+#28) = r3
		memw(r22+#16) = r2
	}
	{
		r0 = memw(r29+#324)
		memw(r22+#44) = r6
	}                                       // 4-byte Folded Reload
	{
		r7 = memw(r29+#488)
		memw(r22+#52) = r6
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#320)
		memw(r22+#48) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		memw(r22+#56) = r6
	}
	.falign
// %bb.439:                             // %for.inc2455
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r18 = r23
		r3 = memw(r29+#420)
		r2 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r20,r3)
		r1 = memw(r29+#1720)
		r0 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r20)
		r2 = add(r1,#1)
		memw(r29+#1720) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = sub(r0,r3)
		if (p0) jump:nt .LBB12_368
		memw(r29+#496) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_353
	}
	.falign
.LBB12_440:                             // %for.body2154.lr.ph
                                        //   in Loop: Header=BB12_368 Depth=2
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r2,#1)
		r3 = add(r20,r3)
	}
	{
		r19 = sub(r3,r24)
		r3 = #1
	}
	{
		r21 = maxu(r2,r3)
	}
	.falign
.LBB12_441:                             // %for.body2154
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_448 Depth 4
                                        //         Child Loop BB12_454 Depth 4
	{
		p0 = cmp.gtu(r24,r22)
	}
	{
		r2 = mux(p0,r20,r19)
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r17 = add(r22,r2)
	}
	.falign
// %bb.442:                             // %for.body2154
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_446
		if (!p3.new) r2 = memw(r29+##256)
	}                                       // 4-byte Folded Reload
// %bb.443:                             // %if.then2166
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#676)
		r4 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r4,r2)
		r3 = memw(r29+#672)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r1 += asl(r17,#9)
		p2 = r2
		r0 = add(r4,r3)
		if (p2.new) jump:nt .LBB12_451
	}
// %bb.444:                             // %if.then2174
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		call lfm2_moe_issue_aligned
		r2 = memw(r29+#312)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.445:                             // %if.then2174
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		jump .LBB12_457
	}
	.falign
.LBB12_446:                             // %for.cond2192.preheader
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		p1 = cmp.gtu(r2,#31)
		r0 = memw(r29+#284)
		if (p1.new) r27 = memw(r29+##676)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) jump:nt .LBB12_457
		r25 = memw(r29+#396)
		if (p1) r23 = memw(r29+##672)
	}                                       // 4-byte Folded Reload
// %bb.447:                             // %for.body2196.lr.ph
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r27 += asl(r17,#9)
		r17 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_448:                             // %for.body2196
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        //       Parent Loop BB12_441 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r23
		r2 = r27
	}
	.falign
// %bb.449:                             // %for.body2196
                                        //   in Loop: Header=BB12_448 Depth=4
	{
		r27 = add(r27,r25)
		r23 = add(r23,#2048)
		p3 = cmp.eq(r0,#0)
		if (!p3.new) jump:nt .LBB12_612
	}
// %bb.450:                             // %for.cond2192
                                        //   in Loop: Header=BB12_448 Depth=4
	{
		r17 = add(r17,#-1)
		r0 = memw(r29+#284)
		if (!cmp.eq(r17.new,#0)) jump:t .LBB12_448
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_457
	}
	.falign
.LBB12_451:                             // %for.cond2177.preheader
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#256)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_457
	}                                       // 4-byte Folded Reload
// %bb.452:                             //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#312)
	}                                       // 4-byte Folded Reload
	{
		r3 = lsr(r2,#1)
		r2 = and(r2,#1)
	}
	{
		loop0(.LBB12_454,r3)
		p2 = cmp.gtu(r3,#0)
		if (!p2.new) jump:t .LBB12_455
	}
	.falign
.LBB12_454:                             //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_368 Depth=2
                                        //       Parent Loop BB12_441 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r6 = #31
		r7 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r6):cm
		weight.n = mxmem(r1,r7)
	}

	//# InlineAsm End
	{
		r3 = add(r0,#2048)
		r5 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r1,r5)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r6):cm
		weight.n = mxmem(r4,r7)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r4,r5)
	} :endloop0
	.falign
.LBB12_455:                             //   in Loop: Header=BB12_441 Depth=3
	{
		r3 = #384
		if (p0.new) r2 = #31
		p0 = cmp.gtu(r2,#0); if (!p0.new) jump:t .LBB12_457
	}
	.falign
.LBB12_456:                             // Block address taken
                                        // %for.body2181
                                        //   in Loop: Header=BB12_441 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r2):cm
		weight.n = mxmem(r1,r3)
	}

	//# InlineAsm End
	.falign
.LBB12_457:                             // %do.body2216
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_460
	}
// %bb.458:                             // %if.then2218
                                        //   in Loop: Header=BB12_441 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.459:                             // %if.then2218
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_460:                             // %do.end2222
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r17 = #0
		r2 = r26
		r3 = memw(r29+#536)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r3,#0)
		r3 = memw(r29+#388)
		if (!p0.new) r1:0 = memd(r29+##1672)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r22,r3)
		if (p0) jump:nt .LBB12_462
		if (!p0) r3 = memw(r29+##284)
	}                                       // 4-byte Folded Reload
// %bb.461:                             // %if.then.i5433
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = add(r3,r2)
		r6 = memw(r29+#536)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_464
		v0 = vmem(r2+#0)
	}
	.falign
.LBB12_462:                             // %if.end.i5436
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#284)
		r1 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.463:                             // %if.end.i5436
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r17 = r0
	}
	.falign
.LBB12_464:                             // %moe_acc_read.exit
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_467
	}
// %bb.465:                             // %if.then2228
                                        //   in Loop: Header=BB12_441 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.466:                             // %if.then2228
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_467:                             // %do.end2234
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r0 = r17
		p3 = cmp.eq(r17,#0)
		if (!p3.new) jump:nt .LBB12_612
	}
// %bb.468:                             // %for.cond2149
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r22 = add(r22,#1)
		if (!cmp.eq(r22.new,r21)) jump:t .LBB12_441
	}
	{
		jump .LBB12_405
	}
	.falign
.LBB12_469:                             // %do.body2511
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_472
	}
// %bb.470:                             // %if.then2513
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.471:                             // %if.then2513
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_472:                             // %do.end2517
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.473:                             // %do.end2517
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_476
	}
// %bb.474:                             // %if.then2520
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.475:                             // %if.then2520
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_476:                             // %do.end2526
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r16 = add(r29,#776)
		r3:2 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		call memset
		r1:0 = combine(r3,r16)
		r2 = #856
	}
	.falign
// %bb.477:                             // %do.end2526
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r1 = memw(r29+#240)
		memw(r29+#1636) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#260)
		memw(r29+#1640) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#488)
		memw(r29+#1632) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#688)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r3)
		r0 = memw(r29+#324)
		memw(r29+#1652) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#4,r16)
		r4 = memw(r29+#580)
		memw(r29+#1644) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r6 = memw(r29+#576)
		memw(r29+#1648) = r6.new
	}                                       // 4-byte Folded Reload
	.falign
// %bb.478:                             // %do.end2526
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		jump .LBB12_499
	}
	.falign
.LBB12_479:                             //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = #0
		memw(r29+#448) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_480:                             // %cond.end2565
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#1656)
		r1 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#412)
		r0 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		r18 = memw(r2+#0)
		if (p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) jump:nt .LBB12_488
		r17 = memw(r1+r3<<#2)
	}
// %bb.481:                             // %do.body2569
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_484
	}
// %bb.482:                             // %if.then2571
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.483:                             // %if.then2571
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_484:                             // %do.end2575
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.485:                             // %do.end2575
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_488
	}
// %bb.486:                             // %if.then2578
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.487:                             // %if.then2578
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_488:                             // %if.end2585
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
	}
	{
		r2 = p3
		if (p3) jump:nt .LBB12_496
		memw(r29+#500) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.489:                             // %do.body2588
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_492
	}
// %bb.490:                             // %if.then2590
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.491:                             // %if.then2590
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_492:                             // %do.end2594
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r3 = memw(r29+#412)
		r2 = memw(r29+#584)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#568)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r2 = #-1
		r3 = memw(r2+r3<<#2)
	}
	{
		r1 += mpyi(r3,#96)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.493:                             // %do.end2594
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_496
	}
// %bb.494:                             // %if.then2603
                                        //   in Loop: Header=BB12_333 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.495:                             // %if.then2603
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_496:                             // %if.end2610
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r4 = add(r29,#2456)
		r16 = memw(r29+#252)
		r2 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r18,#96)
	}
	{
		r3 = and(r2,#1)
		memw(r29+#496) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r18 = togglebit(r3,#0)
		r0 = memw(r16+#20)
		if (cmp.eq(r0.new,#0)) jump:nt .LBB12_498
	}
// %bb.497:                             // %if.then2613
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r6 = memw(r29+#688)
		r5 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r5,r6)
		r6 = memw(r29+#444)
		r3 = memw(r29+#576)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r18,#8)
		r1 = memw(r29+#456)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		r0 += mpyi(r18,r6)
		call hexkl_wh_affine_sums
	}
	.falign
.LBB12_498:                             // %if.end2622
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r23 = #0
		r2 = memw(r29+#264)
		if (cmp.gtu(r2.new,#31)) jump:t .LBB12_506
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_499:                             // %if.end3087
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB12_851
		if (!p2.new) r21 = memw(r29+##384)
	}                                       // 4-byte Folded Reload
// %bb.500:                             // %if.end3090
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r2 = memw(r29+#492)
		if (cmp.eq(r2.new,r21)) jump:t .LBB12_505
	}                                       // 4-byte Folded Reload
// %bb.501:                             // %if.then3094
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r17 = add(r29,#2008)
		r2 = memw(r29+#264)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_505
	}                                       // 4-byte Folded Reload
// %bb.502:                             // %for.body3105.preheader
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r19:18 = combine(#0,#0)
		r2 = memw(r29+#280)
		r3 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r2+r3<<#2)
		r2 = memw(r29+#696)
	}
	{
		r16 += mpyi(r3,#96)
	}
	.falign
.LBB12_503:                             // %for.body3105
                                        //   Parent Loop BB12_333 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r1 = memw(r29+#680)
		memw(r29+#16) = r19
	}
	{
		r20 = memw(r29+#296)
		memw(r29+#12) = r21
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r20,r18)
		r5 = r20
		r0 = memw(r29+#284)
		r4 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r3,r2)
		memw(r29+#4) = r2.new
	}
	{
		r3:2 = memd(r29+#1696)
		memw(r29+#0) = r18
	}                                       // 8-byte Folded Reload
	{
		call moe_push_weight_chunk
		r2 = r3
		r3 = r16
		memw(r29+#8) = #3
	}
	.falign
// %bb.504:                             // %for.body3105
                                        //   in Loop: Header=BB12_503 Depth=2
	{
		r17 = add(r17,#4)
		r19 = add(r19,#1)
		r2 = memw(r29+#696)
		memw(r17+#0) = r0
	}
	{
		r18 = add(r2,r18)
		if (cmp.gtu(r20,r18.new)) jump:t .LBB12_503
	}
	.falign
.LBB12_505:                             // %for.inc3132
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r0 = memw(r29+#460)
		memw(r29+#412) = r21
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		r0 = memw(r29+#340)
		memw(r29+#436) = r0.new
	}                                       // 4-byte Folded Reload
	{
		p0 = not(p0)
		r2 = memw(r29+#248)
		memw(r29+#492) = r21
	}                                       // 4-byte Folded Reload
	{
		r1 = p0
		r2 = add(r2,#1)
		r0 = memw(r29+#240)
		memw(r29+#460) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#1712)
		memw(r29+#248) = r2
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#520) = r1
		memw(r29+#456) = r0
	}                                       // 4-byte Folded Spill
	{
		r1 = memw(r29+#380)
		r0 = memw(r29+#360)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#476) = r1
		memw(r29+#500) = r0
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_333
		r22 = memw(r29+#452)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_506:                             // %for.body2628.lr.ph
                                        //   in Loop: Header=BB12_333 Depth=1
	{
		r19 = #0
		r4 = memw(r29+#444)
		r2 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#412)
		r7 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r1 = mpyi(r18,r4)
		r2 = addasl(r2,r3,#2)
		r22 = memw(r29+#696)
		r6 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		r8 = +mpyi(r4,#1)
		p3 = cmp.eq(r6,#0)
		r0 = memw(r29+#348)
		r5 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		p0 = not(p3)
		p1 = cmp.eq(r0,#0)
		r0 = memw(r29+#476)
		r6 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p1)
		p3 = r6
		p1 = cmp.eq(r0,#0)
		memw(r29+#1656) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		r1 = asl(r7,#2)
		memw(r29+#508) = r1.new
	}                                       // 4-byte Folded Spill
	{
		p0 = and(p0,and(p3,p2))
		p1 = and(p3,!p1)
		r2 = add(r7,#3)
		memw(r29+#612) = r2
	}                                       // 4-byte Folded Spill
	{
		r4 = mpyi(r5,r4)
		r3 = asl(r5,#8)
		r5 = memw(r29+#580)
		memw(r29+#524) = r0
	}                                       // 4-byte Folded Reload
	{
		r1 = p0
		r6 = p1
		memw(r29+#616) = r4
	}                                       // 4-byte Folded Spill
	{
		r4 = asl(r18,#8)
		r6 = add(r5,r3)
		memw(r29+#532) = r1
		memw(r29+#412) = r6
	}                                       // 4-byte Folded Spill
	{
		r2 = lsr(r2,#2)
		r1 = memw(r29+#460)
		memw(r29+#628) = r6
	}                                       // 4-byte Folded Reload
	{
		p1 = r1
		r6 = memw(r29+#576)
		r1:0 = memd(r29+#1672)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r8 = add(r1,#0)
		r1 = add(r5,r4)
		r3 = add(r6,r3)
		r0 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r0,r17,#2)
		r0 = add(r6,r4)
		memw(r29+#588) = r2
		memw(r29+#592) = r1
	}                                       // 4-byte Folded Spill
	{
		r1 = memw(r29+#304)
		memw(r29+#632) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r1,r17,#2)
		r1 = #4
		r0 = memw(r29+#520)
		memw(r29+#600) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r2,r0,#2)
		r4 = maxu(r7,r1)
		memw(r29+#476) = r8
	}                                       // 4-byte Folded Spill
	{
		r0 = addasl(r3,r0,#2)
		memw(r29+#636) = r4
		memw(r29+#608) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#520) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_507:                             // %for.body2628
                                        //   Parent Loop BB12_333 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB12_544 Depth 3
                                        //         Child Loop BB12_551 Depth 4
                                        //         Child Loop BB12_557 Depth 4
	{
		r17 = memw(r29+#704)
		r18 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r1:0 = combine(r17,r18)
	}
	.falign
// %bb.508:                             // %for.body2628
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		p1 = cmp.gtu(r17,r18)
		r1 = add(r29,#2072)
		r17 = r0
		r2 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r20 = addasl(r1,r0,#5)
		p0 = r2
	}
	{
		p3 = or(p0,p1)
		if (p3.new) jump:t .LBB12_516
		if (!p3.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.509:                             // %do.body2647
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_512
	}
// %bb.510:                             // %if.then2649
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.511:                             // %if.then2649
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_512:                             // %do.end2653
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		call hvx_worker_pool_wait_bg
		r1 = r20
		r2 = #-1
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.513:                             // %do.end2653
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_516
	}
// %bb.514:                             // %if.then2657
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.515:                             // %if.then2657
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	.falign
.LBB12_516:                             // %if.end2664
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r24 = add(r29,#1752)
		r21 = add(r19,#8)
		r2 = memw(r29+#296)
		r26 = memw(r29+#700)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r23)
		r0 = memw(r29+#412)
	}                                       // 4-byte Folded Reload
	{
		r18 = minu(r2,r22)
		p3 = r0
		if (!p3.new) jump:t .LBB12_526
		if (p3.new) r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.517:                             // %land.lhs.true2675
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r24+r21<<#2)
	}
	{
		p1 = cmp.eq(r2,#0)
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		if (p1) jump:nt .LBB12_528
		r2 = memw(r3+#0)
	}
// %bb.518:                             // %do.body2680
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		p3 = cmp.eq(r2,#0)
		if (p3.new) jump:nt .LBB12_521
	}
// %bb.519:                             // %if.then2682
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.520:                             // %if.then2682
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_521:                             // %do.end2686
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r3 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r21,#5)
		call hvx_worker_pool_wait_bg
	}
	.falign
// %bb.522:                             // %do.end2686
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_525
	}
// %bb.523:                             // %if.then2691
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.524:                             // %if.then2691
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_525:                             // %do.end2697
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = addasl(r24,r21,#2)
	}
	{
		jump .LBB12_539
		memw(r2+#0) = #0
	}
	.falign
.LBB12_526:                             // %if.else2700
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#524)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB12_539
		if (!p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.527:                             // %if.else2700.do.body2704_crit_edge
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB12_528:                             // %do.body2704
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r0 = add(r29,#2008)
		p0 = cmp.eq(r2,#0)
	}
	{
		r21 = addasl(r0,r19,#2)
		if (p0) jump:nt .LBB12_532
	}
// %bb.529:                             // %do.end2710
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.530:                             // %do.end2710
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#1704) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_532
	}
// %bb.531:                             // %if.then2712
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r3 = #2
		r2 = memw(r21+#0)
	}
	.falign
.LBB12_532:                             // %if.end2715
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		call hexkl_dma_ring_wait
		r0 = memw(r21+#0)
	}
	.falign
// %bb.533:                             // %if.end2715
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_538
	}
// %bb.534:                             // %do.body2721
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_end
	}
	.falign
// %bb.535:                             // %do.body2721
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_538
	}
// %bb.536:                             // %if.then2723
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.537:                             // %if.then2723
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#88)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#88) = r1:0
	}
	.falign
.LBB12_538:                             // %do.end2729
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r1 = memw(r29+#680)
		memw(r29+#4) = r18
	}
	{
		r2 = memw(r29+#324)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = memd(r29+#1696)
		memw(r29+#0) = r23
	}                                       // 8-byte Folded Reload
	{
		r2 = r3
		r3 = r16
		r4 = memw(r29+#300)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_expand_chunk
		r5 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_539:                             // %do.body2733
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_542
	}
// %bb.540:                             // %if.then2735
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r1:0 = memd(r2+#0)
		r3:2 = memd(r2+#16)
	}
	{
		memd(r29+#1728) = r1:0
		memd(r29+#1736) = r3:2
	}                                       // 8-byte Folded Spill
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.541:                             // %if.then2735
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memd(r29+#1744) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_542:                             // %do.end2739
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r21 = asl(r23,#9)
		p1 = cmp.eq(r18,#0)
		r2 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r22,r2)
	}
	{
		r26 += mpyi(r2,r17)
		r22 = #0
		if (p1) jump:nt .LBB12_572
	}
	.falign
.LBB12_544:                             // %for.body2745
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_507 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB12_551 Depth 4
                                        //         Child Loop BB12_557 Depth 4
	{
		call hexkl_micro_hmx_acc_clear_int32
	}
	.falign
// %bb.545:                             // %for.body2745
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) r3 = add(r22,r23)
		if (!p2.new) jump:t .LBB12_549
	}
// %bb.546:                             // %if.then2747
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#680)
		r4 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r4,r2)
		r0 = memw(r29+#688)
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r4,r2)
		r1 += asl(r3,#9)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_554
		if (!p0.new) r2 = memw(r29+##300)
	}                                       // 4-byte Folded Reload
// %bb.547:                             // %if.then2760
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		call lfm2_moe_issue_aligned
		r3 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.548:                             // %if.then2760
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		jump .LBB12_560
	}
	.falign
.LBB12_549:                             // %for.cond2779.preheader
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#260)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.gtu(r2,#31)
		if (!p2.new) jump:t .LBB12_560
		if (p2.new) r3 = memw(r29+##680)
	}
// %bb.550:                             // %for.body2783.lr.ph
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r24 = add(r3,r21)
		r2 = memw(r29+#688)
		r4 = memw(r29+#476)
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r4,r2)
		r25 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_551:                             // %for.body2783
                                        //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_507 Depth=2
                                        //       Parent Loop BB12_544 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		call hexkl_micro_hmx_mm_u8i4
		r1 = r27
		r2 = r24
	}
	.falign
// %bb.552:                             // %for.body2783
                                        //   in Loop: Header=BB12_551 Depth=4
	{
		r27 = add(r27,#2048)
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB12_648
	}
// %bb.553:                             // %for.cond2779
                                        //   in Loop: Header=BB12_551 Depth=4
	{
		r2 = memw(r29+#432)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r24 = add(r24,r2)
		r25 = add(r25,#-1)
		if (!cmp.eq(r25.new,#0)) jump:t .LBB12_551
	}
	{
		jump .LBB12_560
	}
	.falign
.LBB12_554:                             // %for.cond2764.preheader
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#260)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_560
	}                                       // 4-byte Folded Reload
// %bb.555:                             //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r3 = lsr(r2,#1)
		r2 = and(r2,#1)
	}
	{
		loop0(.LBB12_557,r3)
		p1 = cmp.gtu(r3,#0); if (!p1.new) jump:t .LBB12_558
	}
	.falign
.LBB12_557:                             //   Parent Loop BB12_333 Depth=1
                                        //     Parent Loop BB12_507 Depth=2
                                        //       Parent Loop BB12_544 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r6 = #31
		r7 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r6):cm
		weight.n = mxmem(r1,r7)
	}

	//# InlineAsm End
	{
		r3 = add(r0,#2048)
		r5 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r1,r5)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r6):cm
		weight.n = mxmem(r4,r7)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r4,r5)
	} :endloop0
	.falign
.LBB12_558:                             //   in Loop: Header=BB12_544 Depth=3
	{
		r3 = #384
		p3 = cmp.gtu(r2,#0)
		if (p3.new) r2 = #31
		if (!p3.new) jump:t .LBB12_560
	}
	.falign
.LBB12_559:                             // Block address taken
                                        // %for.body2768
                                        //   in Loop: Header=BB12_544 Depth=3
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r2):cm
		weight.n = mxmem(r1,r3)
	}

	//# InlineAsm End
	.falign
.LBB12_560:                             // %do.body2806
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_563
	}
// %bb.561:                             // %if.then2808
                                        //   in Loop: Header=BB12_544 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.562:                             // %if.then2808
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_563:                             // %do.end2812
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r24 = #0
		r2 = r26
		r3 = memw(r29+#392)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r3,#0)
		r3 = memw(r29+#388)
		if (!p3.new) r6 = memw(r29+##392)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r22,r3)
		if (p3) jump:nt .LBB12_565
		if (!p3) r3 = memw(r29+##284)
	}                                       // 4-byte Folded Reload
// %bb.564:                             // %if.then.i5462
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = add(r3,r2)
		r1:0 = memd(r29+#1672)
	}                                       // 8-byte Folded Reload
	{
		r3 = add(r2,#2048)
		r4 = add(r2,#4096)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r6)
	}

	{
		mxmem(r2,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r5 = add(r6,#1024)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r5)
	}

	{
		mxmem(r3,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r3 = add(r6,#2048)
	}
	//# InlineAsm Start
	{
		bias = mxmem(r3)
	}

	{
		mxmem(r4,r1):after:retain:cm.ub = acc
	}

	//# InlineAsm End
	{
		r2 = add(r2,#6016)
	}
	{
		jump .LBB12_567
		v1 = vmem(r2+#0)
	}
	.falign
.LBB12_565:                             // %if.end.i5470
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		call hexkl_micro_hmx_acc_read_int32
		r0 = memw(r29+#284)
		r1 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.566:                             // %if.end.i5470
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r24 = r0
	}
	.falign
.LBB12_567:                             // %moe_acc_read.exit5472
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_570
	}
// %bb.568:                             // %if.then2818
                                        //   in Loop: Header=BB12_544 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.569:                             // %if.then2818
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB12_570:                             // %do.end2824
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r21 = add(r21,#512)
		r0 = r24
		p0 = cmp.eq(r24,#0)
		if (!p0.new) jump:nt .LBB12_648
	}
// %bb.571:                             // %for.cond2741
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r22 = add(r22,#1)
		if (!cmp.eq(r22.new,r18)) jump:t .LBB12_544
	}
	.falign
.LBB12_572:                             // %do.body2834
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_575
	}
// %bb.573:                             // %if.then2836
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.574:                             // %if.then2836
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1728)
	}                                       // 8-byte Folded Reload
	{
		r7:6 = memd(r29+#1736)
		r13:12 = memd(r29+#1744)
	}                                       // 8-byte Folded Reload
	{
		r5:4 = add(r5:4,r7:6)
		r7:6 = memd(r2+#0)
		r9:8 = memd(r2+#16)
	}
	{
		r7:6 = add(r13:12,r7:6)
		r1:0 = add(r5:4,r1:0)
	}
	{
		r5:4 = add(r7:6,r9:8)
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_sample
	}
	.falign
.LBB12_575:                             // %do.end2847
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#528)
		r0 = memw(r29+#532)
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		p3 = cmp.gtu(r2,r19)
	}
	{
		p2 = and(p2,p3)
		if (!p2.new) jump:t .LBB12_585
		if (p2.new) r0 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.576:                             // %if.then2857
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#276)
		r3 = memw(r29+#352)
	}                                       // 4-byte Folded Reload
	{
		r21 = memw(r2+r3<<#2)
	}
	{
		r2 = memw(r0+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_579
	}
// %bb.577:                             // %if.then2875
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.578:                             // %if.then2875
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_579:                             // %do.end2879
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = add(r29,#1816)
	}
	{
		call hexkl_dma_ring_wait
		r0 = memw(r2+r19<<#2)
	}
	.falign
// %bb.580:                             // %do.end2879
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_583
	}
// %bb.581:                             // %if.then2883
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.582:                             // %if.then2883
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB12_583:                             // %do.end2889
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = add(r29,#5632)
		r4 = add(r29,#2712)
		r6 = memw(r29+#316)
		memw(r29+#12) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r4,r19,#5)
		r7 = add(r29,#2328)
		r6 = memw(r29+#252)
		r12 = memw(r29+#420)
	}                                       // 4-byte Folded Reload
	{
		r6 += mpyi(r21,#96)
		r2 += mpyi(r19,#192)
		r8 = memw(r29+#312)
		r5 = memw(r29+#676)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r19,r12)
		r9 = memw(r29+#408)
		memw(r29+#16) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r7,r19,#3)
		r14 = add(r3,r9)
		r15 = sub(r9,r3)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r6 = minu(r15,r12)
		r4 = memw(r29+#284)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		r13 = memw(r29+#364)
		memw(r29+#8) = r8
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#0) = r13
		memw(r29+#20) = r14
	}
	{
		call moe_expand_submit
		memw(r29+#24) = r6
	}
	.falign
// %bb.584:                             // %do.end2889
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = add(r29,#1752)
		r3 = #1
	}
	{
		memw(r2+r19<<#2) = r3
	}
	.falign
.LBB12_585:                             // %if.end2897
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r25 = add(r29,#8704)
		r1 = #880
		p1 = cmp.eq(r19,#0)
		r0 = memw(r29+#400)
	}                                       // 4-byte Folded Reload
	{
		r25 += mpyi(r17,r1)
		p0 = r0
	}
	{
		r2 = p1
		if (p0) jump:nt .LBB12_596
		memw(r29+#512) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.586:                             // %if.end2897
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB12_596
		if (p0.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.587:                             // %do.body2903
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_590
	}
// %bb.588:                             // %if.then2905
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.589:                             // %if.then2905
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_590:                             // %do.end2909
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.591:                             // %do.end2909
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_594
	}
// %bb.592:                             // %if.then2912
                                        //   in Loop: Header=BB12_507 Depth=2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.593:                             // %if.then2912
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r5:4 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB12_594:                             // %do.end2918
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = add(r29,#3872)
		r4 = memw(r29+#688)
		r3 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r3 = memw(r29+#488)
		r6 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r6,r3)
		r3 = #880
		r6 = memw(r29+#496)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r6,r3)
		r3 = memw(r29+#284)
		r6 = memw(r29+#616)
	}                                       // 4-byte Folded Reload
	{
		r4 += add(r3,r6)
		r5 = mux(p0,r25,r2)
		r3 = memw(r29+#260)
		r6 = memw(r29+#628)
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r6,r3)
		r3 = memw(r29+#632)
		memd(r5+#856) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r9:8 = combine(r4,r3)
		if (!p0) r3 = #4
		memd(r5+#864) = r7:6
		memw(r5+#12) = #0
	}
	{
		if (p0) jump:nt .LBB12_596
		memd(r5+#872) = r9:8
	}
// %bb.595:                             // %if.then2947
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r1 = add(pc,##moe_dn_worker@PCREL)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
	}
	.falign
.LBB12_596:                             // %if.end2949
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r21 = add(r29,#8704)
		r3 = #880
		r2 = memw(r16+#20)
		r0 = memw(r29+#596)
	}                                       // 4-byte Folded Reload
	{
		r21 += mpyi(r17,r3)
		r1:0 = combine(r2,r0)
		p0 = cmp.eq(r2,#0)
	}
	{
		if (!p0) r1 = add(r29,##2456)
		if (p0) jump:nt .LBB12_598
		memd(r21+#544) = r1:0
	}
// %bb.597:                             // %if.then2958
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		call memcpy
		r0 = add(r21,#552)
		r2 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_598:                             // %if.end2964
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r1:0 = combine(r18,r23)
		r22 = add(r21,#32)
		r4 = memw(r29+#376)
		r5 = memw(r29+#388)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r26)
		r3 = memw(r4+#8)
		memd(r21+#8) = r1:0

	} :mem_noshuf
	{
		r2 = addasl(r2,r3,#2)
		memw(r21+#4) = r5
	}
	{
		memw(r25+#0) = r2
		r2 = memw(r4+#12)

	} :mem_noshuf
	{
		r0 = memw(r29+#456)
		r18 = memw(r29+#508)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = combine(r0,r2)
		r0 = r22
		r2 = r18
		r1 = memw(r29+#592)
	}                                       // 4-byte Folded Reload
	{
		call memcpy
		memd(r21+#16) = r5:4
	}
	.falign
// %bb.599:                             // %if.end2964
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r24 = add(r21,#288)
		r2 = r18
		r1 = memw(r29+#600)
	}                                       // 4-byte Folded Reload
	{
		call memcpy
		r0 = r24
	}
	.falign
// %bb.600:                             // %if.end2964
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r3:2 = combine(r24,r22)
		r1:0 = memd(r16+#8)
		r22 = memw(r29+#696)
	}
	{
		r3:2 = combine(r0,r1)
		r1:0 = combine(r22,r23)
		r4 = memw(r16+#16)
		memd(r21+#24) = r3:2
	}
	{
		r2 = memw(r29+#544)
		memd(r21+#808) = r3:2
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		memw(r21+#816) = r4
		memw(r21+#820) = r2
	}
	.falign
// %bb.601:                             // %if.end2964
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#548)
		r5:4 = memd(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#608)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r0,r4)
	}
	{
		r1:0 = combine(r3,r2)
		r2 = memw(r29+#264)
		r3 = memw(r29+#520)
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(r2,r3)
		r0 = memw(r29+#500)
		memd(r21+#824) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (p0.new) jump:nt .LBB12_603
		memd(r21+#832) = r3:2
	}
// %bb.602:                             // %if.then3007
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r2 = memw(r29+#612)
		r3 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#436)
		r7 = memw(r29+#448)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		r5 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r2,#2)
		r4 = memw(r3+r4<<#2)
		r6 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r6,r2,#2)
		r3 = memw(r7+#28)
	}
	{
		r6 = sub(r4,r3)
		r4 = memw(r7+#24)
	}
	{
		r5 = addasl(r5,r6,#2)
		r6 = addasl(r2,r6,#2)
		jump .LBB12_604
	}
	.falign
.LBB12_603:                             //   in Loop: Header=BB12_507 Depth=2
	{
		r5:4 = combine(#0,#0)
		r3 = #0
		r6 = #0
	}
	.falign
.LBB12_604:                             // %if.end3027
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r1:0 = combine(r5,r4)
		r5:4 = combine(r3,r6)
		r3 = add(r29,#2072)
		r7 = memw(r29+#512)
	}                                       // 4-byte Folded Reload
	{
		p3 = r7
		r0 = add(r29,#2200)
		r2 = memw(r29+#488)
		memd(r21+#840) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_dn_unit@PCREL)
		r6 = addasl(r0,r17,#5)
		r0 = memw(r29+#564)
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r17,#5)
		p1 = r0
		if (!p3) r2 = #0
		r7 = memw(r29+#588)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = combine(r6,r7)
		if (!p1) r2 = #0
		r6 = memw(r29+#400)
		memw(r20+#0) = r1
	}                                       // 4-byte Folded Reload
	{
		r4 = setbit(r3,#2)
		p3 = r6
		memd(r21+#848) = r5:4
		memd(r3+#8) = r1:0
	}
	{
		if (p3) r2 = #0
		r3 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		if (!p2.new) r1 = add(r20,#0)
		memw(r21+#856) = r2
		memw(r4+#0) = r25
	}
	{
		if (!p2) jump:nt .LBB12_607
		if (!p2) r0 = memw(r29+##324)
	}                                       // 4-byte Folded Reload
// %bb.605:                             // %if.then3051
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r1 = add(pc,##moe_dn_fg_worker@PCREL)
		p0 = cmp.eq(r2,#0)
		r2 = memw(r29+#456)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#636)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r3 = mux(p0,r2,r4)
		r2 = r20
	}
	.falign
// %bb.606:                             // %if.then3051
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		jump .LBB12_609
	}
	.falign
.LBB12_607:                             // %if.else3063
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		call hvx_worker_pool_submit_bg
	}
	.falign
// %bb.608:                             // %if.else3063
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		memw(r29+#484) = r20
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_609:                             // %for.inc3071
                                        //   in Loop: Header=BB12_507 Depth=2
	{
		r23 = add(r22,r23)
		r19 = add(r19,#1)
		r2 = memw(r29+#296)
		r0 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,#1)
		p1 = cmp.gtu(r2,r23); if (p1.new) jump:t .LBB12_507
		memw(r29+#516) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB12_499
	}
	.falign
.LBB12_610:
	{
		r17 = ##-2147449856
		jump .LBB12_208
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_611:
	{
		r17 = ##-2147449856
		jump .LBB12_208
		r3 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_612:                             // %cleanup2501
	{
		jump .LBB12_649
		memw(r29+#340) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_613:                             // %if.else1047
	{
		r2 = memw(r29+#372)
		memd(r29+#1720) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB12_294
		if (p2.new) r22 = memw(r29+##292)
	}                                       // 4-byte Folded Reload
// %bb.614:                             // %for.cond1051.preheader
	{
		r2 = #2
		r19 = add(r29,#1880)
		r3 = memw(r29+#1680)
		r26 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r25 = minu(r3,r2)
		r24 = #0
		r27 = memw(r29+#312)
		r16 = memw(r29+#276)
	}                                       // 4-byte Folded Reload
	{
		r20 = memw(r29+#316)
		memd(r29+#1720) = r1:0
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_615:                             // %for.body1060
                                        // =>This Inner Loop Header: Depth=1
	{
		p0 = tstbit(r24,#0)
		r3 = r27
		r5:4 = combine(#1,r20)
		r2 = memw(r22+#0)
	}
	{
		r22 = add(r22,#4)
		r1 = mux(p0,r26,#0)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r16+r2<<#2)
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#0) = r24
	}
	{
		r2 += mpyi(r6,#96)
		call moe_m1_push
	}
	.falign
// %bb.616:                             // %for.body1060
                                        //   in Loop: Header=BB12_615 Depth=1
	{
		r25 = add(r25,#-1)
		r24 = add(r24,#1)
		r19 = add(r19,#4)
		memw(r19+#0) = r0
	}
	{
		p0 = cmp.eq(r25,#0)
		if (!p0.new) jump:t .LBB12_615
	}
	{
		jump .LBB12_294
	}
	.falign
.LBB12_617:                             // %if.else1242.peel
	{
		r2 = memw(r29+#440)
		r0 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#528)
		r6 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r16 = memw(r2+#0)
		r2 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r3,r16,#2)
		r3 = memw(r29+#272)
		r19 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r2 = #0
		r17 = memw(r2+#0)
		r5 = memw(r29+#336)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r16,#2)
		r4 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r6,r16,#2)
		r3 = memw(r3+r17<<#2)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		r19 += mpyi(r16,r4)
		call hvx_quant_pack_u8_ah_rows
		memw(r29+#4) = r19.new
	}
	.falign
.LBB12_618:                             // %if.end1252.peel
	{
		r2 = memw(r29+#328)
		memw(r29+##8704) = r19
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r2,#8236)
		r2 = memw(r29+#276)
		memw(r29+#1672) = r6.new
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#252)
		r6 = memw(r6+#0)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r6,#0)
		r2 = r4
		r5 = memw(r29+#280)
		r3 = memw(r2+r17<<#2)
	}                                       // 4-byte Folded Reload
	{
		r2 += mpyi(r3,#96)
		r5 = memw(r5+r17<<#2)
		memw(r29+##8708) = r2.new
	}
	{
		r4 += mpyi(r5,#96)
		if (p3) jump:nt .LBB12_622
		memw(r29+##8712) = r4.new
	}
// %bb.619:                             // %land.lhs.true1264.peel
	{
		r0 = add(r2,#88)
		r3 = memw(r2+#44)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB12_622
	}
// %bb.620:                             // %if.then1268.peel
	{
		r18 = add(r29,#8704)
	}
	{
		call hvx_expand_i2i4_table
		r1 = add(r18,#128)
	}
	.falign
// %bb.621:                             // %if.then1268.peel
	{
		r1 = add(r18,#256)
		r2 = memw(r29+##8712)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
.LBB12_622:                             // %if.end1277.peel
	{
		r3 = memw(r29+#372)
		r5 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		r4 = r5
		r6 = memw(r29+#272)
		r7 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+##8708)
		if (!p1) r3 = memw(r29+##8712)
	}
	{
		r1 = memw(r6+r17<<#2)
		r6 = memw(r29+#344)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r16,#2)
		if (!p1) r5 = memw(r3+#4)
		r3 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		r12 = memw(r29+#616)
		r8 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r12,r3)
		if (!p1) r4 = memw(r2+#4)
		memw(r29+##8724) = r6

	} :mem_noshuf
	{
		r7 = add(r3,r7)
		r6 = memw(r29+#512)
		memw(r29+##8740) = r7.new
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r7,r6)
		r7 = memw(r29+#1664)
		memw(r29+##8736) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 = add(r6,r8)
		r3 = memw(r29+#336)
		memw(r29+##8744) = r6
	}                                       // 4-byte Folded Reload
	{
		r3 = addasl(r3,r16,#2)
		r7 = memw(r7+#0)
		memw(r29+##9092) = r1
	}
	{
		r15:14 = memd(r29+#1712)
		memw(r29+##8728) = r3
	}                                       // 8-byte Folded Reload
	{
		r7 = add(r7,r14)
		memw(r29+##8732) = r12
	}
	{
		r7 = add(r6,#256)
		memw(r29+##9088) = r7
	}
	{
		memw(r29+##8748) = r6
		memw(r29+##8752) = r7
	}
	{
		r6 = add(r7,#256)
		r4 = add(r29,#8760)
		memw(r29+##8716) = r4
	}
	{
		memw(r29+##8756) = r6
		memw(r29+##8720) = r5
	}
	{
		r2 = memw(r2+#20)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB12_624
		if (!p0.new) r0 = memw(r29+##8704)
	}
// %bb.623:                             // %if.then1323.peel
	{
		call hexkl_wh_affine_sums
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_624:                             // %if.end1328.peel
	{
		r2 = memw(r29+#1680)
		r28 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r2,#1)
		r2 = memw(r29+#252)
		r24 = memw(r29+#612)
	}                                       // 4-byte Folded Reload
	{
		r3 = p0
		if (p0) jump:nt .LBB12_641
		memw(r29+#348) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.625:                             // %for.body1223.preheader
	{
		r9 = add(r29,#8704)
		r11 = add(r24,#512)
		r10 = memw(r29+#512)
		r3 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r3,#22,#0)
		r4 = extractu(r10,#24,#7)
		r7 = memw(r29+#484)
		r1:0 = memd(r29+#1712)
	}                                       // 4-byte Folded Reload
	{
		r3 = asl(r3,#10)
		r7 = lsr(r7,#7)
		r22 = add(r28,r0)
		r14 = memw(r29+#444)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r14,r14)
		r6 = r10
		r0 = memw(r29+#412)
		r8 = memw(r29+#516)
	}                                       // 4-byte Folded Reload
	{
		r0 += mpyi(r7,r23)
		r7 = add(r5,r3)
		r12 = memw(r29+#248)
		r15 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	{
		r10 += add(r5,r15)
		r12 = asl(r12,#12)
		r13 = add(r7,r10)
		r8 = add(r14,r8)
	}
	{
		r6 += add(r8,r15)
		r4 = asl(r4,#8)
		r23 = add(r9,#900)
		r5 = memw(r29+#580)
	}                                       // 4-byte Folded Reload
	{
		r3 += add(r12,r14)
		r20 = add(r5,add(r0,##1028))
		r5 = memw(r29+#436)
	}                                       // 4-byte Folded Reload
	{
		r21 = add(r6,add(r5,##512))
		r7 = add(r7,r4)
		r5 = memw(r29+#480)
	}                                       // 4-byte Folded Reload
	{
		r24 += add(r3,r4)
		r18 = #1
		r26 = add(r6,r11)
		r5 = add(r20,r5)
	}
	{
		r19 = add(r13,r11)
		r27 = add(r7,r11)
		r16 = add(r10,r11)
		memw(r29+#396) = r28
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#292) = r21
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_626:                             // %for.body1223
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = memw(r20+#0)
		memw(r29+#1656) = r5
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#344)
		r17 = memw(r5+#0)
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r3,r6,#2)
		r3 = memw(r29+#336)
		r25 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r8 = addasl(r3,r6,#2)
		r3 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		r9 = addasl(r3,r17,#2)
		r3 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
	{
		p2 = r3
		if (p2.new) jump:t .LBB12_629
		if (!p2.new) r25 = memw(r29+##416)
	}                                       // 4-byte Folded Reload
// %bb.627:                             // %if.else1242
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r26 = r19
		r19 = r8
		r2 = memw(r29+#528)
		memw(r29+#248) = r26
	}                                       // 4-byte Folded Reload
	{
		r21:20 = combine(r16,r5)
		r16 = r27
		r4 = memw(r29+#256)
		memw(r29+#268) = r20
	}                                       // 4-byte Folded Reload
	{
		r1 = addasl(r2,r6,#2)
		r2 = #0
		r3 = memw(r9+#0)
		r0 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r22 = r24
		r24 = r28
		memw(r29+#1688) = r22
		memw(r29+#0) = r8
	}                                       // 4-byte Folded Spill
	{
		r25 += mpyi(r6,r4)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r27 = r9
		memw(r29+#4) = r25
	}
	.falign
// %bb.628:                             // %if.else1242
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r28 = r24
		r24 = r22
		r9:8 = combine(r27,r19)
		r22 = memw(r29+#1688)
	}                                       // 4-byte Folded Reload
	{
		r19 = r26
		r5 = r20
		r27 = r16
		r26 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r16 = r21
		r20 = memw(r29+#268)
		r21 = memw(r29+#292)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_629:                             // %if.end1252
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r6 = r2
		r3 = memw(r29+#276)
		memw(r23+#-388) = r25
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r3+r17<<#2)
		r3 = memw(r29+#280)
	}                                       // 4-byte Folded Reload
	{
		r3 = r2
		r7 = memw(r3+r17<<#2)
	}
	{
		r3 += mpyi(r4,#96)
		r4 = memw(r29+#1672)
		memw(r23+#-384) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r6 += mpyi(r7,#96)
		memw(r23+#-380) = r6.new
	}
	{
		r4 = memw(r4+#0)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_634
	}
// %bb.630:                             // %land.lhs.true1264
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r1 = add(r23,#-260)
		r0 = add(r3,#88)
		r4 = memw(r3+#44)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB12_634
	}
// %bb.631:                             // %if.then1268
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r17 = r9
		r25 = r5
		memw(r29+#248) = r8
	}                                       // 4-byte Folded Spill
	{
		call hvx_expand_i2i4_table
	}
	.falign
// %bb.632:                             // %if.then1268
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r1 = add(r23,#-132)
		r2 = memw(r23+#-380)
	}
	{
		call hvx_expand_i2i4_table
		r0 = add(r2,#88)
	}
	.falign
// %bb.633:                             // %if.then1268
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r5 = r25
		r9 = r17
		r8 = memw(r29+#248)
		r28 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_634:                             // %if.end1277
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r3 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		if (!p3.new) jump:t .LBB12_636
		if (!p3.new) r3 = memw(r23+##-384)
	}
// %bb.635:                             // %cond.true1287
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		p2 = tstbit(r18,#0)
		r3 = asl(r18,#30)
		r4 = memw(r29+#384)
		r7 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r6 = r4
		r12 = mux(p2,r4,#0)
		r4 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		if (!p2) r4 = #0
		r12 = add(r7,r12)
		r3 = memw(r23+#-384)
	}
	{
		r4 += add(r7,r6)
		jump .LBB12_637
	}
	.falign
.LBB12_636:                             // %cond.false1290
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r4 = memw(r23+#-380)
		r12 = memw(r3+#4)
	}
	{
		r4 = memw(r4+#4)
	}
	.falign
.LBB12_637:                             // %cond.end1293
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r7 = memw(r29+#436)
		memw(r23+#-376) = r12
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r26,r7)
		r6 = add(r16,r7)
		r12 = add(r24,r7)
		memw(r23+#-372) = r4
	}
	{
		r6 = add(r19,r7)
		r4 = add(r27,r7)
		memw(r23+#-356) = r6
		memw(r23+#-360) = r4
	}
	{
		r7 = add(r12,#512)
		memw(r23+#-352) = r6
		memw(r23+#-368) = r5
	}
	{
		r6 = add(r7,#256)
		memw(r23+#-340) = r6.new
	}
	{
		r7 = add(r7,#512)
		r6 = memw(r29+#1664)
		memw(r23+#-344) = r7
	}                                       // 4-byte Folded Reload
	{
		memw(r23+#-364) = r8
		memw(r23+#-348) = r4
	}
	{
		memw(r23+#-336) = r7
		r4 = memw(r6+#0)

	} :mem_noshuf
	{
		r4 = add(r4,r22)
		r1 = memw(r9+#0)
		memw(r23+#0) = r1.new
	}
	{
		memw(r23+#-4) = r4
	}
	{
		r4 = add(r23,#-332)
		r3 = memw(r3+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB12_640
	}
// %bb.638:                             // %if.then1323
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r3 = r8
		r17 = r28
		r0 = memw(r23+#-388)
		r2 = memw(r29+#256)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_sums
	}
	.falign
// %bb.639:                             // %if.then1323
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r28 = r17
		r2 = memw(r29+#252)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_640:                             // %if.end1328
                                        //   in Loop: Header=BB12_626 Depth=1
	{
		r18 = add(r18,#1)
		r22 = add(r22,r28)
		r20 = add(r20,#4)
		r5 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r5,#4)
		r23 = add(r23,#512)
		r26 = add(r26,r21)
		r24 = add(r24,r21)
	}
	{
		r27 = add(r27,r21)
		r19 = add(r19,r21)
		r16 = add(r16,r21)
	}
	{
		r3 = memw(r29+#1680)
		if (!cmp.eq(r3.new,r18)) jump:t .LBB12_626
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_641:                             // %for.cond.cleanup1222
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_644
	}
// %bb.642:                             // %if.then1335
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.643:                             // %if.then1335
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB12_644:                             // %do.end1341
	{
		r2 = memw(r29+#460)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r18 = #0
		if (p1.new) jump:nt .LBB12_668
		if (!p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.645:                             // %if.then1343
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_662
	}
// %bb.646:                             // %if.then1347
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.647:                             // %if.then1347
	{
		r17:16 = combine(r1,r0)
		jump .LBB12_663
	}
	.falign
.LBB12_648:                             // %cleanup3075
	{
		memw(r29+#340) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_649:                             // %out3230
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.650:                             // %out3230
	{
		r2 = memw(r29+#484)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_809
	}                                       // 4-byte Folded Reload
// %bb.651:                             // %if.then3232
	{
		call hvx_worker_pool_wait_bg
		r2 = #-1
		r0 = memw(r29+#324)
		r1 = memw(r29+#484)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.652:                             // %if.then3232
	{
		jump .LBB12_809
	}
	.falign
.LBB12_653:
	{
		r16 = memw(r29+#236)
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_174
	}
	.falign
.LBB12_655:
	{
		r27 = r19
		jump .LBB12_235
	}
	.falign
.LBB12_656:                             // %if.then1019
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_submit
		r4 = #0
		memw(r29+#768) = r4.new
	}
	.falign
// %bb.657:                             // %if.then1019
	{
		r1 = #1
	}
	{
		jump .LBB12_294
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_658:                             // %if.then1231.peel
	{
		r3 = ##-1431655765
		r1 = memw(r29+#256)
		r4 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,#23)
		r19 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyu(r2,r3)
		r0 = r19
		r2 = #0
		r4 = memw(r4+#0)
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
// %bb.659:                             // %if.then1231.peel
	{
		r2 = memw(r29+#360)
		r3 = memw(r29+#368)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,r3)
		r2 = memw(r29+#292)
		if (!p1.new) r3 = memw(r29+##336)
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r2+#0)
		r2 = memw(r29+#440)
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB12_618
		r16 = memw(r2+#0)
		if (!p1) r2 = memw(r29+##344)
	}                                       // 4-byte Folded Reload
// %bb.660:                             // %if.then1237.peel
	{
		r1 = memw(r29+#256)
		r0 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+r16<<#2)
		r3 = memw(r3+r16<<#2)
	}
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		r4 = memw(r29+#416)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.661:                             // %if.then1237.peel
	{
		jump .LBB12_618
	}
	.falign
.LBB12_662:
	{
		r17:16 = combine(#0,#0)
	}
	.falign
.LBB12_663:                             // %do.end1351
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.664:                             // %do.end1351
	{
		r2 = memw(r29+#244)
		memw(r29+#752) = r18
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_668
	}
// %bb.665:                             // %do.body1361
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.666:                             // %do.body1361
	{
		r1:0 = sub(r1:0,r17:16)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_668
	}
// %bb.667:                             // %if.then1363
	{
		r1 = #0
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#80)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_668:                             // %if.end1370
	{
		r7 = memw(r29+#236)
		r5 = memw(r29+#320)
	}                                       // 4-byte Folded Reload
	{
		p1 = !tstbit(r7,#7)
		r2 = r7
		r12 = memw(r29+#332)
		r4 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r3 = extractu(r7,#1,#16)
		p3 = !tstbit(r7,#6)
		r0 = memw(r29+#300)
		r6 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	{
		p2 = r4
		r1:0 = combine(r0,r6)
		r5 = memw(r29+#312)
		memw(r12+#72) = r5
	}                                       // 4-byte Folded Reload
	{
		r2 = and(##16320,lsr(r2,#2))
		r4 = mux(p2,#1,#0)
		r6 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		if (p1) r2 = #192
		r7:6 = combine(r5,r6)
		r5 = memw(r29+#316)
		memd(r12+#8) = r1:0
	}                                       // 4-byte Folded Reload
	{
		r1 = #0
		if (p3) r3 = #1
		r8 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r2 = add(r1,#0)
		r9:8 = combine(r5,r8)
		r5 = memw(r29+#264)
		memd(r12+#0) = r7:6
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#296)
		memd(r12+#32) = r3:2
	}                                       // 4-byte Folded Reload
	{
		r7:6 = combine(r5,r6)
		r2 = memw(r29+#244)
		memd(r12+#16) = r9:8
	}                                       // 4-byte Folded Reload
	{
		memw(r12+#40) = r4
		memd(r12+#24) = r7:6
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_671
	}
// %bb.669:                             // %if.then1405
	{
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		r2 = memw(r29+#244)
		if (p3.new) r0 = memw(r29+##760)
	}                                       // 4-byte Folded Reload
	{
		if (!p3) r0 = add(r1,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#232)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#232) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.670:                             // %if.then1405
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_671:                             // %do.end1409
	{
		r3 = add(r29,#8704)
		r0 = memw(r29+#372)
		r2 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		r22 = add(r3,#8260)
		r18 = add(r3,#8256)
		r4 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r4)
		if (!p1) jump:nt .LBB12_691
		memw(r29+#1664) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.672:                             // %if.else1414
	{
		r2 = memw(r29+#756)
		r3 = memw(r29+#328)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#8248)
		p0 = cmp.gtu(r2,#1); if (!p0.new) jump:t .LBB12_693
		memw(r29+#1656) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.673:                             // %if.then1427.peel
	{
		r0 = add(r29,#712)
		r19 = add(r29,#8704)
		r3 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:t .LBB12_676
		if (!p1.new) r2 = memw(r29+##9220)
	}
// %bb.674:                             // %if.then1430.peel
	{
		r3 = memw(r29+#312)
		r1 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r4 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.675:                             // %if.then1430.peel
	{
		r2 = memw(r29+#756)
	}
	.falign
.LBB12_676:                             // %if.end1439.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r3 = memw(r29+#408)
		memw(r22+#0) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r2,r3)
		r4 = add(r29,#8704)
		r2 = add(r29,#712)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r16 = add(pc,##moe_m1_pair_worker@PCREL)
		memw(r18+#0) = #0
		memw(r29+#772) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r29+#768) = r16
	}
	.falign
// %bb.677:                             // %if.end1439.peel
	{
		r17 = #0
		r2 = memw(r29+##8708)
		memw(r29+#752) = r17.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_680
	}
// %bb.678:                             // %if.end1439.peel
	{
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_680
	}
// %bb.679:                             // %if.then1453.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_680:                             // %for.inc1455.peel
	{
		r2 = memw(r29+#348)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r24 = add(r19,##516)
		if (p2.new) jump:t .LBB12_689
	}
// %bb.681:                             // %for.body1424.preheader
	{
		r17 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = memw(r29+#1680)
		r0 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r19 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r26 = asl(r0,#1)
		r27 = add(r2,#-1)
	}
	{
		r20 = #0
		r25 = #0
	}
	.falign
.LBB12_682:                             // %for.body1424
                                        // =>This Inner Loop Header: Depth=1
	{
		r21 = add(r29,#712)
		r23 = add(r29,#8704)
		r2 = r20
		r4 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r1:0 = combine(r23,r21)
		r3 = memw(r29+#284)
		r5 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.683:                             // %for.body1424
                                        //   in Loop: Header=BB12_682 Depth=1
	{
		r2 = add(r26,r25)
		r1 = r17
		r4 = memw(r29+#408)
		memw(r22+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = r21
		r25 = add(r4,r25)
		r0 = memw(r29+#756)
		memw(r29+#772) = r23
	}
	{
		r3 = maxu(r0,r4)
		r0 = memw(r29+#324)
		memw(r18+#0) = r25
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#768) = r16
	}
	.falign
// %bb.684:                             // %for.body1424
                                        //   in Loop: Header=BB12_682 Depth=1
	{
		r0 = #0
		r2 = memw(r24+#0)
		memw(r29+#752) = r0.new
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_687
	}
// %bb.685:                             // %for.body1424
                                        //   in Loop: Header=BB12_682 Depth=1
	{
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_687
	}
// %bb.686:                             // %if.then1453
                                        //   in Loop: Header=BB12_682 Depth=1
	{
		r2 = add(r29,#8704)
		r1 = r19
		r0 = memw(r29+#324)
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
	}
	.falign
.LBB12_687:                             // %for.inc1455
                                        //   in Loop: Header=BB12_682 Depth=1
	{
		r20 = add(r20,#1)
		r24 = add(r24,#512)
		r27 = add(r27,#-1)
		if (!cmp.eq(r27.new,#0)) jump:t .LBB12_682
	}
// %bb.688:                             // %for.cond.cleanup1423
	{
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r2,#-1)
	}
	{
		p1 = tstbit(r17,#0); if (p1.new) jump:t .LBB12_738
	}
	.falign
.LBB12_689:                             // %if.then1463
	{
		r0 = add(r29,#712)
		r1 = add(r29,#8704)
		r2 = r17
		r4 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post_after_a
		r3 = memw(r29+#284)
		r5 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.690:                             // %if.then1463
	{
		jump .LBB12_738
	}
	.falign
.LBB12_691:                             // %if.then1411
	{
		r2 = add(r29,#8704)
		r3 = memw(r29+#1680)
		r4 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r0 = memw(r29+#324)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r4)
		call hvx_worker_pool_run
		memw(r22+#0) = r3.new
	}
	.falign
// %bb.692:                             // %if.then1411
	{
		jump .LBB12_738
	}
	.falign
.LBB12_693:                             // %for.cond1468.preheader
	{
		r17 = #0
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_703
	}
// %bb.694:                             // %if.then1476.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.695:                             // %if.then1476.peel
	{
		r21:20 = combine(r1,r0)
		jump .LBB12_704
	}
	.falign
.LBB12_696:
	{
		r0 = memw(r29+#256)
		r16 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB12_174
		r2 = memw(r29+#260)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_697:
	{
		r25:24 = combine(#0,#0)
	}
	.falign
.LBB12_698:                             // %do.end1027
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r19 = #0
		r2 = add(r29,#712)
	}
	{
		r0 = memw(r29+#324)
		memw(r29+#768) = r19
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#772) = r19
	}
	.falign
// %bb.699:                             // %do.end1027
	{
		r1 = #0
		r2 = memw(r29+#244)
		memw(r29+#752) = r19
	}                                       // 4-byte Folded Reload
	{
		memd(r29+#1720) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_297
	}
// %bb.700:                             // %do.body1038
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.701:                             // %do.body1038
	{
		r1:0 = sub(r1:0,r25:24)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_297
	}
// %bb.702:                             // %if.then1040
	{
		r5 = #0
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r3,#10)
		r3 = #0
	}
	{
		r1:0 = memd(r2+#80)
		memd(r29+#1720) = r3:2
	}                                       // 8-byte Folded Spill
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		jump .LBB12_294
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_703:
	{
		r21:20 = combine(#0,#0)
	}
	.falign
.LBB12_704:                             // %do.end1480.peel
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r29+#1880)
	}
	.falign
// %bb.705:                             // %do.end1480.peel
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_709
	}
// %bb.706:                             // %do.body1494.peel
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.707:                             // %do.body1494.peel
	{
		r1:0 = sub(r1:0,r21:20)
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
	}
	{
		r5:4 = memd(r2+#64)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#64) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_709
	}
// %bb.708:                             // %if.then1496.peel
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r3 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r16 = lsr(r3,#10)
	}
	{
		r1:0 = memd(r2+#80)
	}
	{
		r1:0 = add(r1:0,r17:16)
	}
	{
		memd(r2+#80) = r1:0
	}
	.falign
.LBB12_709:                             // %if.end1503.peel
	{
		r1 = add(pc,##moe_m1_pair_worker@PCREL)
		r2 = add(r29,#8704)
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#324)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r22+#0) = r3
	}
	.falign
// %bb.710:                             // %if.end1503.peel
	{
		r2 = memw(r29+##8708)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_713
	}
// %bb.711:                             // %if.end1503.peel
	{
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_713
	}
// %bb.712:                             // %if.then1517.peel
	{
		r1 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_713:                             // %if.end1518.peel
	{
		r1 = #0
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,#2)) jump:t .LBB12_716
	}                                       // 4-byte Folded Reload
// %bb.714:                             // %if.then1522.peel
	{
		r1 = #0
		r0 = memw(r29+#284)
		r2 = memw(r29+##9732)
	}                                       // 4-byte Folded Reload
	{
		r5 = #1
		r3 = memw(r29+#312)
		memw(r29+#0) = #2
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.715:                             // %if.then1522.peel
	{
		jump .LBB12_720
		memw(r29+#1888) = r0
	}
	.falign
.LBB12_716:                             // %for.inc1554.peel
	{
		r5 = #3
		r2 = memw(r29+##8712)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#300)
		memw(r29+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.717:                             // %for.inc1554.peel
	{
		r5 = #3
		r2 = memw(r29+#348)
		memw(r29+#1944) = r0
	}                                       // 4-byte Folded Reload
	{
		p3 = r2
		if (p3.new) jump:t .LBB12_738
		if (!p3.new) r2 = memw(r29+##9224)
	}
// %bb.718:                             // %if.then1546.1.peel
	{
		r0 = memw(r29+#284)
		r3 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#356)
		memw(r29+#0) = #1
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.719:                             // %if.then1546.1.peel
	{
		memw(r29+#1948) = r0
	}
	.falign
.LBB12_720:                             // %for.body1472.preheader
	{
		r21 = #1
		r2 = add(r29,#8704)
		r3 = add(r29,#1880)
		r4 = memw(r29+#408)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(pc,##moe_m1_pair_worker@PCREL)
		r16 = #0
		r23 = #2
	}
	{
		r19 = add(pc,##moe_tl2_gate_epilogue_worker@PCREL)
		r20 = asl(r4,#1)
		r24 = add(r2,#1540)
	}
	{
		r27 = add(r3,#12)
	}
	.falign
.LBB12_721:                             // %for.body1472
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_723
	}
// %bb.722:                             // %if.then1476
                                        //   in Loop: Header=BB12_721 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
.LBB12_723:                             // %do.end1480
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		call moe_m1_wait
		r1 = #1
		r0 = memw(r27+#-8)
	}
	.falign
// %bb.724:                             // %do.end1480
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r1 = r17
		r2 = add(r29,#8704)
		r25 = memw(r29+#408)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r3 = r25
		r4 = add(r20,r16)
		r16 = add(r25,r16)
		memw(r22+#0) = r4.new
	}
	{
		call hvx_worker_pool_run
		memw(r18+#0) = r16
	}
	.falign
// %bb.725:                             // %do.end1480
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = memw(r24+#-1024)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_728
	}
// %bb.726:                             // %do.end1480
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_728
	}
// %bb.727:                             // %if.then1517
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = add(r29,#8704)
		r1 = r19
		r3 = r25
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
	}
	.falign
.LBB12_728:                             // %if.end1518
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r3 = add(r21,#2)
	}
	{
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_731
	}                                       // 4-byte Folded Reload
// %bb.729:                             // %if.then1522
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		p0 = tstbit(r21,#0)
		r5 = #1
		r3 = memw(r29+#384)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p0,r3,#0)
		r0 = memw(r29+#284)
		r2 = memw(r24+#0)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r3 = memw(r29+#312)
		r4 = memw(r29+#316)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.730:                             // %if.then1522
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		jump .LBB12_737
		memw(r27+#0) = r0
	}
	.falign
.LBB12_731:                             // %if.else1533
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r25 = and(r23,#2)
	}
	{
		p1 = cmp.eq(r25,#0)
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,r25)) jump:t .LBB12_734
	}                                       // 4-byte Folded Reload
// %bb.732:                             // %if.then1546
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = add(r29,#8704)
		r5 = #3
		r3 = memw(r29+#300)
		r6 = memw(r29+#384)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r25,#9)
		r1 = mux(p1,#0,r6)
		r0 = memw(r29+#284)
		memw(r29+#0) = r25
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r2 = memw(r2+#0)
	}
	.falign
// %bb.733:                             // %if.then1546
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r25<<#2) = r0
	}
	.falign
.LBB12_734:                             // %for.inc1554
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r26 = setbit(r25,#0)
	}
	{
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,r26)) jump:t .LBB12_737
	}                                       // 4-byte Folded Reload
// %bb.735:                             // %if.then1546.1
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = add(r29,#8704)
		p2 = cmp.eq(r25,#0)
		r5 = memw(r29+#384)
		memw(r29+#0) = r26
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r26,#9)
		r6 = mux(p2,#0,r5)
		r3 = memw(r29+#300)
		r7 = memw(r29+#356)
	}                                       // 4-byte Folded Reload
	{
		r2 = setbit(r2,#3)
		r5 = #3
		r0 = memw(r29+#284)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r2 = memw(r2+#0)
	}
	.falign
// %bb.736:                             // %if.then1546.1
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r2 = add(r29,#1944)
	}
	{
		memw(r2+r26<<#2) = r0
	}
	.falign
.LBB12_737:                             // %if.end1558
                                        //   in Loop: Header=BB12_721 Depth=1
	{
		r24 = add(r24,#512)
		r27 = add(r27,#4)
		r23 = add(r23,#2)
		r21 = add(r21,#1)
	}
	{
		r2 = memw(r29+#1680)
		if (!cmp.eq(r2.new,r21)) jump:t .LBB12_721
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_738:                             // %do.body1565
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_743
	}
// %bb.739:                             // %do.body1574
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.740:                             // %do.body1574
	{
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_743
	}
// %bb.741:                             // %if.then1576
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.742:                             // %if.then1576
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_743:                             // %do.end1580
	{
		r2 = memw(r29+#752)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_746
	}
// %bb.744:                             // %if.then1584
	{
		r2 = add(pc,##moe_m1_requant_worker@PCREL)
		r3 = memw(r29+#756)
		memw(r29+#768) = r2.new
	}
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r4 = add(r29,#8704)
		r5 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r2 = add(r29,#712)
		r0 = memw(r29+#324)
		memw(r29+#772) = r4
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
	}
	.falign
// %bb.745:                             // %if.then1584
	{
		r2 = #0 ; jump .LBB12_747
		memw(r29+#752) = r2.new
	}
	.falign
.LBB12_746:                             // %if.else1585
	{
		r1 = add(pc,##moe_m1_requant_worker@PCREL)
		r2 = add(r29,#8704)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		r3 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_747:                             // %do.body1587
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_752
	}
// %bb.748:                             // %do.body1596
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.749:                             // %do.body1596
	{
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#40)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#40) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_752
	}
// %bb.750:                             // %if.then1598
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.751:                             // %if.then1598
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_752:                             // %do.end1602
	{
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB12_771
		if (!p0.new) r2 = memw(r29+##296)
	}                                       // 4-byte Folded Reload
// %bb.753:                             // %if.else1609
	{
		r2 = memw(r29+#756)
	}
	{
		r2 = add(r29,#8704)
		p1 = cmp.gtu(r2,#1); if (!p1.new) jump:t .LBB12_773
	}
// %bb.754:                             // %land.lhs.true1622.peel
	{
		r2 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		p3 = tstbit(r2,#0)
		if (!p3.new) r0 = add(r29,##712)
		if (p3.new) jump:nt .LBB12_757
	}
// %bb.755:                             // %land.lhs.true1622.peel
	{
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,#2)) jump:nt .LBB12_757
	}                                       // 4-byte Folded Reload
// %bb.756:                             // %if.then1630.peel
	{
		r2 = memw(r29+##9736)
		r1 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r3 = memw(r29+#300)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_757:                             // %if.end1653.peel
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r5 = memw(r29+#296)
		r3 = memw(r29+#756)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r2 = add(r29,#712)
		r4 = add(r29,#8704)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(pc,##moe_m1_down_worker@PCREL)
		memw(r18+#0) = #0
		memw(r22+#0) = r5
	}
	{
		call hvx_worker_pool_run
		memw(r29+#772) = r4
		memw(r29+#768) = r17
	}
	.falign
// %bb.758:                             // %if.end1653.peel
	{
		r2 = #0
		r0 = memw(r29+#348)
		memw(r29+#752) = r2.new
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (p0.new) jump:t .LBB12_780
		if (!p0.new) r2 = memw(r29+##1680)
	}                                       // 4-byte Folded Reload
// %bb.759:                             // %land.lhs.true1622.peel5826
	{
		r2 = and(r2,#1)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB12_762
	}
// %bb.760:                             // %land.lhs.true1622.peel5826
	{
		r0 = add(r29,#712)
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,#3)) jump:nt .LBB12_762
	}                                       // 4-byte Folded Reload
// %bb.761:                             // %if.then1630.peel5830
	{
		r2 = memw(r29+#356)
		r3 = memw(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r3,r2)
		r2 = memw(r29+##10248)
		r3 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_762:                             // %if.end1638.peel5834
	{
		r0 = add(r29,#712)
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,#4)) jump:t .LBB12_764
	}                                       // 4-byte Folded Reload
// %bb.763:                             // %if.then1645.peel5837
	{
		r2 = memw(r29+##10760)
		r1 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_q_post
		r3 = memw(r29+#300)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_764:                             // %if.end1653.peel5844
	{
		r1 = add(pc,##moe_m1_q_worker@PCREL)
		r5 = memw(r29+#296)
		r3 = memw(r29+#756)
	}                                       // 4-byte Folded Reload
	{
		r3 = maxu(r3,r5)
		r2 = add(r29,#712)
		r4 = add(r29,#8704)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		r19 = asl(r5,#1)
		memw(r18+#0) = r5
		memw(r29+#772) = r4
	}
	{
		call hvx_worker_pool_run
		memw(r22+#0) = r19
		memw(r29+#768) = r17
	}
	.falign
// %bb.765:                             // %if.end1653.peel5844
	{
		r20 = #0
		r2 = memw(r29+#1680)
		memw(r29+#752) = r20.new
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,#2)
		if (p2.new) jump:t .LBB12_780
		if (!p2.new) r3 = memw(r29+##1680)
	}                                       // 4-byte Folded Reload
// %bb.766:                             // %for.body1619.preheader
	{
		r16 = add(pc,##moe_m1_q_worker@PCREL)
		r2 = add(r29,#8704)
		r24 = #5
	}
	{
		r21 = add(r3,#-2)
		r26 = #0
		r27 = add(r2,#2568)
		r3 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r25 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r23 = +mpyi(r3,#3)
	}
	.falign
.LBB12_767:                             // %for.body1619
                                        // =>This Inner Loop Header: Depth=1
	{
		r3 = asl(r24,#30)
		p2 = tstbit(r24,#0)
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,r24)) jump:t .LBB12_769
	}                                       // 4-byte Folded Reload
// %bb.768:                             // %if.then1645
                                        //   in Loop: Header=BB12_767 Depth=1
	{
		r0 = add(r29,#712)
		r6 = memw(r29+#384)
		r5 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r3,#31)
		r4 = memw(r29+#356)
		r3 = memw(r29+#300)
	}                                       // 4-byte Folded Reload
	{
		r1 = mux(p2,r4,#0)
		r2 = memw(r27+#0)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r1 += add(r5,r6)
		call moe_m1_q_post
	}
	.falign
.LBB12_769:                             // %if.end1653
                                        //   in Loop: Header=BB12_767 Depth=1
	{
		r2 = add(r19,r26)
		r1 = r16
		r3 = memw(r29+#756)
		memw(r18+#0) = r2.new
	}
	{
		r3 = maxu(r3,r25)
		r2 = add(r23,r26)
		r0 = memw(r29+#324)
		memw(r22+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#712)
		r4 = add(r29,#8704)
		memw(r29+#772) = r4.new
	}
	{
		call hvx_worker_pool_run
		memw(r29+#768) = r17
	}
	.falign
// %bb.770:                             // %if.end1653
                                        //   in Loop: Header=BB12_767 Depth=1
	{
		r21 = add(r21,#-1)
		r26 = add(r26,r25)
		r24 = add(r24,#1)
		r27 = add(r27,#512)
	}
	{
		p1 = cmp.eq(r21,#0); if (!p1.new) jump:t .LBB12_767
		memw(r29+#752) = r20
	}
	{
		jump .LBB12_780
	}
	.falign
.LBB12_771:                             // %if.then1604
	{
		r1 = add(pc,##moe_m1_down_worker@PCREL)
		r3 = memw(r29+#1680)
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#324)
		memw(r18+#0) = #0
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r2)
		call hvx_worker_pool_run
		r2 = add(r29,#8704)
		memw(r22+#0) = r3.new
	}
	.falign
// %bb.772:                             // %if.then1604
	{
		jump .LBB12_780
	}
	.falign
.LBB12_773:                             // %for.cond1665.preheader
	{
		r16 = add(pc,##moe_m1_down_worker@PCREL)
		r3 = add(r29,#1944)
		r17 = add(r2,#2056)
	}
	{
		r21 = add(r3,#16)
		r19 = #0
		r20 = #0
	}
	.falign
.LBB12_774:                             // %for.body1669
                                        // =>This Inner Loop Header: Depth=1
	{
		call moe_m1_wait
		r1 = #2
		r0 = memw(r21+#-16)
	}
	.falign
// %bb.775:                             // %for.body1669
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r1 = r16
		r2 = add(r29,#8704)
		r0 = memw(r29+#324)
		r3 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r19 = add(r3,r19)
		memw(r18+#0) = r19
	}
	{
		call hvx_worker_pool_run
		memw(r22+#0) = r19
	}
	.falign
// %bb.776:                             // %for.body1669
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r3 = add(r20,#4)
	}
	{
		r2 = memw(r29+#1680)
		if (!cmp.gtu(r2.new,r3)) jump:t .LBB12_779
	}                                       // 4-byte Folded Reload
// %bb.777:                             // %if.then1679
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		p0 = tstbit(r20,#0)
		r4 = asl(r20,#30)
		r6 = memw(r29+#384)
		memw(r29+#0) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 &= asr(r4,#31)
		r5 = #3
		r3 = memw(r29+#356)
		r2 = memw(r17+#0)
	}                                       // 4-byte Folded Reload
	{
		r7 = mux(p0,r3,#0)
		r3 = memw(r29+#300)
		r0 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		call moe_m1_push
		r1 = add(r6,r7)
		r4 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.778:                             // %if.then1679
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		memw(r21+#0) = r0
	}
	.falign
.LBB12_779:                             // %for.inc1691
                                        //   in Loop: Header=BB12_774 Depth=1
	{
		r17 = add(r17,#512)
		r21 = add(r21,#4)
		r20 = add(r20,#1)
	}
	{
		r2 = memw(r29+#1720)
		if (!cmp.eq(r2.new,r20)) jump:t .LBB12_774
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_780:                             // %do.body1697
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_785
	}
// %bb.781:                             // %do.body1706
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.782:                             // %do.body1706
	{
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#48)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#48) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_785
	}
// %bb.783:                             // %if.then1708
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.784:                             // %if.then1708
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_785:                             // %do.end1712
	{
		r18 = #0
		r2 = memw(r29+#400)
		r3 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r16 = asl(r3,#2)
		p2 = cmp.eq(r2,#0)
		r23 = memw(r29+#544)
		r25 = memw(r29+#1720)
	}                                       // 4-byte Folded Reload
	{
		r2 = p2
		memw(r29+#1656) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#464)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_786:                             // %for.body1718
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_792 Depth 2
	{
		r19 = add(r29,#8704)
		r24 = r2
		r0 = memw(r29+#1656)
		r2 = memw(r2+#0)
	}                                       // 4-byte Folded Reload
	{
		r19 += asl(r18,#9)
		p0 = r0
		r4 = memw(r29+#304)
	}                                       // 4-byte Folded Reload
	{
		r20 = addasl(r4,r2,#2)
		if (p0) jump:nt .LBB12_790
		if (!p0) r4 = memw(r29+##308)
	}                                       // 4-byte Folded Reload
// %bb.787:                             // %if.then1727
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		r3 = mpyi(r18,r3)
		r2 = r16
	}
	{
		r17 = addasl(r4,r3,#2)
	}
	{
		call memset
		r1:0 = combine(#0,r17)
	}
	.falign
// %bb.788:                             // %if.then1727
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		r0 = r17
		r1 = memw(r19+#52)
		r2 = memw(r20+#0)
	}
	{
		call hvx_scale_add_rows_f32
		r3 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.789:                             // %if.then1727
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		jump .LBB12_794
		r3 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_790:                             // %for.cond1736.preheader
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		r22 = #0
		r21 = #0
		r4 = memw(r19+#388)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB12_794
	}
// %bb.791:                             // %for.body1741.lr.ph
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		r4 = memw(r29+#288)
	}                                       // 4-byte Folded Reload
	{
		r17 = addasl(r4,r2,#2)
	}
	.falign
.LBB12_792:                             // %for.body1741
                                        //   Parent Loop BB12_786 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r5 = memw(r17++#4)
		r4 = memw(r19+#52)
	}
	{
		r1 = add(r4,r21)
		r2 = memw(r20++#4)
	}
	{
		r5 = mpyi(r5,r3)
	}
	{
		r0 = addasl(r23,r5,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.793:                             // %for.body1741
                                        //   in Loop: Header=BB12_792 Depth=2
	{
		r22 = add(r22,#1)
		r21 = add(r21,r16)
		r3 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r19+#388)
		if (cmp.gtu(r2.new,r22)) jump:t .LBB12_792
	}
	.falign
.LBB12_794:                             // %cleanup1753
                                        //   in Loop: Header=BB12_786 Depth=1
	{
		r2 = add(r24,#4)
		r18 = add(r18,#1)
		if (!cmp.eq(r18.new,r25)) jump:t .LBB12_786
	}
// %bb.795:                             // %for.cond.cleanup1717
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_798
	}
// %bb.796:                             // %if.then1764
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.797:                             // %if.then1764
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	.falign
.LBB12_798:                             // %do.end1770
	{
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB12_800
		if (p1.new) r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
// %bb.799:                             // %if.then1772
	{
		r2 = memw(r29+#764)
		r3 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (p3.new) r3 = #0
	}
	{
		if (!p3) r3 = add(r2,##-32767)
	}
	{
		jump .LBB12_808
		memw(r29+#340) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_800:                             // %do.body1777
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_803
	}
// %bb.801:                             // %if.then1779
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.802:                             // %if.then1779
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_803:                             // %do.end1783
	{
		r3 = #0
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#308)
		r1 = memw(r29+#544)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#504)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.804:                             // %do.end1783
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_807
	}
// %bb.805:                             // %if.then1788
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.806:                             // %if.then1788
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	.falign
.LBB12_807:                             // %do.end1794
	{
		r2 = memw(r29+#764)
		r3 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		r2 = ##-2147449856
		if (p1.new) r3 = #0
	}
	{
		if (!p1) r3 = add(r2,##-32767)
	}
	{
		memw(r29+#340) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB12_808:                             // %out3230.thread
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_809:                             // %for.body3239
	{
		r2 = memw(r29+#1752)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_811
	}
// %bb.810:                             // %if.then3242
	{
		call hvx_worker_pool_wait_bg
		r1 = add(r29,#2712)
		r2 = #-1
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_811:                             // %for.inc3245
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1756)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_813
	}
// %bb.812:                             // %if.then3242.1
	{
		r2 = #-1
		r1 = add(r3,#32)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_813:                             // %for.inc3245.1
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1760)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_815
	}
// %bb.814:                             // %if.then3242.2
	{
		r2 = #-1
		r1 = add(r3,#64)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_815:                             // %for.inc3245.2
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1764)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_817
	}
// %bb.816:                             // %if.then3242.3
	{
		r2 = #-1
		r1 = add(r3,#96)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_817:                             // %for.inc3245.3
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1768)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_819
	}
// %bb.818:                             // %if.then3242.4
	{
		r2 = #-1
		r1 = add(r3,#128)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_819:                             // %for.inc3245.4
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1772)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_821
	}
// %bb.820:                             // %if.then3242.5
	{
		r2 = #-1
		r1 = add(r3,#160)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_821:                             // %for.inc3245.5
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1776)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_823
	}
// %bb.822:                             // %if.then3242.6
	{
		r2 = #-1
		r1 = add(r3,#192)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_823:                             // %for.inc3245.6
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1780)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_825
	}
// %bb.824:                             // %if.then3242.7
	{
		r2 = #-1
		r1 = add(r3,#224)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_825:                             // %for.inc3245.7
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1784)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_827
	}
// %bb.826:                             // %if.then3242.8
	{
		r2 = #-1
		r1 = add(r3,#256)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_827:                             // %for.inc3245.8
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1788)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_829
	}
// %bb.828:                             // %if.then3242.9
	{
		r2 = #-1
		r1 = add(r3,#288)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_829:                             // %for.inc3245.9
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1792)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_831
	}
// %bb.830:                             // %if.then3242.10
	{
		r2 = #-1
		r1 = add(r3,#320)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_831:                             // %for.inc3245.10
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1796)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_833
	}
// %bb.832:                             // %if.then3242.11
	{
		r2 = #-1
		r1 = add(r3,#352)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_833:                             // %for.inc3245.11
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1800)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_835
	}
// %bb.834:                             // %if.then3242.12
	{
		r2 = #-1
		r1 = add(r3,#384)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_835:                             // %for.inc3245.12
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1804)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_837
	}
// %bb.836:                             // %if.then3242.13
	{
		r2 = #-1
		r1 = add(r3,#416)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_837:                             // %for.inc3245.13
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1808)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_839
	}
// %bb.838:                             // %if.then3242.14
	{
		r2 = #-1
		r1 = add(r3,#448)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_839:                             // %for.inc3245.14
	{
		r3 = add(r29,#2712)
		r2 = memw(r29+#1812)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_841
	}
// %bb.840:                             // %if.then3242.15
	{
		r2 = #-1
		r1 = add(r3,#480)
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_wait_bg
	}
	.falign
.LBB12_841:                             // %for.inc3245.15
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_850
	}
// %bb.842:                             // %if.then3250
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_finish
		r2 = add(r29,#2456)
	}
	.falign
// %bb.843:                             // %if.then3250
	{
		r17 = #0
		r2 = memw(r29+#244)
		r16 = memw(r29+#2456)
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		r16 = memw(r29+#2460)
		memd(r18+#144) = r17:16
	}
	{
		r16 = memw(r29+#2464)
		memd(r18+#152) = r17:16
	}
	{
		r16 = memw(r29+#2468)
		memd(r18+#160) = r17:16
	}
	{
		r16 = memw(r29+#2472)
		memd(r18+#200) = r17:16
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.844:                             // %if.then3250
	{
		r16 = memw(r29+#2476)
		memd(r18+#168) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.845:                             // %if.then3250
	{
		r16 = memw(r29+#2480)
		memd(r18+#176) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.846:                             // %if.then3250
	{
		r16 = memw(r29+#2484)
		memd(r18+#184) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.847:                             // %if.then3250
	{
		r16 = memw(r29+#2488)
		memd(r18+#192) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.848:                             // %if.then3250
	{
		r16 = memw(r29+#2492)
		memd(r18+#208) = r1:0
	}
	{
		call HAP_perf_qtimer_count_to_us
		r1:0 = combine(r17,r16)
	}
	.falign
// %bb.849:                             // %if.then3250
	{
		memd(r18+#216) = r1:0
	}
	.falign
.LBB12_850:                             // %cleanup3369
	{
		jump .LBB12_78
		r4 = memw(r29+#340)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_851:                             // %do.body3137
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_854
	}
// %bb.852:                             // %if.then3139
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.853:                             // %if.then3139
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_854:                             // %do.end3143
	{
		call hvx_worker_pool_wait
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.855:                             // %do.end3143
	{
		r2 = memw(r29+#516)
		r0 = memw(r29+#468)
	}                                       // 4-byte Folded Reload
	{
		p1 = r0
		p3 = cmp.eq(r2,#0)
	}
	{
		p2 = or(p1,p3)
		if (p2.new) jump:t .LBB12_858
		if (!p2.new) r2 = memw(r29+##516)
	}                                       // 4-byte Folded Reload
// %bb.856:                             // %if.then3148
	{
		call __hexagon_umodsi3
		r0 = add(r2,#-1)
		r1 = memw(r29+#704)
	}
	.falign
// %bb.857:                             // %if.then3148
	{
		r3 = add(r29,#2072)
		r2 = #-1
	}
	{
		r1 = addasl(r3,r0,#5)
		call hvx_worker_pool_wait_bg
		r0 = memw(r29+#324)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_858:                             // %if.end3153
	{
		r16 = #0
		r2 = memw(r29+#264)
		if (!cmp.gtu(r2.new,#31)) jump:t .LBB12_866
	}                                       // 4-byte Folded Reload
// %bb.859:                             // %for.body3159.lr.ph
	{
		r2 = memw(r29+#264)
		r19 = memw(r29+#696)
	}                                       // 4-byte Folded Reload
	{
		r20 = asl(r2,#2)
	}
	.falign
.LBB12_860:                             // %for.body3180.lr.ph
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB12_862 Depth 2
	{
		call __hexagon_udivsi3
		r1:0 = combine(r19,r16)
	}
	.falign
// %bb.861:                             // %for.body3180.lr.ph
                                        //   in Loop: Header=BB12_860 Depth=1
	{
		r21 = memw(r29+#548)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r16)
		r3 = memw(r29+#544)
		r5:4 = memd(r29+#1664)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r19)
		r17 = addasl(r3,r16,#7)
		r19 = r4
	}
	{
		r21 += mpyi(r0,r4)
		r18 = asl(r2,#7)
	}
	.falign
.LBB12_862:                             // %for.body3180
                                        //   Parent Loop BB12_860 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = memb(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB12_864
	}
// %bb.863:                             // %if.then3183
                                        //   in Loop: Header=BB12_862 Depth=2
	{
		call memset
		r2 = r18
		r1:0 = combine(#0,r17)
	}
	.falign
.LBB12_864:                             // %for.inc3191
                                        //   in Loop: Header=BB12_862 Depth=2
	{
		r21 = add(r21,#1)
		r17 = add(r17,r20)
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB12_862
	}
// %bb.865:                             // %for.cond.cleanup3179
                                        //   in Loop: Header=BB12_860 Depth=1
	{
		r19 = memw(r29+#696)
		r2 = memw(r29+#296)
	}                                       // 4-byte Folded Reload
	{
		r16 = add(r19,r16)
		if (cmp.gtu(r2,r16.new)) jump:t .LBB12_860
	}
	.falign
.LBB12_866:                             // %for.cond.cleanup3158
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_871
	}
// %bb.867:                             // %do.body3209
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.868:                             // %do.body3209
	{
		r3 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#120)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#120) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB12_871
	}
// %bb.869:                             // %if.then3211
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.870:                             // %if.then3211
	{
		memd(r29+#1704) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB12_871:                             // %do.end3215
	{
		r2 = memw(r29+#404)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r3 = #0
		if (p2.new) jump:t .LBB12_873
	}
// %bb.872:                             // %if.then3217
	{
		r5:4 = combine(#4,#0)
		r0 = memw(r29+#308)
		r1 = memw(r29+#620)
	}                                       // 4-byte Folded Reload
	{
		call moe_dma_copy
		r2 = memw(r29+#504)
	}                                       // 4-byte Folded Reload
	.falign
.LBB12_873:                             // %do.body3221
	{
		r0 = #0
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memw(r29+#340) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB12_649
	}
// %bb.874:                             // %if.then3223
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.875:                             // %if.then3223
	{
		r2 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#1704)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB12_649
		memd(r2+#8) = r1:0
	}
.Lfunc_end12:
	.size	hexkl_mm_u8i4_moe_layer_run, .Lfunc_end12-hexkl_mm_u8i4_moe_layer_run
                                        // -- End function
	.falign
	.type	moe_all_4bit,@function          // -- Begin function moe_all_4bit
moe_all_4bit:                           // @moe_all_4bit
// %bb.0:                               // %entry
	{
		loop0(.LBB13_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB13_8
	}
	.falign
.LBB13_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB13_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (p0.new) jump:nt .LBB13_7
		if (!p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (cmp.eq(r6.new,#2)) jump:nt .LBB13_7
	}
	.falign
.LBB13_5:                               // %for.inc
                                        //   in Loop: Header=BB13_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB13_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB13_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end13:
	.size	moe_all_4bit, .Lfunc_end13-moe_all_4bit
                                        // -- End function
	.falign
	.type	moe_all_2bit,@function          // -- Begin function moe_all_2bit
moe_all_2bit:                           // @moe_all_2bit
// %bb.0:                               // %entry
	{
		loop0(.LBB14_2,r1)
		p0 = cmp.eq(r1,#0); if (p0.new) jump:nt .LBB14_8
	}
	.falign
.LBB14_2:                               // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = r0
		r7 = r0
		r5 = memw(r4+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB14_5
	}
// %bb.3:                               // %if.end
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r5 = memw(r2+#0)
	}
	{
		r6 += mpyi(r5,#96)
	}
	{
		r5 = memw(r6+#84)
	}
	{
		r5 = #0
		p0 = cmp.eq(r5,#2); if (!p0.new) jump:nt .LBB14_7
		if (p0.new) r6 = memw(r3+#0)
	}
// %bb.4:                               // %lor.lhs.false
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r7 += mpyi(r6,#96)
	}
	{
		r6 = memw(r7+#84)
		if (!cmp.eq(r6.new,#2)) jump:nt .LBB14_7
	}
	.falign
.LBB14_5:                               // %for.inc
                                        //   in Loop: Header=BB14_2 Depth=1
	{
		r3 = add(r3,#4)
		r4 = add(r4,#4)
		r2 = add(r2,#4)
	} :endloop0
// %bb.6:
	{
		r5 = #1
	}
	.falign
.LBB14_7:                               // %cleanup
	{
		r0 = r5
		jumpr r31
	}
	.falign
.LBB14_8:
	{
		r0 = #1
		jumpr r31
	}
.Lfunc_end14:
	.size	moe_all_2bit, .Lfunc_end14-moe_all_2bit
                                        // -- End function
	.falign
	.type	htp_tl2_palette_magnitude,@function // -- Begin function htp_tl2_palette_magnitude
htp_tl2_palette_magnitude:              // @htp_tl2_palette_magnitude
// %bb.0:                               // %entry
	{
		r2 = memb(r0+#0)
	}
	{
		r2 = abs(r2)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_3
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r2,#7); if (p1.new) jump:nt .LBB15_3
	}
// %bb.2:                               // %entry
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_3:                               // %for.inc
	{
		r3 = memb(r0+#1)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_8
	}
// %bb.4:                               // %for.inc
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB15_6
	}
// %bb.5:                               // %for.inc
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_6:                               // %lor.lhs.false.1
	{
		if (p0) jump:nt .LBB15_9
	}
// %bb.7:                               // %lor.lhs.false.1
	{
		p0 = cmp.eq(r2,r3); if (!p0.new) jump:t .LBB15_20
	}
	{
		jump .LBB15_9
	}
	.falign
.LBB15_8:
	{
		r3 = r2
	}
	.falign
.LBB15_9:                               // %for.inc.1
	{
		r2 = memb(r0+#2)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_14
	}
// %bb.10:                              // %for.inc.1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB15_12
	}
// %bb.11:                              // %for.inc.1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB15_20
	}
	.falign
.LBB15_12:                              // %lor.lhs.false.2
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB15_15
	}
// %bb.13:                              // %lor.lhs.false.2
	{
		p1 = cmp.eq(r3,r2); if (!p1.new) jump:t .LBB15_20
	}
	{
		jump .LBB15_15
	}
	.falign
.LBB15_14:
	{
		r2 = r3
	}
	.falign
.LBB15_15:                              // %for.inc.2
	{
		r3 = memb(r0+#3)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_21
	}
// %bb.16:                              // %for.inc.2
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB15_18
	}
// %bb.17:                              // %for.inc.2
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB15_20
	}
	.falign
.LBB15_18:                              // %lor.lhs.false.3
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB15_22
	}
// %bb.19:                              // %lor.lhs.false.3
	{
		p0 = cmp.eq(r2,r3); if (p0.new) jump:nt .LBB15_22
	}
	.falign
.LBB15_20:                              // %cleanup21
	{
		r0 = #0
		jumpr r31
	}
	.falign
.LBB15_21:
	{
		r3 = r2
	}
	.falign
.LBB15_22:                              // %for.inc.3
	{
		r2 = #1
	}
	{
		r0 = maxu(r3,r2)
		jumpr r31
	}
.Lfunc_end15:
	.size	htp_tl2_palette_magnitude, .Lfunc_end15-htp_tl2_palette_magnitude
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_usable,@function  // -- Begin function hexkl_acc_i24_usable
hexkl_acc_i24_usable:                   // @hexkl_acc_i24_usable
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB16_3
		r0 = #0
		r4 = r0
	}
// %bb.1:                               // %land.lhs.true
	{
		r5 = memw(r3+#4)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB16_3
	}
// %bb.2:                               // %land.lhs.true2
	{
		r5 = memw(r3+#8)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB16_4
	}
	.falign
.LBB16_3:                               // %land.end
	{
		jumpr r31
	}
	.falign
.LBB16_4:                               // %land.lhs.true3
	{
		r3 = memw(r3+#12)
	}
	{
		p1 = cmp.eq(r3,#32)
		if (p1.new) r3 = add(r1,#-1)
		if (!p1.new) jump:t .LBB16_3
	}
// %bb.5:                               // %land.rhs
	{
		p0 = cmp.gtu(r2,#7)
		if (p0.new) jumpr:nt r31
	}
.LBB16_6:                               // %land.rhs
	{
		p1 = cmp.eq(r4,#0)
		if (p1.new) jumpr:nt r31
	}
.LBB16_7:                               // %land.rhs
	{
		r5 = #-9
		if (cmp.gtu(r5.new,r3)) jump:nt .LBB16_3
	}
// %bb.8:                               // %if.end.i
	{
		r3 = #255
		r5 = sub(#0,r1)
		r6 = ##8388609
	}
	{
		r13:12 = mpyu(r4,r3)
		r7 = #0
		r8 = ##8388608
	}
	{
		r9 = #0
	}
	{
		r15:14 = mpyu(r12,r5)
		r11:10 = mpyu(r12,r2)
	}
	{
		r15 += mpyi(r5,r13)
		r11 += mpyi(r2,r13)
	}
	{
		p1 = cmp.gtu(r7:6,r15:14)
		p0 = cmp.gtu(r9:8,r11:10)
	}
	{
		p1 = and(p1,p0)
	}
	{
		r0 = mux(p1,#1,#0)
		jumpr r31
	}
.Lfunc_end16:
	.size	hexkl_acc_i24_usable, .Lfunc_end16-hexkl_acc_i24_usable
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_banks,@function   // -- Begin function hexkl_acc_i24_banks
hexkl_acc_i24_banks:                    // @hexkl_acc_i24_banks
// %bb.0:                               // %entry
	{
		r7 = #0
		if (!p0.new) r8 = add(r3,#0)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB17_8
	}
// %bb.1:                               // %entry
	{
		r9 = and(r2,#1)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB17_8
	}
// %bb.2:                               // %lor.lhs.false2
	{
		p0 = cmp.gtu(r2,#1); if (!p0.new) jump:nt .LBB17_8
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r15:14 = combine(#0,#0)
		r3 = r1
		r6 = r1
	}
	{
		r3 = or(r9,and(r3,##2047))
		if (!cmp.eq(r3.new,#0)) jump:nt .LBB17_8
	}
// %bb.4:                               // %if.end
	{
		r3 = #24576
		r9 = #0
	}
	{
		r13:12 = mpyu(r2,r3)
	}
	{
		r13:12 = add(r13:12,r7:6)
	}
	{
		r9:8 = add(r13:12,r9:8)
	}
	{
		r11:10 = combine(#0,r9)
	}
	{
		p0 = cmp.eq(r11:10,r15:14)
		if (p0.new) r3 = add(r0,##-3072)
		if (!p0.new) jump:t .LBB17_8
	}
// %bb.5:                               // %lor.lhs.false15
	{
		p1 = cmp.gtu(r0,##3071)
		if (!p1.new) jump:nt .LBB17_8
	}
// %bb.6:                               // %lor.lhs.false15
	{
		r3 = insert(r14,#11,#0)
		if (cmp.gtu(r8,r3.new)) jump:nt .LBB17_8
	}
// %bb.7:                               // %if.end20
	{
		r6 += mpyi(r2,##12288)
		r7 = #1
		memw(r4+#0) = r6.new
	}
	{
		r0 = r7
		jumpr r31
		memw(r5+#0) = r12
	}
	.falign
.LBB17_8:                               // %return
	{
		r0 = r7
		jumpr r31
	}
.Lfunc_end17:
	.size	hexkl_acc_i24_banks, .Lfunc_end17-hexkl_acc_i24_banks
                                        // -- End function
	.falign
	.type	hexkl_acc_i24_prepare,@function // -- Begin function hexkl_acc_i24_prepare
hexkl_acc_i24_prepare:                  // @hexkl_acc_i24_prepare
// %bb.0:                               // %entry
	{
		r3 = #16384
		r1 = add(r0,#1024)
		v0 = vxor(v0,v0)
		vmem(r0+#2) = v0.new
	}
	{
		v2 = vsplat(r3)
		r1 = add(r0,#1152)
		r2 = #24576
		vmem(r1+#0) = v2.new
	}
	{
		v1 = vsplat(r2)
		r1 = add(r0,#1280)
		r3 = add(r0,#1408)
		vmem(r1+#0) = v2
	}
	{
		r1 = add(r0,#1536)
		r2 = #8192
		vmem(r1+#0) = v0
	}
	{
		v3 = vsplat(r2)
		r1 = add(r0,#1792)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2304)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2560)
		vmem(r1+#0) = v0
	}
	{
		r1 = add(r0,#2048)
		vmem(r1+#0) = v0
	}
	{
		r3 = add(r0,#1664)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2176)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#1920)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2688)
		vmem(r1+#0) = v3
	}
	{
		r3 = add(r0,#2432)
		vmem(r3+#0) = v0
	}
	{
		r1 = add(r0,#2816)
		vmem(r1+#0) = v0
	}
	{
		vmem(r0+#0) = v1
	}
	{
		vmem(r0+#3) = v0
	}
	{
		vmem(r0+#4) = v0
	}
	{
		vmem(r0+#1) = v1
	}
	{
		vmem(r0+#5) = v0
	}
	{
		vmem(r0+#6) = v0
	}
	{
		r0 = add(r0,#2944)
		vmem(r0+#7) = v0
	}
	{
		vmem(r3+#0) = v0
	}
	{
		vmem(r1+#0) = v0
	}
	{
		jumpr r31
		vmem(r0+#0) = v0
	}
.Lfunc_end18:
	.size	hexkl_acc_i24_prepare, .Lfunc_end18-hexkl_acc_i24_prepare
                                        // -- End function
	.falign
	.type	moe_push_gate_up_chunks,@function // -- Begin function moe_push_gate_up_chunks
moe_push_gate_up_chunks:                // @moe_push_gate_up_chunks
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#168)
	}                                       // 8-byte Folded Spill
	{
		r23 = memw(r29+#176)
		memd(r29+#136) = r23:22
	}
	{
		p1 = cmp.eq(r23,#0)
		memd(r29+#152) = r19:18
		memd(r29+#144) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#128) = r25:24
		memd(r29+#120) = r27:26
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#28) = r4
		memw(r29+#40) = r2
	}                                       // 4-byte Folded Spill
	{
		if (p1) jump:nt .LBB19_59
		if (!p1) r27 = memw(r29+#188)
		memw(r29+#36) = r1
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r3 = asl(r5,#9)
		r17:16 = combine(r3,#0)
		r25:24 = combine(#0,#0)
		r22 = memw(r29+#180)
	}
	{
		r3 = lsr(r3,#1)
		r21:20 = combine(#0,r23)
		r18 = r0
		memw(r29+#48) = r3
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#36)
		memw(r29+#68) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
		r1:0 = vaslw(r23:22,#9)
		r4 = add(r0,r2)
	}
	{
		r3 = #0
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Spill
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r6 = memw(r29+#184)
		memd(r29+#96) = r3:2
	}
	{
		r2 = add(r2,r1)
		memw(r29+#44) = r4
		memw(r29+#24) = r6
	}                                       // 4-byte Folded Spill
	{
		memd(r29+#88) = r1:0
		memw(r29+#72) = r2
	}                                       // 8-byte Folded Spill
	{
		memw(r29+#56) = r18
		memw(r29+#20) = r3
	}                                       // 4-byte Folded Spill
	.falign
.LBB19_2:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r4 = minu(r22,r20)
		r5 = add(r23,r16)
		r3 = #0
		r2 = memw(r17+#44)
	}
	{
		r26 = minu(r5,r22)
		r3 = insert(r4,#23,#8)
		p0 = cmp.eq(r2,#0)
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r3)
		if (!p0) r5:4 = combine(r26,r25)
		if (p0) jump:nt .LBB19_8
		memw(r29+#32) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.3:                               // %if.then.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = add(r29,#76)
		r0 = r18
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r6 = memw(r29+#24)
		memw(r29+#76) = #1
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		r2 = memw(r29+#40)
		memw(r29+#84) = r24
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_4:                               // %moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r4 = add(r23,r25)
		r2 = memw(r17+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_13
	}
// %bb.5:                               // %if.then.i30
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = add(r29,#76)
		r5 = r26
		r1 = memw(r29+#16)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3 = r17
		r0 = r18
		r6 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r1+#0)
		memw(r29+#0) = r2.new
	}
	{
		r1 = memw(r29+#36)
		memw(r29+#76) = #2
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#40)
		memw(r29+#80) = r6
	}                                       // 4-byte Folded Reload
	{
		call moe_push_native_chunk
		memw(r29+#84) = r24
	}
	.falign
// %bb.6:                               // %if.then.i30
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
	}
	.falign
.LBB19_7:                               // %moe_push_weight_chunk.exit41
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r25 = add(r25,r22)
		r24 = add(r24,#1)
		r1:0 = memd(r29+#88)
		memw(r27++#4) = r26
	}                                       // 8-byte Folded Reload
	{
		p0 = cmp.gtu(r23,r25)
		r21 = add(r21,r0)
		r20 = sub(r20,r22)
		r16 = sub(r16,r22)
	}
	{
		if (p0) jump:nt .LBB19_2
	}
	{
		jump .LBB19_59
	}
	.falign
.LBB19_8:                               // %if.end.i48
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p1 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p0 = cmp.eq(r3,#0)
	}
	{
		r3 = p0
		if (!p1) jump:nt .LBB19_18
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.9:                               // %if.then3.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.10:                              // %if.then3.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_26
	}
// %bb.11:                              // %if.then12.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then12.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB19_27
		r5 = memw(r17+#4)
	}
	{
		jump .LBB19_29
	}
	.falign
.LBB19_13:                              // %if.end.i58
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#16)
		r2 = memw(r17+#84)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r26,#9)
		p0 = cmp.eq(r2,#2)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		r3 = p1
		if (!p0) jump:nt .LBB19_22
		memw(r29+#60) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:                              // %if.then3.i90
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
		r19 = lsr(r2,#1)
	}
	.falign
// %bb.15:                              // %if.then3.i90
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r19

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_32
	}
// %bb.16:                              // %if.then12.i95
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r29+#96)
	}                                       // 8-byte Folded Reload
	{
		r3 = mpyi(r19,r3)
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.17:                              // %if.then12.i95
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB19_33
		r3 = memw(r17+#4)
	}
	{
		jump .LBB19_35
	}
	.falign
.LBB19_18:                              // %if.end30.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.19:                              // %if.end30.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
		memw(r29+#64) = r0

	} :mem_noshuf                           // 4-byte Folded Spill
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_38
	}
// %bb.20:                              // %if.then44.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.21:                              // %if.then44.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB19_39
		r2 = memw(r17+#4)
	}
	{
		jump .LBB19_41
	}
	.falign
.LBB19_22:                              // %if.end30.i61
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.23:                              // %if.end30.i61
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r26 = r0
		r18 = #0
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_48
	}
// %bb.24:                              // %if.then44.i64
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r3 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#52)
		r1:0 = memd(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r5 = r1
		r1:0 = memd(r2+#56)
	}
	{
		r3 = mpyi(r4,r3)
	}
	{
		r4 = lsr(r3,#10)
		r3 = r5
	}
	{
		r1:0 = add(r1:0,r5:4)
		memd(r29+#96) = r3:2
	}                                       // 8-byte Folded Spill
	{
		memd(r2+#56) = r1:0
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.25:                              // %if.then44.i64
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB19_49
		r5 = memw(r17+#4)
	}
	{
		jump .LBB19_51
	}
	.falign
.LBB19_26:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB19_29
		r5 = memw(r17+#4)
	}
	.falign
.LBB19_27:                              // %land.rhs.i.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_29
	}
// %bb.28:                              // %lor.rhs.i.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_29:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r6 = lsr(r21,#1)
		r4 = r19
		r2 = memw(r29+#32)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r1 = add(r5,r6)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = memw(r29+#68)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.30:                              // %moe_weight_src_bypass.exit.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.31:                              // %if.then24.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB19_44
	}
	.falign
.LBB19_32:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:nt .LBB19_35
		r3 = memw(r17+#4)
	}
	.falign
.LBB19_33:                              // %land.rhs.i.i110
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_35
	}
// %bb.34:                              // %lor.rhs.i.i120
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_35:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r0 = r21
		r5:4 = memd(r29+#88)
		memw(r29+#0) = r18
	}                                       // 8-byte Folded Reload
	{
		r2 = add(r5,r21)
		r6 = memw(r29+#32)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r4 = lsr(r2,#1)
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r3,r4)
		r3 = memw(r29+#68)
		r4 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r6,r5)
		call hexkl_dma_ring_push2d
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.36:                              // %moe_weight_src_bypass.exit.i113
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB19_58
	}
// %bb.37:                              // %if.then24.i116
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump .LBB19_54
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_38:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (p0.new) jump:nt .LBB19_41
		r2 = memw(r17+#4)
	}
	.falign
.LBB19_39:                              // %land.rhs.i105.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r3 = memw(r17+#36)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB19_41
	}
// %bb.40:                              // %lor.rhs.i109.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r3,#0)
	}
	.falign
.LBB19_41:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r1 = add(r2,r21)
		r2 = memw(r29+#44)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r21)
		r2 = memw(r29+#48)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r3 = r2
		r4 = memw(r29+#52)
		r5 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.42:                              // %moe_weight_src_bypass.exit112.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.43:                              // %if.then56.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB19_44:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.45:                              // %hexkl_moe_push_weight_chunk.exit
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_4
	}
// %bb.46:                              // %if.then6.i
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3 = #1
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r2 = memw(r29+#64)
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.47:                              // %if.then6.i
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_4
	}
	.falign
.LBB19_48:                              //   in Loop: Header=BB19_2 Depth=1
	{
		r1:0 = combine(#0,#0)
	}
	{
		r2 = memw(r29+#60)
		memd(r29+#104) = r1:0
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB19_51
		r5 = memw(r17+#4)
	}
	.falign
.LBB19_49:                              // %land.rhs.i105.i77
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r18 = #1
		r2 = memw(r17+#36)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB19_51
	}
// %bb.50:                              // %lor.rhs.i109.i87
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r2 = memw(r17+#40)
	}
	{
		r18 = !cmp.eq(r2,#0)
	}
	.falign
.LBB19_51:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r1:0 = combine(r21,r21)
		r2 = memw(r29+#48)
		r7:6 = memd(r29+#88)
	}                                       // 8-byte Folded Reload
	{
		r1 += add(r5,r7)
		r3 = r2
		r5 = memw(r29+#28)
		memw(r29+#0) = r18
	}                                       // 4-byte Folded Reload
	{
		r18 = memw(r29+#56)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#72)
		r4 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r18,r6)
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.52:                              // %moe_weight_src_bypass.exit112.i80
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_7
	}
// %bb.53:                              // %if.then56.i83
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	.falign
.LBB19_54:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.55:                              // %hexkl_moe_push_weight_chunk.exit123
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#96)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#96) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB19_7
	}
// %bb.56:                              // %if.then6.i38
                                        //   in Loop: Header=BB19_2 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r5 = r24
		r2 = memw(r29+#52)
		memw(r29+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#28)
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r3:2 = combine(#2,r26)
		r4 = memw(r29+#48)
		memw(r29+#8) = r4.new
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_trace_push
		r4 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.57:                              // %if.then6.i38
                                        //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_7
	}
	.falign
.LBB19_58:                              //   in Loop: Header=BB19_2 Depth=1
	{
		jump .LBB19_7
		r18 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
.LBB19_59:                              // %for.cond.cleanup
	{
		r17:16 = memd(r29+#160)
		r19:18 = memd(r29+#152)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#144)
		r23:22 = memd(r29+#136)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#128)
		r27:26 = memd(r29+#120)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end19:
	.size	moe_push_gate_up_chunks, .Lfunc_end19-moe_push_gate_up_chunks
                                        // -- End function
	.falign
	.type	moe_m1_q_post,@function         // -- Begin function moe_m1_q_post
moe_m1_q_post:                          // @moe_m1_q_post
// %bb.0:                               // %entry
	{
		r4 = asl(r4,#9)
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r5 = memw(r0+#40)
		r6 = memw(r16+#84)
	}
	{
		r6 = lsr(r4,#1)
		r7 = add(r5,#1)
		p1 = cmp.eq(r6,#2)
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		if (!p1) r6 = add(r4,#0)
		r7 = memw(r16+#44)
		r2 = memw(r2+#4)
	}
	{
		r17 = add(r0,r5)
		p0 = cmp.eq(r7,#0)
	}
	{
		memw(r17+#4) = r2
		memw(r17+#8) = r6
	}
	{
		if (p0) jump:nt .LBB20_3
		memw(r17+#12) = r3
		memw(r0+r5<<#0) = r1
	}
// %bb.1:                               // %if.then
	{
		r0 = memw(r16+#28)
		memw(r17+#8) = ##640
	}
	{
		call hvx_tl2_weight_bytes
		r1 = memw(r16+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r3 = lsr(r2,#9)
		memw(r17+#12) = r3.new
	}
	.falign
.LBB20_3:                               // %if.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_6
	}
// %bb.4:                               // %land.rhs.i
	{
		r2 = memw(r16+#36)
	}
	{
		r2 = #1
		p1 = cmp.eq(r2,#0); if (!p1.new) jump:t .LBB20_7
	}
// %bb.5:                               // %lor.rhs.i
	{
		r2 = memw(r16+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB20_7
	}
	.falign
.LBB20_6:
	{
		r2 = #0
	}
	.falign
.LBB20_7:                               // %moe_weight_src_bypass.exit
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r17+#16) = r2
	}
	{
		r2 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB20_9
	}
// %bb.8:                               // %if.then7
	{
		r1 = #0
		r2 = memw(r17+#8)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		r0 = lsr(r2,#10)
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB20_9:                               // %do.end
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end20:
	.size	moe_m1_q_post, .Lfunc_end20-moe_m1_q_post
                                        // -- End function
	.falign
	.type	moe_m1_push,@function           // -- Begin function moe_m1_push
moe_m1_push:                            // @moe_m1_push
// %bb.0:                               // %entry
	{
		r16 = r5
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r18 = r2
		r2 = memw(r2+#44)
		memd(r29+#32) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		r21:20 = combine(r0,r1)
		memd(r29+#24) = r21:20
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p0) r17 = add(r3,#0)
		if (p0) jump:nt .LBB21_3
		if (p0) r0 = memw(r18+#84)
	}
// %bb.1:                               // %if.then
	{
		call hvx_tl2_weight_bytes
		r0 = memw(r18+#28)
		r1 = memw(r18+#32)
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = ##-858993459
		r19 = #640
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r17 = lsr(r2,#9)
		jump .LBB21_4
	}
	.falign
.LBB21_3:                               // %cond.end3.thread
	{
		r2 = asl(r4,#9)
		p1 = cmp.eq(r0,#2)
	}
	{
		r19 = lsr(r2,#1)
	}
	{
		if (!p1) r19 = add(r2,#0)
	}
	.falign
.LBB21_4:                               // %if.end
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.5:                               // %if.end
	{
		r23 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r3 = mpyi(r17,r19)
		r22 = r0
	}
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_7
	}
// %bb.6:                               // %if.then10
	{
		r1 = #0
		r2 = memw(r23+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r3,#10)
	}
	{
		r5:4 = memd(r2+#56)
	}
	{
		r1:0 = add(r5:4,r1:0)
	}
	{
		memd(r2+#56) = r1:0
	}
	.falign
.LBB21_7:                               // %do.end
	{
		r2 = add(pc,##g_moe_src_bypass@PCREL)
		r1 = memw(r18+#4)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_10
	}
// %bb.8:                               // %land.rhs.i
	{
		r2 = memw(r18+#36)
	}
	{
		r2 = #1
		p0 = cmp.eq(r2,#0); if (!p0.new) jump:t .LBB21_11
	}
// %bb.9:                               // %lor.rhs.i
	{
		r2 = memw(r18+#40)
	}
	{
		r2 = !cmp.eq(r2,#0)
		jump .LBB21_11
	}
	.falign
.LBB21_10:
	{
		r2 = #0
	}
	.falign
.LBB21_11:                              // %moe_weight_src_bypass.exit
	{
		r0 = add(r21,r20)
		r3:2 = combine(r19,r19)
		r5:4 = combine(r17,r19)
		memw(r29+#0) = r2
	}
	{
		call hexkl_dma_ring_push2d
		memw(r29+#4) = #1
	}
	.falign
// %bb.12:                              // %moe_weight_src_bypass.exit
	{
		r2 = memw(r23+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB21_14
	}
// %bb.13:                              // %if.then15
	{
		r4 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		r3:2 = combine(r16,r22)
		r5 = #0
		memw(r29+#0) = r19
		memw(r29+#4) = r17
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r19
	}
	.falign
.LBB21_14:                              // %if.end17
	{
		r0 = r22
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end21:
	.size	moe_m1_push, .Lfunc_end21-moe_m1_push
                                        // -- End function
	.falign
	.type	hexkl_wh_affine_sums,@function  // -- Begin function hexkl_wh_affine_sums
hexkl_wh_affine_sums:                   // @hexkl_wh_affine_sums
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r1,#0)
		allocframe(r29,#128):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		if (p1) jump:nt .LBB22_17
		r31:30 = deallocframe(r30):raw
	}
// %bb.1:                               // %for.body.lr.ph
	{
		r8 = add(r1,#3)
		p0 = cmp.gtu(r2,#31); if (p0.new) jump:t .LBB22_7
		v0 = vxor(v0,v0)
	}
// %bb.2:                               // %for.body.lr.ph.split
	{
		r6 = add(r1,#3)
		v11 = valign(v0,v0,#4)
		r5 = #8
		r7 = #16
	}
	{
		r8 = lsr(r6,#2)
		r6 = #1
		v12.w = vadd(v0.w,v11.w)
	}
	{
		loop0(.LBB22_3,r8)
	}
	{
		r5 = #0
		v13 = vror(v12,r5)
	}
	{
		v14.w = vadd(v12.w,v13.w)
	}
	{
		v15 = vror(v14,r7)
	}
	{
		v1.w = vadd(v14.w,v15.w)
	}
	.falign
.LBB22_3:                               // Block address taken
                                        // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB22_4 Depth 2
	{
		r7 = addasl(r3,r5,#2)
		r8 = addasl(r4,r5,#2)
		r9 = add(r29,#0)
		r12 = #0
	}
	{
		vmem(r29+#0) = v1
	}
	.falign
.LBB22_4:                               // %for.body11
                                        //   Parent Loop BB22_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p0 = cmp.gtu(r12,#2)
		r13 = memw(r7++#4)
		r14 = memw(r9+#0)
	}
	{
		r14 -= mpyi(r13,r2)
		if (p0) jump:nt .LBB22_6
		memw(r8++#4) = r14.new
	}
// %bb.5:                               // %for.body11
                                        //   in Loop: Header=BB22_4 Depth=2
	{
		r13 = add(r6,r12)
		r9 = add(r9,#32)
		r12 = add(r12,#1)
	}
	{
		p1 = cmp.gtu(r1,r13)
		if (p1.new) jump:t .LBB22_4
	}
	.falign
.LBB22_6:                               // %for.cond.cleanup10
                                        //   in Loop: Header=BB22_3 Depth=1
	{
		nop
		r5 = add(r5,#4)
		r6 = add(r6,#4)
	} :endloop0
	{
		jump .LBB22_17
	}
	.falign
.LBB22_7:
	{
		r13 = lsr(r8,#2)
		r5 = lsr(r2,#5)
		r7:6 = combine(#1,#0)
		r9 = #8
	}
	{
		r8 = ##16843009
		r12 = #16
	}
	{
		loop1(.LBB22_8,r13)
	}
	.falign
.LBB22_8:                               // Block address taken
                                        // %for.body.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB22_10 Depth 2
                                        //     Child Loop BB22_14 Depth 2
	{
		r13 = addasl(r0,r6,#5)
		p1 = cmp.gtu(r5,#1)
		if (p1.new) r14 = add(r5,#-2)
		v2 = v0
	}
	{
		r13 = add(r13,#2048)
		if (!p1) jump:nt .LBB22_13
		v3 = vmemu(r13+#0)
	}
// %bb.9:                               // %for.body4.us
                                        //   in Loop: Header=BB22_8 Depth=1
	{
		p0 = cmp.gtu(r5,#2)
		v4 = vmemu(r13+#0)
	}
	{
		loop0(.LBB22_10,r14)
		r13 = add(r13,#2048)
		if (!p0) jump:nt .LBB22_11
		v2 = v0
	}
	.balign 32
.LBB22_10:                              // %for.body4.us
                                        //   Parent Loop BB22_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
		v4 = vmemu(r13+#0)
	}
	{
		r13 = add(r13,#2048)
		nop
	} :endloop0
	.falign
.LBB22_11:                              //   in Loop: Header=BB22_8 Depth=1
	{
		v2.uw += vrmpy(v3.ub,r8.ub)
		v3 = v4
	}
	.falign
.LBB22_13:                              //   in Loop: Header=BB22_8 Depth=1
	{
		r13 = addasl(r3,r6,#2)
		v2.uw += vrmpy(v3.ub,r8.ub)
		r15 = #0
		r28 = add(r29,#0)
	}
	{
		r14 = addasl(r4,r6,#2)
	}
	{
		v5 = valign(v2,v2,#4)
	}
	{
		v6.w = vadd(v2.w,v5.w)
	}
	{
		v7 = vror(v6,r9)
	}
	{
		v8.w = vadd(v6.w,v7.w)
	}
	{
		v9 = vror(v8,r12)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		vmem(r29+#0) = v10.new
	}
	.falign
.LBB22_14:                              // %for.body11.us
                                        //   Parent Loop BB22_8 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		p1 = cmp.gtu(r15,#2)
		r10 = memw(r13++#4)
		r11 = memw(r28+#0)
	}
	{
		r11 -= mpyi(r10,r2)
		if (p1) jump:nt .LBB22_16
		memw(r14++#4) = r11.new
	}
// %bb.15:                              // %for.body11.us
                                        //   in Loop: Header=BB22_14 Depth=2
	{
		r10 = add(r7,r15)
		r28 = add(r28,#32)
		r15 = add(r15,#1)
	}
	{
		p0 = cmp.gtu(r1,r10)
		if (p0.new) jump:t .LBB22_14
	}
	.falign
.LBB22_16:                              // %for.cond.cleanup10.us
                                        //   in Loop: Header=BB22_8 Depth=1
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	.falign
.LBB22_17:                              // %for.cond.cleanup
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end22:
	.size	hexkl_wh_affine_sums, .Lfunc_end22-hexkl_wh_affine_sums
                                        // -- End function
	.falign
	.type	moe_m1_pair_worker,@function    // -- Begin function moe_m1_pair_worker
moe_m1_pair_worker:                     // @moe_m1_pair_worker
// %bb.0:                               // %entry
	{
		r16 = r2
		memd(r29+#-16) = r17:16
		allocframe(#176)
	}                                       // 8-byte Folded Spill
	{
		r19 = add(r2,#8208)
		r22 = r1
		memd(r29+#160) = r19:18
		memd(r29+#144) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r19+#48)
		memd(r29+#152) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r18 = memw(r19+#0)
		memd(r29+#136) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r29+#128) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r16
		r25 = add(r16,#8196)
		r17 = add(r16,#8200)
		r24 = add(r22,#1)
	}
	{
		r2 += asl(r0,#9)
	}
	{
		r2 = memw(r2+#4)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_13
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r2 = memw(r25+#64)
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_udivsi3
		r0 = sub(r2,r23)
	}
	.falign
// %bb.3:                               // %if.then
	{
		r26 = r20
		r2 = memw(r17+#0)
		r3 = memw(r19+#36)
	}
	{
		r2 = add(#127,asl(r2,#1))
		r1 = r26
		r21 = memw(r25+#0)
	}
	{
		r17 = lsr(r2,#7)
	}
	{
		r18 = mpyi(r17,r3)
	}
	{
		r20 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r20,r22)
		call __hexagon_udivsi3
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r20,r24)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r26
	}
	.falign
// %bb.5:                               // %if.then
	{
		r21 = or(#16,asl(r21,#5))
		r25 = r0
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB23_92
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r26 = add(r16,#8252)
		r2 = ##-1431655765
		r20 = r16
	}
	{
		r3 = add(r16,#8244)
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyu(r21,r2)
	}
	{
		r27 = lsr(r2,#4)
	}
	.falign
.LBB23_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r2 = r0
		r16 = r17
		r21 = r19
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r21 -= mpyi(r0,r18)
	}
	{
		r22 = memw(r3+#0)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_udivsi3
		r1:0 = combine(r22,r21)
		r17 = add(r2,r3)
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r21 -= mpyi(r0,r22)
		r23 = r0
		r1 = r22
	}
	{
		r0 = mpyi(r21,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.10:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r24 = r0
		r1 = r22
		r2 = add(r21,#1)
	}
	{
		r0 = mpyi(r2,r27)
		call __hexagon_udivsi3
	}
	.falign
// %bb.11:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r3 = r20
		r4 = r24
		r5 = sub(r0,r24)
		r2 = memw(r26+#0)
	}
	{
		r3 += asl(r17,#9)
		r4 += mpyi(r23,r27)
		r17 = r16
	}
	{
		r23 += mpyi(r21,r16)
		r1 = +mpyi(r5,#24)
	}
	{
		r2 += asl(r24,#9)
		r0 = memw(r3+#12)
		r3 = memw(r3+#28)
	}
	{
		r0 += mpyi(r4,##640)
		r3 += asl(r23,#9)
	}
	{
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.12:                              // %for.body.i
                                        //   in Loop: Header=BB23_7 Depth=1
	{
		r19 = add(r19,#1)
		if (cmp.gtu(r25,r19.new)) jump:t .LBB23_7
	}
	{
		jump .LBB23_92
	}
	.falign
.LBB23_13:                              // %if.end
	{
		r4 = add(r16,#8232)
		r2 = memw(r19+#16)
		memw(r29+#52) = r16
	}                                       // 4-byte Folded Spill
	{
		if (!p0.new) r18 = add(r20,#0)
		p0 = cmp.eq(r2,#0)
		memw(r29+#68) = r17
	}                                       // 4-byte Folded Spill
	{
		r3 = p0
		if (p0) jump:nt .LBB23_15
		memw(r29+#48) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.14:
	{
		p0 = or(p0,!p0)
	}
	{
		r3 = p0
		jump .LBB23_16
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_15:                              // %lor.rhs
	{
		r18 = r20
		r3 = memw(r4+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#44) = r3.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_16:                              // %lor.end
	{
		r5 = #512
		r1:0 = combine(#0,r2)
		r3 = memw(r25+#0)
		r6 = memw(r19+#28)
	}
	{
		r2 = lsr(r5,r6)
		r1:0 = asl(r1:0,#10)
		r21 = #0
		memw(r29+#56) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r3,r2)
	}
	{
		r20 = asl(r2,#1)
	}
	{
		call __hexagon_udivdi3
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.17:                              // %lor.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r5:4 = combine(#0,#0)
		memw(r29+#100) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		memd(r29+#104) = r1:0

	} :mem_noshuf                           // 8-byte Folded Spill
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_20
	}
// %bb.18:                              // %if.then6
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r2,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.19:                              // %if.then6
	{
		r5:4 = combine(r1,r0)
		r23 = memw(r17+#0)
	}
	.falign
.LBB23_20:                              // %do.end
	{
		r20 = r18
		r2 = memw(r25+#64)
		memd(r29+#112) = r5:4
	}                                       // 8-byte Folded Spill
	{
		r16 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r16,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.21:                              // %do.end
	{
		r1:0 = mpyu(r16,r24)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.22:                              // %do.end
	{
		r2 = add(r23,r0)
		r22 = memw(r29+#52)
		memw(r29+#92) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r22,#8236)
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB23_88
		if (p1.new) r1:0 = memd(r29+#104)
	}                                       // 8-byte Folded Reload
// %bb.23:                              // %cond.end
	{
		r3:2 = combine(#127,#1)
		r20 = memw(r19+#0)
	}
	{
		r2 = maxu(r0,r2)
		r1:0 = combine(r20,r17)
	}
	{
		r16 = minu(r2,r3)
		call __hexagon_udivsi3
	}
	.falign
// %bb.24:                              // %cond.end
	{
		r2 = add(r0,#1)
		r3 = add(r17,r16)
		r16 = memw(r29+#100)
		memw(r29+#96) = r16
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r3 = minu(r2,r3)
		memw(r29+#84) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) jump:nt .LBB23_35
	}
// %bb.25:                              // %cond.end
	{
		if (p0.new) r3:2 = combine(r22,r17)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB23_35
		if (p0.new) r4 = memw(r27+#0)
	}
// %bb.26:                              // %if.then17
	{
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r20 = sub(r4,r17)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB23_29
		r3 = r20
		r0 = memw(r3+#4)
	}
// %bb.27:                              // %if.then.i
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.28:                              // %if.then.i
	{
		jump .LBB23_30
	}
	.falign
.LBB23_29:                              // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB23_30:                              // %moe_m1_pf_gu.exit
	{
		r21 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.31:                              // %moe_m1_pf_gu.exit
	{
		r3:2 = combine(r17,r22)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r21)
		p0 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r21)
		r3 = r20
		r5 = memw(r2+#4)
	}
	{
		if (p0) jump:nt .LBB23_34
		r0 = memw(r5+#4)
	}
// %bb.32:                              // %if.then.i329
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.33:                              // %if.then.i329
	{
		jump .LBB23_35
	}
	.falign
.LBB23_34:                              // %if.else.i330
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB23_35:                              // %for.body.lr.ph
	{
		r18 = add(r22,#8228)
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		r0 = add(r22,#8264)
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
		if (p1) r5 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
	}
	{
		if (!p1) r5 = add(r3,#0)
		memw(r29+#80) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#76) = r5
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_36:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB23_41 Depth 2
                                        //       Child Loop BB23_74 Depth 3
                                        //       Child Loop BB23_81 Depth 3
	{
		r17 = memw(r29+#84)
		memw(r29+#60) = r17
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r17)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB23_39
		memw(r29+#88) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.37:                              // %cond.true23
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r20 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.38:                              // %cond.true23
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#96)
		r0 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r2 = minu(r2,r0)
		memw(r29+#84) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_39:                              // %cond.end27
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = memw(r29+#60)
		if (!cmp.gtu(r17,r2.new)) jump:t ##.LBB23_87
	}                                       // 4-byte Folded Reload
// %bb.40:                              // %for.body33.lr.ph
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r21 = memw(r29+#60)
		r2 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,r17)
		r3 = sub(r2,r17)
		memw(r29+#64) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB23_41:                              // %for.body33
                                        //   Parent Loop BB23_36 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB23_74 Depth 3
                                        //       Child Loop BB23_81 Depth 3
	{
		r23 = memw(r19+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r21)
	}
	.falign
// %bb.42:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r24 = r0
		r16 = r22
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r16 += asl(r0,#9)
		p0 = r2
	}
	{
		if (p0) jump:nt .LBB23_50
		r20 = memw(r16+#28)
	}
// %bb.43:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#60)
		if (!cmp.eq(r2.new,r21)) jump:nt .LBB23_50
	}                                       // 4-byte Folded Reload
// %bb.44:                              // %for.body33
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) r1:0 = combine(r23,r17)
		if (!p0.new) jump:nt .LBB23_50
	}
// %bb.45:                              // %if.then48
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.46:                              // %if.then48
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3:2 = combine(r22,r17)
		r4 = memw(r27+#0)
		r1 = memw(r27+#-24)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r23)
		p1 = cmp.eq(r4,#0)
		r4 = memw(r25+#0)
	}
	{
		r3 = memw(r3+#4)
	}
	{
		if (p1) jump:nt .LBB23_49
		r0 = memw(r3+#4)
		if (!p1) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.47:                              // %if.then.i352
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.48:                              // %if.then.i352
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_50
	}
	.falign
.LBB23_49:                              // %if.else.i353
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
		r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_50:                              // %if.end49
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r22 = r21
	}
	{
		r22 -= mpyi(r24,r23)
	}
	{
		r0 = asl(r22,#10)
	}
	{
		r23 = add(r20,r0)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_54
	}
// %bb.51:                              // %land.lhs.true53
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r5 = add(r16,#128)
		r0 = memw(r16+#0)
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r16+#388)
		r3 = memw(r16+#12)
	}
	{
		r2 = memw(r2+#0)
		r4 = memw(r27+#-24)
	}
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB23_56
		r2 = memw(r25+#0)
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then57
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r19+#0)
		r7 = memw(r18+#0)
	}
	{
		r5 = r22
		r7 = add(r23,#512)
		memw(r29+#8) = r5
		memw(r29+#4) = r7
	}
	{
		r6 = add(r6,r22)
		memw(r29+#12) = r23
		memw(r29+#16) = r7
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#0) = r6
	}
	.falign
// %bb.53:                              // %if.then57
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_57
	}
	.falign
.LBB23_54:                              // %if.else75
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r5 = memw(r18+#0)
	}
	{
		r1 = memw(r16+#388)
		r2 = memw(r25+#0)
	}
	{
		r3 = memw(r16+#12)
		r4 = memw(r27+#-24)
	}
	{
		r5 = r22
		r6 = memw(r29+#76)
		memw(r29+#0) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r23
	}
	{
		callr r6
	}
	.falign
// %bb.55:                              // %if.else75
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_57
		r20 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
.LBB23_56:                              // %if.then64
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r18+#0)
		memw(r29+#0) = r6.new
	}
	{
		r5 = r22
		r6 = memw(r29+#80)
		memw(r29+#4) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r23
	}
	{
		callr r6
	}
	.falign
.LBB23_57:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r21 = add(r21,#1)
		r0 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r21,r17)
	}
	{
		r2 = p1
		p1 = r0
		if (p1.new) jump:nt .LBB23_63
		memw(r29+#44) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.58:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#104)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB23_63
		if (p1.new) r2 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
// %bb.59:                              // %if.end85
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = r2
		if (!p0.new) jump:nt .LBB23_63
		if (p0.new) r24 = memw(r19+#0)
	}
// %bb.60:                              // %if.then94
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r17)
	}
	.falign
// %bb.61:                              // %if.then94
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3 = r17
		r2 = memw(r29+#52)
		r4 = memw(r27+#0)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r0,#9)
		r3 -= mpyi(r0,r24)
		p0 = cmp.eq(r4,#0)
		r1 = memw(r27+#-24)
	}
	{
		r4 = memw(r25+#0)
	}
	{
		r2 = add(r3,r24)
		r5 = memw(r2+#4)
		if (!p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB23_67
		r0 = memw(r5+#4)
		if (p0) r3 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %if.then.i367
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB23_63:                              // %if.end95
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_69
	}
	.falign
.LBB23_64:                              // %land.lhs.true99
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB23_70
	}
// %bb.65:                              // %if.then108
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = add(r16,#128)
		memw(r29+#8) = r6
	}
	{
		r6 = memw(r29+#80)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.66:                              // %if.then108
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		jump .LBB23_70
	}
	.falign
.LBB23_67:                              // %if.else.i368
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.68:                              // %if.else.i368
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB23_64
	}
	.falign
.LBB23_69:                              // %if.else122
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r0 = memw(r16+#0)
		r6 = memw(r18+#0)
	}
	{
		r5 = memw(r19+#0)
		r1 = memw(r16+#388)
	}
	{
		r5 = add(r5,r22)
		r2 = memw(r25+#0)
		r3 = memw(r16+#12)
	}
	{
		r6 = add(r23,#512)
		r4 = memw(r27+#-24)
		memw(r29+#0) = r6

	} :mem_noshuf
	{
		r6 = memw(r29+#76)
		memw(r29+#4) = r6
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
.LBB23_70:                              // %if.end135
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r2 = memw(r4+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_85
	}
// %bb.71:                              // %if.then138
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r3 = asl(r22,#5)
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB23_85
	}
// %bb.72:                              // %for.body.us.i
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r9 = lsr(r5,#1)
		r5 = r23
		r4 = and(r5,#1)
	}
	{
		r7 = addasl(r2,r3,#2)
		r2 = add(r16,#56)
		p1 = cmp.gtu(r9,#0)
		if (p1.new) r5 = add(r23,#0)
	}
	{
		if (p1) r8 = add(r2,#0)
		r6 = r2
	}
	{
		if (!p1) jump:nt .LBB23_75
		v0 = vmemu(r7+#0)
	}
// %bb.73:                              //   in Loop: Header=BB23_41 Depth=2
	{
		loop0(.LBB23_74,r9)
		r7:6 = combine(r23,r2)
	}
	.balign 32
.LBB23_74:                              //   Parent Loop BB23_36 Depth=1
                                        //     Parent Loop BB23_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r6++#8)
	}
	{
		v2 = vsplat(r9)
		v3 = vmemu(r7+#0)
	}
	{
		v5 = vmemu(r7+#1)
	}
	{
		v3.w += vmpyie(v2.w,v0.h)
	}
	{
		vmemu(r5++#2) = v3
	}
	{
		r8 = memw(r8+#4)
	}
	{
		v4 = vsplat(r8)
		r8 = r6
	}
	{
		v5.w += vmpyie(v4.w,v0.h)
	}
	{
		r7 = r5
		vmemu(r7+#1) = v5
	} :endloop0
	.falign
.LBB23_75:                              //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = cmp.gtu(r4,#0); if (!p0.new) jump:t .LBB23_77
		if (p0.new) r4 = memw(r6+#0)
	}
	.falign
.LBB23_76:                              // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		v6 = vsplat(r4)
		v7 = vmemu(r5+#0)
	}
	{
		v7.w += vmpyie(v6.w,v0.h)
	}
	{
		vmemu(r5++#1) = v7
	}
	.falign
.LBB23_77:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	{
		r6 = memw(r4+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB23_85
	}
// %bb.78:                              // %hexkl_wh_affine_acc.exit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r5 = memw(r16+#388)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB23_85
	}
// %bb.79:                              // %for.body.us.i376
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r7 = lsr(r5,#1)
		r5 = and(r5,#1)
		r4 = memw(r20+#0)
	}
	{
		r4 = addasl(r6,r4,#2)
		r6 = add(r23,#512)
		p1 = cmp.gtu(r7,#0)
	}
	{
		r3 = addasl(r4,r3,#2)
		r4 = r2
	}
	{
		r3 = r6
		if (!p1) jump:nt .LBB23_82
		v1 = vmemu(r3+#0)
	}
// %bb.80:                              //   in Loop: Header=BB23_41 Depth=2
	{
		loop0(.LBB23_81,r7)
	}
	.balign 32
.LBB23_81:                              //   Parent Loop BB23_36 Depth=1
                                        //     Parent Loop BB23_41 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r4++#8)
	}
	{
		v8 = vsplat(r7)
		v9 = vmemu(r6+#0)
	}
	{
		v11 = vmemu(r6+#1)
	}
	{
		v9.w += vmpyie(v8.w,v1.h)
	}
	{
		vmemu(r3++#2) = v9
	}
	{
		r2 = memw(r2+#4)
	}
	{
		v10 = vsplat(r2)
		r2 = r4
	}
	{
		v11.w += vmpyie(v10.w,v1.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v11
	} :endloop0
	.falign
.LBB23_82:                              //   in Loop: Header=BB23_41 Depth=2
	{
		p0 = cmp.gtu(r5,#0); if (!p0.new) jump:t .LBB23_84
		if (p0.new) r2 = memw(r4+#0)
	}
	.falign
.LBB23_83:                              // Block address taken
                                        // %for.body3.us.i379
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		v12 = vsplat(r2)
		v13 = vmemu(r3+#0)
	}
	{
		v13.w += vmpyie(v12.w,v1.h)
	}
	{
		vmemu(r3++#1) = v13
	}
	.falign
.LBB23_84:                              // %if.end154.loopexit
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r4 = memw(r16+#4)
	}
	.falign
.LBB23_85:                              // %if.end154
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r6 = memw(r29+#72)
		r5 = memw(r16+#388)
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r4+#8)
		r2 = memw(r16+#20)
	}
	{
		r3 = memw(r16+#24)
		r4 = memw(r4+#16)
	}
	{
		r6 = memw(r6+#0)
		r7 = memw(r16+#36)
	}
	{
		r4 = #32
		r8 = memw(r20+#0)
		memw(r29+#16) = r4

	} :mem_noshuf
	{
		r0 = r23
		r1 = #512
		memw(r29+#12) = r0
		memw(r29+#8) = r1
	}
	{
		r3:2 = combine(r22,#1)
		memw(r29+#4) = r3
		memw(r29+#0) = r2
	}
	{
		memw(r29+#36) = #0
		memw(r29+#32) = r8
	}
	{
		memw(r29+#28) = r7
		memw(r29+#24) = r6
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#20) = r8
	}
	.falign
// %bb.86:                              // %if.end154
                                        //   in Loop: Header=BB23_41 Depth=2
	{
		r2 = memw(r29+#44)
		r22 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB23_41
	}
	.falign
.LBB23_87:                              // %for.cond.loopexit
                                        //   in Loop: Header=BB23_36 Depth=1
	{
		r2 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB23_36
	}
	.falign
.LBB23_88:                              // %for.cond.cleanup
	{
		r16 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB23_92
	}
// %bb.89:                              // %if.then.i332
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.90:                              // %if.then.i332
	{
		r3:2 = memd(r29+#112)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB23_91:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB23_91
	}
	.falign
.LBB23_92:                              // %cleanup
	{
		r17:16 = memd(r29+#168)
		r19:18 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#152)
		r23:22 = memd(r29+#144)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#136)
		r27:26 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end23:
	.size	moe_m1_pair_worker, .Lfunc_end23-moe_m1_pair_worker
                                        // -- End function
	.falign
	.type	moe_m1_q_post_after_a,@function // -- Begin function moe_m1_q_post_after_a
moe_m1_q_post_after_a:                  // @moe_m1_q_post_after_a
// %bb.0:                               // %entry
	{
		r6 = add(r2,#2)
		r14 = #640
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(r1,#8192)
		r16 = ##-858960692
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r7 = memw(r20+#0)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r7,r6)
		memd(r29+#32) = r23:22
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (!p1) r22 = add(r1,##8204)
		if (!p1) jump:nt .LBB24_7
		memd(r29+#16) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r1 += asl(r6,#9)
		p0 = tstbit(r2,#0)
		r5 = memw(r0+#40)
		r2 = memw(r20+#20)
	}
	{
		r6 = asl(r2,#9)
		r7 = add(r5,#1)
		if (!p0) r4 = #0
		memw(r0+#40) = r7.new
	}
	{
		r5 = +mpyi(r5,#20)
		r3 = add(r3,r4)
		r19 = memw(r1+#4)
		r2 = memw(r20+#4)
	}
	{
		r4 = lsr(r6,#1)
		r18 = add(r0,r5)
	}
	{
		r3 = memw(r19+#84)
		memw(r0+r5<<#0) = r3
	}
	{
		p1 = cmp.eq(r3,#2)
		r0 = memw(r19+#44)
		r3 = memw(r19+#4)
	}
	{
		p0 = cmp.eq(r0,#0)
		if (!p1) r4 = add(r6,#0)
		memw(r18+#4) = r3
		memw(r18+#12) = r2
	}
	{
		if (p0) jump:nt .LBB24_4
		if (!p0) r0 = memw(r19+#28)
		memw(r18+#8) = r4
	}
// %bb.2:                               // %if.then.i
	{
		r1 = memw(r19+#32)
		memw(r18+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.3:                               // %if.then.i
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r18+#12) = r2.new
	}
	.falign
.LBB24_4:                               // %if.end.i
	{
		r3 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_14
	}
// %bb.5:                               // %land.rhs.i.i
	{
		r3 = memw(r19+#36)
	}
	{
		r3 = #1
		p0 = cmp.eq(r3,#0); if (!p0.new) jump:t .LBB24_15
	}
// %bb.6:                               // %lor.rhs.i.i
	{
		r3 = memw(r19+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB24_15
	}
	.falign
.LBB24_7:                               // %if.end
	{
		r17 = add(pc,##g_moe_src_bypass@PCREL)
		r2 = and(#2,asl(r2,#1))
		r25 = add(r1,#8216)
	}
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		p0 = cmp.gtu(r7,r2)
		p2 = cmp.eq(r2,#0)
	}
	{
		r7 = r1
		if (!p0) jump:nt .LBB24_20
		if (p0) r8 = memw(r0+#40)
		if (p0) r6 = memw(r25+#0)
	}
// %bb.8:                               // %if.then9
	{
		r7 += asl(r2,#9)
		r12 = asl(r6,#9)
		r9 = mux(p2,#0,r4)
		r6 = memw(r22+#0)
	}
	{
		r13 = +mpyi(r8,#20)
		r8 = add(r8,#1)
		r10 = add(r3,r9)
		memw(r0+#40) = r8.new
	}
	{
		r23 = add(r0,r13)
		r24 = memw(r7+#8)
	}
	{
		memw(r0+r13<<#0) = r10
		memw(r23+#12) = r6
	}
	{
		r7 = memw(r24+#84)
		r11 = memw(r24+#44)
	}
	{
		r7 = lsr(r12,#1)
		p0 = cmp.eq(r7,#2)
		p1 = cmp.eq(r11,#0)
		r13 = memw(r24+#4)
	}
	{
		if (!p0) r7 = add(r12,#0)
		memw(r23+#4) = r13
	}
	{
		if (p1) jump:nt .LBB24_11
		memw(r23+#8) = r7
	}
// %bb.9:                               // %if.then.i49
	{
		r27:26 = combine(r3,r1)
		r21 = r18
		r6 = memw(r24+#28)
		memw(r29+#4) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = p2
		r0 = r6
		r19:18 = combine(r2,r17)
		r6 = memw(r24+#32)
	}
	{
		r1 = r6
		r17:16 = combine(r4,r5)
		memw(r23+#8) = r14
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Spill
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.10:                              // %if.then.i49
	{
		r5:4 = combine(r16,r17)
		r16 = ##-858960692
		r2 = memw(r29+#0)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r7 = add(r16,#-32767)
		r6 = r0
		r0 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r6 = mpyu(r6,r7)
		r17 = r18
		r14 = #640
		r3:2 = combine(r27,r19)
	}
	{
		r6 = lsr(r6,#9)
		r18 = r21
		r1 = r26
		memw(r23+#12) = r6.new
	}
	.falign
.LBB24_11:                              // %if.end.i54
	{
		r7 = memw(r17+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_17
	}
// %bb.12:                              // %land.rhs.i.i56
	{
		r7 = memw(r24+#36)
	}
	{
		r7 = #1
		p1 = cmp.eq(r7,#0); if (!p1.new) jump:t .LBB24_18
	}
// %bb.13:                              // %lor.rhs.i.i68
	{
		r7 = memw(r24+#40)
	}
	{
		r7 = !cmp.eq(r7,#0)
		jump .LBB24_18
	}
	.falign
.LBB24_14:
	{
		r3 = #0
	}
	.falign
.LBB24_15:                              // %moe_weight_src_bypass.exit.i
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memw(r18+#16) = r3
	}
	{
		r3 = memw(r4+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_31
	}
// %bb.16:
	{
		r3 = add(r18,#8)
		jump .LBB24_30
	}
	.falign
.LBB24_17:
	{
		r7 = #0
	}
	.falign
.LBB24_18:                              // %moe_weight_src_bypass.exit.i59
	{
		memw(r23+#16) = r7
	}
	{
		r7 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r7 = memw(r7+#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB24_20
	}
// %bb.19:                              // %if.then7.i63
	{
		r7 = memw(r23+#8)
		r8 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r6 = mpyi(r7,r6)
		r7 = #0
		r13:12 = memd(r8+#56)
	}
	{
		r6 = lsr(r6,#10)
	}
	{
		r7:6 = add(r13:12,r7:6)
	}
	{
		memd(r8+#56) = r7:6
	}
	.falign
.LBB24_20:                              // %for.inc
	{
		r2 = setbit(r2,#0)
	}
	{
		r1 += asl(r2,#9)
		r6 = memw(r20+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t .LBB24_31
	}
// %bb.21:                              // %if.then9.1
	{
		r7 = mux(p2,#0,r4)
		r6 = memw(r0+#40)
		r2 = memw(r25+#0)
	}
	{
		r8 = asl(r2,#9)
		r4 = add(r6,#1)
		memw(r0+#40) = r4.new
	}
	{
		r6 = +mpyi(r6,#20)
		r5 += add(r3,r7)
		r21 = memw(r1+#8)
		r2 = memw(r22+#0)
	}
	{
		r4 = lsr(r8,#1)
		r20 = add(r0,r6)
	}
	{
		r3 = memw(r21+#84)
		memw(r0+r6<<#0) = r5
	}
	{
		p0 = cmp.eq(r3,#2)
		r0 = memw(r21+#44)
		r3 = memw(r21+#4)
	}
	{
		p1 = cmp.eq(r0,#0)
		if (!p0) r4 = add(r8,#0)
		memw(r20+#4) = r3
		memw(r20+#12) = r2
	}
	{
		if (p1) jump:nt .LBB24_24
		if (!p1) r0 = memw(r21+#28)
		memw(r20+#8) = r4
	}
// %bb.22:                              // %if.then.i49.1
	{
		r1 = memw(r21+#32)
		memw(r20+#8) = r14
	}
	{
		call hvx_tl2_weight_bytes
	}
	.falign
// %bb.23:                              // %if.then.i49.1
	{
		r2 = add(r16,#-32767)
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#9)
		memw(r20+#12) = r2.new
	}
	.falign
.LBB24_24:                              // %if.end.i54.1
	{
		r3 = memw(r17+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_27
	}
// %bb.25:                              // %land.rhs.i.i56.1
	{
		r3 = memw(r21+#36)
	}
	{
		r3 = #1
		p1 = cmp.eq(r3,#0); if (!p1.new) jump:t .LBB24_28
	}
// %bb.26:                              // %lor.rhs.i.i68.1
	{
		r3 = memw(r21+#40)
	}
	{
		r3 = !cmp.eq(r3,#0)
		jump .LBB24_28
	}
	.falign
.LBB24_27:
	{
		r3 = #0
	}
	.falign
.LBB24_28:                              // %moe_weight_src_bypass.exit.i59.1
	{
		memw(r20+#16) = r3
	}
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB24_31
	}
// %bb.29:
	{
		r3 = add(r20,#8)
	}
	.falign
.LBB24_30:                              // %for.end.sink.split
	{
		r4 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r1 = #0
		r3 = memw(r3+#0)
	}
	{
		r2 = mpyi(r3,r2)
		r4 = memw(r4+##hexkl_probe_us@GOT)
	}
	{
		r0 = lsr(r2,#10)
	}
	{
		r3:2 = memd(r4+#56)
	}
	{
		r1:0 = add(r3:2,r1:0)
	}
	{
		memd(r4+#56) = r1:0
	}
	.falign
.LBB24_31:                              // %for.end
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end24:
	.size	moe_m1_q_post_after_a, .Lfunc_end24-moe_m1_q_post_after_a
                                        // -- End function
	.falign
	.type	moe_tl2_gate_epilogue_worker,@function // -- Begin function moe_tl2_gate_epilogue_worker
moe_tl2_gate_epilogue_worker:           // @moe_tl2_gate_epilogue_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#640):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r2 = add(r2,#8196)
		memd(r30+#-8) = r17:16
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r18 = r0
		r19 = add(r16,#8200)
		r3 = memw(r2+#12)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r3,#48)
		r20 = add(r16,#8244)
		r4 = memw(r2+#64)
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r21 = add(r16,#8264)
		r22 = memw(r2+#60)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r23 = sub(r4,r22)
		if (p1) r4 = add(r22,#0)
		if (!p1) jump:nt .LBB25_18
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p0 = cmp.eq(r23,#48)
		if (p0.new) r3 = ##-1431655765
		if (!p0.new) jump:nt .LBB25_18
	}
// %bb.2:                               // %entry
	{
		r3 = mpyu(r22,r3)
	}
	{
		r3 = lsr(r3,#5)
	}
	{
		r4 -= mpyi(r3,#48)
		if (!cmp.eq(r4.new,#0)) jump:nt .LBB25_18
	}
// %bb.3:                               // %land.lhs.true7
	{
		r4 = memw(r2+#44)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB25_18
	}
// %bb.4:                               // %lor.lhs.false.i
	{
		r4 = #64
	}
	{
		r4 = memw(r2+#0)
		if (!cmp.eq(r4.new,r4)) jump:t .LBB25_18
	}
// %bb.5:                               // %lor.lhs.false1.i
	{
		r4 = #1536
	}
	{
		r4 = memw(r19+#0)
		if (!cmp.eq(r4.new,r4)) jump:t .LBB25_18
	}
// %bb.6:                               // %lor.lhs.false5.i
	{
		r2 = memw(r2+#24)
	}
	{
		p1 = cmp.eq(r2,##2048)
		if (p1.new) r24 = add(r16,#0)
		if (!p1.new) jump:t .LBB25_18
	}
// %bb.7:                               // %lor.lhs.false7.i
	{
		r2 = memw(r20+#0)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB25_18
	}
// %bb.8:                               // %lor.lhs.false9.i
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB25_18
	}
// %bb.9:                               // %lor.lhs.false11.i
	{
		r24 += asl(r3,#9)
	}
	{
		r2 = memw(r24+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB25_18
	}
// %bb.10:                              // %lor.lhs.false13.i
	{
		r25 = memw(r24+#4)
	}
	{
		r2 = memw(r25+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_18
	}
// %bb.11:                              // %lor.lhs.false15.i
	{
		r26 = memw(r24+#8)
	}
	{
		r2 = memw(r26+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB25_18
	}
// %bb.12:                              // %lor.lhs.false18.i
	{
		call htp_tl2_palette_magnitude
		r0 = add(r25,#88)
	}
	.falign
// %bb.13:                              // %lor.lhs.false18.i
	{
		if (p1.new) r0 = add(r26,#88)
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB25_18
	}
// %bb.14:                              // %lor.lhs.false21.i
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.15:                              // %lor.lhs.false21.i
	{
		r5:4 = combine(#0,#48)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB25_18
		if (p0.new) r3:2 = memd(r24+#24)
	}
// %bb.16:                              // %if.end.i
	{
		r1:0 = combine(r17,r18)
		r6 = #1536
		r7 = memw(r24+#20)
		memw(r29+#268) = r5
	}
	{
		r2 = #32
		r3 = #128
		memw(r29+#284) = r2
		memw(r29+#256) = r3
	}
	{
		r2 = #1
		memw(r29+#272) = r2
		memw(r29+#280) = r7
	}
	{
		memw(r29+#276) = r2
		memw(r29+#260) = r3
	}
	{
		r2 = add(r29,#256)
		memw(r29+#264) = r4
	}
	{
		r3 = memw(r25+#12)
	}
	{
		memw(r29+#288) = r3
		r3 = memw(r25+#8)

	} :mem_noshuf
	{
		memw(r29+#292) = r3
		r3 = memw(r25+#16)

	} :mem_noshuf
	{
		r3 = memw(r24+#36)
		memw(r29+#296) = r3
	}
	{
		memw(r29+#300) = r6
		memw(r29+#308) = r6
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#312) = r5
		memw(r29+#304) = r3
	}
	.falign
// %bb.17:                              // %if.end.i
	{
		jump .LBB25_89
	}
	.falign
.LBB25_18:                              // %if.end
	{
		r0 = mpyi(r23,r17)
		call __hexagon_udivsi3
		r1 = r18
	}
	.falign
// %bb.19:                              // %if.end
	{
		r17 = add(r0,r22)
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r23,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.20:                              // %if.end
	{
		r23 = add(r16,#8208)
		r22 = add(r0,r22)
		if (!cmp.gtu(r22.new,r17)) jump:t ##.LBB25_89
	}
// %bb.21:                              // %for.body.lr.ph.i
	{
		r24 = #3
		r2 = memw(r19+#0)
	}
	{
		r2 = add(#127,asl(r2,#1))
	}
	{
		r25 = and(r2,#-128)
	}
	.falign
.LBB25_22:                              // %for.body.i
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB25_26 Depth 2
                                        //     Child Loop BB25_30 Depth 2
                                        //     Child Loop BB25_58 Depth 2
                                        //     Child Loop BB25_62 Depth 2
	{
		r18 = memw(r23+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.23:                              // %for.body.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r3:2 = combine(r16,r17)
		r5 = #1
		r6 = memw(r20+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB25_32
		v0 = vmem(r4+#0)
	}
// %bb.24:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = mpyi(r5,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB25_28
	}
// %bb.25:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_26,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r4,r13,#2)
		v3.w = vadd(v0.w,v23.w)
		v23.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB25_27
	}
	.falign
.LBB25_26:                              //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r25)
		v25.w = vadd(v3.w,v24.w)
		v24.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v26 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r5,#3)
		v27.w = vadd(v25.w,v26.w)
		v28 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r5 = add(r5,#4)
		v29.w = vadd(v27.w,v28.w)
		v30 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r4,r9,#2)
		v3.w = vadd(v29.w,v30.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_27:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = addasl(r4,r12,#2)
		v0.w = vadd(v3.w,v31.w)
		v31.cur = vmem(r13+#0)
	}
	{
		v2.w = vadd(v0.w,v1.w)
		v1.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v2.w,v3.w)
		v3.cur = vmem(r12+#0)
	}
	.falign
.LBB25_28:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = mpyi(r5,r25)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB25_32
	}
// %bb.29:                              // %for.body13.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB25_30,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB25_31
	}
	.balign 32
.LBB25_30:                              // %for.body13.i
                                        //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r5,r25)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v4.w)
		v4.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_31:                              //   in Loop: Header=BB25_22 Depth=1
	{
		v0.w = vadd(v0.w,v5.w)
		v5.cur = vmem(r8+#0)
	}
	.falign
.LBB25_32:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r5 = memw(r3+#4)
		vmem(r29+#2) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r19+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB25_35
	}
// %bb.33:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB25_35
	}
// %bb.34:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_35:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_40
	}
// %bb.36:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_38
	}
// %bb.37:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_38:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		if (p1) jump:nt .LBB25_41
	}
// %bb.39:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_41
	}
	.falign
.LBB25_40:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_41:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB25_46
	}
// %bb.42:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB25_44
	}
// %bb.43:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB25_55
	}
	.falign
.LBB25_44:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB25_47
	}
// %bb.45:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_47
	}
	.falign
.LBB25_46:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r8 = r9
	}
	.falign
.LBB25_47:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB25_52
	}
// %bb.48:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB25_50
	}
// %bb.49:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB25_55
	}
	.falign
.LBB25_50:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB25_53
	}
// %bb.51:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB25_55
	}
	{
		jump .LBB25_53
	}
	.falign
.LBB25_52:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = r8
	}
	.falign
.LBB25_53:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB25_55
		v4.w = vasl(v0.w,r24)
	}
// %bb.54:                              // %if.end.i.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		v5.w = vsub(v4.w,v0.w)
		vmem(r29+#2) = v5.new
	}
	.falign
.LBB25_55:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB25_64
		v1 = vmem(r7+#0)
	}
// %bb.56:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = mpyi(r6,r25)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB25_60
	}
// %bb.57:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r25)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB25_58,r9)
		r14 = mpyi(r14,r25)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r25)
		r13 = addasl(r7,r13,#2)
		v2.w = vadd(v1.w,v6.w)
		v6.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB25_59
	}
	.falign
.LBB25_58:                              //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r25)
		v8.w = vadd(v2.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v9 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r25)
		r12 = add(r6,#3)
		v10.w = vadd(v8.w,v9.w)
		v11 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r25)
		r6 = add(r6,#4)
		v12.w = vadd(v10.w,v11.w)
		v13 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r25)
		r9 = addasl(r7,r9,#2)
		v2.w = vadd(v12.w,v13.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB25_59:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r12 = addasl(r7,r12,#2)
		v15.w = vadd(v2.w,v14.w)
		v14.cur = vmem(r13+#0)
	}
	{
		v17.w = vadd(v15.w,v16.w)
		v16.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v17.w,v18.w)
		v18.cur = vmem(r12+#0)
	}
	.falign
.LBB25_60:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r9 = mpyi(r6,r25)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB25_64
	}
// %bb.61:                              // %for.body13.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB25_62,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB25_63
	}
	.balign 32
.LBB25_62:                              // %for.body13.1.i
                                        //   Parent Loop BB25_22 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r8 = mpyi(r6,r25)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v19.w)
		v19.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB25_63:                              //   in Loop: Header=BB25_22 Depth=1
	{
		v1.w = vadd(v1.w,v20.w)
		v20.cur = vmem(r8+#0)
	}
	.falign
.LBB25_64:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		vmem(r29+#3) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_67
	}
// %bb.65:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_67
	}
// %bb.66:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB25_87
	}
	.falign
.LBB25_67:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_72
	}
// %bb.68:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_70
	}
// %bb.69:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_87
	}
	.falign
.LBB25_70:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		if (p0) jump:nt .LBB25_73
	}
// %bb.71:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_73
	}
	.falign
.LBB25_72:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_73:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB25_78
	}
// %bb.74:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB25_76
	}
// %bb.75:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB25_87
	}
	.falign
.LBB25_76:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB25_79
	}
// %bb.77:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_79
	}
	.falign
.LBB25_78:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r6 = r7
	}
	.falign
.LBB25_79:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB25_84
	}
// %bb.80:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB25_82
	}
// %bb.81:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB25_87
	}
	.falign
.LBB25_82:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB25_85
	}
// %bb.83:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB25_87
	}
	{
		jump .LBB25_85
	}
	.falign
.LBB25_84:                              //   in Loop: Header=BB25_22 Depth=1
	{
		r7 = r6
	}
	.falign
.LBB25_85:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB25_87
		v21.w = vasl(v1.w,r24)
	}
// %bb.86:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		v22.w = vsub(v21.w,v1.w)
		vmem(r29+#3) = v22.new
	}
	.falign
.LBB25_87:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#256)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.88:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB25_22 Depth=1
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r22)) jump:t ##.LBB25_22
	}
	.falign
.LBB25_89:                              // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end25:
	.size	moe_tl2_gate_epilogue_worker, .Lfunc_end25-moe_tl2_gate_epilogue_worker
                                        // -- End function
	.falign
	.type	moe_m1_wait,@function           // -- Begin function moe_m1_wait
moe_m1_wait:                            // @moe_m1_wait
// %bb.0:                               // %entry
	{
		r17 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#8)
	}                                       // 8-byte Folded Spill
	{
		r16 = r0
	}
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_2
	}
// %bb.1:                               // %if.then
	{
		r3 = r1
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call hexkl_dma_trace_wait_begin
		r2 = r16
	}
	.falign
.LBB26_2:                               // %if.end
	{
		call hexkl_dma_ring_wait
		r0 = r16
	}
	.falign
// %bb.3:                               // %if.end
	{
		r2 = memw(r17+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB26_5
	}
// %bb.4:                               // %if.then2
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		jump hexkl_dma_trace_wait_end
		r17:16 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
	.falign
.LBB26_5:                               // %if.end4
	{
		r17:16 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end26:
	.size	moe_m1_wait, .Lfunc_end26-moe_m1_wait
                                        // -- End function
	.falign
	.type	moe_m1_requant_worker,@function // -- Begin function moe_m1_requant_worker
moe_m1_requant_worker:                  // @moe_m1_requant_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r23 = add(r2,#8192)
		r17 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		r25:24 = combine(#0,r0)
		r16 = memw(r23+#0)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r19 = r2
		r3:2 = combine(r25,r24)
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r1:0 = mpyu(r16,r1)
		call __hexagon_udivdi3
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = add(r17,#1)
		r3 = r25
		r21:20 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r16,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r25,r24)
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
	.falign
// %bb.2:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r20)
		if (p0.new) r25 = add(r19,##8200)
	}
	{
		if (p0) r26 = ##16843009
		if (!p0) jump:nt .LBB27_119
		memd(r29+#240) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.3:                               // %for.body.lr.ph
	{
		r21 = #8
		r22 = #16
		v20 = vxor(v20,v20)
		vmem(r29+#2) = v20.new
	}                                       // 128-byte Folded Spill
	{
		memw(r29+#236) = r23
	}                                       // 4-byte Folded Spill
	{
		v7 = valign(v20,v20,#4)
	}
	{
		v8.w = vadd(v20.w,v7.w)
	}
	{
		v9 = vror(v8,r21)
	}
	{
		v10.w = vadd(v8.w,v9.w)
	}
	{
		v11 = vror(v10,r22)
	}
	{
		v22.w = vadd(v10.w,v11.w)
		vmem(r29+#3) = v22.new
	}                                       // 128-byte Folded Spill
	.falign
.LBB27_4:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB27_24 Depth 2
                                        //       Child Loop BB27_28 Depth 3
                                        //       Child Loop BB27_32 Depth 3
                                        //       Child Loop BB27_60 Depth 3
                                        //       Child Loop BB27_64 Depth 3
                                        //     Child Loop BB27_110 Depth 2
                                        //       Child Loop BB27_112 Depth 3
                                        //       Child Loop BB27_116 Depth 3
                                        //     Child Loop BB27_105 Depth 2
                                        //       Child Loop BB27_106 Depth 3
	{
		r17:16 = combine(r20,r19)
	}
	{
		r16 += asl(r20,#9)
		r20 = add(r20,#1)
	}
	{
		r18 = memw(r16+#4)
	}
	{
		r2 = memw(r18+#44)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_92
	}
// %bb.5:                               // %land.lhs.true
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r27 = add(r19,#8208)
		r2 = memw(r23+#56)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB27_92
	}
// %bb.6:                               // %land.lhs.true2
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r22 = add(r19,#8244)
		r21 = add(r19,#8264)
	}
	{
		r2 = memw(r23+#48)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_21
	}
// %bb.7:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r24 = memw(r25+#0)
	}
	{
		r2 = memw(r23+#4)
		if (!cmp.eq(r2.new,r2)) jump:nt .LBB27_22
	}
// %bb.8:                               // %lor.lhs.false.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #48
		p1 = cmp.eq(r24,##1536)
		if (!p1.new) jump:nt .LBB27_22
	}
// %bb.9:                               // %lor.lhs.false3.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = #1536
		r2 = memw(r27+#0)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_22
	}
// %bb.10:                              // %lor.lhs.false5.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #2048
	}
	{
		r2 = memw(r23+#28)
		if (!cmp.eq(r2.new,r2)) jump:t .LBB27_22
	}
// %bb.11:                              // %lor.lhs.false7.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_22
	}
// %bb.12:                              // %lor.lhs.false9.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB27_22
	}
// %bb.13:                              // %lor.lhs.false11.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB27_22
	}
// %bb.14:                              // %lor.lhs.false15.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r23 = memw(r16+#8)
	}
	{
		r2 = memw(r23+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_22
	}
// %bb.15:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
		r0 = add(r18,#88)
	}
	.falign
// %bb.16:                              // %lor.lhs.false18.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		if (p0.new) r0 = add(r23,#88)
		p0 = cmp.eq(r0,#1); if (!p0.new) jump:t .LBB27_22
	}
// %bb.17:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		call htp_tl2_palette_magnitude
	}
	.falign
// %bb.18:                              // %lor.lhs.false21.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = #32
		p1 = cmp.eq(r0,#1); if (!p1.new) jump:t .LBB27_22
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
// %bb.19:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = add(r29,#512)
		r0 = #1
		r5:4 = memd(r16+#24)
		r7:6 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = combine(#0,#1)
		memw(r29+#528) = r3
		memw(r29+#532) = r0
	}
	{
		r4 = #1536
		r3 = memw(r16+#20)
		memw(r29+#540) = r4
	}
	{
		memw(r29+#536) = r3
		memw(r29+#524) = r7
	}
	{
		r3 = memw(r18+#12)
		memw(r29+#544) = r3.new
	}
	{
		r3 = #48
		memw(r29+#520) = r3.new
	}
	{
		r3 = memw(r18+#8)
		memw(r29+#512) = r5
	}
	{
		r3 = #128
		memw(r29+#548) = r3
	}
	{
		r3 = memw(r18+#16)
		memw(r29+#516) = r3
	}
	{
		r3 = memw(r16+#36)
		memw(r29+#552) = r3
	}
	{
		memw(r29+#556) = r4
		memw(r29+#564) = r4
	}
	{
		call hvx_dq_swiglu_worker
		memw(r29+#568) = r7
		memw(r29+#560) = r3
	}
	.falign
// %bb.20:                              // %if.end.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r21 = #8 ; jump .LBB27_92
		r22 = #16
	}
	.falign
.LBB27_21:                              // %land.lhs.true2.if.then_crit_edge
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = memw(r25+#0)
	}
	.falign
.LBB27_22:                              // %if.then
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r27+#0)
	}
	{
		r17 = mpyi(r2,r17)
	}
	{
		r23 = mpyi(r2,r20)
		if (!cmp.gtu(r23.new,r17)) jump:t ##.LBB27_91
	}
// %bb.23:                              // %for.body.i.preheader
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r24 = add(#127,asl(r24,#1))
	}
	{
		r24 = and(r24,#-128)
	}
	.falign
.LBB27_24:                              // %for.body.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_28 Depth 3
                                        //       Child Loop BB27_32 Depth 3
                                        //       Child Loop BB27_60 Depth 3
                                        //       Child Loop BB27_64 Depth 3
	{
		r18 = memw(r27+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r17)
	}
	.falign
// %bb.25:                              // %for.body.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r3:2 = combine(r19,r17)
		r5 = #1
		r6 = memw(r22+#0)
	}
	{
		r3 += asl(r0,#9)
		r2 -= mpyi(r0,r18)
		r8 = add(r6,#-1)
		p0 = cmp.gtu(r6,#1)
	}
	{
		if (p0) r13 = add(r5,#1)
		if (p0) r14 = add(r5,#2)
		r7 = memw(r3+#28)
	}
	{
		r4 = addasl(r7,r2,#7)
	}
	{
		if (!p0) jump:nt .LBB27_34
		v0 = vmem(r4+#0)
	}
// %bb.26:                              // %for.body13.i.preheader
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = mpyi(r5,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB27_30
	}
// %bb.27:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r15 = addasl(r4,r12,#2)
		p1 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_28,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r5,#3)
		r5 = add(r5,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r4,r13,#2)
		v5.w = vadd(v0.w,v31.w)
		v31.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r4,r14,#2)
		if (!p1) jump:nt .LBB27_29
	}
	.falign
.LBB27_28:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r4,r12,#2)
		r13 = mpyi(r5,r24)
		v1.w = vadd(v5.w,v0.w)
		v0.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r4,r13,#2)
		r9 = add(r5,#1)
		r14 = add(r5,#2)
		v2 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r5,#3)
		v3.w = vadd(v1.w,v2.w)
		v4 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r5 = add(r5,#4)
		v5.w = vadd(v3.w,v4.w)
		v6 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r4,r9,#2)
		v5.w = vadd(v5.w,v6.w)
	}
	{
		r13 = addasl(r4,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_29:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = addasl(r4,r12,#2)
		v8.w = vadd(v5.w,v7.w)
		v7.cur = vmem(r13+#0)
	}
	{
		v10.w = vadd(v8.w,v9.w)
		v9.cur = vmem(r9+#0)
	}
	{
		v0.w = vadd(v10.w,v11.w)
		v11.cur = vmem(r12+#0)
	}
	.falign
.LBB27_30:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = mpyi(r5,r24)
		r12 = add(r8,#-1)
		p2 = cmp.gtu(r8,#0)
		if (!p2.new) jump:t .LBB27_34
	}
// %bb.31:                              // %for.body13.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.gtu(r8,#1)
		r5 = add(r5,#1)
	}
	{
		loop0(.LBB27_32,r12)
		r8 = addasl(r4,r9,#2)
		if (!p1) jump:nt .LBB27_33
	}
	.balign 32
.LBB27_32:                              // %for.body13.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r5,r24)
		r5 = add(r5,#1)
		v0.w = vadd(v0.w,v12.w)
		v12.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r4,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_33:                              //   in Loop: Header=BB27_24 Depth=2
	{
		v0.w = vadd(v0.w,v13.w)
		v13.cur = vmem(r8+#0)
	}
	.falign
.LBB27_34:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r5 = memw(r3+#4)
		vmem(r29+#4) = v0
	}
	{
		r4 = memb(r5+#88)
	}
	{
		r8 = abs(r4)
		r4 = memw(r25+#0)
	}
	{
		p1 = cmp.eq(r8,#0)
		if (p1.new) jump:nt .LBB27_37
	}
// %bb.35:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#7)
		if (p2.new) jump:nt .LBB27_37
	}
// %bb.36:                              // %for.cond.cleanup12.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_37:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = memb(r5+#89)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_42
	}
// %bb.38:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_40
	}
// %bb.39:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_40:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		if (p1) jump:nt .LBB27_43
	}
// %bb.41:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_43
	}
	.falign
.LBB27_42:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_43:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = memb(r5+#90)
	}
	{
		r8 = abs(r8)
		if (cmp.eq(r8.new,#0)) jump:nt .LBB27_48
	}
// %bb.44:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,#7)
		if (p1.new) jump:nt .LBB27_46
	}
// %bb.45:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#1)
		if (!p2.new) jump:t .LBB27_57
	}
	.falign
.LBB27_46:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r9,#0)
		if (p1.new) jump:nt .LBB27_49
	}
// %bb.47:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,r8)
		if (!p2.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_49
	}
	.falign
.LBB27_48:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = r9
	}
	.falign
.LBB27_49:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = memb(r5+#91)
	}
	{
		r9 = abs(r9)
		if (cmp.eq(r9.new,#0)) jump:nt .LBB27_54
	}
// %bb.50:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r9,#7)
		if (p2.new) jump:nt .LBB27_52
	}
// %bb.51:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r9,#1)
		if (!p1.new) jump:t .LBB27_57
	}
	.falign
.LBB27_52:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r8,#0)
		if (p2.new) jump:nt .LBB27_55
	}
// %bb.53:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r8,r9)
		if (!p1.new) jump:t .LBB27_57
	}
	{
		jump .LBB27_55
	}
	.falign
.LBB27_54:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = r8
	}
	.falign
.LBB27_55:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r8 = #3
		p2 = cmp.eq(r9,#7)
		if (!p2.new) jump:t .LBB27_57
	}
// %bb.56:                              // %if.end.i.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		v12.w = vasl(v0.w,r8)
	}
	{
		v13.w = vsub(v12.w,v0.w)
		vmem(r29+#4) = v13.new
	}
	.falign
.LBB27_57:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = addasl(r7,r4,#2)
		r8 = asl(r2,#5)
	}
	{
		r7 = addasl(r7,r8,#2)
		r8 = add(r6,#-1)
		if (p0) r6 = #1
	}
	{
		if (p0) r13 = add(r6,#1)
		if (p0) r14 = add(r6,#2)
		if (!p0) jump:nt .LBB27_66
		v1 = vmem(r7+#0)
	}
// %bb.58:                              // %for.body13.1.i.preheader
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = mpyi(r6,r24)
		r9 = lsr(r8,#2)
		r8 = and(r8,#3)
	}
	{
		p0 = cmp.gtu(r9,#0)
		if (!p0.new) jump:t .LBB27_62
	}
// %bb.59:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r15 = addasl(r7,r12,#2)
		p0 = cmp.gtu(r9,#1)
	}
	{
		r13 = mpyi(r13,r24)
		r9 = add(r9,#-1)
	}
	{
		loop0(.LBB27_60,r9)
		r14 = mpyi(r14,r24)
		r9 = add(r6,#3)
		r6 = add(r6,#4)
	}
	{
		r12 = mpyi(r9,r24)
		r13 = addasl(r7,r13,#2)
		v4.w = vadd(v1.w,v14.w)
		v14.cur = vmem(r15+#0)
	}
	{
		r9 = addasl(r7,r14,#2)
		if (!p0) jump:nt .LBB27_61
	}
	.falign
.LBB27_60:                              //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r12 = addasl(r7,r12,#2)
		r13 = mpyi(r6,r24)
		v16.w = vadd(v4.w,v15.w)
		v15.cur = vmem(r13+#0)
	}
	{
		r15 = addasl(r7,r13,#2)
		r9 = add(r6,#1)
		r14 = add(r6,#2)
		v17 = vmem(r9+#0)
	}
	{
		r13 = mpyi(r9,r24)
		r12 = add(r6,#3)
		v18.w = vadd(v16.w,v17.w)
		v19 = vmem(r12+#0)
	}
	{
		r9 = mpyi(r14,r24)
		r6 = add(r6,#4)
		v20.w = vadd(v18.w,v19.w)
		v21 = vmem(r15+#0)
	}
	{
		r12 = mpyi(r12,r24)
		r9 = addasl(r7,r9,#2)
		v4.w = vadd(v20.w,v21.w)
	}
	{
		r13 = addasl(r7,r13,#2)
		nop
	} :endloop0
	.falign
.LBB27_61:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r12 = addasl(r7,r12,#2)
		v23.w = vadd(v4.w,v22.w)
		v22.cur = vmem(r13+#0)
	}
	{
		v25.w = vadd(v23.w,v24.w)
		v24.cur = vmem(r9+#0)
	}
	{
		v1.w = vadd(v25.w,v26.w)
		v26.cur = vmem(r12+#0)
	}
	.falign
.LBB27_62:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r9 = mpyi(r6,r24)
		r12 = add(r8,#-1)
		p1 = cmp.gtu(r8,#0)
		if (!p1.new) jump:t .LBB27_66
	}
// %bb.63:                              // %for.body13.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.gtu(r8,#1)
		r6 = add(r6,#1)
	}
	{
		loop0(.LBB27_64,r12)
		r8 = addasl(r7,r9,#2)
		if (!p2) jump:nt .LBB27_65
	}
	.balign 32
.LBB27_64:                              // %for.body13.1.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_24 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = mpyi(r6,r24)
		r6 = add(r6,#1)
		v1.w = vadd(v1.w,v27.w)
		v27.cur = vmem(r8+#0)
	}
	{
		r8 = addasl(r7,r8,#2)
		nop
	} :endloop0
	.falign
.LBB27_65:                              //   in Loop: Header=BB27_24 Depth=2
	{
		v1.w = vadd(v1.w,v28.w)
		v28.cur = vmem(r8+#0)
	}
	.falign
.LBB27_66:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		vmem(r29+#5) = v1
	}
	{
		r6 = memb(r5+#88)
	}
	{
		r6 = abs(r6)
	}
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_69
	}
// %bb.67:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_69
	}
// %bb.68:                              // %for.cond.cleanup12.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r6,#1)
		if (!p2.new) jump:t .LBB27_89
	}
	.falign
.LBB27_69:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = memb(r5+#89)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_74
	}
// %bb.70:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_72
	}
// %bb.71:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_89
	}
	.falign
.LBB27_72:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		if (p0) jump:nt .LBB27_75
	}
// %bb.73:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,r7); if (!p0.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_75
	}
	.falign
.LBB27_74:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_75:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = memb(r5+#90)
	}
	{
		r6 = abs(r6)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB27_80
	}
// %bb.76:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r6,#7); if (p1.new) jump:nt .LBB27_78
	}
// %bb.77:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,#1); if (!p0.new) jump:t .LBB27_89
	}
	.falign
.LBB27_78:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#0)
		if (p2.new) jump:nt .LBB27_81
	}
// %bb.79:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,r6); if (!p1.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_81
	}
	.falign
.LBB27_80:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = r7
	}
	.falign
.LBB27_81:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = memb(r5+#91)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB27_86
	}
// %bb.82:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r7,#7)
		if (p2.new) jump:nt .LBB27_84
	}
// %bb.83:                              // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p1 = cmp.eq(r7,#1); if (!p1.new) jump:t .LBB27_89
	}
	.falign
.LBB27_84:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB27_87
	}
// %bb.85:                              // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		p2 = cmp.eq(r6,r7)
		if (!p2.new) jump:t .LBB27_89
	}
	{
		jump .LBB27_87
	}
	.falign
.LBB27_86:                              //   in Loop: Header=BB27_24 Depth=2
	{
		r7 = r6
	}
	.falign
.LBB27_87:                              // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r6 = #3
		p1 = cmp.eq(r7,#7); if (!p1.new) jump:t .LBB27_89
	}
// %bb.88:                              // %if.end.i.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		v29.w = vasl(v1.w,r6)
	}
	{
		v30.w = vsub(v29.w,v1.w)
		vmem(r29+#5) = v30.new
	}
	.falign
.LBB27_89:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r1:0 = memd(r5+#8)
		r6 = memw(r3+#20)
	}
	{
		r7 = memw(r3+#24)
		r5 = memw(r5+#16)
	}
	{
		r3 = memw(r3+#36)
		r8 = memw(r21+#0)
	}
	{
		r3 = extractu(r2,#27,#0)
		r0 = add(r29,#512)
		memw(r29+#28) = r3
		memw(r29+#12) = r0
	}
	{
		r1 = #128
		r2 = #1
		memw(r29+#8) = r1
		memw(r29+#32) = r4
	}
	{
		r5:4 = combine(#1,#32)
		memw(r29+#20) = r4
		memw(r29+#16) = r5
	}
	{
		memw(r29+#36) = #0
		memw(r29+#24) = r8
	}
	{
		call hvx_dequant_swiglu_acc_tiles_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.90:                              // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB27_24 Depth=2
	{
		r17 = add(r17,#1)
		if (!cmp.eq(r17.new,r23)) jump:t ##.LBB27_24
	}
	.falign
.LBB27_91:                              // %moe_tl2_gate_epilogue.exit
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r21 = #8
		r22 = #16
		r23 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	.falign
.LBB27_92:                              // %if.end
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_96
	}
// %bb.93:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #1
		r2 = #1
		r7:6 = memd(r16+#40)
		r0 = memw(r16+#36)
	}
	{
		r4 = r7
		r3 = memw(r25+#0)
		r5 = memw(r16+#48)
	}
	{
		memw(r29+#0) = r6
		memw(r29+#16) = #0
	}
	{
		memw(r29+#12) = #0
		memw(r29+#8) = #0
	}
	{
		call hvx_quant_rows_u8_params_rm
		memw(r29+#4) = #0
	}
	.falign
// %bb.94:                              // %if.then8
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = ##-1431655765
		r1 = memw(r25+#0)
		r0 = memw(r16+#40)
	}
	{
		r2 = add(r1,#23)
		r4 = memw(r16+#384)
	}
	{
		r3 = mpyu(r2,r3)
		r2 = #0
	}
	{
		call hvx_tl2_prepare
		r3 = lsr(r3,#4)
	}
	.falign
.LBB27_95:                              // %cleanup
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1:0 = memd(r29+#240)
	}                                       // 8-byte Folded Reload
	{
		p2 = cmp.gtu(r0,r20)
		if (p2.new) jump:t .LBB27_4
	}
	{
		jump .LBB27_119
	}
	.falign
.LBB27_96:                              // %if.end13
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	{
		r2 = add(r1,#3)
	}
	{
		r17 = and(r2,#-4)
		if (!cmp.gtu(r17.new,r1)) jump:t .LBB27_99
	}
// %bb.97:                              // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = mpyi(r3,r1)
		r2 = sub(r17,r1)
		r1 = #0
		r4 = memw(r16+#36)
	}
	{
		r2 = mpyi(r2,r3)
		r0 = addasl(r4,r5,#2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.98:                              // %if.then19
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = memw(r16+#388)
		r3 = memw(r25+#0)
	}
	.falign
.LBB27_99:                              // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = #64
		r0 = memw(r16+#36)
		r4 = memw(r16+#44)
	}
	{
		call hvx_quant_rows_u8_params
		r5 = memw(r16+#48)
		memw(r29+#0) = #0

	} :mem_noshuf
	.falign
// %bb.100:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r1 = #0
		r7:6 = memd(r16+#40)
		r2 = memw(r16+#48)
	}
	{
		r5 = r7
		r0 = memw(r16+#36)
		r4 = memw(r25+#0)
	}
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r17,#0)
		memw(r29+#0) = r2
		memw(r29+#4) = r6
	}
	.falign
// %bb.101:                             // %if.end28
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r2 = memw(r16+#8)
	}
	{
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_95
	}
// %bb.102:                             // %if.then41
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r5 = add(r16,#72)
		r9:8 = combine(#1,#0)
		r2 = memw(r16+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB27_95
	}
// %bb.103:                             // %for.body.lr.ph.i111
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r3 = memw(r25+#0)
		r4 = memw(r16+#48)
	}
	{
		p2 = cmp.gtu(r3,#31)
		if (p2.new) r7 = add(r2,#3)
		if (p2.new) jump:t .LBB27_109
		r6 = memw(r16+#40)
	}
// %bb.104:                             // %for.body.lr.ph.split.i
                                        //   in Loop: Header=BB27_4 Depth=1
	{
		r6 = add(r2,#3)
	}
	{
		r8 = lsr(r6,#2)
		r7:6 = combine(#1,#0)
	}
	{
		loop1(.LBB27_105,r8)
	}
	.falign
.LBB27_105:                             // Block address taken
                                        // %for.body.i113
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_106 Depth 3
	{
		r8 = addasl(r4,r6,#2)
		r9 = addasl(r5,r6,#2)
		r12 = add(r29,#512)
		r13 = #0
	}
	{
		v21.cur = vmem(r29+#3)
		vmem(r29+#4) = v21
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_106:                             // %for.body11.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_105 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r13,#2)
		r14 = memw(r8++#4)
		r15 = memw(r12+#0)
	}
	{
		r15 -= mpyi(r14,r3)
		if (p1) jump:nt .LBB27_108
		memw(r9++#4) = r15.new
	}
// %bb.107:                             // %for.body11.i
                                        //   in Loop: Header=BB27_106 Depth=3
	{
		r14 = add(r7,r13)
		r12 = add(r12,#32)
		r13 = add(r13,#1)
	}
	{
		p0 = cmp.gtu(r2,r14)
		if (p0.new) jump:t .LBB27_106
	}
	.falign
.LBB27_108:                             // %for.cond.cleanup10.i
                                        //   in Loop: Header=BB27_105 Depth=2
	{
		nop
		nop
		r6 = add(r6,#4)
		r7 = add(r7,#4)
	} :endloop1
	{
		jump .LBB27_95
	}
	.falign
.LBB27_109:                             //   in Loop: Header=BB27_4 Depth=1
	{
		r12 = lsr(r7,#2)
		r7 = lsr(r3,#5)
	}
	{
		loop1(.LBB27_110,r12)
	}
	.falign
.LBB27_110:                             // Block address taken
                                        // %for.body.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB27_112 Depth 3
                                        //       Child Loop BB27_116 Depth 3
	{
		r12 = addasl(r6,r8,#5)
		p1 = cmp.gtu(r7,#2)
		r13 = add(r7,#-2)
		p2 = cmp.gtu(r7,#1)
	}
	{
		r12 = add(r12,#2048)
		if (!p2) jump:nt .LBB27_114
		v3 = vmemu(r12+#0)
	}
// %bb.111:                             // %for.body4.us.i
                                        //   in Loop: Header=BB27_110 Depth=2
	{
		loop0(.LBB27_112,r13)
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		if (!p1) jump:nt .LBB27_113
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.balign 32
.LBB27_112:                             // %for.body4.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_110 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		v3 = v6
		v6 = vmemu(r12+#0)
	}
	{
		r12 = add(r12,#2048)
		nop
	} :endloop0
	.falign
.LBB27_113:                             //   in Loop: Header=BB27_110 Depth=2
	{
		v2.uw += vrmpy(v3.ub,r26.ub)
		jump .LBB27_115
		v3 = v6
	}
	.falign
.LBB27_114:                             //   in Loop: Header=BB27_110 Depth=2
	{
		v2 = vmem(r29+#2)
	}                                       // 128-byte Folded Reload
	.falign
.LBB27_115:                             //   in Loop: Header=BB27_110 Depth=2
	{
		r12 = addasl(r4,r8,#2)
		v2.uw += vrmpy(v3.ub,r26.ub)
		r14 = #0
		r15 = add(r29,#512)
	}
	{
		r13 = addasl(r5,r8,#2)
	}
	{
		v14 = valign(v2,v2,#4)
	}
	{
		v15.w = vadd(v2.w,v14.w)
	}
	{
		v16 = vror(v15,r21)
	}
	{
		v17.w = vadd(v15.w,v16.w)
	}
	{
		v18 = vror(v17,r22)
	}
	{
		v19.w = vadd(v17.w,v18.w)
		vmem(r29+#4) = v19.new
	}
	.falign
.LBB27_116:                             // %for.body11.us.i
                                        //   Parent Loop BB27_4 Depth=1
                                        //     Parent Loop BB27_110 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		p1 = cmp.gtu(r14,#2)
		r28 = memw(r12++#4)
		r0 = memw(r15+#0)
	}
	{
		r0 -= mpyi(r28,r3)
		if (p1) jump:nt .LBB27_118
		memw(r13++#4) = r0.new
	}
// %bb.117:                             // %for.body11.us.i
                                        //   in Loop: Header=BB27_116 Depth=3
	{
		r28 = add(r9,r14)
		r15 = add(r15,#32)
		r14 = add(r14,#1)
	}
	{
		p0 = cmp.gtu(r2,r28)
		if (p0.new) jump:t .LBB27_116
	}
	.falign
.LBB27_118:                             // %for.cond.cleanup10.us.i
                                        //   in Loop: Header=BB27_110 Depth=2
	{
		r8 = add(r8,#4)
		r9 = add(r9,#4)
		nop
	} :endloop1
	{
		jump .LBB27_95
	}
	.falign
.LBB27_119:                             // %for.cond.cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end27:
	.size	moe_m1_requant_worker, .Lfunc_end27-moe_m1_requant_worker
                                        // -- End function
	.falign
	.type	moe_m1_down_worker,@function    // -- Begin function moe_m1_down_worker
moe_m1_down_worker:                     // @moe_m1_down_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r21 = add(r2,#8196)
		r22 = r1
		memd(r30+#-24) = r21:20
		memd(r30+#-32) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r20 = r0
		r23 = memw(r21+#60)
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r25 = r2
		r18 = memw(r21+#20)
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r23)
		memd(r30+#-8) = r17:16
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r2 = r25
		r19 = add(r25,#8260)
		r16 = add(r22,#1)
		memw(r29+#212) = r25
	}                                       // 4-byte Folded Spill
	{
		r2 += asl(r0,#9)
		r24 = add(r19,#-40)
		memw(r29+#208) = r24.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+#8)
	}
	{
		r2 = memw(r2+#44)
	}
	{
		if (!p0.new) r17 = add(r0,#0)
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB28_161
		if (!p0.new) r2 = memw(r19+#0)
	}
// %bb.2:                               // %if.then
	{
		r1 = r18
		r0 = sub(r2,r23)
	}
	{
		call __hexagon_udivsi3
	}
	.falign
// %bb.3:                               // %if.then
	{
		r1 = r20
		r2 = memw(r24+#0)
	}
	{
		r2 = add(r2,#127)
	}
	{
		r18 = lsr(r2,#7)
	}
	{
		r23 = mpyi(r18,r0)
	}
	{
		r0 = mpyi(r23,r22)
		call __hexagon_udivsi3
		r22 = memw(r21+#4)
	}
	.falign
// %bb.4:                               // %if.then
	{
		r0 = mpyi(r23,r16)
		call __hexagon_udivsi3
		r19 = r0
		r1 = r20
	}
	.falign
// %bb.5:                               // %if.then
	{
		r20 = r0
		r2 = add(r22,#23)
		p1 = cmp.gtu(r0,r19); if (!p1.new) jump:t .LBB28_222
	}
// %bb.6:                               // %for.body.lr.ph.i
	{
		r3 = ##-1431655765
		r22 = add(r25,#8200)
		r23 = add(r25,#8240)
	}
	{
		r2 = mpyu(r2,r3)
	}
	{
		r2 = lsr(r2,#4)
	}
	{
		r26 = +mpyi(r2,##640)
	}
	.falign
.LBB28_7:                               // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r18,r19)
	}
	.falign
// %bb.8:                               // %for.body.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r27 = r25
		r2 = add(r0,r17)
		r16 = r19
		r1 = memw(r22+#0)
	}
	{
		r27 += asl(r2,#9)
		r16 -= mpyi(r0,r18)
		r3 = add(r29,#256)
	}
	{
		r0 = memw(r27+#16)
		r2 = memw(r27+#384)
	}
	{
		r0 += mpyi(r26,r16)
		call hvx_gemv_u8tl2_panel
	}
	.falign
// %bb.9:                               // %for.body.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r23+#0)
		if (cmp.eq(r2.new,#0)) jump:nt ##.LBB28_60
	}
// %bb.10:                              // %land.lhs.true.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = #64
	}
	{
		r2 = memw(r21+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB28_60
	}
// %bb.11:                              // %land.lhs.true19.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = #1536
	}
	{
		r2 = memw(r22+#0)
		if (!cmp.eq(r2.new,r2)) jump:t ##.LBB28_60
	}
// %bb.12:                              // %land.lhs.true22.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:t .LBB28_60
	}
// %bb.13:                              // %land.lhs.true25.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r27+#388)
		if (!cmp.eq(r2.new,#1)) jump:t .LBB28_60
	}
// %bb.14:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memw(r27+#4)
	}
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_17
	}
// %bb.15:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_17
	}
// %bb.16:                              // %land.lhs.true27.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_17:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_22
	}
// %bb.18:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_20
	}
// %bb.19:                              // %for.inc.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_20:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_23
	}
// %bb.21:                              // %lor.lhs.false.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_23
	}
	.falign
.LBB28_22:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_23:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_28
	}
// %bb.24:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_26
	}
// %bb.25:                              // %for.inc.1.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_26:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_29
	}
// %bb.27:                              // %lor.lhs.false.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_29
	}
	.falign
.LBB28_28:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_29:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = memb(r2+#91)
	}
	{
		r2 = abs(r2)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_34
	}
// %bb.30:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r2,#7); if (p0.new) jump:nt .LBB28_32
	}
// %bb.31:                              // %for.inc.2.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r2,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_32:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_35
	}
// %bb.33:                              // %lor.lhs.false.3.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r2); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_35
	}
	.falign
.LBB28_34:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = r3
	}
	.falign
.LBB28_35:                              // %htp_tl2_palette_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.gtu(r2,#1); if (p0.new) jump:t .LBB28_60
		if (!p0.new) r2 = memw(r27+#8)
	}
// %bb.36:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_39
	}
// %bb.37:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_39
	}
// %bb.38:                              // %land.lhs.true30.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_39:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_44
	}
// %bb.40:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_42
	}
// %bb.41:                              // %for.inc.i140.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_42:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_45
	}
// %bb.43:                              // %lor.lhs.false.1.i143.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_45
	}
	.falign
.LBB28_44:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_45:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r2+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_50
	}
// %bb.46:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_48
	}
// %bb.47:                              // %for.inc.1.i148.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#1); if (!p1.new) jump:t .LBB28_60
	}
	.falign
.LBB28_48:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_51
	}
// %bb.49:                              // %lor.lhs.false.2.i151.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r3); if (!p1.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_51
	}
	.falign
.LBB28_50:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_51:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r2+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_56
	}
// %bb.52:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_54
	}
// %bb.53:                              // %for.inc.2.i156.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_60
	}
	.falign
.LBB28_54:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_57
	}
// %bb.55:                              // %lor.lhs.false.3.i159.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,r4); if (!p0.new) jump:t .LBB28_60
	}
	{
		jump .LBB28_57
	}
	.falign
.LBB28_56:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_57:                              // %htp_tl2_palette_magnitude.exit168.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r9 = asl(r16,#9)
		r0 = add(r29,#256)
		p1 = cmp.gtu(r4,#1); if (p1.new) jump:t .LBB28_60
	}
// %bb.58:                              // %if.then.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r8 = memw(r27+#44)
		r7:6 = memd(r27+#48)
	}
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r3 = add(r5,r9)
		r5 = add(r2,r9)
		r4 = add(r4,r9)
		r2 = memw(r6+#0)
	}
	{
		call hvx_dequant_acc_4tiles_m1_f32
		r6 = add(r7,r9)
		r1 = memw(r8+#0)
		memw(r29+#0) = r6.new
	}
	.falign
// %bb.59:                              // %if.then.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		jump .LBB28_160
	}
	.falign
.LBB28_60:                              // %if.end.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r25 = asl(r16,#7)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r25)) jump:t ##.LBB28_160
	}
// %bb.61:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r6 = memw(r27+#8)
	}
	{
		r3 = memb(r6+#88)
	}
	{
		r3 = abs(r3)
	}
	{
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB28_64
	}
// %bb.62:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#7); if (p0.new) jump:nt .LBB28_64
	}
// %bb.63:                              // %for.body53.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_64:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r6+#89)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_69
	}
// %bb.65:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_67
	}
// %bb.66:                              // %for.inc.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_67:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_70
	}
// %bb.68:                              // %lor.lhs.false.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_70
	}
	.falign
.LBB28_69:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_70:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = memb(r6+#90)
	}
	{
		r3 = abs(r3)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_75
	}
// %bb.71:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,#7); if (p1.new) jump:nt .LBB28_73
	}
// %bb.72:                              // %for.inc.1.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#1); if (!p0.new) jump:t .LBB28_84
	}
	.falign
.LBB28_73:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_76
	}
// %bb.74:                              // %lor.lhs.false.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r3); if (!p0.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_76
	}
	.falign
.LBB28_75:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = r4
	}
	.falign
.LBB28_76:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r6+#91)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_81
	}
// %bb.77:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_79
	}
// %bb.78:                              // %for.inc.2.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_84
	}
	.falign
.LBB28_79:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r3,#0); if (p0.new) jump:nt .LBB28_82
	}
// %bb.80:                              // %lor.lhs.false.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r3,r4); if (!p1.new) jump:t .LBB28_84
	}
	{
		jump .LBB28_82
	}
	.falign
.LBB28_81:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r3
	}
	.falign
.LBB28_82:                              // %for.inc.3.i.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r3 = #3
		p0 = cmp.eq(r4,#7); if (!p0.new) jump:t .LBB28_84
	}
// %bb.83:                              // %if.end.i.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v2.w = vasl(v1.w,r3)
		v1.cur = vmem(r29+#2)
	}
	{
		v3.w = vsub(v2.w,v1.w)
		vmem(r29+#2) = v3.new
	}
	.falign
.LBB28_84:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r29,#256)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r6+#8)
	}
	{
		r3 = memw(r27+#44)
		r6 = memw(r6+#16)
	}
	{
		r2 = addasl(r5,r25,#2)
		r5 = addasl(r9,r25,#2)
		memw(r29+#12) = r2
		memw(r29+#16) = #0
	}
	{
		r2 = addasl(r6,r25,#2)
		memw(r29+#8) = r2
	}
	{
		r2 = addasl(r8,r25,#2)
		memw(r29+#4) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
		r2 = #1
		memw(r29+#0) = r2
	}
	.falign
// %bb.85:                              // %moe_tl2_restore_magnitude.exit.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = setbit(r25,#5)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB28_160
	}
// %bb.86:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_89
	}
// %bb.87:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_89
	}
// %bb.88:                              // %for.body53.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_89:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_94
	}
// %bb.90:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_92
	}
// %bb.91:                              // %for.inc.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_92:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_95
	}
// %bb.93:                              // %lor.lhs.false.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_95
	}
	.falign
.LBB28_94:                              //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_95:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_100
	}
// %bb.96:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_98
	}
// %bb.97:                              // %for.inc.1.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_109
	}
	.falign
.LBB28_98:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB28_101
	}
// %bb.99:                              // %lor.lhs.false.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_101
	}
	.falign
.LBB28_100:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_101:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_106
	}
// %bb.102:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_104
	}
// %bb.103:                             // %for.inc.2.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_109
	}
	.falign
.LBB28_104:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_107
	}
// %bb.105:                             // %lor.lhs.false.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_109
	}
	{
		jump .LBB28_107
	}
	.falign
.LBB28_106:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_107:                             // %for.inc.3.i.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB28_109
	}
// %bb.108:                             // %if.end.i.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v5.w = vasl(v4.w,r4)
		v4.cur = vmem(r29+#3)
	}
	{
		v6.w = vsub(v5.w,v4.w)
		vmem(r29+#3) = v6.new
	}
	.falign
.LBB28_109:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#128)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.110:                             // %moe_tl2_restore_magnitude.exit.1.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r2 = setbit(r25,#6)
		r3 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r3+#0)
		if (!cmp.gtu(r6.new,r2)) jump:t ##.LBB28_160
	}
// %bb.111:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_114
	}
// %bb.112:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_114
	}
// %bb.113:                             // %for.body53.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_114:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_119
	}
// %bb.115:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB28_117
	}
// %bb.116:                             // %for.inc.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_117:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p1) jump:nt .LBB28_120
	}
// %bb.118:                             // %lor.lhs.false.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_120
	}
	.falign
.LBB28_119:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_120:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_125
	}
// %bb.121:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_123
	}
// %bb.122:                             // %for.inc.1.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#1); if (!p0.new) jump:t .LBB28_134
	}
	.falign
.LBB28_123:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB28_126
	}
// %bb.124:                             // %lor.lhs.false.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,r4); if (!p0.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_126
	}
	.falign
.LBB28_125:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_126:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_131
	}
// %bb.127:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#7); if (p0.new) jump:nt .LBB28_129
	}
// %bb.128:                             // %for.inc.2.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_134
	}
	.falign
.LBB28_129:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_132
	}
// %bb.130:                             // %lor.lhs.false.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,r5); if (!p1.new) jump:t .LBB28_134
	}
	{
		jump .LBB28_132
	}
	.falign
.LBB28_131:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_132:                             // %for.inc.3.i.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p0 = cmp.eq(r5,#7); if (!p0.new) jump:t .LBB28_134
	}
// %bb.133:                             // %if.end.i.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v8.w = vasl(v7.w,r4)
		v7.cur = vmem(r29+#4)
	}
	{
		v9.w = vsub(v8.w,v7.w)
		vmem(r29+#4) = v9.new
	}
	.falign
.LBB28_134:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#256)
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r2,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r1 = addasl(r7,r2,#2)
		r6 = addasl(r9,r2,#2)
		memw(r29+#12) = r6
		memw(r29+#8) = r5
	}
	{
		r2 = addasl(r8,r2,#2)
		memw(r29+#4) = r1
		memw(r29+#16) = #0
	}
	{
		r2 = #1
		r5 = r6
		r1 = #32
		memw(r29+#0) = r2
	}
	{
		call hvx_dequant_acc_tile_to_f32
	}
	.falign
// %bb.135:                             // %moe_tl2_restore_magnitude.exit.2.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r6 = or(r25,#96)
		r2 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
		if (!cmp.gtu(r2.new,r6)) jump:t .LBB28_160
	}
// %bb.136:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r7 = memw(r27+#8)
	}
	{
		r3 = memb(r7+#88)
	}
	{
		r4 = abs(r3)
		r3 = add(r29,#256)
	}
	{
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB28_139
	}
// %bb.137:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#7); if (p1.new) jump:nt .LBB28_139
	}
// %bb.138:                             // %for.body53.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_139:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#89)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_144
	}
// %bb.140:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_142
	}
// %bb.141:                             // %for.inc.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_142:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		if (p0) jump:nt .LBB28_145
	}
// %bb.143:                             // %lor.lhs.false.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_145
	}
	.falign
.LBB28_144:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_145:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = memb(r7+#90)
	}
	{
		r4 = abs(r4)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB28_150
	}
// %bb.146:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,#7); if (p0.new) jump:nt .LBB28_148
	}
// %bb.147:                             // %for.inc.1.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#1); if (!p1.new) jump:t .LBB28_159
	}
	.falign
.LBB28_148:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB28_151
	}
// %bb.149:                             // %lor.lhs.false.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,r4); if (!p1.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_151
	}
	.falign
.LBB28_150:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = r5
	}
	.falign
.LBB28_151:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = memb(r7+#91)
	}
	{
		r5 = abs(r5)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_156
	}
// %bb.152:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r5,#7); if (p1.new) jump:nt .LBB28_154
	}
// %bb.153:                             // %for.inc.2.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r5,#1); if (!p0.new) jump:t .LBB28_159
	}
	.falign
.LBB28_154:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB28_157
	}
// %bb.155:                             // %lor.lhs.false.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		p0 = cmp.eq(r4,r5); if (!p0.new) jump:t .LBB28_159
	}
	{
		jump .LBB28_157
	}
	.falign
.LBB28_156:                             //   in Loop: Header=BB28_7 Depth=1
	{
		r5 = r4
	}
	.falign
.LBB28_157:                             // %for.inc.3.i.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r4 = #3
		p1 = cmp.eq(r5,#7); if (!p1.new) jump:t .LBB28_159
	}
// %bb.158:                             // %if.end.i.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		v11.w = vasl(v10.w,r4)
		v10.cur = vmem(r29+#5)
	}
	{
		v12.w = vsub(v11.w,v10.w)
		vmem(r29+#5) = v12.new
	}
	.falign
.LBB28_159:                             // %moe_tl2_restore_magnitude.exit.3.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r0 = add(r3,#384)
		r1 = #32
		r5:4 = memd(r27+#48)
		r9:8 = memd(r7+#8)
	}
	{
		r5 = addasl(r5,r6,#2)
		r7 = memw(r7+#16)
		r3 = memw(r27+#44)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#8) = r5
	}
	{
		r7 = addasl(r7,r6,#2)
		r6 = addasl(r8,r6,#2)
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#4) = r7
		memw(r29+#0) = r6
	}
	.falign
.LBB28_160:                             // %cleanup.i
                                        //   in Loop: Header=BB28_7 Depth=1
	{
		r19 = add(r19,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r20,r19.new)) jump:t ##.LBB28_7
	}                                       // 4-byte Folded Reload
	{
		jump .LBB28_222
	}
	.falign
.LBB28_161:                             // %if.end
	{
		r24 = add(r25,#8232)
		r2 = memw(r21+#28)
	}
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r3 = p1
		if (p1) jump:nt .LBB28_163
		memw(r29+#236) = r3.new
	}                                       // 4-byte Folded Spill
// %bb.162:
	{
		p0 = or(p0,!p0)
		r26 = add(r25,#8204)
	}
	{
		r3 = p0
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB28_164
	}
	{
		jump .LBB28_165
	}
	.falign
.LBB28_163:                             // %lor.rhs
	{
		r26 = add(r25,#8204)
		r3 = memw(r24+#0)
	}
	{
		p1 = cmp.eq(r3,#0)
	}
	{
		p1 = not(p1)
	}
	{
		r3 = p1
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Spill
	{
		r3 = memw(r21+#40)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_165
	}
	.falign
.LBB28_164:                             // %land.lhs.true
	{
		r0 = #2
		r4 = memw(r24+#0)
		memw(r29+#240) = r0.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r4,#0); if (!p1.new) jump:t .LBB28_167
	}
	.falign
.LBB28_165:                             // %cond.false
	{
		r4 = #512
		r1:0 = combine(#0,r2)
		r5 = memw(r26+#0)
	}
	{
		r2 = lsr(r4,r3)
		r1:0 = asl(r1:0,#10)
		r3 = #0
	}
	{
		r2 = mpyi(r5,r2)
		call __hexagon_udivdi3
	}
	.falign
// %bb.166:                             // %cond.false
	{
		r2 = #1
		r3 = #127
	}
	{
		r2 = maxu(r0,r2)
	}
	{
		r2 = minu(r2,r3)
		memw(r29+#240) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_167:                             // %cond.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r21 = #0
		memw(r29+#244) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_170
	}
// %bb.168:                             // %if.then12
	{
		r17 = add(r25,#8256)
	}
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.169:                             // %if.then12
	{
		jump .LBB28_171
		r23 = memw(r17+#0)
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB28_170:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#248) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB28_171:                             // %do.end
	{
		r2 = memw(r19+#0)
	}
	{
		r18 = sub(r2,r23)
		r3:2 = combine(r21,r20)
	}
	{
		r1:0 = mpyu(r18,r22)
		call __hexagon_udivdi3
	}
	.falign
// %bb.172:                             // %do.end
	{
		r1:0 = mpyu(r18,r16)
		call __hexagon_udivdi3
		r17 = add(r23,r0)
		r3:2 = combine(r21,r20)
	}
	.falign
// %bb.173:                             // %do.end
	{
		r2 = add(r23,r0)
		r27 = add(r25,#8236)
		r18 = add(r25,#8216)
		memw(r29+#232) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.gtu(r2,r17); if (!p1.new) jump:t .LBB28_218
		if (p1.new) r20 = memw(r18+#0)
	}
// %bb.174:                             // %cond.end22
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.175:                             // %cond.end22
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r20)
		r3 = add(r17,r3)
	}
	{
		r2 = minu(r3,r2)
		r3 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r19 = minu(r2,r3)
		r3 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (!p1.new) r3 = sub(r19,r17)
		if (p1.new) jump:nt .LBB28_181
	}
// %bb.176:                             // %cond.end22
	{
		if (p0.new) r4 = add(r25,#0)
		if (p0.new) r2 = add(r17,#0)
		p0 = cmp.gtu(r2,r17); if (!p0.new) jump:nt .LBB28_181
	}
// %bb.177:                             // %if.then28
	{
		r4 += asl(r0,#9)
		r2 -= mpyi(r0,r20)
		r1 = r20
	}
	{
		r6 = memw(r4+#8)
		r4 = memw(r26+#0)
	}
	{
		r0 = memw(r6+#4)
	}
	{
		r5 = memw(r27+#0)
		if (cmp.eq(r5.new,#0)) jump:nt .LBB28_180
	}
// %bb.178:                             // %if.then.i270
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
// %bb.179:                             // %if.then.i270
	{
		jump .LBB28_181
	}
	.falign
.LBB28_180:                             // %if.else.i
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
.LBB28_181:                             // %for.body.lr.ph
	{
		r2 = memw(r16+##hvx_gemm_u8i2_wh_col@GOT)
		r3 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1.new) r4 = memw(r16+##hvx_gemm_u8i2_wh_col_nopf@GOT)
	}
	{
		if (!p1) r4 = add(r2,#0)
		r3 = memw(r16+##hvx_gemm_u8i4_wh_col@GOT)
	}
	{
		memw(r29+#220) = r4
	}                                       // 4-byte Folded Spill
	{
		r16 = add(r25,#8228)
		if (!p1) r2 = add(r3,#0)
		if (p1) r2 = memw(r16+##hvx_gemm_u8i4_wh_col_nopf@GOT)
	}
	{
		memw(r29+#216) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_182:                             // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB28_191 Depth 2
                                        //       Child Loop BB28_205 Depth 3
	{
		r20 = r17
		r17 = r19
		r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r2,r19)
	}
	{
		r2 = p0
		if (!p0) jump:nt .LBB28_185
		memw(r29+#228) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.183:                             // %cond.true34
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r21 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r19)
	}
	.falign
// %bb.184:                             // %cond.true34
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = add(r0,#1)
		r3 = memw(r29+#240)
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r2 = mpyi(r2,r21)
		r3 = add(r19,r3)
	}
	{
		r2 = minu(r3,r2)
	}
	{
		r19 = minu(r2,r0)
	}
	.falign
.LBB28_185:                             // %cond.end38
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB28_190
	}
// %bb.186:                             // %cond.end38
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r19,r17); if (!p0.new) jump:nt .LBB28_190
		if (p0.new) r21 = memw(r18+#0)
	}
// %bb.187:                             // %if.then44
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call __hexagon_udivsi3
		r1:0 = combine(r21,r17)
	}
	.falign
// %bb.188:                             // %if.then44
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r2 = r25
		r1 = r21
		r3 = memw(r27+#0)
		r4 = memw(r26+#0)
	}
	{
		r2 += asl(r0,#9)
		p1 = cmp.eq(r3,#0)
		r3 = sub(r19,r17)
	}
	{
		r2 = r17
		r5 = memw(r2+#8)
	}
	{
		r2 -= mpyi(r0,r21)
	}
	{
		if (p1) jump:nt .LBB28_216
		r0 = memw(r5+#4)
	}
// %bb.189:                             // %if.then.i291
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call hvx_gemm_u8i2_wh_prefetch
	}
	.falign
.LBB28_190:                             // %if.end45
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB28_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_191:                             // %for.body50
                                        //   Parent Loop BB28_182 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB28_205 Depth 3
	{
		r23 = memw(r18+#0)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r23,r20)
	}
	.falign
// %bb.192:                             // %for.body50
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r25 += asl(r0,#9)
		r22 = r20
		r19 = add(r20,#1)
	}
	{
		r22 -= mpyi(r0,r23)
	}
	{
		r21 = memw(r25+#32)
	}
	{
		r21 += asl(r22,#9)
		r2 = memw(r27+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_197
	}
// %bb.193:                             // %land.lhs.true61
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = add(r25,#256)
		r2 = memw(r24+#0)
		r0 = memw(r25+#40)
	}
	{
		p0 = cmp.eq(r2,#0)
		if (!p0.new) r6 = add(r22,#1)
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		if (!p0) r7 = add(r21,##512)
		if (p0) jump:nt .LBB28_199
		r3 = memw(r25+#16)
	}
// %bb.194:                             // %land.lhs.true61
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r17,r19); if (!p1.new) jump:nt .LBB28_199
	}
// %bb.195:                             // %if.then68
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#8) = r4

	} :mem_noshuf
	{
		r5:4 = combine(r22,r23)
		memw(r29+#4) = r5
		memw(r29+#12) = r21
	}
	{
		call hvx_gemm_u8i2_wh_cols2_nopf
		memw(r29+#16) = r7
		memw(r29+#0) = r6
	}
	.falign
// %bb.196:                             // %if.then68
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB28_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_197:                             // %if.else87
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = memw(r16+#0)
		r0 = memw(r25+#40)
	}
	{
		r1 = memw(r25+#388)
		r2 = memw(r26+#0)
	}
	{
		r5:4 = combine(r22,r23)
		r3 = memw(r25+#16)
		memw(r29+#0) = r4

	} :mem_noshuf
	{
		r6 = memw(r29+#216)
		memw(r29+#4) = r21
	}                                       // 4-byte Folded Reload
	{
		callr r6
	}
	.falign
// %bb.198:                             // %if.else87
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p0 = or(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB28_201
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_199:                             // %if.then76
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = memw(r16+#0)
		memw(r29+#0) = r5.new
	}
	{
		r5:4 = combine(r22,r23)
		r6 = memw(r29+#220)
		memw(r29+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#8) = r21
	}
	{
		callr r6
	}
	.falign
// %bb.200:                             // %if.then76
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		memw(r29+#204) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB28_201:                             // %if.end97
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r22 = asl(r22,#5)
		r6 = memw(r25+#8)
		r23 = memw(r29+#208)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r6+#20)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB28_210
	}
// %bb.202:                             // %if.then100
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5 = add(r25,#72)
		r2 = memw(r25+#388)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_210
	}
// %bb.203:                             // %for.body.us.i
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r6 = addasl(r3,r22,#2)
		r3 = lsr(r2,#1)
		r4 = and(r2,#1)
	}
	{
		p0 = cmp.gtu(r3,#0)
		if (!p0.new) r3 = add(r21,#0)
		r2 = r5
	}
	{
		if (!p0) jump:nt .LBB28_208
		v0 = vmemu(r6+#0)
	}
// %bb.204:                             //   in Loop: Header=BB28_191 Depth=2
	{
		loop0(.LBB28_205,r3)
		r6 = r21
		r3 = r21
	}
	.balign 32
.LBB28_205:                             //   Parent Loop BB28_182 Depth=1
                                        //     Parent Loop BB28_191 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = memw(r2++#8)
	}
	{
		v13 = vsplat(r7)
		v14 = vmemu(r6+#0)
	}
	{
		v16 = vmemu(r6+#1)
	}
	{
		v14.w += vmpyie(v13.w,v0.h)
	}
	{
		vmemu(r3++#2) = v14
	}
	{
		r5 = memw(r5+#4)
	}
	{
		v15 = vsplat(r5)
		r5 = r2
	}
	{
		v16.w += vmpyie(v15.w,v0.h)
	}
	{
		r6 = r3
		vmemu(r6+#1) = v16
	} :endloop0
// %bb.206:                             //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (!p1.new) jump:t .LBB28_209
	}
	.falign
.LBB28_207:                             // Block address taken
                                        // %for.body3.us.i
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r4 = memw(r2+#0)
	}
	{
		v17 = vsplat(r4)
		v18 = vmemu(r3+#0)
	}
	{
		v18.w += vmpyie(v17.w,v0.h)
	}
	{
		jump .LBB28_209
		vmemu(r3++#1) = v18
	}
	.falign
.LBB28_208:                             //   in Loop: Header=BB28_191 Depth=2
	{
		p1 = cmp.gtu(r4,#0); if (p1.new) jump:t .LBB28_207
	}
	.falign
.LBB28_209:                             // %if.end106.loopexit
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r6 = memw(r25+#8)
	}
	.falign
.LBB28_210:                             // %if.end106
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r5:4 = memd(r25+#48)
		r7 = memw(r6+#16)
	}
	{
		r0 = addasl(r7,r22,#2)
		r5 = addasl(r5,r22,#2)
		r9:8 = memd(r6+#8)
		r1 = memw(r23+#0)
	}
	{
		r6 = addasl(r9,r22,#2)
		r7 = addasl(r8,r22,#2)
		r2 = memw(r25+#388)
		r3 = memw(r25+#44)
	}
	{
		r5 = r6
		memw(r29+#8) = r5
		memw(r29+#12) = r1
	}
	{
		r1:0 = combine(#32,r21)
		memw(r29+#4) = r0
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r7
	}
	.falign
// %bb.211:                             // %if.end106
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r2 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:t .LBB28_214
		if (!p0.new) r5:4 = memd(r25+#48)
		if (!p0.new) r6 = memw(r25+#8)
	}
// %bb.212:                             // %if.then116
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r22 = add(#128,asl(r22,#2))
		r1 = #32
		r0 = add(r21,#512)
		r2 = memw(r25+#388)
	}
	{
		r5 = add(r5,r22)
		r3 = memw(r25+#44)
		r9:8 = memd(r6+#8)
	}
	{
		r12 = memw(r6+#16)
	}
	{
		r6 = add(r9,r22)
		r7 = memw(r23+#0)
		memw(r29+#8) = r5

	} :mem_noshuf
	{
		r7 = add(r12,r22)
		r6 = add(r8,r22)
		r5 = r6
		memw(r29+#12) = r7
	}
	{
		memw(r29+#16) = #0
		memw(r29+#4) = r7
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.213:                             // %if.then116
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r20 = r19
	}
	.falign
.LBB28_214:                             // %if.end134
                                        //   in Loop: Header=BB28_191 Depth=2
	{
		r20 = add(r20,#1)
		r25 = memw(r29+#212)
		if (cmp.gtu(r17,r20.new)) jump:t .LBB28_191
	}                                       // 4-byte Folded Reload
	.falign
.LBB28_215:                             // %for.cond.loopexit
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		r19 = memw(r29+#224)
		r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) jump:t .LBB28_182
	}
	{
		jump .LBB28_218
	}
	.falign
.LBB28_216:                             // %if.else.i293
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		call hvx_gemm_u8i4_wh_prefetch
	}
	.falign
// %bb.217:                             // %if.else.i293
                                        //   in Loop: Header=BB28_182 Depth=1
	{
		p0 = cmp.gtu(r17,r20); if (!p0.new) jump:t .LBB28_215
		memw(r29+#224) = r19
	}                                       // 4-byte Folded Spill
	{
		jump .LBB28_191
	}
	.falign
.LBB28_218:                             // %for.cond.cleanup
	{
		r16 = memw(r29+#244)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB28_222
	}
// %bb.219:                             // %if.then.i273
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.220:                             // %if.then.i273
	{
		r3:2 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB28_221:                             // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB28_221
	}
	.falign
.LBB28_222:                             // %cleanup
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end28:
	.size	moe_m1_down_worker, .Lfunc_end28-moe_m1_down_worker
                                        // -- End function
	.falign
	.type	lfm2_moe_hmx_issue_ok,@function // -- Begin function lfm2_moe_hmx_issue_ok
lfm2_moe_hmx_issue_ok:                  // @lfm2_moe_hmx_issue_ok
// %bb.0:                               // %entry
	{
		r7 = #0
		p0 = cmp.eq(r0,#0); if (p0.new) jump:nt .LBB29_15
	}
// %bb.1:                               // %entry
	{
		p1 = cmp.gtu(r1,#1); if (!p1.new) jump:nt .LBB29_15
	}
// %bb.2:                               // %entry
	{
		p0 = cmp.eq(r2,##2048)
		if (!p0.new) jump:nt .LBB29_15
	}
// %bb.3:                               // %entry
	{
		p1 = cmp.eq(r3,##1536)
		if (!p1.new) jump:nt .LBB29_15
	}
// %bb.4:                               // %entry
	{
		p0 = cmp.eq(r4,##2048)
		if (!p0.new) jump:nt .LBB29_15
	}
// %bb.5:                               // %entry
	{
		p1 = cmp.gtu(r5,#64)
		if (p1.new) jump:nt .LBB29_15
	}
// %bb.6:                               // %entry
	{
		r2 = memw(r29+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB29_15
	}
// %bb.7:                               // %lor.lhs.false13
	{
		r3 = memw(r29+#0)
		if (!cmp.eq(r3.new,r2)) jump:nt .LBB29_15
	}
// %bb.8:                               // %lor.lhs.false13
	{
		r1 = #0
		r2 = memw(r29+#12)
		r3 = memw(r29+#8)
	}
	{
		r2 = or(r2,r3)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB29_15
	}
// %bb.9:                               // %if.end
	{
		r0 = ##131072
		r5 = #0
		r2 = memw(r29+#16)
	}
	{
		r6 = memw(r2+#0)
	}
	{
		r1:0 = add(r7:6,r1:0)
		r6 = memw(r2+#4)
	}
	{
		p1 = cmp.gtu(r1:0,r7:6)
		if (!p1.new) r1 = #0
		if (p1.new) jump:t .LBB29_15
		if (!p1.new) r0 = memw(r2+#8)
	}
// %bb.10:                              // %land.lhs.true
	{
		r4 = ##3145728
	}
	{
		r5:4 = add(r7:6,r5:4)
	}
	{
		p0 = cmp.gtu(r5:4,r1:0)
		if (!p0.new) r7 = #0
		if (p0.new) jump:t .LBB29_15
		if (!p0.new) r4 = memw(r2+#12)
	}
// %bb.11:                              // %land.lhs.true37
	{
		r6 = ##1572864
		r5 = #0
	}
	{
		r7:6 = add(r1:0,r7:6)
	}
	{
		p1 = cmp.gtu(r7:6,r5:4)
		r7 = r1
		if (p1.new) jump:t .LBB29_15
	}
// %bb.12:                              // %land.lhs.true44
	{
		r1 = #0
		r7 = #0
		r6 = memw(r2+#16)
		if (cmp.gtu(r4,r6.new)) jump:t .LBB29_15
	}
// %bb.13:                              // %land.lhs.true48
	{
		r0 = ##196608
	}
	{
		r1:0 = add(r7:6,r1:0)
		r6 = memw(r2+#20)
	}
	{
		p1 = cmp.gtu(r1:0,r7:6)
		if (p1.new) jump:t .LBB29_15
		if (!p1.new) r2 = memw(r29+#20)
	}
// %bb.14:                              // %land.rhs
	{
		p0 = cmp.gtu(r6,r2)
	}
	{
		r7 = mux(p0,#0,#1)
	}
	.falign
.LBB29_15:                              // %return
	{
		r0 = r7
		jumpr r31
	}
.Lfunc_end29:
	.size	lfm2_moe_hmx_issue_ok, .Lfunc_end29-lfm2_moe_hmx_issue_ok
                                        // -- End function
	.falign
	.type	moe_push_act_block,@function    // -- Begin function moe_push_act_block
moe_push_act_block:                     // @moe_push_act_block
// %bb.0:                               // %entry
	{
		p0 = bitsclr(r5,#7)
		r17 = asl(r5,#11)
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		r21:20 = combine(r3,r4)
		r19 = r2
		memd(r29+#32) = r19:18
		memd(r29+#24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r23:22 = combine(r0,r1)
		if (p0) jump:nt .LBB30_2
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %while.body.i
	{
		p1 = tstbit(r5,#0)
		p0 = bitsclr(r5,#3)
		if (p1.new) r16 = ##2048
	}
	{
		if (!p1) r16 = ##4096
	}
	{
		if (p0) r16 = ##8192
		jump .LBB30_3
	}
	.falign
.LBB30_2:
	{
		r16 = #16384
	}
	.falign
.LBB30_3:                               // %hexkl_moe_push_act_block.exit
	{
		call hexkl_dma_ring_next_idx
	}
	.falign
// %bb.4:                               // %hexkl_moe_push_act_block.exit
	{
		call __hexagon_udivsi3
		r18 = r0
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.5:                               // %hexkl_moe_push_act_block.exit
	{
		r19 += mpyi(r20,r21)
		r5:4 = combine(r0,r16)
		r0 = add(r23,r22)
		r3:2 = combine(r16,r16)
	}
	{
		call hexkl_dma_ring_push2d
		r1 = r19
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.6:                               // %hexkl_moe_push_act_block.exit
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB30_9
	}
// %bb.7:                               // %if.then
	{
		r19 = memw(r29+#60)
		r20 = memw(r29+#56)
	}
	//# InlineAsm Start
	{
		r23:22 = c31:30
	}
	//# InlineAsm End
	{
		call __hexagon_udivsi3
		r1:0 = combine(r16,r17)
	}
	.falign
// %bb.8:                               // %if.then
	{
		r5:4 = combine(r19,r20)
		r1:0 = combine(r23,r22)
		r3:2 = combine(#0,r18)
		memw(r29+#4) = r0
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#0) = r16
		memw(r29+#8) = r16
	}
	.falign
.LBB30_9:                               // %if.end
	{
		r0 = r18
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end30:
	.size	moe_push_act_block, .Lfunc_end30-moe_push_act_block
                                        // -- End function
	.falign
	.type	lfm2_moe_issue_aligned,@function // -- Begin function lfm2_moe_issue_aligned
lfm2_moe_issue_aligned:                 // @lfm2_moe_issue_aligned
// %bb.0:                               // %entry
	{
		r6 = lsr(r2,#1)
		r4 = #31
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB31_6
	}
// %bb.1:
	{
		loop0(.LBB31_3,r6)
		r5 = #384
		r2 = and(r2,#1)
		p1 = cmp.gtu(r6,#0)
	}
	{
		if (!p1) jump:nt .LBB31_4
	}
	.balign 32
.LBB31_3:                               // =>This Inner Loop Header: Depth=1
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	{
		r6 = add(r0,#2048)
		r7 = add(r1,r3)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r6,r4):cm
		weight.n = mxmem(r7,r5)
	}

	//# InlineAsm End
	{
		r0 = add(r0,#4096)
		r1 = add(r7,r3)
	} :endloop0
	.falign
.LBB31_4:
	{
		p0 = cmp.gtu(r2,#0)
		if (!p0.new) jumpr:nt r31
	}
	.falign
.LBB31_5:                               // Block address taken
                                        // %for.body
	//# InlineAsm Start
	{
		activation.ub = mxmem(r0,r4):cm
		weight.n = mxmem(r1,r5)
	}

	//# InlineAsm End
	.falign
.LBB31_6:                               // %for.cond.cleanup
	{
		jumpr r31
	}
.Lfunc_end31:
	.size	lfm2_moe_issue_aligned, .Lfunc_end31-lfm2_moe_issue_aligned
                                        // -- End function
	.falign
	.type	moe_expand_submit,@function     // -- Begin function moe_expand_submit
moe_expand_submit:                      // @moe_expand_submit
// %bb.0:                               // %entry
	{
		r17:16 = combine(r2,r3)
		r8 = add(r4,r5)
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r18 = r1
		r3 = memw(r29+#48)
		memd(r29+#16) = r19:18
	}
	{
		r9 = memw(r29+#60)
		memd(r29+#8) = r21:20
	}
	{
		p1 = cmp.eq(r9,#-1)
		r6 = memw(r29+#44)
		r14 = memw(r29+#52)
	}
	{
		r12 = memw(r29+#64)
		memd(r29+#0) = r23:22
	}
	{
		r4 = r12
		r13 = memw(r29+#56)
		r7 = memw(r29+#40)
	}
	{
		r2 = asl(r14,#9)
		memw(r2+#152) = #0
		memw(r17+#8) = #1
	}
	{
		r4 = and(##2147483392,asl(r4,#8))
		r2 = r8
		memw(r17+#12) = r2
	}
	{
		r2 += asl(r13,#9)
		r5:4 = combine(r3,r4)
		if (!p1) r3 = add(r8,#0)
		if (!p1) memw(r17+#8) = #2
	}
	{
		r2 = add(r6,#88)
		if (p1) jump:nt .LBB32_8
		memw(r17+#0) = r2
		memd(r17+#16) = r5:4
	}
// %bb.1:                               // %if.end.thread
	{
		r3 += asl(r9,#9)
		memw(r17+#4) = r3.new
	}
	{
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB32_18
	}
// %bb.2:                               // %for.body.i
	{
		r12 = lsr(r13,#2)
		r15:14 = combine(#0,#1)
		r3 = add(r12,#3)
	}
	{
		r4 = add(r3,r13)
	}
	{
		r13 = lsr(r4,#2)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r13,r12)
		if (p0.new) r13 = sub(r13,r12)
		if (!p0.new) jump:t .LBB32_5
	}
// %bb.3:
	{
		loop0(.LBB32_4,r13)
	}
	.falign
.LBB32_4:                               // Block address taken
                                        // %for.body8.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r15:14,r12)
		r12 = add(r12,#1)
	} :endloop0
	.falign
.LBB32_5:                               // %for.cond.cleanup7.i
	{
		r3 = lsr(r9,#2)
		r12 = add(r3,r9)
	}
	{
		r9 = lsr(r12,#2)
	}
	{
		r13:12 = combine(#0,#1)
		p1 = cmp.gtu(r9,r3)
		if (p1.new) r9 = sub(r9,r3)
		if (!p1.new) jump:t .LBB32_12
	}
// %bb.6:
	{
		loop0(.LBB32_7,r9)
	}
	.falign
.LBB32_7:                               // Block address taken
                                        // %for.body8.i.1
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	{
		jump .LBB32_12
	}
	.falign
.LBB32_8:                               // %if.end
	{
		r4 = add(r12,add(r13,#3))
		r3 = memw(r6+#44)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB32_18
	}
// %bb.9:                               // %for.body.i.us
	{
		r3 = lsr(r13,#2)
	}
	{
		r9 = lsr(r4,#2)
		r13:12 = combine(#0,#1)
		r5:4 = combine(#0,#0)
	}
	{
		p0 = cmp.gtu(r9,r3)
		if (p0.new) r9 = sub(r9,r3)
		if (!p0.new) jump:t .LBB32_12
	}
// %bb.10:
	{
		loop0(.LBB32_11,r9)
	}
	.falign
.LBB32_11:                              // Block address taken
                                        // %for.body8.i.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r5:4 |= asl(r13:12,r3)
		r3 = add(r3,#1)
	} :endloop0
	.falign
.LBB32_12:                              // %for.cond.cleanup.i
	{
		r11:10 = combine(r7,r8)
		r14 = memw(r6+#28)
		r3 = memw(r6+#32)
	}
	{
		r12 = ##-1431655765
		r7 = add(r14,#23)
		r13 = add(r3,#127)
	}
	{
		r7 = mpyu(r7,r12)
		p0 = cmp.gtu(r13,#127)
		r15 = add(r14,#95)
		r9:8 = memd(r6+#56)
	}
	{
		r28 = mpyu(r15,r12)
		r15 = lsr(r13,#7)
		memd(r17+#152) = r11:10
		memw(r17+#184) = #0
	}
	{
		r1 = lsr(r7,#4)
		r7 = lsr(r28,#6)
		r11:10 = combine(r15,r14)
	}
	{
		r14 = +mpyi(r1,##640)
		r13:12 = and(r5:4,~r9:8)
		memd(r17+#168) = r11:10
	}
	{
		r11:10 = combine(r14,r7)
		if (p0) r14 = #0
		memd(r17+#160) = r13:12
	}
	{
		if (!p0) jump:nt .LBB32_21
		memd(r17+#176) = r11:10
	}
// %bb.13:
	{
		r1 = lsr(r15,#1)
		r21:20 = combine(#0,#1)
		r11:10 = combine(#0,#0)
	}
	{
		r28 = and(r15,#1)
		if (!p1.new) r15 = #0
		p1 = cmp.gtu(r1,#0); if (!p1.new) jump:t .LBB32_20
	}
// %bb.14:
	{
		loop0(.LBB32_15,r1)
		r15 = #0
	}
	.falign
.LBB32_15:                              // =>This Inner Loop Header: Depth=1
	{
		r23:22 = combine(r13,r12)
		r1 = add(r14,r7)
		r19 = add(r15,#1)
	}
	{
		r23:22 &= asl(r21:20,r15)
		r15 = add(r15,#2)
	}
	{
		p0 = cmp.eq(r23:22,r11:10)
		r23:22 = combine(r13,r12)
	}
	{
		r23:22 &= asl(r21:20,r19)
		if (!p0) r14 = add(r1,#0)
		if (!p0) memw(r17+#184) = r1
	}
	{
		p1 = cmp.eq(r23:22,r11:10)
		r19 = add(r14,r7)
	}
	{
		if (!p1) r14 = add(r19,#0)
		if (!p1) memw(r17+#184) = r19
	} :endloop0
// %bb.16:
	{
		p0 = cmp.gtu(r28,#0)
		if (!p0.new) jump:t .LBB32_21
	}
	.falign
.LBB32_17:                              // Block address taken
                                        // %for.body25.i
	{
		r13:12 &= asl(r21:20,r15)
		r7 = add(r14,r7)
	}
	{
		p1 = cmp.eq(r13:12,r11:10)
		jump .LBB32_21
		if (!p1.new) memw(r17+#184) = r7
	}
	.falign
.LBB32_18:                              // %if.else
	{
		call hvx_expand_i2i4_table
		r1 = add(r17,#24)
		r19 = r0
		r0 = r2
	}
	.falign
// %bb.19:                              // %if.else
	{
		r0 = r19 ; jump .LBB32_44
	}
	.falign
.LBB32_20:
	{
		p0 = cmp.gtu(r28,#0)
		if (p0.new) jump:t .LBB32_17
	}
	.falign
.LBB32_21:                              // %for.cond.cleanup24.i
	{
		r2 = memb(r2+#0)
	}
	{
		r7 = abs(r2)
		r2 = #0
	}
	{
		p1 = cmp.eq(r7,#0); if (p1.new) jump:nt .LBB32_24
	}
// %bb.22:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#7); if (p0.new) jump:nt .LBB32_24
	}
// %bb.23:                              // %for.cond.cleanup24.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB32_43
	}
	.falign
.LBB32_24:                              // %for.inc.i.i
	{
		r12 = memb(r6+#89)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB32_29
	}
// %bb.25:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB32_27
	}
// %bb.26:                              // %for.inc.i.i
	{
		p0 = cmp.eq(r12,#1)
		if (!p0.new) jump:t .LBB32_43
	}
	.falign
.LBB32_27:                              // %lor.lhs.false.1.i.i
	{
		if (p1) jump:nt .LBB32_30
	}
// %bb.28:                              // %lor.lhs.false.1.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB32_43
	}
	{
		jump .LBB32_30
	}
	.falign
.LBB32_29:
	{
		r12 = r7
	}
	.falign
.LBB32_30:                              // %for.inc.1.i.i
	{
		r7 = memb(r6+#90)
	}
	{
		r7 = abs(r7)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB32_35
	}
// %bb.31:                              // %for.inc.1.i.i
	{
		p1 = cmp.eq(r7,#7); if (p1.new) jump:nt .LBB32_33
	}
// %bb.32:                              // %for.inc.1.i.i
	{
		p0 = cmp.eq(r7,#1); if (!p0.new) jump:t .LBB32_43
	}
	.falign
.LBB32_33:                              // %lor.lhs.false.2.i.i
	{
		p1 = cmp.eq(r12,#0)
		if (p1.new) jump:nt .LBB32_36
	}
// %bb.34:                              // %lor.lhs.false.2.i.i
	{
		p0 = cmp.eq(r12,r7)
		if (!p0.new) jump:t .LBB32_43
	}
	{
		jump .LBB32_36
	}
	.falign
.LBB32_35:
	{
		r7 = r12
	}
	.falign
.LBB32_36:                              // %for.inc.2.i.i
	{
		r12 = memb(r6+#91)
	}
	{
		r12 = abs(r12)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB32_41
	}
// %bb.37:                              // %for.inc.2.i.i
	{
		p0 = cmp.eq(r12,#7)
		if (p0.new) jump:nt .LBB32_39
	}
// %bb.38:                              // %for.inc.2.i.i
	{
		p1 = cmp.eq(r12,#1)
		if (!p1.new) jump:t .LBB32_43
	}
	.falign
.LBB32_39:                              // %lor.lhs.false.3.i.i
	{
		p0 = cmp.eq(r7,#0); if (p0.new) jump:nt .LBB32_42
	}
// %bb.40:                              // %lor.lhs.false.3.i.i
	{
		p1 = cmp.eq(r7,r12)
		if (!p1.new) jump:t .LBB32_43
	}
	{
		jump .LBB32_42
	}
	.falign
.LBB32_41:
	{
		r12 = r7
	}
	.falign
.LBB32_42:                              // %for.inc.3.i.i
	{
		r2 = #1
	}
	{
		r2 = maxu(r12,r2)
	}
	.falign
.LBB32_43:                              // %moe_expand_native.exit
	{
		r3 = and(##-512,asl(r3,#4))
		r5:4 = or(r9:8,r5:4)
		memw(r17+#188) = r2
	}
	{
		memw(r17+#12) = r3
		memd(r6+#56) = r5:4
	}
	.falign
.LBB32_44:                              // %if.end13
	{
		r2 = add(pc,##moe_expand_unit@PCREL)
		r1 = r18
		memw(r18+#4) = r17
	}
	{
		memw(r18+#12) = r16
		memw(r18+#0) = r2
	}
	{
		r17:16 = memd(r29+#24)
		memw(r18+#8) = #8
	}                                       // 8-byte Folded Reload
	{
		r19:18 = memd(r29+#16)
		r21:20 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		jump hvx_worker_pool_submit_bg
		r23:22 = memd(r29+#0)
		deallocframe
	}                                       // 8-byte Folded Reload
.Lfunc_end32:
	.size	moe_expand_submit, .Lfunc_end32-moe_expand_submit
                                        // -- End function
	.falign
	.type	moe_gu_worker,@function         // -- Begin function moe_gu_worker
moe_gu_worker:                          // @moe_gu_worker
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r18 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#8) = r19:18
		memd(r29+#0) = r21:20
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB33_5
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r5:4 = c31:30
	}
	//# InlineAsm End
	{
		r20 = r0
		r1:0 = combine(r5,r4)
		r19 = r1
		r16 = r2
	}
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r2 = r16
		r17:16 = combine(r1,r0)
		r1:0 = combine(r19,r20)
	}
	{
		r3 = memw(r2+#60)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB33_6
	}
	.falign
.LBB33_3:                               // %if.then2
	{
		call hvx_dq_swiglu_i24
	}
	.falign
// %bb.4:                               // %if.then2
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB33_11
	}
	{
		jump .LBB33_14
	}
	.falign
.LBB33_5:
	{
		r17:16 = combine(#0,#0)
		r3 = memw(r2+#60)
		if (!cmp.eq(r3.new,#0)) jump:t .LBB33_3
	}
	.falign
.LBB33_6:                               // %if.else
	{
		r3 = memw(r2+#64)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB33_9
	}
// %bb.7:                               // %if.then4
	{
		call hvx_dq_swiglu_affine
		r4 = add(r2,#68)
	}
	.falign
// %bb.8:                               // %if.then4
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB33_11
	}
	{
		jump .LBB33_14
	}
	.falign
.LBB33_9:                               // %if.else7
	{
		call hvx_dq_swiglu_worker
	}
	.falign
// %bb.10:                              // %if.else7
	{
		r2 = memw(r18+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB33_14
	}
	.falign
.LBB33_11:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.12:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB33_13:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r18+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB33_13
	}
	.falign
.LBB33_14:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end33:
	.size	moe_gu_worker, .Lfunc_end33-moe_gu_worker
                                        // -- End function
	.falign
	.type	moe_dn_worker,@function         // -- Begin function moe_dn_worker
moe_dn_worker:                          // @moe_dn_worker
// %bb.0:                               // %entry
	{
		r3 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#-16) = r17:16
		allocframe(#80)
	}                                       // 8-byte Folded Spill
	{
		r17:16 = combine(r1,r0)
		r20 = r2
		memd(r29+#56) = r21:20
		memd(r29+#64) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#48) = r23:22
		memd(r29+#40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#32) = r27:26
		memw(r29+#20) = r3
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB34_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB34_4
	}
	{
		jump .LBB34_13
	}
	.falign
.LBB34_3:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#24) = r1:0
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r20+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_13
	}
	.falign
.LBB34_4:                               // %if.then2
	{
		r19:18 = vaslw(r17:16,#6)
		r27:26 = vaslw(r17:16,#4)
		p0 = cmp.gtu(r17,#3); if (p0.new) jump:t .LBB34_13
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r25 = sub(#0,r27)
		r2 = memw(r20+#860)
	}
	{
		r2 = add(r2,#3)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r5 = and(r2,#-4)
		memw(r29+#16) = r5.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB34_6:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r5,r27)
		if (!p1.new) jump:nt .LBB34_13
		if (p1.new) r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
// %bb.7:                               // %if.end6
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r2 = add(r2,r25)
		r3 = memw(r20+#864)
		r4 = memw(r20+#860)
	}
	{
		r0 = mpyi(r3,r27)
		p0 = cmp.gtu(r2,#15)
		r2 = add(r25,r4)
		r1 = memw(r20+#856)
	}
	{
		r24 = addasl(r1,r0,#2)
		if (p0) r21 = add(r27,#16)
		if (!p0) r21 = add(r5,#0)
	}
	{
		r22 = add(r21,r25)
	}
	{
		r4 = maxu(r22,r2)
		r23 = minu(r2,r22)
		p1 = cmp.gtu(r22,r2); if (!p1.new) jump:t .LBB34_10
	}
// %bb.8:                               // %if.then24
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r5 = mpyi(r23,r3)
		r1 = #0
	}
	{
		r0 = addasl(r24,r5,#2)
		r2 = sub(r4,r2)
	}
	{
		r2 = mpyi(r3,r2)
	}
	{
		call memset
		r2 = asl(r2,#2)
	}
	.falign
// %bb.9:                               // %if.then24
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r3 = memw(r20+#864)
	}
	.falign
.LBB34_10:                              // %for.inc
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r1:0 = combine(r23,r24)
		r5 = memw(r20+#872)
		r2 = memw(r20+#868)
	}
	{
		r4 = add(r2,r19)
		r5 = add(r5,r19)
		r2 = r22
		memw(r29+#0) = #0
	}
	{
		call hvx_quant_rows_u8_params
	}
	.falign
// %bb.11:                              // %for.inc
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r1 = #0
		r2 = memw(r20+#872)
		r4 = memw(r20+#864)
	}
	{
		r3 = memw(r20+#876)
		r0 = memw(r20+#856)
	}
	{
		r5 = memw(r20+#868)
		memw(r29+#4) = r3

	} :mem_noshuf
	{
		call hvx_quant_pack_u8_ah_rows
		r3:2 = combine(r21,r27)
		memw(r29+#0) = r2
	}
	.falign
// %bb.12:                              // %for.inc
                                        //   in Loop: Header=BB34_6 Depth=1
	{
		r27 = add(r27,r26)
		r25 = sub(r25,r26)
		r19 = add(r19,r18)
		r5 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r17 = add(r17,r16)
		if (!cmp.gtu(r17.new,#3)) jump:t .LBB34_6
	}
	.falign
.LBB34_13:                              // %if.end44
	{
		r16 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB34_17
	}
// %bb.14:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.15:                              // %if.then.i
	{
		r3:2 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r3:2)
	}
	.balign 32
.LBB34_16:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p0) = r5:4
	}
	{
		if (!p0) jump:nt .LBB34_16
	}
	.falign
.LBB34_17:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#72)
		r19:18 = memd(r29+#64)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#56)
		r23:22 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#40)
		r27:26 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end34:
	.size	moe_dn_worker, .Lfunc_end34-moe_dn_worker
                                        // -- End function
	.falign
	.type	moe_dn_unit,@function           // -- Begin function moe_dn_unit
moe_dn_unit:                            // @moe_dn_unit
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#24)
	}                                       // 8-byte Folded Spill
	{
		r20 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		memd(r29+#0) = r21:20
		memd(r29+#8) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19:18 = combine(r1,r2)
	}
	{
		r3 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r3 = memw(r3+#0)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB35_3
	}
// %bb.1:                               // %if.then
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17:16 = combine(r1,r0)
		jump .LBB35_4
	}
	.falign
.LBB35_3:
	{
		r17:16 = combine(#0,#0)
	}
	.falign
.LBB35_4:                               // %do.end
	{
		r1 = asl(r19,#2)
		r0 = r18
		r2 = #4
		r3 = memw(r18+#20)
	}
	{
		r2 = addasl(r2,r19,#2)
		r4 = sub(r3,r1)
	}
	{
		call moe_dn_rows
		p1 = cmp.gtu(r4,#3)
		if (!p1.new) r2 = add(r3,#0)
	}
	.falign
// %bb.5:                               // %do.end
	{
		r2 = memw(r20+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB35_9
	}
// %bb.6:                               // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.7:                               // %if.then.i
	{
		r1:0 = sub(r1:0,r17:16)
	}
	.balign 32
.LBB35_8:                               // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r20+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB35_8
	}
	.falign
.LBB35_9:                               // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#16)
		r19:18 = memd(r29+#8)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#0)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end35:
	.size	moe_dn_unit, .Lfunc_end35-moe_dn_unit
                                        // -- End function
	.falign
	.type	moe_dn_fg_worker,@function      // -- Begin function moe_dn_fg_worker
moe_dn_fg_worker:                       // @moe_dn_fg_worker
// %bb.0:                               // %entry
	{
		r17 = r0
		memd(r29+#-16) = r17:16
		allocframe(#32)
	}                                       // 8-byte Folded Spill
	{
		r20 = r1
		r16 = memw(r2+#4)
		memd(r29+#8) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#16) = r19:18
		memd(r29+#0) = r23:22
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r16+#856)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB36_2
	}
// %bb.1:                               // %if.then
	{
		call moe_dn_worker
		r1:0 = combine(r20,r17)
		r2 = r16
	}
	.falign
.LBB36_2:                               // %if.end
	{
		r21 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB36_5
	}
// %bb.3:                               // %if.then3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.4:                               // %if.then3
	{
		r19:18 = combine(r1,r0)
		jump .LBB36_6
	}
	.falign
.LBB36_5:
	{
		r19:18 = combine(#0,#0)
	}
	.falign
.LBB36_6:                               // %do.end
	{
		r1 = r17
		r22 = memw(r16+#20)
	}
	{
		r0 = mpyi(r22,r20)
		call __hexagon_udivsi3
	}
	.falign
// %bb.7:                               // %do.end
	{
		r20 = r0
		r1 = r17
		r2 = add(r20,#1)
	}
	{
		r0 = mpyi(r22,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %do.end
	{
		call moe_dn_rows
		r2 = r0
		r1:0 = combine(r20,r16)
	}
	.falign
// %bb.9:                               // %do.end
	{
		r2 = memw(r21+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB36_13
	}
// %bb.10:                              // %if.then.i
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.11:                              // %if.then.i
	{
		r1:0 = sub(r1:0,r19:18)
	}
	.balign 32
.LBB36_12:                              // %atomicrmw.start
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = memw(r21+##hexkl_probe_us@GOT)
	}
	{
		r2 = add(r2,#112)
	}
	{
		r5:4 = memd_locked(r2)
	}
	{
		r5:4 = add(r5:4,r1:0)
	}
	{
		memd_locked(r2,p1) = r5:4
	}
	{
		if (!p1) jump:nt .LBB36_12
	}
	.falign
.LBB36_13:                              // %moe_worker_probe_add.exit
	{
		r17:16 = memd(r29+#24)
		r19:18 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#8)
		r23:22 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end36:
	.size	moe_dn_fg_worker, .Lfunc_end36-moe_dn_fg_worker
                                        // -- End function
	.falign
	.type	moe_push_weight_chunk,@function // -- Begin function moe_push_weight_chunk
moe_push_weight_chunk:                  // @moe_push_weight_chunk
// %bb.0:                               // %entry
	{
		memd(r29+#-16) = r17:16
		allocframe(#56)
	}                                       // 8-byte Folded Spill
	{
		r18 = r5
		r6 = memw(r3+#44)
		memd(r29+#40) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r6,#0)
		r5 = memw(r29+#64)
		memd(r29+#32) = r21:20
	}
	{
		if (p0) r2 = add(r3,#0)
		r21 = r4
		r17 = memw(r29+#76)
		r16 = memw(r29+#80)
	}
	{
		if (p0) jump:nt .LBB37_3
		r20 = memw(r29+#72)
		r19 = memw(r29+#68)
	}
// %bb.1:                               // %if.then
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
		r4 = add(r29,#20)
		memw(r29+#4) = r4.new
	}
	{
		r4 = r5
		r5 = r19
		memw(r29+#20) = r20
		memw(r29+#24) = r17
	}
	{
		r6 = memw(r6+#0)
		memw(r29+#28) = r16
	}
	{
		call moe_push_native_chunk
		memw(r29+#0) = r6
	}
	.falign
.LBB37_2:                               // %return
	{
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
	.falign
.LBB37_3:                               // %if.end
	{
		r6 = add(pc,##g_moe_src_bypass@PCREL)
	}
	{
		r4 = r18
		r3 = r4
		memw(r29+#0) = r19
	}
	{
		call hexkl_moe_push_weight_chunk
		r6 = memw(r6+#0)
		memw(r29+#4) = r6.new
	}
	.falign
// %bb.4:                               // %if.end
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB37_2
	}
// %bb.5:                               // %if.then6
	//# InlineAsm Start
	{
		r3:2 = c31:30
	}
	//# InlineAsm End
	{
		r7:6 = vaslw(r19:18,#9)
		r18 = r0
		r1:0 = combine(r3,r2)
		r5:4 = combine(r16,r17)
	}
	{
		r3:2 = combine(r20,r18)
		memw(r29+#0) = r7
		memw(r29+#4) = r21
	}
	{
		call hexkl_dma_trace_push
		memw(r29+#8) = r6
	}
	.falign
// %bb.6:                               // %if.then6
	{
		r0 = r18
		r17:16 = memd(r29+#48)
		r19:18 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#32)
		dealloc_return
	}                                       // 8-byte Folded Reload
.Lfunc_end37:
	.size	moe_push_weight_chunk, .Lfunc_end37-moe_push_weight_chunk
                                        // -- End function
	.globl	hexkl_mm_u8i4_fc_m1_run         // -- Begin function hexkl_mm_u8i4_fc_m1_run
	.falign
	.type	hexkl_mm_u8i4_fc_m1_run,@function
hexkl_mm_u8i4_fc_m1_run:                // @hexkl_mm_u8i4_fc_m1_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#656):raw
	}                                       // 8-byte Folded Spill
	{
		r23 = ##-2147449856
		memd(r29+#624) = r23:22
		memd(r29+#640) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19 = r0
		r0 = add(r23,#-32754)
		memd(r29+#632) = r21:20
		memd(r29+#616) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB38_34
		memd(r29+#608) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r26 = memw(r29+#664)
		if (cmp.eq(r26.new,#0)) jump:nt ##.LBB38_34
	}
// %bb.2:                               // %entry
	{
		r18 = memw(r29+#668)
		if (cmp.eq(r18.new,#0)) jump:nt ##.LBB38_34
	}
// %bb.3:                               // %entry
	{
		r24 = memw(r29+#672)
		if (cmp.eq(r24.new,#0)) jump:nt ##.LBB38_34
	}
// %bb.4:                               // %entry
	{
		r22 = memw(r29+#680)
		if (cmp.eq(r22.new,#0)) jump:nt .LBB38_34
	}
// %bb.5:                               // %if.end
	{
		r6 = add(r5,#-65)
		r0 = add(r23,#-32751)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB38_34
	}
// %bb.6:                               // %lor.lhs.false8
	{
		p1 = !bitsclr(r4,#31)
		if (p1.new) jump:nt .LBB38_34
	}
// %bb.7:                               // %lor.lhs.false8
	{
		r20 = add(r29,#32)
		r7 = #-64
		if (cmp.gtu(r7.new,r6)) jump:nt .LBB38_34
	}
// %bb.8:                               // %for.body.lr.ph
	{
		r2 = #568
		memw(r29+#12) = r1
		memw(r29+#20) = r2
	}                                       // 4-byte Folded Spill
	{
		r1:0 = combine(#0,r20)
		r17:16 = combine(r4,r5)
		r3 = memw(r29+#676)
		memw(r29+#16) = r3
	}
	{
		call memset
		r25 = memw(r29+#684)
		memw(r29+#24) = r3
	}
	.falign
// %bb.9:                               // %for.body.lr.ph
	{
		r4 = lsr(r17,#5)
		r21 = add(r20,#12)
		r3:2 = combine(r17,r16)
		memw(r29+#564) = r4.new
	}
	{
		r0 = add(r23,#-32752)
		r5:4 = combine(r21,r16)
	}
	.falign
.LBB38_10:                              // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = #4095
	}
	{
		r6 = memw(r26+#0)
		if (cmp.gtu(r6.new,r6)) jump:nt .LBB38_34
	}
// %bb.11:                              // %cond.end
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		r6 = +mpyi(r6,#96)
	}
	{
		r7 = memw(r19+r6<<#0)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB38_34
	}
// %bb.12:                              // %lor.lhs.false23
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		r6 = add(r19,r6)
	}
	{
		r7 = memw(r6+#28)
		if (!cmp.eq(r7.new,r3)) jump:nt .LBB38_34
	}
// %bb.13:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		r7 = memw(r6+#32)
		if (cmp.eq(r7.new,#0)) jump:nt .LBB38_34
	}
// %bb.14:                              // %lor.lhs.false26
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		r8 = and(r7,#31)
		if (!cmp.eq(r8.new,#0)) jump:nt .LBB38_34
	}
// %bb.15:                              // %lor.lhs.false32
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		r26 = add(r26,#4)
		r4 = add(r4,#-1)
		r8 = memw(r6+#84)
		if (cmp.eq(r8.new,#2)) jump:nt .LBB38_34
	}
// %bb.16:                              // %for.inc
                                        //   in Loop: Header=BB38_10 Depth=1
	{
		p1 = cmp.eq(r4,#0)
		r8 = memw(r5+#256)
	}
	{
		r8 += lsr(r7,#5)
		memw(r5+#260) = r8.new
	}
	{
		if (!p1) jump:nt .LBB38_10
		if (p1) r6 = memw(r29+##564)
		memw(r5++#4) = r6
	}
// %bb.17:                              // %for.end
	{
		r26 = asl(r6,#11)
		r7 = add(r29,#32)
		r1:0 = combine(#0,#1)
		memw(r29+#28) = r0
	}                                       // 4-byte Folded Spill
	{
		r7 = addasl(r7,r2,#2)
		r19 = setbit(r26,#9)
		r9:8 = combine(#0,#0)
		r5:4 = memd(r22+#24)
	}
	{
		r1:0 = add(r5:4,r1:0)
		memw(r29+#560) = r2
		memd(r22+#40) = r9:8
	}
	{
		r0 = memw(r22+#8)
		memd(r22+#24) = r1:0
	}
	{
		p0 = cmp.gtu(r19,r0)
		r2 = memw(r7+#268)
		memd(r22+#56) = r9:8
	}
	{
		if (!p0) jump:nt .LBB38_22
		memw(r22+#48) = #0
		memw(r29+#568) = r2
	}
// %bb.18:                              // %hexkl_moe_scratch_free.exit.i
	{
		r3:2 = combine(#0,#2)
		r0 = memw(r22+#0)
		memw(r22+#56) = #0
	}
	{
		r3:2 = add(r5:4,r3:2)
	}
	{
		call free
		memd(r22+#24) = r3:2
	}
	.falign
// %bb.19:                              // %hexkl_moe_scratch_free.exit.i
	{
		r0 = or(r26,##640)
		memw(r22+#4) = #0
		memw(r22+#8) = #0
	}
	{
		call malloc
	}
	.falign
// %bb.20:                              // %hexkl_moe_scratch_free.exit.i
	{
		if (!p1.new) r2 = add(r0,#127)
		p1 = cmp.eq(r0,#0); if (p1.new) jump:nt .LBB38_35
		memw(r22+#0) = r0
	}
// %bb.21:                              // %if.end3.i
	{
		r3 = r17
		memw(r22+#8) = r19
	}
	{
		r19 = and(r2,#-128)
		jump .LBB38_23
		memw(r22+#4) = r19.new
	}
	.falign
.LBB38_22:                              // %for.end.if.end56_crit_edge
	{
		r19 = memw(r22+#4)
	}
	.falign
.LBB38_23:                              // %for.body78.lr.ph
	{
		r20 = add(r19,r26)
		r1:0 = combine(#1,r18)
		r2 = #64
		memw(r29+#0) = #0
	}
	{
		r27 = add(r20,#256)
		r22 = r3
	}
	{
		call hvx_quant_rows_u8_params
		r5:4 = combine(r27,r20)
	}
	.falign
// %bb.24:                              // %for.body78.lr.ph
	{
		r1:0 = combine(r22,r18)
		r4 = r19
		r2 = memw(r19+r26<<#0)
		r3 = memw(r20+#256)
	}
	{
		memw(r20+#4) = r2
		memw(r20+#260) = r3
	}
	{
		memw(r20+#8) = r2
		memw(r20+#264) = r3
	}
	{
		call hvx_quant_pack_u8_ah_m1_repeat
		memw(r20+#12) = r2
		memw(r20+#268) = r3
	}
	.falign
// %bb.25:                              // %for.body78.lr.ph
	{
		r2 = memw(r29+#16)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	.falign
.LBB38_26:                              // %for.body78
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = memw(r21+#0)
	}
	{
		r21 = add(r21,#4)
		r5 = memw(r5+#20)
		if (!cmp.eq(r5.new,#0)) jump:nt .LBB38_28
	}
// %bb.27:                              // %for.cond75
                                        //   in Loop: Header=BB38_26 Depth=1
	{
		r16 = add(r16,#-1)
		if (!cmp.eq(r16.new,#0)) jump:t .LBB38_26
	}
	{
		jump .LBB38_30
	}
	.falign
.LBB38_28:                              // %if.then82
	{
		r4 = add(r29,#32)
		r1:0 = combine(#1,r19)
		r3:2 = combine(r27,r17)
	}
	{
		call hexkl_wh_affine_sums
		r4 = add(r4,#540)
	}
	.falign
// %bb.29:                              // %if.then82
	{
		r3 = memw(r29+#20)
		r4 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	.falign
.LBB38_30:                              // %cleanup86
	{
		r7 = extractu(r25,#1,#16)
		p1 = !tstbit(r25,#6)
		r5 = and(r25,##131104)
	}
	{
		r6 = extractu(r25,#1,#18)
		p0 = cmp.eq(r5,#32)
		if (p1) r7 = #1
		memw(r29+#32) = r19
	}
	{
		r2 = minu(r3,r2)
		r5 = mux(p0,#0,r4)
		memw(r29+#36) = r20
		memw(r29+#40) = r27
	}
	{
		p0 = cmp.eq(r5,#0)
		memw(r29+#576) = r24
		memw(r29+#588) = r7
	}
	{
		memw(r29+#592) = r6
		memw(r29+#584) = r2
	}
	{
		if (p0) jump:nt .LBB38_32
		memw(r29+#580) = r5
	}
// %bb.31:                              // %if.then109
	{
		call hexkl_dma_ring_drain
	}
	.falign
.LBB38_32:                              // %if.end110
	{
		r1 = add(pc,##fc_m1_worker@PCREL)
		r3 = #8
		r2 = memw(r29+#568)
	}
	{
		r3 = minu(r2,r3)
		call hvx_worker_pool_run
		r2 = add(r29,#32)
		r0 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.33:                              // %if.end110
	{
		r2 = memw(r29+#596)
		r0 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
		if (p1.new) r0 = #0
		if (!p1.new) r0 = add(r23,##-32767)
	}
	.falign
.LBB38_34:                              // %cleanup128
	{
		r17:16 = memd(r29+#648)
		r19:18 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#632)
		r23:22 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#616)
		r27:26 = memd(r29+#608)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB38_35:
	{
		r0 = add(r23,#-32766)
		jump .LBB38_34
	}
.Lfunc_end38:
	.size	hexkl_mm_u8i4_fc_m1_run, .Lfunc_end38-hexkl_mm_u8i4_fc_m1_run
                                        // -- End function
	.falign
	.type	fc_m1_worker,@function          // -- Begin function fc_m1_worker
fc_m1_worker:                           // @fc_m1_worker
// %bb.0:                               // %entry
	{
		allocframe(r29,#896):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r22 = r0
		r24 = r1
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		r1 = r22
		r16 = r2
		r0 = memw(r2+#552)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-24) = r21:20
		memd(r30+#-16) = r19:18
	}                                       // 8-byte Folded Spill
	{
		call __hexagon_udivsi3
		r20 = memw(r2+#532)
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
// %bb.1:                               // %entry
	{
		r26 = asl(r20,#10)
		r17 = and(r0,#-128)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r26,r17)
	}
	.falign
// %bb.2:                               // %entry
	{
		r23 = #0
		r25 = r0
		r5:4 = combine(#0,#0)
		r27 = memw(r16+#536)
	}
	{
		r3:2 = combine(r23,r22)
		r21 = memw(r16+#548)
		memd(r29+#240) = r5:4
	}
	{
		r1:0 = mpyu(r27,r24)
		call __hexagon_udivdi3
	}
	.falign
// %bb.3:                               // %entry
	{
		r2 = add(r24,#1)
		r19:18 = combine(r1,r0)
	}
	{
		r1:0 = mpyu(r27,r2)
		call __hexagon_udivdi3
		r3:2 = combine(r23,r22)
	}
	.falign
// %bb.4:                               // %entry
	{
		r2 = r0
		p0 = cmp.gtu(r0,r18)
	}
	{
		if (!p0) jump:nt .LBB39_71
		memd(r29+#248) = r3:2
	}                                       // 8-byte Folded Spill
// %bb.5:                               // %if.end
	{
		p1 = cmp.gtu(r26,r17)
		r4 = #1
		p0 = cmp.eq(r21,#0)
	}
	{
		p1 = not(p1)
	}
	{
		p1 = and(p1,!p0)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB39_10
		if (p1) r1:0 = memd(r29+#248)
		memw(r29+#216) = r2.new
	}                                       // 8-byte Folded Reload
// %bb.6:                               // %if.then5
	{
		r2 = add(r0,sub(#3,r18))
	}
	{
		r4 = lsr(r2,#2)
		r2 = asl(r20,#9)
	}
	{
		r4 = minu(r4,r25)
		r3 = memw(r16+#556)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB39_9
	}
// %bb.7:                               // %if.then5
	{
		r3 = add(r4,#3)
		p1 = cmp.gtu(r25,#3)
		if (!p1.new) jump:nt .LBB39_9
	}
// %bb.8:                               // %if.then11
	{
		r4 = and(r4,##1073741820)
		r3 = and(r3,##2147483644)
	}
	{
		p0 = cmp.gtu(r3,r25)
		if (!p0.new) r4 = add(r3,#0)
	}
	.falign
.LBB39_9:                               // %if.end20
	{
		r21 += mpyi(r17,r24)
		memw(r29+#240) = r21.new
	}
	{
		r21 += mpyi(r2,r4)
		r23 = r21
		memw(r29+#244) = r21.new
	}
	.falign
.LBB39_10:                              // %if.end28
	{
		r25 = add(r16,#272)
	}
	{
		r3 = r25
	}
	.balign 32
.LBB39_11:                              // %while.cond.i.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p1 = cmp.gtu(r3,r18); if (!p1.new) jump:t .LBB39_11
	}
// %bb.12:                              // %fc_m1_block_end.exit
	{
		r3 = add(r4,r18)
		r2 = memw(r2+#0)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r5 = add(pc,##g_fc_m1_desc@PCREL)
		r2 = minu(r3,r2)
		memw(r29+#236) = r4
	}                                       // 4-byte Folded Spill
	{
		r5 += asl(r24,#8)
		r3 = r25
	}
	{
		r26 = minu(r2,r0)
		r0 = memw(r29+#216)
		memw(r29+#232) = r5
	}                                       // 4-byte Folded Reload
	{
		p0 = r0
		if (!p0.new) jump:t .LBB39_20
	}
	.balign 32
.LBB39_14:                              // %while.cond.i.i318
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		r3 = add(r2,#4)
		p0 = cmp.gtu(r3,r18); if (!p0.new) jump:t .LBB39_14
	}
// %bb.15:                              // %fc_m1_part.exit.i
	{
		r4 = memw(r2+#-260)
		r3 = memw(r16+#560)
	}
	{
		p1 = cmp.eq(r3,#0)
		r6 = memw(r4+#36)
		r2 = memw(r2+#-4)
	}
	{
		if (p1) r6 = #0
		if (p1) jump:nt .LBB39_19
		r3 = memw(r4+#4)
		r5 = memw(r4+#32)
	}
// %bb.16:                              // %land.rhs.i.i
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB39_19
		if (p0.new) r4 = memw(r4+#40)
	}
// %bb.17:                              // %lor.rhs.i.i
	{
		r6 = !cmp.eq(r4,#0)
	}
	.falign
.LBB39_19:                              // %fc_m1_push.exit
	{
		r5 = and(##-512,asl(r5,#4))
		r7 = sub(r18,r2)
		r4 = sub(r26,r18)
	}
	{
		r4 = asl(r4,#9)
		r1 = #0
		r2 = r23
		r0 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
	{
		r3 += asl(r7,#9)
		memw(r29+#8) = r6
		memw(r29+#4) = r20
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	.falign
.LBB39_20:                              // %while.body.lr.ph
	{
		r23 = #0
		r17 = r26
	}
	.falign
.LBB39_21:                              // %while.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB39_22 Depth 2
                                        //     Child Loop BB39_29 Depth 2
                                        //     Child Loop BB39_36 Depth 2
                                        //     Child Loop BB39_39 Depth 2
                                        //       Child Loop BB39_54 Depth 3
                                        //       Child Loop BB39_58 Depth 3
	{
		r3 = r25
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		p1 = cmp.gtu(r0,r26)
	}
	{
		r2 = p1
		if (!p1) jump:nt .LBB39_24
		memw(r29+#220) = r2.new
	}                                       // 4-byte Folded Spill
	.balign 32
.LBB39_22:                              // %while.cond.i.i328
                                        //   Parent Loop BB39_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = r3
		r3 = memw(r3+#0)
	}
	{
		p1 = cmp.gtu(r3,r26)
		r3 = add(r2,#4)
		if (!p1.new) jump:t .LBB39_22
	}
// %bb.23:                              // %fc_m1_block_end.exit340
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r3 = memw(r29+#236)
		r2 = memw(r2+#0)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r26,r3)
		r1:0 = memd(r29+#248)
	}                                       // 8-byte Folded Reload
	{
		r2 = minu(r3,r2)
	}
	{
		r17 = minu(r2,r0)
	}
	.falign
.LBB39_24:                              // %cond.end39
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r19 = togglebit(r23,#0)
		r2 = r25
		r3 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		if (!p0.new) jump:t .LBB39_36
		if (p0.new) r2 = memw(r29+#232)
	}                                       // 4-byte Folded Reload
// %bb.25:                              // %if.then42
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r0 = addasl(r2,r23,#7)
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.26:                              // %if.then42
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r2 = r25
		p0 = cmp.eq(r0,#0); if (!p0.new) jump:nt .LBB39_70
	}
// %bb.27:                              // %if.end47
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r5 = r25
		p1 = cmp.gtu(r17,r26)
		if (!p1.new) jump:t .LBB39_36
	}
// %bb.28:                              // %if.then49
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r4 = togglebit(r23,#0)
		r2 = add(r29,#240)
	}
	{
		r2 = memw(r2+r4<<#2)
	}
	.balign 32
.LBB39_29:                              // %while.cond.i.i342
                                        //   Parent Loop BB39_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r3 = r5
		r5 = memw(r5+#0)
	}
	{
		p0 = cmp.gtu(r5,r26)
		r5 = add(r3,#4)
		if (!p0.new) jump:t .LBB39_29
	}
// %bb.30:                              // %fc_m1_part.exit.i348
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r5 = memw(r16+#560)
	}
	{
		if (p1.new) r6 = #0
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB39_34
		r5 = memw(r3+#-260)
	}
// %bb.31:                              // %land.rhs.i.i358
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r6 = memw(r5+#36)
	}
	{
		r6 = #1
		p0 = cmp.eq(r6,#0); if (!p0.new) jump:t .LBB39_34
	}
// %bb.32:                              // %lor.rhs.i.i368
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r6 = memw(r5+#40)
	}
	{
		r6 = !cmp.eq(r6,#0)
	}
	.falign
.LBB39_34:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r8 = sub(r17,r26)
		r1 = #0
		r7 = memw(r3+#-4)
		r3 = memw(r5+#4)
	}
	{
		r5 = memw(r5+#32)
		r9 = memw(r16+#532)
	}
	{
		r6 = sub(r26,r7)
		r12 = memw(r29+#232)
		memw(r29+#8) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = and(##-512,asl(r5,#4))
		r0 = addasl(r12,r4,#7)
		memw(r29+#12) = #1
	}
	{
		r3 += asl(r6,#9)
		r4 = asl(r8,#9)
		memw(r29+#4) = r9
	}
	{
		call hexkl_dma_lane_push2d
		memw(r29+#0) = r4
	}
	.falign
// %bb.35:                              // %fc_m1_push.exit371
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r2 = r25
	}
	.balign 32
.LBB39_36:                              // %while.cond.i
                                        //   Parent Loop BB39_21 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r22 = r2
		r2 = memw(r2+#0)
	}
	{
		r2 = add(r22,#4)
		p1 = cmp.gtu(r2,r18); if (!p1.new) jump:t .LBB39_36
	}
// %bb.37:                              // %fc_m1_part.exit
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		p0 = cmp.gtu(r26,r18)
		if (!p0.new) jump:t .LBB39_69
		memw(r29+#228) = r19
		memw(r29+#224) = r17
	}                                       // 4-byte Folded Spill
// %bb.38:                              // %for.body.lr.ph
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r19 = sub(r26,r18)
		r20 = r18
		r17 = memw(r22+#-260)
	}
	.falign
.LBB39_39:                              // %for.body
                                        //   Parent Loop BB39_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB39_54 Depth 3
                                        //       Child Loop BB39_58 Depth 3
	{
		r6 = add(r29,#256)
		r1 = #1
		r24 = memw(r22+#-4)
		r2 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		r21 = sub(r20,r24)
		if (!p1.new) jump:t .LBB39_44
		if (!p1.new) r4 = memw(r17+#32)
	}
// %bb.40:                              // %land.lhs.true62
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r4 = add(r29,#256)
		r5 = sub(r20,r18)
		r3 = add(r29,#240)
		r0 = memw(r16+#0)
	}
	{
		r3 = addasl(r3,r23,#2)
		r1 = #1
		r2 = memw(r16+#556)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB39_46
	}
// %bb.41:                              // %if.then65
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r4 = r19
		r2 = sub(r26,r20)
		if (!cmp.gtu(r2.new,#3)) jump:t .LBB39_48
	}
// %bb.42:                              // %if.then68
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r3 = add(r29,#256)
		r2 = memw(r3+#0)
		r0 = memw(r16+#0)
	}
	{
		call hvx_gemv_u8i4_wh_4col_nopf
		r3 = #512
		r1 = memw(r16+#532)
		memw(r29+#0) = r3

	} :mem_noshuf
	.falign
// %bb.43:                              // %if.then68
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #4
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB39_53
	}
	{
		jump .LBB39_61
	}
	.falign
.LBB39_44:                              // %if.else102
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r27 = #1
		r5 = memw(r16+#556)
		r0 = memw(r16+#0)
	}
	{
		r4 = lsr(r4,#5)
		r2 = memw(r16+#532)
	}
	{
		r5 = r21
		r3 = memw(r17+#4)
		memw(r29+#0) = r5

	} :mem_noshuf
	{
		call hvx_gemm_u8i4_wh_col
		memw(r29+#4) = r6
	}
	.falign
// %bb.45:                              // %if.else102
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB39_53
	}
	{
		jump .LBB39_61
	}
	.falign
.LBB39_46:                              // %if.then94
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r27 = #1
		r2 = memw(r16+#532)
	}
	{
		r4 = r19
		r3 = memw(r3+#0)
		memw(r29+#4) = r4
	}
	{
		call hvx_gemm_u8i4_wh_col_nopf
		memw(r29+#0) = #0
	}
	.falign
// %bb.47:                              // %if.then94
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = asl(r21,#5)
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB39_53
	}
	{
		jump .LBB39_61
	}
	.falign
.LBB39_48:                              // %if.else
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = add(r29,#256)
		p1 = cmp.eq(r2,#3)
		r0 = memw(r16+#0)
		r1 = memw(r16+#532)
	}
	{
		if (!p1) r3 = add(r19,#0)
		if (!p1) jump:nt .LBB39_51
		r4 = r5
		r2 = memw(r3+#0)
	}
// %bb.49:                              // %if.then76
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r3 = add(r29,#256)
		r4 = r19
		memw(r29+#0) = r3.new
	}
	{
		call hvx_gemv_u8i4_wh_3col_nopf
		r3 = #512
	}
	.falign
// %bb.50:                              // %if.then76
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #3
		r4 = memw(r17+#20)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB39_53
	}
	{
		jump .LBB39_61
	}
	.falign
.LBB39_51:                              // %if.else83
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		call hvx_gemv_u8i4_wh_col_aligned_nopf
		r5 = r6
	}
	.falign
// %bb.52:                              // %if.else83
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r6 = asl(r21,#5)
		r27 = #1
		r4 = memw(r17+#20)
		if (cmp.eq(r4.new,#0)) jump:nt .LBB39_61
	}
	.falign
.LBB39_53:                              // %if.then112
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r8 = addasl(r4,r6,#2)
		r7 = asl(r20,#7)
		r5 = add(r29,#256)
		r2 = memw(r16+#540)
	}
	{
		r7 -= asl(r24,#7)
		v0 = vsplat(r2)
		r14 = #0
		r13 = add(r5,#128)
	}
	{
		r12 = add(r4,add(r7,##128))
		r3 = asl(r27,#5)
	}
	.balign 32
.LBB39_54:                              // %for.body.us.i
                                        //   Parent Loop BB39_21 Depth=1
                                        //     Parent Loop BB39_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r14,#64)
		r9 = r14
		v2 = vmemu(r8+#0)
	}
	{
		r4 = r13
		p1 = cmp.gtu(r7,r3)
		r7 = r12
		v1 = vmem(r5+#0)
	}
	{
		v1.w += vmpyie(v0.w,v2.h)
		r8 = add(r8,#128)
		r14 = add(r14,#32)
		vmem(r5+#0) = v1.new
	}
	{
		r13 = add(r13,#128)
		r12 = add(r12,#128)
		r5 = add(r5,#128)
		if (!p1) jump:nt .LBB39_54
	}
// %bb.55:                              // %for.cond10.preheader.i
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r8 = add(r3,sub(#-32,r9))
		r5 = r7
		p0 = cmp.gtu(r3,r14)
		if (!p0.new) jump:t .LBB39_61
	}
// %bb.56:                              // %for.body17.us.i.preheader
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r9 = lsr(r8,#1)
		r3 = r4
		r8 = and(r8,#1)
	}
	{
		loop0(.LBB39_58,r9)
		p1 = cmp.gtu(r9,#0)
		if (!p1.new) jump:t .LBB39_59
	}
	.falign
.LBB39_58:                              //   Parent Loop BB39_21 Depth=1
                                        //     Parent Loop BB39_39 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r9 = memw(r5++#8)
		r12 = memw(r4+#0)
	}
	{
		r1 = memw(r4+#4)
	}
	{
		r12 += mpyi(r9,r2)
		memw(r3++#8) = r12.new
	}
	{
		r7 = r5
		r9 = memw(r7+#4)
	}
	{
		r1 += mpyi(r9,r2)
		r4 = r3
		memw(r4+#4) = r1.new
	} :endloop0
	.falign
.LBB39_59:                              //   in Loop: Header=BB39_39 Depth=2
	{
		p0 = cmp.gtu(r8,#0)
		if (!p0.new) jump:t .LBB39_61
		if (p0.new) r0 = memw(r3+#0)
		if (p0.new) r4 = memw(r5+#0)
	}
	.falign
.LBB39_60:                              // Block address taken
                                        // %for.body17.us.i
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r0 += mpyi(r4,r2)
		memw(r3++#4) = r0.new
	}
	.falign
.LBB39_61:                              // %if.end118
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r0 = add(r29,#256)
		p1 = cmp.eq(r27,#3)
		r2 = memw(r16+#544)
		r3 = memw(r16+#4)
	}
	{
		r7 = addasl(r2,r20,#7)
		if (p1) jump:nt .LBB39_65
		if (p1) r5:4 = memd(r17+#8)
		if (p1) r2 = memw(r16+#8)
	}
// %bb.62:                              // %if.end118
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r0 = add(r29,#256)
		p0 = cmp.eq(r27,#4)
		if (!p0.new) jump:nt .LBB39_67
		if (p0.new) r2 = memw(r16+#8)
	}
// %bb.63:                              // %if.then123
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r5:4 = memd(r17+#8)
		r8 = memw(r17+#16)
	}
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_4tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.64:                              // %if.then123
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t .LBB39_39
	}
	{
		jump .LBB39_69
	}
	.falign
.LBB39_65:                              // %if.then132
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r4 = addasl(r4,r6,#2)
		r3 = addasl(r5,r6,#2)
		r8 = memw(r17+#16)
		r1 = memw(r3+#0)
	}
	{
		r5 = addasl(r8,r6,#2)
		call hvx_dequant_acc_3tiles_m1_f32
		r2 = memw(r2+#0)
		memw(r29+#0) = r7

	} :mem_noshuf
	.falign
// %bb.66:                              // %if.then132
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB39_39
	}
	{
		jump .LBB39_69
	}
	.falign
.LBB39_67:                              // %if.else144
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r0 = add(r29,#256)
		r1 = #32
		r5 = memw(r17+#16)
		r2 = memw(r16+#536)
	}
	{
		r5 = addasl(r5,r6,#2)
		r2 = asl(r2,#5)
		r9:8 = memd(r17+#8)
		r4 = memw(r16+#8)
	}
	{
		r5 = addasl(r9,r6,#2)
		r2 = #1
		memw(r29+#12) = r2
		memw(r29+#4) = r5
	}
	{
		r6 = addasl(r8,r6,#2)
		memw(r29+#8) = r7
		memw(r29+#16) = #0
	}
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#0) = r6
	}
	.falign
// %bb.68:                              // %if.else144
                                        //   in Loop: Header=BB39_39 Depth=2
	{
		r20 = add(r27,r20)
		if (cmp.gtu(r26,r20.new)) jump:t ##.LBB39_39
	}
	.falign
.LBB39_69:                              // %cleanup
                                        //   in Loop: Header=BB39_21 Depth=1
	{
		r18 = r26
		r23 = memw(r29+#228)
		r2 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		r17 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r26 = r17
		if (p0) jump:nt .LBB39_21
	}
	{
		jump .LBB39_71
	}
	.falign
.LBB39_70:                              // %cleanup.thread
	{
		r2 = #1
		memw(r16+#564) = r2.new
	}
	.falign
.LBB39_71:                              // %cleanup163
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end39:
	.size	fc_m1_worker, .Lfunc_end39-fc_m1_worker
                                        // -- End function
	.falign
	.type	moe_expand_unit,@function       // -- Begin function moe_expand_unit
moe_expand_unit:                        // @moe_expand_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2816):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r1 = memw(r2+#152)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r1,#0)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB40_7
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		p0 = and(p0,!p0)
		r2 = memw(r16+#156)
	}
	{
		r0 = p0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB40_16
		memw(r29+#124) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %land.rhs
	{
		r2 = #1536
	}
	{
		r2 = memw(r16+#168)
		if (cmp.eq(r2.new,r2)) jump:nt .LBB40_14
	}
// %bb.3:                               // %land.rhs
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:nt .LBB40_16
	}
// %bb.4:                               // %land.lhs.true
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#24)) jump:t .LBB40_16
	}
// %bb.5:                               // %land.lhs.true3
	{
		r2 = memw(r16+#12)
	}
	{
		p1 = cmp.eq(r2,##49152)
		if (!p1.new) jump:t .LBB40_16
	}
// %bb.6:
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB40_16
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB40_7:                               // %if.end126
	{
		r1 = r18
		r2 = memw(r16+#8)
		r3 = memw(r16+#20)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		r0 = mpyi(r19,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %if.end126
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r19,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.9:                               // %if.end126
	{
		r19 = add(r16,#24)
		r18 = r0
		p0 = cmp.gtu(r0,r17); if (!p0.new) jump:t .LBB40_43
	}
	.falign
.LBB40_11:                              // %for.body135
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.12:                              // %for.body135
                                        //   in Loop: Header=BB40_11 Depth=1
	{
		r2 = r17
		r4 = memw(r16+#12)
		r3 = memw(r16+r0<<#2)
	}
	{
		r2 -= mpyi(r0,r20)
		r1 = memw(r16+#16)
	}
	{
		r3 += mpyi(r4,r2)
		r2 = r19
	}
	{
		call hvx_expand_i2i4
		r0 = add(r3,r1)
	}
	.falign
// %bb.13:                              // %for.body135
                                        //   in Loop: Header=BB40_11 Depth=1
	{
		r17 = add(r17,#1)
		if (cmp.gtu(r18,r17.new)) jump:t .LBB40_11
	}
	{
		jump .LBB40_43
	}
	.falign
.LBB40_14:                              // %land.lhs.true7
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#16)) jump:t .LBB40_16
	}
// %bb.15:                              // %land.rhs10
	{
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r2,##32768)
	}
	{
		r2 = p0
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB40_16:                              // %land.end13
	{
		r1 = r18
		r20 = memw(r16+#184)
		r19 = memw(r16+#176)
	}
	{
		r0 = mpyi(r20,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.17:                              // %land.end13
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r20,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.18:                              // %land.end13
	{
		p1 = cmp.eq(r17,r0); if (p1.new) jump:t .LBB40_43
		r3 = #0
		r18 = r0
	}
// %bb.19:                              // %if.end
	{
		r2 = memw(r16+#172)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB40_43
	}
// %bb.20:                              // %for.body.lr.ph
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r26 = #0
		r25:24 = combine(#2,#96)
	}
	.falign
.LBB40_21:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB40_26 Depth 2
                                        //       Child Loop BB40_35 Depth 3
                                        //       Child Loop BB40_39 Depth 3
	{
		r1:0 = memd(r16+#160)
	}
	{
		r1:0 &= asl(r7:6,r26)
	}
	{
		p1 = cmp.eq(r1:0,r9:8)
		if (!p1.new) r27 = add(r3,r19)
		if (p1.new) jump:nt .LBB40_40
	}
// %bb.22:                              // %if.end23
                                        //   in Loop: Header=BB40_21 Depth=1
	{
		p0 = cmp.gtu(r18,r3); if (!p0.new) jump:nt .LBB40_42
	}
// %bb.23:                              // %if.end23
                                        //   in Loop: Header=BB40_21 Depth=1
	{
		r4 = maxu(r17,r3)
		p1 = cmp.gtu(r27,r17)
		if (!p1.new) jump:nt .LBB40_42
	}
// %bb.24:                              // %if.end28
                                        //   in Loop: Header=BB40_21 Depth=1
	{
		r22 = asl(r26,#11)
		p0 = cmp.gtu(r27,r18)
		if (p0.new) r20 = sub(r18,r3)
		if (!p0.new) r20 = add(r19,#0)
	}
	{
		r21 = sub(r4,r3)
		if (!cmp.gtu(r20,r21.new)) jump:t .LBB40_42
	}
	.falign
.LBB40_26:                              // %for.body39
                                        //   Parent Loop BB40_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB40_35 Depth 3
                                        //       Child Loop BB40_39 Depth 3
	{
		r5 = r22
		r3 = memw(r16+#12)
		r7:6 = memd(r16+#152)
	}
	{
		p0 = cmp.eq(r7,#0)
		r2 = memw(r16+#168)
	}
	{
		r4 = mpyi(r21,r3)
		r2 -= mpyi(r21,#96)
	}
	{
		r1 = minu(r2,r24)
		r4 = +mpyi(r4,#3)
		if (!p0) r2 = memw(r16+#180)
	}
	{
		r5 += add(r6,r4)
		if (p0) jump:nt .LBB40_33
	}
// %bb.27:                              // %if.then51
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		r7 += mpyi(r2,r26)
	}
	{
		r7 += mpyi(r21,##2560)
	}
	.falign
.LBB40_28:                              // %if.end95
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		r0 = r7
		r2 = memw(r29+#124)
		r4 = memw(r16+#188)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r2 = #128
		if (!p1.new) jump:t .LBB40_31
	}
// %bb.29:                              // %if.then97
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		call hvx_tl2_expand_wh96_disjoint
		r2 = #128
	}
	.falign
// %bb.30:                              // %if.then97
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB40_26
	}
	{
		jump .LBB40_41
	}
	.falign
.LBB40_31:                              // %if.else104
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		call hvx_tl2_expand_wh96
	}
	.falign
// %bb.32:                              // %if.else104
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB40_26
	}
	{
		jump .LBB40_41
	}
	.falign
.LBB40_33:                              // %if.else
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB40_28
		r7 = add(r29,#128)
		r6 = r5
	}
// %bb.34:                              //   in Loop: Header=BB40_26 Depth=2
	{
		r4 = add(##989,mpyi(r1,#43))
	}
	{
		r4 = lsr(r4,#10)
	}
	{
		r8 = minu(r4,r25)
	}
	{
		r8 = +mpyi(r8,#5)
	}
	{
		loop0(.LBB40_35,r8)
	}
	.falign
.LBB40_35:                              // Block address taken
                                        // %for.body73
                                        //   Parent Loop BB40_21 Depth=1
                                        //     Parent Loop BB40_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0.cur = vmem(r6++#1)
		vmem(r7++#1) = v0
	} :endloop0
// %bb.36:                              // %for.cond.cleanup72
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		p0 = cmp.gtu(r2,#48)
		r7 = add(r29,#128)
		if (!p0.new) jump:t .LBB40_28
	}
// %bb.37:                              // %for.cond79.preheader
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		r4 = add(##-10,mpyi(r4,#5))
	}
	{
		if (!p1.new) r2 = add(r5,r3)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB40_28
	}
// %bb.38:                              // %for.body84.lr.ph
                                        //   in Loop: Header=BB40_26 Depth=2
	{
		loop0(.LBB40_39,r4)
		r6 = add(r29,#128)
	}
	{
		r4 = add(r6,#1280)
	}
	.falign
.LBB40_39:                              // Block address taken
                                        // %for.body84
                                        //   Parent Loop BB40_21 Depth=1
                                        //     Parent Loop BB40_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r29,#128)
		v1.cur = vmem(r2++#1)
		vmem(r4++#1) = v1
	} :endloop0
	{
		jump .LBB40_28
	}
	.falign
.LBB40_40:                              //   in Loop: Header=BB40_21 Depth=1
	{
		r27 = r3
		jump .LBB40_42
	}
	.falign
.LBB40_41:                              // %for.inc116.loopexit
                                        //   in Loop: Header=BB40_21 Depth=1
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r2 = memw(r16+#172)
	}
	.falign
.LBB40_42:                              // %for.inc116
                                        //   in Loop: Header=BB40_21 Depth=1
	{
		r3 = r27
		r26 = add(r26,#1)
		if (cmp.gtu(r2,r26.new)) jump:t .LBB40_21
	}
	.falign
.LBB40_43:                              // %cleanup150
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end40:
	.size	moe_expand_unit, .Lfunc_end40-moe_expand_unit
                                        // -- End function
	.falign
	.type	moe_m1_q_worker,@function       // -- Begin function moe_m1_q_worker
moe_m1_q_worker:                        // @moe_m1_q_worker
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r2)
		memd(r29+#-16) = r17:16
		allocframe(#72)
	}                                       // 8-byte Folded Spill
	{
		r2 = memw(r2+#44)
		memd(r29+#56) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r18 = minu(r2,r0)
		r20 = #0
		memd(r29+#48) = r21:20
		memd(r29+#40) = r23:22
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r18,r1); if (!p1.new) jump:t .LBB41_10
		memd(r29+#32) = r25:24
		memd(r29+#24) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %for.cond.preheader
	{
		r24 = memw(r16+#40)
		memw(r29+#20) = r0
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r24,#0)
		if (p0.new) jump:nt .LBB41_9
		if (!p0.new) r19 = #0
		memw(r29+#16) = r16
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %for.body.lr.ph
	{
		r21 = add(pc,##g_m1q_desc@PCREL)
		r25 = add(r17,#1)
		r27:26 = combine(#0,r16)
	}
	{
		r21 += asl(r17,#8)
	}
	.falign
.LBB41_3:                               // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r3:2 = combine(r19,r18)
		r16 = memw(r26+#12)
	}
	{
		r1:0 = mpyu(r16,r17)
		call __hexagon_udivdi3
	}
	.falign
// %bb.4:                               // %for.body
                                        //   in Loop: Header=BB41_3 Depth=1
	{
		r1:0 = mpyu(r16,r25)
		call __hexagon_udivdi3
		r23:22 = combine(r1,r0)
		r3:2 = combine(r19,r18)
	}
	.falign
// %bb.5:                               // %for.body
                                        //   in Loop: Header=BB41_3 Depth=1
	{
		if (p0.new) r0 = sub(r0,r22)
		p0 = cmp.gtu(r0,r22); if (!p0.new) jump:t .LBB41_8
		if (p0.new) r4 = memw(r26+#8)
	}
// %bb.6:                               // %if.then6
                                        //   in Loop: Header=BB41_3 Depth=1
	{
		r5 = r4
		r2 = memw(r26+#0)
		r6 = memw(r26+#16)
	}
	{
		r3 = memw(r26+#4)
	}
	{
		r6 = mpyi(r4,r22)
		r1:0 = combine(r20,r21)
		memw(r29+#8) = r6
		memw(r29+#4) = r0
	}
	{
		r2 = add(r2,r6)
		r3 = add(r3,r6)
		memw(r29+#12) = #1
		memw(r29+#0) = r4
	}
	{
		call hexkl_dma_lane_push2d
	}
	.falign
// %bb.7:                               // %if.then6
                                        //   in Loop: Header=BB41_3 Depth=1
	{
		r20 = r21
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r2+#40)
	}
	.falign
.LBB41_8:                               // %if.end
                                        //   in Loop: Header=BB41_3 Depth=1
	{
		r26 = add(r26,#20)
		r21 = add(r21,#128)
		r27 = add(r27,#1)
		if (cmp.gtu(r24,r27.new)) jump:t .LBB41_3
	}
	.falign
.LBB41_9:                               // %for.cond.cleanup
	{
		p1 = cmp.eq(r17,#0)
		if (p1.new) r16 = memw(r29+#16)
		if (p1.new) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r0 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r16 = memw(r29+#16)
		if (p1) memw(r16+#48) = r18
	}                                       // 4-byte Folded Reload
	.falign
.LBB41_10:                              // %if.end18
	{
		r3 = memw(r16+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB41_12
	}
// %bb.11:                              // %if.then20
	{
		callr r3
		r1 = r17
		r2 = memw(r16+#60)
	}
	.falign
.LBB41_12:                              // %if.end22
	{
		if (!p0.new) r0 = add(r20,#0)
		p0 = cmp.eq(r20,#0); if (p0.new) jump:nt .LBB41_15
	}
// %bb.13:                              // %land.lhs.true
	{
		call hexkl_dma_lane_wait
	}
	.falign
// %bb.14:                              // %land.lhs.true
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) memw(r16+#52) = #1
	}
	.falign
.LBB41_15:                              // %if.end26
	{
		r17:16 = memd(r29+#64)
		r19:18 = memd(r29+#56)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#48)
		r23:22 = memd(r29+#40)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#32)
		r27:26 = memd(r29+#24)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end41:
	.size	moe_m1_q_worker, .Lfunc_end41-moe_m1_q_worker
                                        // -- End function
	.falign
	.type	moe_dn_rows,@function           // -- Begin function moe_dn_rows
moe_dn_rows:                            // @moe_dn_rows
// %bb.0:                               // %entry
	{
		r17:16 = combine(r1,r0)
		r6 = r2
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		r3 = memw(r0+#544)
		memd(r29+#48) = r19:18
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.eq(r3,#0)
		r4 = memw(r0+#8)
		if (!p1.new) r0 = memw(r16+#0)
	}
	{
		r18 = asl(r4,#5)
		if (p1) jump:nt .LBB42_3
		if (!p1) r5 = memw(r16+#24)
		if (!p1) r2 = memw(r16+#12)
	}
// %bb.1:                               // %if.then
	{
		r4 = memw(r16+#808)
		r8 = memw(r16+#816)
	}
	{
		r4 = addasl(r4,r18,#2)
		r8 = addasl(r8,r18,#2)
		r1 = memw(r16+#4)
		r3 = memw(r16+#28)
	}
	{
		r12 = memw(r16+#836)
		r13 = memw(r16+#828)
	}
	{
		r7 = memw(r16+#812)
		r9 = memw(r16+#820)
	}
	{
		r7 = addasl(r7,r18,#2)
		r9 = addasl(r9,r18,#2)
		r14 = memw(r16+#832)
	}
	{
		r4 = r6
		r15 = memw(r16+#824)
		memw(r29+#4) = r4

	} :mem_noshuf
	{
		r3 = r17
		memw(r29+#0) = r3
		memw(r29+#32) = r15
	}
	{
		memw(r29+#28) = r14
		memw(r29+#24) = r13
	}
	{
		memw(r29+#20) = r12
		memw(r29+#16) = r9
	}
	{
		call hvx_dequant_i24_tiles_scatter_rows_f32
		memw(r29+#12) = r8
		memw(r29+#8) = r7
	}
	.falign
// %bb.2:                               // %if.then
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB42_15
	}
	{
		jump .LBB42_8
	}
	.falign
.LBB42_3:                               // %if.else
	{
		r5 = memw(r16+#548)
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r5,#0)
		r0 = memw(r16+#0)
		r3 = memw(r16+#16)
	}
	{
		r4 = memw(r16+#24)
		r8 = memw(r16+#808)
	}
	{
		r8 = addasl(r8,r18,#2)
		r14 = memw(r16+#816)
		r1 = memw(r16+#4)
	}
	{
		r14 = addasl(r14,r18,#2)
		r7 = memw(r16+#28)
		r12 = memw(r16+#812)
	}
	{
		r12 = addasl(r12,r18,#2)
		r15 = memw(r16+#820)
		r9 = memw(r16+#836)
	}
	{
		r15 = addasl(r15,r18,#2)
		r13 = memw(r16+#828)
		r28 = memw(r16+#832)
	}
	{
		if (p0) jump:nt .LBB42_6
		r10 = memw(r16+#824)
	}
// %bb.4:                               // %if.then5
	{
		r7 = add(r16,#552)
		memw(r29+#4) = r7
		memw(r29+#36) = r10
	}
	{
		r7 = addasl(r5,r18,#2)
		r5:4 = combine(r6,r17)
		memw(r29+#44) = r7
		memw(r29+#0) = r4
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		memw(r29+#8) = r8
		memw(r29+#40) = r7
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_affine_f32
	}
	.falign
// %bb.5:                               // %if.then5
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB42_15
	}
	{
		jump .LBB42_8
	}
	.falign
.LBB42_6:                               // %if.else25
	{
		r5:4 = combine(r6,r17)
		memw(r29+#0) = r4
		memw(r29+#36) = r10
	}
	{
		memw(r29+#32) = r28
		memw(r29+#28) = r13
	}
	{
		memw(r29+#24) = r9
		memw(r29+#20) = r15
	}
	{
		memw(r29+#16) = r14
		memw(r29+#12) = r12
	}
	{
		call hvx_dequant_acc_tiles_scatter_rows_f32
		memw(r29+#8) = r8
		memw(r29+#4) = r7
	}
	.falign
// %bb.7:                               // %if.else25
	{
		p0 = cmp.eq(r17,#0); if (!p0.new) jump:t .LBB42_15
	}
	.falign
.LBB42_8:                               // %land.rhs.lr.ph
	{
		r19 = #0
		r17 = #0
		r2 = memw(r16+#852)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB42_15
	}
	.falign
.LBB42_10:                              // %for.body.us
                                        // =>This Inner Loop Header: Depth=1
	{
		r1 = #0
		r2 = memw(r16+#844)
		r3 = memw(r16+#824)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r4 = memb(r3+r2<<#0)
		if (!cmp.eq(r4.new,#0)) jump:t .LBB42_13
	}
// %bb.11:                              // %if.then49.us
                                        //   in Loop: Header=BB42_10 Depth=1
	{
		r2 = add(r3,r2)
	}
	{
		memb(r2+#0) = #1
		r2 = memw(r16+#844)

	} :mem_noshuf
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#820)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	{
		r2 = mpyi(r3,r2)
		r3 = memw(r16+#12)
	}
	{
		r4 = addasl(r4,r2,#2)
		r2 = asl(r3,#7)
	}
	{
		r0 = addasl(r4,r18,#2)
		call memset
	}
	.falign
// %bb.12:                              // %if.then49.us
                                        //   in Loop: Header=BB42_10 Depth=1
	{
		r2 = memw(r16+#844)
	}
	{
		r2 = memw(r2+r17<<#0)
	}
	.falign
.LBB42_13:                              // %if.end64.us
                                        //   in Loop: Header=BB42_10 Depth=1
	{
		r3 = memw(r16+#836)
		r4 = memw(r16+#848)
	}
	{
		r6 = memw(r16+#12)
		r5 = memw(r16+#820)
	}
	{
		r7 = mpyi(r3,r2)
		r9 = mpyi(r3,r19)
		r8 = memw(r16+#840)
		r2 = memw(r4+r17<<#0)
	}
	{
		r7 = addasl(r5,r7,#2)
		r3 = asl(r6,#5)
	}
	{
		r6 = addasl(r8,r9,#2)
		r0 = addasl(r7,r18,#2)
	}
	{
		r1 = addasl(r6,r18,#2)
		call hvx_scale_add_rows_f32
	}
	.falign
// %bb.14:                              // %if.end64.us
                                        //   in Loop: Header=BB42_10 Depth=1
	{
		r17 = add(r17,#4)
		r19 = add(r19,#1)
	}
	{
		r2 = memw(r16+#852)
		if (cmp.gtu(r2.new,r19)) jump:t .LBB42_10
	}
	.falign
.LBB42_15:                              // %for.cond.cleanup
	{
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end42:
	.size	moe_dn_rows, .Lfunc_end42-moe_dn_rows
                                        // -- End function
	.type	g_moe_src_bypass,@object        // @g_moe_src_bypass
	.lcomm	g_moe_src_bypass,4,4
	.type	g_m1q_desc,@object              // @g_m1q_desc
	.lcomm	g_m1q_desc,1024,128
	.type	g_fc_m1_desc,@object            // @g_fc_m1_desc
	.lcomm	g_fc_m1_desc,2048,128
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym hexkl_moe_pack_bg_worker
	.addrsig_sym moe_m1_pair_worker
	.addrsig_sym moe_tl2_gate_epilogue_worker
	.addrsig_sym moe_m1_requant_worker
	.addrsig_sym moe_m1_down_worker
	.addrsig_sym moe_gu_worker
	.addrsig_sym moe_dn_worker
	.addrsig_sym moe_dn_unit
	.addrsig_sym moe_dn_fg_worker
	.addrsig_sym fc_m1_worker
	.addrsig_sym moe_expand_unit
	.addrsig_sym moe_m1_q_worker
	.addrsig_sym hexkl_probe_us
	.addrsig_sym g_m1q_desc
	.addrsig_sym g_fc_m1_desc
	.section	.note.llvm.cgmdinfo,"",@note
	.ascii	"F#no_filename_available###0##"
	.ascii	"C#hexkl_moe_pack_bg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_pair_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_tl2_gate_epilogue_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_requant_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_down_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_gu_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_dn_fg_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#fc_m1_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_expand_unit#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#moe_m1_q_worker#(void)#(i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i2_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col_nopf#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"
	.ascii	"C#hvx_gemm_u8i4_wh_col#(void)#(ptr, i32, i32, ptr, i32, i32, i32, ptr)#1##"

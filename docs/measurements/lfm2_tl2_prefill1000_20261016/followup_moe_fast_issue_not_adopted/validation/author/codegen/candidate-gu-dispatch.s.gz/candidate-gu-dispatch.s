	{
		p3 = r2
		if (!p3.new) jump:t .LBB12_446
		if (!p3.new) r2 = memw(r29+##256)
	}                                       // 4-byte Folded Reload
// %bb.443:                             // %if.then2166
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		r2 = memw(r29+#676)
		r4 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r4,r2)
		r3 = memw(r29+#672)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		r1 += asl(r17,#9)
		p2 = r2
		r0 = add(r4,r3)
		if (p2.new) jump:nt .LBB12_451
	}
// %bb.444:                             // %if.then2174
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		call lfm2_moe_issue_aligned
		r2 = memw(r29+#312)
		r3 = memw(r29+#396)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.445:                             // %if.then2174
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		jump .LBB12_457
	}
	.falign
.LBB12_446:                             // %for.cond2192.preheader
                                        //   in Loop: Header=BB12_441 Depth=3
	{
		p1 = cmp.gtu(r2,#31)

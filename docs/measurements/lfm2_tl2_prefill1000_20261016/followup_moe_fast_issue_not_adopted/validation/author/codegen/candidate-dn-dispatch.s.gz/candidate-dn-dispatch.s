	}
// %bb.546:                             // %if.then2747
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#680)
		r4 = memw(r29+#284)
	}                                       // 4-byte Folded Reload
	{
		r1 = add(r4,r2)
		r0 = memw(r29+#688)
		r2 = memw(r29+#1656)
	}                                       // 4-byte Folded Reload
	{
		r0 += add(r4,r2)
		r1 += asl(r3,#9)
		r2 = memw(r29+#372)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB12_554
		if (!p0.new) r2 = memw(r29+##300)
	}                                       // 4-byte Folded Reload
// %bb.547:                             // %if.then2760
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		call lfm2_moe_issue_aligned
		r3 = memw(r29+#432)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.548:                             // %if.then2760
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		jump .LBB12_560
	}
	.falign
.LBB12_549:                             // %for.cond2779.preheader
                                        //   in Loop: Header=BB12_544 Depth=3
	{
		r2 = memw(r29+#260)
		r0 = memw(r29+#284)

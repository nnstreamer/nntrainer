.LBB12_459:                             //   Parent Loop BB12_346 Depth=1
                                        //     Parent Loop BB12_381 Depth=2
                                        //       Parent Loop BB12_454 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7 = #31
		r8 = #384
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r5 = add(r3,#2048)
		r6 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r6)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r5,r7):cm
		weight.n = mxmem(r2,r8)
	}

	//# InlineAsm End
	{
		r3 = add(r3,#4096)
		r2 = add(r2,r6)
	} :endloop0

#ifndef REVIEW_HMX_MM_H
#define REVIEW_HMX_MM_H
#include <hexkl_micro.h>
#include <stdint.h>
extern uint64_t review_align_queries;
void review_packet(const uint8_t *, const uint8_t *);
static inline int hexkl_hmx_mm_aligned(const void *a, const void *w) {
  ++review_align_queries;
  return (((uintptr_t)a & (HEXKL_HMX_ACTIVATION_ALIGNMENT - 1u)) == 0u) &&
         (((uintptr_t)w & (HEXKL_HMX_WEIGHTS_ALIGNMENT - 1u)) == 0u);
}
static inline void hexkl_hmx_mm_u8i4(const void *a, const void *w) {
  review_packet(a, w);
}
static inline void hexkl_hmx_mm_u8i8(const void *a, const void *w) {
  (void)a;
  (void)w;
}
#endif

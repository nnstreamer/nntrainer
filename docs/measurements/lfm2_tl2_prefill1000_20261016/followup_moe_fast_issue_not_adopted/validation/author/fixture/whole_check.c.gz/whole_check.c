// SPDX-License-Identifier: Apache-2.0
/* Whole production MoE caller; the repository's delayed-pool/DMA and scalar
 * arithmetic stand-ins validate schedule-dependent results, not silicon math.
 */
#define _POSIX_C_SOURCE 200112L
#define main existing_moe_host_main
#include "moe_layer_host_check.c"
#undef main
#include "hvx_gemv_u8tl2.h"
#include <assert.h>
#include <hexkl_micro.h>

static uint8_t *arena_base;
static uint32_t arena_bytes;
static hexkl_moe_layout current_layout;
static uint64_t packet_count, event_hash;
static uint32_t clear_count, read_count, fail_read, leaf_calls;
static uint32_t next_kt, previous_col, previous_phase;
uint64_t review_align_queries;

int __real_hexkl_micro_hmx_acc_clear_int32(void);
int __real_hexkl_micro_hmx_mm_u8i4(uint8_t *, uint32_t, uint32_t);
int __real_hexkl_micro_hmx_acc_read_int32(uint8_t *, uint32_t, uint32_t);
static void event(uint64_t value) {
  event_hash = (event_hash ^ value) * UINT64_C(1099511628211);
}

void review_leaf_observe(uint32_t kt, uint32_t step) {
  assert((kt == 64u && step == 96u * 512u) ||
         (kt == 48u && step == 64u * 512u));
  ++leaf_calls;
}

void review_packet(const uint8_t *a, const uint8_t *w) {
  assert(a >= arena_base && w >= arena_base);
  const uint32_t ao = (uint32_t)(a - arena_base);
  const uint32_t wo = (uint32_t)(w - arena_base);
  assert((uintptr_t)a % 2048u == 0u && (uintptr_t)w % 128u == 0u);
  assert((uint64_t)ao + 2048u <= arena_bytes &&
         (uint64_t)wo + 512u <= arena_bytes);
  const int gu = wo < current_layout.w_dn_off;
  const uint32_t bank = gu ? current_layout.w_gu_off : current_layout.w_dn_off;
  const uint32_t nt = gu ? 96u : 64u, nk = gu ? 64u : 48u;
  assert(wo >= bank && (wo - bank) % 512u == 0u);
  const uint32_t tile = (wo - bank) / 512u;
  const uint32_t kt = tile / nt, col = tile % nt;
  assert(kt < nk && kt == next_kt);
  if (next_kt) {
    assert(previous_col == col && previous_phase == (uint32_t)gu);
  } else {
    previous_col = col;
    previous_phase = (uint32_t)gu;
  }
  if (gu) {
    assert(ao == current_layout.act_off + kt * 2048u);
  } else {
    const uint32_t mid = ao - kt * 2048u;
    assert(mid == current_layout.mid_off ||
           mid == current_layout.mid_off + 48u * 2048u);
  }
  next_kt = (next_kt + 1u) % nk;
  event(ao);
  event(wo);
  ++packet_count;
  assert(__real_hexkl_micro_hmx_mm_u8i4(arena_base, ao, wo) == 0);
}

int __wrap_hexkl_micro_hmx_acc_clear_int32(void) {
  assert(next_kt == 0u);
  ++clear_count;
  event(0x1111u);
  return __real_hexkl_micro_hmx_acc_clear_int32();
}
int __wrap_hexkl_micro_hmx_mm_u8i4(uint8_t *base, uint32_t ao, uint32_t wo) {
  assert(base == arena_base);
  if ((uintptr_t)(base + ao) % 2048u || (uintptr_t)(base + wo) % 128u)
    return AEE_EBADPARM;
  review_packet(base + ao, base + wo);
  return AEE_SUCCESS;
}
int __wrap_hexkl_micro_hmx_acc_read_int32(uint8_t *base, uint32_t cfg,
                                          uint32_t offset) {
  assert(next_kt == 0u && base == arena_base);
  assert((uint64_t)offset + 8192u <= arena_bytes);
  ++read_count;
  event(offset);
  if (read_count == fail_read)
    return AEE_EFAILED;
  return __real_hexkl_micro_hmx_acc_read_int32(base, cfg, offset);
}

#ifdef REVIEW_CANDIDATE
int review_guard(int, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t,
                 uint32_t, uint32_t, uint32_t, uint32_t,
                 const hexkl_moe_layout *, uint32_t);
static unsigned guard_cases;
static void guard_checks(void) {
  hexkl_moe_layout layout;
  assert(hexkl_mm_u8i4_moe_layout(2048, 1536, 2048, 8u << 20, &layout) == 0);
  uint32_t fields[10] = {1, 65, 2048, 1536, 2048, 64, 2, 2, 0, HVX_GLU_SILU};
#define CHECK_GUARD(expected)                                                  \
  do {                                                                         \
    assert(review_guard(fields[0], fields[1], fields[2], fields[3], fields[4], \
                        fields[5], fields[6], fields[7], fields[8], fields[9], \
                        &layout, 8u << 20) == (expected));                     \
    ++guard_cases;                                                             \
  } while (0)
  CHECK_GUARD(1);
  const uint32_t bad[10] = {0,  1, 1024, 704, 1024,
                            65, 1, 0,    1,   HVX_GLU_GELU_TANH};
  for (uint32_t i = 0; i < 10; ++i) {
    const uint32_t saved = fields[i];
    fields[i] = bad[i];
    CHECK_GUARD(0);
    fields[i] = saved;
  }
  fields[5] = 0;
  CHECK_GUARD(0);
  fields[5] = 32;
  CHECK_GUARD(1);
  fields[5] = 64;
  fields[6] = fields[7] = 0;
  CHECK_GUARD(0);
  fields[6] = fields[7] = 2;
  const hexkl_moe_layout saved = layout;
  // Cross one boundary at a time, preserving every other range relation.
  layout.act_off = layout.w_gu_off - 2048u * 64u + 2048u;
  CHECK_GUARD(0);
  layout = saved;
  layout.w_gu_off = layout.w_dn_off - 2048u * 1536u + 128u;
  CHECK_GUARD(0);
  layout = saved;
  layout.w_dn_off = layout.gate_off - 1536u * 2048u / 2u + 128u;
  CHECK_GUARD(0);
  layout = saved;
  layout.gate_off = layout.mid_off + 128u;
  CHECK_GUARD(0);
  layout = saved;
  layout.mid_off = layout.result_off - 2u * 1536u * 64u + 2048u;
  CHECK_GUARD(0);
  layout = saved;
  layout.act_off = UINT32_MAX;
  CHECK_GUARD(0);
  layout = saved;
  layout.w_gu_off = UINT32_MAX;
  CHECK_GUARD(0);
  layout = saved;
  layout.w_dn_off = UINT32_MAX;
  CHECK_GUARD(0);
  layout = saved;
  layout.gate_off = UINT32_MAX;
  CHECK_GUARD(0);
  layout = saved;
  layout.mid_off = UINT32_MAX;
  CHECK_GUARD(0);
  layout = saved;
  layout.result_off = (8u << 20) + 1u;
  CHECK_GUARD(0);
#undef CHECK_GUARD
}
#endif

static W backing[4];
static uint8_t *native[4];
static void weights_create(void) {
  memset(&g_tbl, 0, sizeof g_tbl);
  for (uint32_t h = 0; h < 4; ++h) {
    make_weight(h, h % 2u ? 1536u : 2048u, h % 2u ? 2048u : 3072u, &backing[h]);
    hexkl_weight_u8i4 *w = &g_tbl.slots[h];
    int8_t *dense = malloc((size_t)w->K * w->N);
    native[h] = malloc(hvx_tl2_weight_bytes(w->K, w->N));
    assert(dense && native[h]);
    memset(w->colsum_w, 0, w->N * sizeof(int32_t));
    for (uint32_t k = 0; k < w->K; ++k)
      for (uint32_t n = 0; n < w->N; ++n) {
        const int8_t q = (int8_t)((int)(rnd() % 3u) - 1);
        dense[(size_t)k * w->N + n] = q;
        w->colsum_w[n] += q;
      }
    assert(hvx_tl2_pack(dense, w->K, w->N, native[h]) == 0);
    const int8_t pal[4] = {-1, 0, 1, 1};
    memcpy(w->pal, pal, 4);
    w->wh_bytes = native[h];
    w->tl2_bytes = native[h];
    w->bits = 2u;
    w->tl2_compact = 1;
    free(dense);
  }
}

static unsigned cases;
static hexkl_moe_scratch scratch;
static void run(FILE *output, unsigned M, unsigned E, unsigned active,
                unsigned workers, int gelu, int bad_row, unsigned read_error) {
  const uint32_t K = 2048, I = 1536, N = 2048;
  arena_bytes = 8u << 20;
  void *allocation = NULL;
  assert(posix_memalign(&allocation, 2048, arena_bytes) == 0);
  arena_base = allocation;
  memset(arena_base, 0x96, arena_bytes);
  assert(hexkl_mm_u8i4_moe_layout(K, I, N, arena_bytes, &current_layout) == 0);
  uint32_t hg[65] = {0}, hd[65] = {0}, counts[65] = {0};
  uint32_t *rows = calloc((size_t)(active + 1u) * M, sizeof(uint32_t));
  float *routing = calloc((size_t)(active + 1u) * M, sizeof(float));
  float *input = malloc((size_t)M * K * sizeof(float));
  float *result = malloc((size_t)M * N * sizeof(float));
  assert(rows && routing && input && result);
  for (unsigned e = 0; e < active; ++e) {
    const uint32_t expert = e ? E - 1u : 0u;
    hg[expert] = 2u * e;
    hd[expert] = 2u * e + 1u;
    counts[expert] = M;
    for (unsigned m = 0; m < M; ++m) {
      rows[e * M + m] = (m + e) % M;
      routing[e * M + m] = (e ? -0.375f : 0.625f) + 0.0625f * (m % 3u);
    }
  }
  if (bad_row)
    rows[0] = M;
  for (size_t i = 0; i < (size_t)M * K; ++i)
    input[i] = rndf() * 0.0625f;
  memset(result, 0xa5, (size_t)M * N * sizeof(float));
  g_workers = workers;
  score_reset(0, arena_base, arena_bytes);
  const uint32_t before_run = g_run, before_submit = g_submits;
  review_align_queries = packet_count = clear_count = read_count = leaf_calls =
    0;
  event_hash = UINT64_C(1469598103934665603);
  next_kt = 0;
  fail_read = read_error;
  hexkl_probe_on = 0;
  const uint32_t flags = gelu ? HEXKL_MOE_FLAG_GELU_TANH : 0u;
  int rc = hexkl_mm_u8i4_moe_layer_run(
    &g_tbl, arena_base, arena_bytes, arena_bytes, M, K, I, N, E, hg, hd, rows,
    counts, routing, input, result, NULL, &scratch, flags);
  assert(!g_pending && !g_in_run && next_kt == 0u);
  assert(rc == (bad_row ? AEE_EBADPARM : read_error ? AEE_EFAILED : 0));
  const uint32_t blocks = active * ((M + 63u) / 64u);
  if (!bad_row && !read_error) {
    assert(packet_count == (uint64_t)blocks * (96u * 64u + 64u * 48u));
    assert(clear_count == blocks * 160u && read_count == clear_count);
  }
#ifdef REVIEW_CANDIDATE
  const int qualifies =
    M > 1u && E > 0u && E <= 64u && active && !gelu && !bad_row;
  assert(leaf_calls == (qualifies ? clear_count : 0u));
#else
  assert(leaf_calls == 0u);
#endif
  assert(fwrite(result, sizeof(float), (size_t)M * N, output) == (size_t)M * N);
  printf("WHOLE M%u E%u active%u workers%u gelu%d badrow%d error%u rc%d "
         "packets%llu clears%u reads%u runs%u submits%u hash%016llx PASS\n",
         M, E, active, workers, gelu, bad_row, read_error, rc,
         (unsigned long long)packet_count, clear_count, read_count,
         g_run - before_run, g_submits - before_submit,
         (unsigned long long)event_hash);
  free(rows);
  free(routing);
  free(input);
  free(result);
  free(allocation);
  ++cases;
}

int main(int argc, char **argv) {
  assert(argc == 2);
  setvbuf(stdout, NULL, _IONBF, 0);
#ifdef REVIEW_CANDIDATE
  guard_checks();
  assert(guard_cases == 25u);
#endif
  weights_create();
  FILE *output = fopen(argv[1], "wb");
  assert(output);
  run(output, 2, 64, 1, 0, 0, 0, 0);
  run(output, 65, 64, 2, 3, 0, 0, 0);
  run(output, 2, 1, 1, 3, 0, 0, 0);
  run(output, 2, 4, 2, 3, 0, 0, 0);
  run(output, 2, 60, 2, 3, 0, 0, 0);
  run(output, 2, 65, 1, 3, 0, 0, 0);
  run(output, 1, 64, 1, 0, 0, 0, 0);
  run(output, 2, 64, 1, 3, 1, 0, 0);
  run(output, 2, 64, 1, 3, 0, 1, 0);
  run(output, 2, 64, 0, 3, 0, 0, 0);
  run(output, 2, 64, 1, 3, 0, 0, 37);
  assert(fclose(output) == 0);
  hexkl_moe_scratch_free(&scratch);
  for (uint32_t h = 0; h < 4; ++h) {
    free(native[h]);
    free(backing[h].nib);
    free(backing[h].ws);
    free(backing[h].cs);
    free(backing[h].bias);
  }
  printf("MOE_ISSUE_WHOLE %u cases PASS\n", cases);
}

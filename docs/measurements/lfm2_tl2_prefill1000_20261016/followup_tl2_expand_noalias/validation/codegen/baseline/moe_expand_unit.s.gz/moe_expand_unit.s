                        // @moe_expand_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2816):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r1 = memw(r2+#152)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r1,#0)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		if (!p0) r1 = add(r18,#0)
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB37_25
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		r20 = memw(r16+#184)
		r19 = memw(r16+#176)
	}
	{
		r0 = mpyi(r20,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.2:                               // %if.then
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r20,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.3:                               // %if.then
	{
		p1 = cmp.eq(r17,r0); if (p1.new) jump:t .LBB37_32
		r3 = #0
		r18 = r0
	}
// %bb.4:                               // %if.end
	{
		r2 = memw(r16+#172)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB37_32
	}
// %bb.5:                               // %for.body.lr.ph
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r26 = #0
		r25:24 = combine(#2,#96)
	}
	.falign
.LBB37_6:                               // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB37_11 Depth 2
                                        //       Child Loop BB37_17 Depth 3
                                        //       Child Loop BB37_21 Depth 3
	{
		r1:0 = memd(r16+#160)
	}
	{
		r1:0 &= asl(r7:6,r26)
	}
	{
		p1 = cmp.eq(r1:0,r9:8)
		if (!p1.new) r27 = add(r3,r19)
		if (p1.new) jump:nt .LBB37_22
	}
// %bb.7:                               // %if.end8
                                        //   in Loop: Header=BB37_6 Depth=1
	{
		p0 = cmp.gtu(r18,r3); if (!p0.new) jump:nt .LBB37_24
	}
// %bb.8:                               // %if.end8
                                        //   in Loop: Header=BB37_6 Depth=1
	{
		r4 = maxu(r17,r3)
		p1 = cmp.gtu(r27,r17)
		if (!p1.new) jump:nt .LBB37_24
	}
// %bb.9:                               // %if.end13
                                        //   in Loop: Header=BB37_6 Depth=1
	{
		r22 = asl(r26,#11)
		p0 = cmp.gtu(r27,r18)
		if (p0.new) r20 = sub(r18,r3)
		if (!p0.new) r20 = add(r19,#0)
	}
	{
		r21 = sub(r4,r3)
		if (!cmp.gtu(r20,r21.new)) jump:t .LBB37_24
	}
	.falign
.LBB37_11:                              // %for.body24
                                        //   Parent Loop BB37_6 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB37_17 Depth 3
                                        //       Child Loop BB37_21 Depth 3
	{
		r5 = r22
		r3 = memw(r16+#12)
		r7:6 = memd(r16+#152)
	}
	{
		p0 = cmp.eq(r7,#0)
		r2 = memw(r16+#168)
	}
	{
		r4 = mpyi(r21,r3)
		r2 -= mpyi(r21,#96)
	}
	{
		r1 = minu(r2,r24)
		r4 = +mpyi(r4,#3)
		if (!p0) r2 = memw(r16+#180)
	}
	{
		r5 += add(r6,r4)
		if (p0) jump:nt .LBB37_15
	}
// %bb.12:                              // %if.then33
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		r7 += mpyi(r2,r26)
	}
	{
		r7 += mpyi(r21,##2560)
	}
	.falign
.LBB37_13:                              // %if.end77
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		call hvx_tl2_expand_wh96
		r0 = r7
		r2 = #128
		r4 = memw(r16+#188)
	}
	.falign
// %bb.14:                              // %if.end77
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB37_11
	}
	{
		jump .LBB37_23
	}
	.falign
.LBB37_15:                              // %if.else
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB37_13
		r7 = add(r29,#128)
		r6 = r5
	}
// %bb.16:                              //   in Loop: Header=BB37_11 Depth=2
	{
		r4 = add(##989,mpyi(r1,#43))
	}
	{
		r4 = lsr(r4,#10)
	}
	{
		r8 = minu(r4,r25)
	}
	{
		r8 = +mpyi(r8,#5)
	}
	{
		loop0(.LBB37_17,r8)
	}
	.falign
.LBB37_17:                              // Block address taken
                                        // %for.body55
                                        //   Parent Loop BB37_6 Depth=1
                                        //     Parent Loop BB37_11 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0.cur = vmem(r6++#1)
		vmem(r7++#1) = v0
	} :endloop0
// %bb.18:                              // %for.cond.cleanup54
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		p0 = cmp.gtu(r2,#48)
		r7 = add(r29,#128)
		if (!p0.new) jump:t .LBB37_13
	}
// %bb.19:                              // %for.cond61.preheader
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		r4 = add(##-10,mpyi(r4,#5))
	}
	{
		if (!p1.new) r2 = add(r5,r3)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB37_13
	}
// %bb.20:                              // %for.body66.lr.ph
                                        //   in Loop: Header=BB37_11 Depth=2
	{
		loop0(.LBB37_21,r4)
		r6 = add(r29,#128)
	}
	{
		r4 = add(r6,#1280)
	}
	.falign
.LBB37_21:                              // Block address taken
                                        // %for.body66
                                        //   Parent Loop BB37_6 Depth=1
                                        //     Parent Loop BB37_11 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r29,#128)
		v1.cur = vmem(r2++#1)
		vmem(r4++#1) = v1
	} :endloop0
	{
		jump .LBB37_13
	}
	.falign
.LBB37_22:                              //   in Loop: Header=BB37_6 Depth=1
	{
		r27 = r3
		jump .LBB37_24
	}
	.falign
.LBB37_23:                              // %for.inc87.loopexit
                                        //   in Loop: Header=BB37_6 Depth=1
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r2 = memw(r16+#172)
	}
	.falign
.LBB37_24:                              // %for.inc87
                                        //   in Loop: Header=BB37_6 Depth=1
	{
		r3 = r27
		r26 = add(r26,#1)
		if (cmp.gtu(r2,r26.new)) jump:t .LBB37_6
	}
	{
		jump .LBB37_32
	}
	.falign
.LBB37_25:                              // %if.end96
	{
		r1 = r18
		r2 = memw(r16+#8)
		r3 = memw(r16+#20)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		r0 = mpyi(r19,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.26:                              // %if.end96
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r19,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.27:                              // %if.end96
	{
		r19 = add(r16,#24)
		r18 = r0
		p0 = cmp.gtu(r0,r17); if (!p0.new) jump:t .LBB37_32
	}
	.falign
.LBB37_29:                              // %for.body105
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.30:                              // %for.body105
                                        //   in Loop: Header=BB37_29 Depth=1
	{
		r2 = r17
		r4 = memw(r16+#12)
		r3 = memw(r16+r0<<#2)
	}
	{
		r2 -= mpyi(r0,r20)
		r1 = memw(r16+#16)
	}
	{
		r3 += mpyi(r4,r2)
		r2 = r19
	}
	{
		call hvx_expand_i2i4
		r0 = add(r3,r1)
	}
	.falign
// %bb.31:                              // %for.body105
                                        //   in Loop: Header=BB37_29 Depth=1
	{
		r17 = add(r17,#1)
		if (cmp.gtu(r18,r17.new)) jump:t .LBB37_29
	}
	.falign
.LBB37_32:                              // %cleanup120
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end37:
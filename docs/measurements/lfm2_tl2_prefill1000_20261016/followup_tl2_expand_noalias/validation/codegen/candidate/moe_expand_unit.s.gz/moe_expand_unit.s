                        // @moe_expand_unit
// %bb.0:                               // %entry
	{
		allocframe(r29,#2816):raw
	}
	{
		r29 = and(r29,#-128)
	}
	{
		allocframe(r29,#0):raw
	}
	{
		r31:30 = deallocframe(r30):raw
	}
	{
		r17:16 = combine(r1,r2)
		r1 = memw(r2+#152)
		memd(r30+#-8) = r17:16
	}                                       // 8-byte Folded Spill
	{
		p0 = cmp.eq(r1,#0)
		r18 = r0
		memd(r30+#-16) = r19:18
		memd(r30+#-24) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r30+#-32) = r23:22
		memd(r30+#-40) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB37_7
		memd(r30+#-48) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %if.then
	{
		p0 = and(p0,!p0)
		r2 = memw(r16+#156)
	}
	{
		r0 = p0
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB37_16
		memw(r29+#124) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.2:                               // %land.rhs
	{
		r2 = #1536
	}
	{
		r2 = memw(r16+#168)
		if (cmp.eq(r2.new,r2)) jump:nt .LBB37_14
	}
// %bb.3:                               // %land.rhs
	{
		p1 = cmp.eq(r2,##2048)
		if (!p1.new) jump:nt .LBB37_16
	}
// %bb.4:                               // %land.lhs.true
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#24)) jump:t .LBB37_16
	}
// %bb.5:                               // %land.lhs.true3
	{
		r2 = memw(r16+#12)
	}
	{
		p1 = cmp.eq(r2,##49152)
		if (!p1.new) jump:t .LBB37_16
	}
// %bb.6:
	{
		p1 = or(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB37_16
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB37_7:                               // %if.end126
	{
		r1 = r18
		r2 = memw(r16+#8)
		r3 = memw(r16+#20)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		r0 = mpyi(r19,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %if.end126
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r19,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.9:                               // %if.end126
	{
		r19 = add(r16,#24)
		r18 = r0
		p0 = cmp.gtu(r0,r17); if (!p0.new) jump:t .LBB37_43
	}
	.falign
.LBB37_11:                              // %for.body135
                                        // =>This Inner Loop Header: Depth=1
	{
		r20 = memw(r16+#20)
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r20,r17)
	}
	.falign
// %bb.12:                              // %for.body135
                                        //   in Loop: Header=BB37_11 Depth=1
	{
		r2 = r17
		r4 = memw(r16+#12)
		r3 = memw(r16+r0<<#2)
	}
	{
		r2 -= mpyi(r0,r20)
		r1 = memw(r16+#16)
	}
	{
		r3 += mpyi(r4,r2)
		r2 = r19
	}
	{
		call hvx_expand_i2i4
		r0 = add(r3,r1)
	}
	.falign
// %bb.13:                              // %for.body135
                                        //   in Loop: Header=BB37_11 Depth=1
	{
		r17 = add(r17,#1)
		if (cmp.gtu(r18,r17.new)) jump:t .LBB37_11
	}
	{
		jump .LBB37_43
	}
	.falign
.LBB37_14:                              // %land.lhs.true7
	{
		r2 = memw(r16+#172)
		if (!cmp.eq(r2.new,#16)) jump:t .LBB37_16
	}
// %bb.15:                              // %land.rhs10
	{
		r2 = memw(r16+#12)
	}
	{
		p0 = cmp.eq(r2,##32768)
	}
	{
		r2 = p0
		memw(r29+#124) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB37_16:                              // %land.end13
	{
		r1 = r18
		r20 = memw(r16+#184)
		r19 = memw(r16+#176)
	}
	{
		r0 = mpyi(r20,r17)
		call __hexagon_udivsi3
	}
	.falign
// %bb.17:                              // %land.end13
	{
		r17 = r0
		r1 = r18
		r2 = add(r17,#1)
	}
	{
		r0 = mpyi(r20,r2)
		call __hexagon_udivsi3
	}
	.falign
// %bb.18:                              // %land.end13
	{
		p1 = cmp.eq(r17,r0); if (p1.new) jump:t .LBB37_43
		r3 = #0
		r18 = r0
	}
// %bb.19:                              // %if.end
	{
		r2 = memw(r16+#172)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB37_43
	}
// %bb.20:                              // %for.body.lr.ph
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r26 = #0
		r25:24 = combine(#2,#96)
	}
	.falign
.LBB37_21:                              // %for.body
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB37_26 Depth 2
                                        //       Child Loop BB37_35 Depth 3
                                        //       Child Loop BB37_39 Depth 3
	{
		r1:0 = memd(r16+#160)
	}
	{
		r1:0 &= asl(r7:6,r26)
	}
	{
		p1 = cmp.eq(r1:0,r9:8)
		if (!p1.new) r27 = add(r3,r19)
		if (p1.new) jump:nt .LBB37_40
	}
// %bb.22:                              // %if.end23
                                        //   in Loop: Header=BB37_21 Depth=1
	{
		p0 = cmp.gtu(r18,r3); if (!p0.new) jump:nt .LBB37_42
	}
// %bb.23:                              // %if.end23
                                        //   in Loop: Header=BB37_21 Depth=1
	{
		r4 = maxu(r17,r3)
		p1 = cmp.gtu(r27,r17)
		if (!p1.new) jump:nt .LBB37_42
	}
// %bb.24:                              // %if.end28
                                        //   in Loop: Header=BB37_21 Depth=1
	{
		r22 = asl(r26,#11)
		p0 = cmp.gtu(r27,r18)
		if (p0.new) r20 = sub(r18,r3)
		if (!p0.new) r20 = add(r19,#0)
	}
	{
		r21 = sub(r4,r3)
		if (!cmp.gtu(r20,r21.new)) jump:t .LBB37_42
	}
	.falign
.LBB37_26:                              // %for.body39
                                        //   Parent Loop BB37_21 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB37_35 Depth 3
                                        //       Child Loop BB37_39 Depth 3
	{
		r5 = r22
		r3 = memw(r16+#12)
		r7:6 = memd(r16+#152)
	}
	{
		p0 = cmp.eq(r7,#0)
		r2 = memw(r16+#168)
	}
	{
		r4 = mpyi(r21,r3)
		r2 -= mpyi(r21,#96)
	}
	{
		r1 = minu(r2,r24)
		r4 = +mpyi(r4,#3)
		if (!p0) r2 = memw(r16+#180)
	}
	{
		r5 += add(r6,r4)
		if (p0) jump:nt .LBB37_33
	}
// %bb.27:                              // %if.then51
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		r7 += mpyi(r2,r26)
	}
	{
		r7 += mpyi(r21,##2560)
	}
	.falign
.LBB37_28:                              // %if.end95
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		r0 = r7
		r2 = memw(r29+#124)
		r4 = memw(r16+#188)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r2 = #128
		if (!p1.new) jump:t .LBB37_31
	}
// %bb.29:                              // %if.then97
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		call hvx_tl2_expand_wh96_disjoint
		r2 = #128
	}
	.falign
// %bb.30:                              // %if.then97
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB37_26
	}
	{
		jump .LBB37_41
	}
	.falign
.LBB37_31:                              // %if.else104
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		call hvx_tl2_expand_wh96
	}
	.falign
// %bb.32:                              // %if.else104
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		r21 = add(r21,#1)
		if (cmp.gtu(r20,r21.new)) jump:t .LBB37_26
	}
	{
		jump .LBB37_41
	}
	.falign
.LBB37_33:                              // %if.else
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB37_28
		r7 = add(r29,#128)
		r6 = r5
	}
// %bb.34:                              //   in Loop: Header=BB37_26 Depth=2
	{
		r4 = add(##989,mpyi(r1,#43))
	}
	{
		r4 = lsr(r4,#10)
	}
	{
		r8 = minu(r4,r25)
	}
	{
		r8 = +mpyi(r8,#5)
	}
	{
		loop0(.LBB37_35,r8)
	}
	.falign
.LBB37_35:                              // Block address taken
                                        // %for.body73
                                        //   Parent Loop BB37_21 Depth=1
                                        //     Parent Loop BB37_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		v0.cur = vmem(r6++#1)
		vmem(r7++#1) = v0
	} :endloop0
// %bb.36:                              // %for.cond.cleanup72
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		p0 = cmp.gtu(r2,#48)
		r7 = add(r29,#128)
		if (!p0.new) jump:t .LBB37_28
	}
// %bb.37:                              // %for.cond79.preheader
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		r4 = add(##-10,mpyi(r4,#5))
	}
	{
		if (!p1.new) r2 = add(r5,r3)
		p1 = cmp.eq(r4,#0); if (p1.new) jump:nt .LBB37_28
	}
// %bb.38:                              // %for.body84.lr.ph
                                        //   in Loop: Header=BB37_26 Depth=2
	{
		loop0(.LBB37_39,r4)
		r6 = add(r29,#128)
	}
	{
		r4 = add(r6,#1280)
	}
	.falign
.LBB37_39:                              // Block address taken
                                        // %for.body84
                                        //   Parent Loop BB37_21 Depth=1
                                        //     Parent Loop BB37_26 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r7 = add(r29,#128)
		v1.cur = vmem(r2++#1)
		vmem(r4++#1) = v1
	} :endloop0
	{
		jump .LBB37_28
	}
	.falign
.LBB37_40:                              //   in Loop: Header=BB37_21 Depth=1
	{
		r27 = r3
		jump .LBB37_42
	}
	.falign
.LBB37_41:                              // %for.inc116.loopexit
                                        //   in Loop: Header=BB37_21 Depth=1
	{
		r7:6 = combine(#0,#1)
		r9:8 = combine(#0,#0)
		r2 = memw(r16+#172)
	}
	.falign
.LBB37_42:                              // %for.inc116
                                        //   in Loop: Header=BB37_21 Depth=1
	{
		r3 = r27
		r26 = add(r26,#1)
		if (cmp.gtu(r2,r26.new)) jump:t .LBB37_21
	}
	.falign
.LBB37_43:                              // %cleanup150
	{
		r17:16 = memd(r30+#-8)
		r19:18 = memd(r30+#-16)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r30+#-24)
		r23:22 = memd(r30+#-32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r30+#-40)
		r27:26 = memd(r30+#-48)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end37:
	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"hvx_gemv_u8tl2.c"
	.globl	hvx_tl2_weight_bytes            // -- Begin function hvx_tl2_weight_bytes
	.falign
	.type	hvx_tl2_weight_bytes,@function
hvx_tl2_weight_bytes:                   // @hvx_tl2_weight_bytes
// %bb.0:                               // %entry
	{
		r2 = add(r0,##-8421505)
		r3 = ##-8421504
	}
	{
		if (!p0.new) r3 = #127
		r2 = #0
		p0 = cmp.gtu(r3,r2); if (p0.new) jump:nt .LBB0_3
	}
// %bb.1:                               // %entry
	{
		r4 = lsr(r1,#7)
		r3 = add(r1,#127)
		if (!cmp.gtu(r3.new,r3)) jump:nt .LBB0_3
	}
// %bb.2:                               // %if.end
	{
		r2 = ##-1431655765
		r3 = #127
	}
	{
		r2 = mpyu(r0,r2)
		p0 = !bitsclr(r1,r3)
		r3 = #0
	}
	{
		r2 = lsr(r2,#4)
		if (p0) r4 = add(r4,#1)
	}
	{
		r0 -= mpyi(r2,#24)
	}
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) r2 = add(r2,#1)
	}
	{
		r1:0 = mpyu(r4,r2)
		r2 = ##6710886
	}
	{
		p0 = cmp.gtu(r1:0,r3:2)
	}
	{
		r2 = +mpyi(r0,##640)
	}
	{
		if (p0) r2 = #0
	}
	.falign
.LBB0_3:                                // %return
	{
		r0 = r2
		jumpr r31
	}
.Lfunc_end0:
	.size	hvx_tl2_weight_bytes, .Lfunc_end0-hvx_tl2_weight_bytes
                                        // -- End function
	.globl	hvx_tl2_table_bytes             // -- Begin function hvx_tl2_table_bytes
	.balign 32
	.type	hvx_tl2_table_bytes,@function
hvx_tl2_table_bytes:                    // @hvx_tl2_table_bytes
// %bb.0:                               // %entry
	{
		r2 = add(r0,##-8421505)
		r3 = ##-8421504
	}
	{
		r2 = #0
		p0 = cmp.gtu(r3,r2); if (p0.new) jump:t .LBB1_2
	}
// %bb.1:                               // %if.end
	{
		r2 = ##-1431655765
	}
	{
		r2 = mpyu(r0,r2)
	}
	{
		r2 = lsr(r2,#4)
	}
	{
		r0 -= mpyi(r2,#24)
	}
	{
		p1 = cmp.eq(r0,#0)
		if (!p1.new) r2 = add(r2,#1)
	}
	{
		r2 = asl(r2,#9)
	}
	.falign
.LBB1_2:                                // %return
	{
		r0 = r2
		jumpr r31
	}
.Lfunc_end1:
	.size	hvx_tl2_table_bytes, .Lfunc_end1-hvx_tl2_table_bytes
                                        // -- End function
	.globl	hvx_tl2_k_splits                // -- Begin function hvx_tl2_k_splits
	.falign
	.type	hvx_tl2_k_splits,@function
hvx_tl2_k_splits:                       // @hvx_tl2_k_splits
// %bb.0:                               // %entry
	{
		r3 = add(r2,#-9)
		r4 = #-7
		memd(r29+#-16) = r17:16
		allocframe(#48)
	}                                       // 8-byte Folded Spill
	{
		p1 = cmp.gtu(r4,r3)
		r0 = #1
		r3 = r0
		memd(r29+#32) = r19:18
	}                                       // 8-byte Folded Spill
	{
		if (!p1) r4 = add(r3,##-8421505)
		memd(r29+#24) = r21:20
		memd(r29+#16) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (!p1) jump:nt .LBB2_2
		memd(r29+#8) = r25:24
		memd(r29+#0) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
.LBB2_1:                                // %return
	{
		r17:16 = memd(r29+#40)
		r19:18 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#24)
		r23:22 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#8)
		r27:26 = memd(r29+#0)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB2_2:                                // %lor.lhs.false2
	{
		r5 = ##-8421504
		if (cmp.gtu(r5.new,r4)) jump:nt .LBB2_1
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r19 = #127
	}
	{
		r19 = add(r1,#127)
		if (!cmp.gtu(r19.new,r19)) jump:nt .LBB2_1
	}
// %bb.4:                               // %if.end.i
	{
		r6 = lsr(r1,#7)
		r4 = ##-1431655765
		r5 = #127
	}
	{
		r4 = mpyu(r3,r4)
		p1 = !bitsclr(r1,r5)
		r8 = ##6710886
	}
	{
		r17 = lsr(r4,#4)
		r9 = #0
		if (p1) r6 = add(r6,#1)
	}
	{
		r3 -= mpyi(r17,#24)
	}
	{
		p0 = cmp.eq(r3,#0)
		if (!p0.new) r17 = add(r17,#1)
	}
	{
		r5:4 = mpyu(r6,r17)
	}
	{
		p0 = cmp.gtu(r5:4,r9:8)
		if (p0.new) jump:nt .LBB2_1
	}
// %bb.5:                               // %if.end.i
	{
		r3 = +mpyi(r4,##640)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB2_1
	}
// %bb.6:                               // %if.end.i
	{
		p0 = cmp.gtu(r17,#63)
		if (!p0.new) jump:nt .LBB2_1
		r1 = r2
		r22 = add(r2,#-1)
	}
// %bb.7:                               // %for.body.lr.ph
	{
		r16 = r2
		r18 = #1
		r0 = r22
	}
	{
		r0 += lsr(r19,#7)
		call __hexagon_udivsi3
	}
	.falign
// %bb.8:                               // %for.body.lr.ph
	{
		r19 = extractu(r19,#25,#7)
		r21:20 = mpyu(r0,r17)
		r1 = r16
	}
	{
		r0 = addasl(r22,r19,#1)
		call __hexagon_udivsi3
	}
	.falign
// %bb.9:                               // %for.body.lr.ph
	{
		r24 = #9
		r23 = #10
		r2 = add(r17,#1)
	}
	{
		r5:4 = mpyu(r20,r24)
		r2 = lsr(r2,#1)
	}
	{
		r1:0 = mpyu(r0,r2)
		r5 += mpyi(r21,#9)
	}
	{
		r3:2 = mpyu(r0,r23)
	}
	{
		r3 += mpyi(r1,#10)
	}
	{
		p0 = cmp.gtu(r5:4,r3:2)
	}
	{
		r0 = addasl(r22,r19,#2)
		r25 = mux(p0,r0,r20)
		r26 = mux(p0,r1,r21)
		r1 = r16
	}
	{
		call __hexagon_udivsi3
		r18 = mux(p0,#2,#1)
	}
	.falign
// %bb.10:                              // %for.body.lr.ph
	{
		r7:6 = mpyu(r25,r24)
		r2 = add(r17,#3)
	}
	{
		r7 += mpyi(r26,#9)
		r3 = lsr(r2,#2)
		r2 = r0
		r0 = r18
	}
	{
		r3:2 = mpyu(r2,r3)
	}
	{
		r5:4 = mpyu(r2,r23)
	}
	{
		r5 += mpyi(r3,#10)
	}
	{
		p1 = cmp.gtu(r7:6,r5:4)
		if (p1.new) r0 = #4
		jump .LBB2_1
	}
.Lfunc_end2:
	.size	hvx_tl2_k_splits, .Lfunc_end2-hvx_tl2_k_splits
                                        // -- End function
	.globl	hvx_tl2_expand_wh96             // -- Begin function hvx_tl2_expand_wh96
	.falign
	.type	hvx_tl2_expand_wh96,@function
hvx_tl2_expand_wh96:                    // @hvx_tl2_expand_wh96
// %bb.0:                               // %entry
	{
		p3 = cmp.eq(r4,#1)
		r11 = r5
		p0 = cmp.eq(r4,#7)
		allocframe(r29,#176):raw
	}
	{
		memd(r29+#168) = r17:16
		memd(r29+#160) = r19:18
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#152) = r21:20
		memd(r29+#144) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p3) jump:nt .LBB3_2
		if (!p0) jump:nt .LBB3_5
		memd(r29+#136) = r25:24
		memd(r29+#128) = r27:26
	}                                       // 8-byte Folded Spill
	.falign
.LBB3_2:                                // %if.then
	{
		r4 = #-32
	}
	{
		p2 = bitsclr(r1,r4)
		if (!p2.new) r6 = ##16875776
		if (p2.new) jump:nt .LBB3_32
	}
// %bb.3:                               // %if.end.lr.ph
	{
		r4 = add(pc,##tl2_expand_nibbles@PCREL)
		r5 = ##252645135
	}
	{
		r13 = mux(p0,##384,#0)
		r8 = ##269520911
	}
	{
		r9 = ##33718785
		r10 = add(r6,#-32767)
		r13 = add(r4,r13)
	}
	{
		r12 = ##67404803
		p1 = cmp.gtu(r2,#31)
		p3 = cmp.gtu(r2,#63)
	}
	{
		v3 = vsplat(r5)
		r7:6 = combine(#4,#2)
		r5 = #1
		v5 = vmem(r13+#0)
	}
	{
		r16 = add(r8,#-32767)
		r14 = add(r9,#-32767)
		r4 = add(r12,#-32767)
		v4 = vmem(r13+#1)
	}
	{
		p0 = and(p0,!p0)
		v2.h = vasl(v5.h,r7)
		v6 = vmem(r13+#2)
	}
	{
		if (p1) jump:nt .LBB3_16
		v1.h = vasl(v4.h,r7)
		v0.h = vasl(v6.h,r7)
	}
// %bb.4:
	{
		p2 = or(p0,p0)
		p3 = or(p0,p0)
		jump .LBB3_23
	}
	.falign
.LBB3_5:                                // %for.cond71.preheader
	{
		r19 = r4
		p0 = cmp.gtu(r1,#31); if (!p0.new) jump:t .LBB3_32
	}
// %bb.6:                               // %for.cond78.preheader.lr.ph
	{
		if (p1.new) r4 = add(r0,##512)
		p1 = cmp.gtu(r2,#31); if (!p1.new) jump:t .LBB3_32
	}
// %bb.7:                               // %for.cond78.preheader.us.preheader
	{
		r21 = add(pc,##hvx_tl2_expand_wh96.trits@PCREL)
		r2 = lsr(r2,#5)
		memw(r29+#52) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r0,#524)
		r23 = sub(#0,r19)
		r20 = add(r11,#12)
		memw(r29+#96) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r4 = lsr(r1,#5)
		r2 = add(r0,#12)
		memw(r29+#88) = r4
		memw(r29+#84) = r3
	}                                       // 4-byte Folded Spill
	{
		r5 = #0
		r6 = r11
		memw(r29+#100) = r2
		memw(r29+#92) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r0,#520)
		memw(r29+#104) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r0,#8)
		r4 = add(r11,#4)
		memw(r29+#108) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r0,#516)
		memw(r29+#112) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r0,#4)
		memw(r29+#76) = r0
		memw(r29+#80) = r11
	}                                       // 4-byte Folded Spill
	{
		r2 = add(r11,#8)
		memw(r29+#116) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB3_8:                                // %for.cond78.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB3_9 Depth 2
                                        //       Child Loop BB3_11 Depth 3
                                        //         Child Loop BB3_12 Depth 4
	{
		r11 += mpyi(r5,r3)
		r3 = #0
		r17 = memw(r29+#100)
		memw(r29+#4) = r0
	}                                       // 4-byte Folded Reload
	{
		r7 = asl(r5,#5)
		r16 = memw(r29+#96)
		memw(r29+#60) = r2
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#88)
		memw(r29+#28) = r2
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#116)
		memw(r29+#8) = r0
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#108)
		memw(r29+#32) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#112)
		memw(r29+#40) = r7
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r29+#104)
		memw(r29+#72) = r6
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#12) = r6
		memw(r29+#64) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#16) = r4
		memw(r29+#20) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#24) = r0
		memw(r29+#68) = r5
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#48) = r11
		memw(r29+#36) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#56) = r20
	}                                       // 4-byte Folded Spill
	.falign
.LBB3_9:                                // %for.body83.us
                                        //   Parent Loop BB3_8 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB3_11 Depth 3
                                        //         Child Loop BB3_12 Depth 4
	{
		r1 = #0
		r2 = #512
		r0 = memw(r29+#48)
		memw(r29+#44) = r3
	}                                       // 4-byte Folded Reload
	{
		r0 += asl(r3,#9)
		call memset
		r24 = #0
	}
	.falign
// %bb.10:                              // %for.body83.us
                                        //   in Loop: Header=BB3_9 Depth=2
	{
		loop1(.LBB3_11,#32)
		r3:2 = combine(#0,#0)
	}
	.falign
.LBB3_11:                               // Block address taken
                                        // %for.body93.us
                                        //   Parent Loop BB3_8 Depth=1
                                        //     Parent Loop BB3_9 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB3_12 Depth 4
	{
		r6 = and(r24,#3)
		r7 = ##-1431655765
		r4 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		r5 = and(r3,#4)
		r12 = r2
		r4 = add(r3,r4)
		r14 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r12 = insert(r6,#7,#0)
		r13 = mpyu(r4,r7)
		r8 = r4
		r28 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		r7 = lsr(r13,#4)
		r1 = lsr(r13,#1)
		r6 = add(r20,r12)
		r15 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r8 -= mpyi(r7,#24)
	}
	{
		r0 = +mpyi(r7,##640)
		r9 = and(r8,#255)
		r7 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r9 = +mpyi(r9,#171)
		r7 = add(r7,r12)
		r15 = add(r15,r0)
		r8 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(r8,r12)
		r12 = add(r14,r12)
		r10 = r9
		r14 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r11 = lsr(r9,#9)
		r13 = add(r16,r0)
		r14 = add(r14,r0)
		r28 = add(r28,r0)
	}
	{
		r10 = and(##8064,lsr(r10,#3))
		r9 = and(#4,lsr(r9,#7))
		r18 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r4 -= mpyi(r1,#3)
		r25 = add(r0,r10)
		r10 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r0 = lsl(#1,r11)
		r1 = add(r17,r25)
		r11 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		loop0(.LBB3_12,#8)
		r10 = add(r10,r25)
		r11 = add(r11,r25)
		r25 = add(r18,r25)
	}
	.falign
.LBB3_12:                               // Block address taken
                                        // %for.body106.us
                                        //   Parent Loop BB3_8 Depth=1
                                        //     Parent Loop BB3_9 Depth=2
                                        //       Parent Loop BB3_11 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r18 = #15
		r26 = r21
		r22 = memub(r25+#0)
		r27 = memub(r28+#0)
	}
	{
		r18 &= lsr(r22,r9)
		p2 = bitsclr(r0,r27)
		r28 = add(r28,#16)
		r25 = add(r25,#16)
	}
	{
		r26 += mpyi(r18,#3)
		r18 = mux(p2,r19,r23)
	}
	{
		r22 = memub(r4+r26<<#0)
	}
	{
		r18 = mpyi(r22,r18)
	}
	{
		r18 = and(r18,#15)
	}
	{
		r18 = asl(r18,r5)
	}
	{
		r18 = #15
		r12 = add(r12,#16)
		memb(r12+#0) |= r18
	}
	{
		r11 = add(r11,#16)
		r15 = add(r15,#16)
		r22 = memub(r11+#0)
		r26 = memub(r15+#0)
	}
	{
		r18 &= lsr(r22,r9)
		p3 = bitsclr(r0,r26)
		r22 = r21
	}
	{
		r22 += mpyi(r18,#3)
		r18 = mux(p3,r19,r23)
	}
	{
		r22 = memub(r4+r22<<#0)
	}
	{
		r18 = mpyi(r22,r18)
	}
	{
		r18 = and(r18,#15)
	}
	{
		r18 = asl(r18,r5)
	}
	{
		r18 = #15
		r8 = add(r8,#16)
		memb(r8+#0) |= r18
	}
	{
		r10 = add(r10,#16)
		r14 = add(r14,#16)
		r22 = memub(r10+#0)
		r26 = memub(r14+#0)
	}
	{
		r18 &= lsr(r22,r9)
		p0 = bitsclr(r0,r26)
		r22 = r21
	}
	{
		r22 += mpyi(r18,#3)
		r18 = mux(p0,r19,r23)
	}
	{
		r22 = memub(r4+r22<<#0)
	}
	{
		r18 = mpyi(r22,r18)
	}
	{
		r18 = and(r18,#15)
	}
	{
		r18 = asl(r18,r5)
	}
	{
		r18 = #15
		r7 = add(r7,#16)
		memb(r7+#0) |= r18
	}
	{
		r1 = add(r1,#16)
		r13 = add(r13,#16)
		r22 = memub(r1+#0)
		r26 = memub(r13+#0)
	}
	{
		r18 &= lsr(r22,r9)
		p1 = bitsclr(r0,r26)
		r22 = r21
	}
	{
		r22 += mpyi(r18,#3)
		r18 = mux(p1,r19,r23)
	}
	{
		r22 = memub(r4+r22<<#0)
	}
	{
		r18 = mpyi(r22,r18)
	}
	{
		r18 = and(r18,#15)
	}
	{
		r18 = asl(r18,r5)
	}
	{
		r6 = add(r6,#16)
		memb(r6+#0) |= r18
	} :endloop0
// %bb.13:                              // %for.cond.cleanup105.us
                                        //   in Loop: Header=BB3_11 Depth=3
	{
		r24 = add(r24,#1)
		nop
		r2 = add(r2,#16)
		r3 = add(r3,#1)
	} :endloop1
// %bb.14:                              // %for.cond.cleanup92.us
                                        //   in Loop: Header=BB3_9 Depth=2
	{
		r16 = add(r16,#1)
		r17 = add(r17,#1)
		r2 = memw(r29+#36)
		r3 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		r3 = add(r3,#1)
		r20 = add(r20,#512)
		memw(r29+#36) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		memw(r29+#32) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#512)
		memw(r29+#28) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		memw(r29+#24) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r3,r2)
		r2 = memw(r29+#20)
		if (p1.new) r11 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		memw(r29+#20) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#512)
		memw(r29+#16) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#512)
		memw(r29+#12) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		memw(r29+#8) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		if (!p1) jump:nt .LBB3_9
		memw(r29+#4) = r2.new
	}                                       // 4-byte Folded Spill
// %bb.15:                              // %for.cond78.for.cond.cleanup82_crit_edge.us
                                        //   in Loop: Header=BB3_8 Depth=1
	{
		r5 = memw(r29+#68)
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r5 = add(r5,#1)
		r20 = memw(r29+#56)
		r3 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r5,r2)
		r20 = add(r20,r3)
		r6 = memw(r29+#72)
		r2 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,r3)
		r6 = add(r6,r3)
		r4 = memw(r29+#64)
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r3)
		if (!p2) jump:nt .LBB3_8
	}
	{
		jump .LBB3_32
	}
	.falign
.LBB3_16:                               // %for.inc61
	{
		v7 = vmemu(r0+#0)
	}
	{
		v9 = vand(v7,v3)
		v8 = vmemu(r0+#4)
	}
	{
		q3 = vand(v8,r10)
		v11.uh = vlsr(v7.uh,r7)
		v10 = vmemu(r0+#1)
	}
	{
		q1 = vand(v8,r14)
		v9 |= vand(q3,r16)
		v12 = vand(v11,v3)
		v16 = vand(v10,v3)
	}
	{
		v12 |= vand(q1,r16)
		q2 = vand(v8,r4)
	}
	{
		v16 |= vand(q2,r16)
		v13.b = vlut32(v9.b,v5.b,#0)
	}
	{
		v14.b = vlut32(v9.b,v4.b,#0)
	}
	{
		v15.b = vlut32(v9.b,v6.b,#0)
	}
	{
		v17.b = vlut32(v12.b,v5.b,#0)
	}
	{
		v13.b |= vlut32(v12.b,v1.b,#0)
	}
	{
		v14.b |= vlut32(v12.b,v0.b,#0)
	}
	{
		v15.b |= vlut32(v16.b,v2.b,#0)
	}
	{
		v17.b |= vlut32(v16.b,v1.b,#0)
	}
	{
		v29:28 = vshuff(v14,v13,r5)
	}
	{
		v31:30 = vshuff(v17,v15,r5)
	}
	{
		v11:10 = vshuff(v30,v28,r6)
	}
	{
		if (!p3) jump:nt .LBB3_20
		vmemu(r11+#0) = v10
	}
// %bb.17:                              // %for.inc61.1
	{
		p2 = cmp.gtu(r2,#95)
		if (p2.new) r7 = add(r11,##1024)
		v9:8 = vshuff(v31,v29,r6)
	}
	{
		if (!p2) jump:nt .LBB3_21
		vmemu(r11+#4) = v8
	}
// %bb.18:                              // %for.inc61.2
	{
		p3 = cmp.gtu(r2,#127)
		if (p3.new) r2 = add(r11,##1536)
	}
	{
		if (!p3) jump:nt .LBB3_22
		vmemu(r7+#0) = v11
	}
// %bb.19:                              // %if.then56.3
	{
		p0 = or(p0,!p0)
	}
	{
		p2 = or(p0,p0)
		p3 = or(p0,p0)
		vmemu(r2+#0) = v9
	}
	{
		jump .LBB3_23
	}
	.falign
.LBB3_20:
	{
		p2 = or(p0,p0)
		p3 = or(p0,p0)
		jump .LBB3_23
	}
	.falign
.LBB3_21:
	{
		p2 = or(p2,!p2)
		p3 = or(p0,p0)
		jump .LBB3_23
	}
	.falign
.LBB3_22:
	{
		p2 = or(p2,!p2)
	}
	{
		p3 = or(p2,p2)
	}
	.falign
.LBB3_23:                               // %if.end.1
	{
		r7 = ##134776839
		v18 = vmemu(r0+#1)
	}
	{
		r2 = #4
		r7 = add(r7,#-32767)
		v19 = vmemu(r0+#2)
	}
	{
		v22.uh = vlsr(v18.uh,r2)
		v20 = vand(v18,v3)
		v21 = vmemu(r0+#4)
	}
	{
		r2 = ##539009055
		v24.uh = vlsr(v19.uh,r2)
		v23 = vand(v19,v3)
	}
	{
		q0 = vand(v21,r4)
		q3 = vand(v21,r7)
		r2 = add(r2,#-32767)
		v25 = vand(v22,v3)
	}
	{
		v20 |= vand(q0,r16)
		v25 |= vand(q3,r16)
		r12 = #4
		v30 = vand(v24,v3)
	}
	{
		q1 = vand(v21,r16)
		r8 = ##1077985343
		r13 = add(r11,#1408)
	}
	{
		q2 = vand(v21,r2)
		v23 |= vand(q1,r16)
		r9 = ##-2139029377
	}
	{
		v30 |= vand(q2,r16)
		r8 = add(r8,#-32767)
		r9 = add(r9,#-32767)
		v26.b = vlut32(v20.b,v6.b,#0)
	}
	{
		v27.b = vlut32(v25.b,v5.b,#0)
	}
	{
		v28.b = vlut32(v25.b,v4.b,#0)
	}
	{
		v29.b = vlut32(v25.b,v6.b,#0)
	}
	{
		v26.b |= vlut32(v23.b,v2.b,#0)
	}
	{
		v27.b |= vlut32(v23.b,v1.b,#0)
	}
	{
		v28.b |= vlut32(v23.b,v0.b,#0)
	}
	{
		v29.b |= vlut32(v30.b,v2.b,#0)
	}
	{
		v9:8 = vshuff(v27,v26,r5)
	}
	{
		r5 = add(r11,#1152)
		v11:10 = vshuff(v29,v28,r5)
	}
	{
		v25:24 = vshuff(v10,v8,r6)
	}
	{
		r6 = #1
		v17:16 = vshuff(v11,v9,r6)
	}
	{
		if (p0) r5 = add(r11,##1664)
		if (p3) vmemu(r5+#0) = v25
	}
	{
		r5 = #4
		if (p0) vmemu(r5+#0) = v17
	}
	{
		if (p1) vmemu(r11+#1) = v24
	}
	{
		if (p2) vmemu(r11+#5) = v16
	}
	{
		v7 = vmemu(r0+#2)
	}
	{
		v31 = vmemu(r0+#3)
	}
	{
		v30.uh = vlsr(v7.uh,r5)
		v28 = vmemu(r0+#4)
	}
	{
		q2 = vand(v28,r8)
		v29.uh = vlsr(v31.uh,r5)
		v31 = vand(v31,v3)
		v13 = vand(v30,v3)
	}
	{
		q3 = vand(v28,r2)
		v31 |= vand(q2,r16)
		r5 = #1
		v12 = vand(v29,v3)
	}
	{
		v13 |= vand(q3,r16)
		q3 = vand(v28,r9)
	}
	{
		v12 |= vand(q3,r16)
		v14.b = vlut32(v31.b,v5.b,#0)
	}
	{
		v15.b = vlut32(v31.b,v4.b,#0)
	}
	{
		v9.b = vlut32(v13.b,v4.b,#0)
	}
	{
		v10.b = vlut32(v13.b,v6.b,#0)
	}
	{
		v14.b |= vlut32(v12.b,v1.b,#0)
	}
	{
		v15.b |= vlut32(v12.b,v0.b,#0)
	}
	{
		v9.b |= vlut32(v31.b,v0.b,#0)
	}
	{
		v10.b |= vlut32(v12.b,v2.b,#0)
	}
	{
		v21:20 = vshuff(v15,v14,r5)
	}
	{
		r5 = #2
		v23:22 = vshuff(v10,v9,r5)
	}
	{
		v27:26 = vshuff(v20,v22,r5)
	}
	{
		r5 = add(r11,#1280)
		v19:18 = vshuff(v21,v23,r5)
	}
	{
		if (p0) r5 = add(r11,##1792)
		if (p3) vmemu(r5+#0) = v27
	}
	{
		r5 = p3
		if (p0) vmemu(r5+#0) = v19
	}
	{
		if (p1) vmemu(r11+#2) = v26
	}
	{
		if (p2) vmemu(r11+#6) = v18
	}
	{
		v18 = vmemu(r0+#5)
	}
	{
		r5 = add(r0,#1152)
		v12 = vand(v18,v3)
		memw(r29+#4) = r5
	}                                       // 4-byte Folded Spill
	{
		r12 = and(r1,#-32)
		v13.uh = vlsr(v18.uh,r12)
		v19 = vmemu(r5+#0)
	}
	{
		q1 = vand(v19,r10)
		v16 = vand(v13,v3)
		v14 = vmemu(r0+#6)
	}
	{
		q3 = vand(v19,r14)
		v12 |= vand(q1,r16)
		p3 = cmp.gtu(r12,#32)
		v15 = vand(v14,v3)
	}
	{
		v16 |= vand(q3,r16)
		q3 = vand(v19,r4)
		if (p3) r1 = #1
	}
	{
		v15 |= vand(q3,r16)
		v17.b = vlut32(v12.b,v5.b,#0)
	}
	{
		v18.b = vlut32(v12.b,v4.b,#0)
	}
	{
		v21.b = vlut32(v12.b,v6.b,#0)
	}
	{
		v22.b = vlut32(v16.b,v5.b,#0)
	}
	{
		v17.b |= vlut32(v16.b,v1.b,#0)
	}
	{
		v18.b |= vlut32(v16.b,v0.b,#0)
	}
	{
		v21.b |= vlut32(v15.b,v2.b,#0)
	}
	{
		v22.b |= vlut32(v15.b,v1.b,#0)
	}
	{
		v25:24 = vshuff(v18,v17,r6)
	}
	{
		r6 = #2
		v31:30 = vshuff(v22,v21,r6)
	}
	{
		v13:12 = vshuff(v30,v24,r6)
	}
	{
		r6 = p2
		v21:20 = vshuff(v31,v25,r6)
		memw(r29+#8) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r6 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		p2 = r6
		if (p2) vmemu(r11+#7) = v20
	}
	{
		r13 = add(r11,#1920)
		if (p2) vmemu(r13+#0) = v13
	}
	{
		if (p1) vmemu(r11+#3) = v12
	}
	{
		if (p3) r13 = #4
		if (!p3) jump:nt .LBB3_32
		if (p0) vmemu(r13+#0) = v21
	}
// %bb.24:                              // %if.end.4
	{
		p3 = cmp.gtu(r12,#40)
		v30 = vmemu(r0+#6)
	}
	{
		v7 = vand(v30,v3)
		v31 = vmemu(r0+#7)
	}
	{
		v8.uh = vlsr(v30.uh,r13)
		v9 = vand(v31,v3)
		v29 = vmemu(r5+#0)
	}
	{
		q2 = vand(v29,r4)
		q3 = vand(v29,r7)
		v11.uh = vlsr(v31.uh,r13)
		v10 = vand(v8,v3)
	}
	{
		v10 |= vand(q3,r16)
		q0 = vand(v29,r16)
		v12 = vand(v11,v3)
		r6 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		v7 |= vand(q2,r16)
		q1 = vand(v29,r2)
		r13 = add(r11,r3)
	}
	{
		v9 |= vand(q0,r16)
		v12 |= vand(q1,r16)
		r15 = add(r13,#1024)
		v14.b = vlut32(v10.b,v5.b,#0)
	}
	{
		p2 = r6
		v13.b = vlut32(v7.b,v6.b,#0)
		r6 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		v15.b = vlut32(v10.b,v4.b,#0)
	}
	{
		v16.b = vlut32(v10.b,v6.b,#0)
	}
	{
		v13.b |= vlut32(v9.b,v2.b,#0)
	}
	{
		v14.b |= vlut32(v9.b,v1.b,#0)
	}
	{
		v15.b |= vlut32(v9.b,v0.b,#0)
	}
	{
		v16.b |= vlut32(v12.b,v2.b,#0)
	}
	{
		v21:20 = vshuff(v14,v13,r1)
	}
	{
		r1 = #2
		v23:22 = vshuff(v16,v15,r1)
	}
	{
		v15:14 = vshuff(v22,v20,r1)
	}
	{
		v23:22 = vshuff(v23,v21,r1)
	}
	{
		if (p1) vmemu(r13+#0) = v14
	}
	{
		p2 = r6
		if (p2) vmemu(r13+#4) = v22
	}
	{
		r15 = add(r15,#512)
		if (p2) vmemu(r15+#0) = v15
	}
	{
		if (p3) r15 = #4
		if (!p3) jump:nt .LBB3_32
		if (p0) vmemu(r15+#0) = v23
	}
// %bb.25:                              // %if.end.5
	{
		r5 = add(r0,#1024)
		p3 = cmp.gtu(r12,#48)
		v17 = vmemu(r5+#0)
	}
	{
		q0 = vand(v17,r2)
		q2 = vand(v17,r8)
		v19 = vmemu(r0+#7)
	}
	{
		q3 = vand(v17,r9)
		r5 = #1
		v18 = vmemu(r5+#0)
	}
	{
		if (p3) r1 = #1
		v22.uh = vlsr(v19.uh,r15)
		v20 = vand(v18,v3)
		r6 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		p2 = r6
		v20 |= vand(q2,r16)
		v21.uh = vlsr(v18.uh,r15)
		v24 = vand(v22,v3)
	}
	{
		v24 |= vand(q0,r16)
		v23 = vand(v21,v3)
		r6 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		v23 |= vand(q3,r16)
		if (p3) r15 = add(r0,##1280)
		v25.b = vlut32(v20.b,v5.b,#0)
	}
	{
		if (p3) r28 = add(r0,##1408)
		v26.b = vlut32(v20.b,v4.b,#0)
	}
	{
		v27.b = vlut32(v24.b,v4.b,#0)
	}
	{
		v28.b = vlut32(v24.b,v6.b,#0)
	}
	{
		v27.b |= vlut32(v20.b,v0.b,#0)
	}
	{
		v28.b |= vlut32(v23.b,v2.b,#0)
	}
	{
		v25.b |= vlut32(v23.b,v1.b,#0)
	}
	{
		v26.b |= vlut32(v23.b,v0.b,#0)
	}
	{
		v29:28 = vshuff(v28,v27,r5)
	}
	{
		r5 = #2
		v25:24 = vshuff(v26,v25,r5)
	}
	{
		v17:16 = vshuff(v24,v28,r5)
	}
	{
		r5 = add(r13,#1152)
		v25:24 = vshuff(v25,v29,r5)
	}
	{
		if (p1) vmemu(r13+#1) = v16
	}
	{
		p2 = r6
		if (p3) r6 = #4
		if (p2) vmemu(r13+#5) = v24
	}
	{
		r5 = add(r13,#1664)
		if (p2) vmemu(r5+#0) = v17
	}
	{
		if (p3) r5 = add(r0,##1792)
		if (!p3) jump:nt .LBB3_32
		if (p0) vmemu(r5+#0) = v25
	}
// %bb.26:                              // %if.end.6
	{
		r15 = add(r13,#1280)
		p3 = cmp.gtu(r12,#56)
		v29 = vmemu(r15+#0)
	}
	{
		v31 = vand(v29,v3)
		v30 = vmemu(r5+#0)
	}
	{
		q0 = vand(v30,r10)
		v7.uh = vlsr(v29.uh,r6)
		v8 = vmemu(r28+#0)
	}
	{
		q1 = vand(v30,r14)
		v31 |= vand(q0,r16)
		v9 = vand(v7,v3)
		v13 = vand(v8,v3)
	}
	{
		v9 |= vand(q1,r16)
		q2 = vand(v30,r4)
		r6 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		p2 = r6
		v13 |= vand(q2,r16)
		v10.b = vlut32(v31.b,v5.b,#0)
		r6 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		v11.b = vlut32(v31.b,v4.b,#0)
	}
	{
		v12.b = vlut32(v31.b,v6.b,#0)
	}
	{
		v14.b = vlut32(v9.b,v5.b,#0)
	}
	{
		v10.b |= vlut32(v9.b,v1.b,#0)
	}
	{
		v11.b |= vlut32(v9.b,v0.b,#0)
	}
	{
		v12.b |= vlut32(v13.b,v2.b,#0)
	}
	{
		v14.b |= vlut32(v13.b,v1.b,#0)
	}
	{
		v27:26 = vshuff(v11,v10,r1)
	}
	{
		r1 = #2
		v25:24 = vshuff(v14,v12,r1)
	}
	{
		v19:18 = vshuff(v24,v26,r1)
	}
	{
		if (p3) r1 = #1
		v27:26 = vshuff(v25,v27,r1)
	}
	{
		if (p1) vmemu(r13+#2) = v18
	}
	{
		p2 = r6
		if (p3) r6 = #4
		if (p2) vmemu(r13+#6) = v26
	}
	{
		r15 = add(r13,#1792)
		if (p2) vmemu(r15+#0) = v19
	}
	{
		if (p3) r15 = add(r0,##1536)
		if (!p3) jump:nt .LBB3_32
		if (p0) vmemu(r15+#0) = v27
	}
// %bb.27:                              // %if.end.7
	{
		p2 = cmp.gtu(r12,#64)
		v16 = vmemu(r28+#0)
	}
	{
		v18 = vand(v16,v3)
		v17 = vmemu(r15+#0)
	}
	{
		v19.uh = vlsr(v16.uh,r6)
		v20 = vand(v17,v3)
		v15 = vmemu(r5+#0)
	}
	{
		q3 = vand(v15,r4)
		q0 = vand(v15,r7)
		v22.uh = vlsr(v17.uh,r6)
		v21 = vand(v19,v3)
	}
	{
		v21 |= vand(q0,r16)
		v18 |= vand(q3,r16)
		v27 = vand(v22,v3)
		r17 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		q1 = vand(v15,r16)
		q3 = vand(v15,r2)
		r28 = add(r13,#1408)
	}
	{
		v20 |= vand(q1,r16)
		v27 |= vand(q3,r16)
		v23.b = vlut32(v18.b,v6.b,#0)
	}
	{
		r6 = p2
		p2 = r17
		v24.b = vlut32(v21.b,v5.b,#0)
		r17 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		p3 = r17
		v25.b = vlut32(v21.b,v4.b,#0)
		memw(r29+#12) = r6
	}                                       // 4-byte Folded Spill
	{
		v26.b = vlut32(v21.b,v6.b,#0)
	}
	{
		v23.b |= vlut32(v20.b,v2.b,#0)
	}
	{
		v24.b |= vlut32(v20.b,v1.b,#0)
	}
	{
		v25.b |= vlut32(v20.b,v0.b,#0)
	}
	{
		v26.b |= vlut32(v27.b,v2.b,#0)
	}
	{
		v11:10 = vshuff(v24,v23,r1)
	}
	{
		r1 = #2
		v13:12 = vshuff(v26,v25,r1)
	}
	{
		v9:8 = vshuff(v12,v10,r1)
	}
	{
		v13:12 = vshuff(v13,v11,r1)
	}
	{
		if (p1) vmemu(r13+#3) = v8
	}
	{
		r13 = add(r13,#1920)
		if (p2) vmemu(r13+#7) = v12
	}
	{
		r13 = r6
		if (p0) vmemu(r13+#0) = v13
	}
	{
		p3 = r13
		if (!p3.new) jump:t .LBB3_32
		if (p3) vmemu(r28+#0) = v9
	}
// %bb.28:                              // %if.end.8
	{
		r5 = add(r0,#1664)
		r13 = #4
		v28 = vmemu(r5+#0)
	}
	{
		q1 = vand(v28,r2)
		q2 = vand(v28,r8)
		v30 = vmemu(r15+#0)
	}
	{
		q3 = vand(v28,r9)
		r5 = #1
		v29 = vmemu(r5+#0)
	}
	{
		p2 = cmp.gtu(r12,#72)
		if (p2.new) r6 = #4
		v8.uh = vlsr(v30.uh,r13)
		v31 = vand(v29,v3)
	}
	{
		r13 = addasl(r11,r3,#1)
		v31 |= vand(q2,r16)
		v7.uh = vlsr(v29.uh,r13)
		v10 = vand(v8,v3)
	}
	{
		v10 |= vand(q1,r16)
		if (p2) r1 = #1
		v9 = vand(v7,v3)
		r3 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		v9 |= vand(q3,r16)
		v11.b = vlut32(v31.b,v5.b,#0)
		r3 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r28 = add(r0,##1920)
		v12.b = vlut32(v31.b,v4.b,#0)
	}
	{
		if (p2) r15 = add(r0,##2048)
		v13.b = vlut32(v10.b,v4.b,#0)
	}
	{
		v14.b = vlut32(v10.b,v6.b,#0)
	}
	{
		v13.b |= vlut32(v31.b,v0.b,#0)
	}
	{
		v14.b |= vlut32(v9.b,v2.b,#0)
	}
	{
		v11.b |= vlut32(v9.b,v1.b,#0)
	}
	{
		v12.b |= vlut32(v9.b,v0.b,#0)
	}
	{
		v29:28 = vshuff(v14,v13,r5)
	}
	{
		r5 = #2
		v31:30 = vshuff(v12,v11,r5)
	}
	{
		v21:20 = vshuff(v30,v28,r5)
	}
	{
		r5 = add(r13,#1024)
		v29:28 = vshuff(v31,v29,r5)
	}
	{
		if (p1) vmemu(r13+#0) = v20
	}
	{
		p3 = r3
		if (p3) vmemu(r13+#4) = v28
	}
	{
		r5 = add(r5,#512)
		if (p3) vmemu(r5+#0) = v21
	}
	{
		if (p2) r5 = add(r0,##2432)
		if (!p2) jump:nt .LBB3_32
		if (p0) vmemu(r5+#0) = v29
	}
// %bb.29:                              // %if.end.9
	{
		p2 = cmp.gtu(r12,#80)
		v15 = vmemu(r28+#0)
	}
	{
		v17 = vand(v15,v3)
		v16 = vmemu(r5+#0)
	}
	{
		q1 = vand(v16,r10)
		v18.uh = vlsr(v15.uh,r6)
		v19 = vmemu(r15+#0)
	}
	{
		q0 = vand(v16,r14)
		v17 |= vand(q1,r16)
		v20 = vand(v18,v3)
		v24 = vand(v19,v3)
	}
	{
		v20 |= vand(q0,r16)
		q2 = vand(v16,r4)
		r6 = #2
		r3 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		p3 = r3
		v24 |= vand(q2,r16)
		v21.b = vlut32(v17.b,v5.b,#0)
		r3 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		if (p2) r14 = #4
		v22.b = vlut32(v17.b,v4.b,#0)
	}
	{
		v23.b = vlut32(v17.b,v6.b,#0)
	}
	{
		v25.b = vlut32(v20.b,v5.b,#0)
	}
	{
		v21.b |= vlut32(v20.b,v1.b,#0)
	}
	{
		v22.b |= vlut32(v20.b,v0.b,#0)
	}
	{
		v23.b |= vlut32(v24.b,v2.b,#0)
	}
	{
		v25.b |= vlut32(v24.b,v1.b,#0)
	}
	{
		v29:28 = vshuff(v22,v21,r1)
	}
	{
		v31:30 = vshuff(v25,v23,r1)
	}
	{
		v23:22 = vshuff(v30,v28,r6)
	}
	{
		r6 = add(r13,#1152)
		v31:30 = vshuff(v31,v29,r6)
	}
	{
		if (p1) vmemu(r13+#1) = v22
	}
	{
		p3 = r3
		if (p3) vmemu(r13+#5) = v30
	}
	{
		r6 = add(r13,#1664)
		if (p3) vmemu(r6+#0) = v23
	}
	{
		if (p2) r6 = add(r0,##2176)
		if (!p2) jump:nt .LBB3_32
		if (p0) vmemu(r6+#0) = v31
	}
// %bb.30:                              // %if.end.10
	{
		p2 = cmp.gtu(r12,#88)
		if (p2.new) r1 = #4
		v27 = vmemu(r15+#0)
	}
	{
		v29 = vand(v27,v3)
		v28 = vmemu(r6+#0)
	}
	{
		v30.uh = vlsr(v27.uh,r14)
		v31 = vand(v28,v3)
		v26 = vmemu(r5+#0)
	}
	{
		q3 = vand(v26,r4)
		q1 = vand(v26,r7)
		v8.uh = vlsr(v28.uh,r14)
		v7 = vand(v30,v3)
	}
	{
		v7 |= vand(q1,r16)
		v29 |= vand(q3,r16)
		r4 = #1
		v13 = vand(v8,v3)
	}
	{
		q0 = vand(v26,r16)
		q3 = vand(v26,r2)
		r7 = #2
		r3 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		v31 |= vand(q0,r16)
		v13 |= vand(q3,r16)
		v9.b = vlut32(v29.b,v6.b,#0)
	}
	{
		p3 = r3
		v10.b = vlut32(v7.b,v5.b,#0)
		r3 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		v11.b = vlut32(v7.b,v4.b,#0)
	}
	{
		v12.b = vlut32(v7.b,v6.b,#0)
	}
	{
		v9.b |= vlut32(v31.b,v2.b,#0)
	}
	{
		v10.b |= vlut32(v31.b,v1.b,#0)
	}
	{
		v11.b |= vlut32(v31.b,v0.b,#0)
	}
	{
		v12.b |= vlut32(v13.b,v2.b,#0)
	}
	{
		v21:20 = vshuff(v10,v9,r4)
	}
	{
		r4 = add(r13,#1280)
		v23:22 = vshuff(v12,v11,r4)
	}
	{
		v15:14 = vshuff(v23,v21,r7)
	}
	{
		r7 = add(r13,#1792)
		v11:10 = vshuff(v22,v20,r7)
	}
	{
		p3 = r3
		if (p3) vmemu(r13+#6) = v14
	}
	{
		if (p1) vmemu(r13+#2) = v10
	}
	{
		if (p2) r4 = add(r0,##2304)
		if (p3) vmemu(r4+#0) = v11
	}
	{
		if (!p2) jump:nt .LBB3_32
		if (p0) vmemu(r7+#0) = v15
	}
// %bb.31:                              // %if.end.11
	{
		v16 = vmemu(r6+#0)
	}
	{
		r7 = #1
		r0 = #2
		v15 = vmemu(r4+#0)
	}
	{
		v19.uh = vlsr(v16.uh,r1)
		v17 = vand(v15,v3)
		v14 = vmemu(r5+#0)
	}
	{
		q2 = vand(v14,r2)
		q3 = vand(v14,r8)
		v18.uh = vlsr(v15.uh,r1)
		v30 = vand(v19,v3)
	}
	{
		v17 |= vand(q3,r16)
		v30 |= vand(q2,r16)
		v20 = vand(v18,v3)
		r3 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		q0 = vand(v14,r9)
		r2 = add(r13,#1408)
	}
	{
		v20 |= vand(q0,r16)
		v5.b = vlut32(v17.b,v5.b,#0)
	}
	{
		v21.b = vlut32(v17.b,v4.b,#0)
	}
	{
		v31.b = vlut32(v30.b,v4.b,#0)
	}
	{
		v6.b = vlut32(v30.b,v6.b,#0)
	}
	{
		v31.b |= vlut32(v17.b,v0.b,#0)
	}
	{
		v6.b |= vlut32(v20.b,v2.b,#0)
	}
	{
		v5.b |= vlut32(v20.b,v1.b,#0)
	}
	{
		v21.b |= vlut32(v20.b,v0.b,#0)
	}
	{
		v7:6 = vshuff(v6,v31,r7)
	}
	{
		v31:30 = vshuff(v21,v5,r7)
	}
	{
		v3:2 = vshuff(v30,v6,r0)
	}
	{
		v1:0 = vshuff(v31,v7,r0)
		r0 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		p1 = r3
		if (p1) vmemu(r13+#3) = v2
	}
	{
		p1 = r0
		if (p1) vmemu(r13+#7) = v0
	}
	{
		if (p0) r2 = add(r13,##1920)
		if (p1) vmemu(r2+#0) = v3
	}
	{
		if (p0) vmemu(r2+#0) = v1
	}
	.falign
.LBB3_32:                               // %for.end156
	{
		r17:16 = memd(r29+#168)
		r19:18 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#152)
		r23:22 = memd(r29+#144)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#136)
		r27:26 = memd(r29+#128)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end3:
	.size	hvx_tl2_expand_wh96, .Lfunc_end3-hvx_tl2_expand_wh96
                                        // -- End function
	.globl	hvx_tl2_pack                    // -- Begin function hvx_tl2_pack
	.falign
	.type	hvx_tl2_pack,@function
hvx_tl2_pack:                           // @hvx_tl2_pack
// %bb.0:                               // %entry
	{
		r4 = add(r1,##-8421505)
		r5 = ##-8421504
	}
	{
		p0 = cmp.gtu(r5,r4)
		r4 = r0
		memd(r29+#-16) = r17:16
		allocframe(#208)
	}                                       // 8-byte Folded Spill
	{
		r0 = #-1
		if (!p0) r16 = #127
		memd(r29+#192) = r19:18
		memd(r29+#184) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#176) = r23:22
		memd(r29+#168) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB4_20
		memd(r29+#160) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		r16 = add(r2,#127)
		if (!cmp.gtu(r16.new,r16)) jump:nt ##.LBB4_20
	}
// %bb.2:                               // %hvx_tl2_weight_bytes.exit
	{
		p2 = cmp.eq(r4,#0)
		if (p2.new) jump:nt .LBB4_20
	}
// %bb.3:                               // %hvx_tl2_weight_bytes.exit
	{
		r8 = lsr(r2,#7)
		r7:6 = combine(#127,r1)
		p3 = cmp.eq(r3,#0)
		if (p3.new) jump:nt .LBB4_20
	}
// %bb.4:                               // %hvx_tl2_weight_bytes.exit
	{
		p0 = !bitsclr(r2,r7)
		r5 = ##-1431655765
		r9 = #0
	}
	{
		r5 = mpyu(r1,r5)
	}
	{
		r21 = lsr(r5,#4)
		if (p0) r8 = add(r8,#1)
	}
	{
		r6 -= mpyi(r21,#24)
	}
	{
		p1 = cmp.eq(r6,#0)
		if (!p1.new) r21 = add(r21,#1)
	}
	{
		r7:6 = mpyu(r8,r21)
		r8 = ##6710886
	}
	{
		r5 = +mpyi(r6,##640)
		p2 = cmp.gtu(r7:6,r9:8)
	}
	{
		if (p2) r5 = #0
	}
	{
		p3 = cmp.eq(r5,#0)
		if (!p3.new) r7 = add(r4,#0)
		if (p3.new) jump:nt .LBB4_20
	}
// %bb.5:                               // %lor.lhs.false4
	{
		r6 = mpyu(r2,r1)
		if (!cmp.eq(r6.new,#0)) jump:t ##.LBB4_20
	}
// %bb.6:                               // %for.cond.preheader
	{
		r6 = mpyi(r2,r1)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB4_9
	}
	.falign
.LBB4_7:                                // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r8 = memub(r7+#0)
	}
	{
		r8 = add(r8,#-2)
	}
	{
		p3 = cmpb.gtu(r8,##252)
		if (p3.new) r7 = add(r7,#1)
		if (!p3.new) jump:nt .LBB4_20
	}
// %bb.8:                               // %for.cond
                                        //   in Loop: Header=BB4_7 Depth=1
	{
		r6 = add(r6,#-1)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB4_7
	}
	.falign
.LBB4_9:                                // %for.cond21.preheader.lr.ph
	{
		r19:18 = combine(r1,r2)
		r2 = r5
		r17 = r4
		r1:0 = combine(#0,r3)
	}
	{
		call memset
		r20 = r3
	}
	.falign
// %bb.10:                              // %for.cond21.preheader.lr.ph
	{
		r20 = add(r20,#512)
		r0 = #0
		p0 = cmp.eq(r21,#0); if (p0.new) jump:nt .LBB4_20
	}
// %bb.11:                              // %for.cond21.preheader.us.preheader
	{
		r2 = lsr(r16,#7)
		r7:6 = combine(r18,r19)
		r4 = #0
		memw(r29+#28) = r17
	}                                       // 4-byte Folded Spill
	{
		r0 = +mpyi(r21,##640)
		memw(r29+#152) = r2
		memw(r29+#148) = r21
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#156) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_12:                               // %for.cond21.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB4_13 Depth 2
                                        //       Child Loop BB4_14 Depth 3
	{
		loop1(.LBB4_13,r21)
		r9 = asl(r4,#7)
		r2 = #0
		memw(r29+#144) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#140) = r20
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_13:                               // Block address taken
                                        // %for.body26.us
                                        //   Parent Loop BB4_12 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB4_14 Depth 3
	{
		loop0(##.LBB4_14,#128)
		r11 = +mpyi(r2,#24)
		memw(r29+#132) = r2
	}                                       // 4-byte Folded Spill
	{
		r10 = setbit(r11,#1)
		r0 = setbit(r11,#0)
		r2 = or(r11,#3)
		memw(r29+#128) = r20
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r2,r7)
		r5 = mpyi(r10,r7)
		r8 = add(r11,#8)
		memw(r29+#4) = r2
	}                                       // 4-byte Folded Spill
	{
		r4 = mpyi(r11,r7)
		r22 = add(r11,#16)
		r23 = add(r11,#17)
		memw(r29+#44) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = or(r11,#6)
		r5 = or(r11,#7)
		memw(r29+#40) = r5
		memw(r29+#24) = r8
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r2,r7)
		r14 = add(r11,#9)
		r12 = add(r11,#18)
		memw(r29+#16) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r5,r7)
		r3 = or(r11,#5)
		r15 = add(r11,#10)
		memw(r29+#56) = r2
	}                                       // 4-byte Folded Spill
	{
		r4 = mpyi(r0,r7)
		r2 = add(r11,#19)
		memw(r29+#60) = r2
		memw(r29+#32) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r8,r7)
		r8 = mpyi(r22,r7)
		memw(r29+#136) = r2
		memw(r29+#36) = r4
	}                                       // 4-byte Folded Spill
	{
		r8 = mpyi(r23,r7)
		r4 = setbit(r11,#2)
		r18 = add(r11,#13)
		memw(r29+#96) = r8
	}                                       // 4-byte Folded Spill
	{
		r4 = mpyi(r4,r7)
		r1 = add(r11,#11)
		r19 = add(r11,#14)
		memw(r29+#12) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r14,r7)
		r8 = mpyi(r12,r7)
		memw(r29+#64) = r2
		memw(r29+#100) = r8
	}                                       // 4-byte Folded Spill
	{
		r25:24 = combine(r14,r12)
		r17 = add(r11,#12)
		r21 = add(r11,#15)
		r12 = memw(r29+#136)
	}                                       // 4-byte Folded Reload
	{
		r3 = mpyi(r3,r7)
		r16 = r19
		memw(r29+#48) = r4
		memw(r29+#8) = r3
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r15,r7)
		r4 = mpyi(r18,r7)
		p0 = cmp.gtu(r6,r0)
		memw(r29+#68) = r2
	}                                       // 4-byte Folded Spill
	{
		r3 = mpyi(r17,r7)
		p1 = cmp.gtu(r6,r10)
		memw(r29+#52) = r3
		memw(r29+#20) = r5
	}                                       // 4-byte Folded Spill
	{
		r2 = mpyi(r1,r7)
		r4 = mpyi(r19,r7)
		memw(r29+#72) = r2
		memw(r29+#84) = r4
	}                                       // 4-byte Folded Spill
	{
		r5 = mpyi(r21,r7)
		r8 = mpyi(r12,r7)
		r28 = add(r11,#20)
		memw(r29+#104) = r8
	}                                       // 4-byte Folded Spill
	{
		r8 = mpyi(r28,r7)
		r0 = add(r11,#21)
		r27:26 = combine(r1,r15)
		memw(r29+#108) = r8
	}                                       // 4-byte Folded Spill
	{
		r10 = add(r11,#22)
		p2 = cmp.gtu(r6,r11)
		r11 = add(r11,#23)
		r13 = r23
	}
	{
		r3:2 = combine(r18,r17)
		memw(r29+#76) = r2
		memw(r29+#80) = r3
	}                                       // 4-byte Folded Spill
	{
		r5:4 = combine(r22,r21)
		memw(r29+#88) = r4
		memw(r29+#92) = r5
	}                                       // 4-byte Folded Spill
	{
		r8 = mpyi(r0,r7)
		r19 = #0
		r21 = #0
		memw(r29+#112) = r8
	}                                       // 4-byte Folded Spill
	{
		r8 = mpyi(r10,r7)
		memw(r29+#116) = r8
	}                                       // 4-byte Folded Spill
	{
		r8 = mpyi(r11,r7)
		memw(r29+#120) = r8
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#124) = r8
	}                                       // 4-byte Folded Spill
	.falign
.LBB4_14:                               // Block address taken
                                        // %for.body35.us
                                        //   Parent Loop BB4_12 Depth=1
                                        //     Parent Loop BB4_13 Depth=2
                                        // =>    This Inner Loop Header: Depth=3
	{
		r8 = r19
	}
	{
		r8 = or(r9,and(r8,#96))
	}
	{
		r8 += lsr(r21,#2)
		if (!cmp.gtu(r7,r8.new)) jump:t .LBB4_16
	}
// %bb.15:                              // %for.body50.us184.us
                                        //   in Loop: Header=BB4_14 Depth=3
	{
		r15 = #0
		r1 = #0
		r18 = #0
		r14 = memw(r29+#28)
	}                                       // 4-byte Folded Reload
	{
		r22 = add(r14,r8)
		r8 = #0
		if (p2) r14 = memw(r29+#32)
		if (p1) r1 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		if (p0) r8 = memw(r29+#36)
		r17 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		r14 = #0
		p3 = cmp.gtu(r6,r17)
		if (p2) r15 = memb(r22+r14<<#0)
		if (p1) r1 = memb(r22+r1<<#0)
	}
	{
		if (p0) r8 = memb(r22+r8<<#0)
		if (p3) r14 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	{
		r15 = +mpyi(r15,#3)
	}
	{
		r8 = add(r8,r15)
	}
	{
		r8 = +mpyi(r8,#3)
	}
	{
		r15 = add(r1,r8)
		r1 = memub(r20+#-512)
		r8 = memub(r20+#0)
	}
	{
		r17 = abs(r15)
		r8 |= lsr(r15,#31)
	}
	{
		r15 = or(r1,r17)
		memb(r20+#0) = r8
	}
	{
		r17 = #0
		r1 = memw(r29+#12)
		memb(r20+#-512) = r15
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r6,r1)
		if (p3) r14 = memb(r22+r14<<#0)
		if (p3.new) r1 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r23 = +mpyi(r14,#3)
		if (p3) r18 = memb(r22+r1<<#0)
		r1 = memw(r29+#8)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r6,r1)
		r18 = add(r18,r23)
		if (p3.new) r1 = memw(r29+#52)
		r14 = memw(r29+#16)
	}                                       // 4-byte Folded Reload
	{
		r18 = +mpyi(r18,#3)
	}
	{
		p3 = cmp.gtu(r6,r14)
		r1 = #0
		r14 = #0
		if (p3) r17 = memb(r22+r1<<#0)
	}
	{
		r17 = add(r17,r18)
	}
	{
		r18 = abs(r17)
		r17 = lsr(r17,#30)
	}
	{
		r17 = or(r8,and(r17,#2))
		r15 |= asl(r18,#4)
		if (p3) r8 = memw(r29+#56)
		memb(r20+#-512) = r15.new
	}                                       // 4-byte Folded Reload
	{
		r15 = #0
		r17 = #0
		memb(r20+#0) = r17
	}
	{
		if (p3) r1 = memb(r22+r8<<#0)
		r8 = memw(r29+#20)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r6,r8)
		if (p3.new) r8 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	{
		r1 = +mpyi(r1,#3)
	}
	{
		if (p3) r14 = memb(r22+r8<<#0)
		r8 = memw(r29+#24)
	}                                       // 4-byte Folded Reload
	{
		p3 = cmp.gtu(r6,r8)
		r14 = add(r14,r1)
		r8 = #0
		if (p3.new) r15 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		r14 = +mpyi(r14,#3)
	}
	{
		p3 = cmp.gtu(r6,r25)
		if (p3) r15 = memb(r22+r15<<#0)
	}
	{
		r15 = add(r15,r14)
		r14 = add(r20,#-384)
		if (p3) r8 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	{
		r1 = abs(r15)
		r15 = and(#4,lsr(r15,#29))
	}
	{
		r1 = #0
		memb(r14+#0) |= r1
	}
	{
		memb(r20+#0) |= r15
	}
	{
		p3 = cmp.gtu(r6,r26)
		if (p3) r8 = memb(r22+r8<<#0)
		if (p3.new) r15 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r8 = +mpyi(r8,#3)
		p3 = cmp.gtu(r6,r27)
		if (p3) r17 = memb(r22+r15<<#0)
		if (p3.new) r15 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(r17,r8)
	}
	{
		r8 = +mpyi(r8,#3)
		p3 = cmp.gtu(r6,r2)
		r15 = #0
		if (p3) r1 = memb(r22+r15<<#0)
	}
	{
		r8 = add(r1,r8)
	}
	{
		r1 = abs(r8)
		r8 = and(#8,lsr(r8,#28))
	}
	{
		r17 = asl(r1,#4)
		r1 = #0
		if (p3) r8 = memw(r29+#80)
		memb(r20+#0) |= r8
	}                                       // 4-byte Folded Reload
	{
		r14 = #0
		r17 = #0
		memb(r14+#0) |= r17
	}
	{
		p3 = cmp.gtu(r6,r3)
		if (p3) r1 = memb(r22+r8<<#0)
		if (p3.new) r8 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r1 = +mpyi(r1,#3)
		p3 = cmp.gtu(r6,r16)
		r8 = #0
		if (p3) r15 = memb(r22+r8<<#0)
	}
	{
		r15 = add(r15,r1)
		if (p3) r14 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		r15 = +mpyi(r15,#3)
	}
	{
		p3 = cmp.gtu(r6,r4)
		if (p3) r14 = memb(r22+r14<<#0)
	}
	{
		r15 = add(r14,r15)
		r14 = add(r20,#-256)
		if (p3) r8 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r1 = abs(r15)
		r15 = and(#16,lsr(r15,#27))
	}
	{
		r1 = #0
		memb(r14+#0) |= r1
	}
	{
		memb(r20+#0) |= r15
	}
	{
		p3 = cmp.gtu(r6,r5)
		if (p3) r8 = memb(r22+r8<<#0)
		if (p3.new) r15 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		r8 = +mpyi(r8,#3)
		p3 = cmp.gtu(r6,r13)
		if (p3) r17 = memb(r22+r15<<#0)
		if (p3.new) r15 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(r17,r8)
	}
	{
		r8 = +mpyi(r8,#3)
		p3 = cmp.gtu(r6,r24)
		r15 = #0
		if (p3) r1 = memb(r22+r15<<#0)
	}
	{
		r8 = add(r1,r8)
	}
	{
		r1 = abs(r8)
		r8 = and(#32,lsr(r8,#26))
	}
	{
		r17 = asl(r1,#4)
		r1 = #0
		if (p3) r8 = memw(r29+#104)
		memb(r20+#0) |= r8
	}                                       // 4-byte Folded Reload
	{
		r14 = #0
		memb(r14+#0) |= r17
	}
	{
		p3 = cmp.gtu(r6,r12)
		if (p3) r1 = memb(r22+r8<<#0)
		if (p3.new) r8 = memw(r29+#108)
	}                                       // 4-byte Folded Reload
	{
		r1 = +mpyi(r1,#3)
		p3 = cmp.gtu(r6,r28)
		r8 = #0
		if (p3) r15 = memb(r22+r8<<#0)
	}
	{
		r15 = add(r15,r1)
		if (p3) r14 = memw(r29+#112)
	}                                       // 4-byte Folded Reload
	{
		r15 = +mpyi(r15,#3)
	}
	{
		p3 = cmp.gtu(r6,r0)
		if (p3) r14 = memb(r22+r14<<#0)
	}
	{
		r15 = add(r14,r15)
		r14 = add(r20,#-128)
		if (p3) r8 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r1 = abs(r15)
		r15 = and(#64,lsr(r15,#25))
	}
	{
		r15 = #0
		memb(r20+#0) |= r15
	}
	{
		r1 = #0
		memb(r14+#0) |= r1
	}
	{
		p3 = cmp.gtu(r6,r10)
		if (p3) r8 = memb(r22+r8<<#0)
		if (p3.new) r1 = memw(r29+#120)
	}                                       // 4-byte Folded Reload
	{
		r8 = +mpyi(r8,#3)
		p3 = cmp.gtu(r6,r11)
		if (p3) r1 = memb(r22+r1<<#0)
		if (p3.new) r15 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		r8 = add(r1,r8)
	}
	{
		r8 = +mpyi(r8,#3)
		if (p3) r15 = memb(r22+r15<<#0)
	}
	{
		r8 = add(r15,r8)
	}
	{
		r15 = abs(r8)
		r8 = and(#128,lsr(r8,#24))
	}
	{
		r15 = asl(r15,#4)
		memb(r20+#0) |= r8
	}
	{
		memb(r14+#0) |= r15
	}
	.falign
.LBB4_16:                               // %for.cond.cleanup44.us
                                        //   in Loop: Header=BB4_14 Depth=3
	{
		r19 = add(r19,#32)
		r21 = add(r21,#1)
		r20 = add(r20,#1)
	} :endloop0
// %bb.17:                              // %for.cond.cleanup34.us
                                        //   in Loop: Header=BB4_13 Depth=2
	{
		r2 = memw(r29+#132)
		r20 = memw(r29+#128)
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r2,#1)
		r20 = add(r20,#640)
		nop
	} :endloop1
// %bb.18:                              // %for.cond21.for.cond.cleanup25_crit_edge.us
                                        //   in Loop: Header=BB4_12 Depth=1
	{
		r4 = memw(r29+#144)
		r2 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,#1)
		r0 = memw(r29+#156)
		r20 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	{
		r20 = add(r20,r0)
		p1 = cmp.eq(r4,r2); if (!p1.new) jump:t .LBB4_12
		r21 = memw(r29+#148)
	}                                       // 4-byte Folded Reload
// %bb.19:
	{
		r0 = #0
	}
	.falign
.LBB4_20:                               // %cleanup107
	{
		r17:16 = memd(r29+#200)
		r19:18 = memd(r29+#192)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#184)
		r23:22 = memd(r29+#176)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#168)
		r27:26 = memd(r29+#160)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
.Lfunc_end4:
	.size	hvx_tl2_pack, .Lfunc_end4-hvx_tl2_pack
                                        // -- End function
	.globl	hvx_tl2_unpack                  // -- Begin function hvx_tl2_unpack
	.falign
	.type	hvx_tl2_unpack,@function
hvx_tl2_unpack:                         // @hvx_tl2_unpack
// %bb.0:                               // %entry
	{
		p0 = cmp.eq(r0,#0)
		if (!p0.new) r4 = #-1
		memd(r29+#-16) = r17:16
		allocframe(#64)
	}                                       // 8-byte Folded Spill
	{
		if (p0) r4 = #-1
		memd(r29+#48) = r19:18
		memd(r29+#40) = r21:20
	}                                       // 8-byte Folded Spill
	{
		memd(r29+#32) = r23:22
		memd(r29+#24) = r25:24
	}                                       // 8-byte Folded Spill
	{
		if (p0) jump:nt .LBB5_53
		memd(r29+#16) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		if (!p1.new) r4 = add(r1,##-8421505)
		p1 = cmp.eq(r3,#0); if (p1.new) jump:nt .LBB5_53
	}
// %bb.2:                               // %lor.lhs.false2
	{
		r5 = ##-8421504
		if (cmp.gtu(r5.new,r4)) jump:nt .LBB5_11
	}
// %bb.3:                               // %lor.lhs.false2
	{
		r4 = #127
	}
	{
		r4 = add(r2,#127)
		if (!cmp.gtu(r4.new,r4)) jump:nt .LBB5_10
	}
// %bb.4:                               // %if.end.i
	{
		r8 = lsr(r2,#7)
		r5 = ##-1431655765
		r7:6 = combine(#127,r1)
	}
	{
		r5 = mpyu(r1,r5)
		p0 = !bitsclr(r2,r7)
		r12 = ##6710886
	}
	{
		r5 = lsr(r5,#4)
		r13 = #0
		if (p0) r8 = add(r8,#1)
	}
	{
		r6 -= mpyi(r5,#24)
	}
	{
		p1 = cmp.eq(r6,#0)
		if (!p1.new) r5 = add(r5,#1)
	}
	{
		r7:6 = mpyu(r8,r5)
	}
	{
		p0 = cmp.gtu(r7:6,r13:12)
		if (p0.new) r4 = #-1
		if (p0.new) jump:nt .LBB5_53
	}
// %bb.5:                               // %if.end.i
	{
		r6 = +mpyi(r6,##640)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB5_12
	}
// %bb.6:                               // %lor.lhs.false4
	{
		r6 = mpyu(r2,r1)
		if (cmp.eq(r6.new,#0)) jump:t .LBB5_14
	}
// %bb.7:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_10:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_11:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_12:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_14:                               // %for.cond7.preheader.lr.ph
	{
		r8 = +mpyi(r2,#3)
		r15 = add(r3,r2)
		p1 = cmp.eq(r5,#0); if (p1.new) jump:nt .LBB5_50
	}
// %bb.15:                              // %for.cond7.preheader.us.preheader
	{
		r4 = lsr(r4,#7)
		r13:12 = combine(#1,#0)
		memw(r29+#12) = r15
	}                                       // 4-byte Folded Spill
	{
		r4 = +mpyi(r2,#24)
		memw(r29+#8) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#4) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB5_16:                               // %for.cond7.preheader.us
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB5_17 Depth 2
                                        //       Child Loop BB5_18 Depth 3
                                        //         Child Loop BB5_19 Depth 4
	{
		r4 = mpyi(r12,r5)
		r14 = asl(r12,#7)
		r28 = r3
		r11:10 = combine(#0,#0)
	}
	.falign
.LBB5_17:                               // %for.body11.us
                                        //   Parent Loop BB5_16 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB5_18 Depth 3
                                        //         Child Loop BB5_19 Depth 4
	{
		r17 = +mpyi(r11,#24)
		r6 = add(r11,r4)
		r18 = #0
		r16 = r0
	}
	{
		loop1(.LBB5_18,#128)
		r16 += mpyi(r6,##640)
	}
	.falign
.LBB5_18:                               // Block address taken
                                        // %for.body18.us
                                        //   Parent Loop BB5_16 Depth=1
                                        //     Parent Loop BB5_17 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB5_19 Depth 4
	{
		r20 = add(r16,add(r18,##512))
		r19 = r14
		r21 = #0
	}
	{
		loop0(.LBB5_19,#8)
		r19 = insert(r18,#2,#5)
		r23:22 = combine(r10,#0)
		r24 = #0
	}
	{
		r19 += lsr(r18,#2)
	}
	{
		r25 = add(r28,r19)
		r26 = add(r15,r19)
		p0 = cmp.gtu(r2,r19)
	}
	.falign
.LBB5_19:                               // Block address taken
                                        // %for.body27.us
                                        //   Parent Loop BB5_16 Depth=1
                                        //     Parent Loop BB5_17 Depth=2
                                        //       Parent Loop BB5_18 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r7:6 = combine(r21,#15)
		r27 = and(r22,#4)
	}
	{
		r7 = or(r18,and(r7,#384))
	}
	{
		r7 = memub(r16+r7<<#0)
	}
	{
		r6 &= lsr(r7,r27)
		if (cmp.gtu(r6.new,#13)) jump:nt .LBB5_51
	}
// %bb.20:                              // %lor.lhs.false40.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r6,#0)
		r7 = memub(r20+#0)
	}
	{
		r7 &= asl(r13,r24)
	}
	{
		p1 = cmp.eq(r7,#0)
		if (!p2) jump:nt .LBB5_22
	}
// %bb.21:                              // %lor.lhs.false40.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p1) r4 = #-1
		if (!p1) jump:nt .LBB5_53
	}
	.falign
.LBB5_22:                               // %if.end44.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r6 = add(r6,#13)
	}
	{
		r7 = +mpyi(r6,#29)
		r27 = and(r6,#255)
	}
	{
		r27 = +mpyi(r27,#171)
		r7 = add(##-1,lsr(r7,#8))
	}
	{
		r27 = lsr(r27,#9)
	}
	{
		r9 = +mpyi(r27,#86)
		r6 -= mpyi(r27,#3)
	}
	{
		r9 = lsr(r9,#8)
		r6 = and(r6,#255)
	}
	{
		r27 -= mpyi(r9,#3)
	}
	{
		r9 = and(r27,#255)
		r27 = add(r6,#-1)
	}
	{
		if (p1) jump:nt .LBB5_30
		if (!p0) jump:nt .LBB5_38
		r6 = add(r9,#-1)
	}
// %bb.24:                              // %for.body52.us.us256
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r9 = sub(#0,r7)
		p1 = cmp.gtu(r1,r23); if (p1.new) jump:t .LBB5_26
		if (p1.new) memb(r25+#0) = r9.new
	}
// %bb.25:                              // %if.else.us.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r7,#0)
		if (!p2.new) r4 = #-1
		if (!p2.new) jump:nt .LBB5_53
	}
	.falign
.LBB5_26:                               // %for.inc.us.us261
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r7 = add(r23,#1)
	}
	{
		r7 = sub(#0,r6)
		p1 = cmp.gtu(r1,r7); if (p1.new) jump:t .LBB5_28
		if (p1.new) memb(r26+#0) = r7.new
	}
// %bb.27:                              // %if.else.us.us.1
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r6,#0)
		if (!p2.new) r4 = #-1
		if (!p2.new) jump:nt .LBB5_53
	}
	.falign
.LBB5_28:                               // %for.inc.us.us261.1
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r6 = add(r23,#2)
		if (!cmp.gtu(r1,r6.new)) jump:t .LBB5_44
	}
// %bb.29:                              //   in Loop: Header=BB5_19 Depth=4
	{
		r27 = sub(#0,r27)
		jump .LBB5_37
	}
	.falign
.LBB5_30:                               // %if.end44.split.us255
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p0) jump:nt .LBB5_41
	}
// %bb.31:                              // %for.body52.us241.preheader
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.gtu(r1,r23)
		if (p2.new) jump:t .LBB5_33
		if (p2.new) memb(r25+#0) = r7
	}
// %bb.32:                              // %if.else.us246
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p1.new) r4 = #-1
		p1 = cmp.eq(r7,#0); if (!p1.new) jump:nt .LBB5_53
	}
	.falign
.LBB5_33:                               // %for.inc.us252
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r7 = add(r23,#1)
	}
	{
		p2 = cmp.gtu(r1,r7)
		if (p2.new) jump:t .LBB5_35
		if (p2.new) memb(r26+#0) = r6
	}
// %bb.34:                              // %if.else.us246.1
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p1.new) r4 = #-1
		p1 = cmp.eq(r6,#0); if (!p1.new) jump:nt .LBB5_53
	}
	.falign
.LBB5_35:                               // %for.inc.us252.1
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r6 = add(r23,#2)
		if (!cmp.gtu(r1,r6.new)) jump:t .LBB5_45
	}
// %bb.36:                              //   in Loop: Header=BB5_19 Depth=4
	{
		r6 = r17
	}
	{
		r6 += mpyi(r24,#3)
	}
	{
		r6 = add(r6,#2)
	}
	.falign
.LBB5_37:                               // %for.inc82.us.sink.split
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r6 = mpyi(r6,r2)
		r7 = add(r3,r19)
	}
	{
		jump .LBB5_46
		memb(r7+r6<<#0) = r27
	}
	.falign
.LBB5_38:                               // %for.body52.us.us.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r7,#0)
		if (!p2.new) r4 = #-1
		if (!p2.new) jump:nt .LBB5_53
	}
// %bb.39:                              // %for.body52.us.us.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p1.new) r4 = #-1
		p1 = cmp.eq(r6,#0); if (!p1.new) jump:nt .LBB5_53
	}
// %bb.40:                              // %for.body52.us.us.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r27,#0)
		if (p2.new) jump:t .LBB5_46
	}
	{
		jump .LBB5_55
	}
	.falign
.LBB5_41:                               // %for.body52.us223.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		if (!p1.new) r4 = #-1
		p1 = cmp.eq(r7,#0); if (!p1.new) jump:nt .LBB5_53
	}
// %bb.42:                              // %for.body52.us223.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r6,#0)
		if (!p2.new) r4 = #-1
		if (!p2.new) jump:nt .LBB5_53
	}
// %bb.43:                              // %for.body52.us223.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p1 = cmp.eq(r27,#0)
		if (p1.new) jump:t .LBB5_46
	}
	{
		jump .LBB5_58
	}
	.falign
.LBB5_44:                               // %if.else.us.us.2
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p2 = cmp.eq(r27,#0)
		if (p2.new) jump:t .LBB5_46
	}
	{
		jump .LBB5_57
	}
	.falign
.LBB5_45:                               // %if.else.us246.2
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		p1 = cmp.eq(r27,#0)
		if (!p1.new) r4 = #-1
		if (!p1.new) jump:nt .LBB5_53
	}
	.falign
.LBB5_46:                               // %for.inc82.us
                                        //   in Loop: Header=BB5_19 Depth=4
	{
		r24 = add(r24,#1)
		r21 = add(r21,#64)
		r23 = add(r23,#3)
		r22 = add(r22,#4)
	}
	{
		r25 = add(r25,r8)
		r26 = add(r26,r8)
	} :endloop0
// %bb.47:                              // %for.inc90.us
                                        //   in Loop: Header=BB5_18 Depth=3
	{
		r18 = add(r18,#1)
		nop
		nop
	} :endloop1
// %bb.48:                              // %for.inc98.us
                                        //   in Loop: Header=BB5_17 Depth=2
	{
		r11 = add(r11,#1)
		r10 = add(r10,#24)
		r6 = memw(r29+#4)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r11,r5)
		r28 = add(r28,r6)
		r15 = add(r15,r6)
		if (!p0.new) jump:t .LBB5_17
	}
// %bb.49:                              // %for.cond7.for.inc103_crit_edge.us
                                        //   in Loop: Header=BB5_16 Depth=1
	{
		r12 = add(r12,#1)
		r4 = memw(r29+#8)
		r15 = memw(r29+#12)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r12,r4)
		r4 = #0
		if (!p0.new) jump:t .LBB5_16
	}
	{
		jump .LBB5_53
	}
	.falign
.LBB5_50:
	{
		r4 = #0 ; jump .LBB5_53
	}
	.falign
.LBB5_51:
	{
		r4 = #-1
	}
	.falign
.LBB5_53:                               // %return
	{
		r0 = r4
		r17:16 = memd(r29+#56)
		r19:18 = memd(r29+#48)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#40)
		r23:22 = memd(r29+#32)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#24)
		r27:26 = memd(r29+#16)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB5_55:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_57:
	{
		r4 = #-1
		jump .LBB5_53
	}
	.falign
.LBB5_58:
	{
		r4 = #-1
		jump .LBB5_53
	}
.Lfunc_end5:
	.size	hvx_tl2_unpack, .Lfunc_end5-hvx_tl2_unpack
                                        // -- End function
	.globl	hvx_tl2_prepare                 // -- Begin function hvx_tl2_prepare
	.falign
	.type	hvx_tl2_prepare,@function
hvx_tl2_prepare:                        // @hvx_tl2_prepare
// %bb.0:                               // %entry
	{
		r6 = add(pc,##tl2_digits@PCREL)
		p0 = cmp.gtu(r1,#127)
		r7 = #64
	}
	{
		r5 = #0
		if (p0) r8 = ##-1431655765
		if (!p0) jump:nt .LBB6_2
	}
// %bb.1:                               // %cond.false
	{
		r5 = add(r1,#-128)
	}
	{
		r5 = mpyu(r5,r8)
	}
	{
		r5 = add(#1,lsr(r5,#4))
	}
	.falign
.LBB6_2:                                // %cond.end
	{
		r5 = minu(r5,r3)
		q0 = vsetq(r7)
		v0 = vmem(r6+#0)
	}
	{
		p1 = cmp.gtu(r5,r2)
		if (p1.new) r7 = ##536879104
		v1 = vmem(r6+#1)
	}
	{
		if (p1) r8 = ##537075715
		if (!p1) jump:nt .LBB6_6
		v2 = vmem(r6+#2)
	}
// %bb.3:                               // %if.then
	{
		r9 = ##16843009
		r12 = ##33686018
	}
	{
		v15 = vsplat(r7)
		v16 = vsplat(r8)
		r15 = sub(r5,r2)
		r7:6 = combine(#0,r0)
	}
	{
		r11 = ##101058054
		r13 = ##202116108
	}
	{
		v20 = vsplat(r7)
		v18 = vsplat(r9)
		v17 = vmux(q0,v15,v16)
	}
	{
		v19 = vsplat(r12)
		v21 = vsplat(r11)
		r7 = ##303174162
	}
	{
		v22 = vsplat(r13)
		v23 = vsplat(r7)
		v24.b = vadd(v17.b,v18.b)
		v25.b = vadd(v17.b,v19.b)
	}
	{
		v3.b = vadd(v17.b,v20.b)
		v4.b = vadd(v17.b,v21.b)
		v5.b = vadd(v24.b,v20.b)
		v6.b = vadd(v24.b,v21.b)
	}
	{
		v7.b = vadd(v17.b,v22.b)
		v8.b = vadd(v17.b,v23.b)
		v9.b = vadd(v25.b,v20.b)
		v10.b = vadd(v25.b,v21.b)
	}
	{
		v11.b = vadd(v24.b,v22.b)
		v12.b = vadd(v25.b,v22.b)
		v13.b = vadd(v24.b,v23.b)
		v14.b = vadd(v25.b,v23.b)
	}
	{
		r6 += mpyi(r2,#24)
		r14 = asl(r2,#9)
	}
	{
		r7 = add(r14,add(r4,##256))
	}
	{
		loop0(.LBB6_4,r15)
	}
	.falign
.LBB6_4:                                // Block address taken
                                        // %do.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r6 = add(r6,#24)
		v26 = vmemu(r6+#0)
	}
	{
		v17:16.uh = vunpack(v26.ub)
	}
	{
		v27.b = vlut32(v3.b,v16.b,#0)
	}
	{
		v28.b = vlut32(v7.b,v16.b,#0)
	}
	{
		v15.h = vmpyi(v27.h,v0.h)
		v31.b = vlut32(v4.b,v16.b,#0)
	}
	{
		v18.h = vmpyi(v28.h,v0.h)
		v22.b = vlut32(v8.b,v16.b,#0)
	}
	{
		v20.h = vmpyi(v31.h,v0.h)
		v29.b = vlut32(v5.b,v16.b,#0)
	}
	{
		v25.h = vmpyi(v22.h,v0.h)
		v17.b = vlut32(v11.b,v16.b,#0)
	}
	{
		v15.h += vmpyi(v29.h,v1.h)
		v21.b = vlut32(v6.b,v16.b,#0)
	}
	{
		v18.h += vmpyi(v17.h,v1.h)
		v24.b = vlut32(v13.b,v16.b,#0)
	}
	{
		v20.h += vmpyi(v21.h,v1.h)
		v30.b = vlut32(v9.b,v16.b,#0)
	}
	{
		v25.h += vmpyi(v24.h,v1.h)
		v19.b = vlut32(v12.b,v16.b,#0)
	}
	{
		v15.h += vmpyi(v30.h,v2.h)
		v23.b = vlut32(v10.b,v16.b,#0)
		vmem(r7+#-2) = v15.new
	}
	{
		v18.h += vmpyi(v19.h,v2.h)
		v16.b = vlut32(v14.b,v16.b,#0)
		vmem(r7+#0) = v18.new
	}
	{
		v20.h += vmpyi(v23.h,v2.h)
		vmem(r7+#-1) = v20.new
	}
	{
		v25.h += vmpyi(v16.h,v2.h)
		r7 = add(r7,#512)
		vmem(r7+#1) = v25.new
	} :endloop0
// %bb.5:
	{
		r2 = r5
	}
	.falign
.LBB6_6:                                // %if.end
	{
		r5 = +mpyi(r2,#24)
		r7 = asl(r2,#9)
		p0 = cmp.gtu(r3,r2); if (!p0.new) jump:t .LBB6_9
	}
// %bb.7:                               // %for.cond20.preheader.lr.ph
	{
		r6 = sub(r3,r2)
	}
	{
		r2 = add(r5,add(r0,#11))
		r4 = add(r7,add(r4,##256))
		r3 = add(r5,#23)
	}
	{
		loop0(.LBB6_8,r6)
	}
	.falign
.LBB6_8:                                // Block address taken
                                        // %for.cond20.preheader
                                        // =>This Inner Loop Header: Depth=1
	{
		r5 = add(r3,#-23)
		r7 = add(r3,#-22)
		r6 = #0
		r9 = add(r3,#-20)
	}
	{
		p1 = cmp.gtu(r1,r5)
		p0 = cmp.gtu(r1,r7)
		r5 = #0
		r7 = add(r3,#-21)
	}
	{
		p1 = cmp.gtu(r1,r7)
		r8 = #0
		if (p1) r6 = memub(r2+##-11)
	}
	{
		r7 = #0
		p0 = cmp.gtu(r1,r9)
		if (p0) r5 = memub(r2+##-10)
	}
	{
		r11 = add(r3,#-19)
		r12 = #0
		if (p1) r7 = memub(r2+##-9)
	}
	{
		p1 = cmp.gtu(r1,r11)
		r13 = add(r3,#-18)
		if (p0) r8 = memub(r2+##-8)
	}
	{
		p0 = cmp.gtu(r1,r13)
		r9 = #0
		if (p1) r12 = memub(r2+##-7)
	}
	{
		v3.h = vsplat(r6)
		v4.h = vsplat(r8)
		if (p0) r9 = memub(r2+##-6)
	}
	{
		v5.h = vsplat(r5)
		v6.h = vsplat(r12)
		r6 = add(r3,#-17)
		v7 = vmux(q0,v3,v4)
	}
	{
		v8.h = vsplat(r7)
		v10.h = vsplat(r9)
		p1 = cmp.gtu(r1,r6)
		v9 = vmux(q0,v5,v6)
	}
	{
		v12.h = vmpyi(v7.h,v0.h)
		r7 = add(r3,#-16)
		r6 = #0
		v11 = vmux(q0,v8,v10)
	}
	{
		v12.h += vmpyi(v9.h,v1.h)
		p0 = cmp.gtu(r1,r7)
		r5 = #0
		r7 = add(r3,#-15)
	}
	{
		v12.h += vmpyi(v11.h,v2.h)
		r12 = add(r3,#-14)
		r8 = #0
		vmem(r4+#-2) = v12.new
	}
	{
		r13 = add(r3,#-13)
		r14 = add(r3,#-12)
		if (p1) r6 = memub(r2+##-5)
	}
	{
		r15 = add(r3,#-8)
		p1 = cmp.gtu(r1,r7)
		r7 = #0
		r9 = #0
	}
	{
		p0 = cmp.gtu(r1,r12)
		r12 = #0
		if (p0) r5 = memub(r2+##-4)
	}
	{
		v13.h = vsplat(r6)
		p1 = cmp.gtu(r1,r13)
		if (p1) r7 = memub(r2+##-3)
	}
	{
		v26.h = vsplat(r5)
		r6 = add(r3,#-11)
		if (p0) r8 = memub(r2+##-2)
	}
	{
		v29.h = vsplat(r7)
		r5 = #0
		p0 = cmp.gtu(r1,r14)
		r7 = add(r3,#-10)
	}
	{
		v14.h = vsplat(r8)
		p1 = cmp.gtu(r1,r6)
		if (p1) r12 = memub(r2+##-1)
	}
	{
		v27.h = vsplat(r12)
		r6 = #0
		v28 = vmux(q0,v13,v14)
		if (p0) r9 = memub(r2+#0)
	}
	{
		v31.h = vsplat(r9)
		r8 = #0
		p0 = cmp.gtu(r1,r7)
		v30 = vmux(q0,v26,v27)
	}
	{
		v17.h = vmpyi(v28.h,v0.h)
		r9 = #0
		r10 = add(r3,#-7)
		v15 = vmux(q0,v29,v31)
	}
	{
		v17.h += vmpyi(v30.h,v1.h)
		r12 = #0
		r7 = add(r3,#-9)
		r11 = add(r3,#-6)
	}
	{
		v17.h += vmpyi(v15.h,v2.h)
		r14 = add(r3,#-2)
	}
	{
		vmem(r4+#-1) = v17
	}
	{
		p1 = cmp.gtu(r1,r7)
		r7 = #0
		if (p1) r6 = memub(r2+#1)
		if (p0) r5 = memub(r2+#2)
	}
	{
		v18.h = vsplat(r6)
		p0 = cmp.gtu(r1,r15)
		r6 = add(r3,#-5)
		if (p1) r7 = memub(r2+#3)
	}
	{
		v20.h = vsplat(r5)
		p1 = cmp.gtu(r1,r10)
		r5 = #0
		if (p0) r8 = memub(r2+#4)
	}
	{
		v23.h = vsplat(r7)
		p0 = cmp.gtu(r1,r11)
		r7 = add(r3,#-4)
		if (p1) r12 = memub(r2+#5)
	}
	{
		v19.h = vsplat(r8)
		p1 = cmp.gtu(r1,r6)
		r6 = #0
		if (p0) r9 = memub(r2+#6)
	}
	{
		v21.h = vsplat(r12)
		v25.h = vsplat(r9)
		p0 = cmp.gtu(r1,r7)
		v22 = vmux(q0,v18,v19)
	}
	{
		r15 = add(r3,#-1)
		r7 = add(r3,#-3)
		r8 = #0
		v24 = vmux(q0,v20,v21)
	}
	{
		v3.h = vmpyi(v22.h,v0.h)
		r12 = #0
		r9 = #0
		v16 = vmux(q0,v23,v25)
	}
	{
		v3.h += vmpyi(v24.h,v1.h)
	}
	{
		v3.h += vmpyi(v16.h,v2.h)
		vmem(r4+#0) = v3.new
	}
	{
		p1 = cmp.gtu(r1,r7)
		r7 = #0
		if (p1) r6 = memub(r2+#7)
		if (p0) r5 = memub(r2+#8)
	}
	{
		v22.h = vsplat(r6)
		p0 = cmp.gtu(r1,r14)
		p1 = cmp.gtu(r1,r15)
		if (p1) r7 = memub(r2+#9)
	}
	{
		v24.h = vsplat(r5)
		v27.h = vsplat(r7)
		p0 = cmp.gtu(r1,r3)
		if (p0) r8 = memub(r2+#10)
	}
	{
		v23.h = vsplat(r8)
		r3 = add(r3,#24)
		if (p1) r12 = memub(r2+#11)
		if (p0) r9 = memub(r2+#12)
	}
	{
		v25.h = vsplat(r12)
		v29.h = vsplat(r9)
		r2 = add(r2,#24)
		v26 = vmux(q0,v22,v23)
	}
	{
		v28 = vmux(q0,v24,v25)
	}
	{
		v31.h = vmpyi(v26.h,v0.h)
		v30 = vmux(q0,v27,v29)
	}
	{
		v31.h += vmpyi(v28.h,v1.h)
	}
	{
		v31.h += vmpyi(v30.h,v2.h)
		r4 = add(r4,#512)
		vmem(r4+#1) = v31.new
	} :endloop0
	.falign
.LBB6_9:                                // %for.cond.cleanup17
	{
		jumpr r31
	}
.Lfunc_end6:
	.size	hvx_tl2_prepare, .Lfunc_end6-hvx_tl2_prepare
                                        // -- End function
	.globl	hvx_gemv_u8tl2_panel            // -- Begin function hvx_gemv_u8tl2_panel
	.falign
	.type	hvx_gemv_u8tl2_panel,@function
hvx_gemv_u8tl2_panel:                   // @hvx_gemv_u8tl2_panel
// %bb.0:                               // %entry
	{
		v1 = vxor(v1,v1)
		r4 = ##-1431655765
		r7:6 = combine(#0,#1)
	}
	{
		r4 = mpyu(r1,r4)
		v0 = v1
	}
	{
		r10 = lsr(r4,#4)
	}
	{
		r1 -= mpyi(r10,#24)
	}
	{
		p0 = cmp.eq(r1,#0)
		if (!p0.new) r10 = add(r10,#1)
	}
	{
		p1 = cmp.eq(r10,#0)
		if (!p1.new) r4 = add(r0,##256)
		if (p1.new) jump:nt .LBB7_3
	}
// %bb.1:                               // %for.body.preheader
	{
		r5 = #4
		v5:4 = vcombine(v1,v0)
		v3:2 = vcombine(v1,v0)
	}
	{
		r8 = ##16843009
		r9 = ##33686018
	}
	{
		r12 = ##67372036
		r13 = ##134744072
	}
	{
		r14 = ##269488144
		r15 = ##538976288
	}
	{
		r28 = ##1077952576
		r0 = ##-2139062144
	}
	{
		loop0(.LBB7_2,r10)
	}
	.falign
.LBB7_2:                                // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		v10.b = vshuffe(v13.b,v13.b)
		v6 = v1
		v0 = v1
		v13.cur = vmem(r4+#2)
	}
	{
		v15.uh = vlsr(v14.uh,r5)
		v9.b = vshuffo(v13.b,v13.b)
		v7 = v1
		v14.cur = vmem(r4+#-2)
	}
	{
		q3 = vand(v10,r8)
		q2 = vand(v9,r8)
		v8 = v1
		v16 = vmem(r2+#0)
	}
	{
		q1 = vand(v10,r9)
		v21:20.h = vlut16(v14.b,v16.h,r7):nomatch
		v17 = vmem(r4+#-1)
	}
	{
		q0 = vand(v9,r9)
		v18.uh = vlsr(v17.uh,r5)
		if (!q3) v6.h += v20.h
		v19 = vmem(r2+#1)
	}
	{
		v23:22.h = vlut16(v15.b,v16.h,r6):nomatch
		if (!q2) v0.h += v21.h
		v12 = vmem(r4+#0)
	}
	{
		if (!q1) v7.h += v22.h
		if (!q0) v8.h += v23.h
		if (q3) v6.h -= v20.h
		if (q2) v0.h -= v21.h
	}
	{
		v11.uh = vlsr(v12.uh,r5)
		if (q1) v7.h -= v22.h
		if (q0) v8.h -= v23.h
		v26 = vmem(r2+#2)
	}
	{
		q2 = vand(v10,r12)
		q0 = vand(v9,r12)
		v25:24.h = vlut16(v17.b,v19.h,r7):nomatch
	}
	{
		q1 = vand(v10,r13)
		q3 = vand(v9,r13)
		v29:28.h = vlut16(v18.b,v19.h,r6):nomatch
	}
	{
		if (!q2) v6.h += v24.h
		if (!q0) v0.h += v25.h
		if (!q1) v7.h += v28.h
		if (!q3) v8.h += v29.h
	}
	{
		if (q3) v8.h -= v29.h
		if (q2) v6.h -= v24.h
		if (q0) v0.h -= v25.h
		if (q1) v7.h -= v28.h
	}
	{
		q1 = vand(v10,r14)
		r4 = add(r4,#640)
		v31:30.h = vlut16(v12.b,v26.h,r7):nomatch
		v27 = vmem(r4+#1)
	}
	{
		q0 = vand(v9,r14)
		q3 = vand(v10,r15)
		v28.uh = vlsr(v27.uh,r5)
		v29 = vmem(r2+#3)
	}
	{
		q2 = vand(v9,r15)
		r2 = add(r2,#512)
		v17:16.h = vlut16(v11.b,v26.h,r6):nomatch
		if (!q1) v6.h += v30.h
	}
	{
		if (!q0) v0.h += v31.h
		if (!q3) v7.h += v16.h
		if (!q2) v8.h += v17.h
		if (q1) v6.h -= v30.h
	}
	{
		q1 = vand(v10,r28)
		if (q0) v0.h -= v31.h
		if (q3) v7.h -= v16.h
		if (q2) v8.h -= v17.h
	}
	{
		q3 = vand(v9,r28)
		q0 = vand(v10,r0)
		v31:30.h = vlut16(v27.b,v29.h,r7):nomatch
	}
	{
		q2 = vand(v9,r0)
		v25:24.h = vlut16(v28.b,v29.h,r6):nomatch
		if (!q1) v6.h += v30.h
	}
	{
		if (!q0) v7.h += v24.h
		if (!q3) v0.h += v31.h
		if (!q2) v8.h += v25.h
		if (q1) v6.h -= v30.h
	}
	{
		if (q0) v7.h -= v24.h
		if (q3) v0.h -= v31.h
		if (q2) v8.h -= v25.h
	}
	{
		v5:4.w += vadd(v6.h,v7.h)
	}
	{
		v3:2.w += vadd(v0.h,v8.h)
		nop
	} :endloop0
	{
		jump .LBB7_4
	}
	.falign
.LBB7_3:
	{
		v3:2 = vcombine(v1,v0)
		v5:4 = vcombine(v1,v0)
	}
	.falign
.LBB7_4:                                // %for.cond.cleanup
	{
		vmem(r3+#0) = v4
	}
	{
		vmem(r3+#1) = v2
	}
	{
		vmem(r3+#2) = v5
	}
	{
		jumpr r31
		vmem(r3+#3) = v3
	}
.Lfunc_end7:
	.size	hvx_gemv_u8tl2_panel, .Lfunc_end7-hvx_gemv_u8tl2_panel
                                        // -- End function
	.type	tl2_expand_nibbles,@object      // @tl2_expand_nibbles
	.section	.rodata,"a",@progbits
	.p2align	7, 0x0
tl2_expand_nibbles:
	.string	"\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000"
	.string	"\000\000\000\000\001\001\001\001\001\001\017\017\017\017\017\017\000\000\000\000\000\000\001\001\001\001\001\001\000\000\000\000\000\000\000\000\017\017\017\017\017\017\001\001\001\001\001\001\000\000\000\000\000\000\017\017\017\017\017\017\000\000\000\000\000\000\000\000\001\001\001\001\001\001\017\017\017\017\017\017\000\000\000\000\000\000\001\001\001\001\001\001\000\000\000\000\000\000\000\000\017\017\017\017\017\017\001\001\001\001\001\001\000\000\000\000\000\000\017\017\017\017\017\017\000\000\000"
	.string	"\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\000\000\000\000\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\000\000\000\000\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\017\017\000\000\001\001\000\000\000\000\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\001\001\000\000\017\017\000\000\000"
	.string	"\000\000\000\000\000\000\000\000\000\000\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\000\000\000\000\000\000\000\000\000\000\000\000\000\000\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\000\000\000\000\000\000\000\000\000\000\000\000\000\000\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\007\000\000\000\000\000\000\000\000\000\000\000\000\000\000\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\000\000\000"
	.string	"\000\000\000\000\007\007\007\007\007\007\t\t\t\t\t\t\000\000\000\000\000\000\007\007\007\007\007\007\000\000\000\000\000\000\000\000\t\t\t\t\t\t\007\007\007\007\007\007\000\000\000\000\000\000\t\t\t\t\t\t\000\000\000\000\000\000\000\000\007\007\007\007\007\007\t\t\t\t\t\t\000\000\000\000\000\000\007\007\007\007\007\007\000\000\000\000\000\000\000\000\t\t\t\t\t\t\007\007\007\007\007\007\000\000\000\000\000\000\t\t\t\t\t\t\000\000\000"
	.string	"\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\000\000\000\000\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\000\000\000\000\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\t\t\000\000\007\007\000\000\000\000\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\007\007\000\000\t\t\000\000\000"
	.size	tl2_expand_nibbles, 768

	.type	hvx_tl2_expand_wh96.trits,@object // @hvx_tl2_expand_wh96.trits
	.p2align	3, 0x0
hvx_tl2_expand_wh96.trits:
	.space	3
	.ascii	"\000\000\001"
	.ascii	"\000\001\377"
	.string	"\000\001"
	.ascii	"\000\001\001"
	.ascii	"\001\377\377"
	.string	"\001\377"
	.ascii	"\001\377\001"
	.ascii	"\001\000\377"
	.string	"\001\000"
	.ascii	"\001\000\001"
	.ascii	"\001\001\377"
	.string	"\001\001"
	.space	3,1
	.space	3
	.space	3
	.size	hvx_tl2_expand_wh96.trits, 48

	.type	tl2_digits,@object              // @tl2_digits
	.p2align	7, 0x0
tl2_digits:
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	65535                           // 0xffff
	.half	65535                           // 0xffff
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	1                               // 0x1
	.half	1                               // 0x1
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.half	0                               // 0x0
	.size	tl2_digits, 384

	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig

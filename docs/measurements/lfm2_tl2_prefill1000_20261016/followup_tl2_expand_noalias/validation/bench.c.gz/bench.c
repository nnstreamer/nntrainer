#include "hvx_gemv_u8tl2.h"
#include <hexagon_sim_timer.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
void reference_hvx_tl2_expand_wh96(const uint8_t *, uint32_t, uint32_t, uint32_t, int, uint8_t *);
static uint8_t src[2560] __attribute__((aligned(128)));
static uint8_t a[3 * 49152] __attribute__((aligned(128)));
static uint8_t b[3 * 49152] __attribute__((aligned(128)));
int main(void) {
  for (unsigned i = 0; i < sizeof(src); ++i) src[i] = (i * 2349671u + 543u) % 256u;
  const unsigned repeat = 500u;
  for (unsigned rows = 32u; rows <= 96u; rows += 32u)
    for (unsigned stride = 32768u; stride <= 49152u; stride += 16384u)
      for (int magnitude = 1; magnitude <= 7; magnitude += 6) {
        for (unsigned i = 0; i < 10u; ++i) {
          reference_hvx_tl2_expand_wh96(src, rows, 128u, stride, magnitude, a);
          hvx_tl2_expand_wh96_disjoint(src, rows, 128u, stride, magnitude, b);
        }
        const unsigned long long t0 = hexagon_sim_read_pcycles();
        for (unsigned i = 0; i < repeat; ++i)
          reference_hvx_tl2_expand_wh96(src, rows, 128u, stride, magnitude, a);
        const unsigned long long t1 = hexagon_sim_read_pcycles();
        for (unsigned i = 0; i < repeat; ++i)
          hvx_tl2_expand_wh96_disjoint(src, rows, 128u, stride, magnitude, b);
        const unsigned long long t2 = hexagon_sim_read_pcycles();
        if (memcmp(a, b, sizeof(a))) return 1;
        printf("rows=%u stride=%u mag=%d repeat=%u old=%llu new=%llu\n", rows, stride, magnitude, repeat, t1 - t0, t2 - t1);
      }
  return 0;
}

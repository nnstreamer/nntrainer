#ifndef HAP_FARF_H
#define HAP_FARF_H
#include <stdio.h>
#define FARF(level, ...) do { printf(__VA_ARGS__); putchar(10); } while (0)
#endif

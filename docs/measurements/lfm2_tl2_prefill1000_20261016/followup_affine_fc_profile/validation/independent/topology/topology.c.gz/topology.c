#include <assert.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hexkl_mm_opts.h"
#include "hexkl_mm_u8i4_dma.h"
#include "hexkl_probe.h"
#include "hvx_quant_u8.h"
#include "hvx_worker_pool.h"
uint64_t review_ticks, review_qreads;
static char line[4096];
static unsigned reads, joins, drains, submitted, fail_pack, fail_read;
static unsigned cases;
void review_log(const char *fmt, ...) { va_list v; va_start(v,fmt); vsnprintf(line,sizeof line,fmt,v); va_end(v); }
int __wrap_hexkl_micro_hmx_acc_clear_int32(void) { review_ticks+=19; return 0; }
int __wrap_hexkl_micro_hmx_mm_u8i4(uint8_t*b,uint32_t a,uint32_t w) { (void)b;(void)a;(void)w;review_ticks+=23; return 0; }
int __wrap_hexkl_micro_hmx_acc_read_int32(uint8_t*b,uint32_t cfg,uint32_t off) { (void)b;(void)cfg;(void)off;review_ticks+=29; return ++reads==fail_read ? 99:0; }
void __wrap_hexkl_dma_ring_push2d(void*d,const void*s,uint32_t ds,uint32_t ss,uint32_t rs,uint32_t n,int sv,int dv) { (void)d;(void)s;(void)ds;(void)ss;(void)rs;(void)n;(void)sv;(void)dv;review_ticks+=17; }
void __wrap_hexkl_dma_ring_drain(void) { ++drains;review_ticks+=37; }
void __wrap_hvx_worker_pool_run(hvx_worker_pool*p,hvx_worker_pool_func f,void*c,uint32_t n) { (void)p;(void)f;(void)c;(void)n;review_ticks+=13; }
void __wrap_hvx_worker_pool_submit(hvx_worker_pool*p,hvx_worker_pool_func f,void*c,uint32_t n) { (void)p;(void)f;(void)c;(void)n;++submitted;review_ticks+=41; }
void __wrap_hvx_worker_pool_wait(hvx_worker_pool*p) { (void)p;++joins;review_ticks+=31; }
int __wrap_hvx_quant_params_pack_u8_ah(const float*x,const uint16_t*x16,const float*enc,uint32_t hd,uint32_t M,uint32_t mp,uint32_t K,const float*g,float eps,float*scratch,float*sc,int32_t*zp,uint8_t*out,hvx_worker_pool*p) { (void)x;(void)x16;(void)enc;(void)hd;(void)M;(void)mp;(void)K;(void)g;(void)eps;(void)scratch;(void)sc;(void)zp;(void)out;(void)p;review_ticks+=11;return fail_pack?98:0; }
int __wrap_hvx_quant_pack_u8_ah(const float*x,uint32_t M,uint32_t mp,uint32_t K,const float*sc,const int32_t*zp,uint8_t*out,hvx_worker_pool*p) { (void)x;(void)M;(void)mp;(void)K;(void)sc;(void)zp;(void)out;(void)p;review_ticks+=11;return fail_pack?98:0; }
static uint64_t field(const char*k) { char key[80];snprintf(key,sizeof key," %s=",k);const char*p=strstr(line,key);assert(p);return strtoull(p+strlen(key),NULL,10); }
static void run(uint32_t M, const uint32_t*N,uint32_t nh,unsigned err,int supplied) {
  static uint8_t arena[8u<<20];
  hexkl_weight_u8i4_table*tbl=calloc(1,sizeof *tbl);
  uint32_t handles[3]={0,1,2};uint32_t total=0;int32_t offsets[2048]={0};float scales[2048]={0};
  for(unsigned i=0;i<nh;i++) { total+=N[i]; tbl->slots[i].K=2048;tbl->slots[i].N=N[i];tbl->slots[i].bits=4;tbl->slots[i].in_use=1;tbl->slots[i].w_offset=offsets;tbl->slots[i].colsum_w=offsets;tbl->slots[i].w_scale=scales;tbl->slots[i].bias=scales;tbl->slots[i].wh_bytes=arena; }
  float*act=calloc((size_t)M*2048,4),*out=calloc((size_t)M*total,4);
  float *scale=calloc(M+64,4);int32_t*zp=calloc(M+64,4);hexkl_mm_opts o={0};if(supplied){o.act_scale=scale;o.act_zp=zp;}
  line[0]=0; review_ticks=review_qreads=0;reads=joins=drains=submitted=0;fail_pack=err==1;fail_read=err==2?33:0;hexkl_probe_on=0;
  int rc=hexkl_mm_u8i4_layer_run(tbl,arena,sizeof arena,sizeof arena,M,2048,handles,nh,act,out,&o);
  assert((rc==0)==(err==0));
  assert(line[0]);
  unsigned expected_reads=((M+63)/64)*(total/32);
  if(!err) { assert(reads==expected_reads);assert(field("reads")==expected_reads);assert(field("pipeline")==1); assert(drains==nh+1); assert(submitted+1==joins); }
  assert(field("reads")==reads && field("joins")==joins);
  assert(field("pack_t")==12);
  assert(field("sums_t")== (err==1?0:14));
  assert(field("read_t")==30u*reads);
  assert(field("join_t")==32u*joins);
  assert(field("drain_t")==38u*drains);
  assert(field("clock_t")==32 && field("clock_pairs")==32);
  assert(field("brackets")==1+1+(err==1?0:1)+reads+joins+drains);
  assert(review_qreads==2*field("brackets")+64);
  uint64_t sum=field("pack_t")+field("sums_t")+field("read_t")+field("join_t")+field("drain_t");
  assert(sum<=field("body_t"));
  printf("TOPOLOGY M=%u nh=%u N=%u error=%u supplied=%d reads=%u joins=%u drains=%u timer_reads=%llu PASS\n",M,nh,total,err,supplied,reads,joins,drains,(unsigned long long)review_qreads);
  printf("%s\n",line);
  free(tbl);free(act);free(out);free(scale);free(zp);++cases;
}
int main(void) {
  const unsigned Ns[4][3]={{2048,0,0},{2048,512,512},{2048,2048,2048},{512,0,0}};
  const unsigned ms[]={2,64,65,512,1024};
  for(unsigned i=0;i<5;i++)for(unsigned j=0;j<4;j++)run(ms[i],Ns[j],j==1||j==2?3:1,0,i&1);
  run(1024,Ns[1],3,1,0);run(1024,Ns[1],3,2,0);
  printf("ACTUAL_FC_TIMER_TOPOLOGY %u cases PASS (primitive semantics mocked; no numeric/performance claim)\n",cases);
}

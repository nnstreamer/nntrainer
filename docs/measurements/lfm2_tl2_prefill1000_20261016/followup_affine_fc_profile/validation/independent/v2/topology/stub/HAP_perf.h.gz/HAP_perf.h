#ifndef REVIEW_HAP_PERF_H
#define REVIEW_HAP_PERF_H
#include <stdint.h>
extern uint64_t review_ticks, review_qreads;
static inline uint64_t HAP_perf_get_qtimer_count(void) { ++review_qreads; return ++review_ticks; }
static inline uint64_t HAP_perf_qtimer_count_to_us(uint64_t c) { return c; }
static inline uint64_t HAP_perf_get_pcycles(void) { return ++review_ticks; }
#endif

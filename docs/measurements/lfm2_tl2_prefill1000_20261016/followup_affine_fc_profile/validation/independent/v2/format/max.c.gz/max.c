#include <assert.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
static char lines[2][512];static unsigned nl;
static const uint64_t step=UINT64_C(0x07ffffffffffffff);
static uint64_t tick=UINT64_MAX-1-UINT64_C(0x07ffffffffffffff);
static uint64_t hexkl_probe_now_ticks(void){tick+=step;return tick;}
static void logline(const char*f,...){assert(nl<2);va_list v;va_start(v,f);vsnprintf(lines[nl++],512,f,v);va_end(v);}
#define FARF(level,...) logline(__VA_ARGS__)
typedef struct {
  int on;
  uint32_t M, N, nh, n[3], reads, joins, brackets;
  uint64_t start, phase, pack, sums, read, join, drain;
} lfm_fc_trace;

static void lfm_fc_trace_end(const lfm_fc_trace *t, int rc, uint32_t stride,
                             uint32_t tiles, int pipelined) {
  if (!t->on)
    return;
  /* body excludes allocations/validation before begin and this calibration/log.
   * Raw 19.2 MHz ticks avoid truncation at every accumulator tile. */
  const uint64_t body = hexkl_probe_now_ticks() - t->start;
  uint64_t clock = 0u;
  for (uint32_t i = 0; i < 32u; ++i) {
    const uint64_t a = hexkl_probe_now_ticks();
    clock += hexkl_probe_now_ticks() - a;
  }
  /* Split at the existing start tick: the phone truncates FARF payloads near
   * 228 bytes. Even full-width integer values fit below 192 bytes per line;
   * the terminal marker makes truncation of the last number detectable. */
  FARF(ERROR,
       "[LFM-AFC2G] s=%llx d=%u,2048,%u,%u,%u,%u,%u "
       "x=%d,%u,%u,%d c=%u,%u,%u !",
       (unsigned long long)t->start, t->M, t->N, t->nh, t->n[0], t->n[1],
       t->n[2], rc, stride, tiles, pipelined, t->reads, t->joins,
       t->brackets + 1u);
  FARF(ERROR,
       "[LFM-AFC2T] s=%llx t=%llx,%llx,%llx,%llx,%llx,%llx "
       "k=19200000,32,%llx !",
       (unsigned long long)t->start, (unsigned long long)body,
       (unsigned long long)t->pack, (unsigned long long)t->sums,
       (unsigned long long)t->read, (unsigned long long)t->join,
       (unsigned long long)t->drain, (unsigned long long)clock);
}
int main(void){lfm_fc_trace t={0};t.on=1;t.start=UINT64_MAX;t.M=t.N=t.nh=t.n[0]=t.n[1]=t.n[2]=t.reads=t.joins=UINT32_MAX;t.brackets=UINT32_MAX-1;t.pack=t.sums=t.read=t.join=t.drain=UINT64_MAX;lfm_fc_trace_end(&t,INT32_MIN,UINT32_MAX,UINT32_MAX,INT32_MIN);assert(nl==2);assert(strlen(lines[0])==188);assert(strlen(lines[1])==167);for(unsigned i=0;i<2;i++){assert(strlen(lines[i])<192);assert(lines[i][strlen(lines[i])-1]=='!');puts(lines[i]);}puts("ACTUAL_V2_FORMAT maximum G188 T167 PASS");}
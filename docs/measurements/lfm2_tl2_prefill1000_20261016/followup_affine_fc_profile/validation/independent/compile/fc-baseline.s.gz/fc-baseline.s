hexkl_mm_u8i4_layer_run:                // @hexkl_mm_u8i4_layer_run
// %bb.0:                               // %entry
	{
		p1 = cmp.eq(r0,#0)
		memd(r29+#-16) = r17:16
		allocframe(r29,#656):raw
	}                                       // 8-byte Folded Spill
	{
		r24 = ##-2147449855
		memd(r29+#616) = r25:24
		memd(r29+#640) = r19:18
	}                                       // 8-byte Folded Spill
	{
		r19 = add(r24,#-32755)
		memd(r29+#632) = r21:20
		memd(r29+#624) = r23:22
	}                                       // 8-byte Folded Spill
	{
		if (p1) jump:nt .LBB15_38
		memd(r29+#608) = r27:26
	}                                       // 8-byte Folded Spill
// %bb.1:                               // %entry
	{
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB15_38
	}
// %bb.2:                               // %entry
	{
		r23 = memw(r29+#664)
		if (cmp.eq(r23.new,#0)) jump:nt .LBB15_38
	}
// %bb.3:                               // %entry
	{
		r21 = memw(r29+#668)
		if (cmp.eq(r21.new,#0)) jump:nt .LBB15_38
	}
// %bb.4:                               // %lor.lhs.false6
	{
		r25 = add(pc,##hexkl_mm_u8i4_fused_run.kDefaults@PCREL)
		r27 = memw(r29+#672)
		r6 = memw(r29+#680)
	}
	{
		p0 = cmp.eq(r6,#0)
		p2 = cmp.eq(r27,#0)
		if (!p0.new) r25 = add(r6,#0)
		r20 = memw(r29+#676)
	}
	{
		p1 = cmp.eq(r20,#0)
		if (!p2) jump:nt .LBB15_6
	}
// %bb.5:                               // %land.lhs.true
	{
		r6 = memw(r25+#16)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_20
	}
	.falign
.LBB15_6:                               // %lor.lhs.false11
	{
		if (p1) jump:nt .LBB15_38
	}
	.falign
.LBB15_7:                               // %lor.lhs.false13
	{
		p2 = cmp.eq(r4,#0)
		if (p2.new) jump:nt .LBB15_38
	}
// %bb.8:                               // %lor.lhs.false13
	{
		p0 = cmp.eq(r5,#0); if (p0.new) jump:nt .LBB15_38
	}
// %bb.9:                               // %if.end
	{
		r6 = memw(r25+#32)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_22
	}
// %bb.10:                              // %land.lhs.true19
	{
		r6 = memw(r25+#20)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.11:                              // %lor.lhs.false21
	{
		r6 = memw(r25+#24)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.12:                              // %lor.lhs.false23
	{
		r6 = memw(r25+#4)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.13:                              // %lor.lhs.false25
	{
		r17:16 = combine(r2,r5)
		r26 = r0
		r6 = memw(r25+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
// %bb.14:                              // %lor.lhs.false28
	{
		r6 = memw(r25+#36)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.15:                              // %lor.lhs.false30
	{
		r6 = memw(r25+#40)
		if (cmp.eq(r6.new,#0)) jump:nt .LBB15_38
	}
// %bb.16:                              // %lor.lhs.false32
	{
		r1:0 = combine(r6,r5)
		memw(r29+#32) = r1
	}                                       // 4-byte Folded Spill
	{
		call __hexagon_umodsi3
		r22 = r3
		r18 = r4
	}
	.falign
// %bb.17:                              // %lor.lhs.false32
	{
		p2 = cmp.eq(r0,#0)
		if (p2.new) r0 = add(r26,#0)
		if (!p2.new) jump:t .LBB15_38
	}
// %bb.18:                              // %lor.lhs.false32.if.end36_crit_edge
	{
		p1 = or(p1,!p1)
		r2 = memw(r25+#8)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_38
	}
// %bb.19:
	{
		r5:4 = combine(r16,r18)
		r3:2 = combine(r22,r17)
		r1 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_23
	}
	.falign
.LBB15_20:                              // %land.lhs.true9
	{
		if (p1) jump:nt .LBB15_38
	}
// %bb.21:                              // %land.lhs.true9
	{
		r6 = memw(r25+#32)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_7
	}
	{
		jump .LBB15_38
	}
	.falign
.LBB15_22:                              // %if.end36
	{
		r6 = memw(r25+#8)
		r7 = memw(r25+#4)
	}
	{
		p2 = cmp.eq(r6,#0)
		p1 = cmp.eq(r7,#0)
	}
	{
		p0 = not(p2)
	}
	{
		p2 = xor(p1,p0)
		if (!p2.new) jump:t .LBB15_38
	}
	.falign
.LBB15_23:                              // %if.end44
	{
		if (!p1) jump:nt .LBB15_25
	}
// %bb.24:                              // %if.end44
	{
		r6 = memw(r25+#16)
		if (!cmp.eq(r6.new,#0)) jump:t .LBB15_38
	}
	.falign
.LBB15_25:                              // %if.end53
	{
		r6 = memw(r25+#20)
	}
	{
		p2 = cmp.eq(r6,#0)
	}
	{
		p0 = not(p2)
	}
	{
		p1 = and(p0,!p1)
		if (!p1.new) r22 = #0
		if (p1.new) jump:t .LBB15_38
		if (!p1.new) r7 = memw(r25+#48)
	}
// %bb.26:                              // %if.end62
	{
		p2 = cmp.eq(r7,#0)
		r8 = memw(r25+#44)
		r6 = memw(r25+#80)
	}
	{
		p0 = not(p2)
		p1 = cmp.eq(r8,#0)
	}
	{
		p2 = xor(p1,p0)
		if (!p2.new) jump:t .LBB15_38
	}
// %bb.27:                              // %if.end70
	{
		r6 = #0
		p0 = cmp.eq(r6,#0); if (p0.new) jump:nt .LBB15_37
	}
// %bb.28:                              // %if.then73
	{
		if (p1) jump:nt .LBB15_38
		if (!p1) r9 = memw(r25+#52)
	}
// %bb.29:                              // %lor.lhs.false77
	{
		p1 = cmp.eq(r9,#0)
		if (!p1.new) r9 = add(r23,#0)
		if (p1.new) jump:nt .LBB15_38
	}
// %bb.30:
	{
		loop0(.LBB15_31,r21)
	}
	.falign
.LBB15_31:                              // Block address taken
                                        // %for.body
                                        // =>This Inner Loop Header: Depth=1
	{
		r12 = #4095
	}
	{
		r12 = memw(r9+#0)
		if (cmp.gtu(r12.new,r12)) jump:nt .LBB15_38
	}
// %bb.32:                              // %lor.lhs.false86
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r9 = add(r9,#4)
		r13 = memw(r8+#0)
		if (!cmp.eq(r13.new,r22)) jump:nt .LBB15_38
	}
// %bb.33:                              // %if.end92
                                        //   in Loop: Header=BB15_31 Depth=1
	{
		r13 = r0
		r8 = add(r8,#4)
	}
	{
		r13 += mpyi(r12,#96)
	}
	{
		r12 = memw(r13+#32)
	}
	{
		r22 = add(r12,r22)
		nop
	} :endloop0
// %bb.34:
	{
		r8 = r21
	}
	.falign
.LBB15_35:                              // %for.body100
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = memw(r7+#0)
		if (!cmp.eq(r9.new,r22)) jump:nt .LBB15_38
	}
// %bb.36:                              // %for.cond96
                                        //   in Loop: Header=BB15_35 Depth=1
	{
		r7 = add(r7,#4)
		r8 = add(r8,#-1)
		if (!cmp.eq(r8.new,#0)) jump:t .LBB15_35
	}
	.falign
.LBB15_37:                              // %if.end112
	{
		r13 = lsr(r5,#5)
		p0 = !bitsclr(r5,#31)
		r18 = add(r4,#63)
		if (!p0.new) jump:nt .LBB15_39
	}
	.falign
.LBB15_38:                              // %cleanup1062
	{
		r0 = r19
		r17:16 = memd(r29+#648)
		r19:18 = memd(r29+#640)
	}                                       // 8-byte Folded Reload
	{
		r21:20 = memd(r29+#632)
		r23:22 = memd(r29+#624)
	}                                       // 8-byte Folded Reload
	{
		r25:24 = memd(r29+#616)
		r27:26 = memd(r29+#608)
	}                                       // 8-byte Folded Reload
	{
		r31:30 = dealloc_return(r30):raw
	}
	.falign
.LBB15_39:
	{
		r14 = lsr(r18,#6)
		r8 = r23
		r7 = #1
		r17:16 = combine(#0,#0)
	}
	{
		loop0(.LBB15_40,r21)
		r15 = and(r18,#-64)
	}
	.falign
.LBB15_40:                              // Block address taken
                                        // %for.body126
                                        // =>This Inner Loop Header: Depth=1
	{
		r9 = #4095
	}
	{
		r9 = memw(r8+#0)
		if (cmp.gtu(r9.new,r9)) jump:nt .LBB15_38
	}
// %bb.41:                              // %lor.lhs.false130
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = +mpyi(r9,#96)
	}
	{
		r12 = memw(r0+r9<<#0)
		if (cmp.eq(r12.new,#0)) jump:nt .LBB15_38
	}
// %bb.42:                              // %if.end136
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r9 = add(r0,r9)
	}
	{
		r12 = memw(r9+#28)
		if (!cmp.eq(r12.new,r5)) jump:nt .LBB15_38
	}
// %bb.43:                              // %if.end144
                                        //   in Loop: Header=BB15_40 Depth=1
	{
		r8 = add(r8,#4)
		r12 = memw(r9+#32)
		r9 = memw(r9+#20)
	}
	{
		r16 = maxu(r12,r16)
		r9 = lsr(r12,#5)
		p1 = cmp.eq(r9,#0)
		if (!p1.new) r17 = add(r7,#0)
	}
	{
		r6 = maxu(r9,r6)
		nop
	} :endloop0
// %bb.44:                              // %for.end165
	{
		r8 = extractu(r13,#23,#0)
		r7 = extractu(r13,#21,#0)
		r19 = add(r24,#-32767)
	}
	{
		r9 = asl(r7,#11)
		r8 = asl(r8,#9)
	}
	{
		r28 = mpyi(r9,r14)
		r6 = mpyi(r8,r6)
		memw(r29+#296) = r28.new
	}
	{
		r2 = minu(r2,r3)
		r7 = add(r6,r28)
		memw(r29+#300) = r7.new
	}
	{
		r12 = add(r6,add(r7,##2047))
	}
	{
		r12 = insert(r28,#11,#0)
	}
	{
		r6 = add(r12,#16384)
		if (cmp.gtu(r6.new,r2)) jump:t .LBB15_38
	}
// %bb.45:                              // %if.end194
	{
		r2 = sub(r2,r12)
		r1 = memw(r25+#52)
		memw(r29+#32) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = lsr(r2,#14)
		p2 = cmp.eq(r1,#0)
		r0 = #32
		memw(r29+#84) = r0
	}                                       // 4-byte Folded Spill
	{
		r2 = minu(r2,r0)
		memw(r29+#92) = r28
		memw(r29+#104) = r8
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#112) = r9
		memw(r29+#60) = r15
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#108) = r14
		memw(r29+#96) = r13
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#100) = r3
		memw(r29+#36) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#88) = r5
		memw(r29+#64) = r12
	}                                       // 4-byte Folded Spill
	{
		if (p2) jump:nt .LBB15_54
		memw(r29+#52) = r2
	}                                       // 4-byte Folded Spill
// %bb.46:                              // %for.body209.lr.ph
	{
		r3 = #0
		r1 = #1
		r4 = memw(r25+#56)
		r2 = memw(r25+#72)
	}
	{
		loop0(.LBB15_48,r21)
		p0 = cmp.eq(r4,#0); if (p0.new) jump:nt .LBB15_49
	}
	.falign
.LBB15_48:                              // Block address taken
                                        // %for.body209
                                        // =>This Inner Loop Header: Depth=1
	{
		p0 = cmp.gtu(r2,r3)
		r3 = add(r3,#1)
		r5 = #0
		r6 = memw(r4+#0)
	}
	{
		r4 = add(r4,#4)
		if (p0) r5 = memw(r25+#68)
	}
	{
		r5 = maxu(r6,r5)
	}
	{
		r5 = lsr(r5,#5)
	}
	{
		r1 = maxu(r5,r1)
		nop
	} :endloop0
	{
		jump .LBB15_51
	}
	.falign
.LBB15_49:
	{
		loop0(.LBB15_50,r21)
	}
	.balign 32
.LBB15_50:                              // Block address taken
                                        // %for.body209.us
                                        // =>This Inner Loop Header: Depth=1
	{
		p1 = cmp.gtu(r2,r3)
		r4 = #0
		r3 = add(r3,#1)
	}
	{
		if (p1) r4 = memw(r25+#68)
	}
	{
		r4 = lsr(r4,#5)
	}
	{
		r1 = maxu(r4,r1)
		nop
	} :endloop0
	.falign
.LBB15_51:                              // %for.cond.cleanup208
	{
		r2 = memw(r29+#52)
		if (cmp.gtu(r1,r2.new)) jump:t .LBB15_54
	}                                       // 4-byte Folded Reload
// %bb.52:                              // %if.then242
	{
		r26 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		call __hexagon_umodsi3
		r0 = r26
	}
	.falign
// %bb.53:                              // %if.then242
	{
		r26 = sub(r26,r0)
		memw(r29+#52) = r26.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_54:                              // %if.end246
	{
		call hexkl_dma_ring_reset
	}
	.falign
// %bb.55:                              // %if.end246
	{
		call hexkl_acc_layout_get
		r0 = memw(r29+#32)
		r1 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.56:                              // %if.end246
	{
		r1 = #0
		r2 = memw(r0+#4)
		memw(r29+#48) = r0
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		r2 = p1
		if (!p1) r3 = memw(r29+#48)
		memw(r29+#40) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		if (p1) jump:nt .LBB15_88
	}
// %bb.57:                              // %cond.end250.thread
	{
		r0 = memw(r3+#12)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	.falign
.LBB15_58:                              // %if.end259
	{
		p1 = cmp.eq(r17,#0)
		r2 = #0
		memw(r29+#56) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		if (!p1) r2 = memw(r29+#36)
		memw(r29+#44) = r2
	}                                       // 4-byte Folded Reload
	{
		if (p1) jump:nt .LBB15_61
		memw(r29+#72) = r0
	}                                       // 4-byte Folded Spill
// %bb.59:                              // %cond.true261
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.60:                              // %cond.true261
	{
		memw(r29+#44) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_61:                              // %cond.end265
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB15_64
		if (p2.new) r2 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
// %bb.62:                              // %cond.false270
	{
		r2 = mpyi(r2,r16)
	}
	{
		call malloc
		r0 = asl(r2,#2)
	}
	.falign
// %bb.63:                              // %cond.false270
	{
		memw(r29+#56) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_64:                              // %cond.end274
	{
		r1 = #0
		r2 = memw(r25+#4)
		memw(r29+#120) = r2.new
	}                                       // 4-byte Folded Spill
	{
		p0 = cmp.eq(r2,#0)
		memw(r29+#68) = r1
		memw(r29+#76) = r1
	}                                       // 4-byte Folded Spill
	{
		r0 = p0
		if (p0) r2 = memw(r29+#60)
		memw(r29+#80) = r1
	}                                       // 4-byte Folded Reload
	{
		if (!p0) jump:nt .LBB15_68
		memw(r29+#116) = r0
	}                                       // 4-byte Folded Spill
// %bb.65:                              // %if.then279
	{
		r24 = asl(r2,#2)
	}
	{
		call malloc
		r0 = r24
	}
	.falign
// %bb.66:                              // %if.then279
	{
		call malloc
		r0 = r24
		memw(r29+#80) = r0
	}                                       // 4-byte Folded Spill
	.falign
// %bb.67:                              // %if.then279
	{
		memw(r29+#76) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_68:                              // %if.end284
	{
		r2 = memw(r29+#40)
		r16 = memw(r25+#80)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_72
	}
// %bb.69:                              // %if.end284
	{
		p2 = cmp.eq(r16,#0)
		if (p2.new) jump:nt .LBB15_72
		if (!p2.new) r2 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
// %bb.70:                              // %cond.true291
	{
		call malloc
		r0 = asl(r2,#7)
	}
	.falign
// %bb.71:                              // %cond.true291
	{
		memw(r29+#68) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_72:                              // %cond.end295
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_74
	}
// %bb.73:                              // %cond.end295
	{
		r2 = memw(r29+#44)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_82
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_74:                              // %lor.lhs.false300
	{
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:nt .LBB15_76
	}
// %bb.75:                              // %lor.lhs.false300
	{
		r2 = memw(r29+#56)
		if (cmp.eq(r2.new,#0)) jump:t .LBB15_82
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_76:                              // %lor.lhs.false305
	{
		r2 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) jump:t .LBB15_79
	}
// %bb.77:                              // %land.lhs.true309
	{
		r2 = memw(r29+#76)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_82
	}                                       // 4-byte Folded Reload
// %bb.78:                              // %land.lhs.true309
	{
		r2 = memw(r29+#80)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_82
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_79:                              // %lor.lhs.false313
	{
		p1 = cmp.eq(r16,#0); if (p1.new) jump:nt .LBB15_90
		if (!p1.new) r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
// %bb.80:                              // %lor.lhs.false313
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_90
	}
// %bb.81:                              // %lor.lhs.false313
	{
		r2 = memw(r29+#68)
		if (!cmp.eq(r2.new,#0)) jump:nt .LBB15_90
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_82:                              // %if.then322
	{
		call free
		r0 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.83:                              // %if.then322
	{
		call free
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.84:                              // %if.then322
	{
		call free
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.85:                              // %if.then322
	{
		call free
		r0 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.86:                              // %if.then322
	{
		call free
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.87:                              // %if.then322
	{
		jump .LBB15_38
	}
	.falign
.LBB15_88:                              // %cond.end250
	{
		r1:0 = combine(#0,#0)
		r2 = memw(r2+##hexkl_probe_us@GOT)
	}
	{
		memd(r2+#136) = r1:0
	}
	{
		r2 = memw(r25+#44)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_58
	}
// %bb.89:
	{
		r19 = add(r24,#-32749)
		jump .LBB15_38
	}
	.falign
.LBB15_90:                              // %if.end323
	{
		r2 = memw(r23+#0)
		r16 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#104)
		r1 = memw(r25+#8)
	}                                       // 4-byte Folded Reload
	{
		r16 += mpyi(r2,#96)
		memw(r29+#192) = r1
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r16+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r19
	}
	.falign
// %bb.91:                              // %if.end323
	{
		r24 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r19)
		r19 = memw(r16+#4)
	}
	.falign
// %bb.92:                              // %if.end323
	{
		r5:4 = combine(r0,r24)
		r1 = r19
		r2 = memw(r29+#32)
		r3 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r2,r3)
		r3:2 = combine(r24,r24)
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	{
		call hexkl_dma_ring_push2d
	}
	.falign
// %bb.93:                              // %if.end323
	{
		r19 = memw(r25+#16)
		if (cmp.eq(r19.new,#0)) jump:nt .LBB15_100
	}
// %bb.94:                              // %if.then341
	{
		r16 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		call dma_row_size_dividing
		r0 = r16
	}
	.falign
// %bb.95:                              // %if.then341
	{
		r24 = r0
	}
	{
		call __hexagon_udivsi3
		r1:0 = combine(r24,r16)
	}
	.falign
// %bb.96:                              // %if.then341
	{
		r5:4 = combine(r0,r24)
		r3:2 = combine(r24,r24)
		r1 = r19
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		memw(r29+#0) = #0
		memw(r29+#4) = #1
	}
	.falign
// %bb.97:                              // %if.then341
	{
		r16 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_103
	}
// %bb.98:                              // %if.then347
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.99:                              // %if.then347
	{
		jump .LBB15_104
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_100:                             // %do.body359
	{
		r16 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
	}
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_108
	}
// %bb.101:                             // %if.then361
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.102:                             // %if.then361
	{
		jump .LBB15_109
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_103:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_104:                             // %do.end
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.105:                             // %do.end
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	{
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB15_124
	}
// %bb.106:                             // %if.then352
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.107:                             // %if.then352
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		jump .LBB15_124
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_108:
	{
		r1:0 = combine(#0,#0)
	}
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_109:                             // %do.end365
	{
		r2 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) r0 = add(r27,#0)
		if (p2.new) jump:nt .LBB15_112
		if (p2.new) r1 = memw(r25+#32)
	}
// %bb.110:                             // %if.else376
	{
		r2 = memw(r25+#0)
		memw(r29+#4) = r2.new
	}
	{
		r2 = memw(r29+#60)
		r1 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#88)
		r5 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#120)
		r6 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_pack_u8_ah
		memw(r29+#0) = r6
	}
	.falign
// %bb.111:                             // %if.else376
	{
		r19 = r0 ; jump .LBB15_114
	}
	.falign
.LBB15_112:                             // %if.then368
	{
		r5 = memw(r25+#24)
		r2 = memw(r25+#36)
	}
	{
		r4 = memw(r29+#32)
		r0 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r25+#40)
		r6 = memw(r25+#28)
	}
	{
		r7 = memw(r25+#20)
	}
	{
		r8 = memw(r25+#0)
		memw(r29+#24) = r4

	} :mem_noshuf
	{
		r0 = r27
		memw(r29+#4) = r5
		memw(r29+#0) = r0
	}
	{
		r4 = memw(r29+#36)
		memw(r29+#28) = r8
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#60)
		memw(r29+#12) = r7
	}                                       // 4-byte Folded Reload
	{
		r17 = memw(r29+#76)
		memw(r29+#20) = r17.new
	}                                       // 4-byte Folded Reload
	{
		r24 = memw(r29+#80)
		memw(r29+#16) = r24.new
	}                                       // 4-byte Folded Reload
	{
		call hvx_quant_params_pack_u8_ah
		memw(r29+#8) = r6
	}
	.falign
// %bb.113:                             // %if.then368
	{
		r19 = r0
		memw(r29+#192) = r17
		memw(r29+#120) = r24
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_114:                             // %do.body381
	{
		r2 = memw(r16+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
	}
	{
		p1 = cmp.eq(r2,#0); if (p1.new) jump:nt .LBB15_117
	}
// %bb.115:                             // %if.then383
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.116:                             // %if.then383
	{
		r2 = memw(r16+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#24)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#24) = r1:0
	}
	.falign
.LBB15_117:                             // %if.end390
	{
		p2 = cmp.eq(r19,#0)
		if (p2.new) jump:nt .LBB15_124
		if (!p2.new) r0 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
// %bb.118:                             // %if.then393
	{
		call free
	}
	.falign
// %bb.119:                             // %if.then393
	{
		call free
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.120:                             // %if.then393
	{
		call free
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.121:                             // %if.then393
	{
		call free
		r0 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.122:                             // %if.then393
	{
		call free
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.123:                             // %if.then393
	{
		jump .LBB15_38
	}
	.falign
.LBB15_124:                             // %if.end394
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (p0.new) jump:nt .LBB15_126
		if (!p0.new) r4 = memw(r29+#88)
		if (!p0.new) r7 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
// %bb.125:                             // %if.then396
	{
		r1 = add(pc,##fc_affine_sums_worker@PCREL)
		r2 = memw(r29+#32)
		memw(r29+#448) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r29,#448)
		r0 = memw(r29+#36)
		memw(r29+#452) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#108)
		memw(r29+#460) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r25+#0)
		memw(r29+#456) = r4
	}
	{
		r6 = memw(r29+#44)
		memw(r29+#464) = r7
	}                                       // 4-byte Folded Reload
	{
		call hvx_worker_pool_run
		memw(r29+#468) = r6
	}
	.falign
.LBB15_126:                             // %if.end400
	{
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
	}
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_129
		if (!p0.new) r2 = memw(r25+#12)
	}
// %bb.127:                             // %land.end
	{
		p2 = or(p2,!p2)
		p1 = cmp.eq(r2,#0)
	}
	{
		r0 = p2
		if (p1) jump:nt .LBB15_249
		memw(r29+#268) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.128:
	{
		p1 = and(p1,!p1)
		r0 = p2
		memw(r29+#236) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		jump .LBB15_130
		memw(r29+#272) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_129:                             // %land.end.thread
	{
		p1 = or(p1,!p1)
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		r1 = p1
		memw(r29+#272) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r0 = p1
		memw(r29+#236) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#268) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_130:                             // %if.end469
	{
		r2 = add(pc,##_GLOBAL_OFFSET_TABLE_@PCREL)
		r3 = memw(r25+#60)
		memw(r29+#180) = r3.new
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#72) = r2
	}                                       // 4-byte Folded Spill
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_133
	}
// %bb.131:                             // %if.then473
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.132:                             // %if.then473
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_133:                             // %do.end477
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.134:                             // %do.end477
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_137
	}
// %bb.135:                             // %if.then480
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.136:                             // %if.then480
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r5:4 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r5:4)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_137:                             // %for.body492.lr.ph
	{
		p2 = cmp.gtu(r18,#63)
		r3 = memw(r29+#52)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r3,#13)
		r1 = asl(r3,#9)
		memw(r29+#220) = r2.new
	}                                       // 4-byte Folded Spill
	{
		r2 = extractu(r0,#11,#0)
		r0 = asl(r3,#7)
		memw(r29+#256) = r1
		memw(r29+#132) = r23
	}                                       // 4-byte Folded Spill
	{
		r1 = p2
		r0 = #0
		memw(r29+#260) = r0
		memw(r29+#244) = r2
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#176) = r1
		memw(r29+#128) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#172) = r0
		memw(r29+#116) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_138:                             // %for.body492
                                        // =>This Loop Header: Depth=1
                                        //     Child Loop BB15_167 Depth 2
                                        //       Child Loop BB15_168 Depth 3
                                        //         Child Loop BB15_169 Depth 4
                                        //           Child Loop BB15_171 Depth 5
                                        //         Child Loop BB15_187 Depth 4
                                        //         Child Loop BB15_194 Depth 4
                                        //         Child Loop BB15_216 Depth 4
                                        //     Child Loop BB15_157 Depth 2
	{
		r2 = add(r29,#296)
		r3 = memw(r25+#44)
		r16 = memw(r29+#128)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r3,#0)
		r0 = memw(r29+#132)
		r1 = memw(r25+#48)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r1,#0)
		if (!p2) r4 = memw(r29+#116)
		r7 = memw(r29+#84)
	}                                       // 4-byte Folded Reload
	{
		if (!p2) r16 = memw(r3+r4<<#2)
		r4 = memw(r0+#0)
	}
	{
		r5 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r7 += mpyi(r4,#96)
		r2 = insert(r5,#1,#2)
		r6 = add(r5,#1)
		memw(r29+#144) = r6.new
	}                                       // 4-byte Folded Spill
	{
		r3 = addasl(r1,r5,#2)
		p1 = cmp.gtu(r21,r6)
		if (p1.new) r18 = memw(r29+#84)
		memw(r29+#92) = r7
	}                                       // 4-byte Folded Reload
	{
		if (p0) r3 = add(r7,#32)
		r17 = memw(r7+#32)
		r2 = memw(r2+#0)
	}
	{
		r0 = memw(r3+#0)
		memw(r29+#140) = r2
	}                                       // 4-byte Folded Spill
	{
		if (!p1) jump:nt .LBB15_142
		if (p1) r26 = memw(r29+#144)
		memw(r29+#136) = r0
	}                                       // 4-byte Folded Reload
// %bb.139:                             // %if.then522
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r3 = memw(r29+#104)
		r2 = memw(r23+r26<<#2)
	}                                       // 4-byte Folded Reload
	{
		r18 += mpyi(r2,#96)
	}
	{
		r2 = memw(r18+#32)
	}
	{
		r2 = lsr(r2,#5)
	}
	{
		r19 = mpyi(r3,r2)
	}
	{
		call dma_row_size_dividing
		r0 = r19
	}
	.falign
// %bb.140:                             // %if.then522
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = add(r29,#296)
		r24 = r0
	}
	{
		r2 = insert(r26,#1,#2)
		r1:0 = combine(r24,r19)
		r19 = memw(r18+#4)
	}
	{
		call __hexagon_udivsi3
		r18 = memw(r2+#0)
	}
	.falign
// %bb.141:                             // %if.then522
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r5:4 = combine(r0,r24)
		r1 = r19
		r2 = memw(r29+#32)
		memw(r29+#4) = #1
	}                                       // 4-byte Folded Reload
	{
		call hexkl_dma_ring_push2d
		r0 = add(r2,r18)
		r3:2 = combine(r24,r24)
		memw(r29+#0) = #0
	}
	.falign
.LBB15_142:                             // %if.end539
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#176)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (p1.new) r1 = #0
		if (!p1.new) jump:t .LBB15_144
	}
// %bb.143:                             // %for.body544.lr.ph
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r4 = addasl(r20,r16,#2)
		p0 = cmp.gtu(r17,#31); if (p0.new) jump:t .LBB15_166
		if (p0.new) r3 = memw(r29+#140)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_144:                             // %do.body918
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_147
	}
// %bb.145:                             // %if.then920
                                        //   in Loop: Header=BB15_138 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.146:                             // %if.then920
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_147:                             // %do.end924
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		call hexkl_dma_ring_drain
	}
	.falign
// %bb.148:                             // %do.end924
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_151
	}
// %bb.149:                             // %if.then927
                                        //   in Loop: Header=BB15_138 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.150:                             // %if.then927
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#104)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#104) = r1:0
	}
	.falign
.LBB15_151:                             // %do.end933
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (!cmp.eq(r2.new,#0)) jump:t .LBB15_163
	}
// %bb.152:                             // %do.body937
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_155
	}
// %bb.153:                             // %if.then939
                                        //   in Loop: Header=BB15_138 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.154:                             // %if.then939
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_155:                             // %do.end943
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r26 = memw(r2+#20)
		r19 = memw(r2+#32)
	}
	{
		r16 = asl(r19,#8)
		p1 = cmp.eq(r26,#0)
		if (p1.new) jump:nt .LBB15_159
		if (!p1.new) r18 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
// %bb.156:                             // %for.body952.preheader
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r17 = #0
		r27 = memw(r29+#56)
		r24 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_157:                             // %for.body952
                                        //   Parent Loop BB15_138 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	{
		r2 = #64
		r1:0 = combine(r19,r27)
		r3 = r19
		r5:4 = combine(r24,r26)
	}
	{
		r2 = minu(r18,r2)
		call hexkl_wh_affine_acc
	}
	.falign
// %bb.158:                             // %for.body952
                                        //   in Loop: Header=BB15_157 Depth=2
	{
		r17 = add(r17,#64)
		r18 = add(r18,#-64)
		r24 = add(r24,#256)
		r27 = add(r27,r16)
	}
	{
		r2 = memw(r29+#36)
		if (cmp.gtu(r2.new,r17)) jump:t .LBB15_157
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_159:                             // %if.end973
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#92)
		r1 = memw(r29+#36)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r25+#12)
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	{
		r5:4 = memd(r2+#8)
		r2 = memw(r2+#16)
	}
	{
		r2 = memw(r29+#128)
		memw(r29+#8) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r20,r2,#2)
		memw(r29+#12) = r2.new
	}
	{
		r3 = r19
		r2 = memw(r29+#60)
		memw(r29+#16) = r3
	}                                       // 4-byte Folded Reload
	{
		memw(r29+#4) = r4
		memw(r29+#0) = r5
	}
	{
		call hvx_dequant_i32_to_f32
		r4 = memw(r29+#120)
		r5 = memw(r29+#192)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.160:                             // %if.end973
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_163
	}
// %bb.161:                             // %if.then982
                                        //   in Loop: Header=BB15_138 Depth=1
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.162:                             // %if.then982
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_163:                             // %if.end989
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
	}
	{
		r3 = memw(r25+#56)
		if (cmp.eq(r3.new,#0)) jump:nt .LBB15_165
	}
// %bb.164:                             // %if.then995
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r4 = memw(r29+#116)
		r0 = memw(r29+#180)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r3+r4<<#2)
	}
	{
		r4 = addasl(r0,r3,#2)
		memw(r29+#180) = r4.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_165:                             // %for.inc1007
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r3 = memw(r29+#36)
		r5 = memw(r29+#144)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r5,r21)
		if (p0.new) r19 = #0
		r4 = memw(r29+#128)
		memw(r29+#116) = r5
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r2,r3)
		r0 = memw(r29+#132)
		memw(r29+#128) = r4.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,#4)
		if (!p0) jump:nt .LBB15_138
		memw(r29+#132) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_262
	}
	.falign
.LBB15_166:                             // %for.body544.us.preheader
                                        //   in Loop: Header=BB15_138 Depth=1
	{
		r2 = memw(r29+#32)
		r0 = memw(r29+#136)
	}                                       // 4-byte Folded Reload
	{
		r3 = lsr(r17,#5)
		r24 = add(r3,r2)
		memw(r29+#168) = r1
		memw(r29+#252) = r4
	}                                       // 4-byte Folded Spill
	{
		r2 = asl(r0,#8)
		r1 = #0
		r0 = memw(r29+#68)
		memw(r29+#280) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r2 = extractu(r3,#23,#0)
		r0 = memw(r29+#244)
		memw(r29+#292) = r2
	}                                       // 4-byte Folded Reload
	{
		r24 = or(r0,and(r24,#127))
		r2 = asl(r2,#9)
		memw(r29+#196) = r3
		memw(r29+#248) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#212) = r1
		memw(r29+#40) = r2
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_167:                             // %for.body544.us
                                        //   Parent Loop BB15_138 Depth=1
                                        // =>  This Loop Header: Depth=2
                                        //       Child Loop BB15_168 Depth 3
                                        //         Child Loop BB15_169 Depth 4
                                        //           Child Loop BB15_171 Depth 5
                                        //         Child Loop BB15_187 Depth 4
                                        //         Child Loop BB15_194 Depth 4
                                        //         Child Loop BB15_216 Depth 4
	{
		r1 = #0
		r4 = memw(r29+#212)
		r0 = memw(r29+#172)
	}                                       // 4-byte Folded Reload
	{
		r3 = asl(r4,#7)
		p1 = tstbit(r0,#0)
		r6 = memw(r29+#136)
		memw(r29+#288) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = asl(r4,#6)
		r3 = p1
		r0 = memw(r29+#36)
		memw(r29+#232) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = asl(r4,#8)
		r5 = sub(r0,r2)
		p2 = cmp.gtu(r0,r2)
		memw(r29+#216) = r1
	}                                       // 4-byte Folded Spill
	{
		r6 = mpyi(r2,r6)
		r2 = mpyi(r2,r22)
		r1 = memw(r29+#44)
		memw(r29+#284) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,r3)
		r0 = #64
		r1 = memw(r29+#248)
		memw(r29+#224) = r1.new
	}                                       // 4-byte Folded Reload
	{
		r4 = minu(r5,r0)
		r0 = memw(r29+#120)
		memw(r29+#152) = r2
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,r3)
		if (!p2) r4 = #0
		r1 = memw(r29+#192)
		memw(r29+#184) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r1,r3)
		r0 = #0
		r1 = memw(r29+#196)
		memw(r29+#204) = r0.new
	}                                       // 4-byte Folded Reload
	{
		r0 = #0
		p0 = cmp.eq(r4,#0)
		r1 = memw(r29+#252)
		memw(r29+#208) = r1
	}                                       // 4-byte Folded Reload
	{
		r2 = addasl(r1,r6,#2)
		r0 = p0
		memw(r29+#188) = r2
		memw(r29+#200) = r0
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#276) = r2
		memw(r29+#124) = r4
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#264) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_168:                             // %for.body565.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        // =>    This Loop Header: Depth=3
                                        //         Child Loop BB15_169 Depth 4
                                        //           Child Loop BB15_171 Depth 5
                                        //         Child Loop BB15_187 Depth 4
                                        //         Child Loop BB15_194 Depth 4
                                        //         Child Loop BB15_216 Depth 4
	{
		r16 = #0
		r2 = memw(r29+#196)
		r3 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r2 = sub(r2,r3)
		r0 = memw(r29+#172)
		r1 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r2,r1)
		r5 = and(r0,#1)
		r0 = memw(r29+#208)
		memw(r29+#164) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = minu(r1,r0)
		p0 = cmp.eq(r2,#0)
		r1 = memw(r29+#220)
		memw(r29+#156) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = p0
		r4 = memw(r29+#64)
		r17 = memw(r29+#204)
	}                                       // 4-byte Folded Reload
	{
		r4 += mpyi(r1,r5)
		memw(r29+#240) = r5
		memw(r29+#228) = r0
	}                                       // 4-byte Folded Spill
	{
		if (p0) jump:nt .LBB15_185
		memw(r29+#160) = r4
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_169:                             // %for.body582.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        // =>      This Loop Header: Depth=4
                                        //           Child Loop BB15_171 Depth 5
	{
		r2 = memw(r29+#88)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.gtu(r2,#31)
	}
	{
		r2 = p1
	}
	{
		call hexkl_micro_hmx_acc_clear_int32
		r19 = r2
	}
	.falign
// %bb.170:                             // %for.body582.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r2 = r19
		r26 = memw(r29+#168)
		r18 = memw(r29+#96)
	}                                       // 4-byte Folded Reload
	{
		p0 = r2
		if (!p0.new) jump:t .LBB15_176
		r27 = memw(r29+#140)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_171:                             // %for.body587.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        //         Parent Loop BB15_169 Depth=4
                                        // =>        This Inner Loop Header: Depth=5
	{
		r3 = add(r0,r26)
		r2 = r27
		p2 = cmp.eq(r24,#0)
		if (p2.new) jump:nt .LBB15_174
	}
// %bb.172:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		call hexkl_micro_hmx_mm_u8i4
		r2 = add(r17,r27)
		r1 = r26
	}
	.falign
// %bb.173:                             // %mm_u8i4_tile.exit.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		p1 = cmp.eq(r0,#0); if (p1.new) jump:t .LBB15_175
	}
	{
		jump .LBB15_235
	}
	.falign
.LBB15_174:                             // %mm_u8i4_tile.exit.thread.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		r4 = #31
		r5 = #384
	}
	{
		r2 += add(r0,r17)
	}
	//# InlineAsm Start
	{
		activation.ub = mxmem(r3,r4):cm
		weight.n = mxmem(r2,r5)
	}

	//# InlineAsm End
	.falign
.LBB15_175:                             // %for.inc606.us
                                        //   in Loop: Header=BB15_171 Depth=5
	{
		r26 = add(r26,#2048)
		r2 = memw(r29+#40)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r27 = add(r27,r2)
		r18 = add(r18,#-1)
		if (!cmp.eq(r18.new,#0)) jump:t .LBB15_171
	}
	.falign
.LBB15_176:                             // %do.body611.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_179
	}
// %bb.177:                             // %if.then613.us
                                        //   in Loop: Header=BB15_169 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.178:                             // %if.then613.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_179:                             // %do.end617.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r2 = memw(r29+#160)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r2 += asl(r16,#13)
		call hexkl_micro_hmx_acc_read_int32
		r1 = memw(r29+#100)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.180:                             // %do.end617.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r19 = r0
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_183
	}
// %bb.181:                             // %if.then623.us
                                        //   in Loop: Header=BB15_169 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.182:                             // %if.then623.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#0)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#0) = r1:0
	}
	.falign
.LBB15_183:                             // %do.end629.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r17 = add(r17,#512)
		r16 = add(r16,#1)
		p0 = cmp.eq(r19,#0); if (!p0.new) jump:nt .LBB15_236
	}
// %bb.184:                             // %for.cond578.us
                                        //   in Loop: Header=BB15_169 Depth=4
	{
		r2 = memw(r29+#156)
		if (!cmp.eq(r2.new,r16)) jump:t .LBB15_169
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_185:                             // %for.end638.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#92)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r16 = add(r0,r3)
		r2 = memw(r2+#20)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_189
	}
// %bb.186:                             // %land.lhs.true641.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r18 = r16
		r2 = memw(r29+#48)
		r3 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p0 = r3
		r0 = memw(r29+#236)
		r17 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p0)
		r2 = memw(r2+#4)
		r19 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r2,#0)
	}
	{
		p0 = not(p1)
		p1 = r0
	}
	{
		p2 = and(p1,and(p0,p2))
		if (!p2.new) jump:t .LBB15_189
	}
	.falign
.LBB15_187:                             // %for.body652.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		r2 = memw(r29+#48)
		r3 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r3 = #32
		r4 = memw(r2+#8)
		r6 = memw(r3+#20)
	}
	{
		r0 = addasl(r18,r4,#2)
		r4 = add(r6,r17)
		r1 = memw(r2+#12)
		r2 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	{
		call hexkl_wh_affine_acc
		r5 = memw(r29+#152)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.188:                             // %for.body652.us
                                        //   in Loop: Header=BB15_187 Depth=4
	{
		r17 = add(r17,#128)
		r18 = add(r18,#8192)
		r19 = add(r19,#-1)
		if (!cmp.eq(r19.new,#0)) jump:t .LBB15_187
	}
	.falign
.LBB15_189:                             // %if.end667.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#236)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (!p2.new) jump:t .LBB15_203
		if (!p2.new) r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
// %bb.190:                             // %if.else805.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#4)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_214
	}
// %bb.191:                             // %for.cond810.preheader.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) jump:nt .LBB15_233
		if (!p2.new) r2 = memw(r29+##264)
	}                                       // 4-byte Folded Reload
// %bb.192:                             // %for.cond810.preheader.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		p2 = r2
		if (!p2.new) r17 = #0
		if (p2.new) jump:nt .LBB15_233
		if (!p2.new) r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
// %bb.193:                             // %for.body819.lr.ph.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
		r18 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		r19 = memw(r29+#224)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_194:                             // %for.body819.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p2 = cmp.eq(r2,#0)
		r0 = memw(r29+#48)
	}                                       // 4-byte Folded Reload
	{
		if (p2) jump:nt .LBB15_197
		r26 = memw(r0+#8)
	}
// %bb.195:                             // %if.then829.us
                                        //   in Loop: Header=BB15_194 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.196:                             // %if.then829.us
                                        //   in Loop: Header=BB15_194 Depth=4
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_197:                             // %do.end833.us
                                        //   in Loop: Header=BB15_194 Depth=4
	{
		r0 = asl(r26,#2)
		r2 = memw(r29+#48)
		r4 = memw(r29+#92)
	}                                       // 4-byte Folded Reload
	{
		r0 = add(r16,r0)
		r5 = memw(r25+#12)
		r6 = memw(r29+#136)
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r2+#12)
		r3:2 = memd(r4+#8)
	}
	{
		r2 = add(r2,r18)
		r5 = add(r3,r18)
		r4 = memw(r4+#16)
		memw(r29+#16) = r5

	} :mem_noshuf
	{
		r3 = add(r4,r18)
		r2 = memw(r29+#124)
		memw(r29+#0) = r2
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#184)
		memw(r29+#4) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#188)
		memw(r29+#12) = r6
	}                                       // 4-byte Folded Reload
	{
		call hvx_dequant_acc_tile_to_f32
		memw(r29+#8) = r19
	}
	.falign
// %bb.198:                             // %do.end833.us
                                        //   in Loop: Header=BB15_194 Depth=4
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_201
	}
// %bb.199:                             // %if.then849.us
                                        //   in Loop: Header=BB15_194 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.200:                             // %if.then849.us
                                        //   in Loop: Header=BB15_194 Depth=4
	{
		r3 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_202
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_201:                             //   in Loop: Header=BB15_194 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_202:                             // %do.end855.us
                                        //   in Loop: Header=BB15_194 Depth=4
	{
		r17 = add(r17,#1)
		r18 = add(r18,#128)
		r16 = add(r16,#8192)
		r19 = add(r19,#128)
	}
	{
		r3 = memw(r29+#164)
		if (cmp.gtu(r3.new,r17)) jump:t .LBB15_194
	}                                       // 4-byte Folded Reload
	{
		jump .LBB15_233
	}
	.falign
.LBB15_203:                             // %do.body670.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_206
	}
// %bb.204:                             // %if.then672.us
                                        //   in Loop: Header=BB15_168 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.205:                             // %if.then672.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_206:                             // %do.end676.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		call hvx_worker_pool_wait
		r0 = memw(r25+#0)
	}
	.falign
// %bb.207:                             // %do.end676.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_210
	}
// %bb.208:                             // %if.then680.us
                                        //   in Loop: Header=BB15_168 Depth=3
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.209:                             // %if.then680.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_210:                             // %do.end686.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#264)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_233
		if (!p1.new) r2 = memw(r29+#240)
	}                                       // 4-byte Folded Reload
// %bb.211:                             // %if.then689.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r3 = add(r29,#312)
	}
	{
		r3 += mpyi(r2,#68)
		r2 = memw(r29+#272)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		if (p2.new) r2 = #0
		if (!p2.new) jump:t .LBB15_226
		if (p2.new) r5 = memw(r25+#56)
	}
// %bb.212:                             // %land.lhs.true696.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r4 = #0
		p1 = cmp.eq(r5,#0)
		if (!p1.new) r2 = memw(r29+#116)
		r6 = memw(r29+#180)
	}                                       // 4-byte Folded Reload
	{
		if (!p1) r2 = memw(r5+r2<<#2)
	}
	{
		r5 = memw(r25+#72)
		memw(r3+#12) = r2
	}
	{
		r0 = memw(r29+#116)
		memw(r3+#0) = r6
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.gtu(r5,r0)
		r5 = memw(r25+#64)
		memw(r3+#20) = r5.new
	}
	{
		if (!p0) jump:nt .LBB15_227
		r5 = memw(r25+#68)
		memw(r3+#16) = r5.new
	}
// %bb.213:                             // %cond.true712.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r6 = memw(r29+#288)
		r4 = memw(r25+#76)
	}                                       // 4-byte Folded Reload
	{
		r5 = mpyi(r6,r5)
	}
	{
		r4 = addasl(r4,r5,#2)
		jump .LBB15_227
	}
	.falign
.LBB15_214:                             // %for.cond862.preheader.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#228)
	}                                       // 4-byte Folded Reload
	{
		p1 = r2
		if (!p1.new) r4 = #0
		if (p1.new) jump:nt .LBB15_233
		if (!p1.new) r3 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
// %bb.215:                             // %do.body867.us.preheader
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#220)
	}                                       // 4-byte Folded Reload
	{
		r2 = +mpyi(r2,#1)
		r3 = memw(r3+##hexkl_probe_on@GOT)
		r26 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r5 = memw(r29+#232)
		r0 = memw(r29+#64)
	}                                       // 4-byte Folded Reload
	{
		p0 = r5
		if (!p0.new) r2 = add(r4,#0)
	}
	{
		r27 = add(r0,r2)
		r2 = memw(r3+#0)
	}
	.falign
.LBB15_216:                             // %do.body867.us
                                        //   Parent Loop BB15_138 Depth=1
                                        //     Parent Loop BB15_167 Depth=2
                                        //       Parent Loop BB15_168 Depth=3
                                        // =>      This Inner Loop Header: Depth=4
	{
		p0 = cmp.eq(r2,#0); if (p0.new) jump:nt .LBB15_219
	}
// %bb.217:                             // %if.then869.us
                                        //   in Loop: Header=BB15_216 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.218:                             // %if.then869.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_219:                             // %do.end873.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		r1 = r27
		r4 = r26
		r2 = memw(r29+#92)
		r0 = memw(r29+#32)
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#212)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+#32)
		memw(r29+#0) = r2.new
	}
	{
		call hexkl_micro_hmx_copy_32b_to_submatrix
		r2 = memw(r29+#56)
		r5 = memw(r29+#60)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.220:                             // %do.end873.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		r19 = r0
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_223
	}
// %bb.221:                             // %if.then881.us
                                        //   in Loop: Header=BB15_216 Depth=4
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.222:                             // %if.then881.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		r3 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r3+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#8)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#8) = r1:0
	}
	{
		r2 = memw(r3+##hexkl_probe_on@GOT)
	}
	{
		jump .LBB15_224
		r2 = memw(r2+#0)
	}
	.falign
.LBB15_223:                             //   in Loop: Header=BB15_216 Depth=4
	{
		r2 = #0
	}
	.falign
.LBB15_224:                             // %do.end887.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		r26 = add(r26,#1)
		r27 = add(r27,#8192)
		p1 = cmp.eq(r19,#0); if (!p1.new) jump:nt .LBB15_236
	}
// %bb.225:                             // %for.cond862.us
                                        //   in Loop: Header=BB15_216 Depth=4
	{
		r3 = memw(r29+#156)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#-1)
		memw(r29+#156) = r3.new
	}                                       // 4-byte Folded Spill
	{
		p1 = cmp.eq(r3,#0); if (!p1.new) jump:t .LBB15_216
	}
	{
		jump .LBB15_233
	}
	.falign
.LBB15_226:                             // %cond.end703.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r2 = memw(r29+#180)
		memw(r3+#0) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r25+#64)
		memw(r3+#20) = r2.new
	}
	{
		r2 = memw(r25+#68)
		memw(r3+#16) = r2.new
	}
	{
		r2 = #0
		memw(r3+#12) = #0
	}
	.falign
.LBB15_227:                             // %cond.end718.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r5 = memw(r29+#164)
		memw(r3+#4) = r4
	}                                       // 4-byte Folded Reload
	{
		r5 = asl(r5,#5)
		memw(r3+#8) = r5.new
	}
	{
		r5 = memw(r29+#268)
	}                                       // 4-byte Folded Reload
	{
		p1 = r5
		if (p1.new) r6 = #0
		if (!p1.new) jump:t .LBB15_229
		if (!p1.new) r5 = memw(r25+#80)
	}
// %bb.228:                             // %cond.end727.us.thread
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r5 = memw(r25+#84)
		memw(r3+#28) = r5.new
	}
	{
		r5 = #0 ; jump .LBB15_230
		memw(r3+#24) = #0
		memw(r3+#32) = #0
	}
	.falign
.LBB15_229:                             // %cond.true738.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r7 = memw(r29+#280)
		r6 = memw(r25+#84)
	}                                       // 4-byte Folded Reload
	{
		memw(r3+#32) = r7
	}
	{
		r7 = memw(r29+#284)
		memw(r3+#28) = r6
	}                                       // 4-byte Folded Reload
	{
		r5 = addasl(r5,r7,#2)
		r6 = memw(r25+#44)
		memw(r3+#24) = r5.new
	}
	{
		r7 = memw(r29+#116)
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r6+r7<<#2)
		r7 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r6 = addasl(r6,r7,#5)
	}
	.falign
.LBB15_230:                             // %cond.end744.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r5 |= or(r2,r4)
		r7 = memw(r29+#144)
		r9 = memw(r29+#200)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(pc,##fc_row_post@PCREL)
		r0 = cmp.eq(r9,#0)
		r12 = memw(r29+#164)
	}                                       // 4-byte Folded Reload
	{
		p0 = cmp.eq(r7,r21)
		p1 = cmp.eq(r5,#0)
		r1 = memw(r29+#116)
		memw(r3+#36) = r6
	}                                       // 4-byte Folded Reload
	{
		r6 = or(r9,r1)
		r2 = add(r12,r9)
		r0 = memw(r29+#240)
		memw(r3+#52) = r0
	}                                       // 4-byte Folded Reload
	{
		r6 = cmp.eq(r6,#0)
		r8 = memw(r29+#196)
		r1 = memw(r25+#88)
	}                                       // 4-byte Folded Reload
	{
		p2 = cmp.eq(r2,r8)
		r2 = cmp.eq(r2,r8)
		memw(r3+#44) = r6
		memw(r3+#60) = r1
	}
	{
		r7 = +mpyi(r0,#76)
		p0 = and(p0,p2)
		r6 = add(r29,#448)
		r1 = memw(r25+#92)
	}
	{
		r2 = add(r6,r7)
		memw(r3+#56) = r2
		memw(r3+#40) = r22
	}
	{
		r5 = mux(p0,#1,#0)
		if (p1) r4 = #0
		memw(r3+#64) = r1
		memw(r2+#64) = r3
	}
	{
		memw(r3+#48) = r5
	}
	{
		r3 = memw(r29+#32)
		memw(r2+#60) = r4
	}                                       // 4-byte Folded Reload
	{
		r1 = memw(r29+#48)
		r0 = memw(r29+#160)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,r0)
	}
	{
		r0 = memw(r1+#8)
		memw(r2+#4) = ##8192

	} :mem_noshuf
	{
		r3 = addasl(r3,r0,#2)
		memw(r6+r7<<#0) = r3.new
	}
	{
		memw(r2+#8) = r9
		r3 = memw(r1+#12)

	} :mem_noshuf
	{
		r7 = memw(r29+#124)
		memw(r2+#12) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#184)
		memw(r2+#16) = r7
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#92)
		memw(r2+#20) = r3
	}                                       // 4-byte Folded Reload
	{
		r6 = memw(r29+#188)
		memw(r2+#44) = #0
	}                                       // 4-byte Folded Reload
	{
		r1:0 = memd(r3+#8)
		memw(r2+#24) = r6
	}
	{
		r5:4 = memd(r3+#16)
		memw(r2+#56) = r12
	}
	{
		r3 = memw(r3+#32)
		memw(r2+#28) = r1
	}
	{
		p0 = cmp.eq(r5,#0)
		r3 = memw(r29+#136)
		memw(r2+#48) = r3
	}                                       // 4-byte Folded Reload
	{
		r3 = memw(r29+#72)
		memw(r2+#52) = r3
	}                                       // 4-byte Folded Reload
	{
		r4 = memw(r29+#276)
		memw(r2+#36) = r4
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#32) = r0
		memw(r2+#40) = r4
	}
	{
		if (p0) jump:nt .LBB15_232
		r1 = memw(r3+##hvx_dq_tiles_rows_worker@GOT)
	}
// %bb.231:                             // %if.then796.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r1 = add(pc,##fc_affine_worker@PCREL)
		r3 = memw(r29+#152)
		memw(r2+#68) = r5
	}                                       // 4-byte Folded Reload
	{
		memw(r2+#72) = r3
	}
	.falign
.LBB15_232:                             // %for.inc904.us.sink.split
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		call hvx_worker_pool_submit
		r0 = memw(r25+#0)
		r3 = memw(r29+#124)
	}                                       // 4-byte Folded Reload
	.falign
.LBB15_233:                             // %for.inc904.us
                                        //   in Loop: Header=BB15_168 Depth=3
	{
		r4 = memw(r29+#200)
		r2 = memw(r29+#52)
	}                                       // 4-byte Folded Reload
	{
		r4 = add(r4,r2)
		r3 = memw(r29+#172)
		r0 = memw(r29+#196)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r3,#1)
		p0 = cmp.gtu(r0,r4)
		r1 = memw(r29+#208)
		memw(r29+#172) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r3 = sub(r1,r2)
		r1 = memw(r29+#256)
		memw(r29+#208) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#204)
		memw(r29+#200) = r4
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		r0 = memw(r29+#232)
		memw(r29+#204) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p2 = r0
		r2 = memw(r29+#260)
		r1 = memw(r29+#216)
	}                                       // 4-byte Folded Reload
	{
		p2 = not(p2)
		r3 = add(r1,r2)
		r0 = memw(r29+#224)
		memw(r29+#216) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r1 = p2
		r3 = add(r0,r2)
		if (!p0) r2 = memw(r29+#108)
		memw(r29+#232) = r1.new
	}                                       // 4-byte Folded Reload
	{
		if (p0) jump:nt .LBB15_168
		if (!p0) r3 = memw(r29+#212)
		memw(r29+#224) = r3
	}                                       // 4-byte Folded Reload
// %bb.234:                             // %for.cond561.for.inc913_crit_edge.us
                                        //   in Loop: Header=BB15_167 Depth=2
	{
		r3 = add(r3,#1)
		r0 = memw(r29+#112)
		memw(r29+#212) = r3.new
	}                                       // 4-byte Folded Reload
	{
		p1 = cmp.eq(r3,r2)
		r1 = memw(r29+#168)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r1,r0)
		r0 = memw(r29+#280)
		memw(r29+#168) = r3.new
	}                                       // 4-byte Folded Reload
	{
		r2 = add(r0,#8192)
		r1 = memw(r29+#292)
		memw(r29+#280) = r2.new
	}                                       // 4-byte Folded Reload
	{
		r0 = memw(r29+#248)
	}                                       // 4-byte Folded Reload
	{
		r3 = add(r0,r1)
		if (!p1) jump:nt .LBB15_167
		memw(r29+#248) = r3.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_144
	}
	.falign
.LBB15_235:
	{
		r19 = r0
	}
	.falign
.LBB15_236:                             // %do.body1012
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_239
	}
// %bb.237:                             // %if.then1014
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.238:                             // %if.then1014
	{
		memd(r29+#304) = r1:0
	}                                       // 8-byte Folded Spill
	.falign
.LBB15_239:                             // %do.end1018
	{
		call hvx_worker_pool_wait
		r0 = memw(r25+#0)
	}
	.falign
// %bb.240:                             // %do.end1018
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_on@GOT)
	}
	{
		r2 = memw(r2+#0)
		if (cmp.eq(r2.new,#0)) jump:nt .LBB15_243
	}
// %bb.241:                             // %if.then1022
	//# InlineAsm Start
	{
		r1:0 = c31:30
	}
	//# InlineAsm End
	{
		call HAP_perf_qtimer_count_to_us
	}
	.falign
// %bb.242:                             // %if.then1022
	{
		r2 = memw(r29+#72)
	}                                       // 4-byte Folded Reload
	{
		r2 = memw(r2+##hexkl_probe_us@GOT)
		r5:4 = memd(r29+#304)
	}                                       // 8-byte Folded Reload
	{
		r1:0 = sub(r1:0,r5:4)
	}
	{
		r7:6 = memd(r2+#16)
	}
	{
		r1:0 = add(r1:0,r7:6)
	}
	{
		memd(r2+#16) = r1:0
	}
	.falign
.LBB15_243:                             // %cleanup1029
	{
		call free
		r0 = memw(r29+#80)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.244:                             // %cleanup1029
	{
		call free
		r0 = memw(r29+#76)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.245:                             // %cleanup1029
	{
		call free
		r0 = memw(r29+#56)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.246:                             // %cleanup1029
	{
		call free
		r0 = memw(r29+#68)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.247:                             // %cleanup1029
	{
		call free
		r0 = memw(r29+#44)
	}                                       // 4-byte Folded Reload
	.falign
// %bb.248:                             // %cleanup1029
	{
		jump .LBB15_38
	}
	.falign
.LBB15_249:                             // %land.end410
	{
		p0 = and(p0,!p0)
		r2 = memw(r25+#52)
	}
	{
		r0 = p0
		p2 = cmp.eq(r2,#0)
		if (p2.new) jump:nt .LBB15_261
		memw(r29+#236) = r0.new
	}                                       // 4-byte Folded Spill
// %bb.250:                             // %for.body421.lr.ph
	{
		p0 = or(p0,!p0)
		r24 = #1
		r2 = memw(r29+#52)
		r16 = memw(r25+#56)
	}                                       // 4-byte Folded Reload
	{
		r19 = asl(r2,#5)
		r1 = p0
		p0 = cmp.eq(r16,#0)
		r17 = memw(r25+#72)
	}
	{
		r0 = p0
		memw(r29+#268) = r1
	}                                       // 4-byte Folded Spill
	{
		memw(r29+#40) = r0
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_251:                             // %for.body421
                                        // =>This Inner Loop Header: Depth=1
	{
		r26 = #0
		r1 = #0
		r2 = memw(r29+#40)
	}                                       // 4-byte Folded Reload
	{
		p2 = r2
		r2 = add(r24,#-1)
		if (!p2.new) r1 = memw(r16+#0)
	}
	{
		p0 = cmp.gtu(r17,r2)
		p1 = cmp.eq(r1,#0); if (p1.new) jump:nt .LBB15_254
		if (p0.new) r26 = memw(r25+#68)
	}
// %bb.252:                             // %lor.lhs.false443
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		call __hexagon_umodsi3
		r0 = r19
	}
	.falign
// %bb.253:                             // %lor.lhs.false443
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		p2 = cmp.eq(r0,#0)
		if (!p2.new) jump:nt .LBB15_263
	}
	.falign
.LBB15_254:                             // %land.rhs447
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		p0 = or(p0,!p0)
		p1 = cmp.eq(r26,#0)
		if (!p1.new) r1:0 = combine(r26,r19)
		if (p1.new) jump:nt .LBB15_257
	}
// %bb.255:                             // %lor.rhs
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		call __hexagon_umodsi3
	}
	.falign
// %bb.256:                             // %lor.rhs
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		p0 = cmp.eq(r0,#0)
	}
	.falign
.LBB15_257:                             // %land.end453
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		if (p0) r16 = add(r16,#4)
		if (!p0) jump:nt .LBB15_259
	}
// %bb.258:                             // %land.end453
                                        //   in Loop: Header=BB15_251 Depth=1
	{
		p2 = cmp.gtu(r21,r24)
		r24 = add(r24,#1)
		if (p2.new) jump:t .LBB15_251
	}
	.falign
.LBB15_259:                             // %for.cond.cleanup420
	{
		if (!p0) jump:nt .LBB15_264
		if (p0) r3 = memw(r25+#52)
		if (p0) r2 = memw(r25+#80)
	}
// %bb.260:                             // %if.then467
	{
		p0 = or(p0,!p0)
		p1 = cmp.eq(r2,#0)
	}
	{
		r0 = p0
		memw(r29+#272) = r0.new
	}                                       // 4-byte Folded Spill
	{
		r2 = p1
		memw(r29+#268) = r2.new
	}                                       // 4-byte Folded Spill
	{
		jump .LBB15_130
		memw(r3+#0) = #1
	}
	.falign
.LBB15_261:
	{
		p1 = and(p1,!p1)
	}
	{
		r2 = p1
		jump .LBB15_130
		memw(r29+#272) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_262:
	{
		jump .LBB15_236
	}
	.falign
.LBB15_263:
	{
		p0 = and(p0,!p0)
	}
	{
		r2 = p0
		jump .LBB15_130
		memw(r29+#272) = r2.new
	}                                       // 4-byte Folded Spill
	.falign
.LBB15_264:
	{
		p2 = and(p2,!p2)
	}
	{
		r2 = p2
		jump .LBB15_130
		memw(r29+#272) = r2.new
	}                                       // 4-byte Folded Spill

#ifndef HAP_PERF_H
#define HAP_PERF_H
#include <stdint.h>
static uint64_t lfm_test_clock;
static uint64_t lfm_test_step = 1;
static inline uint64_t HAP_perf_get_qtimer_count(void) {return lfm_test_clock += lfm_test_step;}
static inline uint64_t HAP_perf_qtimer_count_to_us(uint64_t t) {return t;}
#endif

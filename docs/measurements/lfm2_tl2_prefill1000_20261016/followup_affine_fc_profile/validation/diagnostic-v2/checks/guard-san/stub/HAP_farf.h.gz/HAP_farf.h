#ifndef HAP_FARF_H
#define HAP_FARF_H
void lfm_test_log(const char *, ...);
#define FARF(level, ...) lfm_test_log(__VA_ARGS__)
#endif

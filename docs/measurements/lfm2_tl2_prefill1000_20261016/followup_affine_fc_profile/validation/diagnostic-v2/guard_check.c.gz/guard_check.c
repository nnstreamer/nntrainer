// SPDX-License-Identifier: Apache-2.0
/* The actual diagnostic helper in the whole production TU, not a mirror. */
#include <assert.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include NNTR_TEST_SOURCE

uint64_t hexkl_probe_us[HEXKL_PROBE_N];
int hexkl_probe_on = 17;
static hexkl_weight_u8i4_table table;

static unsigned max_geometry, max_timing;
void lfm_test_log(const char *format, ...) {
  char buffer[1024];
  va_list ap;
  va_start(ap, format);
  const int n = vsnprintf(buffer, sizeof(buffer), format, ap);
  va_end(ap);
  assert(n > 0 && n <= 192);
  assert(n + 64 + 1 <= 256); /* reserve64 prefix bytes and NUL */
  assert(buffer[n - 1] == '!');
  if (strstr(buffer, "[LFM-AFC2G]")) {
    if ((unsigned)n > max_geometry)
      max_geometry = (unsigned)n;
  } else {
    assert(strstr(buffer, "[LFM-AFC2T]"));
    if ((unsigned)n > max_timing)
      max_timing = (unsigned)n;
  }
  puts(buffer);
}

int main(void) {
  const uint32_t handles[4] = {0u, 1u, 2u, 3u};
  int32_t offset = 0;
  uint8_t byte = 0;
  for (unsigned c = 0; c < 25; ++c) {
    uint32_t M = 1024, K = 2048, nh = 1;
    hexkl_mm_opts opts = {0};
    for (unsigned i = 0; i < 4; ++i) {
      memset(&table.slots[i], 0, sizeof(table.slots[i]));
      table.slots[i].in_use = 1;
      table.slots[i].K = 2048;
      table.slots[i].N = 2048;
      table.slots[i].bits = 4;
      table.slots[i].w_offset = &offset;
    }
    const int expected = c < 7;
    switch (c) {
    case 0:
      break;
    case 1:
      M = 64;
      table.slots[0].N = 512;
      break;
    case 2:
      M = 512;
      nh = 3;
      break;
    case 3:
      nh = 3;
      table.slots[1].N = table.slots[2].N = 512;
      break;
    case 4:
      M = 2;
      break;
    case 5:
      M = 1920;
      nh = 3;
      break;
    case 6:
      opts.act_scale = (const float *)&offset;
      opts.act_zp = &offset;
      break;
    case 7:
      M = 1;
      break;
    case 8:
      M = 0;
      break;
    case 9:
      K = 2816;
      break; // Gemma4 native MoE hidden width
    case 10:
      K = 4096;
      break;
    case 11:
      nh = 0;
      break;
    case 12:
      nh = 2;
      break;
    case 13:
      nh = 4;
      break;
    case 14:
      table.slots[0].bits = 2;
      break;
    case 15:
      table.slots[0].bits = 0;
      break;
    case 16:
      table.slots[0].w_offset = NULL;
      break;
    case 17:
      table.slots[0].tl2_bytes = &byte;
      break;
    case 18:
      opts.act_ah_prepacked = &byte;
      break;
    case 19:
      opts.act_u16 = (const uint16_t *)&offset;
      break;
    case 20:
      opts.accumulate = 1;
      break;
    case 21:
      table.slots[0].N = 4096;
      break;
    case 22:
      nh = 3;
      table.slots[2].N = 1024;
      break;
    case 23:
      nh = 3;
      table.slots[2].w_offset = NULL;
      break;
    case 24:
      nh = 3;
      table.slots[1].bits = 2;
      break;
    }
    hexkl_weight_u8i4 saved[4];
    memcpy(saved, table.slots, sizeof(saved));
    const hexkl_mm_opts saved_opts = opts;
    for (unsigned i = 0; i < HEXKL_PROBE_N; ++i)
      hexkl_probe_us[i] = 1000u + i;
    const uint64_t clock = lfm_test_clock;
    lfm_fc_trace t = lfm_fc_trace_begin(&table, M, K, handles, nh, &opts);
    assert(t.on == expected);
    assert(lfm_test_clock == clock + (unsigned)expected);
    lfm_fc_trace_end(&t, 0, 32, 32, 1);
    assert(lfm_test_clock == clock + (expected ? 66u : 0u));
    assert(!memcmp(saved, table.slots, sizeof(saved)));
    assert(!memcmp(&saved_opts, &opts, sizeof(opts)));
    assert(hexkl_probe_on == 17);
    for (unsigned i = 0; i < HEXKL_PROBE_N; ++i)
      assert(hexkl_probe_us[i] == 1000u + i);
  }
  /* Exercise the actual two printf calls at full type widths, not a copied
   * format estimate. Unsigned fake-clock wrap makes body and ID both64-bit. */
  lfm_fc_trace worst = {0};
  worst.on = 1;
  worst.M = worst.N = worst.nh = UINT32_MAX;
  worst.n[0] = worst.n[1] = worst.n[2] = UINT32_MAX;
  worst.reads = worst.joins = UINT32_MAX;
  worst.brackets = UINT32_MAX - 1u;
  worst.start = worst.pack = worst.sums = worst.read = UINT64_MAX;
  worst.join = worst.drain = UINT64_MAX;
  lfm_test_step = UINT64_MAX / 32u;
  lfm_test_clock = worst.start + UINT64_MAX - lfm_test_step;
  lfm_fc_trace_end(&worst, INT32_MIN, UINT32_MAX, UINT32_MAX, INT32_MIN);
  assert(max_geometry == 188u && max_timing == 167u);
  printf("actual-helper25 guards + full-width snprintf bounds PASS: G%u T%u "
         "bytes; prefix64+NUL within256\n",
         max_geometry, max_timing);
  return 0;
}

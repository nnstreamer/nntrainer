// Standalone audit fixture; no model or device access.
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <hexagon_sim_timer.h>

typedef void (*block_fn)(const float *, const float *, float *, uint32_t,
                         uint32_t, uint32_t, uint32_t);
extern block_fn audit_base;
extern block_fn audit_pipeline_off;
static float x[8*2048] __attribute__((aligned(128)));
static float w[2048*64] __attribute__((aligned(128)));
static float a[8*64+32] __attribute__((aligned(128)));
static float b[8*64+32] __attribute__((aligned(128)));
static uint32_t rng = 0x91cde25;
static uint32_t next_rand(void) {rng ^= rng<<13; rng^=rng>>17; rng^=rng<<5; return rng;}
static void run(block_fn f, float *out, unsigned K) {
  for (unsigned k0=0; k0<K; k0+=256)
    f(x+k0,w,out,K,64,k0,k0+256<K?k0+256:K);
}
int main(void) {
  const unsigned ks[]={1,2,17,255,256,257,511,512,2048};
  unsigned checks=0;
  for (unsigned p=0;p<4;++p) {
    for (unsigned i=0;i<sizeof(x)/sizeof(*x);++i) {
      x[i]=(float)((int)(next_rand()%65537)-32768)/32768.0f;
      if (p==1) x[i]*=0x1p-126f;
      if (p==2) x[i]*=0x1p60f;
      if (p==3) x[i]=(i&1)?-x[i]:x[i];
    }
    for (unsigned i=0;i<sizeof(w)/sizeof(*w);++i) {
      w[i]=(float)((int)(next_rand()%65537)-32768)/16384.0f;
      if (p==2) w[i]*=0x1p-60f;
    }
    for(unsigned k=0;k<sizeof(ks)/sizeof(*ks);++k) {
      memset(a,0xa5,sizeof(a));memset(b,0xa5,sizeof(b));
      run(audit_base,a,ks[k]);run(audit_pipeline_off,b,ks[k]);
      assert(memcmp(a,b,sizeof(a))==0);
      for(unsigned i=8*64;i<8*64+32;++i) {uint32_t v;memcpy(&v,a+i,4);assert(v==0xa5a5a5a5);}
      ++checks;
    }
  }
  for(unsigned i=0;i<sizeof(x)/sizeof(*x);++i) x[i]=(float)((int)(next_rand()%65537)-32768)/32768.0f;
  for(unsigned i=0;i<sizeof(w)/sizeof(*w);++i) w[i]=(float)((int)(next_rand()%65537)-32768)/16384.0f;
  run(audit_base,a,2048);run(audit_pipeline_off,b,2048);
  const unsigned repeats=8;
  uint64_t t0=hexagon_sim_read_pcycles();
  for(unsigned r=0;r<repeats;++r) run(audit_base,a,2048);
  uint64_t t1=hexagon_sim_read_pcycles();
  for(unsigned r=0;r<repeats;++r) run(audit_pipeline_off,b,2048);
  uint64_t t2=hexagon_sim_read_pcycles();
  assert(memcmp(a,b,8*64*4)==0);
  printf("exact_checks=%u repeats=%u base_cycles=%llu pipeline_off_cycles=%llu\n",checks,repeats,(unsigned long long)(t1-t0),(unsigned long long)(t2-t1));
  return 0;
}

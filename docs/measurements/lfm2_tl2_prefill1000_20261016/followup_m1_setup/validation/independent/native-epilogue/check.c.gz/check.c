// SPDX-License-Identifier: Apache-2.0
/* Independent review-only test: actual GU epilogue on SDK libnative. */
#include "hvx_dequant_i32.h"
#include <assert.h>
#include <sanitizer/asan_interface.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

enum { I = 1536, NP = I / 32, ROWS = 4, PARAMS = 64 };
static int32_t tiles[2 * NP][ROWS * 32] __attribute__((aligned(128)));
static float scale[PARAMS] __attribute__((aligned(128)));
static int32_t zp[PARAMS] __attribute__((aligned(128)));
static float ws[2 * I], bias[2 * I];
static int32_t cs[2 * I];
static float expected[ROWS][I] __attribute__((aligned(128)));
static float actual[ROWS][I] __attribute__((aligned(128)));

int main(void) {
  const unsigned pairs[] = {1, 3, NP};
  const float scales[] = {0.0f, 0.0001f, 0x1p-120f, 0.125f};
  unsigned cases = 0;
  for (unsigned i = 0; i < 2u * NP; ++i)
    for (unsigned r = 0; r < ROWS * 32u; ++r)
      tiles[i][r] = (int32_t)((i * 7891u + r * 911u) % 997531u) - 498766;
  for (unsigned n = 0; n < 2u * I; ++n) {
    ws[n] = 0.001f * (float)(1u + n % 7u);
    bias[n] = 0.03125f * ((float)(n % 17u) - 8.0f);
    cs[n] = (int32_t)(n % 2049u) - 1024;
  }
  for (unsigned pi = 0; pi < 3; ++pi)
    for (unsigned si = 0; si < 4; ++si)
      for (unsigned lanes = 1; lanes <= 8; ++lanes) {
        memset(expected, 0xa5, sizeof expected);
        memset(actual, 0xa5, sizeof actual);
        for (unsigned r = 0; r < PARAMS; ++r) {
          scale[r] = r ? 1.0f : scales[si];
          zp[r] = r ? 0 : 127 + (int32_t)si;
        }
        hvx_dq_swiglu_job job = {(const uint8_t *)tiles,
                                 sizeof tiles[0],
                                 pairs[pi],
                                 0u,
                                 32u,
                                 1u,
                                 scale,
                                 zp,
                                 cs,
                                 ws,
                                 bias,
                                 I,
                                 &expected[0][0],
                                 I,
                                 HVX_GLU_SILU};
        hvx_dq_swiglu_worker(1u, 0u, &job);
        __asan_poison_memory_region(scale + 1, sizeof scale - sizeof *scale);
        __asan_poison_memory_region(zp + 1, sizeof zp - sizeof *zp);
        for (unsigned t = 0; t < 2u * NP; ++t)
          __asan_poison_memory_region(tiles[t] + 32,
                                      3u * 32u * sizeof(int32_t));
        __asan_poison_memory_region(actual[1], 3u * I * sizeof(float));
        job.dst = actual[0];
        for (unsigned lane = 0; lane < lanes; ++lane)
          hvx_dq_swiglu_worker(lanes, lane, &job);
        __asan_unpoison_memory_region(scale, sizeof scale);
        __asan_unpoison_memory_region(zp, sizeof zp);
        __asan_unpoison_memory_region(tiles, sizeof tiles);
        __asan_unpoison_memory_region(actual, sizeof actual);
        assert(memcmp(expected, actual, sizeof actual) == 0);
        ++cases;
      }
  printf("NATIVE_M1_EPILOGUE %u bit-exact poisoned padding cases PASS\n",
         cases);
  return 0;
}

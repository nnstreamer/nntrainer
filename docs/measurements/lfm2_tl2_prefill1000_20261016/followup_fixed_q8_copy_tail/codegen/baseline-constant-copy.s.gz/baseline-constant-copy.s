	.text
	.attribute	4, 81	// Tag_arch
	.attribute	5, 81	// Tag_hvx_arch
	.attribute	7, 1	// Tag_hvx_qfloat
	.attribute	1001, 81	// Tag_hmx_arch
	.file	"constant-copy.c"
	.globl	copy128                         // -- Begin function copy128
	.balign 32
	.type	copy128,@function
copy128:                                // @copy128
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v0 = vmemu(r1+#0)
	}
	{
		v1 = vsplat(r2)
	}
	{
		v2 = vxor(v0,v1)
	}
	{
		jumpr r31
		vmemu(r0+#0) = v2
	}
.Lfunc_end0:
	.size	copy128, .Lfunc_end0-copy128
                                        // -- End function
	.globl	copy256                         // -- Begin function copy256
	.balign 32
	.type	copy256,@function
copy256:                                // @copy256
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v0 = vmemu(r1+#0)
	}
	{
		v1 = vsplat(r2)
	}
	{
		v2 = vxor(v0,v1)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v1)
	}
	{
		jumpr r31
		vmemu(r0+#1) = v4
	}
.Lfunc_end1:
	.size	copy256, .Lfunc_end1-copy256
                                        // -- End function
	.globl	copy512                         // -- Begin function copy512
	.balign 32
	.type	copy512,@function
copy512:                                // @copy512
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v0 = vmemu(r1+#0)
	}
	{
		v1 = vsplat(r2)
	}
	{
		v2 = vxor(v0,v1)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v1)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v1)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v1)
	}
	{
		jumpr r31
		vmemu(r0+#3) = v8
	}
.Lfunc_end2:
	.size	copy512, .Lfunc_end2-copy512
                                        // -- End function
	.globl	copy1024                        // -- Begin function copy1024
	.falign
	.type	copy1024,@function
copy1024:                               // @copy1024
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v0 = vmemu(r1+#0)
	}
	{
		v1 = vsplat(r2)
	}
	{
		v2 = vxor(v0,v1)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v1)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v1)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v1)
	}
	{
		vmemu(r0+#3) = v8
	}
	{
		v9 = vmemu(r1+#4)
	}
	{
		v10 = vxor(v9,v1)
	}
	{
		vmemu(r0+#4) = v10
	}
	{
		v11 = vmemu(r1+#5)
	}
	{
		v12 = vxor(v11,v1)
	}
	{
		vmemu(r0+#5) = v12
	}
	{
		v13 = vmemu(r1+#6)
	}
	{
		v14 = vxor(v13,v1)
	}
	{
		vmemu(r0+#6) = v14
	}
	{
		v15 = vmemu(r1+#7)
	}
	{
		v16 = vxor(v15,v1)
	}
	{
		jumpr r31
		vmemu(r0+#7) = v16
	}
.Lfunc_end3:
	.size	copy1024, .Lfunc_end3-copy1024
                                        // -- End function
	.globl	copy2048                        // -- Begin function copy2048
	.falign
	.type	copy2048,@function
copy2048:                               // @copy2048
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v1 = vmemu(r1+#0)
	}
	{
		v0 = vsplat(r2)
		r2 = add(r1,#1024)
	}
	{
		v2 = vxor(v1,v0)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v0)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v0)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v0)
	}
	{
		vmemu(r0+#3) = v8
	}
	{
		v9 = vmemu(r1+#4)
	}
	{
		v10 = vxor(v9,v0)
	}
	{
		vmemu(r0+#4) = v10
	}
	{
		v11 = vmemu(r1+#5)
	}
	{
		v12 = vxor(v11,v0)
	}
	{
		vmemu(r0+#5) = v12
	}
	{
		v13 = vmemu(r1+#6)
	}
	{
		v14 = vxor(v13,v0)
	}
	{
		vmemu(r0+#6) = v14
	}
	{
		v15 = vmemu(r1+#7)
	}
	{
		v16 = vxor(v15,v0)
	}
	{
		vmemu(r0+#7) = v16
	}
	{
		r2 = add(r0,#1024)
		v17 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v17,v0)
	}
	{
		r2 = add(r1,#1152)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#1152)
		v19 = vmemu(r2+#0)
	}
	{
		v20 = vxor(v19,v0)
	}
	{
		r2 = add(r1,#1280)
		vmemu(r2+#0) = v20
	}
	{
		r2 = add(r0,#1280)
		v21 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v21,v0)
	}
	{
		r2 = add(r1,#1408)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#1408)
		v23 = vmemu(r2+#0)
	}
	{
		v24 = vxor(v23,v0)
	}
	{
		r2 = add(r1,#1536)
		vmemu(r2+#0) = v24
	}
	{
		r2 = add(r0,#1536)
		v25 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v25,v0)
	}
	{
		r2 = add(r1,#1664)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#1664)
		v27 = vmemu(r2+#0)
	}
	{
		v28 = vxor(v27,v0)
	}
	{
		r2 = add(r1,#1792)
		r1 = add(r1,#1920)
		vmemu(r2+#0) = v28
	}
	{
		r2 = add(r0,#1792)
		r0 = add(r0,#1920)
		v29 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v29,v0)
	}
	{
		vmemu(r2+#0) = v30
	}
	{
		v31 = vmemu(r1+#0)
	}
	{
		v0 = vxor(v31,v0)
	}
	{
		jumpr r31
		vmemu(r0+#0) = v0
	}
.Lfunc_end4:
	.size	copy2048, .Lfunc_end4-copy2048
                                        // -- End function
	.globl	copy4096                        // -- Begin function copy4096
	.falign
	.type	copy4096,@function
copy4096:                               // @copy4096
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v1 = vmemu(r1+#0)
	}
	{
		v0 = vsplat(r2)
		r2 = add(r1,#1024)
	}
	{
		v2 = vxor(v1,v0)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v0)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v0)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v0)
	}
	{
		vmemu(r0+#3) = v8
	}
	{
		v9 = vmemu(r1+#4)
	}
	{
		v10 = vxor(v9,v0)
	}
	{
		vmemu(r0+#4) = v10
	}
	{
		v11 = vmemu(r1+#5)
	}
	{
		v12 = vxor(v11,v0)
	}
	{
		vmemu(r0+#5) = v12
	}
	{
		v13 = vmemu(r1+#6)
	}
	{
		v14 = vxor(v13,v0)
	}
	{
		vmemu(r0+#6) = v14
	}
	{
		v15 = vmemu(r1+#7)
	}
	{
		v16 = vxor(v15,v0)
	}
	{
		vmemu(r0+#7) = v16
	}
	{
		r2 = add(r0,#1024)
		v17 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v17,v0)
	}
	{
		r2 = add(r1,#1152)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#1152)
		v19 = vmemu(r2+#0)
	}
	{
		v20 = vxor(v19,v0)
	}
	{
		r2 = add(r1,#1280)
		vmemu(r2+#0) = v20
	}
	{
		r2 = add(r0,#1280)
		v21 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v21,v0)
	}
	{
		r2 = add(r1,#1408)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#1408)
		v23 = vmemu(r2+#0)
	}
	{
		v24 = vxor(v23,v0)
	}
	{
		r2 = add(r1,#1536)
		vmemu(r2+#0) = v24
	}
	{
		r2 = add(r0,#1536)
		v25 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v25,v0)
	}
	{
		r2 = add(r1,#1664)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#1664)
		v27 = vmemu(r2+#0)
	}
	{
		v28 = vxor(v27,v0)
	}
	{
		r2 = add(r1,#1792)
		vmemu(r2+#0) = v28
	}
	{
		r2 = add(r0,#1792)
		v29 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v29,v0)
	}
	{
		r2 = add(r1,#1920)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#1920)
		v31 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v31,v0)
	}
	{
		r2 = add(r1,#2048)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#2048)
		v2 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v2,v0)
	}
	{
		r2 = add(r1,#2176)
		vmemu(r2+#0) = v31
	}
	{
		r2 = add(r0,#2176)
		v4 = vmemu(r2+#0)
	}
	{
		v2 = vxor(v4,v0)
	}
	{
		r2 = add(r1,#2304)
		vmemu(r2+#0) = v2
	}
	{
		r2 = add(r0,#2304)
		v6 = vmemu(r2+#0)
	}
	{
		v3 = vxor(v6,v0)
	}
	{
		r2 = add(r1,#2432)
		vmemu(r2+#0) = v3
	}
	{
		r2 = add(r0,#2432)
		v8 = vmemu(r2+#0)
	}
	{
		v6 = vxor(v8,v0)
	}
	{
		r2 = add(r1,#2560)
		vmemu(r2+#0) = v6
	}
	{
		r2 = add(r0,#2560)
		v10 = vmemu(r2+#0)
	}
	{
		v7 = vxor(v10,v0)
	}
	{
		r2 = add(r1,#2688)
		vmemu(r2+#0) = v7
	}
	{
		r2 = add(r0,#2688)
		v12 = vmemu(r2+#0)
	}
	{
		v10 = vxor(v12,v0)
	}
	{
		r2 = add(r1,#2816)
		vmemu(r2+#0) = v10
	}
	{
		r2 = add(r0,#2816)
		v14 = vmemu(r2+#0)
	}
	{
		v11 = vxor(v14,v0)
	}
	{
		r2 = add(r1,#2944)
		vmemu(r2+#0) = v11
	}
	{
		r2 = add(r0,#2944)
		v16 = vmemu(r2+#0)
	}
	{
		v14 = vxor(v16,v0)
	}
	{
		r2 = add(r1,#3072)
		vmemu(r2+#0) = v14
	}
	{
		r2 = add(r0,#3072)
		v18 = vmemu(r2+#0)
	}
	{
		v15 = vxor(v18,v0)
	}
	{
		r2 = add(r1,#3200)
		vmemu(r2+#0) = v15
	}
	{
		r2 = add(r0,#3200)
		v20 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v20,v0)
	}
	{
		r2 = add(r1,#3328)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#3328)
		v22 = vmemu(r2+#0)
	}
	{
		v19 = vxor(v22,v0)
	}
	{
		r2 = add(r1,#3456)
		vmemu(r2+#0) = v19
	}
	{
		r2 = add(r0,#3456)
		v24 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v24,v0)
	}
	{
		r2 = add(r1,#3584)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#3584)
		v26 = vmemu(r2+#0)
	}
	{
		v23 = vxor(v26,v0)
	}
	{
		r2 = add(r1,#3712)
		vmemu(r2+#0) = v23
	}
	{
		r2 = add(r0,#3712)
		v28 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v28,v0)
	}
	{
		r2 = add(r1,#3840)
		r1 = add(r1,#3968)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#3840)
		r0 = add(r0,#3968)
		v30 = vmemu(r2+#0)
	}
	{
		v27 = vxor(v30,v0)
	}
	{
		vmemu(r2+#0) = v27
	}
	{
		v1 = vmemu(r1+#0)
	}
	{
		v0 = vxor(v1,v0)
	}
	{
		jumpr r31
		vmemu(r0+#0) = v0
	}
.Lfunc_end5:
	.size	copy4096, .Lfunc_end5-copy4096
                                        // -- End function
	.globl	copy8192                        // -- Begin function copy8192
	.falign
	.type	copy8192,@function
copy8192:                               // @copy8192
// %bb.0:                               // %entry
	{
		r2 = ##-2139062144
		v1 = vmemu(r1+#0)
	}
	{
		v0 = vsplat(r2)
		r2 = add(r1,#1024)
	}
	{
		v2 = vxor(v1,v0)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v0)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v0)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v0)
	}
	{
		vmemu(r0+#3) = v8
	}
	{
		v9 = vmemu(r1+#4)
	}
	{
		v10 = vxor(v9,v0)
	}
	{
		vmemu(r0+#4) = v10
	}
	{
		v11 = vmemu(r1+#5)
	}
	{
		v12 = vxor(v11,v0)
	}
	{
		vmemu(r0+#5) = v12
	}
	{
		v13 = vmemu(r1+#6)
	}
	{
		v14 = vxor(v13,v0)
	}
	{
		vmemu(r0+#6) = v14
	}
	{
		v15 = vmemu(r1+#7)
	}
	{
		v16 = vxor(v15,v0)
	}
	{
		vmemu(r0+#7) = v16
	}
	{
		r2 = add(r0,#1024)
		v17 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v17,v0)
	}
	{
		r2 = add(r1,#1152)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#1152)
		v19 = vmemu(r2+#0)
	}
	{
		v20 = vxor(v19,v0)
	}
	{
		r2 = add(r1,#1280)
		vmemu(r2+#0) = v20
	}
	{
		r2 = add(r0,#1280)
		v21 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v21,v0)
	}
	{
		r2 = add(r1,#1408)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#1408)
		v23 = vmemu(r2+#0)
	}
	{
		v24 = vxor(v23,v0)
	}
	{
		r2 = add(r1,#1536)
		vmemu(r2+#0) = v24
	}
	{
		r2 = add(r0,#1536)
		v25 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v25,v0)
	}
	{
		r2 = add(r1,#1664)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#1664)
		v27 = vmemu(r2+#0)
	}
	{
		v28 = vxor(v27,v0)
	}
	{
		r2 = add(r1,#1792)
		vmemu(r2+#0) = v28
	}
	{
		r2 = add(r0,#1792)
		v29 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v29,v0)
	}
	{
		r2 = add(r1,#1920)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#1920)
		v31 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v31,v0)
	}
	{
		r2 = add(r1,#2048)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#2048)
		v2 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v2,v0)
	}
	{
		r2 = add(r1,#2176)
		vmemu(r2+#0) = v31
	}
	{
		r2 = add(r0,#2176)
		v4 = vmemu(r2+#0)
	}
	{
		v2 = vxor(v4,v0)
	}
	{
		r2 = add(r1,#2304)
		vmemu(r2+#0) = v2
	}
	{
		r2 = add(r0,#2304)
		v6 = vmemu(r2+#0)
	}
	{
		v3 = vxor(v6,v0)
	}
	{
		r2 = add(r1,#2432)
		vmemu(r2+#0) = v3
	}
	{
		r2 = add(r0,#2432)
		v8 = vmemu(r2+#0)
	}
	{
		v6 = vxor(v8,v0)
	}
	{
		r2 = add(r1,#2560)
		vmemu(r2+#0) = v6
	}
	{
		r2 = add(r0,#2560)
		v10 = vmemu(r2+#0)
	}
	{
		v7 = vxor(v10,v0)
	}
	{
		r2 = add(r1,#2688)
		vmemu(r2+#0) = v7
	}
	{
		r2 = add(r0,#2688)
		v12 = vmemu(r2+#0)
	}
	{
		v10 = vxor(v12,v0)
	}
	{
		r2 = add(r1,#2816)
		vmemu(r2+#0) = v10
	}
	{
		r2 = add(r0,#2816)
		v14 = vmemu(r2+#0)
	}
	{
		v11 = vxor(v14,v0)
	}
	{
		r2 = add(r1,#2944)
		vmemu(r2+#0) = v11
	}
	{
		r2 = add(r0,#2944)
		v16 = vmemu(r2+#0)
	}
	{
		v14 = vxor(v16,v0)
	}
	{
		r2 = add(r1,#3072)
		vmemu(r2+#0) = v14
	}
	{
		r2 = add(r0,#3072)
		v18 = vmemu(r2+#0)
	}
	{
		v15 = vxor(v18,v0)
	}
	{
		r2 = add(r1,#3200)
		vmemu(r2+#0) = v15
	}
	{
		r2 = add(r0,#3200)
		v20 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v20,v0)
	}
	{
		r2 = add(r1,#3328)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#3328)
		v22 = vmemu(r2+#0)
	}
	{
		v19 = vxor(v22,v0)
	}
	{
		r2 = add(r1,#3456)
		vmemu(r2+#0) = v19
	}
	{
		r2 = add(r0,#3456)
		v24 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v24,v0)
	}
	{
		r2 = add(r1,#3584)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#3584)
		v26 = vmemu(r2+#0)
	}
	{
		v23 = vxor(v26,v0)
	}
	{
		r2 = add(r1,#3712)
		vmemu(r2+#0) = v23
	}
	{
		r2 = add(r0,#3712)
		v28 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v28,v0)
	}
	{
		r2 = add(r1,#3840)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#3840)
		v30 = vmemu(r2+#0)
	}
	{
		v27 = vxor(v30,v0)
	}
	{
		r2 = add(r1,#3968)
		vmemu(r2+#0) = v27
	}
	{
		r2 = add(r0,#3968)
		v1 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v1,v0)
	}
	{
		r2 = add(r1,#4096)
		vmemu(r2+#0) = v31
	}
	{
		r2 = add(r0,#4096)
		v3 = vmemu(r2+#0)
	}
	{
		v2 = vxor(v3,v0)
	}
	{
		r2 = add(r1,#4224)
		vmemu(r2+#0) = v2
	}
	{
		r2 = add(r0,#4224)
		v5 = vmemu(r2+#0)
	}
	{
		v3 = vxor(v5,v0)
	}
	{
		r2 = add(r1,#4352)
		vmemu(r2+#0) = v3
	}
	{
		r2 = add(r0,#4352)
		v7 = vmemu(r2+#0)
	}
	{
		v6 = vxor(v7,v0)
	}
	{
		r2 = add(r1,#4480)
		vmemu(r2+#0) = v6
	}
	{
		r2 = add(r0,#4480)
		v9 = vmemu(r2+#0)
	}
	{
		v7 = vxor(v9,v0)
	}
	{
		r2 = add(r1,#4608)
		vmemu(r2+#0) = v7
	}
	{
		r2 = add(r0,#4608)
		v11 = vmemu(r2+#0)
	}
	{
		v10 = vxor(v11,v0)
	}
	{
		r2 = add(r1,#4736)
		vmemu(r2+#0) = v10
	}
	{
		r2 = add(r0,#4736)
		v13 = vmemu(r2+#0)
	}
	{
		v11 = vxor(v13,v0)
	}
	{
		r2 = add(r1,#4864)
		vmemu(r2+#0) = v11
	}
	{
		r2 = add(r0,#4864)
		v15 = vmemu(r2+#0)
	}
	{
		v14 = vxor(v15,v0)
	}
	{
		r2 = add(r1,#4992)
		vmemu(r2+#0) = v14
	}
	{
		r2 = add(r0,#4992)
		v17 = vmemu(r2+#0)
	}
	{
		v15 = vxor(v17,v0)
	}
	{
		r2 = add(r1,#5120)
		vmemu(r2+#0) = v15
	}
	{
		r2 = add(r0,#5120)
		v19 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v19,v0)
	}
	{
		r2 = add(r1,#5248)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#5248)
		v21 = vmemu(r2+#0)
	}
	{
		v19 = vxor(v21,v0)
	}
	{
		r2 = add(r1,#5376)
		vmemu(r2+#0) = v19
	}
	{
		r2 = add(r0,#5376)
		v23 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v23,v0)
	}
	{
		r2 = add(r1,#5504)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#5504)
		v25 = vmemu(r2+#0)
	}
	{
		v23 = vxor(v25,v0)
	}
	{
		r2 = add(r1,#5632)
		vmemu(r2+#0) = v23
	}
	{
		r2 = add(r0,#5632)
		v27 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v27,v0)
	}
	{
		r2 = add(r1,#5760)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#5760)
		v29 = vmemu(r2+#0)
	}
	{
		v27 = vxor(v29,v0)
	}
	{
		r2 = add(r1,#5888)
		vmemu(r2+#0) = v27
	}
	{
		r2 = add(r0,#5888)
		v31 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v31,v0)
	}
	{
		r2 = add(r1,#6016)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#6016)
		v2 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v2,v0)
	}
	{
		r2 = add(r1,#6144)
		vmemu(r2+#0) = v31
	}
	{
		r2 = add(r0,#6144)
		v4 = vmemu(r2+#0)
	}
	{
		v2 = vxor(v4,v0)
	}
	{
		r2 = add(r1,#6272)
		vmemu(r2+#0) = v2
	}
	{
		r2 = add(r0,#6272)
		v6 = vmemu(r2+#0)
	}
	{
		v3 = vxor(v6,v0)
	}
	{
		r2 = add(r1,#6400)
		vmemu(r2+#0) = v3
	}
	{
		r2 = add(r0,#6400)
		v8 = vmemu(r2+#0)
	}
	{
		v6 = vxor(v8,v0)
	}
	{
		r2 = add(r1,#6528)
		vmemu(r2+#0) = v6
	}
	{
		r2 = add(r0,#6528)
		v10 = vmemu(r2+#0)
	}
	{
		v7 = vxor(v10,v0)
	}
	{
		r2 = add(r1,#6656)
		vmemu(r2+#0) = v7
	}
	{
		r2 = add(r0,#6656)
		v12 = vmemu(r2+#0)
	}
	{
		v10 = vxor(v12,v0)
	}
	{
		r2 = add(r1,#6784)
		vmemu(r2+#0) = v10
	}
	{
		r2 = add(r0,#6784)
		v14 = vmemu(r2+#0)
	}
	{
		v11 = vxor(v14,v0)
	}
	{
		r2 = add(r1,#6912)
		vmemu(r2+#0) = v11
	}
	{
		r2 = add(r0,#6912)
		v16 = vmemu(r2+#0)
	}
	{
		v14 = vxor(v16,v0)
	}
	{
		r2 = add(r1,#7040)
		vmemu(r2+#0) = v14
	}
	{
		r2 = add(r0,#7040)
		v18 = vmemu(r2+#0)
	}
	{
		v15 = vxor(v18,v0)
	}
	{
		r2 = add(r1,#7168)
		vmemu(r2+#0) = v15
	}
	{
		r2 = add(r0,#7168)
		v20 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v20,v0)
	}
	{
		r2 = add(r1,#7296)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#7296)
		v22 = vmemu(r2+#0)
	}
	{
		v19 = vxor(v22,v0)
	}
	{
		r2 = add(r1,#7424)
		vmemu(r2+#0) = v19
	}
	{
		r2 = add(r0,#7424)
		v24 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v24,v0)
	}
	{
		r2 = add(r1,#7552)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#7552)
		v26 = vmemu(r2+#0)
	}
	{
		v23 = vxor(v26,v0)
	}
	{
		r2 = add(r1,#7680)
		vmemu(r2+#0) = v23
	}
	{
		r2 = add(r0,#7680)
		v28 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v28,v0)
	}
	{
		r2 = add(r1,#7808)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#7808)
		v30 = vmemu(r2+#0)
	}
	{
		v27 = vxor(v30,v0)
	}
	{
		r2 = add(r1,#7936)
		r1 = add(r1,#8064)
		vmemu(r2+#0) = v27
	}
	{
		r2 = add(r0,#7936)
		r0 = add(r0,#8064)
		v1 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v1,v0)
	}
	{
		vmemu(r2+#0) = v31
	}
	{
		v3 = vmemu(r1+#0)
	}
	{
		v0 = vxor(v3,v0)
	}
	{
		jumpr r31
		vmemu(r0+#0) = v0
	}
.Lfunc_end6:
	.size	copy8192, .Lfunc_end6-copy8192
                                        // -- End function
	.globl	copy16384                       // -- Begin function copy16384
	.falign
	.type	copy16384,@function
copy16384:                              // @copy16384
// %bb.0:                               // %entry
	{
		loop0(.LBB7_1,#4)
		r2 = ##-2139062144
	}
	{
		v0 = vsplat(r2)
	}
	.falign
.LBB7_1:                                // Block address taken
                                        // %for.body.i
                                        // =>This Inner Loop Header: Depth=1
	{
		r2 = add(r1,#1024)
		v1 = vmemu(r1+#0)
	}
	{
		v2 = vxor(v1,v0)
	}
	{
		vmemu(r0+#0) = v2
	}
	{
		v3 = vmemu(r1+#1)
	}
	{
		v4 = vxor(v3,v0)
	}
	{
		vmemu(r0+#1) = v4
	}
	{
		v5 = vmemu(r1+#2)
	}
	{
		v6 = vxor(v5,v0)
	}
	{
		vmemu(r0+#2) = v6
	}
	{
		v7 = vmemu(r1+#3)
	}
	{
		v8 = vxor(v7,v0)
	}
	{
		vmemu(r0+#3) = v8
	}
	{
		v9 = vmemu(r1+#4)
	}
	{
		v10 = vxor(v9,v0)
	}
	{
		vmemu(r0+#4) = v10
	}
	{
		v11 = vmemu(r1+#5)
	}
	{
		v12 = vxor(v11,v0)
	}
	{
		vmemu(r0+#5) = v12
	}
	{
		v13 = vmemu(r1+#6)
	}
	{
		v14 = vxor(v13,v0)
	}
	{
		vmemu(r0+#6) = v14
	}
	{
		v15 = vmemu(r1+#7)
	}
	{
		v16 = vxor(v15,v0)
	}
	{
		vmemu(r0+#7) = v16
	}
	{
		r2 = add(r0,#1024)
		v17 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v17,v0)
	}
	{
		r2 = add(r1,#1152)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#1152)
		v19 = vmemu(r2+#0)
	}
	{
		v20 = vxor(v19,v0)
	}
	{
		r2 = add(r1,#1280)
		vmemu(r2+#0) = v20
	}
	{
		r2 = add(r0,#1280)
		v21 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v21,v0)
	}
	{
		r2 = add(r1,#1408)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#1408)
		v23 = vmemu(r2+#0)
	}
	{
		v24 = vxor(v23,v0)
	}
	{
		r2 = add(r1,#1536)
		vmemu(r2+#0) = v24
	}
	{
		r2 = add(r0,#1536)
		v25 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v25,v0)
	}
	{
		r2 = add(r1,#1664)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#1664)
		v27 = vmemu(r2+#0)
	}
	{
		v28 = vxor(v27,v0)
	}
	{
		r2 = add(r1,#1792)
		vmemu(r2+#0) = v28
	}
	{
		r2 = add(r0,#1792)
		v29 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v29,v0)
	}
	{
		r2 = add(r1,#1920)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#1920)
		v31 = vmemu(r2+#0)
	}
	{
		v1 = vxor(v31,v0)
	}
	{
		r2 = add(r1,#2048)
		vmemu(r2+#0) = v1
	}
	{
		r2 = add(r0,#2048)
		v2 = vmemu(r2+#0)
	}
	{
		v3 = vxor(v2,v0)
	}
	{
		r2 = add(r1,#2176)
		vmemu(r2+#0) = v3
	}
	{
		r2 = add(r0,#2176)
		v4 = vmemu(r2+#0)
	}
	{
		v30 = vxor(v4,v0)
	}
	{
		r2 = add(r1,#2304)
		vmemu(r2+#0) = v30
	}
	{
		r2 = add(r0,#2304)
		v6 = vmemu(r2+#0)
	}
	{
		v31 = vxor(v6,v0)
	}
	{
		r2 = add(r1,#2432)
		vmemu(r2+#0) = v31
	}
	{
		r2 = add(r0,#2432)
		v8 = vmemu(r2+#0)
	}
	{
		v6 = vxor(v8,v0)
	}
	{
		r2 = add(r1,#2560)
		vmemu(r2+#0) = v6
	}
	{
		r2 = add(r0,#2560)
		v10 = vmemu(r2+#0)
	}
	{
		v7 = vxor(v10,v0)
	}
	{
		r2 = add(r1,#2688)
		vmemu(r2+#0) = v7
	}
	{
		r2 = add(r0,#2688)
		v12 = vmemu(r2+#0)
	}
	{
		v10 = vxor(v12,v0)
	}
	{
		r2 = add(r1,#2816)
		vmemu(r2+#0) = v10
	}
	{
		r2 = add(r0,#2816)
		v14 = vmemu(r2+#0)
	}
	{
		v11 = vxor(v14,v0)
	}
	{
		r2 = add(r1,#2944)
		vmemu(r2+#0) = v11
	}
	{
		r2 = add(r0,#2944)
		v16 = vmemu(r2+#0)
	}
	{
		v14 = vxor(v16,v0)
	}
	{
		r2 = add(r1,#3072)
		vmemu(r2+#0) = v14
	}
	{
		r2 = add(r0,#3072)
		v18 = vmemu(r2+#0)
	}
	{
		v15 = vxor(v18,v0)
	}
	{
		r2 = add(r1,#3200)
		vmemu(r2+#0) = v15
	}
	{
		r2 = add(r0,#3200)
		v20 = vmemu(r2+#0)
	}
	{
		v18 = vxor(v20,v0)
	}
	{
		r2 = add(r1,#3328)
		vmemu(r2+#0) = v18
	}
	{
		r2 = add(r0,#3328)
		v22 = vmemu(r2+#0)
	}
	{
		v19 = vxor(v22,v0)
	}
	{
		r2 = add(r1,#3456)
		vmemu(r2+#0) = v19
	}
	{
		r2 = add(r0,#3456)
		v24 = vmemu(r2+#0)
	}
	{
		v22 = vxor(v24,v0)
	}
	{
		r2 = add(r1,#3584)
		vmemu(r2+#0) = v22
	}
	{
		r2 = add(r0,#3584)
		v26 = vmemu(r2+#0)
	}
	{
		v23 = vxor(v26,v0)
	}
	{
		r2 = add(r1,#3712)
		vmemu(r2+#0) = v23
	}
	{
		r2 = add(r0,#3712)
		v28 = vmemu(r2+#0)
	}
	{
		v26 = vxor(v28,v0)
	}
	{
		r2 = add(r1,#3840)
		vmemu(r2+#0) = v26
	}
	{
		r2 = add(r0,#3840)
		v30 = vmemu(r2+#0)
	}
	{
		v27 = vxor(v30,v0)
	}
	{
		r2 = add(r1,#3968)
		r1 = add(r1,#4096)
		vmemu(r2+#0) = v27
	}
	{
		r2 = add(r0,#3968)
		r0 = add(r0,#4096)
		v1 = vmemu(r2+#0)
	}
	{
		v2 = vxor(v1,v0)
	}
	{
		nop
		vmemu(r2+#0) = v2
	} :endloop0
// %bb.2:                               // %xor80_copy.exit
	{
		jumpr r31
	}
.Lfunc_end7:
	.size	copy16384, .Lfunc_end7-copy16384
                                        // -- End function
	.ident	"QuIC LLVM Hexagon Clang version 19.0.04"
	.section	".note.GNU-stack","",@progbits
	.addrsig

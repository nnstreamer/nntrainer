#include "hvx_tile_f16.h"
static inline void xor80_copy(uint8_t *dst, const uint8_t *src, uint32_t n) {
  const HVX_Vector x = Q6_V_vsplat_R(0x80808080);
  const uint32_t full = n & ~127u;
  uint32_t i = 0;
  for (; i < full; i += 128u) {
    hvx_tile_store_u(dst + i, Q6_V_vxor_VV(hvx_tile_load_u(src + i), x));
  }
  // Legal head dimensions include 32, 64 and 96: do not touch the next row.
  for (; i < n; ++i) {
    dst[i] = src[i] ^ 0x80u;
  }
}
void copy128(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 128u); }
void copy256(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 256u); }
void copy512(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 512u); }
void copy1024(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 1024u); }
void copy2048(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 2048u); }
void copy4096(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 4096u); }
void copy8192(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 8192u); }
void copy16384(uint8_t *dst, const uint8_t *src) { xor80_copy(dst, src, 16384u); }

/* Copyright 2019 Google LLC. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#ifndef RUY_RUY_PMU_H_
#define RUY_RUY_PMU_H_

namespace ruy {

class PmuEventsPrivate;

class PmuEvents {
 public:
  PmuEvents();
  ~PmuEvents();
  void StartRecording();
  void StopRecording();
  float L1RefillCount() const;
  float L2RefillCount() const;
  float L3RefillCount() const;
  float BranchMispredictionCount() const;
  float FrontendStallCount() const;
  float BackendStallCount() const;
  float L1TLBRefillCount() const;
  float L2TLBRefillCount() const;
  float L1WritebackCount() const;
  float L2WritebackCount() const;

 private:
  PmuEventsPrivate* priv = nullptr;
};

}  // namespace ruy

#endif  // RUY_RUY_PMU_H_
